<? 
if($HTTP_COOKIE_VARS[unick] == "phpmysql") {
?>
<? // TUTORIALES
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borrartutorial) { 
    $query = "delete from tutoriales where id='$borrartutorial'"; mysql_query($query); 
    echo "<b>Borrado el tutorial <b>$borrartutorial</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de tutoriales</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from tutoriales order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[id]</td>
    <td>$datos[usuario]</td>
    <td>$datos[titulo]</td>
    <td><a href=index.php?id=administrar&borrartutorial=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?>
<br>
<br>
<? // ENLACES
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borrarenlace) { 
    $query = "delete from enlaces where id='$borrarenlace'"; mysql_query($query); 
    echo "<b>Borrado el enlace <b>$borrarenlace</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de enlaces</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from enlaces order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[id]</td>
    <td>$datos[usuario]</td>
    <td>$datos[descripcion]</td>
    <td><a href=index.php?id=administrar&borrarenlace=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?>
<br>
<br>
<? // DESCARGAS
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borrardescarga) { 
    $query = "delete from descargas where id='$borrardescarga'"; mysql_query($query); 
    echo "<b>Borrado la descarga <b>$borrardescarga</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de descargas</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from descargas order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[usuario]</td>
    <td>$datos[descripcion]</td>
    <td><a href=index.php?id=administrar&borrardescarga=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?>
<br>
<br>
<?  // USUARIOS
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borrarusuario) { 
    $query = "delete from usuarios where id='$borrarusuario'"; mysql_query($query); 
    echo "<b>Borrado la descarga <b>$borrarusuario</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de usuarios</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from usuarios order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[nick]</td>
    <td>$datos[email]</td>
    <td><a href=index.php?id=administrar&borrarusuario=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?>
<br>
<br>
<? // NOTICIAS
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borranoticia) { 
    $query = "delete from noticias where id='$borranoticia'"; mysql_query($query); 
    echo "<b>Borrado la noticia <b>$borranoticia</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de Noticias</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from noticias order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[usuario]</td>
    <td>$datos[titulo]</td>
    <td><a href=index.php?id=administrar&borranoticia=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?>
<br>
<br>
<?  // COMENARIOS DE NOTICIAS
include("config.php");
//si se pide borrar algun tutorial ... 
if ($borranoticiacom) { 
    $query = "delete from noticiascom where id='$borranoticiacom'"; mysql_query($query); 
    echo "<b>Borrado la noticia <b>$borranoticiacom</b>. <a href=index.php?id=administrar</a><br><br>"; 
} 
//muestra todos los registros de los tutoriales<br>
echo "<b>Listado de Noticias Comentarios</b>"; 
echo "<table width=100% border=0 cellpadding=5 cellspacing=0 align=center style=border: #757575 1 solid>"; 
$query = "select * from noticiascom order by id"; 
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
echo "<tr>
    <td>$datos[usuario]</td>
    <td>$datos[comentario]</td>
    <td><a href=index.php?id=administrar&borranoticiacom=$datos[id]>borrar</a></td>
    "; 
} 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
mysql_free_result($resp); 
@mysql_close($conecta); 

?><br>
<?

}

else {

echo "Solo phpmysql puede administrar el sitio." ;

}

?>
