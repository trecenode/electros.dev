<? 
session_start(); 
if(isset($SESSION)){ 
"<script>location.href='user.php'</script>";
} else {  
?> 
<html><head><title>Necesita identificaci�n! </title></head> 
<body> 
<center><h1>Identificate! :D </h1></center> 
<form action="comprueba.php" method="POST"> 
Login: <input type="text" name="login"><br> 
Password: <input type="password" name="pass"><br> 
<input type="submit" value="Entrar"> 
</form> 
</body></html> 
<? 
} 
?> 

 