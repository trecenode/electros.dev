<head>
<form action="crea_user.php" method="POST"> 
Login: <input type="text" name="login"><br> 
Password: <input type="password" name="pass1"><br> 
Repite Password: <input type="password" name="pass2"><br> 
Nombre: <input type="text" name="nombre"><br> 
Apellidos: <input type="text" name="apellidos"><br> 
E-mail: <input type="text" name="email"><br> 
<input type="submit" name="Crear"> 
</form> 
</head>