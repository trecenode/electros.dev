<? 
$server="localhost"; 
$database="user"; 
$dbpass="pass"; 
$dbuser="user";
$query="SELECT * FROM usuarios WHERE login='$login'"; 
$link=mysql_connect($server,$dbuser,$dbpass); 
$result=mysql_db_query($database,$query,$link); 
if(mysql_num_rows($result)){ 
echo "El usuario ya existe en la BD"; 
} else { 
mysql_free_result($result); 
if($pass1!=$pass2) { 
echo "Los passwords deben coincidir<br>"; 
echo 'Clica <a href="form.php">aqu�</a> para volver al formulario'; 
} else { 
$pass1=crypt($pass2, "semilla");  
$query="INSERT INTO usuarios (login, nombre, apellidos, password, email) VALUES ('$login','$nombre','$apellidos','$pass1','$email')"; 

$result=mysql_db_query($database,$query,$link); 
if(mysql_affected_rows($link)){ 
echo "Usuario introducido correctamente"; 
} else { 
echo "Error introduciendo el usuario"; 
}  
} 
}  
?>
