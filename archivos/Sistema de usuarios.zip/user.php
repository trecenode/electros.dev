<? 
session_start(); 
if(!isset($SESSION)){ 
header("location: login.php"); 
} else { 
echo "<html><body>"; 
echo "Bienvenido "; 
echo $SESSION["nombre"]; 
echo $SESSION["apellidos"]." "; 
echo "<br>Has entrado con el nombre de usuario "; 
echo $SESSION["login"]; 
echo "<br>Para cerrar la sesi�n, pulsa: <a href='logout.php'>logout</a>"; 
echo "</body></html>"; 
} 
?> 