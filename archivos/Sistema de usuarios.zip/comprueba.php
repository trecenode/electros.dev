﻿<?
session_start();
$server="localhost";
$database="db";
$dbpass="pass";
$dbuser="user";
$query="SELECT * FROM usuarios WHERE login='$login'";
$link=mysql_connect($server,$dbuser,$dbpass);
$result=mysql_db_query($database,$query,$link);
if(mysql_num_rows($result)==0){
echo "No existe el login introducido";
} else {
$array=mysql_fetch_array($result);
if($array["password"]==crypt($pass,"semilla") ){
$SESSION["login"]=$login;
$SESSION["nombre"]=$array["nombre"];
$SESSION["apellidos"]=$array["apellidos"];
session_register("SESSION");
header("location:user.php");

} else {
echo "Password incorrecto!";
}
} 
?>
