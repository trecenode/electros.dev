<? 
session_start(); 
if(!isset($SESSION)){ 
header("location: login.php"); 
} else { 
session_unset(); 
session_destroy(); 
echo "Las variables de sesi�n han sido eliminadas, y la sesi�n se ha dado por finalizada correctamente ;-)"; 
} 
?> 
