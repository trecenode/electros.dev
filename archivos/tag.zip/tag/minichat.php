<?
//****************************
//*** MiniChat v.1.2       ***
//*** Creado por: Electros ***
//*** Web: www.electros.tk ***
//****************************

//*********************
//*** Configuraci�n ***
//*********************

// Mensajes a mostrar (0 para mostrar todos)
$mostrar = 30 ;
// Maximo de caracteres por nick
$max_nick = 20 ;
// Maximo de caracteres por mensaje
$max_mensaje = 200 ;
// Maximo de caracteres por web
$max_web = 50 ;
// Maximo de caracteres por palabra (palabras muy grandes como una URL puede descuadrar el dise�o
// y ocasionar que el minichat no se vea correctamente) si no deseas esta opci�n pon 0.
$max_palabra = 25 ;
// Caretos
$caretos = "ON" ;
// Censura de palabras
$censura = "OFF" ;
// Permitir c�digo HTML (se recomienda que est� desactivado)
$codigo = "OFF" ;
// Altura de la tabla de mensajes (cuando los mensajes mostrados rebasan la altura marcada
// aparece una barra de desplazamiento) 
$altura = 100 ;
// Estilo (archivo que contiene el estilo del minichat, tipo de letra, tama�o, color, fondo)
$estilo = "estilo.php" ;
// Lista de caretos (si $caretos est� en ON)
if($caretos == "ON") {
function caretos($texto) {
// --> Inicio caretos
$texto = str_replace(":D","[:alegre.gif:]",$texto) ;
$texto = str_replace(":8","[:asustado.gif:]",$texto) ;
$texto = str_replace(":P","[:burla.gif:]",$texto) ;
$texto = str_replace(":S","[:confundido.gif:]",$texto) ;
$texto = str_replace(":(1","[:demonio.gif:]",$texto) ;
$texto = str_replace(":(2","[:demonio2.gif:]",$texto) ;
$texto = str_replace(":?","[:duda.gif:]",$texto) ;
$texto = str_replace(":-(","[:enojado.gif:]",$texto) ;
$texto = str_replace(";)","[:guino.gif:]",$texto) ;
$texto = str_replace(":'(","[:llorar.gif:]",$texto) ;
$texto = str_replace(":lol","[:lol.gif:]",$texto) ;
$texto = str_replace(":M","[:moda.gif:]",$texto) ;
$texto = str_replace(":|","[:neutral.gif:]",$texto) ;
$texto = str_replace(":)","[:risa.gif:]",$texto) ;
$texto = str_replace(":-)","[:sonrisa.gif:]",$texto) ;
$texto = str_replace(":R","[:sonrojado.gif:]",$texto) ;
$texto = str_replace(":O","[:sorprendido.gif:]",$texto) ;
$texto = str_replace(":(","[:triste.gif:]",$texto) ;
// --> Fin caretos
$texto = str_replace("[:","<img src=\"caretos/",$texto) ;
$texto = str_replace(":]","\" width=\"15\" height=\"15\">",$texto) ;
return $texto ;
}
}
// Lista de censura de palabras (si $censura est� en ON)
if($censura == "ON") {
function censura($texto) {
// --> Inicio palabras
$texto = str_replace("insulto","***",$texto) ;
// --> Fin palabras
return $texto ;
}
}
// C�digo HTML (si $codigo est� en OFF)
if($codigo == "OFF") {
function codigo($texto) {
$texto = htmlspecialchars($texto) ;
return $texto ;
}
}

//*******************************
//*** Fin de la configuraci�n ***
//*******************************

// *** Guardar mensaje ***
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = stripslashes($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$mensaje = quitar($mensaje) ;
$web = quitar($web) ;
if($codigo == "OFF") {
$nick = codigo($nick) ;
$mensaje = codigo($mensaje) ;
$web = codigo($web) ;
}
// Si $max_palabra es mayor que cero
if($max_palabra > 0) {
$palabras = explode(" ",$mensaje) ;
$total = count($palabras) ;
for($a = 0 ; $a < $total ; $a++) {
if(strlen($palabras[$a]) > $max_palabra) { $palabras[$a] = chunk_split($palabras[$a],$max_palabra," ") ; }
}
$mensaje = implode($palabras," ") ;
}
$minichat = fopen("minichat.txt",a) ;
if($web == "" || $web == "http://") {
fwrite($minichat,"\n<b>&lt;$nick&gt;</b> $mensaje") ;
}
else {
fwrite($minichat,"\n<a href=\"$web\" target=\"_blank\">&lt;$nick&gt;</a> $mensaje") ;
}
fclose($minichat) ;
}
?>
<html>
<head>
<title></title>
<?
include("$estilo") ;
?>
</head>
<body>
<div style="height: <? echo $altura ?> ; overflow: auto">
<?
// *** Mostrar los mensajes ***
$mensajes = file("minichat.txt") ;
$total = count($mensajes) ;
if($total < $mostrar || $mostrar == 0) {
$maximo = 0 ;
}
else {
$maximo = $total - $mostrar ;
}
while($total > $maximo) {
$total-- ;
$mensaje = $mensajes[$total] ;
if($caretos == "ON") {
$mensaje = caretos($mensaje) ;
}
if($censura == "ON") {
$mensaje = censura($mensaje) ;
}
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="mensaje">
<tr>
<td>
<? echo $mensaje ?>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?
}
?>
</div>
<script>
function revisar(campo) {
if(campo.value=='Tu nick') { campo.value='' ; }
if(campo.value=='Tu mensaje') { campo.value='' ; }
}
function validar() {
if(formulario.nick.value == '' || formulario.nick.value == 'Tu nick') { alert('Debes escribir un nick') ; return false ; }
if(formulario.mensaje.value == '' || formulario.mensaje.value == 'Tu mensaje') { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<script>
function caretos(codigo) {
formulario.mensaje.value += codigo ;
formulario.mensaje.focus() ;
}
</script>
<div align="center">
<form name="formulario" method="post" action="minichat.php" onsubmit="return validar()">
<input type="text" name="nick" size="10" maxlength="<? echo $max_nick ?>" value="Tu nick" onfocus="revisar(this)" class="formulario"><br>
<input type="text" name="mensaje" size="20" maxlength="<? echo $max_mensaje ?>" value="Tu mensaje" onfocus="revisar(this)" class="formulario"><br>
<input type="text" name="web" size="20" maxlength="<? echo $max_web ?>" value="http://" class="formulario"><br>
<input type="submit" name="enviar" value="Enviar" class="formulario">
<p align="center">
<b>Caretos:</b><br>
<table border="0" cellpadding="5" cellspacing="0" align="center">
<tr>
<td><a href="javascript:caretos(':D')"><img src="caretos/alegre.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':8')"><img src="caretos/asustado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':P')"><img src="caretos/burla.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':S')"><img src="caretos/confundido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(1')"><img src="caretos/demonio.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':(2')"><img src="caretos/demonio2.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':?')"><img src="caretos/duda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-(')"><img src="caretos/enojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(';)')"><img src="caretos/guino.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':\'(')"><img src="caretos/llorar.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':lol')"><img src="caretos/lol.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':M')"><img src="caretos/moda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':|')"><img src="caretos/neutral.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':)')"><img src="caretos/risa.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-)')"><img src="caretos/sonrisa.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td></td>
<td><a href="javascript:caretos(':R')"><img src="caretos/sonrojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':O')"><img src="caretos/sorprendido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(')"><img src="caretos/triste.gif" width="15" height="15" border="0"></a></td>
<td></td>
</tr>
</table>
<p>&nbsp;</p>
<div align="center">
</div>
<tr>
</form>
</div>
<p align="center">
<a href="http://peruhack.webcindario.com" target="_blank">MiniChat</a>
</body>
</html>