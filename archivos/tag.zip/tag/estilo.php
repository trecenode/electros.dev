<style>
/*** Cuerpo del MiniChat ***/
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
background: #dddddd ;
margin: 0 ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #444444 ;
scrollbar-highlight-color: #b8c2cc ;
scrollbar-3dlight-color: #99999 ;
scrollbar-track-color: #aaaaaa ;
scrollbar-arrow-color: #000000 ;
}
/*** Enlaces ***/
a {
color: #333333 ;
font-weight: bold ;
}
/*** Color de negrita ***/
b {
color: #646464 ;
}
/*** Tabla de los mensajes ***/
.mensaje {
border: #770000 1 solid ;
background: #dddddd ;
}
/*** Formulario ***/
.formulario {
font-family: verdana ;
font-size: 8pt ;
border: #770000 1 solid ;
background: #dddddd ;
color: #000000 ;
text-align: center ;
}
</style>