<?
//****************************
//*** MiniChat v.1.4       ***
//*** Creado por: Electros ***
//*** Web: www.electros.tk ***
//****************************

//*********************
//*** Configuraci�n ***
//*********************

// Mensajes a mostrar (0 para mostrar todos)
$mostrar = 30 ;
// Maximo de caracteres por nick
$max_nick = 20 ;
// Maximo de caracteres por mensaje
$max_mensaje = 200 ;
// Maximo de caracteres por web
$max_web = 100 ;
// Maximo de caracteres por palabra (palabras muy grandes pueden descuadrar el dise�o y
// ocasionar que el minichat no se vea correctamente) si no deseas esta opci�n pon 0.
$max_palabra = 25 ;
// Caretos
$caretos = "SI" ;
// Mostrar fecha en los mensajes
$fecha_mensajes = "SI" ;
// Mostrar IP en los mensajes
$ip_mensajes = "NO" ;
// Estilo (archivo que contiene el estilo del minichat, tipo de letra, tama�o, color, fondo)
$estilo = "estilo.php" ;
// Filtro Anti-Spam (para evitar el env�o excesivo de direcciones webs, busca cualquier
// direcci�n web contenida en el mensaje y la transformar� en la palabra indicada)
$antispam = "SI" ;
$antispam_palabra = "<i>SPAM</i>" ;
// Censura de palabras
$censura = "NO" ;
// Permitir c�digo HTML (se recomienda que est� desactivado)
$codigo = "NO" ;
// Altura de la tabla de mensajes (cuando los mensajes mostrados rebasan la altura marcada
// aparece una barra de desplazamiento) 
$altura = 125 ;

// *** Fin de configuraci�n b�sica ***

// ***************
// *** Caretos ***
// ***************
if($caretos == "SI") {
function caretos($texto) {
// --> Inicio caretos
$lista_caretos = array(
":D"   => "alegre.gif",
":P"   => "burla.gif",
":(1"  => "demonio.gif",
":?"   => "duda.gif",
";)"   => "guino.gif",
":lol" => "lol.gif",
":|"   => "neutral.gif",
":-)"  => "sonrisa.gif",
":O"   => "sorprendido.gif",
":8"   => "asustado.gif",
":S"   => "confundido.gif",
":(2"  => "demonio2.gif",
":-("  => "enojado.gif",
":'("  => "llorar.gif",
":M"   => "moda.gif",
":)"   => "risa.gif",
":R"   => "sonrojado.gif",
":("   => "triste.gif",
) ;
// --> Fin caretos
foreach($lista_caretos as $a => $b) {
$texto = str_replace($a,"<img src=\"caretos/$b\" width=\"15\" height=\"15\" align=\"absmiddle\">",$texto) ;
}
return $texto ;
}
}

// ***************************
// *** Palabras censuradas ***
// ***************************
if($censura == "SI") {
function censura($texto) {
// --> Inicio palabras
$lista_censura = array(
"insulto1" => "*****",
"insulto2" => "*****",
"insulto3" => "*****"
) ;
// --> Fin palabras
foreach($lista_censura as $a => $b) {
$texto = str_replace($a,$b,$texto) ;
}
return $texto ;
}
}

//*******************************
//*** Fin de la configuraci�n ***
//*******************************

// *** Comprueba si el archivo minichat.txt tiene el permiso CHMOD 666 ***
if(substr(base_convert(fileperms("minichat.txt"),10,8),3) < 666) {
echo "
<style>
.error { font-size: 10pt }
</style>
<div class=\"error\">
<p><b>Error</b>
<p>El archivo <b>minichat.txt</b> debe tener el permiso CHMOD 666.
<p>Se intentar� poner el permiso de forma autom�tica ...
" ;
if(!@chmod("minichat.txt",0666)) { echo "<p>No se pudo modificar el archivo. Debes hacerlo a trav�s de tu programa de FTP favorito." ; }
else { echo "<p>El archivo <b>minichat.txt</b> ha sido modificado. Para finalizar haz click <a href=\"minichat.php\">aqu�</a>." ; }
echo "</div><br>" ;
}

// *** Guardar mensaje ***
if($enviar) {
function limpiar($a) {
$a = trim($a) ;
$a = str_replace("|","",$a) ;
return $a ;
}
$nick = limpiar($nick) ;
$mensaje = limpiar($mensaje) ;
$web = limpiar($web) ;
$minichat = fopen("minichat.txt",a) ;
if($web == "" || $web == "Tu email o web") {
$nick = "<b>&lt;$nick&gt;</b>" ;
}
else {
if(eregi("^www.",$web)) { $web = "http://$web" ; }
if(eregi("^[0-9a-z_\-]+@[0-9a-z_\-\.]+[a-z]{2,3}$",$web)) { $web = "mailto:$web" ; }
$nick = "<a href=\"$web\">&lt;$nick&gt;</a>" ;
}
$meses = array("","Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ; $dia = date(d) ; $mes = date(n) ; $ano = date(Y) ; $fecha = "$dia $meses[$mes] $ano ".date("h:i A") ;
fwrite($minichat,"\r\n$nick | $mensaje | $fecha | $REMOTE_ADDR") ;
fclose($minichat) ;
}
?>
<html>
<head>
<title>MiniChat v.1.3</title>
<?
include("$estilo") ;
?>
<base target="_blank">
</head>
<body>
<div style="height: <?=$altura?> ; overflow: auto">
<?
// *** Mostrar los mensajes ***
$mensajes = file("minichat.txt") ;
$total = count($mensajes) ;
if($total < $mostrar || $mostrar == 0) {
$maximo = 0 ;
}
else {
$maximo = $total - $mostrar ;
}
while($total > $maximo) {
$total-- ;
list($nick,$mensaje,$fecha,$ip) = explode(" | ",$mensajes[$total]) ;
if($codigo == "NO") { $mensaje = htmlspecialchars($mensaje) ; }
if($censura == "SI") { $mensaje = censura($mensaje) ; }
if($antispam == "SI") { $mensaje = preg_replace("/(http:\/\/|www.)[^\s]+/i",$antispam_palabra,$mensaje) ; }
if($max_palabra > 0) {
$palabras = explode(" ",$mensaje) ;
$total_palabras = count($palabras) ;
for($a = 0 ; $a < $total_palabras ; $a++) {
if(strlen($palabras[$a]) > $max_palabra) { $palabras[$a] = chunk_split($palabras[$a],$max_palabra," ") ; }
}
$mensaje = implode($palabras," ") ;
}
if($caretos == "SI") { $mensaje = caretos($mensaje) ; }
if($total % 2) { $estilo_tabla = "mensaje1" ; } else { $estilo_tabla = "mensaje2" ; }
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="<?=$estilo_tabla?>">
<tr>
<td>
<?="$nick $mensaje"?>
<?
if($fecha_mensajes == "SI") { echo "<div class=\"fecha\">$fecha</div>" ; }
if($ip_mensajes == "SI") { echo "<div class=\"ip\">$ip</div>" ; }
?>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?
}
?>
</div>
<script>
enviando = 0 ;
function limpiar(campo) {
if(campo.value=='Tu nick') { campo.value='' ; }
if(campo.value=='Tu mensaje') { campo.value='' ; }
if(campo.value=='Tu email o web') { campo.value='' ; }
}
function validar() {
if(formulario.nick.value == '' || formulario.nick.value == 'Tu nick') { alert('Debes escribir un nick') ; return false ; }
if(formulario.mensaje.value == '' || formulario.mensaje.value == 'Tu mensaje') { alert('Debes escribir un mensaje') ; return false ; }
if(enviando == 0) { enviando++ ; } else { alert('El mensaje se est� enviando') ; return false ; }
}
</script>
<div align="center">
<form name="formulario" method="post" action="minichat.php" target="_self" onsubmit="return validar()">
<input type="text" name="nick" size="10" maxlength="<?=$max_nick?>" value="Tu nick" onfocus="limpiar(this)" class="formulario"><br>
<input type="text" name="mensaje" size="20" maxlength="<?=$max_mensaje?>" value="Tu mensaje" onfocus="limpiar(this)" class="formulario"><br>
<input type="text" name="web" size="20" maxlength="<?=$max_web?>" value="Tu email o web" onfocus="limpiar(this)" class="formulario"><br>
<input type="submit" name="enviar" value="Enviar" class="formulario">
</form>
<div style="font-family: verdana ; font-size: 7pt">
<a href="http://www.electros.tk" target="_blank">MiniChat v.1.4</a>
</div>
</div>
</body>
</html>