<style>
/*** Cuerpo del MiniChat ***/
body,table {
font-family: verdana ;
font-size: 7pt ;
color: #000000 ;
background: #eeeeee ;
margin: 0 ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/*** Enlaces ***/
a {
color: #000000 ;
font-weight: bold ;
}
/*** Negrita ***/
b {
color: #000000 ;
}
/*** Fecha ***/
.fecha {
font-weight: bold ;
color: #757575 ;
text-align: right ;
}
/*** IP ***/
.ip {
font-weight: bold ;
color: #757575 ;
text-align: right ;
}
/*** Tabla de los mensajes ***/
.mensaje1 {
border-color: #000000 ;
border-width: 1 ;
border-style: solid ;
background: #cccccc ;
}
.mensaje2 {
border-color: #000000 ;
border-width: 1 ;
border-style: solid ;
background: #dddddd ;
}
/*** Formulario ***/
.formulario {
font-family: verdana ;
font-size: 7pt ;
border-color: #000000 ;
border-width: 1 ;
border-style: solid ;
background: #bbbbbb ;
color: #000000 ;
text-align: center ;
}
</style>