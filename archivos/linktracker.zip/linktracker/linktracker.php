<?PHP
//********************
//**Link Tracker 0.2**
//**Raymondjavaxx*****
//********************

//**Configuracion**
$ver = 50;
$max_letras = 100;
//*****************
?>
<style>
<!--
.tabla_titulo
{
	color: #444444;
	background-color: #FFC428;
	font-size: 9pt;
	TEXT-DECORATION: none;
	font-weight:bold;
}
.tabla_pie
{
	color: #444444;
	background-color: #FFF0C0;
	font-size: 9pt;
	TEXT-DECORATION: none;
}
.tabla_sombra_1
{
	color: #444444;
	background-color: #E8E8E8;
	font-size: 9pt;
	TEXT-DECORATION: none;
}
.tabla_sombra_2 
{
	color: #444444;
	background-color: #D8D8D8;
	font-size: 9pt;
	TEXT-DECORATION: none;
}
-->
</style>
<table cellSpacing="1" cellPadding="1" border="0">
	<tr class="tabla_titulo">
		<td noWrap align="middle">&nbsp;Fecha&nbsp;</td>
		<td noWrap align="middle">&nbsp;Hora&nbsp;</td>
		<td width="98%" >&nbsp;Url</td>
	</tr>
<?PHP
$archivo = file("track.txt");
$total = count($archivo);
$class = 2;

if($total < $ver || $ver == 0)
{
	$max = 0;
	}
else
{
	$max = $total - $ver;
}

while($total > $max)
{
	$total-- ;
	$dato = explode("|",$archivo[$total]);
	$dato[2] = str_replace("
", "", $dato[2]);
	$mostrarurl = $dato[2];
	if(strlen($mostrarurl) > $max_letras)
	{
		$mostrarurl = chunk_split($mostrarurl,$max_letras,"<br>");
	}
	if ($dato[2] == "Su computador")
	{
		$dato[2] = "#";
	}
	if($class == 1)
	{
		$class = 2;
	}
	else
	{
		$class = 1;
	}
?>
	<tr class="tabla_sombra_<?php echo $class ?>">
		<td noWrap align="middle">&nbsp;<?php echo $dato[0] ?>&nbsp;</td>
		<td noWrap align="middle">&nbsp;<?php echo $dato[1] ?>&nbsp;</td>
		<td width="100%" >&nbsp;<a target="_blank" href="<?php echo $dato[2] ?>"><?php echo $mostrarurl ?></a>
		</td>
	</tr>
<?PHP
}

?>
</table>
<table cellSpacing="1" cellPadding="1" border="0" width="100%">
	<tr class="tabla_pie">
		<td width="75%" >&nbsp;</td>
		<td width="25%" >&nbsp;Link Tracker</td>
	</tr>
</table>