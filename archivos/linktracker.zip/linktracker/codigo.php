<?PHP
//**********************
//***Link Tracker 0.2***
//***Raymondjavaxx******
//**********************

$url=$HTTP_REFERER;
if ($url=="")
{
	$url = "Su computador";
}
$mes = explode(",","Ene,Feb,Mar,Abr,May,Jun,Jul,Ago,Sep,Oct,Nov,Dic");
$fecha = date("d/").$mes[date(m)-1].date("/20y");
$hora = date("H:i");
$archivo = fopen("track.txt",a);
fwrite($archivo,"$fecha|$hora|$url\n");
fclose($archivo);

?>