<table width="100%" border="0" cellspacing="3" cellpadding="2">
  <tr> 
    <td width="20%"><strong><font color="004861"><?php print($category_list[$k]["string"]); ?></font></strong></td>
    <td width="80%"><table border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td ><img src="poll/images/bluel.gif"></td>
          <td ><img src="poll/images/bluem.gif" width="<?php 
		  $length=$category_list[$k]["value"]/$total_votes*100;
		  printf("%d",$length*10);
		  
		  ?>" height="9"></td>
          <td ><img src="poll/images/bluer.gif"></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td class="small"><?php print(" (".$category_list[$k]["value"]." votes )"); ?></td>
    <td class="small">( Vote Percentage = <?php printf("%d",$length); ?>% )</td>
  </tr>
</table>
