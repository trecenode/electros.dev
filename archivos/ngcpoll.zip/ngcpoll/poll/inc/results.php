<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td>&nbsp; </td>
  </tr>
  <tr> 
    <td class="header">Question : <?php print($category_list[$i]["string"]); ?></td>
  </tr>
  <tr> 
    <td>And here are the results : Total votes ( <strong> <font color="#FF0000"> 
      <?php         $total_votes = 0;
        for($k=0;$k<$total_entries;$k++)
	     {
    	if($poll_show==$category_list[$k]["poll"] && $category_list[$k]["type"]=="option" )
		{
		$total_votes=$total_votes+$category_list[$k]["value"];
		}}
print($total_votes);
?>
      </font></strong> ) </td>
  </tr>
  <tr> 
    <td>&nbsp; </td>
  </tr>
  <tr> 
    <td> 
      <?php
	       
        for($k=0;$k<$total_entries;$k++)
	     {
    	if($poll_show==$category_list[$k]["poll"] && $category_list[$k]["type"]=="option" )
		{
		include("results_bar.php");
		}
	    }
		
		
	?>
    </td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      &nbsp;&nbsp;<?php if($already_voted=="yes"){print(" You have already voted ...");}
	else {print(" Thank you for you vote");} ?>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
