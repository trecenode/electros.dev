<form name="form" method="post" action="<?php print($PHP_SELF) ?>">
  <div align="center">
    <input name="page" type="hidden" id="page" value="subscribe">
    <input name="view_type" type="hidden" id="view_type" value="setup">
    <table border="0" cellspacing="5" cellpadding="0">
      <tr> 
        <td>Administrator Email : </td>
        <td> <input name="email" type="text" class="box" id="email" value="<?php if(isset($email)){print($email);}?>"></td>
      </tr>
      <tr> 
        <td>Administrator Password :</td>
        <td><input name="password" type="password" id="password" class="box"></td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td> <div align="center"> 
            <input type="submit" name="Submit" value="Submit" class="box">
          </div></td>
      </tr>
    </table>
  </div>
</form>
