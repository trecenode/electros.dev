<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<LINK href="ngc.css" rel=STYLESHEET type=text/css>
<title>Simple Mail Admin Panel</title>
</head><body>
<?php 
/*it opens from the main dir only */
$admin_email="me@mysite.com";
$admin_pass="password";
require("globals.php");

require("inc/csvfile.php");
if(!isset($password))$password=""; 
if(!isset($email))$email=""; 

if($password!=$admin_pass or  $email!=$admin_email) 
{
echo "<form name=\"form\" method=\"post\" action=\"$PHP_SELF\"><table border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"1\" bgcolor=\"#0000FF\">
<tr><td bgcolor=\"f7f7f7\"><table border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>&nbsp;</td></tr><tr><td><strong>NGC Poll Manager Login</strong></td>
</tr><tr><td>&nbsp;</td></tr></table><table border=\"0\" cellpadding=\"0\" cellspacing=\"5\" bgcolor=\"f7f7f7\">
 <tr> <td>Administrator Email : </td><td> <input name=\"email\" type=\"text\" class=\"box\" id=\"email\" value=\"\"></td>
     </tr><tr> <td>Administrator Password :</td><td><input name=\"password\" type=\"password\" id=\"password\" class=\"box\"></td>
          </tr><tr> <td>&nbsp;</td><td> <div align=\"center\"><input type=\"submit\" name=\"Submit2\" value=\"Submit\" class=\"box\">
              </div></td></tr></table></td></tr></table></form>";
return;
}
?>
NGC POLL Manager By ngcoders ( <a href="http://www.ngcoders.com">www.ngcoders.com</a> 
) 
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="1" bgcolor="004861">
  <tr>
    <td><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="1" bgcolor="f7f7f7">
        <tr>
          <td height="95" valign="top"><strong> &nbsp;NGC POLL Administration Panel 
            : <br>
            <br>
            </strong>
            <table width="100%" border="0" cellpadding="0" cellspacing="1" bgcolor="009861">
              <tr> 
                <td bgcolor="004861"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="efefef">
                    <tr> 
                      <td> 
                        <table width="100%" border="0" cellspacing="1" cellpadding="0">
                          <tr>
                            <td><table border="0" cellspacing="4" cellpadding="5">
                                <tr> 
                                  <td><form name="form1" method="post" action="<?php print($PHP_SELF) ?>">
                                      <input type="hidden" name="action" value="new">
                                      <input type="hidden" name="email" value="<?php print($email) ?>">
                                      <input type="hidden" name="password" value="<?php print($password) ?>">
                                      <input type="submit" name="Submit" value="New Poll" class="box">
                                    </form></td>
                                  <td><form name="form2" method="post" action="<?php print($PHP_SELF) ?>">
                                      <input type="hidden" name="action" value="edit">
                                      <input type="hidden" name="email" value="<?php print($email) ?>">
                                      <input type="hidden" name="password" value="<?php print($password) ?>">
                                      <input type="submit" name="Submit2" value="Edit Poll" class="box">
                                    </form></td>
                                  <td><form name="form3" method="post" action="<?php print($PHP_SELF) ?>">
                                      <input type="hidden" name="action" value="setting">
                                      <input type="hidden" name="email" value="<?php print($email) ?>">
                                      <input type="hidden" name="password" value="<?php print($password) ?>">
                                      <input type="submit" name="Submit3" value="Edit Settings" class="box">
                                    </form></td>
                                </tr>
                              </table></td>
                            <td>
<table width="100%" border="0" align="right" cellpadding="4" cellspacing="5">
                                <tr>
                                  <td><form name="form3" method="post" action="<?php print($PHP_SELF) ?>">
                                      <input type="hidden" name="action" value="help">
                                      <input type="hidden" name="email" value="<?php print($email) ?>">
                                      <input type="hidden" name="password" value="<?php print($password) ?>">
                                      <input type="submit" name="Submit32" value="Help" class="box">
                                    </form></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
            <strong> </strong> <strong><br>
            </strong> 
            <?php
			$base_file = new csvfile;
			$base_file->name=$main_data_file;
			$base_file->init();

			/* find total number of categories */
			$total_entries=$base_file->entries();
			$category_list= array( );
			$base_file->get_entrylist(0,$total_entries-1,$category_list);

				if( !isset($action)) { include ("admin/login.php"); $action="login"; }
				if($action == "create"){
				print("<br>The Poll is being created ...<hr>");
				$new_poll = array();
				$new_poll["type"]="poll";
				$new_poll["poll"]=$poll_name;
				$new_poll["string"]=$poll_question;
				$new_poll["value"]=$poll_options;
				$new_poll["date"]= $date;
				$new_poll["ip"]== "";
				$base_file->append($new_poll);
				
				$new_poll["type"]="option";
				$new_poll["poll"]=$poll_name;
				$new_poll["string"]="Not Set";
				$new_poll["value"]="0";
				$new_poll["date"]= "";
				$new_poll["ip"]= "";
				for($i=0;$i<$poll_options;$i++)
				{
				$base_file->append($new_poll);
				}
				print("<br>Poll Name : ".$poll_name);
				print("<br>Poll Question : ".$poll_question);
				print("<br>Number of options : ".$poll_options);
				print("<br>Created on  : ".date("D j F Y",$date));
				print("<br><br><hr><br>Poll Created . Please select Edit Poll to edit the options ...");
				}

				if($action == "new"){
				include("admin/new.php");
				}

/*update and data base after an poll edit */
if($action == "update_data"){
				print("<br>The Poll is being updated ...<hr>");

/*first delete the orignal */
                for($i=0;$i<$total_entries;$i++)
				{
				$holder= $category_list[$i]["poll"]; /* dynamic variables */
				if($holder==$poll)
				 	{
					$del_poll=array();
					$del_poll["poll"]=$category_list[$i]["poll"];
					$entry_num=$base_file->find_entry($del_poll);
					$base_file->delete($entry_num);
					}
				}       
printf("<br>Name of Poll :".$poll);

/*create a new and fill entries */

				$new_poll = array();
				$new_poll["type"]="poll";
				$new_poll["poll"]=$poll_name;
				$new_poll["string"]=$poll_question;
				$new_poll["value"]=$poll_options;
				$new_poll["date"]= $date;
				$new_poll["ip"]== "";
				$base_file->append($new_poll);
				
				$new_poll["type"]="option";
				$new_poll["poll"]=$poll_name;
				$new_poll["string"]="Not Set";
				$new_poll["value"]="0";
				$new_poll["date"]= "";
				$new_poll["ip"]= "";
				
				for($i=0;$i<$poll_options;$i++)
				{
				$son="option".$i;
				if(!isset($$son))$$son="Not Set";
				$new_poll["string"]=$$son;
				$son="value".$i;
				if(!isset($$son))$$son="0";
				$new_poll["value"]=$$son;
				$base_file->append($new_poll);
				}

print("<br><br><hr><br>Poll Updated . Please select an option to continue ...");

/*$poll_select=md5($poll_name);
$action="edit_data";
$submit="Edit poll";*/
}



				if($action == "edit_data"){
/*             	include("admin/poll_edit.php");*/
/* edit a poll */
	 if ( $submit=="Edit poll")
	 {
            for($i=0;$i<$total_entries;$i++)
				{
				$holder= md5($category_list[$i]["poll"]); /* dynamic variables */
				if($holder==$poll_select)
				 	{
					break;
					}
				}       

	 include("admin/poll_edit.php");
	 }
       
/* delete a poll */
			 if ( $submit=="Delete")
                    {
				print("<BR>The following poll was deleted ...<br><hr>");
                for($i=0;$i<$total_entries;$i++)
				{
				$holder= md5($category_list[$i]["poll"]); /* dynamic variables */
				if($holder==$poll_select)
				 	{
					$del_poll=array();
					$del_poll["poll"]=$category_list[$i]["poll"];
        			if($category_list[$i]["type"]=="poll")printf("<BR>%s",$del_poll["poll"]);
					$entry_num=$base_file->find_entry($del_poll);
					$base_file->delete($entry_num);
					}
				}       
				 print("<br><br><hr><br> Please select an action from above to continue ...");
				}
				
				}

				if($action == "edit"){
				include("admin/edit.php");
				}
				if($action == "update"){
		        $fp=fopen("globals.php","w");
                
				$out=sprintf("<?php \r\n\$date = time();\r\n");
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$main_dir=\"%s\";\r\n",$new_main_dir);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$data_dir=\"data/\";\r\n");
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$data_file=\"%s\";\r\n",$new_data_file);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$relative_string=\"%s\";\r\n",$new_relative_string);
				fwrite($fp,$out,strlen($out));
				
   				$out=sprintf("\$main_data_file=\$data_dir.\$data_file;\r\n");
				fwrite($fp,$out,strlen($out));
/*
				$out=sprintf("\$conf_email=\"%s\";\r\n",$new_conf_email);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$thank_email=\"%s\";\r\n",$new_thank_email);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$thank_text=\"%s\";\r\n",$new_thank_text);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("\$email_title=\"%s\";\r\n",$new_email_title);
				fwrite($fp,$out,strlen($out));
                $out=sprintf("?>\r\n"); 
				fwrite($fp,$out,strlen($out)); */
				fclose($fp); 
				require("globals.php"); 
            $action="setting"; }
			if($action == "setting"){ include("admin/setting.php"); 
            } 
		if($action == "help"){ include("readme.htm"); } 
			?> </td>
        </tr>
      </table></td>
  </tr>
</table></body></html>