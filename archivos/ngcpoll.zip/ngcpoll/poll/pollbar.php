<table width="100%" border="0" cellspacing="10" cellpadding="1">
  <tr> 
    <td bgcolor="003e9c"><table width="100%" border="0" cellpadding="1" cellspacing="1" bgcolor="dbe2ea">
        <tr> 
          <td bgcolor="b6c2d0" class="header"> <table width="150" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="30"><div align="center">&nbsp;<span class="header"><img src="images/topic_poll.gif" width="20" height="18"></span></div></td>
                <td width="122"><span class="header">&nbsp;&nbsp;Opnion Poll</span></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td bgcolor="f7f7f7" class="orange"><form action="index.php" method="submit" enctype="multipart/form-data" name="form1">
              <table width="100%" border="0" cellspacing="0" cellpadding="3">
                <tr> 
                  <td colspan="2"> <strong> 
                    <input name="poll_show" type="hidden" value="<?php print($poll_show); ?>">
                    <?php 
				  /* Question */
				  print($category_list[$i]["string"]);
				  ?>
                    &nbsp;</strong></td>
                </tr>
                <tr> 
                  <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <?php 
                       for($k=0;$k<$total_entries;$k++)
					   { 
					   if($poll_show==$category_list[$k]["poll"] && $category_list[$k]["type"]=="option" )
						{
                        print("<tr><td><input type=\"radio\" name=\"option_select\" value=\"".$k."\"></td>"); 
                        print("<td>&nbsp;".$category_list[$k]["string"]."</td></tr>");
//						include("pollbar.php");
						}
                       }
					  ?>
                    </table></td>
                </tr>
                <tr> 
                  <td>
<div align="right" class="small">
                      <input name="page" type="hidden" id="page" value="poll">
                      <input name="view_type" type="hidden" id="view_type" value="results">
                      Please submit to <br>
                      view the results <br>
                    </div></td>
                  <td> 
                    <input type="submit" name="Submit" value="Submit" class="box">
                  </td>
                </tr>
              </table>
            </form></td>
        </tr>
      </table></td>
  </tr>
</table>
