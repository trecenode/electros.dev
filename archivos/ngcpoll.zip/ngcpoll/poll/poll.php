<?php 
/* main directory */

$main_dir="";
require($main_dir."globals.php");

if(!isset($csv_include))require($main_dir."inc/csvfile.php");

if(!isset($view_type)){ $view_type="main";}  

/*open main data base and read the various categories*/
$base_file = new csvfile;
$base_file->name=$main_dir.$main_data_file;
$base_file->init();

/* find total number of categories */
$total_entries=$base_file->entries();
$category_list= array( );
$base_file->get_entrylist(0,$total_entries-1,$category_list);

if($view_type=="results")
{
if(!isset($poll_show))$poll_show=$catergory_list[0]["poll"];


for($i=0;$i<$total_entries;$i++)
	{
	if($poll_show==$category_list[$i]["poll"] && $category_list[$i]["type"]=="poll" )
		{
   
		if($REMOTE_ADDR==$category_list[$i]["ip"])
			{
			$already_voted="yes";
/*			print($poll_update_table["value"]."yes");*/
			} else { 	
			$poll_update_table= array();
			$base_file->get_entry($i,$poll_update_table);
			$poll_update_table["ip"]=$REMOTE_ADDR;
			$base_file->change($i,$poll_update_table);
			
			$base_file->get_entry($option_select,$poll_update_table);
			$poll_update_table["value"]=$poll_update_table["value"]+1;
/*			print($poll_update_table["value"]."value")*/
			$base_file->change($option_select,$poll_update_table);
			$already_voted="no";
			}
        $base_file->get_entrylist(0,$total_entries-1,$category_list);
		
		include($main_dir."inc/results.php");
		break;
		}
	}

}

if($view_type=="vote")
{
/*if the poll type is not selecte will pick the first poll*/
if(!isset($poll_show))$poll_show=$catergory_list[0]["poll"];

for($i=0;$i<$total_entries;$i++)
	{
	if($poll_show==$category_list[$i]["poll"] && $category_list[$i]["type"]=="poll" )
		{
		include("pollbar.php");
		break;
		}
	}
}

/*	print($num);
	print($base_file->entries());
*/

?>