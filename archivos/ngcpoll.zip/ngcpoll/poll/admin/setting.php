Please fill in appropiate values as you want for how you want the script to behave 
<br>
 <br> 
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="004861">
  <tr> 
    <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="dee3e7">
        <tr> 
          <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="efefef">
                       <tr> 
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td><form name="form1" method="post" action="">
                    <input type="hidden" name="email" value="<?php print($email) ?>">
                    <input type="hidden" name="password" value="<?php print($password) ?>">
                    <input name="action" type="hidden" id="action" value="update">
                    <table width="80%" border="0" align="center" cellpadding="4" cellspacing="4">
                      <tr> 
                        <td>Main directory ( polll/ )</td>
                        <td><p> 
                            <label></label>
                            <input name="new_main_dir" type="text" class="box" id="new_main_dir" value="<?php print($main_dir); ?>" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td>Main data base file</td>
                        <td><p> 
                            <label></label>
                            <label></label>
                            <input name="new_data_file" type="text" class="box" id="new_data_file" value="<?php print($data_file); ?>" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td> Relative string ( Incase of embedding )</td>
                        <td><p> 
                            <label> </label>
                            <input name="new_relative_string" type="text" class="box" id="new_relative_string" value="<?php print($relative_string); ?>" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                        <td><input type="reset" name="Reset" value="Reset" class="box"> 
                          &nbsp;&nbsp;&nbsp; <input type="submit" name="Submit2" value="Submit" class="box"></td>
                      </tr>
                    </table>
                  </form></td>
              </tr>
            </table> </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p>
