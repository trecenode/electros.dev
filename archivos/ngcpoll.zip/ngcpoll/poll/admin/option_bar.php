
  <tr> 
    <td width="34%">Option <?php printf($z); ?> : </td>
    <td width="34%"><input name="option<?php printf($z); ?>" type="text" class="box" value="<?php print($category_list[$k]["string"]); ?>"></td>
    <td width="29%"><input name="value<?php printf($z); ?>" type="text" class="box" value="<?php print($category_list[$k]["value"]); ?>" size="10" ></td>
  </tr>


