Here you can create a New Poll Please select a name for the poll to be refered 
to , A Question and the number of options .<br>
<br>
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="004861">
  <tr> 
    <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="dee3e7">
        <tr> 
          <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="efefef">
              <tr> 
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td><form name="form1" method="post" action="<?php print($PHP_SELF) ?>">
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="email" value="<?php print($email) ?>">
                    <input type="hidden" name="password" value="<?php print($password) ?>">
                    <table width="80%" border="0" align="center" cellpadding="4" cellspacing="4">
                      <tr> 
                        <td>Poll Name : </td>
                        <td><p> 
                            <label></label>
                            <input name="poll_name" type="text" class="box" id="poll_name" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td>Question : </td>
                        <td><p> 
                            <label></label>
                            <label></label>
                            <input name="poll_question" type="text" class="box" id="poll_question" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td> Number of Options :</td>
                        <td><p> 
                            <label></label>
                            <input name="poll_options" type="text" class="box" id="poll_options" value="5" size="40">
                            <br>
                          </p></td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                        <td><input type="reset" name="Reset" value="Reset" class="box"> 
                          &nbsp;&nbsp;&nbsp; <input type="submit" name="Submit2" value="Submit" class="box"></td>
                      </tr>
                    </table>
                  </form></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
