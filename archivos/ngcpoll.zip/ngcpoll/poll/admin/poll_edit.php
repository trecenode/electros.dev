<p>Please select the appropiate options for your poll . </p>
<form name="form1" method="post" action="<?php print($PHP_SELF) ?>">
  <input type="hidden" name="action" value="update_data">
  <input type="hidden" name="email" value="<?php print($email) ?>">
  <input type="hidden" name="password" value="<?php print($password) ?>">
  <input name="poll" type="hidden" value="<?php print($category_list[$i]["poll"]); ?>">

  <table width="90%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="004861">
    <tr> 
      <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="dee3e7">
          <tr> 
            <td> 
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="8" bgcolor="#efefef">
                <tr> 
                  <td><div align="center"> 
                      <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
                        <tr bgcolor="#CCCCCC"> 
                          <td width="8%"> <div align="left"><font color="004861"><strong>Main 
                              Settings :</strong></font></div></td>
                        </tr>
                        
                      </table>
                      <table width="100%" border="0" cellspacing="5" cellpadding="0">
                        <tr> 
                          <td width="35%">Poll Name : </td>
                          <td width="65%"><input name="poll_name" type="text" class="box" id="poll_name" value="<?php print($category_list[$i]["poll"]); ?>" size="40"> 
                          </td>
                        </tr>
                        <tr> 
                          <td>Poll Question :</td>
                          <td><input name="poll_question" type="text" class="box" id="poll_question" value="<?php print($category_list[$i]["string"]); ?>" size="60" ></td>
                        </tr>
                        <tr> 
                          <td>Poll Options : </td>
                          <td><input name="poll_options" type="text" class="box" id="poll_options" value="<?php print($category_list[$i]["value"]); ?>" size="40" ></td>
                        </tr>
                      </table>
                    </div></td>
                </tr>
                <tr> 
                  <td><table width="100%" border="0" align="center" cellpadding="4" cellspacing="1">
                      <tr bgcolor="#CCCCCC"> 
                        <td width="8%"> <div align="center"></div></td>
                        <td width="18%"><font color="004861"><strong>Option String</strong></font></td>
                        <td width="52%"> <div align="left"><font color="004861"><strong>Votes 
                            </strong></font></div></td>
                      </tr>
                      <?php
$z=0;
for($k=0;$k<$total_entries;$k++)
{
if($category_list[$k]["type"]=="option" && $category_list[$k]["poll"]==$category_list[$i]["poll"])
{
if($z%2==0){$color="#f7f7f7";}
   else { $color="#dee3e7";}
include("option_bar.php");
$z++;
}
}
?>
                    </table>
                    <div align="center"></div></td>
                </tr>
                <tr>
                  <td><hr> <div align="center"> 
                      <input type="reset" name="Reset" value="Reset" class="box">
                      &nbsp;&nbsp;&nbsp; 
                      <input type="submit" name="Submit2" value="Submit" class="box">
                    </div></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>
