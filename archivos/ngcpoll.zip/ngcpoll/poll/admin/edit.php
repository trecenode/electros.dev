<p>Just Select the poll you wish to edit or delete </p>
<form name="form1" method="submit" action="<?php print($PHP_SELF) ?>">
  <input type="hidden" name="action" value="edit_data">
  <input type="hidden" name="email" value="<?php print($email) ?>">
  <input type="hidden" name="password" value="<?php print($password) ?>">
    <table width="90%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="004861">
  <tr>
    <td><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="dee3e7">
        <tr>
          <td>
              
              <table width="100%" border="0" align="center" cellpadding="4" cellspacing="1">
                <tr bgcolor="#CCCCCC"> 
                  <td width="8%"> 
                    <div align="center"><font color="004861"><strong>Index</strong></font></div></td>
                  <td width="18%"><font color="004861"><strong>Poll Name</strong></font></td>
                  <td width="52%"> <div align="left"><font color="004861"><strong>Question</strong></font></div></td>
                  <td width="9%"> 
                    <div align="center"><font color="004861"><strong>Votes</strong></font></div></td>
                  <td width="13%"> 
                    <div align="center"><font color="004861"><strong>Select</strong></font></div></td>
                </tr>
                <?php
$z=0;
for($i=0;$i<$total_entries;$i++)
{
if($category_list[$i]["type"]=="poll")
{
if($z%2==0){$color="#f7f7f7";}
   else { $color="#dee3e7";}
include("bar.php");
$z++;
}
}
?>
              </table>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="8" bgcolor="#efefef">
                <tr> 
                  <td><div align="center"> 
                      <hr>
                      <input type="reset" name="Reset" value="Reset" class="box">
                      &nbsp;&nbsp;&nbsp; 
                      <input type="submit" name="submit" value="Edit poll" class="box">
                      &nbsp;&nbsp;&nbsp; 
                      <input type="submit" name="submit" value="Delete" class="box">
                    </div></td>
                </tr>
              </table>
            </td>
        </tr>
      </table></td>
  </tr>
</table></form>
