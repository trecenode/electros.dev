  <tr bgcolor="<?php print($color); ?>">
    <td><div align="center"><?php print($z); ?></center></td>
    <td><?php print($category_list[$i]["poll"]); ?></td>
    <td><?php print($category_list[$i]["string"]); ?></td>
    <td><div align="center"><?php  
	$total_votes=0;
	for( $j=0;$j<$total_entries;$j++)
	{
	if($category_list[$i]["poll"]==$category_list[$j]["poll"])
	{
	if($category_list[$j]["type"]=="option")
		{
		$total_votes=$total_votes+$category_list[$j]["value"];
		}
	}
	}
	print($total_votes); 
	
	
	
	?></center></td>
    <td><div align="center">
      <input name="poll_select" type="radio" value="<?php print(md5($category_list[$i]["poll"]));?>" <?php if($i==0)print("checked");?> >
      </div></td>
  </tr>