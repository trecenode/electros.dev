Welcome to NGC Poll Manager . Please choose one of the options abouve to continue 
any further . To exit simply close the current window . 