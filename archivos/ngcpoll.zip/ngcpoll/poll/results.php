<link href="ngc.css" rel="stylesheet" type="text/css"> <table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr> 
    <td bgcolor="003e9c"><table width="100%" border="0" cellpadding="1" cellspacing="1" bgcolor="dbe2ea">
        <tr> 
          <td bgcolor="b6c2d0" class="header"> <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="33%"><div align="center"> 
                    <table border="0" align="left" cellpadding="0" cellspacing="0">
                      <tr> 
                        <td width="30"> 
                          <div align="center">&nbsp;<span class="header"><img src="images/topic_poll.gif" width="20" height="18"></span></div></td>
                        <td><span class="header">Poll results Page </span></td>
                      </tr>
                    </table>
                  </div></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td bgcolor="f7f7f7" valign="top"> <div align="center"> 
              <?php 
//		  $view_type="main";
//		  $main_category="fad58de7366495db4650cfefac2fcd61";
		  include("poll/poll.php") 
		  ?>
            </div></td>
        </tr>
      </table></td>
  </tr>
</table>
NGC Poll Manager ( <a href="http://www.ngcoders.com" class="gsmall">www.ngcoders.com</a> )