<?php 
$date = time();
$main_dir="poll/";
$data_dir="data/";
$data_file="main.txt";
$relative_string="index.php?page=poll&";
$main_data_file=$data_dir.$data_file;
