<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="ngc.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="e3e3e3">
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="1" bgcolor="00399c">
  <tr>
    <td>
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="f7f7f7">
        <tr> 
          <td height="80"> 
            <div align="center"><img src="images/ngcbar.jpg" width="600" height="80"></div></td>
        </tr>
        <tr> 
          <td height="192"> <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="100" bgcolor="dee3e7">
<div align="center">
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&lt;-- Your menu --&gt;<br>
                    </p>
                    <p><img src="images/spacer.gif" width="170" height="1"></p>
                    <p><img src="images/spacer.gif" width="170" height="1"> </p>
                  </div></td>
                <td width="100%" valign="top"> <div align="center">
                   <?php
				    if(isset ($page))
					{
					if ($page == "poll")
					{
					include("poll/results.php");
					}
					}else {
					/* include( your title page"); */
					print(":Your Main Page Goes Here :");
					} 
	
					?>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                  </div></td>
                <td width="29%" bgcolor="dee3e7"> <div align="center"> 
                    <?php 
		
		 $poll_show="games";
$view_type="vote";
include("poll/poll.php");

 ?>
                    <a href="poll/admin.php" class="pblink"><br>
                    <br>
                    Admin Panel </a><br>
                    <br>
                    <img src="images/spacer.gif" width="170" height="1"> </div></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td height="57"> <p align="center">NGC Poll System<br>
              For updates and other such scripts come to <br>
              <a href="http://www.ngcoders.com">www.ngcoders.com </a></p></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
