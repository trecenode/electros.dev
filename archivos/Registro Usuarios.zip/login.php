<?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////
?>
<form method="post" action="entrar.php">
    <div >
      <div align="center">
        <p><img src="Iconos/user1_find.png" width="48" height="48">          </p>
        <p><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Usuario:</font>
          <input type="text" name="user" size="25" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
          </p>
        <p><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Contrase�a:</font>
          <input type="password" name="pass" size="25" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
          </p>
        <p>
          <input type="submit" name="entrar" value="Entrar" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
        </p>
      </div>
    </div>
</form>
<div>
  <div align="center"><br>
      <b>
        <a href="index.php?id=registrar.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Registrarse</font></a>
    </b>
  </div>
</div>
