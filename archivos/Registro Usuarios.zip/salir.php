<?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////

// Para eliminar las cookies en caso de que el usuario quiera salir.
setcookie("user",$_COOKIE["user"],time()-3600);
setcookie("pass",$_COOKIE["pass"],time()-3600);
header("location: index.php");
?>
<center><br><br><font face=verdana size=1 color=#000000><b>Has sido Desconectado</b></center>
<SCRIPT LANGUAGE="javascript">
location.href = "index.php?id=";
</SCRIPT>