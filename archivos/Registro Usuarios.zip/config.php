<?
$dbh=mysql_connect ("localhost", "USER", "PASSWORD") or die ('No se pudo conectar ala base de datos por:: ' . mysql_error());
mysql_select_db ("DB");
?>