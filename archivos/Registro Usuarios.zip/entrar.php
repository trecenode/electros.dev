<?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////

// Si el login es correcto crea las cookies, si no te manda a la cresta.
include("config.php");

$user = $_POST['user'];
$pass = md5($_POST['pass']);

$resp = mysql_query("select * from usuarios where user='".$user."'");
$row = mysql_fetch_array($resp);
if($row['pass'] == $pass){
    
    setcookie("user",$user,time()+90000);
    setcookie("pass",$pass,time()+90000);
    
    echo "<font face=Verdana size=1 color=#696969>Iniciando Sesi�n...";
?>
    <SCRIPT LANGUAGE="javascript">location.href = "index.php?id=panel";</SCRIPT>
<?
} else {
    echo "<font face=Verdana size=1 color=#696969>Contrase�a o Usuario Incorreto";
}
?>