<?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////

// Formulario de registro con pocos datos
?>
<form method="post" action="registro.php">
  <div align="center">Porfavor rellena este formulario para poderte registrar<br>
    Gracias.<br>
    <table>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Usuario:</font></td>
          <td><input type="text" name="user" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Contrase�a:</font></td>
          <td><input type="password" name="pass" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Sexo:</font></td>
          <td><input type="radio" name="sexo" value="h"><font face="Verdana" size="1" color="#333333">Hombre &nbsp;&nbsp; <input type="radio" name="sexo" value="m"> Mujer</td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Nombre:</font></td>
          <td><input type="text" name="nombre" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Email:</font></td>
          <td><input type="text" name="email" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Edad:</font></td>
          <td><input type="text" name="edad" size="10" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Pais:</font></td>
          <td><input type="text" name="pais" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
  </table>
  <br>
  <input type="submit" name="registrar" value="Registrar" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
  </div>
</form>
