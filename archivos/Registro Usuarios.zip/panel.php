<?
if(isset($_COOKIE['user']) && isset($_COOKIE['pass'])){
?>
<center>
<font face="Verdana, Arial, Helvetica, sans-serif" color="#333333" size="1"><b>PANEL PARA USUARIOS</b></font><BR><BR>
<table cellpadding="10">
    <tr>
        <td><center><a href="index.php"><img src="Iconos/index.png" width="48" height="48" border="0"></a><br>
        <font face="Verdana" color="#333333" size="1"><a href="index.php?id=inicio">Inicio web</a></font></center></td>
        <td>&nbsp;</td>
        <td><center>
        <img src="Iconos/user1_information.png" width="48" height="48" border="0"><br>
        <font face="Verdana" color="#333333" size="1"><a href="index.php?id=perfil">Modificar Perfil</a></font></center></td>
        <td>&nbsp;</td>
        <td><center><img src="Iconos/news.png" width="48" height="48" border="0"><br>
        <font face="Verdana" color="#333333" size="1"><a href="index.php?id=newsend">Enviar Noticia</a></font></center></td>
    </tr>
    <tr>
        <td><center><img src="Iconos/mail_server.png" width="48" height="48" border="0"><br>
        <font face="Verdana" color="#333333" size="1"><a href="index.php?id=contacto">Contactar</a></font>
        </center></td>
        <td>&nbsp;</td>
        <td><center>
        <a href="perfil.php"><img src="Iconos/view.png" width="48" height="48" border="0"></a><br>
        <font face="Verdana" color="#333333" size="1"><a href="index.php?id=usuarios">Ver Usuarios</a></font></center></td>
        <td>&nbsp;</td>
        <td><center><a href="salir.php"><img src="Iconos/link.png" width="48" height="48" border="0"></a><br><font face="Verdana" color="#333333" size="1"><a href="index.php?id=salir">Cerrar Sesi�n</a></font></center></td>
    </tr>
</table>
</center>
<br>
<? } ?>