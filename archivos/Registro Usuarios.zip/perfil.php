<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">
<div align="center">
  <?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////

// Para que edites el perfil Viendo si tienes las cookies obviamente.

if(isset($_COOKIE['user']) && isset($_COOKIE['pass'])){


include("config.php");
$email = $_POST['email'];
$edad = $_POST['edad'];
$pais = $_POST['pais'];
$pass = md5($_POST['pass']);
$cambiarperfil = $_POST['cambiarperfil'];

if(isset($email) && isset($pais) && isset($cambiarperfil)){

    if(empty($pass)){
    
        if(mysql_query("update usuarios set email='$email', edad='$edad', pais='$pais' where user='".$_COOKIE['user']."'")){
        echo "Perfil Modificado con exito!"; } else { echo "Su perfil no se ha podido Modificar."; }
    
    } else {
    
        if(mysql_query("update usuarios set email='$email', edad='$edad', pais='$pais', pass='$pass' where user='".$_COOKIE['user']."'")){
        echo "Perfil Modificado con exito!"; } else { echo "Su perfil no se ha podido Modificar."; }
    }

} else {

    $resp = mysql_query("select * from usuarios where user='".$_COOKIE['user']."'");
    $row = mysql_fetch_array($resp);
?>
</div>
<form method="post" action="perfil.php">
  <div align="center">
  <p><img src="file:///Mac Mini/Users/alejandromedinamartinez/Desktop/Registro De Usuarios/Iconos/edit.png" width="48" height="48"></p>
  <table>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Contrase�a:</font></td>
          <td><input type="password" name="pass" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Email:</font></td>
          <td><input type="text" name="email" size="30" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif" value="<?=$row['email']?>"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Edad:</font></td>
          <td><input type="text" name="edad" size="10" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif" value="<?=$row['edad']?>"></td>
      </tr>
    <tr>
      <td width="80"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">Pais:</font></td>
          <td><input type="text" name="pais" size="10" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif" value="<?=$row['pais']?>"></td>
      </tr>
  </table>
  <br>
  <input type="submit" name="cambiarperfil" value="Cambiar Perfil" style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
  </div>
</form>

<div align="center">
  <? } 




} else {
?>
  <SCRIPT LANGUAGE="javascript">location.href = "login.php";</SCRIPT>
  <? } ?>  
</div>
