<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#333333">
<?
//////////////////////////////////////////////////////
//
//  Script de usuarios por: LinKini
//  http://www.linkini.net
//
//  No seas lamer. No quites mis titulos ��
//  Sistema de usuarios para Forowebmaster
//
//////////////////////////////////////////////////////

// Procesando los datos de registrar.php
include("config.php");

$sexo = $_POST['sexo'];
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$edad = $_POST['edad'];
$pais = $_POST['pais'];
$user = $_POST['user'];
$pass = md5($_POST['pass']);
$registrar = $_POST['registrar'];


if(isset($sexo) && isset($nombre) && isset($email) && isset($edad) && isset($pais) && isset($user) && isset($pass) && isset($registrar)){
    
    $resp = mysql_query("select * from usuarios");
    while($row = mysql_fetch_array($resp)){ 
        $user2 = $row['user']; 
    }
        
        if($user == $user2){ echo "El Usuario que ha escogido ya existe, por favor vuelva atr�s y seleccione otro Usuario"; } else {
                if(mysql_query("insert into usuarios (sexo,nombre,email,edad,pais,user,pass) values ('$sexo','$nombre','$email','$edad','$pais','$user','$pass')")){
                    echo "Registro Exitoso!";
                } else {
                    echo "El Registro no se ha finalizado. Por favor asegurese de haber llenado todos los campos.";
                }    
        }
        
        
    
} else {
    echo "El Registro no se ha finalizado. Por favor asegurese de haber llenado todos los campos";
}
?>  