<title>Codigohtm - htm,java,javascript,php</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>

<div class="t1">Codigohtm<br>
  <br>
</div>
<table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
  <tr> 
    <td align="center" class="tabla_mensaje"><div align="left">Tutoriales 
        <b><?
// Nombre del archivo
if($secciones !="./") {
echo "$secciones";
} 
else 
{ 
echo "principales";
} 
?></b>
      </div></td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="14%" valign="top"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
        <td width="14%" valign="top">
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
        <tr> 
          <td height="29" align="center" class="tabla_subtitulo"><div align="left">:: 
              Secciones :: </div></td>
        </tr>
<?
// mostrar las carpetas del directorio
if(!$web){
$web='.';
}
else
{
$dir=$web."/";
}
$handle=opendir($web); 
while ($file = readdir($handle)) {
if($file!==basename($PHP_SELF)&&$file!==".."&&$file!=="..")
{
if(!$file) {
echo "";
}
if(!is_dir($file)){
echo "";
} else {

?>
<tr>
<td height='2' class='tabla_mensaje'><div align='left'><a  href='index.php?secciones=<? echo "$file/" ?>'>. <? echo $file;  ?></a></div></td>
</tr>
<?php

}
}
}
closedir($handle);
echo '';
?>
      </table>

<br>
      <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
        <tr> 
          <td height="29" align="center" class="tabla_subtitulo"><div align="left">:: 
              Minichat :: </div></td>
        </tr>
        <tr> 
          <td align="center" class="tabla_mensaje"><div align="left">Cuadro</div>
            </td>
        </tr>
        <tr> 
          <td height="2" align="center" class="tabla_mensaje"><div align="left">Responder 
            </div></td>
        </tr>
      </table> 
      <br>
      <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
        <tr> 
          <td height="29" align="center" class="tabla_subtitulo"><div align="left">:: 
              Enlaces :: </div></td>
        </tr>
        <tr> 
          <td align="center" class="tabla_mensaje"><div align="left">Buscador</div></td>
        </tr>
        <tr> 
          <td height="2" align="center" class="tabla_mensaje"><div align="left">Enlaces 
            </div></td>
        </tr>
      </table> </td>
    <td width="1%">&nbsp;</td>
        <td width="85%" valign="top">
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td height="7" class="tabla_subtitulo"><b>Archivo</b></td>
    <td height="7" class="tabla_subtitulo"><strong>Descripcion</strong></td>
    <td width="12%" height="7" class="tabla_subtitulo"><div align="left"><strong>Autor</strong></div></td>
    <td width="8%" class="tabla_subtitulo"><b>Tama�o</b></td>
    <td width="8%" class="tabla_subtitulo"><b>Lecturas</b></td>
    <td colspan="4" class="tabla_subtitulo">&nbsp;</td>
  </tr>
<?php
// Contamos los clicks echo en los archivos
// se pone index.php?a=fichero y dependiendo de la existencia fisica del fichero
// en dicho directorio abriremos un header u otro.
if ($a) {
$fichero = $a ;
$fp=fopen("$fichero.dat","r");
$numero=fread($fp,filesize("$fichero.dat"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.dat", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

?>
<script>location='index.php?tutorial=<? echo $a ?>&secciones=<? echo $secciones ?>'</script>
<?

}
// Contamos los clicks echo en las descargas adjuntas ,
// se guardar como 'archivo.zip.dat'
if ($b) {
$fichero = $b ; 
$fp=fopen("$fichero.zip.dat","r");
$numero=fread($fp,filesize("$fichero.zip.dat"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.zip.dat", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

?>
<script>location='<? echo $b ?>.zip'</script>
<?
}
// Script 'Codigohtm' realizado  por elcidop en colaboracion con $$felipe$$
/// Web del autor: wwww.phpmysql.tk www.elcidop.com wwww.elcidop.webcindario.com

// Script para 'ver el directorio' realizado por $$felipe$$ //
// web del autor de este codigo : portalmusik.elcidop.com //
// inicio path
if($secciones != "" ) {
$secciones = "$secciones";
}
else {
$secciones = "./";
}
// fin path
								 // Le damos valor a las variables de configuraci�n
 $Config['Path'] = "$secciones"; 		// Directorio donde stan los archivos a mostrar.
 $Config['Show'] = 20; 			// Numero de archivos a mostrar por p�ginas.

 $Show['20 Anteriores'] = 0;		// Por defecto no se mostrara 10 Anteriores
 $Show['20 Siguientes'] = 0;		// Por defecto no se mostrara 10 Siguientes
 
 if ($c == "") $c = 0;			// Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
 $dir = @opendir($Config['Path']); 		// Abrimos el directorio donde estan los archivos
 $Plus = $c;					// Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

 while ($c > 0 && $elemento = @readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
 {
  $Show['20 Anteriores'] = 1;
  $c--;
 }

 $Counter = 0;			// Ponemos a 0 el contador

 // Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
 if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
 }
 
 // Mostramos el numero de archivos que se tienen que mostrar por p�gina.
 while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
 {
  $Counter++;
  
  $elemento1 = strtolower($elemento); 
  
  if (strpos($elemento1, ".txt") > 1) {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".txt","",$elemento); 
?>
  <tr> 
    <td width="20%" height='7' class="tabla_mensaje"> 
      <?
// Archivo adjunto
$archivofisico = str_replace("$secciones","",$tutorial); 
if(file_exists("$secciones$elemento2.zip")) {
echo "<a href='index.php?b=$secciones$elemento2' target='_blank'><img src='zip.gif' border='0' width='16' height='16'></a>";
}
else 
{ 
echo "";
} 
?>
      <a href="index.php?a=<? echo $secciones ?><?php echo $elemento2 ?>&secciones=<? echo $secciones ?>"><img src="txt.gif" border="0" width="16" height="16" > 
      <? echo $elemento2 ?></a></td>
    <td width="29%" class="tabla_mensaje">
      <div align="left"><?
// asignamos el tama�o de los archivo
if(file_exists("$secciones$elemento2.php")) {
include ("$secciones$elemento2.php") ;
echo "$iddesc";
}
else 
{ 
echo "Sin descripcion";
}
?></div>
    </td>
    <td class="tabla_mensaje"> 
      <?
// asignamos el tama�o de los archivo
if(file_exists("$secciones$elemento2.php")) {
include ("$secciones$elemento2.php") ;
echo "$idautor";
}
else 
{ 
echo "Anonimo";
}
?>
      <br> </td>
    <td height='7' class='tabla_mensaje'> 
      <?  
// asignamos el tama�o de los archivo
$elemento = "$secciones/$elemento";
if(filesize($elemento) > 1000000) {
$tamano = filesize($elemento)/1024/1024;
$tamano = ceil($tamano) ;
echo "$tamano Mb";
}
else { 
if(filesize($elemento) > 1000) {
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
echo "$tamano Kb";
} 
else {
$tamano = filesize($elemento);
$tamano = ceil($tamano);
echo "$tamano bytes";
} 
}
?>
    </td>
    <td class='tabla_mensaje'> 
      <?
// asignamos el tama�o de los archivo
if(file_exists("$secciones$elemento2.dat")) {
include ("$secciones$elemento2.dat") ;
}
else 
{ 
echo "0";
}
?>
    </td>
    <td width="6%" class='tabla_mensaje'><a href="index.php?archivo=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>" >Editar</a></td>
    <td width="7%" class='tabla_mensaje'><a href="index.php?borrar=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>">Borrar</a></td>
    <td width="10%" class='tabla_mensaje'><a href="index.php?renombrar=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>">Renombrar</a></td>
  </tr>
  <?php
  }
 }
  
 // Si sobran archivos pondremos el "10 Siguientes"
 if ($elemento = @readdir($dir))
 {
  $Show['20 Siguientes'] = 1;
 }

 //Cerramos el directorio 
 @closedir($dir); 
?>
</table>
<div align="right">
<?php
 // Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
 if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."&secciones=$secciones\">20 Anteriores | </a>");
 if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."&secciones=$secciones\">20 Siguientes</a></p>");
?>
</div>
<a href="index.php?archivon=<? echo $secciones ?>nuevo%20%20tutorial&secciones=<? echo $secciones ?>"> <br>
      + A&ntilde;adir nuevo tutorial</a><br>
      <strong><a href="index.php?directorio=<? echo $secciones ?>nuevo%20%20directorio&secciones=<? echo $secciones ?>">+ 
      Crear una nueva seccion</a></strong><br>
<? if ($tutorial) 
{ 
?><br>
<table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid' dwcopytype="CopyTableCell">
  <tr> 
    <td width="97%" height="1" align="center" class="tabla_subtitulo"><div align="center" class="t1"> 
<?
// Nombre del archivo
if(file_exists("$tutorial.txt")) {
$none4 = str_replace("$secciones","",$tutorial);
echo "$none4";
} 
else 
{ 
echo "No existe";
} 
?>
      </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="8" colspan="2" class="tabla_mensaje"> <div align="left"> 
        <? /*opcion nueva para poder subir tutoriales sobre el bbcode y que no interfiera con el propio bbcode de la pagina*/ if ($bbcode != "off" ) { ?>
        &iquest;Tienes problemas para ver el tutorial ? pulsa en <a href="<? echo $_SERVER[REQUEST_URI] ?>&bbcode=off">desactivar 
        bbcode</a> 
        <? } ?>
        <? if ($bbcode == "off" ) { ?>
        <b>* bbcode desactivado</b> , para activarlo de nuevo pulsa <b> <a href="index.php?tutorial=<? echo $tutorial ?>&secciones=<? echo $secciones ?>">aqui</a></b> 
        <? } ?>
      </div></td>
  </tr>
  <tr> 
    <td height="1" colspan="2" class="tabla_mensaje"> 
      <table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
        <tr> 
          <td width="100%" height="31" class="tabla_mensaje"> 
            <?
// Autor del tutorial
$archivofisico = str_replace("$secciones","",$tutorial); 
if(file_exists("$secciones$archivofisico.php")) {
include ("$secciones$archivofisico.php") ;
echo "- Autor del tutorial : <b>$idautor</b>";
}
else 
{ 
echo "";
}
?>
            <br>
            <?
// Fecha subid tutorial
$archivofisico = str_replace("$secciones","",$tutorial);  
if(file_exists("$secciones$archivofisico.php")) {
include ("$secciones$archivofisico.php") ;
echo "- Fecha de subida del tutorial : <b>$idfecha</b>";
}
else 
{ 
echo "";
}
?>
            <br>
<?
// Descripcion
$archivofisico = str_replace("$secciones","",$tutorial);
// asignamos el tama�o de los archivo
if(file_exists("$secciones$archivofisico.php")) {
include ("$secciones$archivofisico.php") ;
echo "- Descripcion: $iddesc";
}
else 
{ 
echo "";
}
?>
          </td>
        </tr>
        <?
// Archivo adjunto
if(file_exists("$tutorial.zip")) {
?>
        <?
}
else 
{ 
echo "";
} 
?>
      </table>
            <br>
            <table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
              <tr> 
                <td width="100%" height="32" class="tabla_mensaje"> 
                  <?
// Buscamos si el archivo existe y lo leemos
// $codigo seria el contenido del archivo en si
if(file_exists("$tutorial.txt")) {  
$archi = "$tutorial.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// bbcode o codigo especial, este codigo lo que hace
// es sustituir determinadas expresiones de letras
// por codigo html seguro
// para desactivarlo pon if ($bbcode == "on" ) {
// index.php?tutorial=aaa&bbcode=on
if ($bbcode != "off" ) {
$codigo = str_replace("[b]","<b>",$codigo) ;
$codigo = str_replace("[/b]","</b>",$codigo) ;
$codigo = str_replace("[img]","<img src=\"",$codigo) ;
$codigo = str_replace("[/img]","\" border=\"0\">",$codigo) ;

$codigo = str_replace("[azul]","<font color=blue>",$codigo) ;
$codigo = str_replace("[/azul]","</font>",$codigo) ;
$codigo = str_replace("[red]","<font color=red>",$codigo) ;
$codigo = str_replace("[/red]","</font>",$codigo) ;
$codigo = str_replace("[u]","<u>",$codigo) ; 
$codigo = str_replace("[/u]","</u>",$codigo) ; 
$codigo = str_replace("[s]","<strike>",$codigo) ; 
$codigo = str_replace("[/s]","</strike>",$codigo) ; 
$codigo = str_replace("[sup]","<sup>",$codigo) ; 
$codigo = str_replace("[/sup]","</sup>",$codigo) ; 
$codigo = str_replace("[sub]","<sub>",$codigo) ; 
$codigo = str_replace("[/sub]","</sub>",$codigo) ; 
$codigo = str_replace("[left]","<left>",$codigo) ; 
$codigo = str_replace("[/left]","</left>",$codigo) ; 
$codigo = str_replace("[center]","<p align=center>",$codigo) ;
$codigo = str_replace("[/center]","</p>",$codigo) ;
$codigo = str_replace("[right]","<p align=right>",$codigo) ;
$codigo = str_replace("[/right]","</p>",$codigo) ;
// Inicio caretos : por defecto desactivados
// ya que esta demostrado que puede interferir con colorear el codigo
// para activarlos permanetemente pon if ($caretos != "off" ) {
if ($caretos == "on" ) {
$codigo = str_replace("[[","",$codigo) ;
$codigo = str_replace("]]","",$codigo) ;
$codigo = str_replace(":D","[[alegre.gif]]",$codigo) ;
$codigo = str_replace(":8","[[asustado.gif]]",$codigo) ;
$codigo = str_replace(":P","[[burla.gif]]",$codigo) ;
$codigo = str_replace(":S","[[confundido.gif]]",$codigo) ;
$codigo = str_replace(":(1","[[demonio.gif]]",$codigo) ;
$codigo = str_replace(":(2","[[demonio2.gif]]",$codigo) ;
$codigo = str_replace(":?","[[duda.gif]]",$codigo) ;
$codigo = str_replace(":-(","[[enojado.gif]]",$codigo) ;
$codigo = str_replace(";)","[[guino.gif]]",$codigo) ;
$codigo = str_replace(":'(","[[llorar.gif]]",$codigo) ;
$codigo = str_replace(":lol","[[lol.gif]]",$codigo) ;
$codigo = str_replace(":M","[[moda.gif]]",$codigo) ;
$codigo = str_replace(":|","[[neutral.gif]]",$codigo) ;
$codigo = str_replace(":)","[[risa.gif]]",$codigo) ;
$codigo = str_replace(":-)","[[sonrisa.gif]]",$codigo) ;
$codigo = str_replace(":R","[[sonrojado.gif]]",$codigo) ;
$codigo = str_replace(":O","[[sorprendido.gif]]",$codigo) ;
$codigo = str_replace(":(","[[triste.gif]]",$codigo) ;
$codigo = str_replace("[[","<img src=\"caretos/",$codigo) ;
$codigo = str_replace("]]","\" width=\"15\" height=\"15\">",$codigo) ;
}
// anti-insultos
$codigo = str_replace("capullo","***",$codigo) ;
$codigo = str_replace("cabron","***",$codigo) ;
$codigo = str_replace("hijo puta","***",$codigo) ;
$codigo = str_replace("maricon","***",$codigo) ;
$codigo = str_replace("puta","***",$codigo) ;
$codigo = str_replace("gay","***",$codigo) ;
// convertir enlaces a url
$codigo = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$codigo) ;
// colorear el codigo 
// by wwww.electros.tk
if(strstr($codigo,"[codigo]")) {
$partes = explode("[codigo]",$codigo) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$codigo = implode("",$partes) ;
} 
}
// Ponemos en el codigo los puntos y los espacios correspondientes.
$codigo = str_replace("\r\n","<br>",$codigo) ;
// Mostramos el codigo de la pagina
echo "$codigo";
} 
else 
{ 
echo "Este tutorial se esta actualizando o ya no existe.";
} 
?>
                </td>
              </tr>
              <?
// Archivo adjunto
if(file_exists("$tutorial.zip")) {
?>
              <?
}
else 
{ 
echo "";
} 
?>
            </table>
          </td>
  </tr>
  <?
// Archivo adjunto
if(file_exists("$tutorial.zip")) {
?><tr>
    <td height='4' colspan='2' class='tabla_mensaje'><div align="center"><a href='index.php?b=<? echo $tutorial ?>' target='_blank'><img src='zip.gif' border='0' width='16' height='16'> 
        Descargar archivo</a> (
        <?
// Contamos los clicks en los archivos
if(file_exists("$tutorial.zip.dat")) {
include ("$tutorial.zip.dat") ;
}
else 
{ 
echo "0";
}
?>
        ) </div></td>
  </tr><?
}
else 
{ 
echo "";
} 
?>
</table>
      <br>
<table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
        <tr> 
          <td height="0" align="center" class="tabla_subtitulo"><div class="t1">Comentarios</div>
            </td>
        </tr>
        <tr>
          <td height="1" align="center" class="tabla_mensaje"><table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid' dwcopytype="CopyTableCell">
                
<?
$elemento = $a ;  
$file = "$tutorial.com.dat"; 
//Se tramita el formulario y se guardan los nuevos datos.

if(!empty($opinion))
{
// bbcode para mayor seguridad
function quitar2($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$opinion = quitar2($opinion) ;
$nombre = quitar2($nombre) ;
// creamos el fichero
$fichero = fopen($file, "a");
fwrite($fichero, "$nombre////$opinion\n");
fclose($fichero);
}
//Se inicia el proceso de impresion de los datos
if(file_exists($file)&&is_file($file))
{
$fichero = fopen($file, "r");
//Se extraen todas las lineas.
while(!feof($fichero))
{
$cadena = fgets($fichero, 4096);
list($nom, $men)=split('////', $cadena);
//Se elimina la lectura de los \n \r
if(!empty($cadena)){
?>
<tr> 
<td width="17%" height="1" align="center" class="tabla_subtitulo"><div align="left"><? echo $nom ?></div></td>
<td width="83%" align="center" class="tabla_mensaje"><div align="left"><? echo $men ?></div></td>
</tr>
<? }
}//END WHILE
fclose($fichero);
}
?>
                
              </table>
            &nbsp;</td>
        </tr>
        <tr> 
          <td height="203" align="center" class="tabla_mensaje"><div align="center">
		  <FORM METHOD="Post" ACTION="<? echo $_SERVER[REQUEST_URI] ?>">
                <table width="1" border="0" cellspacing="0" cellpadding="2">
                  <tr> 
                    <td width="1" height="25" valign="top"><div align="center"> 
                        <div align="center">Nombre:</div>
                      </div></td>
                    <td width="1" valign="top"> 
                      <input name="nombre" type="Text" id="nombre3" size=60 maxlength=60 style="font-size:10px;font-family:verdana;" class="form">
                      </td>
                  </tr>
                  <tr> 
                    <td height="1" valign="top">Opinion:<b> </b></td>
                    <td valign="top"><b>
                      <textarea name="opinion" cols="60" rows="8" class="form" style="font-size:10px;font-family:verdana;"></textarea>
                      </b></td>
                  </tr>
                  <tr> 
                    <td height="1" colspan="2"><div align="center"><b>
                        <INPUT name="Submit" TYPE="Submit" class="form" VALUE="Enviar Opini�n">
                        </b></div></td>
                  </tr>
                </table>
            </FORM>
            </div></td>
        </tr>
      </table>
	  
      <br>
      <?
}
?>
      <br>
<?
// Crear un nuevo tutorial: si el archivo no tiene nombre 
// y comprobamos si no existe nuevo%20%20tutorial.txt
if ($archivon != "") {
if(!file_exists("nuevo%20%20tutorial.txt")) { 
 function write_fil2($arch, $titulo) {
 if ($fp = @fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$secciones$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left"> 
        Nuevo tutorial 
        <script>
function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
      </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="587" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method="post" action='index.php?action=new&archivon=<? echo $archivon ?>&secciones=<? echo $secciones ?>' id="formulario" name="formulario" enctype="multipart/form-data">
          Nombre del tutorial :<br>
          <input name='archivon' type='text' class='form' value="<? /*si el archivo es 'nuevo tutorial' evitaremos que ponga eso mismo en el formulario */  if ($archivon ="nuevo%20%20tutorial"){$archivon ="";}  else {} echo $archivon ?>" size="33">
          <br>
          Autor del tutorial :<br>
          <input name='cnautor' type='text' class='form' id="cnautor" size="33">
          <br>
          Contrase&ntilde;a atribuida al tutorial :<br>
          <input name='cnpass' type='text' class='form' id="cnpass" size="33">
          <br>
          Breve descripcion del tutorial :<br>
                <textarea rows="3" cols="50"  name="cndesc" id="cndesc" class='form'><? echo $cndesc; ?>
</textarea>
          <br>
          Contenido del tutorial :<br>
          <br>
          <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> Insertar un codigo php.<br>
		  <a href="javascript:descargar('[azul][/azul]')">[azul][/azul]</a> Insertar codigo azul.<br>
		  <a href="javascript:descargar('[red][/red]')">[red][/red]</a> Insertar un codigo rojo.<br>
          <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar un texto 
          en negrita.<br>
          <a href="javascript:descargar('[img][/img]')">[img][/img]</a> Insertar 
          una imagen.<br>
          <br>
          <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. <br>
		  <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. <br>
		  <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> Superindice. <br>
		  <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> Subindice. <br>
		  <a href="javascript:descargar('[left][/left]')">[left][/left]</a> Alinear texto a la izquierda . <br>
		  <a href="javascript:descargar('[right][/right]')">[right][/right]</a> Alinear texto a la derecha . <br>
          <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
          Alinear texto al centro . <br>
          <br>
          <br>
          <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
          <br>
          <br>
          <b>Como deseas enviar el archivo ?</b><br>
          <input type="radio" name="envioarchivo" value="0" id="envioarchivo1" checked>
          <label for="envioarchivo1">No subir archivo</label>
          <input type="radio" name="envioarchivo" value="1" id="envioarchivo2">
          <label for="envioarchivo2">Subir el archivo</label>
          <br>
          <br>
          <b style="color: #ff0000">Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input type="file" name="archivo" size="30" class="form">
          <br>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$descargar = $HTTP_POST_VARS['descargar'];
}
else if($action == "new")
{
// comprobamos si en el form se envian todos los campos y no hay ningun vacio
if (isset($descargar)&&isset($cnpass)&&isset($cnautor)&&isset($cndesc)&&($descargar!="")&&($cnpass!="")&&($cnautor!="")&&($cndesc!="")){
// creamos el archivo.php fisicamente con los datos
$cnpass = htmlspecialchars(md5($_POST['cnpass']));
$cnautor = htmlspecialchars(trim($_POST['cnautor']));
$cnautor = htmlspecialchars(trim($_POST['cnautor']));
$cnfecha = htmlspecialchars(trim($_POST['cnfecha']));
$cndesc = htmlspecialchars(trim($_POST['cndesc']));
$cnfecha = Date("d.m.y")." a las ".Date("H:i:s");

$nuevo .= "<"."?\n";
$nuevo .="\$idpass = \"$cnpass\";\n";
$nuevo .="\$idautor = \"$cnautor\";\n";
$nuevo .="\$idfecha = \"$cnfecha\";\n";
$nuevo .="\$iddesc = \"$cndesc\";\n";
$nuevo .= "?".">";

$fich = fopen("$secciones$archivon.php","w");
fputs($fich,$nuevo);
fclose($fich);
// creamos el archivo .txt con el tutorial
if(!file_exists("$secciones$archivon.txt")) {
if(!file_exists("$seccionesnuevo%20%20tutorial.txt")) {  
$archivon = htmlspecialchars(trim($_POST['archivon']));
$descargar = htmlspecialchars(trim($_POST['descargar']));


$rs = write_fil2("$secciones$archivon.txt", "$descargar");
$archi = "$secciones$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
// enviamos el archivo
if($enviar) {
if($archivo != "" && $envioarchivo == 1) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "zip") { $error = "S�lo se permiten archivos .zip<br>" ; }

if(file_exists("$archivo_name")) { $error= "Ya existe un archivo con este nombre.<br>" ; }
if($archivo_size > 250000) { $error= "El archivo debe pesar menos de 250 Kb.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
}
copy($archivo,"$secciones$archivon.zip");
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Nuevo 
        tutorial </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
        Nuevo tutorial creado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
}
}
}
}
?>
<br>
<?
if ($archivo != "") { 
 function write_fil($arch, $titulo) {
 if ($fp = fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
// Leemos la informacion del archivo.txt y la mostarmos
$archi = "$archivo.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
// Abrimos el archivo .php con los datos
if(file_exists("$archivo.php")) {
include ("$archivo.php") ;
}
else 
{
echo "";
}
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
        Editar un comentario 
        <script>
function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
      </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="5" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method="post" action='index.php?action=ver&archivo=<? echo $archivo ?>&secciones=<? echo $secciones ?>' id="formulario" name="formulario" enctype="multipart/form-data">
          Contrase&ntilde;a :<br>
          <input type='text' name='contrasena' class='form'>
                <br>
                Nombre del tutorial :<br>
		  <input name='none' type='text' class='form' value="<?  $none = str_replace("$secciones","",$archivo);  echo $none ?>" size="33" readonly>
          <input name='archivo' type='hidden' class='form' value="<? echo $archivo ?>" size="33" readonly>
                <br>
                    Breve descripcion del tutorial :<br>
                    <textarea rows="3" cols="50"  name="cndesc" id="cndesc" class='form'><? echo $iddesc ?>
</textarea>
                    <br>
                    Contenido del tutorial :<br>
          <br>
                    <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> 
                    Insertar un codigo php.<br>
                    <a href="javascript:descargar('[azul][/azul]')">[azul][/azul]</a> 
                    Insertar codigo azul.<br>
                    <a href="javascript:descargar('[red][/red]')">[red][/red]</a> 
                    Insertar un codigo rojo.<br>
                    <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar 
                    un texto en negrita.<br>
                    <a href="javascript:descargar('[img][/img]')">[img][/img]</a> 
                    Insertar una imagen.<br>
                    <br>
                    <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. 
                    <br>
                    <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. 
                    <br>
                    <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> 
                    Superindice. <br>
                    <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> 
                    Subindice. <br>
                    <a href="javascript:descargar('[left][/left]')">[left][/left]</a> 
                    Alinear texto a la izquierda . <br>
                    <a href="javascript:descargar('[right][/right]')">[right][/right]</a> 
                    Alinear texto a la derecha . <br>
                    <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
                    Alinear texto al centro .<br>
          <br>
          <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
          <?
// Si existe el Archivo adjunto lo mostramos
if(file_exists("$archivo.zip")) {
?><br>
          <br>
          Archivo adjunto :<b> <img src="zip.gif" width="15" height="16"> <?  $none6 = str_replace("$secciones","",$archivo);  echo "$none6.zip"; ?><br>
          <br>
          Deseas actualizar el archivo adjunto ?</b> <br>
          <input type='radio' name='envioarchivo' value='0' id='radio3' checked>
          <label for='radio3'>No</label>
          <input type='radio' name='envioarchivo' value='1' id='radio4'>
          <label for='radio4'>Si</label>
          <br>
          <b style='color: #ff0000'>Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input name='archiv' type='file' class='form' id="archiv" size='30'>
          <br>
          <input name="borrare" type="checkbox" id="borrare" value="1">
          Borrar archivo <br>
          <?
}
else 
{ 
?><br>
          <b>Como deseas enviar el archivo ?</b><br>
          <input type="radio" name="envioarchivo" value="0" id="radio6" checked>
          <label for="radio6">No subir archivo</label>
          <input type="radio" name="envioarchivo" value="1" id="radio7">
          <label for="radio7">Subir el archivo</label>
          <br>
          <br>
          <b style="color: #ff0000">Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input name="archiv" type="file" class="form" id="archiv" size="30">
          <br>
                <?
} 
?>
                <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<? 
$descargar = $HTTP_POST_VARS['descargar'];
}
else if($action == "ver")
{
if(file_exists("$archivo.php")) {
require ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// Comprobamos que la contrase�a del formulario sea la misma que la del archivo .php
if (md5($contrasena) != $idpass) { exit; }{
// Comprobamos que no haya ningun dato vacio o sin rellenar en el formulario 
if (isset($descargar)&&isset($contrasena)&&isset($cndesc)&&($descargar!="")&&($contrasena!="")&&($cndesc!=""))
{
// Editamos el achivo .txt
$archivo = htmlspecialchars(trim($_POST['archivo']));
$descargar = htmlspecialchars(trim($_POST['descargar']));

$rs = write_fil("$archivo.txt", "$descargar");
$archi = "$archivo.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// Editamos el archivo .php
$cnpass = htmlspecialchars(md5($_POST['cnpass']));
$cnautor = htmlspecialchars(trim($_POST['cnautor']));
$cnfecha = htmlspecialchars(trim($_POST['cnfecha']));
$cndesc = htmlspecialchars(trim($_POST['cndesc']));

$cnpass = $idpass ;
$cnautor = $idautor ;
$cnfecha = Date("d.m.y")." a las ".Date("H:i:s");

$datos .= "<"."?\n";
$datos .="\$idpass = \"$cnpass\";\n";
$datos .="\$idautor = \"$cnautor\";\n";
$datos .="\$idfecha = \"$cnfecha\";\n";
$datos .="\$iddesc = \"$cndesc\";\n";
$datos .= "?".">";

$fichdatos = fopen("$archivo.php","w");
fputs($fichdatos,$datos);
fclose($fichdatos);
// borrar el archivo
if($borrare == "1") { unlink("$extensiones$archivo.zip"); }
// actualizar el archivo
if($enviar) {
if($archiv != "" && $envioarchivo == 1) {
$extensiones = explode(".",$archiv_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "zip") { $error = "S�lo se permiten archivos .zip<br>" ; }

if($archiv_size > 250000) { $error= "El archivo debe pesar menos de 250 Kb.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
}
copy($archiv,"$archivo.zip") ;
}
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Editar 
        un comentario</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
              <?
if($borrare) {
?>
              * Archivo borrado y Comentario modificado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
              aqui</a> 
              <?
}
else 
{ 
?>
              * Comentario modificado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
              aqui</a> 
              <?
} 
?>
            </div></td>
  </tr>
</table>
<?
}
}
}
}
?>
<br>
<?
if ($borrar != "") {
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> Borrar 
        un archivo</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method=post action='index.php?action=borrar&archivo=<? echo $borrar ?>&secciones=<? echo $secciones ?>' id=form1 name=form1 enctype="multipart/form-data">
          Se dispone a borrar el siguiente archivo, para confirmar la accion intruduzca 
          la contrase&ntilde;a y pulse enviar.<br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
          <br>
          Nombre del archivo:<br>
		  <input name='none2' type='text' class='form' value="<?  $none2 = str_replace("$secciones","",$borrar);  echo $none2 ?>" size="33" readonly>
          <input name='archivo' type='hidden' class='form' value="<? echo $borrar ?>" size="33" readonly>
                <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $HTTP_POST_VARS['archivo'];
}
else if($action == "borrar")
{
if(file_exists("$archivo.php")) {
include ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// si la contrase�a codificaa en md5 es distinta de la que en archivo.php salimos
if (md5($contrasena) != $idpass) { exit; }{ 
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
// se borra el archivo
unlink("$secciones$archivo.txt") ;
// se borra los posibles restos del archivo, como su contrase�a, comentario, lecturas, zip y clicks en el zip
// a los cuales le ponemos una @ para que no muestre el error en pantalla
@unlink("$secciones$archivo.php") ;
@unlink("$secciones$archivo.dat") ;
@unlink("$secciones$archivo.zip.dat") ;
@unlink("$secciones$archivo.zip") ;
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Borrar 
        un archivo</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
              Archivo borrado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
              aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
?>
<br>
<?
if ($renombrar != "") {
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> Renombrar 
        un archivo</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method=post action='index.php?action=renombrar&archivo=<? echo $renombrar ?>&secciones=<? echo $secciones ?>' id=form1 name=form1 enctype="multipart/form-data">
          Se dispone a renombrar el siguiente archivo, para confirmar la accion 
          intruduzca la contrase&ntilde;a y pulse enviar.<br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
          <br>
          Nombre del archivo antiguo:<br>
		  <input name='none3' type='text' class='form' value="<?  $none3 = str_replace("$secciones","",$renombrar);  echo $none3 ?>" size="33" readonly>
          <input name='archivo' type='hidden' class='form' value="<? echo $renombrar ?>" size="33" readonly="">
          <br>
          Nuevo nombre:<br>
          <input name='nuevo' type='text' class='form' size="33">
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $HTTP_POST_VARS['archivo'];
$nuevo = $HTTP_POST_VARS['nuevo'];
}
else if($action == "renombrar")
{
if(file_exists("$archivo.php")) {
include ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// si la contrase�a codificaa en md5 es distinta de la que en archivo.php salimos
if (md5($contrasena) != $idpass) { exit; }{
if(isset($archivo)&&isset($contrasena)&&isset($nuevo)&&($archivo!="")&&($contrasena!="")&&($nuevo!=""))
{
// Renombramos el archivo del tutorial
rename("$archivo.txt", "$secciones$nuevo.txt");
// Renombramos el resto de archivos que pudiera tener
@rename("$archivo.dat", "$secciones$nuevo.dat");
@rename("$archivo.zip.dat", "$secciones$nuevo.zip.dat");
@rename("$archivo.zip", "$secciones$nuevo.zip");
@rename("$archivo.php", "$secciones$nuevo.php");
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Renombrar 
        un archivo</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
              Archivo renombrado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
              aqui</a></div></td>
  </tr>
</table>
      <?
}
}
}
?>
      <br>
<?
// solo el admin puede crear directorios, la contrase�a se especifica mas abajo
if ($directorio != "") {
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
              Crear una nueva seccion</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method=post action='index.php?action=directorio&archivo=<? echo $directorio ?>&secciones=<? echo $secciones ?>' id="directorio" name="directorio" enctype="multipart/form-data">
                Se dispone a crear una nueva seccion ,cada seccion que cree sera 
                en realidad un nuevo <font color="#0000FF">directorio web<br>
                fisico</font> con el nombre de la seccion. Una vez creado podra 
                guardar sus tututoriales y vera en el menu la su susodicha seccion, 
                para confirmar la accion intruduzca la contrase&ntilde;a y pulse 
                enviar. <br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
                
                <? if ($secciones != "./") { ?><br>
                <font color="#FF0000">Advertencia : La subseccion<br>
                se guardara dentro del directorio</font><font color="#FF0000"><br>
                <input name='none5' type='text' class='form' id="none" value="<?  $none5 = str_replace("nuevo  directorio","",$directorio);  echo $none5 ?>" readonly>
                </font> 
                <? } ?>
                <br>
                Nombre de la seccion :<br>
          <input name='archivo' type='text' class='form' value="<? if ($directorio ="nuevo%20%20directorio"){ $directorio ="";}  else {} echo $directorio ?>" size="33">
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $_POST['archivo'];
}
else if($action == "directorio")
{
if(!file_exists("$secciones$archivo")) {  
if ($contrasena != "123456") { exit; }{  // aqui tu contrase�a
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
// creamos el directorio
mkdir("$secciones$archivo", 0777);
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Crear 
              una nueva seccion</div></td>
          <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php?secciones=<? echo $secciones ?>">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
              Seccion creada satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
              aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
}
?>    </td>
  </tr>
</table>
