<html>

<head>

<title>Foro</title>
<link REL="STYLESHEET" HREF="estilo.css" TYPE="text/css">
</head>

<body>

<table border="0" width="720">
  <tr>
    <td width="100%">
      <table border="0" width="100%" height="150">
        <tr>
          <td width="100%" height="25" align="center">
            <p align="center"><font face="Verdana" color="#003366" size="3"><b>&nbsp;Bienvenido
            al Foro </b></font><font face="Verdana" color="#003366" size="4">&nbsp;&nbsp;&nbsp;</font><font face="Verdana" color="#003366" size="3">
            &nbsp;</font></p>
          </td>
        </tr>
        <tr>
          <td width="100%" height="12"></td>
        </tr>
        <tr>
          <td width="100%" height="8">
            <p align="center"><font face="Verdana" size="2">&nbsp;</font></td>
        </tr>
        <tr>
          <td width="100%" height="50">
            <table border="0" width="100%" cellspacing="1" cellpadding="0">
              <tr>
                <td width="13%" align="center">
                  <p align="left">caracteres &gt;</td>
                <td width="6%" align="center">:)</td>
                <td width="6%" align="center">:e&nbsp; </td>
                <td width="6%" align="center">:D&nbsp; </td>
                <td width="7%" align="center">:a&nbsp; </td>
                <td width="6%" align="center">:8&nbsp; </td>
                <td width="8%" align="center">:u&nbsp;&nbsp; </td>
                <td width="8%" align="center">:x </td>
                <td width="6%" align="center">:k&nbsp; </td>
                <td width="5%" align="center">:w</td>
                <td width="7%" align="center">:z</td>
                <td width="7%" align="center">:s </td>
                <td width="8%" align="center">:j&nbsp; </td>
                <td width="8%" align="center">:r&nbsp;&nbsp; </td>
              </tr>
              <tr>
                <td width="13%" align="center">
                  <p align="left">Emoticones &gt;</td>
                <td width="6%" align="center"><img border="0" src="imagenes/sonrisa.gif"></td>
                <td width="6%" align="center"><img border="0" src="imagenes/ojo.gif"></td>
                <td width="6%" align="center"><img border="0" src="imagenes/divertido.gif"></td>
                <td width="7%" align="center"><img border="0" src="imagenes/hola.gif"></td>
                <td width="6%" align="center"><img border="0" src="imagenes/ojotes.gif"></td>
                <td width="8%" align="center"><img border="0" src="imagenes/confundido.gif"></td>
                <td width="8%" align="center"><img border="0" src="imagenes/enfado.gif"></td>
                <td width="6%" align="center"><img border="0" src="imagenes/cabreo.gif"></td>
                <td width="5%" align="center"><img border="0" src="imagenes/sock.gif"></td>
                <td width="7%" align="center"><img border="0" src="imagenes/zzz.gif"></td>
                <td width="7%" align="center"><img border="0" src="imagenes/golpes.gif"></td>
                <td width="8%" align="center"><img border="0" src="imagenes/barco.gif"></td>
                <td width="8%" align="center"><img border="0" src="imagenes/moto.gif"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td width="100%" height="15">  <center><? include("foro.php")?></center>
          </td>
        </tr>
        <tr>
          <td width="100%" height="16" align="center">
            <p align="right"><font color="#003366">
            </td>
        </tr>
      </table>
    </td>
  </tr>
</table>

<p align="right">&nbsp;</p>
<p align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>

</body>

</html>
