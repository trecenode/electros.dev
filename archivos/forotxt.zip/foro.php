
<?
// Ruta absoluta a los archivos de texto:
$postsID = "id.dat";
$posts = "mensajes.dat";

// Nombre del foro
$nForo = "" ;

// Colores del foro
$tabla_color="#D0DDEE";
$borde_color="#24559F";
$fila1_color="#BCCEE7";
$fila2_color="#AEC4E1";

// Mostrar formulario 'si' o 'no'
$verFormulario = "si";

// Login: Nombre (admin) y Pass (pass)
$loginNombre = "palabra1";
$loginPass = "palabra2";

function validarTags() 
 {
 global $nombre;
 global $asunto;
 global $mensaje;
 $nombre = htmlspecialchars(trim($nombre));
 $nombre = str_replace("&","&",$nombre);
 $nombre = preg_replace("/(\015\012)|(\015)|(\012)/","",$nombre);
 $nombre = stripslashes(str_replace("<","",$nombre));
 $nombre = strip_tags(str_replace(">","",$nombre));
 $nombre = substr(strip_tags($nombre),0,12);
 $asunto = htmlspecialchars(trim($asunto));
 $asunto = str_replace("&","&",$asunto);
 $asunto = preg_replace("/(\015\012)|(\015)|(\012)/","",$asunto);
 $asunto = stripslashes(str_replace("<","",$asunto));
 $asunto = strip_tags(str_replace(">","",$asunto));
 $asunto = substr(strip_tags($asunto),0,30);
 $mensaje = htmlspecialchars(trim($mensaje));
 $mensaje = str_replace("&","&",$mensaje);
 $mensaje = preg_replace("/(\015\012)|(\015)|(\012)/","<br>",$mensaje);
 $mensaje = str_replace("<","",$mensaje);
 $mensaje = str_replace(">","",$mensaje);
 return;
 }

function reemplazarTags() 
 {
 global $mensaje1;
 $mensaje1 = str_replace('[b]', '<b>', $mensaje1);
 $mensaje1 = str_replace('[/b]', '</b>', $mensaje1);
 $mensaje1 = str_replace('[i]', '<i>', $mensaje1);
 $mensaje1 = str_replace('[/i]', '</i>', $mensaje1);
 $mensaje1 = str_replace('[u]', '<u>', $mensaje1);
 $mensaje1 = str_replace('[/u]', '</u>', $mensaje1);
 $mensaje1 = str_replace('[c]', "<font color='#004080'>", $mensaje1);
 $mensaje1 = str_replace('[/c]', '</font>', $mensaje1);
 $mensaje1 = str_replace ("[tk]", "<img src='imagenes/tk.gif' width='15' height='15'>", $mensaje1);
 $mensaje1 = str_replace(":)", "<img src='imagenes/sonrisa.gif' >", $mensaje1);
 $mensaje1 = str_replace(":e", "<img src='imagenes/ojo.gif' >", $mensaje1);
 $mensaje1 = str_replace(":D", "<img src='imagenes/divertido.gif' >", $mensaje1);
 $mensaje1 = str_replace(":a", "<img src='imagenes/hola.gif' >", $mensaje1);
 $mensaje1 = str_replace(":8", "<img src='imagenes/ojotes.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":u", "<img src='imagenes/confundido.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":x", "<img src='imagenes/enfado.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":k", "<img src='imagenes/cabreo.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":w", "<img src='imagenes/sock.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":z", "<img src='imagenes/zzz.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":s", "<img src='imagenes/golpes.gif' >", $mensaje1);
 $mensaje1 = eregi_replace (":j", "<img src='imagenes/barco.gif' >", $mensaje1);
 $mensaje1 = str_replace (":r", "<img src='imagenes/moto.gif' >", $mensaje1);
 return;
 }

function escribirMensaje($posts, $postsID)
 {
 global $nueva_id;
 $fp = fopen ($postsID, "rb");
 $id = fgets($fp, 4096);
 $nueva_id = $id + 1;
 fclose($fp);
 $fp = fopen ($postsID, "r+b");
 flock ($fp,2);
 fwrite($fp, $nueva_id);
 flock ($fp,3);
 fclose($fp);
 
 $fp = fopen ($posts, "ab");
 flock ($fp,2);
 fwrite($fp, "\r\n");
 flock ($fp,3);
 fclose($fp);
 return;
 }
 
function eliminarMensaje($elArchivo, $elPost)
 {
    $i = 0;
    $archivo1 = file($elArchivo);
    $fp = fopen($elArchivo, "w");
    for ($i = 0; $i <= sizeof($archivo1); $i++)
    {
    if (strstr($archivo1[$i], $elPost))
    { 
 $archivo1[$i] = "";
 }
 fwrite($fp, $archivo1[$i]);
    }
    fclose($fp);
    return;
    }
 
// Contar temas y mensajes

$temas=0;
$mens=0;
 
$fp = fopen ($posts, "rb");
while (!feof ($fp))
 {
  $buff = fgets($fp, 4096);
  if(substr($buff, 0, 12 )=="[nuevo_post]") {
   $p=explode('|||^^^|||', "$buff");
   if ($p[2]==0) {
    $temas++;
    $mens++;
   }
   else {
    $mens++;
   }
  }
 }
fclose($fp);

switch($a)
{

// Ingrear al sistema

case "login":

 echo "<form action='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid' method='post'>\n";
 echo "<table border='0' cellspacing='1' cellpadding='3' width='320' bgcolor='$borde_color'>\n<tr bgcolor='$tabla_color' style='color: #24559F'>\n<td><b>Acceso para el Administrador</b></td></tr>\n";
 echo "<tr><td width='320' colspan='2' bgcolor='#ffffff'>\n";
 echo "<table cols='2' width='320' class='body'>\n";
 echo "<tr><td colspan='2' bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>\n";
 echo "<tr><td width='70' valign='top'>Usuario:</td><td width='250'>\n<input type='text' name='usuario' size='35' maxlength='12' class='input'></td></tr>\n";
 echo "<tr><td width='70' valign='top'>Password:</td><td width='250'>\n<input type='text' name='password' size='35' maxlength='30' class='input'></td></tr>\n";
 echo "<tr><td width='320' colspan='2'></td></tr>\n";
 echo "<tr><td width='70' valign='top'></td><td width='250'>\n<input type='submit' name='login' value='Ingresar' class='boton'> \n<input type='reset' value='Restablecer' class='boton'></td></tr>\n";
 echo "<tr><td bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>\n";
 echo "</table></td></tr></table></form>\n";
 if (!$usuario or !$password) {
  echo "<a href='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid'><< Volver al mensaje</a>";
 }
 
break;


// Postear un nuevo mensaje

case "postnuevo":

 // Validar formulario
 
 if (!$nombre or !$asunto or !$mensaje) {
  echo "Por favor, complete todos los campos del formuario.<br><a href='index.php?ver_formulario=$verFormulario'><< Volver al Foro</a>";
 }
 else {
 
 escribirMensaje($posts, $postsID);
 
 // Reemplazar tags no deseados
 
 validarTags();
 
 // Escribir post en el archivo
 
 if (!$nombre or !$asunto or !$mensaje) {
 $nombre = "(Ninguno)";
 $asunto = "(Ninguno)";
 }
 $fecha=date("d-m-y");
 $fp = fopen ($posts, "ab");
 flock ($fp,2);
 fwrite($fp, "[nuevo_post]|||^^^|||$nueva_id|||^^^|||0|||^^^|||$nombre|||^^^|||$asunto|||^^^|||$fecha|||^^^|||$mensaje|||^^^|||");
 flock ($fp,3);
 fclose($fp);
 
 echo "Muchas gracias. Su mensaje ha sido agregado.<br><a href='index.php?ver_formulario=$verFormulario' target='_top'><< Volver atr�s</a>";
 }
break;


// En caso de que sea una respuesta

case "responder":

 if (!$nombre or !$asunto or !$mensaje) {
  echo "Por favor, complete todos los campos del formuario.<br><a href='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid' target='_top'><< Volver al mensaje</a>";
 }

 else {

 escribirMensaje($posts, $postsID);
 
 // Reemplazar tags...
 
 validarTags();
 
 $fecha=date("d-m-y");
 $fp = fopen ($posts, "ab");
 flock ($fp,2);
 fwrite($fp, "[nuevo_post]|||^^^|||$nueva_id|||^^^|||$tid|||^^^|||$nombre|||^^^|||$asunto|||^^^|||$fecha|||^^^|||$mensaje|||^^^|||");
 flock($fp,3);
 fclose($fp);
 
 echo "Muchas gracias. Su respuesta ha sido agregada.<br><a href='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid' target='_top'><< Ver mensaje</a>";
 }
break;


// En caso de ver un mensaje

case "ver_mensaje":

 $ahora = date("d-m-y");
 $zonahoraria = date("O");
 
 echo "<table border='0' width='550'>\n<tr><td align='left'>\n<tr><td>$nForo<td align='right'>\n";
 if ($usuario != $loginNombre || $password != $loginPass)
 {
 echo "<a href='index.php?ver_formulario=$verFormulario&a=login&tid=$tid'>Admin</a> | ";
 }
 elseif ($usuario == $loginNombre && $password == $loginPass) 
 {
 $verFormulario = "no";
 }
 echo "<a href='index.php?ver_formulario=$verFormulario' target='_top'>Volver al Foro</a>\n</td></tr></table>\n
 <table border='0' width='550' cellspacing='1' cellpadding='2' bgcolor='$borde_color'>\n<tr bgcolor='$tabla_color' border='1' bordercolor='1' style='color:#24559F'>
 <td width='100'>\n<b>Autor</b><td width='450'><b>Mensaje</b></td></tr>\n";
 
 $fp = fopen ($posts, "rb");

 while(!feof ($fp))
 {
 
  $buffer = fgets($fp, 4096);
  if (substr($buffer, 0, 12 )=="[nuevo_post]")
  {
   $p=explode('|||^^^|||', "$buffer");
   if ($p[1]==$tid)
   {
    $asunto=$p[4];
    $mensaje1 = nl2br($p[6]);
    
    if ($usuario == $loginNombre && $password == $loginPass)
    {
    $eliminar = "[ <a href='index.php?ver_formulario=$verFormulario&a=eliminar&usuario=$usuario&password=$password&tid=$tid&p1=$p[1]&p2=$p[2]&p3=$p[3]&p4=$p[4]'>Eliminar</a> ]";
    }
    
    reemplazarTags();
    
    echo "<tr bgcolor='$fila1_color' border='1' bordercolor='1'><td valign='top'>\n
    <B>$p[3]</B><td><b>$p[4]</b><p>$mensaje1</td></tr>\n
    <tr bgcolor='$fila1_color' border='1' bordercolor='#ffffff'><td>$eliminar</td>\n
    <td>Fecha: $p[5]</td></tr>"; 
   }
  }
 }
 fclose($fp);

 $fp = fopen ($posts, "rb");
 
 $color=0;
 while (!feof ($fp))
 {
  $buffer = fgets($fp, 4096);
  if(substr($buffer, 0, 12 )=="[nuevo_post]")
  {
   $p=explode('|||^^^|||', "$buffer");
   if ($p[2]==$tid)
   {
    $asunto = substr(strip_tags($p[4]),0,30);
    $nombre = substr(strip_tags($p[3]),0,10);
    $mensaje1 = nl2br($p[6]);
    
    if ($usuario == $loginNombre && $password == $loginPass)
    {
    $eliminar = "[ <a href='index.php?ver_formulario=$verFormulario&a=eliminar&usuario=$usuario&password=$password&tid=$tid&p1=$p[1]&p2=$p[2]&p3=$p[3]&p4=$p[4]'>Eliminar</a> ]";
    }

    reemplazarTags();
    
    if ($color==0) {
    echo "<tr bgcolor='$fila2_color' border='1' bordercolor='1'>\n<td valign='top'>\n<B>$nombre</B><td><B>Re: $asunto</B><p>\n$mensaje1</td>\n
    <tr bgcolor='$fila2_color' border='1' bordercolor='#ffffff'>\n<td>$eliminar</td><td>Fecha: $p[5]</td></tr>\n";
    $color=1;
    }
    else {
    echo "<tr bgcolor='$fila1_color' border='1' bordercolor='1'>\n<td valign='top'>\n<B>$nombre</B><td><B>Re: $asunto</B><p>\n$mensaje1</td>\n
    <tr bgcolor='$fila1_color' border='1' bordercolor='#ffffff'>\n<td>$eliminar</td><td>Fecha: $p[5]</td></tr>\n";
    $color=0;
    }
   }
  }
 }
 fclose($fp);
 echo "</table><table width='550'><tr><td></tr></td>";
 echo "<tr><td align='right'><A HREF='index.php?ver_formulario=$verFormulario'>Volver al Foro</A></tr></td></table>";
 
 // Formulario de respuesta
 
 if ($verFormulario == "si" && $tid != "")
 {
 echo "<form action='index.php?ver_formulario=$verFormulario&a=responder' method='post'>\n";
 echo "<table border='0' cellspacing='1' cellpadding='3' width='550' bgcolor='$borde_color'>\n<tr bgcolor='$tabla_color' style='color:#24559F'>\n<td><b>Responder al mensaje:</b> $asunto</td></tr>\n";
 echo "<tr><td width='550' colspan='2' bgcolor='#ffffff'>\n";
 echo "<table cols='2' width='550' class='body'>\n";
 echo "<tr><td colspan='2' bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>";
 echo "<tr><td width='100' valign='top'>Nombre:</td><td width='450'><input type='text' name='nombre' size='55' maxlength='12' class='input'></td></tr>\n";
 echo "<tr><td width='100' valign='top'>Mensaje:</td><td width='450'><textarea name='mensaje' rows='8' cols='54' class='input'></textarea></td></tr>\n"; 
 echo "<tr><td width='550' colspan='2'></td></tr>\n";
 echo "<tr><td width='100' valign='top'></td><td width='450'>\n<input type='submit' name='responder' value='Responder mensaje' class='boton'> \n<input type='reset' value='Restablecer' class='boton'></td></tr>\n";
 echo "<input type='hidden' name='tid' value='$tid'><input type='hidden' name='asunto' value='$asunto'>\n";
 echo "<tr><td bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>\n";
 echo "</table></form></td></tr></table>\n";
 }
break;


// Eliminar mensaje

case "eliminar":

 if ($usuario == $loginNombre && $password == $loginPass){
  if ($p1 != "" && $p2 != "" && $p3 != "" && $p4 != ""){
  $elPost = "[nuevo_post]|||^^^|||$p1|||^^^|||$p2|||^^^|||$p3|||^^^|||$p4|||^^^|||";
  eliminarMensaje($posts, $elPost);
  echo "Listo. El mensaje ha sido eliminado.<br><a href='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid&usuario=$usuario&password=$password' target='_top'><< Volver al mensaje</a>";
  }
 }
 else 
 {
 echo "<font color='#ff0000'><b>Error! El sistema no lo ha identificado.</b></font><br>\n";
 echo "<a href='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$tid' target='_top'><< Volver al mensaje</a>\n";
 }
break;


// Mostrar todos los mensajes

default:

 $limite = 5;
 $ahora=date("d-m-y");
 $zonahoraria=date("O");
 echo "<table border='0' width='550'><tr><td>$nForo<td align='right'>$temas temas y $mens mensajes</td></tr></table>\n
 <table border='0' width='550' cellspacing='1' cellpadding='2' bgcolor='$borde_color'>\n
 <tr bgcolor='$tabla_color' border='1' bordercolor='1' style='color: #24559F'><td width='20'> </td><td width='280'>\n
 <b>Asunto</b></td><td width='90'><b>Autor</b></td><td width='80'><b>Respuestas</b></td><td width='80'><b>Fecha</b></td></tr>\n";
 $fp = fopen ($posts, "rb");
 while (!feof ($fp))
 {
  $buffer = fgets($fp, 4096);
  if(substr($buffer, 0, 12 )=="[nuevo_post]")
  {
   $p=explode('|||^^^|||', "$buffer");
   if ($p[2]==0)
   {
   $fp1 = fopen ($posts, "rb");
   $respuestas=0;
   while (!feof ($fp1))
    {
    $buffer1 = fgets($fp1, 4096);
    
    if(substr($buffer1, 0, 12 )=="[nuevo_post]")
    {
     
     $p1=explode('|||^^^|||', "$buffer1");
     if ($p1[2]==$p[1]) {
      $respuestas++;
     }
 
   }
   }
   fclose($fp1);

   echo "<tr bgcolor='#ffffff' border='1' bordercolor='1'><td>";
   if ($respuestas==0)
   {
   echo "<img src='imagenes/0mens.gif' width='16' height='16'>";
   }
   else 
   {
   echo "<img src='imagenes/1mens.gif' width='16' height='16'>";
   }
   echo "<td><A HREF='index.php?ver_formulario=$verFormulario&a=ver_mensaje&tid=$p[1]'>$p[4]</A><td>$p[3]<td align='center'>$respuestas<td>$p[5]</td></tr>";
   }
  }
 }
 fclose ($fp);
 echo "</table><br>";
 
 // Formulario para publicar un tema nuevo
 
 if ($verFormulario == "si")
 {
 echo "<form action='index.php?ver_formulario=$verFormulario&a=postnuevo' method='post'>\n";
 echo "<table border='0' cellspacing='1' cellpadding='2' width='550' bgcolor='$borde_color'><tr bgcolor='$tabla_color' style='color:#24559F'><td><b>Publicar un tema nuevo</b></td></tr>";
 echo "<tr><td width='550' bgcolor='#ffffff'>";
 echo "<table cols='2' width='550' class='body'>";
 echo "<tr><td colspan='2' bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>";
 echo "<tr><td width='100' valign='top'>Nombre:</td><td width='450'><input type='text' name='nombre' size='55' maxlength='12' class='input'></td></tr>\n";
 echo "<tr><td width='100' valign='top'>Asunto:</td><td width='450'><input type='text' name='asunto' size='55' maxlength='30' class='input'></td></tr>\n";
 echo "<tr><td width='100' valign='top'>Mensaje:</td><td width='450'><textarea name='mensaje' rows='8' cols='54' class='input'></textarea></td></tr>\n"; 
 echo "<tr><td width='550' colspan='2'></td></tr>";
 echo "<tr><td width='100' valign='top'></td><td width='400'><input type='submit' name='postnuevo' value='Publicar tema' class='boton'> <input type='reset' value='Restablecer' class='boton'></td></tr>\n";
 echo "<tr><td bgcolor='#ffffff'><img src='imagenes/tablasepara.gif' width='1' height='10'></td></tr>";
 echo "</table></form></td></tr></table>\n";
 }
 break;
}
?>

