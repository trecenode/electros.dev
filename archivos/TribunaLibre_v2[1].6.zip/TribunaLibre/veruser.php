<? 
include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");
include("tagnicks.php");
?>
<html>
<head>
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body bgcolor="#cccccc"><table border="0" cellpadding="2" cellspacing="2" width="100%" bgcolor="#cccccc" height="100%" style="border: 1px solid <? echo $bordetabla; ?>"><tr><td class="Texto" align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0"><tr><td class="Texto"><font color="#cc0000"><?=_REGISTEREDUSERS; ?></font></td></tr></table></td></tr><tr><td valign="top" height="100%"><table border="0" cellpadding="2" cellspacing="2">
<?

echo "<tr><td class=\"Texto\">"._ADMINISTRATOR.": $admin</td></tr>";

// Mostramos los nicks de los usuarios registrados
for ($n = 0; $n < sizeof($nicks); $n++) {
   $name = $nicks[$n][0];
   $m = $n + 1;
   echo "<tr><td class=\"Texto\">$m. $name</td></tr>";
   }
?>
</table></td></tr></table>
</body>
</html>