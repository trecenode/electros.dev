<?
session_name('admin');
session_start();
session_register('esAdmin');

////////////////////////////////////////////////////////////////
//                                                            // 
//   Tribuna Libre v2.6                                      //
//   GNU GENERAL PUBLIC LICENSE (GPL)                         // 
//   http://www.tribunalibre.da.ru                            //
//   Copyright � 2003  Tribuna Libre All rights reserved      //
//   Por favor no borres este texto                           //
//                                                            //
////////////////////////////////////////////////////////////////

include("tagnicks.php");
include("configtag.php");
include("funciones.php");
include("colores.php");
include("ips.php");
include("language/lang-".$langactual.".php");
	
$error = "";

if (isset($enviar)) {

  if ($HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR'];   
  else if ($HTTP_SERVER_VARS['HTTP_VIA'] != "") 
         $ip = $HTTP_SERVER_VARS['HTTP_VIA'];   
  else if ($HTTP_SERVER_VARS['REMOTE_ADDR'] != "") 
         $ip = $HTTP_SERVER_VARS['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 
  
  if (in_array($ip, $ips)) 
    $error = _NOWRITE;
  else {	
    $nick = trim($nick);
	$nick = str_replace(" ","",$nick);
	$mensaje = trim($mensaje);
  if ($mensaje !="mensaje" && $mensaje != "" && $nick != "Nick" && $nick != "") {
    
    if (!existeNick($nick))
      $error = guardarMensaje($nick, $clave, $mensaje, $url, $ip);
    else { 
   
      if (comprobarNick($nick, $clave)) {
	    $existeNick = "true";
	    $error = guardarMensaje($nick, $clave, $mensaje, $url, $ip);
	  } else 
	      $error = _INCORRECTPASS;		 		
    }
  
  } else {
      if ($nick == "Nick" || $nick == "")
	    $error = _NONICK;
      if (($mensaje == "mensaje" || $mensaje == "") && $error != "")
	    $error .= "<br>"._NOMESSAGE;
	  else if ($mensaje == "mensaje" || $mensaje == "")
	         $error = _NOMESSAGE;	 
  } 
 }
} 
?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
<script language="javascript">
<? include("funciones.js"); ?>
</script>
<style type="text/css">
<!--
.CampoTexto { 
   font-size: 10px; 
   font-family: verdana;
   font-size: 10px; 
   font-family: verdana; 
   border: 1px solid <? echo $bordecampo; ?>; 
   background: <? echo $fondocampo; ?>;

}
-->
</style>
</head> 
<body onload="recibirFoco();"> 
<FORM METHOD="post" ACTION="ftag.php?<? echo session_name()."=".session_id() ?>" name="tag"><table border="0" cellpadding="1" cellspacing="0">
<tr><td align="center" colspan="3">
<?
if ($activarLogo == "on") {
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td style="border: 1px solid <?=$bordetabla; ?>" align="center"><a href="http://tribunalibre.coolfreepage.com" class="EnlaceMenu" target="_blank"><img src="img/logotag.gif" border="0" alt="<?=_WEBDESCRIPTION; ?>"></a></td></tr></table>
<?
}
?>
</td></tr><tr><td colspan="3">
<iframe marginwidth="0" marginheight="0" src="<? if ($opciones) { echo ("opciones.php?".session_name()."=".session_id().""); } else { echo ("tag.php?id=".$error."&".session_name()."=".session_id().""); } ?>" frameborder="0" width="180" height="380" scrolling="yes" name="iframe"></iframe>
</td></tr><tr><td valign="top" align="center" class="Texto" colspan="3"><input name="nick" value="<?=_NICKNAME; ?>" <? if ($activarReg == "on") { echo "size=20"; } else { echo "size=33"; } ?> class="CampoTexto" maxlength="<? echo $maxNick; ?>" onfocus="borrarNick();" onclick="borrarNick();"><SCRIPT>
<!--
document.tag.nick.focus();
document.tag.nick.value='<?=_NICKNAME; ?>';
//-->
</SCRIPT><? if ($activarReg == "on") { ?>&nbsp;<input name="clave" value="<?=_PASSWORD; ?>" size="9" maxlength="10" type="Password" onfocus="borrarClave();" class="CampoTexto"><? } ?></td></tr>
<? 
// Si la opcion est� activada
if ($activarUrl == "on") {
?>
<tr><td align="center" colspan="3"><input name="url" value="http://" size=33 class="CampoTexto"></td></tr>
<?
}
?>
<tr><td align="center" class="Texto" colspan="3"><input name="mensaje" size=27 value="<?=_MESSAGE; ?>"
 class="CampoTexto" onfocus="borrarMensaje();" maxlength="<? echo $maxMsg ?>" onKeyPress="charsleft(this);" onKeyDown="charsleft(this);" onBlur="charsleft(this);" onKeyUp="charsleft(this);" onFocus="charsleft(this);" wrap="VIRTUAL" onChange="charsleft(this);">&nbsp;<input class="CampoTexto" size="2" value="<? echo $maxMsg ?>" name="num" readonly></td></tr>
<tr><td align="center" class="Texto"><INPUT CLASS="Boton" TYPE="submit" VALUE="<?=_SEND; ?>" name="enviar"></td><td><INPUT CLASS="Boton" TYPE="Reset" VALUE="<?=_RESET; ?>" name="borrar"></td><td><INPUT CLASS="Boton" TYPE="submit" VALUE="<?=_OPTIONS; ?>" name="opciones"></td></tr></form></td></tr></table></body> 
</html>