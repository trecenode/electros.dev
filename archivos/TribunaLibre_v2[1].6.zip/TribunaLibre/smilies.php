<? 
include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<head>
<title>Tribuna Libre v2.6 - Smilies</title>	
<link rel="stylesheet" type="text/css" href="style.css">
<link REL="STYLESHEET" HREF="estilo.css" TYPE="text/css">
</head>
<BODY bgcolor="#ECCBA7">
<table border="0" cellpadding="5" cellspacing="0" width="100%" height="100%" style="border: 1px solid <? echo $bordetabla; ?>"><tr><td align="center" width="50%">
<img src="smilies/bien.gif" alt=":bien"></td><td class="Texto">:bien</td></tr><tr><td align="center">
<img src="smilies/cool.gif" alt=":cool"></td><td class="Texto">:cool</td></tr><tr><td align="center">
<img src="smilies/duda.gif" alt=":duda"></td><td class="Texto">:duda</td></tr><tr><td align="center">
<img src="smilies/enojado.gif" alt=":enojo"></td><td class="Texto">:enojo</td></tr><tr><td align="center">
<img src="smilies/ginando.gif" alt=":("></td><td class="Texto">:(</td></tr><tr><td align="center">
<img src="smilies/lengua.gif" alt=":P"></td><td class="Texto">:P</td></tr><tr><td align="center">
<img src="smilies/llorando.gif" alt=":llorar"></td><td class="Texto">:llorar</td></tr><tr><td align="center">
<img src="smilies/mal.gif" alt=":mal"></td><td class="Texto">:mal</td></tr><tr><td align="center">
<img src="smilies/ojotes.gif" alt="8)"></td><td class="Texto">8)</td></tr><tr><td align="center">
<img src="smilies/risa.gif" alt=":D"></td><td class="Texto">:D</td></tr><tr><td align="center">
<img src="smilies/sonrisa.gif" alt=":)"></td><td class="Texto">:)</td></tr><tr><td align="center">
<img src="smilies/triste.gif" alt=":("></td><td class="Texto">:(</td></tr><tr><td align="center" colspan="2">
<a href="tag.php" class="EnlaceMenu"><?=_RETURN; ?></a></td></tr></table>
</BODY>
</HTML>