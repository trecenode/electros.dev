<?
include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");
?>
<html>
<head>
   <title>Tribuna Libre v2.6</title> 
<?
 if ($activarTiempo == "on")
   echo "<meta http-equiv='Refresh' content='".$tiempo."'>";
?>
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" bgcolor="<? echo $fondotabla ?>" style="border-left: 1px solid <? echo $bordetabla ?>; border-right: 1px solid <? echo $bordetabla ?>; border-top: 1px solid <? echo $bordetabla ?>; border-bottom: 1px solid <? echo $bordetabla ?>;" width="100%" height="100%"><tr>
<?

if ($id != "") {
?>
<td class="Texto" align="center"><font color="#cc0000"> 
<?
  echo $id;
?>
</font></td></tr>
<?
} else if (filesize("tag.txt") == 0) {
?>
<td class="Texto" align="center"><font color="#cc0000"> 
<?
  echo _EMPTY;
?>
</font></td></tr>
<?
} else {  
// Leemos los mensajes
$archivo = file("tag.txt");
$lineas = count($archivo);
 for ($i = 0; $i < $lineas; $i++) {
 	$total .= $archivo[$i]; 
 }
$mensajes = explode("%%",$total);
$num = count($mensajes)-2;

if ($numMensajes == 0)
  $numMensajes = $num;
else
  $numMensajes = $numMensajes - 1;  
?>
<td class="Texto" align="center" valign="top"><table border="0" cellpadding="2" cellspacing="0" width="100%">
<?
// Mostramos el n�mero de mensajes indicado por el administrador 
for ($i = $num; $i >= $num - $numMensajes; $i--) {
   if ($i % 2 == 0) $bg = $cpar; else $bg = $cimpar;
?>
<tr><td class="Texto" bgcolor="<?=$bg; ?>" style="border-bottom: 1px solid <? echo $bordetabla ?>"> 
<?
echo $mensajes[$i]; 
?>
</td></tr>
<?
echo "\n"; 
}
?>
</td></tr></table>
<?
}
?>
</td></tr></table>
</body></html>