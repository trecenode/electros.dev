<? 
include ("colores.php"); 
include("configtag.php");
include("tagnicks.php");
include("language/lang-".$langactual.".php");
?>
<html>
<head>
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body bgcolor="#cccccc">
<table border = 0 cellpadding=2 cellspacing=2 width="100%" bgcolor="#cccccc" height="100%" style="border: 1px solid <? echo $bordetabla; ?>"><tr><td align="center" valign="middle"><table border ="0" cellpadding="2" cellspacing="2">
<tr><td colspan="2" align="center">
<? 

function yaExiste($login) {
   global $nicks, $admin, $pass;
   
   for ($n = 0; $n < sizeof($nicks); $n++)
	  if (strtolower($nicks[$n][0]) == strtolower($login))
		return true;
		
   if (strtolower($admin) == strtolower($login))
	 return true;
					
   return false;
}	   

	// Guardamos el array con los usuarios 
    function guardar($user, $pas) {
        global $nicks;
		array_push($nicks, array($user, $pas));
        $total  = "<?php\n \$nicks = array (\n";
        for ($n = 0; $n < sizeof ($nicks); $n++) {
            $total = "".$total." array (\"" . addSlashes($nicks[$n][0]) . "\",\"" . addSlashes($nicks[$n][1]) . "\")";
            if ($n != sizeof ($nicks) - 1)
			  $total = "".$total.",\n";
		    else
			  $total = "".$total."\n";
        }
		
        $total = "".$total.");\n?>\n";
        $archivo = fopen("tagnicks.php", "w+");
		fwrite($archivo, $total); 
		fclose($archivo);
    } 

if (isset($enviar)) {
  $nick = trim(stripSlashes($nick));
  $nick = str_replace(" ","",$nick);
  $clave = trim(stripSlashes($clave));
  $clave = str_replace(" ","",$clave);
  if ($nick != "" && $clave != "") {
    if (!yaExiste($nick)) {
      guardar($nick, $clave);
      echo "<tr><td><font class=\"Texto\">"._REGISTERED."</font></td></tr>";
      echo "<tr><td><font class=\"Texto\"><b>&#187;</b>"._NEWNICK." <font color=\"cc0000\">$nick</font></font></td></tr>";
      echo "<tr><td><font class=\"Texto\"><b>&#187;</b>"._NEWPASS." <font color=\"cc0000\">$clave<br></font></font></td></tr>";
    } else {
        echo "<tr><td align=\"center\"><font class=\"Texto\" color=#ff0000>"._ERRORNICK."</td></tr><tr><td align=\"center\"><font class=\"Texto\"><a href=\"javascript:history.back(1)\" class=\"EnlaceMenu\">"._RETURN."</a></font></td></tr>";
      }   
  } else {
      if ($nick == "")
        echo "<div align=\"center\"><font class=\"Texto\" color=#ff0000>"._NONICK."<br></font></div>";
      if ($clave == "")
        echo "<div align=\"center\"><font class=\"Texto\" color=#ff0000>"._NOPASS."<br></font></div>";  
      echo "<div align=\"center\"><font class=\"Texto\"><a href=\"javascript:history.back(1)\" class=\"EnlaceMenu\">"._RETURN."</a></font></div>";
    }
} else {
?>
<form method="post" action="nuser.php">
   <font class="Texto"><?=_PANELREG; ?></font></td></tr>
    <tr>
      <td><font class="Texto"><?=_NICKNAME; ?></font></td>
      <td><input type="text" name="nick" value="" size="8" class="Boton" maxlength="<?php echo $maxNick; ?>"> </td>
    </tr>
    <tr>
      <td><font class="Texto"><?=_PASSWORD; ?></font></td>
      <td><input type="password" name="clave" value="" size="8" class="Boton"></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="enviar" value="<?=_ACCEPT; ?>" class="Boton"></td>
</form>
<? 
} 
?>
</tr></table></td></tr></table>
</body>
</html>