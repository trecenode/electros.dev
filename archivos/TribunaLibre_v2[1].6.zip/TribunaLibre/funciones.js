function charsleft(campo) {
  var anz = campo.value.length;
  if (anz > <?=$maxMsg; ?>) {
   campo.value = campo.value.substring(0,225);
   frei = 0;
  } else 
      frei = <?=$maxMsg; ?> -anz;
  document.forms["tag"].num.value = frei;
}

function recibirFoco() {
  document.tag.nick.focus();
  document.tag.nick.value='<?=_NICKNAME; ?>';
}

function borrarNick() {
  if (document.tag.nick.value == '<?=_NICKNAME; ?>')
    document.tag.nick.value='';
}

function borrarMensaje() {
  if (document.tag.mensaje.value == '<?=_MESSAGE; ?>')
    document.tag.mensaje.value='';
}

function borrarClave() {
  if (document.tag.clave.value == '<?=_PASSWORD; ?>')
    document.tag.clave.value='';
}
