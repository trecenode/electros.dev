<?
    // Verifica que existe un usuario
    function existeNick($login) {
        global $nicks, $admin, $activarReg;
		
	    if ($activarReg == "on") {	
          for ($n = 0; $n < sizeof($nicks); $n++)
		   if (strtolower($nicks[$n][0]) == strtolower($login))
		     return true;
	    }
		   
		if (strtolower($admin) == strtolower($login)) 
		  return true;
		  
        return false;
    }
	
    // Verifica que existe un usuario y que su password es el indicado
    function comprobarNick($login, $pas) {
        global $nicks, $admin, $pass, $activarReg;
		
		if ($activarReg == "on") {	
          for ($n = 0; $n < sizeof($nicks); $n++) {
		   if (strtolower($nicks[$n][0]) == strtolower($login))
		     if (strtolower($nicks[$n][1]) == strtolower($pas))
		       return true;		 
	      }
		}
		
		if (strtolower($admin) == strtolower($login))
		  if (strtolower($pass) == strtolower($pas))
		    return true;
			
        return false;
    }
	
	// Verifica si es el administrador
	function esAdmin($login, $pas) {
	   global $admin, $pass;
	   
	   if (strtolower($admin) == strtolower($login) && strtolower($pass) == strtolower($pas))
	     return true;
		 
	   return false; 
	}

    // Funci�n para reemplazar los c�digos por su respectivo smilie
    function reemplazarSmilies($palabra) {
	    $palabra = str_replace(":)","<img src=\"smilies/sonrisa.gif\">", $palabra);
        $palabra = str_replace(":(","<img src=\"smilies/triste.gif\">", $palabra);
        $palabra = str_replace(";)","<img src=\"smilies/ginando.gif\">", $palabra);
        $palabra = str_replace("8)","<img src=\"smilies/ojotes.gif\">", $palabra);
        $palabra = str_replace(":P","<img src=\"smilies/lengua.gif\">", $palabra);
        $palabra = str_replace(":D","<img src=\"smilies/risa.gif\">", $palabra);
        $palabra = str_replace(":cool","<img src=\"smilies/cool.gif\">", $palabra);
        $palabra = str_replace(":llorar","<img src=\"smilies/llorando.gif\">", $palabra);
        $palabra = str_replace(":enojo","<img src=\"smilies/enojado.gif\">", $palabra);
        $palabra = str_replace(":duda","<img src=\"smilies/duda.gif\">", $palabra);
        $palabra = str_replace(":bien","<img src=\"smilies/bien.gif\">", $palabra);
        $palabra = str_replace(":mal","<img src=\"smilies/mal.gif\">", $palabra);
	
	    return $palabra;
    }

    function guardarMensaje($login, $pas, $texto, $web, $ipLogin) {
        global $maximo, $existeNick, $activarIp, $activarHora, $maxMsg, $maxNick;
	    
		if (strlen($login) > $maxNick) 
		  return _NEXCEEDSLIMITCHARS;
		if (strlen($texto) > $maxMsg)
		  return _MEXCEEDSLIMITCHARS;
		  
        // No permitir etiquetas HTML, ni espacios en blanco en el nick
        $login = str_replace("<","&lt;",$login); 
        $login = str_replace(">","&gt;",$login);
        $login = reemplazarSmilies($login);
        $web = str_replace("<","&lt;",$web); 
        $web = str_replace(">","&gt;",$web);
        $web = str_replace(" ","",$web);
        $texto = str_replace("<","&lt;",$texto);
        $texto = str_replace(">","&gt;",$texto);  

        // Aqu� vamos a procesar el mensaje palabra por palabra para que ninguna 
		// sea demasiado larga y destroce el dise�o
        // Dividimos el mensaje por palabras
        $palabras = explode(" ",$texto);
        // Contamos cuantas palabras son 
        $numpalabras = count($palabras); 

        // Bucle "for" para recorrer las palabras y dividirlas si hay alguna larga
        for ($i = 0; $i < $numpalabras; $i++) {
           // Comparamos la longitud de las palabras con el m�ximo
           if (strlen($palabras[$i]) > $maximo) {
             // Dividimos las palabras que excedan el m�ximo  
             $palabras[$i] = wordwrap($palabras[$i],$maximo,"<br>",1);
           }
           $palabras[$i] = reemplazarSmilies($palabras[$i]);
        } // Fin bucle "for"

        // Unimos las palabras mediante espacios vac�os para crear el mensaje	
        $texto = implode(" ",$palabras);

        $login = stripslashes($login);
        $texto = stripslashes($texto);

        // Abrimos el archivo donde se guardan los mensajes l�nea a l�nea
        $archivo = file("tag.txt");
        // Contamos las l�neas que tiene el archivo
        $lineas = count($archivo);
        // Fecha en la que se envi� el mensaje
        $fecha = Date("d.m.y")." "._AT." ".Date("H:i:s");

        if ($existeNick == "true") {
          if (esAdmin($login, $pas))
              $color = "ff0000";
	        else
              $color = "990000";	 
        } else
            $color = "000080";  
 
        // Unimos el mensaje a etiquetas HTML y miramos si el usuario ha introducido una url
        if ($web != "" && $web != "http://") 
          $nuevo = "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
  
        $nuevo .= "<font color=#".$color." ";

        if ($activarIp == "on")
          $nuevo .= "title=\"".$ipLogin."\"";
  
        $nuevo .= "><b>".$login."</b></font>";

        if ($web != "" && $web != "http://") 
          $nuevo .= "</i></a>";
  
        $nuevo .= "<br> ".$texto."";

        if ($activarHora == "on")
          $nuevo .= "<br><font color=\"#cc0000\">".$fecha."</font>%%";
        else
          $nuevo .= "%%";

        // No permitir que env�en "%%" (es el separador de los mensajes)
        if (eregi("%%",$login) || eregi("%%",$texto)) {
          return _NOSEND." %%";
        } else {
        // Abrimos el fichero con los mensajes
        $archivo = fopen("tag.txt","a");
        // A�adimos el nuevo mensaje a los antiguos 
        fputs($archivo,$nuevo);
        // Cerramos el archivo
        fclose($archivo);
        }
		
		return "";
    }

?>