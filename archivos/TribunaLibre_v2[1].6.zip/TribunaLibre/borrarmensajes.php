<? 
session_name('admin');
session_start();

include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");

?>	
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body><table border=0 height=100% width="100%" style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc" cellpadding="0" cellspacing="0"><tr><td align="center" class="Texto" style="border-bottom: 1px solid <? echo $bordetabla; ?>">
<?
if ($HTTP_SESSION_VARS['esAdmin'] == "true") {
if ($aceptar) {
  if (isset($mensaje)) {
    $abrir = file("tag.txt","r");
	$lineas = count($abrir);
    for ($i = 0; $i < $lineas; $i++) {
 	   $total .= $abrir[$i]; 
    }
    
    $mensajes = explode("%%",$total);
    $nummensajes = count($mensajes)-1;
	
    for ($i = 0; $i < $nummensajes; $i++) {	  
      if ($mensaje[$i] != "on") {
        $nuevo .= "".$mensajes[$i]."%%";
      }
    }
    
    $abrir2 = fopen("tag.txt","w");
              fputs($abrir2,$nuevo);
              fclose($abrir2);
	echo ""._ERASEDMESSAGES."<br><a href=admintag.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a>"; 
	} else {
	    echo ""._NOSELECTEDMESSAGES."<br><a href=borrarmensajes.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a>";
	}
} else if ($todos) {
      $abrir = fopen("tag.txt","w");
               fputs($abrir,"");
               fclose($abrir);
			   echo ""._ALLMESSAGESERASED."<br><a href=admintag.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a>";
} else if ($ayuda) 
         include("ayuda.html");
	   else {
  
?>
<form name="formborrar" method="post" action="<?=$PHP_SELF;?>"><table cellpadding="2"><tr><td class="Texto"><font color="#cc0000"><?=_ERASEMESSAGES; ?></font></td></tr></table></td></tr><tr><td height="100%" valign="top"><table border="0" cellpadding="0" cellspacing="0" width="100%">
<?

    $abrir = file("tag.txt","r");
	$lineas = count($abrir);
    for ($i = 0; $i < $lineas; $i++) {
 	   $total .= $abrir[$i]; 
    }
    
    $mensajes = explode("%%",$total);
    $nummensajes = count($mensajes)-1;
    
	for ($i= 0; $i < $nummensajes; $i++) {
       echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid ".$bordetabla."\"><INPUT TYPE=checkbox name=mensaje[".$i."]>$mensajes[$i]</td></tr>";
     
    }

?></table></td></tr><tr><td align="center"><table cellpadding="2"><tr><td>
<input name="aceptar" type="submit" value="<?=_RESET; ?>" class="Boton">&nbsp;<input name="todos" type="submit" value="<?=_ALL; ?>" class="Boton">&nbsp;<input name="ayuda" type="submit" value="<?=_HELP; ?>" class="Boton">
</td></tr></table></td></tr><tr><td align="center"><a href="admintag.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td></tr></td></tr></form></table>
<?  
}
} else
  echo "<font class=\"Texto\"><font color=\"#cc0000\">"._NOACCESS."</font>";

?>
</body>
</html>