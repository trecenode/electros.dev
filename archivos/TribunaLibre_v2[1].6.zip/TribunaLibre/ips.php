<?
 $ips = array(); 
?>