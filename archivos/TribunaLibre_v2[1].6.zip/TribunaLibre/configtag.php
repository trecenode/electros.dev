<? 
 $admin = "Demo"; 
 $pass = "demo"; 
 $maximo = 14; 
 $numMensajes = "50"; 
 $maxNick = 14; 
 $maxMsg = 160; 
 $activarUrl = "on"; 
 $activarReg = "on"; 
 $activarIp = "on"; 
 $activarHora = "on"; 
 $activarLogo = "on"; 
 $langactual = "spanish"; 
 $activarTiempo = "on"; 
 $tiempo = "10"; 
?>