<? 
 $fondotabla = "#D5E4E9"; 
 $bordetabla = "#C4D3D8"; 
 $bordecampo = "#CCCCCC"; 
 $fondocampo = "#DDDDDD"; 
 $cimpar = "#E6F5FA"; 
 $cpar = "#D5E4E9"; 
 ?>