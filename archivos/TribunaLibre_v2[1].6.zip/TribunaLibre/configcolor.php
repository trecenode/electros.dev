<? 
session_name('admin');
session_start();

include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");

  // Desde aqu� concatenamos toda la informaci�n obtenida en el formulario de configuraci�n y la guardamos en el        fichero
  function guardarConfiguracion() {
     global $fondo, $borde, $fondoc, $bordec, $impar, $par;
     $nuevo = "<? \n \$fondotabla = \"".$fondo."\"; \n \$bordetabla = \"".$borde."\"; \n \$bordecampo = \"".$bordec."\"; \n \$fondocampo = \"".$fondoc."\"; \n \$cimpar = \"".$impar."\"; \n \$cpar = \"".$par."\"; \n ?>";

     $fichero = fopen("colores.php","w");
     fputs($fichero,$nuevo);
     fclose($fichero);
     echo "<font color=\"#cc0000\">"._SAVEDCONFIG."";
  }

?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body><table border=0 height=100% width="100%" style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc"><tr><td align="center" class="Texto">
<?
if ($HTTP_SESSION_VARS['esAdmin'] == "true") {
if ($aceptar) {
  if ($fondo != "" && $borde != "" && $bordec != "" && $fondoc != "" && $impar != "" && $par != "")
    guardarConfiguracion();
  else 
    echo "<font color=\"cc0000\">"._NOTEXT."<br></font><a href=\"configcolor.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else if ($ayuda) {
         include("ayuda.html");
	   } else {
  
?>
<form name="formcolor" method="post" action="<?=$PHP_SELF;?>"><table border="0" cellpadding="0" cellspacing="2" width="100%"><tr><td class="Texto" colspan="2" align="center"><font color="#cc0000"><?=_CONFIGCOLORS; ?></font></td></tr><tr><td class="Texto" colspan="2" align="center"></td></tr><tr><td class="Texto">
	<?=_BGTABLE; ?>: </td><td align="right"><input type="text" name="fondo" size="8" value="<? echo $fondotabla; ?>" class="Boton"></td></tr><tr><td class="Texto">
	<?=_BORDERTABLE; ?>: </td><td align="right"><input type="text" name="borde" size="8" value="<? echo $bordetabla; ?>" class="Boton"></td></tr><tr><td class="Texto">
	<?=_ODDCELL; ?>: </td><td align="right"><input type="text" name="impar" size="8" value="<? echo $cimpar; ?>" class="Boton"></td></tr><tr><td class="Texto">
	<?=_PARCELL; ?>: </td><td align="right"><input type="text" name="par" size="8" value="<? echo $cpar; ?>" class="Boton"></td></tr><tr><td class="Texto">
	<?=_BGTEXTFIELD; ?>: </td><td align="right"><input type="text" name="fondoc" size="8" value="<? echo $fondocampo; ?>" class="Boton"></td></tr><tr><td class="Texto">
	<?=_BORDERTEXTFIELD; ?>: </td><td align="right"><input type="text" name="bordec" size="8" value="<? echo $bordecampo; ?>" class="Boton"></td></tr></table>
<input name="aceptar" type="submit" value="<?=_ACCEPT; ?>" class="Boton">&nbsp;<input name="ayuda" type="submit" value="<?=_HELP; ?>" class="Boton">
</form></td></tr>
<tr><td colspan="2" align="center"><a href="admintag.php?<? echo session_name()."=".session_id() ?>" class=EnlaceMenu><?=_RETURN; ?></a>
</td></tr></table>
<?  
}
} else
  echo "<font class=\"Texto\"><font color=\"#cc0000\">"._NOACCESS."</font></td></tr></table>";

?></td></tr></table>
</body>
</html>