<? 
session_name('admin');
session_start();

include("colores.php");
include("configtag.php"); 
include("language/lang-".$langactual.".php");
?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body>
<table width="100%" height="100%" style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc">
<tr><td align="center">
<table border=0>
<tr><td class="Texto" align="center"><a href="admintag.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_ADMINISTRATOR; ?></a></td></tr>
<? if ($activarReg == "on") { ?>
<tr><td align="center"><a href="nuser.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_USERSREGISTER; ?></a></td></tr>
<tr><td align="center"><a href="veruser.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_USERS; ?></a></td></tr>
<? } ?>
<tr><td align="center"><a href="smilies.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_SMILIES; ?></a></td></tr>
<tr><td align="center"><a href="tag.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td></tr></table></td></tr></table>
</body>
</html>