<?
include("configtag.php");
include("language/lang-".$langactual.".php");
?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body>
<table width="100%" height="100%" bgcolor="#cccccc"><tr><td align="center" valign="top"><table border="0"><tr>
<td class="Texto" align="center"><font color="#cc0000"><?=_CONFIGHELP; ?></font></td></tr>
<tr><td class="Texto" align="center"></td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_CNICK; ?></font> <?=_ECNICK; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_CWORD; ?>:</font> <?=_ECWORD; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_CMESSAGE; ?>:</font> <?=_ECMESSAGE; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_SHOWMESSAGES; ?>:</font> <?=_ESHOWMESSAGES; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_REGNICK; ?>:</font> <?=_EREGNICK; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_URLNICK; ?>:</font> <?=_EURLNICK; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_SHOWIP; ?>:</font> <?=_ESHOWIP; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_SHOWDATEHOUR; ?>:</font> <?=_ESHOWDATEHOUR; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_SHOWLOGO; ?>:</font> <?=_ESHOWLOGO; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_REFRESH; ?>:</font> <?=_EREFRESH; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_LOGIN; ?>:</font> <?=_ELOGIN; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_PASSWORD; ?>:</font> >?=_EPASSWORD; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000">� <?=_CONFIGCOLOR; ?></td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_BGTABLE; ?>:</font> <?=_EBGTABLE; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_BORDERTABLE; ?>:</font> <?=_EBORDERTABLE; ?>. </td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_ODDCELL; ?>:</font> <?=_EODDCELL; ?>. </td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_PARCELL; ?>:</font> <?=_EPARCELL; ?>. </td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_BGTEXTFIELD; ?>:</font> <?=_EBGTEXTFIELD; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000"><?=_BORDERTEXTFIELD; ?>:</font> <?=_EBORDERTEXTFIELD; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000">� <?=_ERASEMESSAGES; ?></td></tr>
<tr><td class="Texto"><?=_EERASEMESSAGES; ?>.</td></tr>
<tr><td class="Texto"><font color="#cc0000">� <?=_CONTROLIP; ?></td></tr>
<tr><td class="Texto"><?=_ECONTROLIP; ?>.</td></tr>
<tr><td></td></tr>
<tr><td class="Texto" align="center"><a href="javascript:history.back(1)" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr></table></td></tr></table>
</body>
</html>