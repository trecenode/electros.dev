<? 
session_name('admin');
session_start();

include("configtag.php");
include("colores.php");
include("ips.php");
include("language/lang-".$langactual.".php");

    // Guardamos el array con las ips 
	function guardar($array_ips) {		
        $total  = "<?\n \$ips = array(";
        for ($n = 0; $n < sizeof ($array_ips); $n++) {
            $total = "".$total."\"".addSlashes($array_ips[$n])."\"";
            if ($n != sizeof($array_ips) - 1)
			  $total = "".$total.",";
		    else
			  $total = "".$total."";
        }
		
        $total = "".$total.");\n?>\n";
        $archivo = fopen("ips.php", "w+");
		fwrite($archivo, $total); 
		fclose($archivo);
		
    } 

?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body>
<table border=0 height=100% width="100%" style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc"><tr><td align="center" class="Texto">
<?
if ($HTTP_SESSION_VARS['esAdmin'] == "true") {
if (isset($banear)) {
  if ($ipbanear != "") {
    array_push($ips, $ipbanear);
    guardar($ips);
	echo "<div align=center>"._BANIP."<br><a href=admintag.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a></div>";
  } else 
    echo "<font class=\"Texto\">"._NOIP."<br></font><a href=\"banear.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else if (isset($borrar)) {
if ($ips[0] == "")
  echo "<font class=\"Texto\">"._NOBANIP."<br></font><a href=\"banear.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {
if (!isset($ip)) {
  echo "<font class=\"Texto\">"._NOSELECTEDIP."<br></font><a href=\"banear.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
    $nips = array();
    for ($i = 0; $i < sizeof($ips); $i++) {	  
      if ($ip[$i] != "on") {
        array_push($nips,$ips[$i]);
      }
    }
	
	guardar($nips);

	echo ""._ERASEDIP."<br><a href=admintag.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a>";

        }
}
} else if (isset($todas)) {
        if ($ips[0] == "")
          echo "<font class=\"Texto\">"._NOBANIP."<br></font><a href=\"banear.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
           $abrir = fopen("ips.php","w");
           fputs($abrir,"<?\n \$ips = array(); \n?>");
           fclose($abrir);
	       echo ""._ALLIPERASED."<br><a href=admintag.php?session_name()=session_id() class=EnlaceMenu>"._RETURN."</a>";
        }
} else if (isset($ayuda)) {
         include("ayuda.html");
	   } else {
  
?>
<table border="0" cellpadding="0" cellspacing="0">
<form name="formcolor" method="post" action="<?=$PHP_SELF;?>">
<tr><td class="Texto" align="center"><font color="#cc0000"><?=_CONTROLIP; ?></font></td></tr>
<tr><td class="Texto" align="center"></td></tr>
<tr><td class="Texto" align="center"><?=_IP; ?>: <input type="text" name="ipbanear" size="20" value="" class="Boton"></td></tr>
<tr><td class="Texto" align="center"></td></tr>
<tr><td class="Texto" align="center"><input name="banear" type="submit" value="Banear" class="Boton"></td></tr>
<tr><td class="Texto" align="center">&nbsp;</td></tr>
<tr><td class="Texto" align="center"><?=_BANIPS; ?></td></tr>
<tr><td class="Texto" colspan="2">
<?
if ($ips[0] == "")
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table>";
for ($n = 0; $n < sizeof($ips); $n++) {
   echo "<tr><td class=\"Texto\"><INPUT TYPE=checkbox name=ip[".$n."]>$ips[$n]</td></tr>";
   }
echo "</table>";
}
?>  
</td></tr><tr><td><table cellpadding="1" cellspacing="0"><tr><td><input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td><td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td><td><input name="ayuda" type="submit" value="<?=_HELP; ?>" class="Boton"></td></tr></table></td></tr></form><tr><td colspan="2" align="center"><a href="admintag.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td></tr></table>
<? 
} 
} else
  echo "<font class=\"Texto\"><font color=\"#cc0000\">"._NOACCESS."</font>";

?>
</td></tr></table>
</body>
</html>