<?php

//ftag.php
define("_SEND", "Enviar");
define("_WEBDESCRIPTION", "Recursos php gratuitos para webmasters");
define("_NICKNAME", "Nick");
define("_MESSAGE", "mensaje");
define("_PASSWORD", "Password");
define("_RESET", "Borrar");
define("_OPTIONS", "Opciones");
define("_UNKNOWIP", "IP desconocida");
define("_NOWRITE", "No puedes escribir mensajes");
define("_INCORRECTPASS", "Password incorrecta");
define("_NONICK", "Nick vac�o");
define("_NOMESSAGE", "Mensaje vac�o");

//nuser.php
define("_REGISTERED", "Registro finalizado con �xito, ya puedes enviar mensajes con tu nick registrado.");
define("_NEWNICK", "Tu nick es");
define("_NEWPASS", "Tu password es");
define("_ERRORNICK", "Este nick ya est� registrado");
define("_RETURN", "volver");
define("_NOPASS", "Password vac�o");
define("_PANELREG", "Panel de registro");
define("_ACCEPT", "Aceptar");

//admintag.php
define("_SAVEDCONFIG", "Configuraci�n guardada</font><br>Debes actualizar la p�gina para ver los cambios");
define("_NOADMIN", "Ahora ya no eres el administrador");
define("_NOTEXT", "Has dejado alg�n campo vac�o");
define("_CONFIG", "Configuraci�n");
define("_CNICK", "Caracteres Nick");
define("_CWORD", "Caracteres palabra");
define("_CMESSAGE", "Caracteres mensaje");
define("_SHOWMESSAGES", "Mostrar mensajes");
define("_REGNICK", "Registro nicks");
define("_URLNICK", "Url Nick");
define("_SHOWIP", "Mostrar ip");
define("_SHOWDATEHOUR", "Mostrar fecha y hora");
define("_SHOWLOGO", "Mostrar logo");
define("_REFRESH", "Tiempo refresco");
define("_SEG", "Segundos");
define("_CONFIGCOLOR", "Configurar color");
define("_CONTROLIP", "Control IP's");
define("_EMPTY", "No hay mensajes");
define("_ERASE", "Borrar mensajes");
define("_LOGIN", "Login");
define("_HELP", "Ayuda");
define("_LOGOUT", "logout/salir");
define("_PANELIDEN", "Panel de identificaci�n");
define("_INCORRECTD", "Datos incorrectos");
define("_LANGUAGE", "Lenguaje");

//banear.php
define("_BANIP", "IP baneada");
define("_NOIP", "No has introducido la IP");
define("_NOBANIP", "No hay IP's baneadas");
define("_NOSELECTEDIP", "No has seleccionado ninguna IP");
define("_ERASEDIP", "IP borrada");
define("_ALLIPERASED", "Todas las IP's han sido borradas");
define("_IP", "IP");
define("_BANIPS", "IP's baneadas");
define("_NONE", "Ninguna");
define("_ALL", "Todas");
define("_NOACCESS", "No tienes acceso a esta p�gina");

//borrarmensajes.php
define("_ERASEDMESSAGES", "Mensajes borrados");
define("_NOSELECTEDMESSAGES", "No has marcado ning�n mensaje");
define("_ALLMESSAGESERASED", "Todos los mensajes han sido borrados");
define("_ERASEMESSAGES", "Borrar mensajes");

//configcolor.php
define("_CONFIGCOLORS" ,"Configuraci�n colores");
define("_BGTABLE", "Fondo tabla");
define("_BORDERTABLE", "Borde tabla");
define("_ODDCELL", "Celda impar");
define("_PARCELL", "Celda par");
define("_BGTEXTFIELD", "Fondo campo de texto");
define("_BORDERTEXTFIELD", "Borde campo de texto");

//funciones.php
define("_NEXCEEDSLIMITCHARS", "El nick excede el l�mite de caracteres");
define("_MEXCEEDSLIMITCHARS", "El mensaje excede el l�mite de caracteres");
define("_AT", "a las");
define("_NOSEND", "No puedes enviar");

//opciones.php
define("_ADMINISTRATOR", "Administrador");
define("_USERSREGISTER", "Registrarme");
define("_USERS", "Usuarios");
define("_SMILIES", "Smilies");

//veruser.php
define("_REGISTEREDUSERS", "Usuarios registrados");

//ayuda.php
define("_CONFIGHELP", "Ayuda para configuraci�n");
define("_ECNICK", "n�mero de caracteres que tendr� como m�ximo el nick");
define("_ECWORD", "n�mero de caracteres que tendr�n como m�ximo las palabras del mensaje");
define("_ECMESSAGE", "n�mero de caracteres que tendr� como m�ximo un mensaje");
define("_ESHOWMESSAGES", "n�mero de mensajes que se mostrar�n. Si quieres que se muestren todos los mensajes introduce un 0");
define("_EREGNICK", "opci�n para permitir el registro de usuarios");
define("_EURLNICK", "opci�n para permitir url's en los nicks");
define("_ESHOWIP", "opci�n para ver la ip del posteador al colocar el rat�n sobre su nick");
define("_ESHOWDATEHOUR", "mostrar la fecha y la hora del mensaje");
define("_ESHOWLOGO", "mostrar el logo superior de Tribuna Libre");
define("_EREFRESH", "opci�n para refrescar el panel de los mensajes. Si se activa esta opci�n habr� que introducir en el campo el tiempo en <font color=\"#cc0000\">Segundos</font> que debe trascurrir entre cada actualizaci�n");
define("_ECONTROLIP", "Para banear una IP debes introducir dicha IP en el campo de texto correspondiente y pulsar el bot�n \"Banear\". Si quieres borrar una IP de la lista de IP's baneadas selecci�nala marcando la casilla que aparece a su izquierda y presiona el bot�n \"Borrar\". Si quieres borrarlas todas haz clic sobre el bot�n \"Todas\"");
define("_EERASEMESSAGES", "Para borrar un mensaje debes marcar la casilla que aparece a la izquierda de cada mensaje y pulsar el bot�n \"Borrar\". Si quieres borrarlos todos haz clic sobre el bot�n \"Todos\""); 
define("_EBORDERTEXTFIELD", "color del borde de los campos del formulario (nick, mensaje, url)");
define("_EBGTEXTFIELD", "color del fondo de los campos de texto del formulario");
define("_EPARCELL", "color de la celda par de la tabla de mensajes");
define("_EODDCELL", "color de la celda impar de la tabla de mensajes");
define("_EBORDERTABLE", "color del borde de las tablas");
define("_EBGTABLE", "color del fondo de la tabla donde se visualizan los mensajes");
define("_ELOGIN", "tu nick como administrador. Tambi�n sirve para enviar mensajes");
define("_EPASSWORD", "tu password como administrador");

?>