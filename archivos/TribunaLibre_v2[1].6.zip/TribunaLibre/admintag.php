<?
session_name('admin');
session_start();

include("configtag.php"); 
include("colores.php"); 
include("language/lang-".$langactual.".php");

  // Desde aqu� concatenamos toda la informaci�n obtenida en 
  // el formulario de configuraci�n y la guardamos en el fichero
  function guardarConfiguracion() {
     global $loginAdmin, $passAdmin, $valorPalabra, $valorMensajes, $valorNick, 
	 $maxPalabra, $url, $ip, $hora, $logo, $refresh, $valorTiempo, $registro, $langactual, $lenguaje;
     $nuevo = "<? \n \$admin = \"".$loginAdmin.
	 "\"; \n \$pass = \"".$passAdmin."\"; \n \$maximo = ".$valorPalabra.
	 "; \n \$numMensajes = \"".$valorMensajes."\"; \n \$maxNick = ".$valorNick.
	 "; \n \$maxMsg = ".$maxPalabra."; \n";
	 
     if (isset($url)) 
       $nuevo .= " \$activarUrl = \"on\"; \n";
	 else
	   $nuevo .= " \$activarUrl = \"off\"; \n"; 
	    
	 if (isset($registro)) 
       $nuevo .= " \$activarReg = \"on\"; \n";
	
     if (isset($ip))
       $nuevo .= " \$activarIp = \"on\"; \n";
	   
     if (isset($hora))
       $nuevo .= " \$activarHora = \"on\"; \n";
	   
     if (isset($logo))
       $nuevo .= " \$activarLogo = \"on\"; \n";
	 else
	   $nuevo .= " \$activarLogo = \"off\"; \n";  
	   
	 $nuevo .=  " \$langactual = \"".$lenguaje."\"; \n"; 
	   
	 if (isset($refresh)) {
	   $nuevo .= " \$activarTiempo = \"".$refresh."\"; \n";
	   $nuevo .= " \$tiempo = \"".$valorTiempo."\"; \n";
	   }
	   
     $nuevo .= "?>";

     $fichero = fopen("configtag.php","w");
     fputs($fichero,$nuevo);
     fclose($fichero);
     echo "<font class=\"Texto\"><font color=\"#cc0000\">"._SAVEDCONFIG."</font>";
  }

?>
<html> 
<head> 
   <title>Tribuna Libre v2.6</title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
</head>
<body><table border=0 height=100% width="100%" style="border: 1px solid <? echo $bordetabla ?>" bgcolor="#cccccc"><tr><td align="center">
<?
if (($login == strtolower($admin) && $password == strtolower($pass)) || ($HTTP_SESSION_VARS['esAdmin'] == "true")) {
        $esAdmin = "true";
		  
if ($id == logout) { 
    session_unset();
	echo "<font class=\"Texto\">"._NOADMIN."<br></font><a href=\"tag.php\" class=\"EnlaceMenu\">"._RETURN."</a>";
  } else if ($aceptar) {
           if ($loginAdmin != "" && $passAdmin != "" && $valorPalabra != "" && $valorMensajes != "" && $valorNick != "" && $maxPalabra != "" && (($refresh && $valorTiempo != "") || !isset($refresh)))
             guardarConfiguracion();
           else 
             echo "<font class=\"Texto\">"._NOTEXT."<br></font><a href=\"admintag.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
         } else if (isset($ayuda)) 
                  include("ayuda.html");
				else { 
?>
<font class="Texto">
<form name="form" method="post" action="admintag.php?<? echo session_name()."=".session_id() ?>"><table border="0" cellpadding="0" cellspacing="2" width="100%"><tr><td class="Texto" colspan="2" align="center"><font color="#cc0000"><?=_CONFIG; ?></font></td></tr><tr><td class="Texto" colspan="2" align="center"></td></tr><tr><td class="Texto">
	<?=_CNICK; ?>: </td><td align="right"><input type="text" name="valorNick" size="2" value="<?php echo $maxNick; ?>" class="Boton"></td></tr><tr><td class="Texto">
    <?=_CWORD; ?>: </td><td align="right"><input type="text" name="valorPalabra" size="2" value="<?php echo $maximo; ?>" class="Boton"></td></tr><tr><td class="Texto">
    <?=_CMESSAGE; ?>: </td><td align="right"><input type="text" name="maxPalabra" size="2" value="<?php echo $maxMsg; ?>" class="Boton"></td></tr><tr><td class="Texto">
    <?=_SHOWMESSAGES; ?>: </td><td align="right"><input type="text" name="valorMensajes" size="2" value="<?php echo $numMensajes; ?>" class="Boton"></td></tr><tr><td colspan="2"  class="Texto" align="left"><input type="checkbox" name="registro" <?php if($activarReg == "on") { echo "checked"; } ?>>&nbsp;<?=_REGNICK; ?></td></tr><tr><td colspan="2"  class="Texto" align="left"><input type="checkbox" name="url" <?php if($activarUrl == "on") { echo "checked"; } ?>>&nbsp;<?=_URLNICK; ?> </td></tr><tr><td colspan="2"  class="Texto" align="left"><input type="checkbox" name="ip" <?php if($activarIp == "on") { echo "checked"; } ?>>&nbsp;<?=_SHOWIP; ?> </td></tr><tr><td colspan="2"  class="Texto" align="left"><input type="checkbox" name="hora" <?php if($activarHora == "on") { echo "checked"; } ?>>&nbsp;<?=_SHOWDATEHOUR; ?> </td></tr><tr><td colspan="2"  class="Texto" align="left"><input type="checkbox" name="logo" <?php if($activarLogo == "on") { echo "checked"; } ?>>&nbsp;<?=_SHOWLOGO; ?></td></tr><tr><td class="Texto" align="left" colspan="2"><input type="checkbox" name="refresh" <?php if($activarTiempo == "on") { echo "checked"; } ?>>&nbsp;<?=_REFRESH; ?> </td></tr><tr><td class="Texto" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=_SEG; ?>:</td><td align="right"><input type="text" name="valorTiempo" size="2" value="<?php echo $tiempo; ?>" class="Boton"></td></tr>
<tr><td class="Texto" colspan="2"><?=_LANGUAGE; ?>:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="lenguaje" class="Select">
<?
    $directorio = opendir("language");
    while ($file = readdir($directorio)) {
	if (preg_match("/^lang\-(.+)\.php/", $file, $matches)) {
	    $langFound = $matches[1];
	    $langlista .= "$langFound ";
	}
    }
    closedir($directorio);
    $langlista = explode(" ", $langlista);
    sort($langlista);
    for ($i = 0; $i < sizeof($langlista); $i ++) {
	if($langlista[$i]!="") {
	    $content .= "<option value=\"$langlista[$i]\" ";
	    if($langlista[$i] == $langactual) $content .= " selected";
	    $content .= ">".ucfirst($langlista[$i])."</option>\n";
	}
    }
	
	echo $content;
	?>
</select></td>
</tr>
<tr><td class="Texto" colspan="2"><a href="configColor.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_CONFIGCOLOR; ?></a></td></tr><tr><td class="Texto" colspan="2"><a href="banear.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_CONTROLIP; ?></a></td></tr><tr><td class="Texto" colspan="2"><? if (filesize("tag.txt") == 0) echo _EMPTY; else echo "<A href=borrarmensajes.php?".session_name()."=".session_id()." class=\"EnlaceMenu\">"._ERASE."</a>"; ?></td></tr><tr><td class="Texto" colspan="2" style="border-top: 1px solid <? echo $bordetabla ?>">&nbsp;</td></tr><tr><td class="Texto">
    <?=_LOGIN; ?>: </td><td><input type="text" name="loginAdmin" size="5" value="<?php echo $admin; ?>" class="Boton"></td></tr><tr><td class="Texto">
    <?=_PASSWORD; ?>: </td><td><input type="password" name="passAdmin" size="5" value="<?php echo $pass; ?>" class="Boton"></td></tr><tr><td class="Texto" colspan="2">&nbsp;</td></tr></table>
<input name="aceptar" type="submit" value="<?=_ACCEPT; ?>" class="Boton">&nbsp;<input name="ayuda" type="submit" value="<?=_HELP; ?>" class="Boton">
</form>
</font>
<table border=0 width="100%" cellpadding=0 cellspacing=0><tr><td align="right"><a href="admintag.php?id=logout" class="EnlaceMenu"><?=_LOGOUT; ?></td></tr></table>
<?
}
} else if (!isset($login) && !isset($password)) {
?>

   <form method="post" action="admintag.php?<? echo session_name()."=".session_id() ?>" name="formAdmin">
   <div align="center"><font class="Texto"><?=_PANELIDEN; ?></font></div>
    <table border = 0 cellpadding=2 cellspacing=2>
    <tr>
      <td><font class="Texto"><?=_LOGIN; ?></font></td>
      <td><input type="text" name="login" size="8" class="Boton"></td>
    </tr>
    <tr>
      <td><font class="Texto"><?=_PASSWORD; ?></font></td>
      <td><input type="password" name="password" size="8" class="Boton"></td>
    </tr>
    <tr>
      <td colspan="2" align =center bgcolor="#cccccc">
        <input type = "submit" value = "<?=_ACCEPT; ?>" class="Boton">
      </td>
    </tr>
	</form>
<?
} else {
?>
<table border=0 cellpadding=0 cellspacing=0><tr><td align="center" class="Texto"><?=_INCORRECTD; ?></td></tr><tr><td align="center" class="Texto"><a href="javascript:history.back(1)" class="EnlaceMenu"><?=_RETURN; ?></a></td></tr></table>
<?
  }
?>
</td></tr></table>
</body>
</html>