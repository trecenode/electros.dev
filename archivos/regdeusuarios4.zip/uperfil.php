<?
include("ulogin.php") ;
?>
<?
include("config.php") ;
$resp = mysql_query("select * from usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if($editarconfirmacion) {
echo "Tus datos han sido editados con �xito. Haz click <a href=index.php>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
// Si el usuario no puso la edad, esta tiene un valor de cero en la base de datos
// Para no mostrar el cero en la edad se hace lo siguiente
if($datos[edad] == 0) { $edad = "" ; }
else { $edad = $datos[edad] ; }
// En la base de datos se guarda el sexo masculino y femenino con 2 valores, 0 y 1 respectivamente,
// si el usuario selecciono en su perfil sexo femenino (1), en el formulario de editar la opci�n debe
// aparecer seleccionada
if($datos[sexo] == 1) { $sexo = " selected" ; }
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
echo "
<p class=titulo>Perfil
<p><b>Usuario desde el:</b> $fecha
<p>En esta secci�n puedes editar tus datos de registro. Los campos con un asterisco (*) son obligatorios.
<script>
function revisar() {
if(formulario.pass.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res.') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.descripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form method=post action=ueditar.php>
<b>* Nick:</b><br>
<input type=text name=nick maxlength=20 value=\"$datos[nick]\" class=form style=\"color: #757575\" readonly><br>
<b>* Contrase�a:</b><br>
<input type=password name=contrasena maxlength=20 value=\"$datos[contrasena]\" class=form><br>
<b>* Email:</b><br>
<input type=text name=email maxlength=40 value=\"$datos[email]\" class=form><br>
<b>Pa�s:</b><br>
<input type=text name=pais maxlength=20 value=\"$datos[pais]\" class=form><br>
<b>Edad:</b><br>
<input type=text name=edad maxlength=2 size=3 value=\"$edad\" class=form><br>
<b>Sexo:</b><br>
<select name=sexo class=form>
<option value=0>Masculino
<option value=1$sexo>Femenino
</select><br>
<b>Descripci�n:</b><br>
<textarea name=descripcion cols=30 rows=5 class=form style=\"font-family: verdana\">$datos[descripcion]</textarea><br><br>
<input type=submit name=editar value=Editar class=form>
</form>
" ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>