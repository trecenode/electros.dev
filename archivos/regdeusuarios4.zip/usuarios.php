<?
include("config.php") ;
echo "
<p class=titulo>Usuarios
" ;
if($u) {
$resp = mysql_query("select * from usuarios where id='$u'") ;
$datos = mysql_fetch_array($resp) ;
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
if($datos[edad] == 0) { $edad = "" ; }
else { $edad = $datos[edad] ; }
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
echo "
<p><b>Usuario desde el:</b> $fecha
<p>
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr>
<td><b>Nick:</b></td>
<td>$datos[nick]</td>
</tr>
<tr>
<td><b>Pa�s:</b></td>
<td>$datos[pais]</td>
</tr>
<tr>
<td><b>Edad:</b></td>
<td>$edad</td>
</tr>
<tr>
<td><b>Sexo:</b></td>
<td>$sexotexto[$sexonumero]</td>
</tr>
<tr>
<td><b>Descripci�n:</b></td>
<td>$datos[descripcion]</td>
</tr>
</table>
<p><a href=usuarios.php>Regresar a Usuarios</a>
" ;
}
else {
$resp = mysql_query("select id from usuarios") ;
$usuarios = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 25 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select id,nick,sexo,pais from usuarios order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
echo "
<p><b>Usuarios registrados en la web:</b> $usuarios
<p>
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr bgcolor=#252525>
<td width=50%><b>Nick</b></td>
<td width=25%><b>Sexo</b></td>
<td width=25%><b>Pa�s</b></td>
</tr>
" ;
while($datos = mysql_fetch_array($resp)) {
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
echo "
<tr>
<td><a href=usuarios.php?u=$datos[id]>$datos[nick]</a></td>
<td>$sexotexto[$sexonumero]</td>
<td>$datos[pais]</td>
</tr>
" ;
}
echo "
</table>
" ;
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=?ver=usuarios>Anteriores $mostrar usuarios</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=?ver=usuarios&desde=$anteriores>Anteriores $mostrar usuarios</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $usuarios) {
echo "<a href=?ver=usuarios&desde=$desde>Siguientes $mostrar usuarios</a>" ;
}
}
?>