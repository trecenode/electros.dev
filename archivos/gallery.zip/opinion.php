<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #FFE7B3 ;
scrollbar-darkshadow-color: #FFAE06 ;
scrollbar-shadow-color: #FFB722 ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #FFAE06 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #FFAE06 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #B97C00 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #A46F00 ;
}
/* Tablas del foro */
.tabla_principal {
border: #FFAE06 0 solid ;
}
.tabla_titulo {
border-left: #FFB722 2 solid ; border-top: #FFB722 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFAE06 ;
}
.tabla_subtitulo {
border-left: #FFCF6A 2 solid ; border-top: #FFCF6A 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFC64F ;
}
.tabla_mensaje {
border-left: #FFE7B3 2 solid ; border-top: #FFE7B3 2 solid ; border-right: #FFCF6A 2 solid ; border-bottom: #FFCF6A 2 solid ;
background: #FFDA8C ;
}
/* Formulario */
.form {
border: #FFAE06 1 solid ;
background: #FFCF6A ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
<div align="center"><br> <img src="<? echo $a ?>" > <br>
  <br>
  <a href="index.php">Atr�s</a> <br>
  <br>
</div>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td height='7' colspan="2" class="tabla_subtitulo"><b><? echo $a ?>&nbsp;</b></td>
  </tr>
  <tr> 
    <td height='7' class="tabla_mensaje"><div align="left"><b>Nombre</b></div></td>
    <td class="tabla_mensaje"><b>Opinion</b></td>
  </tr>
  <?
$elemento = $a ;  
$file = "estadisticas/$elemento.txt"; 
//Se tramita el formulario y se guardan los nuevos datos.
if(!empty($opinion))
{
$fichero = fopen($file, "a");
fwrite($fichero, "$nombre////$opinion\n");
fclose($fichero);
}
//Se inicia el proceso de impresion de los datos
if(file_exists($file)&&is_file($file))
{
$fichero = fopen($file, "r");
//Se extraen todas las lineas.
while(!feof($fichero))
{
$cadena = fgets($fichero, 4096);
list($nom, $men)=split('////', $cadena);
//Se elimina la lectura de los \n \r
if(!empty($cadena)){
?>
  <tr> 
    <td height='7' class="tabla_mensaje"><div align="left">
        <? echo $nom ?>
        </div></td>
    <td class="tabla_mensaje">
      <? echo $men ?>
      </td>
  </tr>
<? }
}//END WHILE
fclose($fichero);
}
?>
</table>
<div align="center"><br>
</div>
<FORM METHOD="Post" ACTION="<? echo $_SERVER[REQUEST_URI] ?>">
  <div align="center"><B>Deja tu opinion :</B><br>
    <b>Nombre: 
    <INPUT NAME="nombre" TYPE="Text" id="nombre" SIZE=60 MAXLENGTH=60 style="font-size:10px;font-family:verdana;" class="form">
    <br>
    Mensaje: 
    <textarea name="opinion" cols="60" style="font-size:10px;font-family:verdana;" class="form"></textarea>
    <br>
    <br>
    <INPUT TYPE="Submit" VALUE="Enviar Opini�n" class="form">
    </b></div>
</FORM>