<title>Tu Imagen - Podras enviar tu imagen para que todo el mundo vea tu imagen</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #FFE7B3 ;
scrollbar-darkshadow-color: #FFAE06 ;
scrollbar-shadow-color: #FFB722 ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #FFAE06 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #FFAE06 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #B97C00 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #A46F00 ;
}
/* Tablas del foro */
.tabla_principal {
border: #FFAE06 0 solid ;
}
.tabla_titulo {
border-left: #FFB722 2 solid ; border-top: #FFB722 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFAE06 ;
}
.tabla_subtitulo {
border-left: #FFCF6A 2 solid ; border-top: #FFCF6A 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFC64F ;
}
.tabla_mensaje {
border-left: #FFE7B3 2 solid ; border-top: #FFE7B3 2 solid ; border-right: #FFCF6A 2 solid ; border-bottom: #FFCF6A 2 solid ;
background: #FFDA8C ;
}
/* Formulario */
.form {
border: #FFAE06 1 solid ;
background: #FFCF6A ;
font-family: verdana ;
font-size: 8pt ;
}
</style><body>
<table width="100%" border="0" cellspacing="2" cellpadding="0">
  <!--DWLayoutTable-->
  <tr> 
    <td width="744" height="144" valign="top">      <div align="center"><img src="logo.gif" width="500" height="145">
        <!-- INICIO codigo banners.miarroba.com -->
        <SCRIPT LANGUAGE="JavaScript" SRC="http://miarroba.com/banners/ver.php?id=8374"></SCRIPT>
        <!-- FIN codigo banners.miarroba.com -->
    </div></td>
  </tr>
</table>
<table width="740" border="0" cellspacing="0" cellpadding="4">
  <!--DWLayoutTable-->
  <tr>
    <td width="565" rowspan="2" valign="top"><table width="565" height="244" border="0" cellpadding="0" cellspacing="4">
        <!--DWLayoutTable-->
        <tr> 
          <td width="300" rowspan="2" valign="top"><div align="right"> 
              <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
                <tr> 
                  <td height="7" colspan="2" class="tabla_titulo">Imagenes</td>
                </tr>
                <?php
// Le damos valor a las variables de configuraci�n
$Config['Path'] = "."; // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 3; // Numero de archivos a mostrar por p�ginas.
$Show['3 Anteriores'] = 0; // Por defecto no se mostrara 5 Anteriores
$Show['3 Siguientes'] = 0; // Por defecto no se mostrara 5 Siguientes
if ($c == "") $c = 0; // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']); // Abrimos el directorio donde estan los archivos
$Plus = $c; // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.
while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['3 Anteriores'] = 1;
$c--;
}
$Counter = 0; // Ponemos a 0 el contador
// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['3 Anteriores'] == 0) $Counter=$Counter-2; else {
$c = 2;
while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['3 Anteriores'] = 1;
$c--;
}
}
// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
$Counter++;
$elemento1 = strtolower($elemento); 
if ((strpos($elemento1, ".gif") > 1) || (strpos($elemento1, ".jpg") > 1)) {
// pasamos el tama�o del archivo a kb
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
// fecha de subida del archivo
$elementotiempo = filectime("$elemento");
$fecha=explode("�",date("�d�m�Y�h�i",$elementotiempo));
$ano=str_replace("2001","01",$fecha[3]);
$ano=str_replace("2002","02",$ano);
$ano=str_replace("2003","03",$ano);
$ano=str_replace("2004","04",$ano);
$ano=str_replace("2005","05",$ano);
$ano=str_replace("2006","06",$ano);
$ano=str_replace("2007","07",$ano);
$ano=str_replace("2008","08",$ano);
$ano=str_replace("2009","09",$ano);
$ano=str_replace("2010","10",$ano);
$fecha="$fecha[1]/$fecha[2]/$ano a las $fecha[4]:$fecha[5]";
?>
                <tr> 
                  <td width="17%" height='7' class="tabla_subtitulo"><b>Imagen</b> 
                  </td>
                  <td width="83%" height='7' class='tabla_subtitulo'><b>Datos 
                    de la imagen</b> </td>
                </tr>
                <tr> 
                  <td height='7' class="tabla_mensaje"><a href="click.php?<?php echo $elemento ?>" target="_blank"><img src="<?php echo $elemento ?>" width="80" height="80" border="0"></a></td>
                  <td height='7' class='tabla_mensaje'>Nombre : <?php echo $elemento ?><br>
                      Tama�o :&nbsp;<?php echo $tamano ; ?> Kb<br>
                      Fecha : <? echo $fecha ?> <br>
                      Hits : 
                      <?php @include("estadisticas/$elemento.ebp"); ?>
                      <br>
                  <a href="opinion.php?a=<? echo $elemento ?>">Ver comentarios</a> </td>
                </tr>
                <?php
}
}
// Si sobran archivos pondremos el "3 Siguientes"
if ($elemento = readdir($dir))
{
$Show['3 Siguientes'] = 1;
}
//Cerramos el directorio 
closedir($dir); 
?>
              </table>              <div align="right"> 
                <?php
// Mostraos si es necessario el "3 Anteriores" y "3 Siguientes".
if ($Show['3 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."\">3 Anteriores | </a>");
if ($Show['3 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."\">3 Siguientes</a></p>");
?>
              </div>            <div align="left"><a href="ver.php">Ver todas</a> | <a href="chat.php" target="_blank">Ir
          al chat</a></div></td>
          <td width="253" height="144" valign="top"><table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
              <!--DWLayoutTable-->
              <tr> 
                <td width="235" height='7' class="tabla_subtitulo">Upload de imagenes </td>
              </tr>
              <tr> 
                <td height='110' valign="top" class="tabla_mensaje"> 
                  <? 
if($enviar) {
if($archivo != "" ) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "gif" && $extensiones[$num] != "jpg" ) { $error = "S�lo se permiten archivos .gif,.jpg<br>" ; }

if(file_exists("$archivo_name")) { $error = "Ya existe un archivo con este nombre.<br>" ; }
if($archivo_size > 256000 ) { $error .= "El archivo debe pesar menos de 250 kb<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
move_uploaded_file($archivo,"$archivo_name") ;
echo "<div aling=left>El archivo <a href='$archivo_name' target='_blank'>$archivo_name</a> ha sido subido con �xito. <a href='$_SERVER[REQUEST_URI]' target='_top'>pulsa aqui</a></div>" ;
}
else {
echo "El archivo <b>$archivo_name</b> supera los 250 Kb" ;
}
}
?>
                  <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
                    <input type="file" name="archivo" class="form">
                    <input type="submit" name="enviar" value="Enviar Imagen" class="form">
    
                    </form>                  <div align="left">
                      <p>Solo se aceptan imagenes .gif y .jpg</p>
                      <p>&nbsp;</p>
                    </div></td>
              </tr>
              <tr>
                <td height='6'></td>
              </tr>
          </table>            <div align="right"></div></td>
        </tr>
        <tr>
          <td height="37">&nbsp;</td>
        </tr>
            </table></td>
    <td width="16" height="104">&nbsp;</td>
    <td width="135" valign="top"> <div align="left">
        <div align="right">
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <!--DWLayoutTable-->
            <tr> 
              <td width="113" height='7' class="tabla_subtitulo">Imagenes ( 
                <?
// abrimos el directorio
$dirfakes = opendir(".");
while ($elemento = readdir($dirfakes)) {
// leemos solo los que tengan ese tipo de extension
$elementofakes = strtolower($elemento); 
if ((strpos($elementofakes, ".gif") > 1) || (strpos($elementofakes, ".jpg") > 1)) 
// mostramos el total de ficheros
$ifakes++;
}
echo $ifakes ;
?>
                ) </td>
            </tr>
            <tr> 
              <td height='38'>&nbsp;</td>
            </tr>
          </table>
          <br>
        </div>
      </div></td>
  </tr>
  <tr>
    <td height="148">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
