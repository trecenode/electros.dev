<?
//Solo se nesesita poner la url de click.php?http://www.sudominio.com/pagina/fichero

$permisodecomentarios= sprintf ("%o", (fileperms("estadisticas")) & 0777);
if($permisodecomentarios == 777){
}else{
$errores.="La carpeta estadisticas no tiene permiso 777<br>";
$errordepermisoswebdeebps="No tiene permiso de escritura >,<";
}


if($errordepermisoswebdeebps == "Pon permiso de escritura a la carpeta estadisticas >,<"){
echo"<title>Error de permisos de archivos de datos</title>";
echo"<font face=Arial size=1>";
echo"<center><h3>Error de permisos de archivos de datos</h3></center>";
echo"<br>";
echo"<font face=Arial size=1>";
echo$errores;
exit;
}


if(file_exists("estadisticas")){
}else{
mkdir("estadisticas",0777);
}

$es = explode("?",$REQUEST_URI); $archivo=$es[1];
$direccion="$archivo";
$archivo=str_replace("/","#",$archivo);
$archivo=str_replace("%20"," ",$archivo);

if($archivo){


if(is_file("estadisticas/$archivo.ebp")){

$fp=fopen("estadisticas/$archivo.ebp","r");
$numero=fread($fp,filesize("estadisticas/$archivo.ebp"));
$clicks=1+$numero;

$archivo = fopen ("estadisticas/$archivo.ebp", "w");
fputs ($archivo,$clicks);
fclose ($archivo);

header("Location:$direccion");

}else{
$archivo = fopen ("estadisticas/$archivo.ebp", "w");
fputs ($archivo,1);
fclose ($archivo);
header("Location:$direccion");
}
}
else{
echo "<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #FFE7B3 ;
scrollbar-darkshadow-color: #FFAE06 ;
scrollbar-shadow-color: #FFB722 ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #FFAE06 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #FFAE06 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #B97C00 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #A46F00 ;
}
/* Tablas del foro */
.tabla_principal {
border: #FFAE06 0 solid ;
}
.tabla_titulo {
border-left: #FFB722 2 solid ; border-top: #FFB722 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFAE06 ;
}
.tabla_subtitulo {
border-left: #FFCF6A 2 solid ; border-top: #FFCF6A 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFC64F ;
}
.tabla_mensaje {
border-left: #FFE7B3 2 solid ; border-top: #FFE7B3 2 solid ; border-right: #FFCF6A 2 solid ; border-bottom: #FFCF6A 2 solid ;
background: #FFDA8C ;
}
/* Formulario */
.form {
border: #FFAE06 1 solid ;
background: #FFCF6A ;
font-family: verdana ;
font-size: 8pt ;
}
</style>" ;
echo "<title>Estadisticas</title>";
echo "<table width='100%' border='0' cellspacing='2' cellpadding='0'>
<tr> 
<td width='32'><a href='index.php'><img src='logo.bmp' border='0'></a> </td>
<td width='939'><div class='t1'>Lafotodeldia.webcindario.com 
</div></td>
</tr>
</table>";
echo "<br>Estadisticas<br>";
echo "<br>";
echo "<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td width='73%' height='7' class='tabla_subtitulo'><b>Url</b></td>
<td width='17%' class='tabla_subtitulo'><b>Fecha</b></td>
<td width='10%' class='tabla_subtitulo'><b>Hits</b></td>
</tr>";
$dir=opendir("estadisticas");
while($archivo = readdir($dir)){
if($archivo=="."){
}else{
if($archivo == ".."){
}else{

$fp=fopen("estadisticas/$archivo","r");
$clicks=fread($fp,filesize("estadisticas/$archivo"));
$url=str_replace("#","/",substr($archivo,0,-4));
$url=str_replace("%20"," ",substr($archivo,0,-4));
$archivotiempo = filectime("estadisticas/$archivo");
$fecha=explode("�",date("�d�m�Y�h�i",$archivotiempo));
$ano=str_replace("2001","01",$fecha[3]);
$ano=str_replace("2002","02",$ano);
$ano=str_replace("2003","03",$ano);
$ano=str_replace("2004","04",$ano);
$ano=str_replace("2005","05",$ano);
$ano=str_replace("2006","06",$ano);
$ano=str_replace("2007","07",$ano);
$ano=str_replace("2008","08",$ano);
$ano=str_replace("2009","09",$ano);
$ano=str_replace("2010","10",$ano);
$fecha="$fecha[1]/$fecha[2]/$ano a las $fecha[4]:$fecha[5]";

echo "<tr> 
    <td height='7' class='tabla_mensaje'> 
      <a href='$url' target='_blank'>$url</a></td>
    <td height='7' class='tabla_mensaje'>$fecha</td>
    <td class='tabla_mensaje'> 
      $clicks
    </td>
  </tr>";
}
}
}
echo "</table>";
echo "<br>"; 
echo "<center><a href='index.php'>volver</a></center>";
closedir($dir);
}
?>