<?php
 $tiempo_logout = 600;
 $arr = file("usuarios.dat");       // INDICAMOS EL ARCHIVO
 $contenido = $REMOTE_ADDR.":".time()."\n";
 for($i=0;$i<sizeof($arr);$i++) {
 $tmp = explode(":",$arr[$i]);
if (( $tmp[0] != $REMOTE_ADDR ) && (( time() - $tmp[1] ) < $tiempo_logout )) {
 $contenido .= $REMOTE_ADDR.":".time()."\n";  // CALCULAMOS EL TIEMPO
 }
 }
 $fp = fopen("usuarios.dat","w");  // ABRIMOS EL ARCHIVO
 fputs($fp,$contenido);
 fclose($fp);  // LO CERRAMOS
 $array = file("usuarios.dat"); //LO MOSTRAMOS
 $USUARIOS_ACTIVOS = count($array);
  if($USUARIOS_ACTIVOS=="1") { echo "1"; }
 else { echo $USUARIOS_ACTIVOS. " "; }
 ?>
