<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'> 
<tr> 
  <td width="78%" height="7" class="tabla_subtitulo"><b>Archivo</b></td> 
  <td class="tabla_subtitulo"><b>Tama�o</b></td> 
</tr> 

<?php
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = ".";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 10;             // Numero de archivos a mostrar por p�ginas.

$Show['10 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['10 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['10 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 los contadores
$Contador = 0;

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['10 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['10 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
  $Contador++;
  $Counter++;

  $elemento1 = strtolower($elemento); 
  if (strpos($elemento1, ".zip") > 1) {

   // pasamos el tama�o del archivo a kb
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
// fecha de subida del archivo
$elementotiempo = filectime("$elemento");
$fecha=explode("�",date("�d�m�Y�h�i",$elementotiempo));
$ano=str_replace("2001","01",$fecha[3]);
$ano=str_replace("2002","02",$ano);
$ano=str_replace("2003","03",$ano);
$ano=str_replace("2004","04",$ano);
$ano=str_replace("2005","05",$ano);
$ano=str_replace("2006","06",$ano);
$ano=str_replace("2007","07",$ano);
$ano=str_replace("2008","08",$ano);
$ano=str_replace("2009","09",$ano);
$ano=str_replace("2010","10",$ano);
$fecha="$fecha[1]/$fecha[2]/$ano a las $fecha[4]:$fecha[5]"; 
?> 
<tr> 
    <td height='7' class="tabla_mensaje"><a href="<?php echo $elemento ?>" ><img src="../imagenes/zip.gif" border="0" width="16" height="16"> 
      <? echo $elemento ?></a></td> 
  <td height='7' class='tabla_mensaje'><?php echo $tamano ; ?> Kb </td> 
</tr> 
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
  $Show['10 Siguientes'] = 1;
}

//Cerramos el directorio 
closedir($dir); 
?> 
</table>
<div align="right">
  <table width="200" border="0">
    <tr>
      <td><? echo"$Contador" ?>&nbsp;</td>
    </tr>
  </table>
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['10 Anteriores'] == 1) echo("<a href=\"contador.php?c=".($Plus-$Config['Show'])."\">10 Anteriores </a>| ");
if ($Show['10 Siguientes'] == 1) echo("&nbsp;<a href=\"contador.php?c=".($Plus+$Config['Show'])."\">10 Siguientes</a></p>");
?>
</div>
