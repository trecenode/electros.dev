<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #FFE7B3 ;
scrollbar-darkshadow-color: #FFAE06 ;
scrollbar-shadow-color: #FFB722 ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #FFAE06 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #FFAE06 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #B97C00 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #A46F00 ;
}
/* Tablas del foro */
.tabla_principal {
border: #FFAE06 0 solid ;
}
.tabla_titulo {
border-left: #FFB722 2 solid ; border-top: #FFB722 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFAE06 ;
}
.tabla_subtitulo {
border-left: #FFCF6A 2 solid ; border-top: #FFCF6A 2 solid ; border-right: #FFB722 2 solid ; border-bottom: #FFB722 2 solid ;
background: #FFC64F ;
}
.tabla_mensaje {
border-left: #FFE7B3 2 solid ; border-top: #FFE7B3 2 solid ; border-right: #FFCF6A 2 solid ; border-bottom: #FFCF6A 2 solid ;
background: #FFDA8C ;
}
/* Formulario */
.form {
border: #FFAE06 1 solid ;
background: #FFCF6A ;
font-family: verdana ;
font-size: 8pt ;
}
</style><table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
                <tr> 
                  <td height='7' class="tabla_subtitulo">Chat (<?php include("activos.php"); ?> personas online)</td>
                </tr>
                <tr> 
                  <td height='7' class="tabla_mensaje"><marquee direction="up" scrollamount="3" height="100" onMouseOver="stop()" onMouseOut="start()">
                    <? 
$archivo="tagboard.txt"; 
$total=10; 
//si hay mensaje, lo guardamos 
if (($nick) && ($mensaje)) { 
$temp = $nick ."{sep}". $mensaje ."\n"; 
$arch = fopen($archivo,"a"); 
$a = fwrite($arch,$temp); 
fclose($arch); 
} 
//con esto mostramos los mensajes. 
$arch = file($archivo); 
$var = count($arch)-1; 
$ultimo = $var - $total + 1; 
while ($var >= $ultimo) { 
if ($arch[$var]) { $b=split("{sep}",$arch[$var]); echo "<b>$b[0]</b> >>> $b[1]"; 
echo "<HR align=center width=75%>"; } 
$var--; 
}  
?>
                    </marquee> <? echo "</div> 
<form action=\"". $PHP_SELF ."\" method=post> 
<input type=text name=nick value=Nick class=form> 
<input type=text name=mensaje value=Mensaje class=form> 
<input type=submit value=\"Enviar\" class=form> 
</form>"; ?></td>
                </tr>
              </table>
              <div align="center"></div>
            