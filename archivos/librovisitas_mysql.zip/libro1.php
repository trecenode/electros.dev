<html>
<head>
</head> 
<?php 
include("conex.php"); 
$link=Conectarse(); 
$result=mysql_query("select * from libro order by ID_libro desc",$link); 
?> 
<?php 

while($row = mysql_fetch_array($result)) { 
echo "<table border=0 width=100%>\n";
echo "<tr><td valign=top align=right class=\"libro1\" width=100>Nombre:\n";
printf("<td class=\"libro2\">%s", $row["nombre"]); 
echo "<tr><td valign=top align=right class=\"libro1\" width=100>E-mail:\n";
printf("<td class=\"libro2\"><a href=\"mailto:%s\">%s</a>", $row["email"],$row["email"]); 
echo "<tr><td valign=top align=right class=\"libro1\" width=100>Fecha:\n";
printf("<td class=\"libro2\">%s", $row["fecha"]); 
echo "<tr><td valign=top align=right class=\"libro1\" width=100>Mensaje:\n";
printf("<td class=\"libro2\">%s", $row["mensaje"]); 
echo "</table>\n";
echo "<hr color=blue>\n";
}
mysql_free_result($result); 
mysql_close($link); 
?> 
<font size=4>
<a name=mensaje>
<form action=libro2.php method=post>
<table border=0 align=center>
<? 
if ($nombre == "error")
{echo "<tr><td><td>\n";
echo "<table border=0 align=center>\n";
echo "<tr><td>\n";
echo "<font color=red face=\"Arial\" size=2><b>* DEBES INGRESAR UN NOMBRE *</b></font>\n";
echo "</table>\n";}
?>
<tr><td align=right>Nombre:</td>
<td><input type=text size=40 name="nombre" <? 
if (($ttnombre > "0") && ($nombre != "error"))
{echo "value=\"$ttnombre\"";}
?> maxlength=50 class=textos>

<? 
if ($email == "error")
{echo "<tr><td><td>\n";
echo "<table border=0 align=center>\n";
echo "<tr><td>\n";
echo "<p><font color=red face=\"Arial\" size=2><b>* EL E-MAIL ES INV�LIDO *</b></font>\n";
echo "</table>\n";}
?>
<tr><td align=right>E-mail:</td>
<td><input type=text size=40 name="email" <? 
if (($ttemail > "0") && ($email != "error"))
{echo "value=\"$ttemail\"";}
?> maxlength=100 class=textos>

<? 
if ($mensaje == "error")
{echo "<tr><td><td>\n";
echo "<table border=0 align=center>\n";
echo "<tr><td>\n";
echo "<p><font color=red face=\"Arial\" size=2><b>* DEBES ESCRIBIR ALGO *</b></font>\n";
echo "</table>\n";}
?>
<tr><td valign=top align=right>Mensaje:</td>
<td><textarea name="mensaje" class=textos rows=4 cols=40 wrap=virtual maxlength=255>
<? 
if (($ttmensaje > "0") && ($mensaje != "error"))
{echo "$ttmensaje";}
?>
</textarea>
</td></tr>

<tr><td>&nbsp;</td><td>
<input type=submit value='Enviar' class=botones>
<input type=reset value='Borrar' class=botones>
</td></tr>
</table></form>
</font>
<? 
setcookie("ttmensaje","",time()+10744,"/","webcindario.com");
?>
