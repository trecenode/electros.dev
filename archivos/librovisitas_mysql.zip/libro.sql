CREATE TABLE libro (
ID_libro int(11) NOT NULL auto_increment,
nombre varchar(200) default NULL,
email varchar(200) default NULL,
url varchar(200) default NULL,
mensaje longtext,
fecha varchar(200) default NULL,
PRIMARY KEY (ID_libro),
FULLTEXT KEY email (email)
) TYPE=MyISAM;