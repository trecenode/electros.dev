<?php 
include("conex.php"); 
$link=Conectarse(); 
$tiempo = time();
$dia = date(w, $tiempo);
$dias = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado","Domingo");
$fecha = date(j, $tiempo);
$mes = date(n, $tiempo);
$meses = array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
$anno = date(Y, $tiempo);
$hora = date(H, $tiempo);
$minuto = date(i, $tiempo);
$segundo = date(s, $tiempo);
$completa = "$dias[$dia] $fecha de $meses[$mes] del $anno, $hora:$minuto:$segundo";

$era = "";
$erb = "";
$erc = "";

function emailsyntax_is_valid($objeto) {
list($local, $domain) = explode("@", $objeto);
$pattern_local = '^([0-9a-z]*([-|_]?[0-9a-z]+)*)(([-|_]?)\.([-|_]?)[0-9a-z]*([-|_]?[0-9a-z]+)+)*([-|_]?)$';
$pattern_domain = '^([0-9a-z]+([-]?[0-9a-z]+)*)(([-]?)\.([-]?)[0-9a-z]*([-]?[0-9a-z]+)+)*\.[a-z]{2,4}$';
$match_local = eregi($pattern_local, $local);
$match_domain = eregi($pattern_domain, $domain);
if ($match_local && $match_domain) {
return 1;
} else {
return 0;
}
}
if (($nombre > "0") && (($email < "0") || ($mensaje < "0")))
{setcookie("ttnombre",$nombre,time()+10834,"/","webcindario.com");}

if (($email > "0") && (($nombre < "0") || ($mensaje < "0")))
{setcookie("ttemail",$email,time()+10834,"/","webcindario.com");}

if (($mensaje > "0") && (($email < "0") || ($nombre < "0")))
{setcookie("ttmensaje",$mensaje,time()+10834,"/","webcindario.com");}

if ($nombre < "0")
{header("Location: libro1.php?nombre=error#mensaje");}else

if ((!emailsyntax_is_valid($email)) || ($email < "0"))
{header("Location: libro1.php?email=error#mensaje");}else

if ($mensaje < "0")
{header("Location: libro1.php?mensaje=error#mensaje");}else

{mysql_query("insert into libro (nombre,email,fecha,mensaje) values ('$nombre','$email','$completa','$mensaje')",$link);
mysql_free_result($result); 
mysql_close($link);
setcookie("ttnombre","",time(),"/","webcindario.com");
setcookie("ttemail","",time(),"/","webcindario.com");
setcookie("ttmensaje","",time(),"/","webcindario.com");
header("Location: libro1.php");}
?>
