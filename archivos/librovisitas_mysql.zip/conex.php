<?php 
function Conectarse() 
{ 
if (!($link=mysql_connect("localhost","usuario","contrase�a"))) 
{echo "Error en el nombre de usuario y contrase�a,revisa el archivo conex.php"; 
exit(); 
} 
if (!mysql_select_db("nombredelabasededatos",$link)) 
{echo "Error en el nombre de la base de datos,revisa el archivo conex.php"; 
exit(); 
} 
return $link; 
} 
?> 