<?

// ***** Modificar las siguientes lineas con sus datos *****
$servidor = "localhost";
$usuario = "usuario";
$password = "contrase�a";
$base_de_datos = "nombre_BD";

// nombre de la tabla...
$nombre_tabla = "libro";
// estructura de la tabla...
$sql ="CREATE TABLE ".$nombre_tabla."(
ID_libro int(11) NOT NULL auto_increment,
nombre varchar(200) default NULL,
email varchar(200) default NULL,
url varchar(200) default NULL,
mensaje longtext,
fecha varchar(200) default NULL,
PRIMARY KEY (ID_libro),
FULLTEXT KEY email (email)
) TYPE=MyISAM;
);";
// ********************** Fin modificacion **********************

$myconn = mysql_connect($servidor,$usuario,$password);
if (!@mysql_select_db($base_de_datos)){
echo ("Imposible abrir la BD");
exit();
}

if(!@mysql_query($sql,$myconn)) echo "Error: ".mysql_error();
else{
echo ("<P ALIGN=center><B>Tabla creada con �xito</B></P>");

// Muestro los datos de la tabla creada...
$result = mysql_query("SELECT * FROM $nombre_tabla");
$fields = mysql_num_fields($result);
$i = 0;
$table = mysql_field_table($result,$i);
echo "<BR>";
echo "<B>Nombre de la tabla:</B> ".$table."<BR>";
echo "<B>Cantidad de campos:</B> ".$fields."<BR>";
echo "<TABLE WIDTH=100% BORDER=1><TR>";
echo "<TD ALIGN=center>Tipo</TD>
<TD ALIGN=center>Nombre</TD>
<TD ALIGN=center>Largo</TD>
<TD ALIGN=center>Flags / Atributos</TD>";
echo "</TR>";
while($i < $fields){
$type = mysql_field_type ($result, $i);
$name = mysql_field_name ($result, $i);
$len = mysql_field_len ($result, $i);
$flags = mysql_field_flags ($result, $i);
if ($flags == "") $flags = "&nbsp;";
echo "<TR>";
echo "<TD>".$type."</TD>";
echo "<TD>".$name."</TD>";
echo "<TD>".$len."</TD>";
echo "<TD>".$flags."</TD>";
echo "</TR>";
$i++;
}
echo "</TABLE>";
}
?>