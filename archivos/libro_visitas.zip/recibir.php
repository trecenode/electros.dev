<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="enlaces.php"><img src="libro.gif" alt="" width="48" height="48" border="0"></a> 
          <strong>LIBRO DE VISITAS</strong><br>
          <br>
          <font class="content">[ <a href="libro.php">Principal</a> | <a href="escribir.php">Escribir 
          en el libro</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br>
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td><div align="center"> 
          <?php
$pvm = getdate();
$archivo="libro.txt"; #aqu� para cambiar la ruta del archivo donde se guardan las entradas 
$uusi="<table border=0 width=95% cellspacing=1>
  <tr> 
    <td width=30%><b>Nombre :</b></td>
    <td width=70%> $nombre </td>
  </tr>
  <tr> 
    <td width=30%><b>Fecha : </b></td>
    <td width=70%>$pvm[mday]-$pvm[mon]-$pvm[year]</td>
  </tr>
  <tr> 
    <td width=30%><b>E-mail :</b></td>
    <td width=70%><a href='mailto:$email'>$email</a></td>
  </tr>
  <tr> 
    <td width=30%><b>Web :</b></td>
    <td width=70%><a href='http://$weburl' target='_blank'>$nombreweb</a></td>
  </tr>
  <tr> 
    <td width=30%><b>Localizaci�n :</b></td>
    <td width=70%>$pais - $ciudad </td>
  </tr>
  <tr> 
    <td width=30%><b>Nos encontr� en un:</b></td>
    <td width=70%> $desde </td>
  </tr>
  <tr> 
    <td width=30%><b>Tu opinion de la web :</b></td>
    <td width=70%> $grupo</td>
  </tr>
  <tr> 
    <td width=30%><b>Comentario :</b></td>
    <td width=70%> $comentario </td>
  </tr>
</table>

<hr width=70%>\n\n";
$fp=fopen($archivo, "r+");
$vanha=fread($fp, filesize($archivo));
fseek($fp, 0);
fwrite($fp, "${uusi}${vanha}");
fclose($fp);


print "Enlace a&ntilde;adido <a href=enlaces.php>regresar</a>";
?>
        </div></td>
    </tr>
  </table>
</div>
<div align="center"></div>
</body>
</html>
