<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="enlaces.php"><img src="libro.gif" alt="" width="48" height="48" border="0"></a> 
          <strong>LIBRO DE VISITAS</strong><br>
          <br>
          <font class="content">[ <a href="libro.php">Principal</a> | <a href="escribir.php">Escribir 
          en el libro</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br> 
  <table width="50%" border="1" cellspacing="0">
    <tr>
      <td><div align="center">
          <?php include("libro.txt"); #aqu� para cambiar la ruta del archivo que muestra las entradas 
		 ?>
        </div></td>
    </tr>
  </table>
  <br>
  <br>
</div>
