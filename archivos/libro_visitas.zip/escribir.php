<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="enlaces.php"><img src="libro.gif" alt="" width="48" height="48" border="0"></a> 
          <strong>LIBRO DE VISITAS</strong><br>
          <br>
          <font class="content">[ <a href="libro.php">Principal</a> | <a href="escribir.php">Escribir 
          en el libro</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br>
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td><div align="center"> 
          <?php
print "<table border=0 width=95% cellspacing=1>
  <form method='post' action='recibir.php' onsubmit='return error ()' name='myform'>
    <tr> 
      <td width=30%><b>Nombre :</b></b></td>
      <td width=70%> <input name=nombre maxlenght=30 type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Email :</b></td>
      <td width=70%> <INPUT name=email type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Nombre de tu web :</b></td>
      <td width=70%> <INPUT name=nombreweb type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Url :</b></td>
      <td width=70%> Http:// 
        <INPUT name=weburl type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Pa�s :</b></td>
      <td width=70%> <input maxlenght=50 name=pais type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Ciudad :</b></td>
      <td width=70%> <input maxlenght=50 name=ciudad type=text> </td>
    </tr>
    <tr> 
      <td width=30%><b>Nos encontraste en :</b></td>
      <td width=70%> <select name=desde>
          <option value=Buscador>En un buscador</option>
          <option value=Top>En un top</option>
          <option value=Directorio>Un enlace de una web</option>
          <option value=Afiliado>Una web afiliada</option>
          <option value=...>Otro sitio</option>
        </select> </td>
    </tr>
    <tr> 
      <td width=30%><b>Cual es tu opinion de la web :</b></td>
      <td width=70%> <input name=grupo type=text id=grupo maxlenght=50> </td>
    </tr>
    <tr> 
      <td width=30%><b>Comentarios :</b></td>
      <td width=70%> <textarea name=comentario rows=5 cols=23></textarea> <input type=submit value=Enviar> 
      </td>
    </tr>
    <script>
                        function error (){
                                if (document.myform.nombre.value == '') {
                                        alert('Por favor, introduzca su nombre.');
                                        document.myform.nombre.focus();
                                        return false}
                                if (document.myform.email.value == '') {
                                        alert('Por favor, introduzca el email.');
                                        document.myform.email.focus();
                                        return false}
                                 if (document.myform.nombreweb.value == '') {
                                        alert('Por favor, introduzca el nombre de su web o web preferida.');
                                        document.myform.nombreweb.focus();
                                        return false}
                                if (document.myform.weburl.value == '') {
                                        alert('Por favor, introduzca su url, o web preferida.');
                                        document.myform.weburl.focus();
                                        return false}
                                if (document.myform.pais.value == '') {
                                        alert('Por favor, introduzca el pais.');
                                        document.myform.pais.focus();
                                        return false}
                                 if (document.myform.ciudad.value == '') {
                                        alert('Por favor, introduzca la ciudad.');
                                        document.myform.ciudad.focus();
                                        return false}
                                if (document.myform.desde.value == '') {
                                        alert('Por favor, introduzca desde donde nos conocio.');
                                        document.myform.desde.focus();
                                        return false}
                                if (document.myform.grupo.value == '') {
                                        alert('Por favor, introduce tu opinion de la web.');
                                        document.myform.grupo.focus();
                                        return false}
                                 if (document.myform.comentario.value == '') {
                                        alert('Por favor, introduzca el comentario.');
                                        document.myform.comentario.focus();
                                        return false}
                                else return getPermission();
                        }

</script>
  </form>
</table>
";
?>
        </div></td>
    </tr>
  </table>
  <br>
  <br>
</div>
</body>
</html>
