<html>
<head>
<title>Comentario</title>
<!-- Contador de caracteres ----->
<script LANGUAGE="JavaScript">
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
</script>
<!-- fin ------>
<!-- EDITAR ESTILO ------>
<style>
TEXTAREA {
background:C0C0C0; font-weight:bold;
}
INPUT {
background:C0C0C0; font-weight:bold;
}
</style>

</head>
<body>
<?
/************************************/
/**** SCRIPT DE NACHO MARTINEZ *****/
/* http://ringoweb.webcindario.com */
/**********************************/
if(isset($submit)):
  $para = "tucorreo@dominio.com";//TU DIRECCION DE CUENTA 
  $asunto = "�Han ontroducido informacion en la web";//MENSAJE K KIERES K APAREZCA EN EL ASUNTO
  $cuerpo = "�Un usuario introdujo datos!\n";//MENSAJE EN EL CUERPO
  $cuerpo .= "Sus datos son:\n\n";
  $cuerpo .= "$comentario";//VARIABLE DEL TEXTAREA
  $uasunto = "�Gracias por su comentario!";//ASUNTO K SE ENVIA AL USUARIO
  $ucuerpo = "�Gracias por su comentario!Si tiene alguna sugerencia
              mas puede volver a enviarla se estudiara";//MENSAJE K SE ENVIA AL USUARIO
  mail($para, $asunto, $cuerpo);//SE ENVIA EL E-MAIL
  mail($email, $uasunto, $ucuerpo);
  echo "<h2>Gracias por la informacion</h2>";//MENSAJE PARA DAR LAS GRACIAS
  echo "<a href=javascript:history.back(-1);>Volver</a>";
else:
?>
<form action="comentario.php" method="post">
<h2>Por favor, envienos su comentario</h2>
<font color="0000ff"><b>.:Tu E-Mail:.</b></font><br>
<input type="text" name="email" style="border:1px solid"><br>
<textarea cols=35 rows=15 name="comentario" style="border:1px solid" onKeyDown="textCounter(this.form.comentario,this.form.remLen,250);"
  onKeyUp="textCounter(this.form.comentario,this.form.remLen,250);">
</textarea><br><input readonly type="text" name="remLen" size="3" maxlength="3" value="250" style="border:1px solid"> caracteres
<BR>
<input type="submit" name="submit" value="�Enviar!" style="border:1px solid">
</form>
<?
endif;
?>
</body>
</html>