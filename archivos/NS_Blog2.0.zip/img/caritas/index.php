<?
function caritas($que){
$caras = Array(
"[1020]" => "1020.gif",
"[542]" => "542.gif",
"[942]" => "942.gif",
"[965]" => "965.gif",
"[atencion]" => "atencion.gif",
"[beso]" => "beso.gif",
"[beso2]" => "beso2.gif",
"[bien]" => "bien.gif",
"[bosteso]" => "bosteso.gif",
"[brabo]" => "brabo.gif",
"[burlon]" => "burlon.gif",
"[busqueda]" => "busqueda.gif",
"[callate]" => "callate.gif",
"[charla]" => "charla.gif",
"[chelear]" => "chelear.gif",
"[desepcion]" => "desepcion.gif",
"[diablo]" => "diablo.gif",
"[durmiendo]" => "durmiendo.gif",
"[enojado]" => "enojado.gif",
"[feliz]" => "feliz.gif",
"[fumar]" => "fumar.gif",
"[gino]" => "gino.gif",
"[gratitud]" => "gratitud.gif",
"[hombre]" => "hombre.gif",
"[lengua]" => "lengua.gif",
"[llorando]" => "llorando.gif",
"[madreado]" => "madreado.gif",
"[mentada]" => "mentada.gif",
"[mujer]" => "mujer.gif",
"[no]" => "no.gif",
"[novios]" => "novios.gif",
"[ojeras]" => "ojeras.gif",
"[ops]" => "ops.gif",
"[ops2]" => "ops2.gif",
"[pc]" => "pc.gif",
"[pena]" => "pena.gif",
"[piensa]" => "piensa.gif",
"[presumido]" => "presumido.gif",
"[programando]" => "programando.gif",
"[quemando]" => "quemando.gif",
"[risa]" => "risa.gif",
"[si]" => "si.gif",
"[sonrisa]" => "sonrisa.gif",
"[sorpresa]" => "sorpresa.gif",
"[triste]" => "triste.gif",
"[wakala]" => "wakala.gif");
foreach($caras as $comando => $src){
	$que = str_replace($comando,"<img src='img/caritas/$src'>",$que);
	}
return $que;
}
$path="./"; //tu dir
$dir=dir($path);
while ($elemento = $dir->read()){
	if(strlen($elemento)>3){
		if(ereg(".gif$",$elemento)){
			$comando = $elemento;
			$comando = str_replace(".gif","",$comando);
			echo caritas("[$comando]")."<br>";
			}
		}
	}

$dir->close();
?>