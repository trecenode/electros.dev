			<center><!---->
			<table width="650">
				<tr>
					<td>
					<div id="entrada_<?=$this->leer["id"]?>">
						<div id="titulo">
							<?=$this->leer["titulo"]?>
						</div>
						<div class="texto">
							<?
							if($_POST){
								echo $this->leer["cuerpo"];
								}
							else{
								echo $this->formato($this->leer["cuerpo"]);
								}
							?>
							<?
							$temp = mysql_query("select * from ns_comentarios where id='".$this->leer["id"]."'");
							?>
							<div class="texto" title="Comentarios para esta entrada" style="text-align:right;"> 
							<a href="index.php?pagina=blog&accion=ver&id=<?=$this->leer["id"]?>">
							Ver Comentarios (<?=mysql_num_rows($temp)?>)</a></div>
						</div>
							<center>
								<p>
								<div class="detalles" style="text-align:right;">
									Escrito por: <?
									echo ADMIN;
									?>. en el dia <?=$this->leer["fecha"]?>	<br>
									<a href="javascript:editar_post(<?="'".$this->leer[id]."'"?>)">Editar post</a>
								</div>
								<hr id="separador">
								<p>
							</center>
						</div>
					</td>
				</tr>
			</table></center><!---->
