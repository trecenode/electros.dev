<?
if(ES_ADMIN=="si"){
?>
			<center><!---->
			<table width="650">
				<tr>
					<td>
						<div id="titulo">
							Administrar
						</div>
					<div class="texto">
<img src="img/nuevo.png">
 <a href="javascript: ir('blog.php?accion=admin&tarea=nueva')">Agregar una entrada nueva</a><br>
<img src="img/datos.png">
 <a href="javascript: ir('blog.php?accion=admin&tarea=datos')">Cambiar datos</a><br>
<img src="img/salir.png">
 <a href="javascript: ir('blog.php?accion=admin&tarea=salir')">Salir de NS Blog 2.0</a><br>
</div>	
					</td>
				</tr>
			</table></center><!---->

<?
	}
else{
	include("./forms/login.php");
	}
?>
