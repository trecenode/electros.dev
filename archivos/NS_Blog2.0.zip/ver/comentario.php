			<center><!---->
			<table width="650">
				<tr>
					<td>
						<div id="titulo">
							RE: <? echo TITULO; ?>
						</div>
						<div class="texto">
							<?
							if($_POST){
								echo $this->leer["cuerpo"];
								}
							else{
								echo $this->formato($this->leer["cuerpo"]);
								}
								?>
						</div>
							<center>
								<p>
								<div class="detalles" style="text-align:right;">
									Escrito por: <?
									echo $this->leer["autor"] = $this->leer["autor"] == "||@DMIN||" ? ADMIN : $this->leer["autor"];
									?> . En el dia <?=$this->leer["fecha"]?>	
								</div>
								<hr id="separador">
								<p>
							</center>
					</td>
				</tr>
			</table></center><!---->