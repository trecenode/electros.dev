<style>
#paginado{
	position:relative;
	width:620px;
	}
#enlace_ant{
	position:absolute;
	top:0px;
	text-align:left;
	}
#enlace_sig{
	position:absolute;
	top:0px;
	right:0px;
	}
#menu_ordenar{
	position:absolute;
	top:0px;
	left:285px;
	}
</style>


<!------------------------------>
<center><!---->
	<table width="650">
		<tr>
			<td>
				<div id="paginado">
					<div id="enlace_ant">
						<div class="texto">
							<?=$extras->enlace_ant?>
						</div>
					</div>

<?
var $ir;
foreach($_GET as $nombre => $contenido){
	$ir.="$nombre=$contenido&";
	}
$ir = str_replace("&por=".$_GET[por],"",$ir);
echo "
<script>
function orden(por){
	self.location.href = \"index.php?\"+ \"$ir\" + '&por=' + por;
	}	
</script>"
?>
					<div id="menu_ordenar">
								<div class="texto" onmouseover="mostrar_menu('menu_orden')" onmouseout="ocultar_menu('menu_orden')">
								Ordenar Por...	
								</div>
								<div class="menu_orden" id="menu_orden" onmouseover="mostrar_menu(this.id)" onmouseout="ocultar_menu(this.id)">
									<div class="texto">
										<div id="sub_orden_1" class="sub_orden" onmouseover="color('ffffff',this.id)" onmouseout="color('ffffff',this.id)" class="sub_orden" style="border-top-width:1px;">
											<a href="javascript:orden('id_desc')">ID (...3,2,1)</a>
										</div>
										<div id="sub_orden_2" class="sub_orden" onmouseover="color('ffffff',this.id)" onmouseout="color('ffffff',this.id)" class="sub_orden">
											<a href="javascript:orden('id_asc')">ID (1,2,3...)</a>
										</div>
										<div id="sub_orden_3" class="sub_orden" onmouseover="color('ffffff',this.id)" onmouseout="color('ffffff',this.id)" class="sub_orden">
											<a href="javascript:orden('autor_desc')">Autor (Z-A))</a>
										</div>
										<div id="sub_orden_4" class="sub_orden" onmouseover="color('ffffff',this.id)" onmouseout="color('ffffff',this.id)" class="sub_orden">
											<a href="javascript:orden('autor_desc')">Autor (A-Z)</a>
										</div>
									</div>
								</div>
					</div>

					<div id="enlace_sig">
						<div class="texto">
							<?=$extras->enlace_sig?>
						</div>
					</div>
				</div>
			</td>
		</tr>
	</table>
</center><!----><p>
