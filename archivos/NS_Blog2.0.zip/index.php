<?
include("datos.php");
include("skin.php");
define("ADMIN",$datos[admin]);
?>
<html>
<head>
<title><?=$datos["titulo"]?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<script src="js/otros.js"></script>
<script src="js/ajax.js"></script>
<?
//Sistema de frases
$frase = Array("By NosferatuSoft","www.nosferatusoft.com.ar","maravillas del PHP ","frase aleatoria...");
$numero = rand(0,count($frase));
$numero = !$frase[$numero] ? rand(0,count($frase)) : $numero;
?>
<div id="header">
	<div onclick="javascript: skin('rojo')" id="skin_rojo"></div>
	<div onclick="javascript: skin('verde')" id="skin_verde"></div>
	<div onclick="javascript: skin('azul')" id="skin_azul"></div>
	<div id="header_titulo">
		<?
			echo $datos["titulo"];
		?>
	</div>
	<div id="header_frase">
		<?=$frase[$numero];
		?>
	</div>
</div>
<div id="contenido">
	<div id="arribas">
			<div class="arriba_enlaces">	
			<a href="index.php">Blog</a>
			<?
			$accion = $_GET[accion];
			$accion = str_replace("'","",$accion);
			$id = $_GET[id];
			$id = !is_numeric($id) ? 0 : $id; 
			if($_GET[accion] and $_GET[id]){
				include("config.php");
				$temp = mysql_query("select titulo from ns_entradas where id='$id'");
				$leer = mysql_fetch_array($temp);
				define("TITULO",$leer["titulo"]);
				echo " >> <a href='index.php?pagina=blog&accion=ver&id=$id'>".TITULO."</a>";
				}
			?>
	
				<input type="text" style="position:absolute; left:470px; width:150px; height:17px;" id="busqueda" value="<?=$_COOKIE[nsb_busc]?>">
				<input type="button" style="position:absolute; left:630px; width:70px; height:17px;" value="Buscar" onclick="buscar()">
		</div>
	</div>
	<div id="cont_arriba">
	</div>
	<div id="cont">
		<div id="contenido_central"><!---- Contenido----->
		<?
		$pagina = $_GET["pagina"];
		$pagina = str_replace("'","",$pagina);
		if(!$pagina){
			$pagina = "blog";
			}
		if(!file_exists("$pagina.php")){
			$pagina = "404";
			}
		include("$pagina.php");
		?>
		</div><!----/contenido------>
	</div>
	<div id="cont_abajo"></div>
	<div class="texto" style="text-align:center;">
		(C) 2005 Desarrollado por <a href="http://www.nosferatusoft.com.ar">NosferatuSoft</a><br>
		1024 x 768px :: <a href="http://www.getfirefox.com">Firefox</a> :: <a href="<?=$datos["url"]?>" title="<?=$datos["email"]?>"><?=$datos["admin"]?></a> :: <a href="javascript:ir('blog.php?accion=admin')">Admin</a><br>
		<a href="http://nsblog.nosferatusoft.com.ar">Sitio ofial de NS Blog 2.0</a> 
	</div>
</div>
<div id="skin"></div>
<!-- Ocultas-->
