<?
class skin{
	function pasar($var){
		$this->datos["defecto"] = $var;
		}
	function mostrar($cual,$cont){
		echo "<style>\n";
		echo file_get_contents($cual);
		echo "</style>";
		}
	function buscar($color){
		$this->path = "skins/$color/index.css";
		switch($color){
			case "azul":
				$this->mostrar($this->path,$skin);
			break;
			case "rojo":
				$this->mostrar($this->path,$skin);
			break;
			case "verde":	
				$this->mostrar($this->path,$skin);
			break;
			}
		}
	function cambiar(){
		$skin = $_GET["skin"];
		setcookie("nsb_skin",$skin,time()+3600000);
		$skin = !$skin ? $this->datos["defecto"] : $skin;
		$this->buscar($skin);
		}
	function interpretar(){
		$skin = $_COOKIE["nsb_skin"];
		$skin = !$skin ? $this->datos["defecto"] : $skin;
		$this->buscar($skin);
		}
	}
$asdf = new skin();
$asdf->pasar($datos["defecto"]);
if($_GET["skin"]){
	$asdf->cambiar();
	}
if(!$_GET["skin"]){
	$asdf->interpretar();
	}
?>
