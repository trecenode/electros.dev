function ajax_objeto(){
	try{
		ajax = new ActiveXObject("Msxml2.XMLHTTP");
		}
	catch(e){
		try{
			ajax = new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch(E){
				ajax = false;
				}
			}
	if(!ajax && typeof XMLHttpRequest!='undefined'){
		ajax = new XMLHttpRequest();
	}
	return ajax;
}
function comentar(){
	var msg_error="";
	var cuerpo = document.getElementById('cuerpo').value;
	var autor = document.getElementById('autor').value;
	var id = document.getElementById('id').value;
	if(!cuerpo || cuerpo=="Comentario"){
		msg_error+="El mensaje no est� escrito\n";
		}
	if(!autor || autor=="Tu Nombre"){
		msg_error+="El autor no est� escrito";
		}
	if(msg_error!=""){
		alert(msg_error);
		return false;
		}
	ajax=ajax_objeto();
	ajax.open("POST", "blog.php?accion=comentar&id="+id,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById("contenido_central").innerHTML = ajax.responseText + document.getElementById("contenido_central").innerHTML;
			document.getElementById('cuerpo').disabled = true;
			document.getElementById('autor').disabled = true;
			alert("Gracias por comentar.");
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send("autor="+autor+"&cuerpo="+cuerpo+"&id="+id);
	}

//

function buscar(){
	var msg_error="";
	var que = document.getElementById('busqueda').value;
	if(!que){
		msg_error+="No se puede buscar si no pones algo...";
		}
	if(msg_error!=""){
		alert(msg_error);
		return false;
		}
	ajax=ajax_objeto();
	ajax.open("GET", "blog.php?accion=buscar&que="+que,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==1){
			document.getElementById("contenido_central").innerHTML = "Buscnado....";
			}
		if(ajax.readyState==4){
			document.getElementById("contenido_central").innerHTML = ajax.responseText;
			}
		}
	ajax.send(null);
	}
function ir(a){
	ajax=ajax_objeto();
	ajax.open("GET",a,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById("contenido_central").innerHTML = ajax.responseText;
			}
		}
	ajax.send(null);
	}
function logeo(){
	var user = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;
	var error_msg;
	if(!user){
		error_msg+= "No escribiste tu nick";
		}
	if(!pass){
		error_msg+= "No escribiste el password";
		}
	ajax=ajax_objeto();
	ajax.open("POST", "blog.php?accion=admin&tarea=logeo",true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			if(ajax.responseText=="error"){
				alert("Datos incorrectos");
				return false;
				}
			ir('blog.php?accion=admin&tarea=panel');
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send("user="+user+"&pass="+pass);
	}
///////
function nueva_entrada(q){
	var msg_error="";
	var cuerpo = document.getElementById('cuerpo').value;
	var titulo = document.getElementById("titulo_nueva").value;
	if(!cuerpo){
		msg_error+="El mensaje no est� escrito\n";
		}
	if(!titulo){
		msg_error+="El titulo no esta escrito\n";
		}
	if(msg_error!=""){
		alert(msg_error);
		return false;
		}
	ajax=ajax_objeto();
	ajax.open("POST", "blog.php?accion=admin&tarea=nueva&inc=si",true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			alert("Se publico con exito la entrada");
			ir('blog.php?accion=admin&tarea=panel');
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send("titulo="+titulo+"&cuerpo="+cuerpo);
	}
function skin(color){
	var navegador = navigator.appName;
	var todas_get = window.location.search;
	if(navegador=="Microsoft Internet Explorer"){
		if(!todas_get){
			todas_get = "index.php?"
			}
		location = todas_get + "&skin=" + color;
		return false;
		}
	ajax=ajax_objeto();
	ajax.open("GET","skin.php?skin="+color,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById("skin").innerHTML = ajax.responseText;
			}
		}
	ajax.send(null);
	}
//
function guardar_datos(){
	var msg_error="";
	var titulo = document.getElementById("titulo_d").value;
	var admin = document.getElementById("admin").value;
	var password = document.getElementById("password").value;
	var email = document.getElementById("email").value;
	var url = document.getElementById("url").value;
	var entradas = document.getElementById("entradas").value;
	var mensajes = document.getElementById("mensajes").value;
	var defecto = document.getElementById("defecto").value;
	var todos = "titulo="+titulo+"&admin="+admin+"&password="+password+"&email="+email+"&url="+url+"&entradas="+entradas+"&mensajes="+mensajes+"&defecto="+defecto+"&skin="+defecto;
	ajax=ajax_objeto();
	ajax.open("POST", "blog.php?accion=admin&tarea=datos&inc=si",true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			alert("Se guado correctamente todo");
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send(todos);
	}
/////
function editar_post(cual){
	ajax=ajax_objeto();
	ajax.open("GET", "blog.php?accion=admin&tarea=editar_post&cual="+cual,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById("entrada_"+cual).innerHTML = ajax.responseText;
			}
		}
	ajax.send(null);
	}

/////
function guardar_post(cual){
	var titulo = document.getElementById("titulo_editar_"+cual).value;
	var cuerpo = document.getElementById("cuerpo_editar_"+cual).value;
	ajax=ajax_objeto();
	ajax.open("POST", "blog.php?accion=admin&tarea=editar_post&cual="+cual,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById("entrada_"+cual).innerHTML = ajax.responseText;
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send("titulo="+titulo+"&cuerpo="+cuerpo);
	}

/////
function instalar(){
	var msg_error="";
	var mysql_user = document.getElementById("mysql_user").value;
	var mysql_pass = document.getElementById("mysql_pass").value;
	var mysql_host = document.getElementById("mysql_host").value;
	var mysql_db = document.getElementById("mysql_db").value;
	var titulo = document.getElementById("titulo_d").value;
	var admin = document.getElementById("admin").value;
	var password = document.getElementById("password").value;
	var email = document.getElementById("email").value;
	var url = document.getElementById("url").value;
	var entradas = document.getElementById("entradas").value;
	var mensajes = document.getElementById("mensajes").value;
	var defecto = document.getElementById("defecto").value;
	var todos = "mysql_user="+mysql_user+"&mysql_host="+mysql_host+"&mysql_pass="+mysql_pass+"&mysql_db="+mysql_db+"&titulo="+titulo+"&admin="+admin+"&password="+password+"&email="+email+"&url="+url+"&entradas="+entradas+"&mensajes="+mensajes+"&defecto="+defecto+"&skin="+defecto;
	ajax=ajax_objeto();
	ajax.open("POST", "clase_instalar.php",true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			alert("Se instalo NS Blog 2.0 con exito, ahora borar estos archivos:\ninstalar.php\nforms/instalar.php\nclase_instalar.php\n esto es por seguridad");
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send(todos);
	}