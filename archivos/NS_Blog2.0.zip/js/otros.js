function caritas(q,c){
	document.getElementById(c).value += q;
	}
function mostrar_menu(c){
	document.getElementById(c).style.visibility="visible";
	}
function ocultar_menu(a){
	document.getElementById(a).style.visibility="hidden";
	}
function color(color,cual){
	document.getElementById(cual).style.background = color;
	}
