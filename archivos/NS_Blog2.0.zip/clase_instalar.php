<?
if($_POST){
		$mysql_host = $_POST[mysql_host];
		$mysql_usuario = $_POST[mysql_user];
		$mysql_contrasena = $_POST[mysql_pass];
		$mysql_db = $_POST[mysql_db];
		$conectar = @mysql_connect($mysql_host,$mysql_usuario,$mysql_contrasena) or die("Los d�tos para conectar con la base de datos son incorrectos.") ;
		mysql_select_db($mysql_db,$conectar) or die("No existe la base de datos...") ;
				$tabla["blog_comentarios"] = "CREATE TABLE ns_comentarios(
				num int auto_increment NOT NULL,
				autor char(25) NOT NULL, 
				cuerpo longtext NOT NULL,
				fecha char(25) NOT NULL,
				id smallint(25) NOT NULL, 
				PRIMARY KEY (num) 
				);";
				$tabla["blog_entradas"] ="CREATE TABLE ns_entradas(
				id int auto_increment NOT NULL,
				titulo char(50) NOT NULL,
				fecha char(25) NOT NULL,
				cuerpo longtext NOT NULL,
				PRIMARY KEY (id) 
				);";
		mysql_query($tabla["blog_comentarios"]) or die(mysql_error());
		mysql_query($tabla["blog_entradas"]) or die(mysql_error());
///////////////////////////////////////////////////////
		$config = "
				<?
				\$mysql_host = \"$_POST[mysql_host]\";
				\$mysql_usuario = \"$_POST[mysql_user]\";
				\$mysql_contrasena = \"$_POST[mysql_pass]\";
				\$mysql_db = \"$_POST[mysql_db]\";
				\$conectar = @mysql_connect(\$mysql_host,\$mysql_usuario,\$mysql_contrasena) or die(\"Los d�tos para conectar con la base de datos son incorrectos.\") ;
				mysql_select_db(\$mysql_db,\$conectar) or die(\"No existe la base de datos...\") ;
				?>
				";
		
		$abrir = @fopen("config.php","w+") or die("no se puede abrir config.php");
		@fwrite($abrir,$config) or die("no se puede escribir en config.php");
		@fclose($abrir);
		///////////////		
		$codigo = "
		<?
		\$datos[\"titulo\"] = \"$_POST[titulo]\";
		\$datos[\"admin\"] = \"$_POST[admin]\";
		\$datos[\"password\"] = \"$_POST[password]\";
		\$datos[\"email\"] = \"$_POST[email]\";
		\$datos[\"url\"] = \"$_POST[url]\";
		\$datos[\"entradas\"] = $_POST[entradas];
		\$datos[\"mensajes\"] = $_POST[mensajes];
		\$datos[\"defecto\"] = \"$_POST[skin]\";
		?>
		";
		$abrir = @fopen("datos.php","w+") or die("No se pudo conectar con datos.php");
		@fwrite($abrir,$codigo) or die("No se pudo escribie en datos.php");
		@fclode($abrir);
		unlink("forms/instalar.php");
		unlink("instalar.php");
	}
?>
