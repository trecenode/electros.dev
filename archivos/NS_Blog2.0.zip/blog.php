<?
@header("Expires: Thu, 27 Mar 1980 23:59:00 GMT");
@header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
@header("Cache-Control: no-cache, must-revalidate");
@header("Pragma: no-cache");
include("config.php");
include("datos.php");
$accion = $_GET["accion"];
include("extras.php");
$extras = new extras();	
switch($accion){
	default:
		include("tareas_blog.php");
		$blog = new tareas_blog();
		$blog->ordenar_entradas($_GET["por"]);
		$extras->paginar($blog->sentencia,"ver/entrada.php",$datos["entradas"],$_GET["cant"]);
		include("ver/enlaces.php");
	break;
	case "ver":
		define("ADMIN",$datos["admin"]);
		include("tareas_blog.php");
		$blog = new tareas_blog();
		$blog->ordenar_comentarios($_GET["por"],$_GET["id"]);
		$extras->paginar($blog->sentencia,"ver/comentario.php",$datos["mensajes"],$_GET["cant"]);
		include("ver/enlaces.php");
		include("forms/comentar.php");
	break;
	case "comentar":
		$extras->es_admin();
		include("tareas_blog.php");
		$blog = new tareas_blog();
		$blog->comentar($_POST["autor"],$_POST["cuerpo"],$_POST["id"],$extras->formato($_POST["cuerpo"]));
	break;
	case "buscar":
		include("tareas_blog.php");
		$blog = new tareas_blog();
		$blog->buscar($_GET["que"]);
		$extras->paginar($blog->sentencia,"ver/comentario.php",10,$_GET["cant"]);
		if($extras->resultados==0){
			echo "<div class='texto'><b>No</b> se encntraron resultados para <b>".$_GET[que]."</b> </div>";
			}
	break;
	case "admin":
		include("admin.php");
		include("datos.php");
		$extras->es_admin();
		$admin = new admin();
		switch($_GET[tarea]){
			case "logeo":
				$admin->login($_POST[user],$_POST[pass]);
			break;
			default:
			case "panel":
				include("ver/panel.php");
			break;
			case "nueva":
				if(!$_GET[inc]){
					include("forms/nueva.php");
					}
				if($_GET[inc]=="si"){
					$admin->nueva($_POST[cuerpo],$_POST[titulo]);
					}
			break;
			case "salir":
				$admin->salir();			
			break;
			case "datos":
				if(!$_POST){
					include("forms/datos.php");
					}
				else{
					$admin->cambiar_datos();
					}
			break;
			case "editar_post":
				if(!$_POST){
					$admin->editar_post($_GET[cual]);
					}
				else{
					$admin->guardar_post($_GET[cual],$_POST[cuerpo],$_POST[titulo],$extras->formato($_POST[cuerpo]));
					}
			break;
			}
	break;
	}
?>
