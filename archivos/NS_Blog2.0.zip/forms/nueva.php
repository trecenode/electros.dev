<?
if(ES_ADMIN=="si"){
?>			
			<center><!---->
			<table width="650">
				<tr>
					<td>
						<div id="titulo">
							Nueva Entrada
						</div>
					<input id="titulo_nueva" type="text"><br>
<a href="javascript:caritas('[!]','cuerpo')"><img src='img/caritas/atencion.gif' border='0'></a><a href="javascript:caritas('[beso]','cuerpo')"><img src='img/caritas/beso2.gif' border='0'></a><a href="javascript:caritas('[bien]','cuerpo')"><img src='img/caritas/bien.gif' border='0'></a><a href="javascript:caritas('[bosteso]','cuerpo')"><img src='img/caritas/bosteso.gif' border='0'></a><a href="javascript:caritas('[brabo]','cuerpo')"><img src='img/caritas/brabo.gif' border='0'></a><a href="javascript:caritas('[burlon]','cuerpo')"><img src='img/caritas/burlon.gif' border='0'></a><a href="javascript:caritas('[busqueda]','cuerpo')"><img src='img/caritas/busqueda.gif' border='0'></a><a href="javascript:caritas('[callar]','cuerpo')"><img src='img/caritas/callate.gif' border='0'></a><a href="javascript:caritas('[chelear]','cuerpo')"><img src='img/caritas/chelear.gif' border='0'></a><a href="javascript:caritas('[despcion]','cuerpo')"><img src='img/caritas/desepcion.gif' border='0'></a><a href="javascript:caritas('[diablo]','cuerpo')"><img src='img/caritas/diablo.gif' border='0'></a><a href="javascript:caritas('[enojado]','cuerpo')"><img src='img/caritas/enojado.gif' border='0'></a><a href="javascript:caritas('=)','cuerpo')"><img src='img/caritas/feliz.gif' border='0'></a><a href="javascript:caritas('[fumar]','cuerpo')"><img src='img/caritas/fumar.gif' border='0'></a><a href="javascript:caritas('[gi�o]','cuerpo')"><img src='img/caritas/gino.gif' border='0'></a><a href="javascript:caritas('[gratitud]','cuerpo')"><img src='img/caritas/gratitud.gif' border='0'></a><a href="javascript:caritas('[hombre]','cuerpo')"><img src='img/caritas/hombre.gif' border='0'></a><a href="javascript:caritas('[mujer]','cuerpo')"><img src='img/caritas/mujer.gif' border='0'></a><a href="javascript:caritas('=P','cuerpo')"><img src='img/caritas/lengua.gif' border='0'></a><a href="javascript:caritas(':\'(','cuerpo')"><img src='img/caritas/llorando.gif' border='0'></a><a href="javascript:caritas('[maderado]','cuerpo')"><img src='img/caritas/madreado.gif' border='0'></a><a href="javascript:caritas('[no]','cuerpo')"><img src='img/caritas/no.gif' border='0'></a><a href="javascript:caritas('[novios]','cuerpo')"><img src='img/caritas/novios.gif' border='0'></a><a href="javascript:caritas('[ojeras]','cuerpo')"><img src='img/caritas/ojeras.gif' border='0'></a><a href="javascript:caritas('[uuff]','cuerpo')"><img src='img/caritas/ops2.gif' border='0'></a><a href="javascript:caritas('[pena]','cuerpo')"><img src='img/caritas/pena.gif' border='0'></a><br><a href="javascript:caritas('[piensa]','cuerpo')"><img src='img/caritas/piensa.gif' border='0'></a><a href="javascript:caritas('8-)','cuerpo')"><img src='img/caritas/presumido.gif' border='0'></a><a href="javascript:caritas('[programador]','cuerpo')"><img src='img/caritas/programando.gif' border='0'></a><a href="javascript:caritas('[quemando]','cuerpo')"><img src='img/caritas/quemando.gif' border='0'></a><a href="javascript:caritas('=D','cuerpo')"><img src='img/caritas/sonrisa.gif' border='0'></a><a href="javascript:caritas('[si]','cuerpo')"><img src='img/caritas/si.gif' border='0'></a><a href="javascript:caritas('[jaja]','cuerpo')"><img src='img/caritas/risa.gif' border='0'></a><a href="javascript:caritas('[sorprendido]','cuerpo')"><img src='img/caritas/sorpresa.gif' border='0'></a><a href="javascript:caritas('[triste]','cuerpo')"><img src='img/caritas/triste.gif' border='0'></a><a href="javascript:caritas('[wakala]','cuerpo')"><img src='img/caritas/wakala.gif' border='0'></a> <input type="button" class="boton" onclick="caritas('[n]texto en negritas[/n]','cuerpo')" value="[n] [/n]">
<input type="button" class="boton" onclick="caritas('[c]texto en cursiva[/c]','cuerpo')" value="[c] [/c]"> 
<input type="button" class="boton" onclick="caritas('[s]texto subrallado[/s]','cuerpo')" value="[s] [/s]">
						<textarea id="cuerpo" style="width:500px; height:110px;">Comentario</textarea><p>
						<input type="button" onclick="nueva_entrada('asdf')" value="Postear!"><br>
						<a href="javascript: ir('blog.php?accion=admin&tarea=panel')">Regresar al panel</a>
					</td>
				</tr>
			</table></center><!---->
<?
	}
else{
	include("./forms/login.php");
	}
?>