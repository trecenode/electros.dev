			<center><!---->
			<table width="650">
				<tr>
					<td>
						<div id="titulo">
							Cambiar Datos
						</div>
						<style>
						.datos_texto{
							position:absolute;
							left:0px;
							width:70px;
							height:22px;
							}
						.datos_input{	
							position:absolute;
							left:50px;
							width:auto;
							height:22px;
							}
						</style>
						<div style="position:relative;">
							<div clas="datos_text">
								<div class="texto">
									<b>Ingresa tus datos</b>
								</div>
							</div><br>
								<div class="datos_texto">
								<div class="texto">
									Mysql Host:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mysql_host" class="datos_input">
							</div><br>
							
								<div class="datos_texto">
								<div class="texto">
									Mysql User:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mysql_user" class="datos_input">
							</div><br>
							
								<div class="datos_texto">
								<div class="texto">
									Mysql Pass:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mysql_pass" class="datos_input">
							</div><br>
							
								<div class="datos_texto">
								<div class="texto">
									Mysql DB:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mysql_db" class="datos_input">
							</div><br>
							
							<!------>
							<div class="datos_texto">
								<div class="texto">
									Nombre
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="admin" class="datos_input">
							</div><br>
							
							
							<div class="datos_texto">
								<div class="texto">
									Password:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="password" class="datos_input">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Email:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="email" class="datos_input">
							</div><br>
							<!----->
							<div class="datos_texto">
								<div class="texto">
									Pagina Web:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="url" class="datos_input">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Titulo:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="titulo_d" class="datos_input">
							</div><br>
								
							<div class="datos_texto">
								<div class="texto">
									Entradas:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="entradas" class="datos_input">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Comentarios:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mensajes" class="datos_input">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Skin:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="defecto" class="datos_input">
							</div><br>
					</div><p>
					<div class="datos_input">
						<div class="texto"><br>
							<input type="button" value="Instalar" onclick="instalar()">
						</div>
					</div>
					</td>
				</tr>
			</table></center><!---->