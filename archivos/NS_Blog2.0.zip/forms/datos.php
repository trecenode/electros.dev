<?
if(ES_ADMIN=="si"){
?>			

			<center><!---->
			<table width="650">
				<tr>
					<td>
						<div id="titulo">
							Cambiar Datos
						</div>
						<style>
						.datos_texto{
							position:absolute;
							left:0px;
							width:70px;
							height:22px;
							}
						.datos_input{	
							position:absolute;
							left:50px;
							width:auto;
							height:22px;
							}
						</style>
						<div style="position:relative;">
							<div clas="datos_text">
								<div class="texto">
									<b>Configuracion Personal</b>
								</div>
							</div><br>
							<div class="datos_texto">
								<div class="texto">
									Nombre
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="admin" class="datos_input" value="<?=$datos[admin]?>">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Password:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="password" class="datos_input" value="<?=$datos[password]?>">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Email:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="email" class="datos_input" value="<?=$datos[email]?>">
							</div><br>
							<!----->
							<div class="datos_texto">
								<div class="texto">
									Pagina Web:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="url" class="datos_input" value="<?=$datos[url]?>">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Titulo:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="titulo_d" class="datos_input" value="<?=$datos[titulo]?>">
							</div><br>
								
							<div class="datos_texto">
								<div class="texto">
									Entradas:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="entradas" class="datos_input" value="<?=$datos[entradas]?>">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Comentarios:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="mensajes" class="datos_input" value="<?=$datos[mensajes]?>">
							</div><br>
							
							<div class="datos_texto">
								<div class="texto">
									Skin:
								</div>
							</div>
							<div class="datos_input">
								<input type="text" id="defecto" class="datos_input" value="<?=$datos[defecto]?>">
							</div><br>
					</div>
					<div class="datos_input">
						<div class="texto">
							<input type="button" value="Guardar Cambios" onclick="guardar_datos()">
							<a href="javascript: ir('blog.php?accion=admin&tarea=panel')">Regresar al panel</a>
						</div>
					</div>
					</td>
				</tr>
			</table></center><!---->
<?
	}
else{
	include("./forms/login.php");
	}
?>
