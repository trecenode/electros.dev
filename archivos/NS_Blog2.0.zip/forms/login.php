
<style>
#logeo{
	position:absolute;
	top:22px;
	left:275px;
	}
</style>
<div id="logeo">
	<div class="texto">
		Usuario: &nbsp;&nbsp;<input type="text" id="user" style="position: absolute; left:58px; width:150px;"><br>
		Password: <input type="password" id="pass" style="position: absolute; left:58px; top:22px;width:150px;"><p>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="button" value="Entrar!" onclick="logeo()">
	</div>
</div>
<br><br>
