<?
class admin{
	function form_login(){
		include("forms/login.php");
		}
	function login($user,$pass){
		include("datos.php");
		$msg_error;
		$msg_error = !$user ? $msg_error."No escribiste el usuario" : $msg_error;
		$msg_error = !$pass ? $msg_error."\nNo escribiste el password" : $msg_error;
		if($datos["admin"]==$user and $datos["password"]==$pass){
			setcookie("nsb_user",$user,time()+3600000);
			setcookie("nsb_pass",$pass,time()+3600000);
			echo "
			Redireccionando...";
			}
		else{
			echo "error";
			}
		}
	function nueva($cuerpo,$titulo){
			$autor = $_COOKIE["nsb_user"];
			$fecha = date("d/m/y");
			$cuerpo = str_replace("'","",$cuerpo);
			$titulo = str_replace("'","",$titulo);
			$query = "insert into ns_entradas (cuerpo,fecha,titulo) values ('$cuerpo','$fecha','$titulo')";
			@mysql_query($query) or die(mysql_error());
		}
	function salir(){
		setcookie("nsb_user");
		setcookie("nsb_pass");
		echo "Has salido correctamente del sistema... <a href=\"javascript: ir('blog.php')\">Ir a la pagina principal</a>";
		}
	function cambiar_datos(){
		$codigo = "
		<?
		\$datos[\"titulo\"] = \"$_POST[titulo]\";
		\$datos[\"admin\"] = \"$_POST[admin]\";
		\$datos[\"password\"] = \"$_POST[password]\";
		\$datos[\"email\"] = \"$_POST[email]\";
		\$datos[\"url\"] = \"$_POST[url]\";
		\$datos[\"entradas\"] = $_POST[entradas];
		\$datos[\"mensajes\"] = $_POST[mensajes];
		\$datos[\"defecto\"] = \"$_POST[skin]\";
		?>
		";
		setcookie("nsb_pass",$_POST[password],time()+3600000);
		$abrir = @fopen("datos.php","w+") or die("No se pudo conectar con datos.php");
		@fwrite($abrir,$codigo) or die("No se pudo escribie en datos.php");
		@fclode($abrir);
		echo "Se guado correctamente todo";
		}
	function editar_post($cual){
		$cual = addslashes($cual);
		if(ES_ADMIN=="si"){
			$buscar = mysql_query("select cuerpo,titulo,id from ns_entradas where id='$cual'");
			$this->leer = mysql_fetch_array($buscar);
			include("forms/editar_post.php");
			}
		else{
			echo "<div class='texto'>No puedes editar este mensaje</div>
					<hr id='separador'>";
			}
		}
	function guardar_post($cual,$cuerpo,$titulo,$cuerpo2){
		$cual = addslashes($cual);
		$cuerpo = addslashes($cuerpo);
		$titulo = addslashes($titulo);
		if(ES_ADMIN=="si"){
			$buscar = mysql_query("update ns_entradas set cuerpo='$cuerpo',titulo='$titulo' where id='$cual'");
			$buscar = mysql_query("select * from ns_entradas where id='$cual'");
			$this->leer = mysql_fetch_array($buscar);
			$this->leer["cuerpo"] = $cuerpo2;
			include("ver/entrada.php");
			}
		else{
			echo "<div class='texto'>No puedes editar este mensaje</div>
					<hr id='separador'>";
			}
		}
	}
?>
