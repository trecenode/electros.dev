<?
class tareas_blog{
	function ordenar_entradas($por){
		$por = addslashes($por);
		switch($por){
			default:
				$this->sentencia = "select * from ns_entradas order by id desc";
				$this->orden[$por] = "selected";
			break;
			case "id_asc":
				$this->sentencia = "select * from ns_entradas order by id asc";
				$this->orden[$por] = "selected";
			break;
			case "autor_desc":
				$this->sentencia = "select * from ns_entradas order by autor desc";
				$this->orden[$por] = "selected";
			break;
			case "autor_asc":
				$this->sentencia = "select * from ns_entradas order by autor asc";
				$this->orden[$por] = "selected";
			break;
			}
		}
	function ordenar_comentarios($por,$cual){
		$por = addslashes($por);
		$cual = addslashes($cual);
		switch($por){
			default:
				$this->sentencia = "select * from ns_comentarios where id='$cual' order by num desc";
				$this->orden[$por] = "selected";
			break;
			case "id_asc":
				$this->sentencia = "select * from ns_comentarios where id='$cual' order by num asc";
				$this->orden[$por] = "selected";
			break;
			case "autor_desc":
				$this->sentencia = "select * from ns_comentarios where id='$cual' order by autor desc";
				$this->orden[$por] = "selected";
			break;
			case "autor_asc":
				$this->sentencia = "select * from ns_comentarios where id='$cual' order by autor asc";
				$this->orden[$por] = "selected";
			break;
			}
		}
	function comentar($autor,$cuerpo,$id,$cuerpo2){
			include("datos.php");
			if(ES_ADMIN=="si"){
				$autor = "||@DMIN||";
				}
			else{
				$autor = $autor==$datos["admin"] ? "@nonimo" : $autor;
				$autor = $autor=="||@DMIN||" ? "@nonimo" : $autor;
				}
			include("datos.php");
			$fecha = date("d/m/y");
			$autor = addslashes($autor);
			$cuerpo = addslashes($cuerpo);
			$id = addslashes($id);
			$temp = mysql_query("select titulo from ns_entradas where id='$id'");
			$asf = mysql_fetch_array($temp);
			$s = "insert into ns_comentarios (autor,cuerpo,id,fecha) values ('$autor','$cuerpo','$id','$fecha')";
			mysql_query($s) or die(mysql_error());
			$this->leer["fecha"] = $fecha;
			$this->leer["autor"] = $autor;
			$this->leer["cuerpo"] = $cuerpo2;
			$this->leer["titulo"] = $asf["titulo"];;
			include("ver/comentario.php");
		}
	function buscar($que){
		$que = addslashes($que);
		setcookie("nsb_busc",$que,time()+3600000);
		$query = "select * from ns_comentarios where cuerpo like '%$que%' or autor like '%$que%'";
		$this->sentencia = $query;
		}
	}
?>