<html>
<head>
<title>Instalacion de NS Blog 2.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<script src="js/otros.js"></script>
<script src="js/ajax.js"></script>
<style>
<?=file_get_contents("skins/azul/index.css");?>
</style>
<div id="header">
	<div onclick="javascript: skin('rojo')" id="skin_rojo"></div>
	<div onclick="javascript: skin('verde')" id="skin_verde"></div>
	<div onclick="javascript: skin('azul')" id="skin_azul"></div>
	<div id="header_titulo">
		Instalar
	</div>
	<div id="header_frase">
		NS Blog 2.0
	</div>
</div>
<div id="contenido">
	<div id="arribas">
		<div class="arriba_enlaces">
			Instalacion ::
		</div>
	</div>
	<div id="cont_arriba">
	</div>
	<div id="cont">
		<div id="contenido_central"><!---- Contenido----->
			<?
					include("forms/instalar.php");
			?>
		</div><!----/contenido------>
	</div>
	<div id="cont_abajo"></div>
	<div class="texto" style="text-align:center;">
		(C) 2005 Desarrollado por <a href="http://www.nosferatusoft.com.ar">NosferatuSoft</a><br>
		1024 x 768px :: <a href="http://www.getfirefox.com">Firefox</a><br>
		<a href="http://nsblog.nosferatusoft.com.ar">Powered By NS Blog 2.0</a> 
	</div>
</div>
<div id="skin"></div>
