<?
class extras{
	function paginar($sen,$archivo,$cuantos,$por){
		foreach($_GET as $nombre => $cont){
			$ir.="$nombre=$cont&";
			}
		$orden_por = $_GET[por];
		$ir = str_replace("cant=".$_GET["cant"],"",$ir);
		$ir = str_replace("por=$orden_por","",$ir);
		$sig = $por + $cuantos;
		$ant = $por - $cuantos;
		$this->num = 0;
		$por = !$por ? 0 : $por;
		$this->enlace_sig = "<a href='index.php?$ir"."cant=$sig&por=$orden_por"."'> $cuantos Siguientes</a>";
		$this->enlace_ant = "<a href='index.php?$ir"."cant=$ant&por=$orden_por"."'> $cuantos Anteriores</a>";
		if(!is_numeric($por) or $por==0){
			$this->enlace_ant = "";
			}
		$query = mysql_query("$sen limit $por,$cuantos") or die(mysql_query());
		while($this->leer = mysql_fetch_array($query)){
				include($archivo);
				$this->num++;
			}
		$this->resultados = mysql_num_rows($query);
		$this->enlace_sig = $this->num==$cuantos ? $this->enlace_sig : "";
		}
//////
	function formato($que){
		$que = htmlspecialchars($que);
		$que = preg_replace("/\[color=((#)?[0-9a-z]+)\](.+)\[\/color\]/iU","<font color=\\1>\\3</font>",$que);
		$que = str_replace("[n]","<b>",$que);
		$que = str_replace("[c]","<i>",$que);
		$que = str_replace("[s]","<u>",$que);
		$que = str_replace("[/n]","</b>",$que);
		$que = str_replace("[/c]","</i>",$que);
		$que = str_replace("[/s]","</u>",$que);
		$que = str_replace("[img]","<img src='",$que);
		$que = str_replace("[/img]","'>",$que);
		$que = preg_replace("/http:\/\/[^\s]+/i","<a href=\"\\0\">\\0</a>",$que);
		$que = nl2br($que);
		$caras = Array(
			"[!]" => "atencion.gif",
			"[beso]" => "beso2.gif",
			"[bien]" => "bien.gif",
			"[bosteso]" => "bosteso.gif",
			"[brabo]" => "brabo.gif",
			"[burlon]" => "burlon.gif",
			"[busqueda]" => "busqueda.gif",
			"[callar]" => "callate.gif",
			"[chelear]" => "chelear.gif",
			"[despcion]" => "desepcion.gif",
			"[diablo]" => "diablo.gif",
			"[enojado]" => "enojado.gif",
			"=)" => "feliz.gif",
			"[fumar]" => "fumar.gif",
			"[gi�o]" => "gino.gif",
			"[gratitud]" => "gratitud.gif",
			"[hombre]" => "hombre.gif",
			"[mujer]" => "mujer.gif",
			"=P" => "lengua.gif",
			":\'(" => "llorando.gif",
			"[maderado]" => "madreado.gif",
			"[no]" => "no.gif",
			"[novios]" => "novios.gif",
			"[ojeras]" => "ojeras.gif",
			"[uuff]" => "ops2.gif",
			"[pena]" => "pena.gif",
			"[piensa]" => "piensa.gif",
			"8-)" => "presumido.gif",
			"[programador]" => "programando.gif",
			"[quemando]" => "quemando.gif",
			"=D" => "sonrisa.gif",
			"[si]" => "si.gif",
			"[jaja]" => "risa.gif",
			"[sorprendido]" => "sorpresa.gif",
			"[triste]" => "triste.gif",
			"[wakala]" => "wakala.gif");
		foreach($caras as $comando => $src){
			$que = str_replace($comando,"<img src='img/caritas/$src' border='0'>",$que);
			}
		return $que;
		}
	function es_admin(){
		include("datos.php");
		$this->user_c = $_COOKIE["nsb_user"];
		$this->pass_c = $_COOKIE["nsb_pass"];
		$this->autentico = false;
		if($this->user_c == $datos["admin"] and $this->pass_c == $datos["password"]){
			define("ES_ADMIN","si");
			}
		else{
			define("ES_ADMIN","no");
			}
		}
}
?>
