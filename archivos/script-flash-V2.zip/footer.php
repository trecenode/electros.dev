<?

//No remuevas los creditos de este texto sin Consentimiento del Autor
//Solo puedes remover el hipervinculo a la pagina de dise�ador si cambias el template

$search_ip = search_db("visitantes", "ip", $ip_user);

if($search_ip >= 1)
{
   M_Query("UPDATE visitantes SET tiempo = '$act_time' WHERE ip = '$ip_user'");	
}
else
{
  M_Query("INSERT INTO visitantes (id, ip, tiempo) VALUES ('', '$ip_user', '$act_time')");	
}
mysql_close($conect);

$tiempo_final = tiempo_carga();
$carga_pagina = round($tiempo_final - $tiempo_inicio, 4);
echo '<font face="Verdana" size="2" color="#FFFFFF"><center>';
echo "Pagina creada en : [ <b>$carga_pagina</b> ] segundos con [ <b>$num_querys</b> ] consultas<br>";
echo 'Copyright 2006 <a href="http://www.celwebs.com">Programacion</a>';
// Autor del Template
echo ' - <a href="http://www.adolfo187.org">'.htmlentities("Dise�o Base").'</a>';
//
echo '</center></font>';


?>