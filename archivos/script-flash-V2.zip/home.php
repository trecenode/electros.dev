<?

if(!defined("flash_script")) die("Error");

$tipo = trim($_GET['modulo']);




if(empty($tipo)) $tipo = "news";


	$dir_sec = "sec/$tipo.php";
	
	//Verificamos que el archivo exista y buscamos posibles intentos de RFI
	if(file_exists($dir_sec) && !eregi("http://", $tipo))
	     {
		    include($dir_sec);   
	     }
	 else
	     {
		     echo tabla_cont("Error", "<center>No se encontro la pagina.<center>");
	     }
	    	
	


?>