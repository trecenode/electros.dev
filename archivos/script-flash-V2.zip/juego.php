<?
include 'config.inc.php';
include 'class/funciones.php';
include 'class/temp.php';
$tiempo_inicio = tiempo_carga();
    $id_get = trim($_GET['id']);
    $nom_categ = trim($_GET['name']);


    
    $select_game = M_Query("SELECT id, name, descg, categ, file_dir, img_dir, votos, puntos, tipo_swf, tipo_img, size, width, height FROM juegos WHERE (id = '$id_get') AND (tipo_id = '0' AND active = '1') LIMIT 1");

    if(mysql_num_rows($select_game) == 1)
    {
	    $juego = mysql_fetch_assoc($select_game);
	    mysql_free_result($select_game);
	    $id = $juego['id'];
	    $nombre = $juego['name'];
	    $categoria = $juego['categ'];
	    $descripcion = $juego['descg'];
	    $imagen = $juego['img_dir'];
	    $swf = $juego['file_dir'];
	    $votos = $juego['votos'];
	    $puntos = $juego['puntos'];
	    $tipo_archivo = $juego['tipo_swf'];
	    $tipo_dimensiones = $juego['size'];
        
	  
	    $valorado = ($votos == 0) ? 'No Valorado' : $puntos / $votos;
	    
	    $titulo = $web.' Juego '.$nombre;
	    
	    $select_cate = M_Query("SELECT id, nombre FROM categ WHERE id = '$categoria' LIMIT 1");
	    $fetch_cat = mysql_fetch_assoc($select_cate);
	    
	    if(!$mod_rewrite)
	        $_categ = '<a href="index.php?modulo=categ&id='.$fetch_cat['id'].'&name='.mod_s($fetch_cat['nombre']).'">'.$fetch_cat['nombre'].'</a>';
	     else
	        $_categ = '<a href="categoria-'.$fetch_cat['id'].'-'.mod_rew($fetch_cat['nombre']).'.html">'.$fetch_cat['nombre'].'</a>';
	       
	    
	    if($tipo_archivo == 1 || $tipo_archivo == 2)
	    {
		    if($tipo_dimensiones == 1)
		    {
		           list($ancho, $alto, $tip, $atr) = getimagesize($swf);
	        }
		    elseif($tipo_dimensiones == 2)
		    {
		           	    $ancho = $juego['width'];
	                    $alto = $juego['height'];
            }
	        else
	        {
	                    $ancho = $width;
	                    $alto = $height;
            }
	    
          $file_size = ($tipo_archivo == 1) ? view_size(filesize($swf)) : 'No disponible.';

	      $content .= '<center><object id=FlashGame classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="'.$ancho.'" height="'.$alto.'">
                          <param name=movie value="'.$swf.'">
                          <param name=quality value=high>
		    	          <embed src="'.$swf.'" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="'.$ancho.'" height="'.$alto.'" class="FlashGame">
                          </embed> 
                        </object><center>';
	      
	      
	      $content .= '<br>'.tabla_cont('Juego '.$nombre, '<img align="left" src="'.$imagen.'" alt="Flash '.$nombre.'" title="Flash '.$nombre.'" />'.$descripcion.'<br>Valorado: '.round($valorado, 2).'<br>Categoria: '.$_categ.'<br>Peso del Archivo: '.$file_size);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><? echo $titulo; ?></title>
<link rel="StyleSheet" href="imagenes/style.css" type="text/css">

</head>


<body>
<table width="776" border="0" align="center" cellpadding="0" cellspacing="0" height="623">
  <tr>
    <td height="250" background="imagenes/h01.jpg">&nbsp;</td>
  </tr>
  <tr>
    <td background="imagenes/bg.jpg" height="235">
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="0" valign="top">
        
          <!-- BLOQUES IZQUIERDA -->
                    

     
         <!-- FIN BLOQUES IZQUIERDA -->

           </td>
            <td valign="top">
        <? 
        echo $content; 

        ?>
        <!-- <? ?> -->
                
        </td>
        <td width="0" valign="top">
        
        <!-- BLOQUES DERECHOS -->
        
              <?
              include 'block/menu.php';
              ?>
              <?
              include 'block/opc-juego.php';
              ?>
              <?
              include 'block/voto.php';
              ?>
              <?
              include 'block/search.php';
              ?>
              <?
              include("block/cater-flash.php");
              ?>

       
        
         <!-- FIN BLOQUES DERECHOS -->
        
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="138" background="imagenes/f01.jpg">&nbsp;</td>
  </tr>
</table>
<?
    }
    else
    {
  echo '<html>
        <head>
         <title>'.$titulo.'</title>
          <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
          </head>
          <frameset rows="80, *">
          <frame src="iframe.php" frameborder="0" noresize="noresize" marginwidth="0" marginheight="0">
          <frame src="'.$swf.'" frameborder="0" noresize="noresize" marginwidth="0" marginheight="0">
          <noframes>
          	<body>
            	<p>Actualiza tu Navegador porque este no sporta Marcos<br />

                	</p>
              	</body>
          	</noframes>
          </frameset>';
	    
    }
    
}
 else
    {

    }
    
include 'footer.php';
?>
</body>
</html>