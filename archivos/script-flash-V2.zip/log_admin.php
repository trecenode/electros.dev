<?
session_start();
include('config.inc.php');
include("class/funciones.php");
$check_scode = $_SESSION['secure_code'];

if($_POST['log_submit'])
{
	$log_name = trim($_POST['log_name']);
	$log_pwd = trim($_POST['log_pwd']);
	$log_sec = intval(trim($_POST['log_sec']));
	
	if(empty($log_name)) $error .= 'Error: Debes escribir tu nombre de administrador.<br>';
	if(empty($log_pwd)) $error .= 'Error: Debes escribir tu password de administrador.<br>';
	
	if($gd_lib)
	{
	if(empty($log_sec)) $error .= 'Error: Debes escribir el codigo de seguridad.<br>';
	if($log_sec != $check_scode) $error .= 'Error: Codigo de Seguridad Incorrecto.<br>';
	}
	
	if(isset($error))
	  {
		  echo '<center><font face="Verdana" size="2" color="#000000"><b>'.$error.'<br><a href="admin.php">Volver</a></b></font></center>'; 
	  }
	else
	  {
		 $log_pwd = md5($log_pwd);
	     $check_datos = M_Query("SELECT nombre, password FROM admins WHERE nombre = '$log_name' AND password = '$log_pwd' LIMIT 1");
	         if(mysql_num_rows($check_datos) == 1)
	             {
		             $datos_cookie = base64_encode($log_name.$cookie_sep.$log_pwd);
		             setcookie("script_admin", $datos_cookie, time()+(604800*2));
		             header("Location: admin.php");
	             }
	         else
	             {
		              echo '<center><font face="Verdana" size="2" color="#000000"><b>Nombre o Password Incorrectos.<br><a href="admin.php">Volver</a></b></font></center>'; 
	             }
      }
	
}

mysql_close($conect);

?>