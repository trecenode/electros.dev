<?

include('config.inc.php');
include("class/funciones.php");

$tipo = trim($_GET['tipo']);
$id = intval(trim($_GET['id']));

    if(empty($tipo)) $error .= 'Error: No esta definido el tipo de Link.<br>';
    if($tipo != 'in' && $tipo != 'out') $error .= 'Error: Tipo de Link no Valido.<br>';
	if(empty($id)) $error .= 'Error: Id No definido.<br>';
	
	if(isset($error))
	  {
		  echo '<center><font face="Verdana" size="2" color="#000000"><b>'.$error.'<br><a href="'.$url_web.'">Volver</a></b></font></center>'; 
	  }
	else
	  {
		  
		$up_end = M_Query("SELECT url FROM enlaces WHERE id = '$id' AND activo = '1' LIMIT 1");
        $enl_f = mysql_fetch_assoc($up_end);
        
	     if($tipo == 'out')
	     {
		      $field = "vistas";
		      $link = $enl_f['url'];
	     }
	     elseif($tipo == 'in')
	     {
		      $field = "entrantes";
		      $link = $url_web;
	     }
	     
	        
	         if(mysql_num_rows($up_end) == 1)
	             {
                    $update_enlace = M_Query("UPDATE enlaces SET $field = $field+1 WHERE id = '$id'");
		             header("Location: $link");
	             }
	         else
	             {
		              echo '<center><font face="Verdana" size="2" color="#000000"><b>No se encontro el enlace o esta Inactivo.<br><a href="'.$url_web.'">Volver</a></b></font></center>'; 
	             }
          }
	


mysql_close($conect);

?>