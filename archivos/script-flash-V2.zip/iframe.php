<!--

Modifica esta pagina a tu gusto
Es la que se mostrara en la parte
superior de los juegos de url
externa.

-->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#006699">
<center>
<b><font face="Verdana" size="5" color="#FFFFFF">Publicidad <br> Banner de 468x60</font></b>
</center>
</body>
</html>