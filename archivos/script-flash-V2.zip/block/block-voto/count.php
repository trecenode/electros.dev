<?

include '../../config.inc.php';
include '../../class/funciones.php';

if(!defined("flash_script")) die("Error");

$id_juego = intval($_GET['id']);
$puntos = intval($_GET['puntos']);

$votos_juegos = M_Query("SELECT name FROM juegos WHERE id = '$id_juego' AND (active = '1' AND tipo_id = '0') LIMIT 1");

if(mysql_num_rows($votos_juegos) == 1)
{
	$_juegod = mysql_fetch_assoc($votos_juegos);
	$_juegon = $_juegod['name'];
	
	echo '<title>Votar Juego '.$_juegon.'</title>';
	echo '<body bgcolor="#000000"';
	
	$up_point = M_Query("UPDATE juegos SET votos = votos + 1, puntos = puntos + $puntos WHERE id = '$id_juego'");
	
	if($up_point)
	   echo '<center><font color="#FFFFFF" face="Verdana" size="2"> [ Juego '.$_juegon.' votado correctamente ] </font></center>';
	else
	   echo '<center><font color="#FFFFFF" face="Verdana" size="2"> [ Error  al votar el juego '.$_juegon.' ] </font></center>';
}
else
{
	echo '<center><font face="Verdana" size="2"> [ No se encontro el juego ] </font></center>';
}



?>