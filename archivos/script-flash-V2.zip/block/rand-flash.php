<?

if(!defined("flash_script")) die("Error");
unset($content);

$s_ranf = M_Query("SELECT id, name, img_dir FROM juegos WHERE (active = '1' AND tipo_id = '0') ORDER BY RAND() LIMIT 1");

if(mysql_num_rows($s_ranf) >= 1)
{
	
          $_rflash = mysql_fetch_assoc($s_ranf);
               
	           $content .= '<center><img src="'.$_rflash['img_dir'].'" alt="'.$_rflash['name'].'" title="'.$_rflash['name'].'"></center><br>';
	            
	            if(!$mod_rewrite)
	                $content .= '<center>[ <a href="juego.php?id='.$_rflash['id'].'&name='.mod_s($_rflash['name']).'">'.$_rflash['name'].'</a> ]</center>';
	            else
	                $content .= '<center>[ <a href="juego-'.$_rflash['id'].'-'.mod_rew($_rflash['name']).'.html">'.$_rflash['name'].'</a> ]</center>';
               	
	
}
else
{
	$content .= '<center>[ No hay juegos ]<center>';	
}

mysql_free_result($s_ranf);

echo tabla_blok('Juego Aleatorio', $content);

?>