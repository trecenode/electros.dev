<?

if(!defined("flash_script")) die("Error");
unset($content);

$url_contacto = (!$mod_rewrite) ? "index.php?modulo=contacto" : "contacto.html" ;
$url_buscador = (!$mod_rewrite) ? "index.php?modulo=buscador" : "buscador.html" ; 

$content = '- <a href="index.php">Inicio</a><br>
            - <a href="'.$url_contacto.'">Contactanos</a><br>
            - <a href="'.$url_buscador.'">Buscador</a><br>
            - <a href="javascript:window.external.AddFavorite('."'$url_web'".', '."'$web'".')">Agregar a Favoritos</a><br>

            ';
echo tabla_blok('Principal', $content);

?>