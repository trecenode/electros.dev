<?

if(!defined("flash_script")) die("Error");
unset($content);

$s_popf = M_Query("SELECT id, name FROM juegos WHERE (active = '1' AND tipo_id = '0') AND (puntos > '0' AND votos > '0') ORDER BY puntos % votos DESC LIMIT 10");

if(mysql_num_rows($s_popf) >= 1)
{
	
           while($_pflash = mysql_fetch_assoc($s_popf))
               {
	               if(!$mod_rewrite)
	                 $content .= '- <a href="juego.php?id='.$_pflash['id'].'&name='.mod_s($_pflash['name']).'">'.$_pflash['name'].'</a><br>';
	               else
	                 $content .= '- <a href="juego-'.$_pflash['id'].'-'.mod_rew($_pflash['name']).'.html">'.$_pflash['name'].'</a><br>';
               }	
	
}
else
{
	$content .= '<center>[ No hay juegos ]<center>';	
}

mysql_free_result($s_popf);

echo tabla_blok('Juegos Populares', $content);
?>