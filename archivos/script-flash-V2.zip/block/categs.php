<?

if(!defined("flash_script")) die("Error");
unset($content);

$m_categs = M_Query("SELECT id, nombre FROM categ WHERE active = '1' ORDER BY id ASC");

if(mysql_num_rows($m_categs) >= 1)
{
	
           while($_acate = mysql_fetch_assoc($m_categs))
               {
	
	             if(!$mod_rewrite)
	              $content .= '- <a href="index.php?modulo=categ&id='.$_acate['id'].'&name='.mod_s($_acate['nombre']).'">'.$_acate['nombre'].'</a><br>';
	             else
	              $content .= '- <a href="categoria-'.$_acate['id'].'-'.mod_rew($_acate['nombre']).'.html">'.$_acate['nombre'].'</a><br>';
               }	
	
}
else
{
	$content .= '[ No Hay Categorias ]';	
}

mysql_free_result($m_categs);

echo tabla_blok('Categorias', $content);

?>