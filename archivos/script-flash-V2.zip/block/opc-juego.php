<?

if(!defined("flash_script")) die("Error");
unset($content);

$tamano = htmlentities("Tama�o");


$juego_nop = (!$mod_rewrite) ? "juego.php?id=$id&name=".mod_s($nombre) : "juego-$id-".mod_rew($nombre).".html";
$juego_rec = (!$mod_rewrite) ? "index.php?modulo=recomendar&rid=$id" : "recomendar-$id.html";

$content .= implode(file("block/javascript.txt"));
$content .= '
            - <a href="javascript:_SWFZoom(1)">[ Aumentar '.$tamano.' ]</a><br>
            - <a href="javascript:_SWFZoom(0)">[ Disminuir '.$tamano.' ]</a><br>
            - <a href="javascript:window.external.AddFavorite('."'$url_web/$juego_nop'".', '."'$nombre'".')">[ Agregar a Favoritos ]</a><br>
            - <a href="'.$juego_rec.'">[ Recomendar Juego ]</a>
             ';

echo tabla_blok('Opciones del Juego', $content);

?>