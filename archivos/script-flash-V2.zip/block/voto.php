<?

if(!defined("flash_script")) die("Error");
unset($content);

//Este bloque solo puede ser usado en el archivo juego.php

$burl_action = (!$mod_rewrite) ? "index.php?modulo=buscador" : "buscador.html";



$content = '<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <form name="votos_m">
  <tr>
    <td width="100%">
    <font face="Verdana" size="2"><center>Puntos:<br></font>
    <select size="1" name="voto_check">
    <option value="1">1</option>
    <option value="2">2</option>
    <option selected value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
     </select>
     </center>
    </td>
  </tr>
  <tr>
    <td width="100%"><center><input type="button" value="Votar" onClick="javascript:PopWindow('."'$id'".')"></center></td>
  </tr>
  </form>
</table>';

echo tabla_blok('Votar Juego', $content);

?>