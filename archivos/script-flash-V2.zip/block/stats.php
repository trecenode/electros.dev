<?

if(!defined("flash_script")) die("Error");
unset($content);

$_minutest = $_minutes * 300;
$_stime = $act_time - $_minutest;


$_s_jugadores = M_Query("SELECT NULL FROM visitantes WHERE tiempo >= '$_stime'");
$_jugadoreson = mysql_num_rows($_s_jugadores);
mysql_free_result($_s_jugadores);

$_total_juegos = M_Query("SELECT NULL FROM juegos WHERE active = '1' AND tipo_id = '0'");
$_totalf_juegos = mysql_num_rows($_total_juegos);
mysql_free_result($_total_juegos);

$content = '<font face="Verdana" size="1">
           - Jugadores Online: '.$_jugadoreson.'<br>
           - Total de Juegos: '.$_totalf_juegos.'<br>
           ';

echo tabla_blok('Estadisticas', $content);

?>