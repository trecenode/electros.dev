<?

//Este bloque solo se puede usar desde juegos.php en el directorio principal.

if(!defined("flash_script")) die("Error");
unset($content);

$id_categ = $categoria;

$s_catef = M_Query("SELECT id, name FROM juegos WHERE (categ = '$id_categ' AND id != '$id') AND (active = '1' AND tipo_id = '0') ORDER BY RAND() LIMIT 10");

if(mysql_num_rows($s_catef) >= 1)
{
	
           while($_rcflash = mysql_fetch_assoc($s_catef))
               {
	               if(!$mod_rewrite)
	                 $content .= '- <a href="juego.php?id='.$_rcflash['id'].'&name='.mod_s($_rcflash['name']).'">'.$_rcflash['name'].'</a><br>';
	               else
	                 $content .= '- <a href="juego-'.$_rcflash['id'].'-'.mod_rew($_rcflash['name']).'.html">'.$_rcflash['name'].'</a><br>';
               }	
	
}
else
{
	$content .= '<center>[ No hay juegos ]<center>';	
}

mysql_free_result($s_catef);

echo tabla_blok('Juegos Similares', $content);
?>