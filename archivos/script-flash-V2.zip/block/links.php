<?

if(!defined("flash_script")) die("Error");
unset($content);

$m_links = M_Query("SELECT id, titulo, url, tipo, vistas, entrantes FROM enlaces WHERE activo = '1' ORDER BY id ASC");

if(mysql_num_rows($m_links) >= 1)
{
	
           while($_links = mysql_fetch_assoc($m_links))
               {
	              
	              if($_links['tipo'] == 1)
	                 $content .= '- <a href="'.$_links['url'].'">'.$_links['titulo'].'</a>';
	              else
	                $content .= '- <a href="links.php?tipo=out&id='.$_links['id'].'" title="Pagina: '.$_links['titulo']."\n".'Entrantes: '.$_links['entrantes']."\n".'Salientes: '.$_links['vistas'].'">'.$_links['titulo'].'</a>';
	             
               }	
	
}
else
{
	$content .= '[ No Hay Enlaces ]';	
}

mysql_free_result($m_links);


echo tabla_blok('Enlaces', $content);

?>