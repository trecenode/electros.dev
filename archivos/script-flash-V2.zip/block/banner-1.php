<?

if(!defined("flash_script")) die("Error");
unset($content);

//Ejemplo 1 de como poner publicidad javascript en los bloques
//Este archivo es solo de ejemplo, puede borrarlo, modificarlo o lo que quieras.

$content .= '<center>'.implode(file("block/publi1.txt")).'</center>';

echo tabla_blok('Adsense', $content);

?>