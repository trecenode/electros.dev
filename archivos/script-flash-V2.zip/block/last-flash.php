<?

if(!defined("flash_script")) die("Error");
unset($content);

$s_lastf = M_Query("SELECT id, name FROM juegos WHERE active = '1' AND tipo_id = '0' ORDER BY id DESC LIMIT 10");

if(mysql_num_rows($s_lastf) >= 1)
{
	
           while($_lflash = mysql_fetch_assoc($s_lastf))
               {
	
	             if(!$mod_rewrite)
	               $content .= '- <a href="juego.php?id='.$_lflash['id'].'&name='.mod_s($_lflash['name']).'">'.$_lflash['name'].'</a><br>'."\n";
	             else
	               $content .= '- <a href="juego-'.$_lflash['id'].'-'.mod_rew($_lflash['name']).'.html">'.$_lflash['name'].'</a><br>'."\n";
               }	
	
}
else
{
	$content .= '<center>[ No hay juegos ]<center>';	
}

mysql_free_result($s_lastf);

echo tabla_blok('Ultimos Juegos', $content);

?>