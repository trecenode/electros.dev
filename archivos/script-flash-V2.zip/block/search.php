<?

if(!defined("flash_script")) die("Error");
unset($content);



$burl_action = (!$mod_rewrite) ? "index.php?modulo=buscador" : "buscador.html";


$content .= '<center><form method="POST" action="'.$burl_action.'">
  <input type="hidden" name="add_desc" value="NOT">
  <input type="hidden" name="add_categ" value="NOT">
  <font face="Verdana" size="2">Buscar:</font><br>
  <input type="text" name="by_name" size="10"><br>
  <input type="submit" value="Buscar" name="search_send">
  </form><br><a href="'.$burl_action.'">[ Busqueda Avanzada ]</a></a><center>';

echo tabla_blok('Buscador', $content);

?>