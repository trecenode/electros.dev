<?
if(!defined("flash_script")) die("Error");


$body_negadmin = '<html>
<head>
<title>Agregar Administrador</title>
</head>

<body bgcolor="#000000">
<form method="POST" action="admin.php">
<table align="center" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 3px double #FF9900" bordercolor="#111111" width="400" id="AutoNumber1" height="76" bgcolor="#006699">
  <tr>
    <td colspan="2" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="394" height="16">
    <p align="center"><font size="2">Agrega el Primer Administrador</font></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Nombre:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="text" size="20" name="fi_name"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Password:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="password" size="20" name="fi_pwd"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Confirmar Password:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="password" size="20" name="fi_cpwd"></td>
  </tr>
   <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Correo:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="text" size="20" name="fi_mail"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Codigo de Seguridad:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="text" size="10" name="fi_sec"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" colspan="2" width="394" height="3">
    <p align="center"><img src="class/sec_code.php" alt="Codigo de Seguridad" border="0"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" colspan="2" width="394" height="13">
    <p align="center"><input type="submit" size="20" value="Agregar" name="fi_submit"></td>
  </tr>
</table>
</form>

</body>
</html>';

$have_admins = M_Query("SELECT NULL FROM admins");

if(mysql_num_rows($have_admins) <= 0)
{
	session_start();
	
	if(!$_POST['fi_submit'])
	   {
	      die($body_negadmin);
       }
    else
       {

                 $nom_admin = trim($_POST['fi_name']);
                 $pass_admin = trim($_POST['fi_pwd']);
                 $cpass_admin = trim($_POST['fi_cpwd']);
                 $mail_admin = trim($_POST['fi_mail']);
                 $sec_admin = trim($_POST['fi_sec']);

                 if(empty($nom_admin)) $error .= 'Error: Debes escribir un nombre para el administrador.<br>';
                 if(empty($pass_admin)) $error .= 'Error: Debes escribir un password para el administrador.<br>';
                 if(empty($cpass_admin)) $error .= 'Error: Debes confirmar el password para el administrador.<br>';
                 if(empty($mail_admin)) $error .= 'Error: Debes escribir una cuenta de correo para el administrador.<br>';
                 if(empty($sec_admin)) $error .= 'Error: Debes escribir el codigo de Seguridad.<br>';
                 if(!es_correo($mail_admin)) $error .= 'Error: Correo no valido.<br>';
                 if($pass_admin != $cpass_admin) $error .= 'Error: Las Contrase�as no coinciden.<br>';
                 if($sec_admin != $_SESSION['secure_code']) $error .= 'Error: Codigo de Seguridad Incorrecto.<br>';

                 if($password_seguro == true)
                 {
                 if(!is_alphanum($pass_admin)) $error .= 'Error: Password Inseguro, debe ser Alfanumerico (Modo Password Seguro).<br>'; 
                 if(strlen($pass_admin) < 6) $error .= 'Error: Password Inseguro, debe ser mayor de 6 caracteres (Modo Password Seguro).<br>'; 
                 }

        if(isset($error))
        {
	     echo '<center><font face="Verdana" size="2" color="#000000"><b>'.$error.'<br><a href="admin.php">Volver</a></b></font></center>'; 
	    }
        else
        {
	    $md5_pass_admin = md5($pass_admin);
	    $add_admin = M_Query("INSERT INTO admins (id, nombre, password, mail, nivel) VALUES ('', '$nom_admin', '$md5_pass_admin', '$mail_admin', '1')");
	                  
	                   if($add_admin == true)
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#000000"><b>Administrador Agregado Con Exito<br><a href="admin.php">Volver</a></b></font></center>';
	                      }
	                   else
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#000000"><b>Error al Agregar al Administrador.<br>'.MySQL_ERROR().'<br><a href="admin.php">Volver</a></b></font></center>';   
	                      }
        }


	  exit;   
  }
}

	mysql_free_result($have_admins);



?>