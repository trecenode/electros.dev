<?

session_start();

$code = rand(100000, 999999);

$_SESSION['secure_code'] = $code;

$img_create = imagecreatefromjpeg('code_bg.jpg');

Header("Content-type: image/jpeg");

ImageColorAllocate($img_create, 0,0,0);

$c_red = ImageColorAllocate($img_create, 0, 0, 0);

imagestring($img_create, 10, 10, 3, $_SESSION['secure_code'], $c_red);

imagejpeg($img_create, '', 5000);

ImageDestroy($img_create);


?>