<?
if(!defined("flash_script")) die("Error");



$act_time = date("U");
$ip_user = $_SERVER['REMOTE_ADDR'];
$width = intval($width);
$height = intval($height);
$cookie_sep = ";";

if(empty($ip_user)) $ip_user = getenv("REMOTE_ADDR");

function M_Query ($query)
{
global $num_querys, $conect;
$num_querys++;
$query = trim($query);
$ejecute_query = MySql_Query($query, $conect);	
return $ejecute_query;	
}

function mod_s ($text)
{
    $text = mysql_real_escape_string($text);
    $text = strtolower($text);
    $text = urlencode($text);
	return $text;
}

function tiempo_carga()
{
$micro_time = Microtime(); 
$micro_ex = explode(" ", $micro_time); 
$final_time = $micro_ex[1] + $micro_ex[0]; 
return $final_time;
}


function search_db ($re1, $re2, $re3)
{
	$Select = M_Query("SELECT $re2 FROM $re1 WHERE $re2 = '$re3'");
	$fin = MySql_Num_Rows($Select);
	MySql_Free_Result($Select);
return $fin;	
}

function borrar_acentos ($texto) {
static $acentos = "����������������������������������������";
static $validos = "aeiouAEIOUaeiouAEIOUaeiouAEIOUaeiouAEIOU";
return strtr($texto, $acentos, $validos);
}


function format($mens) 
{ 
$mens = str_replace ('<', '/', $mens); 
$mens = str_replace ('>', '/', $mens);
return $mens;
} 

function mod_rew ($texto){
$texto = str_replace("[", "", $texto);
$texto = str_replace("]", "", $texto);
$texto = str_replace("(", "", $texto);
$texto = str_replace(")", "", $texto);
$texto = str_replace("�", "n", $texto);
$texto = str_replace(" ", "-", $texto);
$texto = str_replace("?", "", $texto);
$texto = str_replace("�", "", $texto);
$texto = str_replace(":", "", $texto);
$texto =  borrar_acentos($texto);
$texto = strtolower($texto);
return $texto;
}



	
	function view_size($size) 
	{
    $mb = 1024*1024;
    if ( $size > $mb ) {
        $mysize = sprintf ("%01.2f",$size/$mb) . " Mb.";
    } elseif ( $size >= 1024 ) {
        $mysize = sprintf ("%01.2f",$size/1024) . " Kb.";
    } else {
        $mysize = $size . " bytes";
    }
    return $mysize;
    }


function r_code (){
$letras = range("a","z");	
$cletras = count($letras);
$rand[0] = rand(0, ($cletras)-1);
$rand[1] = rand(0, ($cletras)-1);
$rand[2] = rand(0, ($cletras)-1);
$rand[3] = rand(0, ($cletras)-1);
$rand[4] = rand(0, ($cletras)-1);
$code[0] .= $letras[$rand[0]];
$code[1] .= rand(0,9);
$code[2] .= $letras[$rand[1]];
$code[3] .= rand(0,9);
$code[4] .= $letras[$rand[2]];
$code[5] .= rand(0,9);
$code[6] .= $letras[$rand[3]];
$code[7] .= rand(0,9);
$code[8] .= $letras[$rand[4]];
$code[9] .= rand(0,9);
shuffle($code);
$all_code = implode($code);
return $all_code;	
}


 function es_correo($correo){ 
    if (ereg("^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$",$correo))
        { 
            $is_mail_var = true; 
        } 
        else 
        { 
            $is_mail_var = false; 
        } 
      return $is_mail_var;
    }  

 function is_alphanum($cadena)
 {
   if(is_numeric($cadena) || (is_string($cadena) && ctype_alpha($cadena)))
     {  
	     $return = false;
     }
     else
     {
	     $return = true;
     }
  return $return;
 }
  


?>