<?

if(!defined("flash_script")) die("Error");

function tabla_cont ($title,$content)
           {

	     	$echo = '<table width="460" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                    <td height="40" background="imagenes/t01.jpg">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                    <td><div align="center" class="Estilo1">'.$title.'</div></td>
                    </tr>
                    </table></td>
                    </tr>
                    <tr>
                    <td background="imagenes/t02.jpg">
                    '.$content.'
                    </td>
                    </tr>
                    <tr>
                    <td><img src="imagenes/t03.jpg" width="460" height="10" /></td>
                    </tr>
                    </table>';
                return $echo;
                
            }
            
            
function tabla_blok ($title,$content)
           {           
            
            
          $echo = '<table width="147" border="0" cellspacing="0" cellpadding="0">
                   <tr>
                   <td height="40" background="imagenes/b01.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                   <tr>
                   <td><div align="center" class="Estilo1">'.$title.'</div></td>
                   </tr>
                   </table></td>
                   </tr>
                   <tr>
                   <td background="imagenes/b02.jpg">
                   '.$content.'
                   </td>
                   </tr>
                   <tr>
                   <td><img src="imagenes/b03.jpg" width="147" height="10" /></td>
                   </tr>
                   </table>';
                    
                 return $echo;
                
            }    
?>