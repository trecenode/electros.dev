<?
/**********************************************************/
// Clase PHP para subir Archivos
// Desarrollada por J. Pablo
// Contacto: pablo2004@gmail.com
// Version 1.0 
/**********************************************************/


if(!defined("flash_script")) die("Error");

class UpArchivos
{

		var $file_tmp;
		var $file_name;
		var $file_dir;
		var $file_size;
		var $file_type;
	    var $file_ext;
		var $my_dir;
		var $file_ext_suport;
		var $final_name;
		var $dir_chmod = 0777;
		
		function assign_fold ($the_fold){
			$this->my_dir = $the_fold;
		}
		
		function assign_ext ($the_ext){
			if(is_array($the_ext))
			   {
				 $this->file_ext_suport = $the_ext; 
			   }
		}
		
		function assign_file ($up_files){
		 $this->file_tmp = $up_files['tmp_name'];
		 $this->file_name = $up_files['name'];
		 $this->file_size = $up_files['size'];
		 $this->file_type = $up_files['type'];
		 $this->file_dir = $this->my_dir.'/'.$this->file_name;
		 $ext_exp = explode(".", $this->file_name);
		 $cou_arr = count($ext_exp);
		 $this->file_ext = $ext_exp[$cou_arr-1];
		}
       

		function ext_suport (){
	       if(is_array($this->file_ext_suport))
	       {
	          foreach($this->file_ext_suport as $the_ext)
	            {
	             if(strcasecmp($the_ext, $this->file_ext) == 0)
	                   { 
		                  $ext_return = true; 
		               }
	             }	
	  
            }
            else
            {
	            $ext_return = false;
            }
	      return $ext_return ;
        }
        
        function create_dir (){
	        if(!file_exists($this->my_dir))
                {                                
	                 if(mkdir($this->my_dir) && chmod($this->my_dir, $this->dir_chmod)) $create_dir = true; else  $create_dir = false;
                }
                else{
	                $create_dir = false;
                }
	        return $create_dir;
        }
        
        function upload_file(){
	        if(!file_exists($this->my_dir)){ if($this->create_dir()) $dir_exist = true; else $dir_exist = false; }else{ $dir_exist = true; }
	             
	             if($dir_exist){
	                if(move_uploaded_file($this->file_tmp, $this->file_dir))
		             {
			             $upload_file = true;
		             }else{
                         $upload_file = false;
		             }
	             }else{
		               $upload_file = false;
	             }
	          return $upload_file;
	    }
	    
	    function add_char ($add_char, $side = 0, $divider = "-")
	    {
		 if($side == 0) 
		  { 
		  $this->file_dir  = $this->my_dir;
		  $this->file_dir  .= '/';
		  $this->file_dir  .= $add_char;
		  $this->file_dir  .= $divider;
		  $this->file_dir  .= $this->file_name;
		  
		  $this->final_name  = $add_char;
		  $this->final_name .= $divider;
		  $this->final_name .= $this->file_name;
	      }
	     else
	      {
		
		      $ext_fin = '.'.$this->file_ext;
		      $mod_name = str_replace($ext_fin, "", $this->file_name);
		      
		  $this->file_dir  = $this->my_dir;
		  $this->file_dir  .= '/';
		  $this->file_dir  .= $mod_name;
		  $this->file_dir  .= $divider;
		  $this->file_dir  .= $add_char;
		  $this->file_dir  .= $ext_fin;
		  
		  $this->final_name  = $mod_name;
		  $this->final_name .= $divider;
		  $this->final_name .= $add_char;
		  $this->final_name .= $ext_fin;  
		      
	      }
	    }
	     
        
}

?>