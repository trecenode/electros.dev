<?
if(!defined("flash_script")) die("Error");

$datos_admin = trim($_COOKIE['script_admin']);

if($gd_lib)
{
$img_scode = '
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Codigo de Seguridad:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="text" size="10" name="log_sec"></td>
  </tr>
	<tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" colspan="2" width="394" height="3">
    <p align="center"><img src="class/sec_code.php" alt="Codigo de Seguridad" border="0"></td>
  </tr>';
}
else
{
	$img_scode = '';
}

$body_die = '
<html>
<head>
<title>Acceso</title>
</head>

<body bgcolor="#000000">
<form method="POST" action="log_admin.php">
<table align="center" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 3px double #FF9900" bordercolor="#111111" width="400" id="AutoNumber1" height="76" bgcolor="#006699">
  <tr>
    <td colspan="2" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="394" height="16">
    <p align="center"><font size="2">Datos de Acceso</font></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Nombre:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="text" size="20" name="log_name"></td>
  </tr>
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="190" height="13">
    Password:</td>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" width="203" height="13"><input type="password" size="20" name="log_pwd"></td>
  </tr>

'.$img_scode.'
  <tr>
    <td style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; font-weight: bold; border: 1px dashed #FF9900; background-color: #006699" colspan="2" width="394" height="13">
    <p align="center"><input type="submit" size="20" value="Entrar" name="log_submit"></td>
  </tr>
</table>
</form>

</body>
</html>';

if(empty($datos_admin))
{
	die($body_die);
}
else
{
	$cook_dec = base64_decode($datos_admin);
	$da_adm = explode($cookie_sep, $cook_dec);
	$admin_nam = trim($da_adm[0]);
	$admin_pwd = trim($da_adm[1]);
	$verifi_admin = M_Query("SELECT id, nombre, password, mail, nivel FROM admins WHERE nombre = '$admin_nam' AND password = '$admin_pwd' LIMIT 1");
	
	if(mysql_num_rows($verifi_admin) <= 0)
	{
		die($body_die);
	}
	else
	{
	$fetch_assoc_admin = mysql_fetch_assoc($verifi_admin);
	
	$dadmin_nombre = $fetch_assoc_admin['nombre'];
	$dadmin_passw = $fetch_assoc_admin['password'];
	$dadmin_email = $fetch_assoc_admin['mail'];
	$dadmin_nivel = $fetch_assoc_admin['nivel'];
    }
	mysql_free_result($verifi_admin);
	
}




?>