<?php

include("config.inc.php");
include("class/funciones.php");
include("class/class.files.php");
if($seach_if_admin_exist == true) include("class/admin_exists.php");
include("class/is_admin.php");

$p_time = tiempo_carga();

$op = trim($_GET['op']);
$volver = "admin.php?op=$op";

$dir = "admin";

             $opciones_admin .= ' <tr>
                                  <td style="border-style: dashed; border-width: 1" width="100%"><b>
                                  <font face="Verdana" size="2" color="#FFFFFF"><center><a href="admin.php">Inicio</a></center></font></b></td>
                                  </tr> ';

$opdir = opendir($dir);
$ext_permition = 'php';
while($file_php = readdir($opdir))
{
	$info_m = pathinfo($file_php);
	if(strcasecmp($info_m['extension'], $ext_permition) == 0)
	     {
		    
		     $file_php = str_replace(".".$ext_permition, "", $file_php);
		     $opciones_admin .= ' <tr>
                                  <td style="border-style: dashed; border-width: 1" width="100%"><b>
                                  <font face="Verdana" size="2" color="#FFFFFF"><center><a href="admin.php?op='.$file_php.'">'.ucfirst($file_php).'</a></center></font></b></td>
                                  </tr> ';
	     }
}
closedir($opdir);


echo '
<html>
<head>
<title>Administracion</title>

<style type="text/css">
<!--
a:link,
a:visited,
a:active{
	background: transparent;
	color: #FFFFFF;
	text-decoration: underline;
}

a:hover{
	background: transparent;
	color: #336699;
	
}
-->
</style>
</head>
<body bgcolor="#000000">

<div align="center">
  <center>

<table border="1" cellpadding="0" cellspacing="0" style="border:3px double #FF9900; border-collapse: collapse; background-color:#006699" width="500" id="AutoNumber1">
  <tr>
    <td style="border-style: dashed; border-width: 1" width="493" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">OPCIONES<br>Bienvenido: '.$dadmin_nombre.' - <a href="log_out.php">[ Salir ]</a></font></b></td>
  </tr>
  
  '.$opciones_admin.'
  
  <tr>
    <td style="border-style: dashed; border-width: 1" width="100%" colspan="2">

    <p align="center"><p>&nbsp;</p>';

    if(!empty($op))
    {
	    $url_open = "admin/$op.php";
	      if(file_exists($url_open) && !eregi("http://", $op))
	         {
	             include($url_open);
             }
    }
    else
    {
	    echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF">';
	    echo htmlentities("Script PHP & MySql de Juegos y Animaciones Flash 1.0");
	    echo '</font></p>';
    }
    
     
echo  '</td>
  </tr>
</table>

  </center>
</div>';




mysql_close($conect);
if($num_querys == '') $num_querys = 0;
$f_time = tiempo_carga();
echo '<center><font face="Verdana" size="1" color="#00FF00"><b>Pagina Generada en: '.round($f_time-$p_time,4).' segundos - Con '.$num_querys.' consultas.</b></font></center>';
?>

</body>
</html>