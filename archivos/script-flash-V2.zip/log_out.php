<?

		             setcookie("script_admin");
		             header("Location: admin.php");


?>