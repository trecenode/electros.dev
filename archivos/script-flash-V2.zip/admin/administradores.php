<?php

if(!defined("flash_script")) die("Error");

$sel_all_admins = M_Query("SELECT id, nombre FROM admins");
if(mysql_num_rows($sel_all_admins) >= 1)
{
while($d_adm = mysql_fetch_assoc($sel_all_admins))
{
	$all_admins .= '<option value="'.$d_adm['id'].'">'.$d_adm['nombre'].'</option>';
}
}
else
{
	$all_admins = '<option value="0">No Hay Categorias</option>';
}
mysql_free_result($sel_all_admins);

$del_admin = intval(trim($_GET['del_admin']));


if(!$_POST['enviar_admin'] && !$_POST['edit_b_admin'] && !$_POST['editar_admin'] && empty($del_admin))
{

echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Agregar 
    Administrador</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="nom_admin"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Password:</font></b></td>
    <td width="50%" height="19"><input type="password" size="20" name="pass_admin"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Confirmar Password:</font></b></td>
    <td width="50%" height="19"><input type="password" size="20" name="cpass_admin"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Correo:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="mail_admin"></td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="enviar_admin" value="Agregar Administrador"></td>
  </tr>
</table></form>';

echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar Administrador</font></b></td>
  </tr>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Elegir Administrador:</font></b></td>
    <td width="50%" height="19">
    <select name="id_admin">
    '.$all_admins.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="edit_b_admin" value="Seleccionar"></td>
  </tr>
</table></form>';


}




if($_POST['enviar_admin'])
{
$nom_admin = trim($_POST['nom_admin']);
$pass_admin = trim($_POST['pass_admin']);
$cpass_admin = trim($_POST['cpass_admin']);
$mail_admin = trim($_POST['mail_admin']);


if(empty($nom_admin)) $error .= 'Error: Debes escribir un nombre para el administrador.<br>';
if(empty($pass_admin)) $error .= 'Error: Debes escribir un password para el administrador.<br>';
if(empty($cpass_admin)) $error .= 'Error: Debes confirmar el password para el administrador.<br>';
if(empty($mail_admin)) $error .= 'Error: Debes escribir una cuenta de correo para el administrador.<br>';
if(!es_correo($mail_admin)) $error .= 'Error: Correo no valido.<br>';
if($pass_admin != $cpass_admin) $error .= 'Error: Las Contrase�as no coinciden.<br>';

if($password_seguro == true)
{
if(!is_alphanum($pass_admin)) $error .= 'Error: Password Inseguro, debe ser Alfanumerico (Modo Password Seguro).<br>'; 
if(strlen($pass_admin) < 6) $error .= 'Error: Password Inseguro, debe ser mayor de 6 caracteres (Modo Password Seguro).<br>'; 
}

if(isset($error))
   {
	   echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
   }
else
   {
	    $md5_pass_admin = md5($pass_admin);
	    $add_admin = M_Query("INSERT INTO admins (id, nombre, password, mail, nivel) VALUES ('', '$nom_admin', '$md5_pass_admin', '$mail_admin', '0')");
	                  
	                   if($add_admin == true)
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Administrador Agregado Con Exito<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                      }
	                   else
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Agregar al Administrador.<br>'.MySQL_ERROR().'<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                      }
   }

}

if($_POST['edit_b_admin'])
{
	$id_admin = intval(trim($_POST['id_admin']));
	
	$selec_admin = M_Query("SELECT id, nombre, password, mail, nivel FROM admins WHERE id = '$id_admin'");

	   if(mysql_num_rows($selec_admin) == 1)
	      {
		      $ds_admin = mysql_fetch_assoc($selec_admin);
		      
		      if($ds_admin['nivel'] == 1 && $dadmin_nivel == 0)
		        {
			       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No tienes permisos para editar este administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>';    
		        }
		      else
		        {
		      echo '<form method="POST" action="'.$volver.'">
		            <input type="hidden" name="id_admin" value="'.$ds_admin['id'].'">
		            <input type="hidden" name="pwddb_admin" value="'.$ds_admin['password'].'">
                    <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
                    <tr>
                    <td width="100%" colspan="2" height="16">
                    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
                    Administrador</font></b></td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
                    <td width="50%" height="19"><font face="Verdana" size="2" color="#FFFFFF"><b>'.$ds_admin['nombre'].'</b></font></td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Correo:</font></b></td>
                    <td width="50%" height="19"><input type="text" value="'.$ds_admin['mail'].'" size="20" name="mail_admin"></td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Cambiar Password:</font></b></td>
                    <td width="50%" height="19">
                    <select name="changepwd_admin">
                    <option selected value="1">No</option>
                    <option value="2">Si</option>
                    </select>
                    </td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Password Actual:</font></b></td>
                    <td width="50%" height="19"><input type="password" size="20" name="acpass_admin"></td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Password:</font></b></td>
                     <td width="50%" height="19"><input type="password" size="20" name="pass_admin"></td>
                    </tr>
                    <tr>
                    <td width="50%" height="19"><b>
                    <font face="Verdana" size="2" color="#FFFFFF">Confirmar Password:</font></b></td>
                    <td width="50%" height="19"><input type="password" size="20" name="cpass_admin"></td>
                    </tr>
                    <tr>
                    <td width="100%" height="1" colspan="2">
                    <p align="center"><input type="submit" size="20" name="editar_admin" value="Editar Administrador"></td>
                    </tr>
                    </table></form><center><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_admin='.$ds_admin['id'].'">[ Borrar Administrador ]</a></b></font></center>';
	              }
	      }
	   else
	      {
		      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	      }
	mysql_free_result($selec_admin);
	
}


if($_POST['editar_admin'])
{
	
$id_admin = intval(trim($_POST['id_admin']));
$pwddb_admin = trim($_POST['pwddb_admin']);

$mail_admin = trim($_POST['mail_admin']);
$changepwd_admin = intval(trim($_POST['changepwd_admin']));

$acpass_admin = trim($_POST['acpass_admin']);
$pass_admin = trim($_POST['pass_admin']);
$cpass_admin = trim($_POST['cpass_admin']);


if(empty($mail_admin)) $error .= 'Error: No puedes dejar en blanco el correo del Administrador.<br>';
if(!es_correo($mail_admin)) $error .= 'Error: El correo del Administrador no es valido.<br>';

if($changepwd_admin == 2)
{
if(md5($acpass_admin) != $pwddb_admin) $error .= 'Error: Password Actual Incorrecto.<br>';
if(empty($acpass_admin)) $error .= 'Error: Debes escribir el password actual del Administrador.<br>';
if(empty($pass_admin)) $error .= 'Error: Debes escribir el nuevo password del Administrador.<br>';	
if(empty($cpass_admin)) $error .= 'Error: Debes confirmar el nuevo password del Administrador.<br>';
if($pass_admin != $cpass_admin) $error .= 'Error: Passwords nuevos Diferentes.<br>';

if($password_seguro == true)
{
if(!is_alphanum($pass_admin)) $error .= 'Error: Password Inseguro, debe ser Alfanumerico (Modo Password Seguro).<br>'; 
if(strlen($pass_admin) < 6) $error .= 'Error: Password Inseguro, debe ser mayor de 6 caracteres (Modo Password Seguro).<br>'; 
}
$na_pass = md5($pass_admin);
$if_change_pwd = " password = '$na_pass',";
}

if(isset($error))
{
	 echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
}
else
{ 
	
             $update_admin = M_Query("UPDATE admins SET $if_change_pwd mail = '$mail_admin' WHERE id = '$id_admin'");	
                 if($update_admin == true)
                      {
	                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Datos de el administrador editados correctamente.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
                      }
                 else
                      {
	                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al modificar los datos del administrador.<br>'.mysql_error().'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
                      }
}

}

if(!empty($del_admin))
{
	
	$confirm = $_GET['confirm'];
	$select_dadmin = M_Query("SELECT id, nombre FROM admins WHERE id = '$del_admin' LIMIT 1");
	    if(mysql_num_rows($select_dadmin) == 1)
	        {
		        $dda_admin = mysql_fetch_assoc($select_dadmin);
		        
		         if($dda_admin == 1 && $dadmin_nivel == 0) 
		            {
			            echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No tienes permisos para borrar a este administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		            }
		         else
		         {
		           
		              echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Administrador: '.$dda_admin['nombre'].'</b></font></p>';
		               if(!$confirm)
		                  {
		                     echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_admin='.$dda_admin['id'].'&confirm=true">[ Confirmar ]</a>  -  <a href="'.$volver.'">[ Cancelar ]</a></b></font></p>';
	                      }
	                   else
	                      {
		                      $delete_admin = M_Query("DELETE FROM admins WHERE id = '$del_admin'");
		                           if($delete_admin == true)
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Administrador Borrado con Exito.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                           else
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Borrar al Administrador.<br>'.MySQL_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                      
	                      }
                   }
		        
	        }
	     else
	     {  
		     echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	     }
	mysql_free_result($select_dadmin);
	
}
?>