<?php

if(!defined("flash_script")) die("Error");

$del_categ = intval(trim($_GET['del_categ']));

$sel_all_categ = M_Query("SELECT id, nombre FROM categ");
if(mysql_num_rows($sel_all_categ) >= 1)
{
while($d_cate = mysql_fetch_assoc($sel_all_categ))
{
	$all_categorias .= '<option value="'.$d_cate['id'].'">'.$d_cate['nombre'].'</option>';
}
}
else
{
	$all_categorias = '<option value="0">No Hay Categorias</option>';
}
mysql_free_result($sel_all_categ);


if(!$_POST['enviar_categ'] && !$_POST['editar_b_categ'] && !$_POST['mover_categ'] && !$_POST['editar_categ'] && empty($del_categ) && !$_POST['move_final_categ'])
{
echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Agregar 
    Categor�a</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="nom_categ"></td>
  </tr>
  <tr>
    <td width="50%" height="1"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Activar Categor�a:</font></b></td>
    <td width="50%" height="1">
     <select name="active_categ">
    <option value="1">Si</option>
    <option value="2">No</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="enviar_categ" value="Agregar Categoria"></td>
  </tr>
</table></form>';


echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
    Categor�a</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Selecciona la Categoria:</font></b></td>
    <td width="50%" height="19">
    <select name="id_categ">
    '.$all_categorias.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="editar_b_categ" value="Editar Categoria"></td>
  </tr>
</table></form>';

echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Mover 
    Juegos por Categor�as</font></b></td>
  </tr>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">A la Categor�a:</font></b></td>
    <td width="50%" height="19">
    <select name="mov_a_categ">
    '.$all_categorias.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="mover_categ" value="Mover"></td>
  </tr>
</table></form>';

}

if($_POST['enviar_categ'])
{
	
$categ_nombre = trim($_POST['nom_categ']);
$categ_status = trim($_POST['active_categ']);

unset($error);
if(empty($categ_nombre)){ $error .= 'Error: Debes escribir el nombre de la Categoria.<br>'; }
if(search_db("categ", "nombre", $categ_nombre) >= 1){ $error .= 'Error: Ya existe una categoria con ese nombre.<br>'; }
if(strlen($categ_nombre) > 50){ $error .= 'Error: El nombre de la categoria no debe pasar los 50 Caracteres.<br>'; }

if(isset($error))
{
	echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';
}
else
{
	$categ_nombre = borrar_acentos($categ_nombre);
	$categ_status = intval($categ_status);
	$insert_categ = M_Query("INSERT INTO categ (id, nombre, active) VALUES ('', '$categ_nombre', '$categ_status')");
	    
	        if($insert_categ)
	        {
		        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Categoria Agregada Correctamente<br><a href="'.$volver.'">Volver</a></b></font></center>';
	        }
	        else
	        {
		        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Agregar la Categoria<br>'.MySql_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
	        }
}


}

if($_POST['editar_b_categ'])
{
$id_categ = intval(trim($_POST['id_categ']));
	$sel_cate = M_Query("SELECT id, nombre, active FROM categ WHERE id = '$id_categ'");
	    if(mysql_num_rows($sel_cate) == 1)
	    {
		    $cate_dats = mysql_fetch_assoc($sel_cate);
		             if($cate_dats['active'] == 1)
		             {
		                $c_op = '<option selected value="1">Si</option>
  		                         <option value="2">No</option>';
		             }
		             else
		             {
			            $c_op = '<option value="1">Si</option>
  		                         <option selected value="2">No</option>';   
		             }
		    
		        echo '<form method="POST" action="'.$volver.'">
		              <input type="hidden" name="id_categ" value="'.$cate_dats['id'].'">
		              <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
		                <tr>
 		                 <td width="100%" colspan="2" height="16">
  		                <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
  		                Categor�a</font></b></td>
  		              </tr>
 		               <tr>
 		                 <td width="50%" height="19"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
  		                <td width="50%" height="19"><input type="text" value="'.$cate_dats['nombre'].'" size="20" name="nom_categ"></td>
  		              </tr>
 		               <tr>
  		                <td width="50%" height="1"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Activar Categor�a:</font></b></td>
  		                <td width="50%" height="1">
  		                 <select name="active_categ">
  		                '.$c_op.'
  		                </select>
  		                </td>
 		               </tr>
 		               <tr>
 		                 <td width="100%" height="1" colspan="2">
  		                <p align="center"><input type="submit" size="20" name="editar_categ" value="Editar Categoria"></td>
 		               </tr>
		              </table></form><center><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_categ='.$cate_dats['id'].'">[ Borrar Categoria ]</a></b></font></center>';
	    }
	    else
	    {
		    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro la categoria.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	    }
	mysql_free_result($sel_cate);
}

if($_POST['editar_categ'])
{
	$id_categ = intval(trim($_POST['id_categ']));
	$nom_categ = trim($_POST['nom_categ']);
	$active_categ = intval(trim($_POST['active_categ']));
	
	   if(empty($nom_categ)) $error .= 'Error: Debes escribir el nombre de la categoria.<br>';
	            
	             if(isset($error))
	                {
		                 echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';
	                }
	             else
	                {
		                 $update_categ = M_Query("UPDATE categ SET nombre = '$nom_categ', active = '$active_categ' WHERE id = '$id_categ'");
		                      if($update_categ == true)
		                         {
			                          echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Categoria editada correctamente.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                         }
		                       else
		                         {
			                          echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Editar la Categoria<br>'.MySql_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                         }
	                }
	
	
}

if(!empty($del_categ))
{
	$confirm = $_GET['confirm'];
	$sel_cate = M_Query("SELECT id, nombre, active FROM categ WHERE id = '$del_categ'");
	
	   if(mysql_num_rows($sel_cate) == 1)
	      {
		      $del_categ = mysql_fetch_assoc($sel_cate);
		      
		        echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Categoria: '.$del_categ['nombre'].'<br>Nota: Se Borraran todos los juegos de esta categoria, por lo que te recomendarlos moverlos a otra categoria si no quieres eliminarlos.</b></font></p>';
		               if(!$confirm)
		                  {
		                     echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_categ='.$del_categ['id'].'&confirm=true">[ Confirmar ]</a>  -  <a href="'.$volver.'">[ Cancelar ]</a></b></font></p>';
		                    
	                      }
	                   else
	                      {
		                      $id_to_del = intval($del_categ['id']);
		                      $delete_cateo = M_Query("DELETE FROM categ WHERE id = '$id_to_del'");
		                      $delete_games = M_Query("DELETE FROM juegos WHERE categ = '$id_to_del'");
		                           if($delete_cateo == true && $delete_games == true)
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Categoria Borrada con Exito.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                           else
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Borrar la Categoria.<br>'.MySQL_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                      
	                      }      
		      
		      
		      
	      }
	   else
	      {
		      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro la categoria.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	      }
	  mysql_free_result($sel_cate);
	
}

if($_POST['mover_categ'])
{


$mov_a_categ = intval(trim($_POST['mov_a_categ']));
  

            if(isset($error))
               {
	               echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
               }
            else
              {
	           
	              $sel_categ_a = M_Query("SELECT id, nombre FROM categ WHERE id = '$mov_a_categ'");
	              $datc_a = mysql_fetch_assoc($sel_categ_a);
	             
	              mysql_free_result($sel_categ_a);
	              
	              $id_de = $datc_de['id'];
	              $name_de = $datc_de['nombre'];
	              $id_a = $datc_a['id'];
	              $name_a = $datc_a['nombre'];
	              
echo '<form method="POST" action="'.$volver.'">
   
     <input type="hidden" name="a_catem" value="'.$id_a.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Mover 
    Juegos</font></b></td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Deseas 
    juegos mover a la categoria '.$name_a.'</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Cuales Juegos:</font></b></td>
    <td width="50%" height="19">
     <select name="cuales_juegos">
    <option value="1">Por Categoria</option>
    <option value="2">Escogerlos por ID</option>
    <option value="3">Ambos</option>
    </select></td>
  </tr>
    <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">De la Categor�a:</font></b></td>
    <td width="50%" height="19">
    <select name="mov_de_categ">
    '.$all_categorias.'
    </select>
    </td>
  <tr>
    <td width="50%" height="1"><b><font face="Verdana" size="2" color="#FFFFFF">
    Seleccionar juegos a mover: <br></font>
    <font face="Verdana" size="1" color="#FFFFFF">
    Debes escribir el numero ID de los juegos a mover separados por comas (,). Ejemplo: 1, 5, 10, 60</font></b></td>
    <td width="50%" height="1">
     <textarea name="def_juegos" rows="4" cols="32"></textarea>
     </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="move_final_categ" value="Mover Juegos"></td>
  </tr>
</table></form>';
	             
              }
              
	
}

if($_POST['move_final_categ'])
{
$de_catem = intval(trim($_POST['mov_de_categ']));
$a_catem = intval(trim($_POST['a_catem']));
$cuales_juegos = intval(trim($_POST['cuales_juegos']));
$def_juegos = trim($_POST['def_juegos']);
$los_juegos = explode(",", $def_juegos);
$cou_arr = count($los_juegos);

if($cuales_juegos == 1 || $cuales_juegos == 3)
{
if($de_catem == $a_catem) $error .= 'Error: No puedes mover juegos a la misma categoria.<br>';
}

if($cuales_juegos == 2 || $cuales_juegos == 3)
{
 if(empty($def_juegos))	$error .= 'Error: No especificaste que juegos quieres mover.<br>';
 foreach($los_juegos as $id_juego)
   {
   if(!is_numeric($id_juego)) $no_numeric_juego = 1;
   }
if(isset($no_numeric_juego)) $error .= 'Error: Debes especificar solo datos numericos.<br>';
if($cou_arr <= 0) $error .= 'Error: Debes especificar al menos 1 juego a mover.<br>';
}


      if(isset($error))
        {
	         echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
        }
      else
        {
           if($cuales_juegos == 1 || $cuales_juegos == 3)
              {
	              $move_juegos_query = M_Query("UPDATE juegos SET categ = '$a_catem' WHERE categ = '$de_catem' and tipo_id = '0'");
	              
	                  if($move_juegos_query == true)
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Juegos Movidos por Categoria Exitosamente<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                      }
	                   else
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al mover los juegos por Categoria.<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                      }
              }
            if($cuales_juegos == 2 || $cuales_juegos == 3)
              {
	               foreach($los_juegos as $m_juego)
	               { 
		                $p_b++;
		                $_consulta_move .= "(id = '$m_juego')";
		                if($p_b >= 1 and $p_b <= ($cou_arr - 1)){  $_consulta_move .= ' OR '; }
                   }
                   
                      $move_juegos_query = M_Query("UPDATE juegos SET categ = '$a_catem' WHERE $_consulta_move and (tipo_id = '0')");
  
                        if($move_juegos_query == true)
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$cou_arr.' Juegos Movidos por ID Exitosamente<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                      }
	                   else
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al mover los juegos por ID.<br>'.MySQL_ERROR().'<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                      }
              }
              
       }

}

?>