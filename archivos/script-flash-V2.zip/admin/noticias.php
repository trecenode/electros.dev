<?php

if(!defined("flash_script")) die("Error");


$lista = $_GET['lista'];
$id_edit = intval($_GET['id_edit']);
$borrar_id = intval($_GET['borrar_id']);

$sell_all_news = M_Query("SELECT NULL FROM juegos WHERE tipo_id = '1'");
$count_all_news = mysql_num_rows($sell_all_news);
mysql_free_result($sell_all_news);


              if(!$_POST['agregar_news'] && !$lista && !$_POST['b_editar_news'] && empty($id_edit) && !$_POST['edit_news'] && empty($borrar_id))
		              {
                echo '<form method="POST" action="'.$volver.'">
		              <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
		                <tr>
 		                 <td width="100%" colspan="2" height="16">
  		                <p align="center"><b>
                        <font face="Verdana" size="2" color="#FFFFFF">Agregar 
                        Noticia<br>Total de Noticias: '.$count_all_news.'</font></b></td>
  		              </tr>
 		               <tr>
 		                 <td width="50%" height="19"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Titulo:</font></b></td>
  		                <td width="50%" height="19"><input type="text" size="20" name="title_news"></td>
  		              </tr>
 		               <tr>
  		                <td width="50%" height="1"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Texto:</font></b></td>
  		                <td width="50%" height="1">
  		                 <textarea name="text_news" rows="6" cols="40"></textarea>
  		                </td>
 		               </tr>
 		               <tr>
 		                 <td width="50%" height="1">
  		                <b><font face="Verdana" size="2" color="#FFFFFF">Activar 
                        Noticia:</font></b></td>
 		                 <td width="50%" height="1">
  		                <select name="active_news">
  		                <option value="1">Si</option>
  		                <option value="2">No</option>
  		                </select>
  		                </td>
 		               </tr>
 		               <tr>
 		                 <td width="100%" height="1" colspan="2">
  		                <p align="center"><input type="submit" size="20" name="agregar_news" value="Agregar Noticia"></td>
 		               </tr>
		              </table></form>';
		              
		              echo '<form method="POST" action="'.$volver.'" enctype="multipart/form-data">
		              <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="7">
  		              <tr>
  		                <td width="100%" colspan="2" height="16">
  		                <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
   		               Noticia</font></b></td>
 		               </tr>
  		              <tr>
  		                <td width="100%" height="19" colspan="2">
  		                <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF"><a href="'.$volver.'&lista=true">[ Ver 
  		                lista Completa de Noticias ]</a></font></b></td>
  		              </tr>
 		               <tr>
   		               <td width="50%" height="19"><b>
   		               <font face="Verdana" size="2" color="#FFFFFF">Editar por Nombre:</font></b></td>
   		               <td width="50%" height="19">
   		                <input type="text" size="20" name="name_edit_news"></td>
  		              </tr>
 		               <tr>
  		                <td width="50%" height="19"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Editar por Id:</font></b></td>
  		                <td width="50%" height="19">
  		                 <input type="text" size="20" name="id_edit_news"></td>
 		               </tr>
 		               <tr>
  		                <td width="100%" height="1" colspan="2">
  		                <p align="center"><input type="submit" size="20" name="b_editar_news" value="Editar"></td>
 		               </tr>
		              </table></form>';
		              
	              }
		              
		              
		              
		              
		              
		              if($_POST['agregar_news'])
		              {
			              $title_news = trim($_POST['title_news']);
			              $text_news = trim($_POST['text_news']);
			              $active_news = intval(trim($_POST['active_news']));
			              
			              if(empty($title_news)) $error .= 'Error: Debes especificar el titulo de la noticia.<br>';
			              if(empty($text_news)) $error .= 'Error: Debes especificar el contenido de la noticia.<br>';
			              
			                  if(isset($error))
			                     {
				                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
			                     }
			                    else
			                     {
				                      $title_news = borrar_acentos($title_news);
				                      $text_news = nl2br(htmlentities(borrar_acentos($text_news)));
				                      $insert_news = M_Query("INSERT INTO juegos (id, name, descg, active, tipo_id) VALUES ('', '$title_news', '$text_news', '$active_news', '1')");
				                                        if($insert_news == true)
	                                                        {
		                                                         echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Noticia Agregada Exitosamente<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                                                        }
	                                                    else
	                                                        {
		                                                         echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Agregar la Noticia<br>'.MySQL_ERROR().'<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                                                        }
				                      
			                     }
			              
			              
		              }
		              
		   
		              
		                         
if($lista)
{

if($count_all_news <= 0)
{
	 echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontraron noticias.<br><a href="'.$volver.'">Volver</a></b></font></center>';  
}
else
{

//Cantidad de Juegos por Pagina ////	
$ExP = 10;                          //
//////////////////////////////////////
$Sec = intval($_GET['cat']);
$Des = $ExP * $Sec;

$sel_news = M_Query("SELECT id, name FROM juegos WHERE tipo_id = '1' ORDER BY id ASC LIMIT $Des, $ExP");	
$count_all = MySql_Num_Rows($sel_news);
echo '<p align="left"><font face="Verdana" size="2" color="#FFFFFF">';
while($g_list = MySql_Fetch_Assoc($sel_news))
{ 
	$a++;
	echo $a.' .- <a href="'.$volver.'&id_edit='.$g_list['id'].'">'.$g_list['name'].'</a><br>';
}
echo '</font></p>';
mysql_free_result($sel_news);


$page = $count_all_news / $ExP;
echo '<p align="center"><font size="2" face="Verdana">';
$page2 = $page - 1;
if($Sec == ''){ $prev = ''; }


if($Sec >= 1){ $prev = $Sec - 1; echo '<a href="'.$volver.'&lista=true&cat='.$prev.'">< Anterior</a> -'; }
for ($x = 1; $x < $page;$x++) {
if($x == $Sec){
	echo " [$x] ";
}
else{
echo ' [<a href="'.$volver.'&lista=true&cat='.$x.'">'.$x.'</a>] ';
}
}
if($Sec >= 0 and $Sec < $page2 and $page >= 1){ $next = $Sec + 1; echo '- <a href="'.$volver.'&lista=true&cat='.$next.'">Siguiente ></a>'; }

}
}


if($_POST['b_editar_news'] || !empty($id_edit))
{
	$id_edit_news = trim(intval($_POST['id_edit_news']));
	$name_edit_news = trim($_POST['name_edit_news']);
	
    if(empty($id_edit_news) && !empty($id_edit)) $id_edit_news = $id_edit;
	
	if(empty($id_edit_news) && empty($name_edit_news)) $error .= 'Error: Debes especificar al menos un campo para buscar la notica.<br>';
	       
	   if(isset($error)) 
	        {
		          echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
	        }
	      else
	         {
	                 if(!empty($id_edit_news)){ $b_field = "id"; $b_var = $id_edit_news; }
	                 elseif(!empty($name_edit_news)){ $b_field = "name"; $b_var = $name_edit_news; }
	                 
                    $sel_notq = M_Query("SELECT * FROM juegos WHERE tipo_id = '1' and $b_field = '$b_var' LIMIT 1");	
                    if(mysql_num_rows($sel_notq) == 1)
                    {
	                    $d_enot = mysql_fetch_assoc($sel_notq);
	                    
	                    $act_not = ($d_enot['active'] == 1) ? '<option selected value="1">Si</option><option value="2">No</option>' :  '<option value="1">Si</option><option selected value="2">No</option>';
	                                      
	                        echo '<form method="POST" action="'.$volver.'">
	                        <input type="hidden" name="id_news" value="'.$d_enot['id'].'">
		              <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
		                <tr>
 		                 <td width="100%" colspan="2" height="16">
  		                <p align="center"><b>
                        <font face="Verdana" size="2" color="#FFFFFF">Editar 
                        Noticia</font></b></td>
  		              </tr>
 		               <tr>
 		                 <td width="50%" height="19"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Titulo:</font></b></td>
  		                <td width="50%" height="19"><input type="text" value="'.$d_enot['name'].'" size="20" name="title_news"></td>
  		              </tr>
 		               <tr>
  		                <td width="50%" height="1"><b>
  		                <font face="Verdana" size="2" color="#FFFFFF">Texto:</font></b></td>
  		                <td width="50%" height="1">
  		                 <textarea name="text_news" rows="6" cols="40">'.$d_enot['descg'].'</textarea>
  		                </td>
 		               </tr>
 		               <tr>
 		                 <td width="50%" height="1">
  		                <b><font face="Verdana" size="2" color="#FFFFFF">Activar 
                        Noticia:</font></b></td>
 		                 <td width="50%" height="1">
  		                <select name="active_news">
  		               '.$act_not.'
  		                </select>
  		                </td>
 		               </tr>
 		               <tr>
 		                 <td width="100%" height="1" colspan="2">
  		                <p align="center"><input type="submit" size="20" name="edit_news" value="Editar Noticia"></td>
 		               </tr>
		              </table></form><p align="center"><font face="Verdana" size="2" color="#FFFFFF"><a href="'.$volver.'&borrar_id='.$d_enot['id'].'"><b>[ Borrar Noticia ]</b></a></font></p>';
	                    
                    }
                    else
                    {
	                    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro la noticia.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
                    }
                    mysql_free_result($sel_notq);
                   
                    
             }
}


if($_POST['edit_news'])
{
	
			              $title_news = trim($_POST['title_news']);
			              $text_news = trim($_POST['text_news']);
			              $id_news = intval(trim($_POST['id_news']));
			              $active_news = intval(trim($_POST['active_news']));	
	
				          if(empty($title_news)) $error .= 'Error: Debes especificar el titulo de la noticia.<br>';
			              if(empty($text_news)) $error .= 'Error: Debes especificar el contenido de la noticia.<br>';
			              
			                  if(isset($error))
			                     {
				                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
			                     }
			                    else
			                     {
				                     $up_new = M_Query("UPDATE juegos SET name = '$title_news', descg = '$text_news', active = '$active_news' WHERE id = '$id_news' AND tipo_id = '1'");
				                     
			                                   if($up_new == true)
	                                                        {
		                                                         echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Noticia Editada Exitosamente<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                                                        }
	                                                    else
	                                                        {
		                                                         echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Editar la Noticia<br>'.MySQL_ERROR().'<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                                                        }
				                     
				                     
				                 }
	
	
	
	
	
}


if(!empty($borrar_id))
{
	$confirm = $_GET['confirm'];
	$select_dnot = M_Query("SELECT id, name FROM juegos WHERE id = '$borrar_id' and tipo_id = '1' LIMIT 1");
	    if(mysql_num_rows($select_dnot) == 1)
	        {
		        $del_new = mysql_fetch_assoc($select_dnot);
		         
		              echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Noticia: '.$del_new['name'].'</b></font></p>';
		               if(!$confirm)
		                  {
		                     echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&borrar_id='.$del_new['id'].'&confirm=true">[ Confirmar ]</a>  -  <a href="'.$volver.'">[ Cancelar ]</a></b></font></p>';
	                      }
	                   else
	                      {
		                      $delete_news = M_Query("DELETE FROM juegos WHERE id = '$borrar_id' and tipo_id = '1'");
		                           if($delete_news == true)
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Noticia Borrada con Exito.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                           else
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Borrar la Noticia.<br>'.MySQL_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                      
	                      }
		        
	        }
	     else
	     {  
		     echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro la noticia.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	     }
	mysql_free_result($select_dnot);
}
?>
