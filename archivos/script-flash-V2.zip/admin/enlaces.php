<?php

if(!defined("flash_script")) die("Error");

$sel_all_admins = M_Query("SELECT id, titulo FROM enlaces");
if(mysql_num_rows($sel_all_admins) >= 1)
{
while($d_adm = mysql_fetch_assoc($sel_all_admins))
{
	$all_admins .= '<option value="'.$d_adm['id'].'">'.$d_adm['titulo'].'</option>';
}
}
else
{
	$all_admins = '<option value="0">No Hay Enlaces</option>';
}
mysql_free_result($sel_all_admins);



$del_enlace = intval(trim($_GET['del_enlace']));


if(!$_POST['enviar_enlace'] && !$_POST['edit_b_enlace'] && !$_POST['editar_enlace'] && empty($del_enlace))
{

echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Agregar 
    Enlaces</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Titulo:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="tit_enl"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Direccion:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="dir_enl"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Tipo:</font></b></td>
    <td width="50%" height="19">
    <select name="tip_enl">
    <option value="1">Directo</option>
    <option value="2">Script</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Activo:</font></b></td>
    <td width="50%" height="19">
    <select name="act_enl">
    <option value="1">Si</option>
    <option value="2">No</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="enviar_enlace" value="Agregar Enlace"></td>
  </tr>
</table></form>';

echo '<form method="POST" action="'.$volver.'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar Enlace</font></b></td>
  </tr>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Elegir Enlace:</font></b></td>
    <td width="50%" height="19">
    <select name="id_enlace">
    '.$all_admins.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="edit_b_enlace" value="Seleccionar"></td>
  </tr>
</table></form>';


}




if($_POST['enviar_enlace'])
{
$tit_enl = trim($_POST['tit_enl']);
$dir_enl = trim($_POST['dir_enl']);
$tip_enl = trim($_POST['tip_enl']);
$act_enl = trim($_POST['act_enl']);


if(empty($tit_enl)) $error .= 'Error: Debes escribir el titulo de la pagina.<br>';
if(empty($dir_enl)) $error .= 'Error: Debes escribir la direccion url de la pagina.<br>';



if(isset($error))
   {
	   echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
   }
else
   {

	    $add_link = M_Query("INSERT INTO enlaces (id, titulo, url, tipo, activo, vistas, entrantes) VALUES ('', '$tit_enl', '$dir_enl', '$tip_enl', $act_enl, '0', '0')");
	                  
	                   if($add_link == true)
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Enlace Agregado Con Exito<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	                      }
	                   else
	                      {
		                       echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Agregar el Enlace.<br>'.MySQL_ERROR().'<br><a href="'.$volver.'">Volver</a></b></font></center>';    
	                      }
   }

}



if($_POST['edit_b_enlace'])
{
	$id_enlace = intval(trim($_POST['id_enlace']));
	
	$selec_enlace = M_Query("SELECT id, titulo, url, tipo, activo, vistas, entrantes FROM enlaces WHERE id = '$id_enlace'");
		      echo mysql_error();
	   if(mysql_num_rows($selec_enlace) == 1)
	      {

		      $ds_enlace = mysql_fetch_assoc($selec_enlace);
		      $tip_activo = ($ds_enlace['activo'] == 1) ? '<option selected value="1">Si</option><option value="2">No</option>' : '<option value="1">Si</option><option selected value="2">No</option>';
		      $tip_tipo = ($ds_enlace['tipo'] == 1) ? '<option selected value="1">Directo</option><option value="2">Script</option>' : '<option value="1">Directo</option><option selected value="2">Script</option>';
		 
echo 
'<form method="POST" action="'.$volver.'">
<input type="hidden" name="id_enl" value="'.$ds_enlace['id'].'">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
    Enlace</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Titulo:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" value="'.$ds_enlace['titulo'].'" name="tit_enl"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Direccion:</font></b></td>
    <td width="50%" height="19"><input type="text" value="'.$ds_enlace['url'].'" size="20" name="dir_enl"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Tipo:</font></b></td>
    <td width="50%" height="19">
    <select name="tip_enl">
    '.$tip_tipo.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Activo:</font></b></td>
    <td width="50%" height="19">
    <select name="act_enl">
    '.$tip_activo.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="editar_enlace" value="Editar Enlace"></td>
  </tr>
</table></form><center><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_enlace='.$ds_enlace['id'].'">[ Borrar Enlace ]</a></b></font></center>';
	              
	      }
	   else
	      {
		      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
	      }
	mysql_free_result($selec_enlace);
	
}


if($_POST['editar_enlace'])
{

$id_enl = intval(trim($_POST['id_enl']));
$tit_enl = trim($_POST['tit_enl']);
$dir_enl = trim($_POST['dir_enl']);
$tip_enl = trim($_POST['tip_enl']);
$act_enl = trim($_POST['act_enl']);

if(empty($tit_enl)) $error .= 'Error: Debes escribir el titulo de la pagina.<br>';
if(empty($dir_enl)) $error .= 'Error: Debes escribir la direccion url de la pagina.<br>';



if(isset($error))
{
	 echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
}
else
{ 
	
             $update_enlace = M_Query("UPDATE enlaces SET titulo = '$tit_enl', url = '$dir_enl', tipo = '$tip_enl', activo = '$act_enl' WHERE id = '$id_enl'");	
                 if($update_enlace == true)
                      {
	                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Enlace Editado Correctamente.<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
                      }
                 else
                      {
	                      echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al editar el enlace.<br>'.mysql_error().'<br><a href="'.$volver.'">Volver</a></b></font></center>'; 
                      }
}

}




if(!empty($del_enlace))
{
	
	$confirm = $_GET['confirm'];
	$select_enlace = M_Query("SELECT id, titulo FROM enlaces WHERE id = '$del_enlace' LIMIT 1");
	    if(mysql_num_rows($select_enlace) == 1)
	        {
		        $dda_enl = mysql_fetch_assoc($select_enlace);
		        
		           
		              echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Enlace: '.$dda_enl['titulo'].'</b></font></p>';
		               if(!$confirm)
		                  {
		                     echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&del_enlace='.$dda_enl['id'].'&confirm=true">[ Confirmar ]</a>  -  <a href="'.$volver.'">[ Cancelar ]</a></b></font></p>';
	                      }
	                   else
	                      {
		                      $delete_enlace = M_Query("DELETE FROM enlaces WHERE id = '$del_enlace'");
		                           if($delete_enlace == true)
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Enlace Borrado con Exito.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                           else
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Borrar el Enlace.<br>'.MySQL_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                      
	                      }
                   
		        
	        }
	     else
	     {  
		     echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el administrador.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	     }
	mysql_free_result($select_enlace);
	
}
?>