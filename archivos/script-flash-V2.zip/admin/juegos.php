<?php

if(!defined("flash_script")) die("Error");

//////////// Contar Juegos //////////////
$sell_all_juegos = M_Query("SELECT NULL FROM juegos WHERE tipo_id = '0'");
$count_all_juegos = mysql_num_rows($sell_all_juegos);
mysql_free_result($sell_all_juegos);
/////////////////////////////////////////

$max_upload_size = intval(ini_get('post_max_size'));

$lista = $_GET['lista'];
$id_edit = intval($_GET['id_edit']);
$borrar_id = intval($_GET['borrar_id']);

// Error a mostrar en caso de que no se encuentre la funcion getimagesize, de lo contrario se agregara esa opcion
if(!function_exists('getimagesize'))
{
	echo '<center><font face="Verdana" size="2" color="#00FF00"><b>Alerta: Su Version de PHP no soporta la funcion GetImageSize, le recomiendo que arregle eso con su provedor de hosting</b></font></center>';
}	
else
{
	$op_leidas = '<option selected value="1">Funcion</option>';
}

if(!empty($width) && !empty($height)) $op_script = '<option value="3">Script</option>';




if(!$_POST['enviar_juego'] && !$_POST['b_editar_juego'] && !$lista && empty($id_edit) && !$_POST['editar_juego'] && !$borrar_id)
{


// Leemos las categorias en la base de datos

$select_categs = M_Query("SELECT id, nombre FROM categ");
$num_categ = mysql_num_rows($select_categs);
if($num_categ >= 1)
{
	while($opd_categ = mysql_fetch_assoc($select_categs))
	{
     $option_categs .= '<option value="'.$opd_categ['id'].'">'.$opd_categ['nombre'].'</option>';
    }
}
mysql_free_result($select_categs);


// Mostramos el formulario para agregar juegos en caso de que se encuentren categorias

if($num_categ == 0)
{
echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Primero debes de agregar categorias.</b></font></center>';
}
else
{

echo '<form method="POST" action="'.$volver.'" enctype="multipart/form-data">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="175">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Agregar 
    Juego<br>Numero de Juegos: '.$count_all_juegos.'<br><font face="Verdana" size="1" color="#FFFFFF">Nota: Limite de '.$max_upload_size.' Megabytes por Archivo en este Servidor</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="nom_juego"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Categoria:</font></b></td>
    <td width="50%" height="19">
    <select name="categ_juego">
    '.$option_categs.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Agregar Swf por:</font></b></td>
    <td width="50%" height="19">
    <select name="tip_swf_juego">
    <option value="1">Upload</option>
    <option value="2">Url</option>
    <option value="3">Pagina Externa</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Agregar Imagen por:</font></b></td>
    <td width="50%" height="19">
    <select name="tip_img_juego">
    <option value="1">Upload</option>
    <option value="2">Url</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Definir Ancho y Alto por:</font></b></td>
    <td width="50%" height="19">
    <select name="tipd_juego">
    '.$op_leidas.'
    <option value="2">Definir</option>
    '.$op_script.'
    </select> 
    <b><font face="Verdana" size="1" color="#FFFFFF">Recomendado 
    Funcion</font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Define el Ancho y Alto: </font>
    <font face="Verdana" size="1" color="#00FF00">(*)</font></b></td>
    <td width="50%" height="19">
    <font face="Verdana"><b><font size="2" color="#FFFFFF">Ancho: </font>
    <font color="#FFFFFF">
    <input type="text" size="5" name="wd_juego"></font><font size="2" color="#FFFFFF">
    Alto: </font><font color="#FFFFFF">
    <input type="text" size="5" name="hd_juego"></font><font size="2" color="#FFFFFF">
    </font></b></font>
    </td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
    Definir Imagen:  </font><font face="Verdana" size="2" color="#00FF00">
    </font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Imagen por Url:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="urlimg_juego"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Imagen por Upload:</font></b></td>
    <td width="50%" height="19"><input type="file" size="20" name="fileimg_juego"></td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
    Definir Archivo del Juego: </font>
    </b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Swf por Url:</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="urlswf_juego"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Swf por Pagina Externa: (IFrame)</font></b></td>
    <td width="50%" height="19"><input type="text" size="20" name="exturl_juego"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Swf por Upload:</font></b></td>
    <td width="50%" height="19"><input type="file" size="20" name="fileswf_juego"></td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
    Descripci�n:</font></b></td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><textarea name="desc_juego" rows="5" cols="44"></textarea></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Activar Juego:</font></b></td>
    <td width="50%" height="19">
     <select name="active_juego">
    <option value="1">Si</option>
    <option value="2">No</option>
   
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><input type="submit" size="20" name="enviar_juego" value="Agregar Juego"></td>
  </tr>
</table></form><b><font face="Verdana" size="1" color="#00FF00">(*) Solo Especifica el Ancho y Alto si elegiste como opcion Definir Ancho y Alto por: Definir</font></b>';

echo '<form method="POST" action="'.$volver.'" enctype="multipart/form-data">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="7">
  <tr>
    <td width="100%" colspan="2" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar 
    Juego</font></b></td>
  </tr>
  <tr>
    <td width="100%" height="19" colspan="2">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF"><a href="'.$volver.'&lista=true">[ Ver 
    lista Completa de Juegos ]</a></font></b></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Editar por Nombre:</font></b></td>
    <td width="50%" height="19">
     <input type="text" size="20" name="name_edit_juego"></td>
  </tr>
  <tr>
    <td width="50%" height="19"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Editar por Id:</font></b></td>
    <td width="50%" height="19">
     <input type="text" size="20" name="id_edit_juego"></td>
  </tr>
  <tr>
    <td width="100%" height="1" colspan="2">
    <p align="center"><input type="submit" size="20" name="b_editar_juego" value="Editar"></td>
  </tr>
</table></form>';

}

}


if($_POST['enviar_juego'])
{

$nom_juego = trim($_POST['nom_juego']);
$categ_juego = intval(trim($_POST['categ_juego']));
$tip_swf_juego = intval(trim($_POST['tip_swf_juego']));
$tip_img_juego = intval(trim($_POST['tip_img_juego']));
$tipd_juego = intval(trim($_POST['tipd_juego']));
$wd_juego = intval(trim($_POST['wd_juego']));
$hd_juego = intval(trim($_POST['hd_juego']));
$urlimg_juego = trim($_POST['urlimg_juego']);
$fileimg_juego = $_FILES['fileimg_juego'];
$urlswf_juego = trim($_POST['urlswf_juego']);
$exturl_juego = trim($_POST['exturl_juego']);
$fileswf_juego = $_FILES['fileswf_juego'];
$desc_juego = trim($_POST['desc_juego']);
$active_juego = intval(trim($_POST['active_juego']));
$add_char = $count_all_juegos + 1;

unset($error);
	
if(empty($nom_juego)) $error .= 'Error: Debes escribir un nombre para el juego.<br>';
if(search_db("juegos", "name", $nom_juego) >= 1) $error .= 'Error: Ya hay un juego con ese nombre.<br>';

if($tip_swf_juego == 1)
{
$up_swf = new UpArchivos();
$up_swf->assign_fold("files/swf");
$up_swf->assign_file($fileswf_juego);
$up_swf->assign_ext(array('swf'));
$up_swf->add_char($add_char, 0, "-");	
	
     unset($error_up);
     if(empty($fileswf_juego)) $error_up .= "Error: Debes elejir un archivo a subir.<br>";
     if(!$up_swf->ext_suport()) $error_up .= "Error: Extencion <b>".$up_swf->file_ext."</b> no Soportada<br>";
	 
     if(isset($error_up))
     {
	     $error .= $error_up;
     }
     else
     {
	     	
	        if(!$up_swf->upload_file()) $error .= 'Error: No se subio el archivo Swf.<br>';
	        $url_swf = $up_swf->file_dir;
     }
}
elseif($tip_swf_juego == 2)
{
	if(empty($urlswf_juego)) $error .= 'Error: debes especificar la url del juego.<br>';
	$url_swf = $urlswf_juego;
}
else
{
	if(empty($exturl_juego)) $error .= 'Error: debes especificar la url del juego para el IFRAME.<br>';
	$url_swf = $exturl_juego;	
}


if($tip_img_juego == 1)
{
$up_img = new UpArchivos();
$up_img->assign_fold("files/img");
$up_img->assign_file($fileimg_juego);
$up_img->assign_ext(array('jpg', 'gif', 'jpeg', 'png', 'bmp'));
$up_img->add_char($add_char, 0, "-");	
	
     unset($error_up);
      if(empty($fileimg_juego)) $error_up .= "Error: Debes elejir una imagen a subir.<br>";
     if(!$up_img->ext_suport()) $error_up .= "Error: Extencion <b>".$up_img->file_ext."</b> no Soportada<br>";
	 
     if(isset($error_up))
     {
	     $error .= $error_up;
     }
     else
     {
	     	
	        if(!$up_img->upload_file()) $error .= 'Error: No se subio la imagen.<br>';
	        $url_img = $up_img->file_dir;
     }
}
else
{
	if(empty($urlimg_juego)) $error .= 'Error: debes especificar la url de la imagen.<br>';
	$url_img = $urlimg_juego;
}


if($tipd_juego == 2)
{
	if(empty($wd_juego)) $error .= 'Error: debes especificar el Ancho del archivo Swf<br>';
	if(empty($hd_juego)) $error .= 'Error: debes especificar el Alto del archivo Swf.<br>';
}

if(empty($desc_juego)) $error .= 'Error: Debes escribir una descripcion para el Juego.<br>';


            if(isset($error))
                   {
	                  echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
                   }
            else
                   {
	                  $nom_juego = borrar_acentos($nom_juego);
	                  $desc_juego = nl2br(borrar_acentos(htmlentities($desc_juego)));
	                  $insert_newgame = M_Query("INSERT INTO juegos (id, name, descg, categ, file_dir, img_dir, votos, puntos, active, tipo_swf, tipo_img, tipo_id, size, width, height) VALUES ('', '$nom_juego', '$desc_juego', '$categ_juego', '$url_swf', '$url_img', '0', '0', '$active_juego', '$tip_swf_juego', '$tip_img_juego', '0', '$tipd_juego', '$wd_juego', '$hd_juego')"); 
                       
	                  if($insert_newgame == true)
	                        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Juego Agregado con Exito<br><a href="'.$volver.'">Volver</a></b></font></center>';  
	                   else
	                        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al agregar el juego<br>'.MySql_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
	               }
	
}

if($_POST['editar_juego'])
{
	
$id_juego = intval(trim($_POST["id_juego"]));
$nom_juego = trim($_POST["nom_juego"]);

$categ_juego = intval(trim($_POST["categ_juego"]));
$tip_swf_juego = intval(trim($_POST["tip_swf_juego"]));
$tip_img_juego = intval(trim($_POST["tip_img_juego"]));
$tipd_juego = intval(trim($_POST["tipd_juego"]));
$wd_juego = intval(trim($_POST["wd_juego"]));
$hd_juego = intval(trim($_POST["hd_juego"]));
$mod_img_juego = intval(trim($_POST["mod_img_juego"]));
$mod_swf_juego = intval(trim($_POST["mod_swf_juego"]));

$urlimg_juego = trim($_POST["urlimg_juego"]);
$urlswf_juego = trim($_POST["urlswf_juego"]);
$exturl_juego = trim($_POST["exturl_juego"]);
$desc_juego = trim($_POST["desc_juego"]);

$fileswf_juego = $_FILES['fileswf_juego'];
$fileimg_juego = $_FILES['fileimg_juego'];

$active_juego = intval(trim($_POST["active_juego"]));

$swf_act_juego = trim($_POST["swf_act_juego"]);
$img_act_juego = trim($_POST["img_act_juego"]);

unset($error);
if(empty($nom_juego)) $error .= 'Error: Debes escribir el nombre del juego.<br>';

if($mod_swf_juego == 1)
{
if($tip_swf_juego == 1)
{
unlink($swf_act_juego);
	
$up_swf = new UpArchivos();
$up_swf->assign_fold("files/swf");
$up_swf->assign_file($fileswf_juego);
$up_swf->assign_ext(array('swf'));
$up_swf->add_char($id_juego, 0, "-");	
	
     
     if(empty($fileswf_juego)) $error_up .= "Error: Debes elejir un archivo a subir.<br>";
     if(!$up_swf->ext_suport()) $error_up .= "Error: Extencion <b>".$up_swf->file_ext."</b> no Soportada<br>";
	 
     if(isset($error_up))
     {
	     $error .= $error_up;
     }
     else
     {
	     	
	        if(!$up_swf->upload_file()) $error .= 'Error: No se subio el archivo Swf.<br>';
	        $url_swf = $up_swf->file_dir;
     }
}
elseif($tip_swf_juego == 2)
{
	if(empty($urlswf_juego)) $error .= 'Error: debes especificar la url del juego.<br>';
	$url_swf = $urlswf_juego;
}
else
{
	if(empty($exturl_juego)) $error .= 'Error: debes especificar la url del juego para el IFRAME.<br>';
	$url_swf = $exturl_juego;	
}
$if_mod_swf = "file_dir = '$url_swf',";
}

if($mod_img_juego == 1)
{

if($tip_img_juego == 1)
{
unlink($img_act_juego);
$up_img = new UpArchivos();
$up_img->assign_fold("files/img");
$up_img->assign_file($fileimg_juego);
$up_img->assign_ext(array('jpg', 'gif', 'jpeg', 'png', 'bmp'));
$up_img->add_char($id_juego, 0, "-");	
	
     
     if(empty($fileimg_juego)) $error_up .= "Error: Debes elejir una imagen a subir.<br>";
     if(!$up_img->ext_suport()) $error_up .= "Error: Extencion <b>".$up_img->file_ext."</b> no Soportada<br>";
	 
     if(isset($error_up))
     {
	     $error .= $error_up;
     }
     else
     {
	     	
	        if(!$up_img->upload_file()) $error .= 'Error: No se subio la imagen.<br>';
	        $url_img = $up_img->file_dir;
     }
}
else
{
	if(empty($urlimg_juego)) $error .= 'Error: debes especificar la url de la imagen.<br>';
	$url_img = $urlimg_juego;
}
$if_mod_img = "img_dir = '$url_img',";	
}
if($tipd_juego == 2)
{
	if(empty($wd_juego)) $error .= 'Error: debes especificar el Ancho del archivo Swf<br>';
	if(empty($hd_juego)) $error .= 'Error: debes especificar el Alto del archivo Swf.<br>';
}
if(empty($desc_juego)) $error .= 'Error: Debes escribir una descripcion para el Juego.<br>';

            if(isset($error))
                   {
	                  echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
                   }
            else
                   {
	                  $nom_juego = borrar_acentos($nom_juego);
	                  $desc_juego = nl2br(borrar_acentos($desc_juego));
	                  $edit_newgame = M_Query("UPDATE juegos SET name = '$nom_juego',
	                                     descg = '$desc_juego',
	                                     categ = '$categ_juego',
	                                     $if_mod_swf 
	                                     $if_mod_img
	                                     active = '$active_juego',
	                                     tipo_swf = '$tip_swf_juego',
	                                     tipo_img = '$tip_img_juego',
	                                     size = '$tipd_juego',
	                                     width = '$wd_juego',
	                                     height = '$hd_juego' WHERE id = '$id_juego'");
	                  
	                  if($edit_newgame == true)
	                        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Juego Editado con Exito<br><a href="'.$volver.'">Volver</a></b></font></center>';  
	                   else
	                        echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al editar el juego<br>'.MySql_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
	               }
	
}


if($_POST['b_editar_juego'] || !empty($id_edit))
{
$name_edit_juego = trim($_POST['name_edit_juego']);
$id_edit_juego = intval(trim($_POST['id_edit_juego']));

if(empty($id_edit_juego)) $id_edit_juego = $id_edit;

if(empty($name_edit_juego) && empty($id_edit_juego)) $error .= 'Error: Debes de especificar 1 campo para la busqueda<br>'; 

if(!empty($name_edit_juego))
{
$where_b = "name Like '%$name_edit_juego%'";	
}
else
{
$where_b = "id = '$id_edit_juego'";	
}

                   if(isset($error))
                   {
	                  echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$error.'<br><a href="'.$volver.'">Volver</a></b></font></center>';  
                   }
                   else
                   {
                          $seach_game = M_Query("SELECT * FROM juegos WHERE $where_b AND tipo_id = '0' Limit 1");
                          if(mysql_num_rows($seach_game) == 1)
                              {
	                           $e_game = mysql_fetch_assoc($seach_game);

                               $select_categs = M_Query("SELECT id, nombre FROM categ");
	                           while($opd_categ = mysql_fetch_assoc($select_categs))
	                           {
		                          if($e_game['categ'] == $opd_categ['id'])
		                           { 
                                      $option_categs .= '<option selected value="'.$opd_categ['id'].'">'.$opd_categ['nombre'].'</option>';
                                   }
                                   else
                                   {
	                                  $option_categs .= '<option value="'.$opd_categ['id'].'">'.$opd_categ['nombre'].'</option>';
                                   }
                               }
                           mysql_free_result($select_categs);
                           
                           if($e_game['tipo_swf'] == 1)
                              {
	                                $tipo_swf_options = ' <option selected value="1">Upload</option>
   	                                                      <option value="2">Url</option>
   	                                                      <option value="3">Pagina Externa</option>';
                              }
                            elseif($e_game['tipo_swf'] == 2)
                              {
	                                $tipo_swf_options = ' <option value="1">Upload</option>
   	                                                      <option selected value="2">Url</option>
   	                                                      <option value="3">Pagina Externa</option>';
   	                                $value_swfurl = $e_game['file_dir'];
                              }
                             else
                              {
	                                $tipo_swf_options = ' <option value="1">Upload</option>
   	                                                      <option value="2">Url</option>
   	                                                      <option selected value="3">Pagina Externa</option>';
   	                                $value_swfext = $e_game['file_dir'];
                              }
                              
                              
                            if($e_game['tipo_img'] == 1)
                              {
	                                $tipo_img_options = ' <option selected value="1">Upload</option>
   	                                                      <option value="2">Url</option>';
                              }
                            else
                              {
	                                $value_imgurl = $e_game['img_dir'];
	                                $tipo_img_options = ' <option value="1">Upload</option>
   	                                                      <option selected value="2">Url</option>';
                              }
                              
                              
                              if($e_game['size'] == 1)
                              {
	                                $tipo_dimens =  $op_leidas.'
   	                                                <option value="2">Definir</option>
   	                                                '.$op_scrip;
                              }
                            elseif($e_game['size'] == 2)
                              {
	                                $tipo_dimens = '<option value="1">Funcion</option>
   	                                                <option selected value="2">Definir</option>'
   	                                                .$op_scrip;
                              }
                             else
                              {
	                                $tipo_dimens = '<option value="1">Funcion</option>
   	                                                <option value="2">Definir</option>
   	                                                <option selected value="3">Script</option>';
                              }

	                                 echo '<form method="POST" action="'.$volver.'" enctype="multipart/form-data">
	                                      <input type="hidden" value="'.$e_game['id'].'" name="id_juego">     
	                                      <input type="hidden" value="'.$e_game['file_dir'].'" name="swf_act_juego"> 
	                                      <input type="hidden" value="'.$e_game['img_dir'].'" name="img_act_juego"> 
	                                  <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="175">
	                                         <tr>
 	                                          <td width="100%" colspan="2" height="16">
 	                                          <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Editar Juego</font></b></td>
 	                                        </tr>
 	                                        <tr>
  	                                         <td width="50%" height="19"><b>
  	                                         <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
  	                                         <td width="50%" height="19"><input type="text" size="20" value="'.$e_game['name'].'" name="nom_juego"></td>
 	                                        </tr>
 	                                        <tr>
 	                                          <td width="50%" height="19"><b>
 	                                          <font face="Verdana" size="2" color="#FFFFFF">Categoria:</font></b></td>
	                                           <td width="50%" height="19">
 	                                          <select name="categ_juego">
 	                                          '.$option_categs.'
  	                                         </select>
  	                                         </td>
  	                                       </tr>
 	                                        <tr>
    	                                       <td width="50%" height="19"><b>
    	                                       <font face="Verdana" size="2" color="#FFFFFF">Editar Swf por:</font></b></td>
    	                                       <td width="50%" height="19">
    	                                       <select name="tip_swf_juego">
    	                                       '.$tipo_swf_options.'
   	                                        </select>
   	                                        </td>
  	                                       </tr>
 	                                        <tr>
    	                                       <td width="50%" height="19"><b>
    	                                       <font face="Verdana" size="2" color="#FFFFFF">Editar Imagen por:</font></b></td>
    	                                       <td width="50%" height="19">
   	                                        <select name="tip_img_juego">
   	                                        '.$tipo_img_options.'
 	                                          </select>
  	                                         </td>
  	                                       </tr>
  	                                       <tr>
   	                                        <td width="50%" height="19"><b>
   	                                        <font face="Verdana" size="2" color="#FFFFFF">Definir Ancho y Alto por:</font></b></td>
   	                                        <td width="50%" height="19">
   	                                        <select name="tipd_juego">
   	                                       '.$tipo_dimens.'
   	                                        </select> 
   	                                        <b><font face="Verdana" size="1" color="#FFFFFF">Recomendado 
    	                                       Funcion</font></b></td>
  	                                       </tr>
  	                                       <tr>
   	                                        <td width="50%" height="19"><b>
   	                                        <font face="Verdana" size="2" color="#FFFFFF">Define el Ancho y Alto: </font>
   	                                        <font face="Verdana" size="1" color="#00FF00">(*)</font></b></td>
   	                                        <td width="50%" height="19">
   	                                        <font face="Verdana"><b><font size="2" color="#FFFFFF">Ancho: </font>
   	                                        <font color="#FFFFFF">
   	                                        <input type="text" value="'.$e_game['width'].'" size="5" name="wd_juego"></font><font size="2" color="#FFFFFF">
   	                                        Alto: </font><font color="#FFFFFF">
   	                                        <input type="text" value="'.$e_game['height'].'" size="5" name="hd_juego"></font><font size="2" color="#FFFFFF">
   	                                        </font></b></font>
   	                                        </td>
 	                                        </tr>
 	                                        <tr>
  	                                         <td width="100%" height="19" colspan="2">
  	                                         <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
  	                                         Elije si deseas cambiar archivos:  </font><font face="Verdana" size="2" color="#00FF00">
 	                                          </font></b></td>
 	                                        </tr>
 	                                        <tr>
    	                                       <td width="50%" height="19"><b>
    	                                       <font face="Verdana" size="2" color="#FFFFFF">Cambiar Imagen:</font></b></td>
    	                                       <td width="50%" height="19">
   	                                        <select name="mod_img_juego">
   	                                         <option value="1">Si</option>
   	                                         <option selected value="2">No</option>
 	                                          </select>
  	                                         </td>
  	                                       </tr>
  	                                        <tr>
    	                                       <td width="50%" height="19"><b>
    	                                       <font face="Verdana" size="2" color="#FFFFFF">Cambiar Archivo Swf:</font></b></td>
    	                                       <td width="50%" height="19">
   	                                        <select name="mod_swf_juego">
   	                                        <option value="1">Si</option>
   	                                        <option selected value="2">No</option>
 	                                          </select>
  	                                         </td>
  	                                       </tr>
 	                                        <tr>
  	                                         <td width="100%" height="19" colspan="2">
  	                                         <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
  	                                         Definir Imagen:  </font><font face="Verdana" size="2" color="#00FF00">
 	                                          </font></b></td>
 	                                        </tr>
	                                         <tr>
	                                           <td width="50%" height="19"><b>
	                                       	                                           <font face="Verdana" size="2" color="#FFFFFF">Imagen por Url:</font></b></td>
	                                           <td width="50%" height="19"><input type="text" size="20" value="'.$value_imgurl.'" name="urlimg_juego"></td>
	                                         </tr>
	                                        	                                        <tr>
	                                           <td width="50%" height="19"><b>
	                                           <font face="Verdana" size="2" color="#FFFFFF">Imagen por Upload:</font></b></td>
	                                           <td width="50%" height="19"><input type="file" size="20" name="fileimg_juego"></td>
	                                         </tr>
 	                                        <tr>
	                                           <td width="100%" height="19" colspan="2">
 	                                          <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
 	                                          Definir Archivo del Juego: </font>
	                                           </b></td>
 	                                        </tr>
 	                                        <tr>
 	                                          <td width="50%" height="19"><b>
 	                                          <font face="Verdana" size="2" color="#FFFFFF">Swf por Url:</font></b></td>
 	                                          <td width="50%" height="19"><input type="text" value="'.$value_swfurl.'" size="20" name="urlswf_juego"></td>
 	                                        </tr>
 	                                        <tr>
	                                           <td width="50%" height="19"><b>
	                                           <font face="Verdana" size="2" color="#FFFFFF">Swf por Pagina Externa: (IFrame)</font></b></td>
	                                           <td width="50%" height="19"><input type="text" value="'.$value_swfext.'" size="20" name="exturl_juego"></td>
	                                         </tr>
	                                         <tr>
	                                           <td width="50%" height="19"><b>
	                                           <font face="Verdana" size="2" color="#FFFFFF">Swf por Upload:</font></b></td>
 	                                          <td width="50%" height="19"><input type="file" size="20" name="fileswf_juego"></td>
	                                         </tr>
 	                                        <tr>
  	                                         <td width="100%" height="19" colspan="2">
 	                                          <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">
  	                                         Descripci�n:</font></b></td>
 	                                        </tr>
	                                         <tr>
 	                                          <td width="100%" height="19" colspan="2">
 	                                          <p align="center"><textarea name="desc_juego" rows="5" cols="44">'.$e_game['descg'].'</textarea></td>
 	                                        </tr>
 	                                        <tr>
 	                                          <td width="50%" height="19"><b>
 	                                          <font face="Verdana" size="2" color="#FFFFFF">Activar Juego:</font></b></td>
 	                                          <td width="50%" height="19">
 	                                           <select name="active_juego">';
 	                                           if($e_game['active'] == 1)
 	                                           {
	 	                                           echo '
  	                                              <option selected value="1">Si</option>
 	                                              <option value="2">No</option>';
	                                           }
	                                           else
	                                           {
		                                          echo '
  	                                              <option value="1">Si</option>
 	                                              <option selected value="2">No</option>';
	                                           }
   	                                     echo '</select>
  	                                         </td>
 	                                        </tr>
 	                                        <tr>
 	                                          <td width="100%" height="19" colspan="2">
 	                                          <p align="center"><input type="submit" size="20" name="editar_juego" value="Editar Juego"></td>
	                                         </tr>
	                                       </table></form><p align="center"><font face="Verdana" size="2" color="#FFFFFF"><a href="'.$volver.'&borrar_id='.$e_game['id'].'"><b>[ Borrar Juego ]</b></a></font></p>';
                              }
                              else
                              {
	                              echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el juego.<br><a href="'.$volver.'">Volver</a></b></font></center>';  
                              }
                       mysql_free_result($seach_game);
                   }
	
}

if($lista)
{

if($count_all_juegos <= 0)
{
	 echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontraron juegos.<br><a href="'.$volver.'">Volver</a></b></font></center>';  
}
else
{

//Cantidad de Juegos por Pagina ////	
$ExP = 10;                          //
//////////////////////////////////////
$Sec = intval($_GET['cat']);
$Des = $ExP * $Sec;

$sel_games = M_Query("SELECT id, name FROM juegos WHERE tipo_id = '0' ORDER BY id ASC LIMIT $Des, $ExP");	
$count_all = MySql_Num_Rows($sel_games);
echo '<p align="left"><font face="Verdana" size="2" color="#FFFFFF">';
while($g_list = MySql_Fetch_Assoc($sel_games))
{ 
	$a++;
	echo $a.' .- <a href="'.$volver.'&id_edit='.$g_list['id'].'">'.$g_list['name'].'</a><br>';
}
echo '</font></p>';
mysql_free_result($sel_games);


$page = $count_all_juegos / $ExP;
echo '<p align="center"><font size="2" face="Verdana">';
$page2 = $page - 1;
if($Sec == ''){ $prev = ''; }


if($Sec >= 1){ $prev = $Sec - 1; echo '<a href="'.$volver.'&lista=true&cat='.$prev.'">< Anterior</a> -'; }
for ($x = 1; $x < $page;$x++) {
if($x == $Sec){
	echo " [$x] ";
}
else{
echo ' [<a href="'.$volver.'&lista=true&cat='.$x.'">'.$x.'</a>] ';
}
}
if($Sec >= 0 and $Sec < $page2 and $page >= 1){ $next = $Sec + 1; echo '- <a href="'.$volver.'&lista=true&cat='.$next.'">Siguiente ></a>'; }

}
}

if($borrar_id)
{
	$confirm = $_GET['confirm'];
	$select_dgame = M_Query("SELECT id, name, file_dir, img_dir, tipo_swf, tipo_img FROM juegos WHERE id = '$borrar_id' and tipo_id = '0' LIMIT 1");
	    if(mysql_num_rows($select_dgame) == 1)
	        {
		        $del_game = mysql_fetch_assoc($select_dgame);
		         
		              echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Juego: '.$del_game['name'].'</b></font></p>';
		               if(!$confirm)
		                  {
		                     echo '<p align="center"><font face="Verdana" size="2" color="#FFFFFF"><b><a href="'.$volver.'&borrar_id='.$del_game['id'].'&confirm=true">[ Confirmar ]</a>  -  <a href="'.$volver.'">[ Cancelar ]</a></b></font></p>';
	                      }
	                   else
	                      {
		                      $delete_game = M_Query("DELETE FROM juegos WHERE id = '$borrar_id' and tipo_id = '0'");
		                           if($delete_game == true)
		                                {
			                                if($del_game['tipo_swf'] == 1) unlink($del_game['file_dir']);
			                                if($del_game['tipo_img'] == 1) unlink($del_game['img_dir']);
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Juego Borrado con Exito.<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                           else
		                                {
			                                echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al Borrar el Juego.<br>'.MySQL_Error().'<br><a href="'.$volver.'">Volver</a></b></font></center>';
		                                }
		                      
	                      }
		        
	        }
	     else
	     {  
		     echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>No se encontro el juego.<br><a href="'.$volver.'">Volver</a></b></font></center>';
	     }
	mysql_free_result($select_dgame);
}

?>