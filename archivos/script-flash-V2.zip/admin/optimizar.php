<?php

if(!defined("flash_script")) die("Error");

$option = trim($_GET['option']);

if(empty($option))
{
echo '<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #FF9900; background-color: #006699" width="100%" id="AutoNumber1" height="1">
  <tr>
    <td width="100%" height="16">
    <p align="center"><b><font face="Verdana" size="2" color="#FFFFFF">Opciones</font></b></td>
  </tr>
  <tr>
    <td width="100%" height="21">
    <font face="Verdana" size="2" color="#FFFFFF">
    
     - <a href="'.$volver.'&option=tables">Optimizar todas la tablas</a><br>
     - <a href="'.$volver.'&option=vaciar">Vaciar tabla Visitantes</a>
    
    </font>
    </td>
  </tr>
  </table>';
}
  
if($option == 'tables')
{
$sel_tables = mysql_list_tables($db);
$a = 0;
while($table = mysql_fetch_row($sel_tables))
{
	$a++;
	$tabla = mysql_real_escape_string($table[0]);
	if(M_Query("OPTIMIZE TABLE $tabla"))
	    {
		    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$a.'.- Exito al optimizar la tabla: '.$tabla.'</b></font></center><br>';
	    }
	 else
	    {
		    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>'.$a.'.- Error al optimizar la tabla: '.$tabla.'</b></font></center><br>';
	    }
}

mysql_free_result($sel_tables);
}

if($option == 'vaciar')
{

	if(M_Query("TRUNCATE TABLE visitantes"))
	    {
		    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Exito vaciar la tabla Visitantes.</b></font></center><br>';
	    }
	 else
	    {
		    echo '<center><font face="Verdana" size="2" color="#FFFFFF"><b>Error al vaciar la tabla Visitantes.</b></font></center><br>';
	    }
}




?>
