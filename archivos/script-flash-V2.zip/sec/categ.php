<?

if(!defined("flash_script")) die("Error");
    
    

    $by_categ = intval(trim($_GET['id']));
    
//Cantidad de Juegos por Pagina //////	
$ExP = 10;                          //
//////////////////////////////////////

$Sec = intval($_GET['sec']);
$Des = $ExP * $Sec;

	$select_games = M_Query("SELECT id, name, descg, img_dir, tipo_id FROM juegos WHERE (categ = '$by_categ') AND (active = '1' AND tipo_id = '0') ORDER BY id DESC LIMIT $Des, $ExP");	
	$game_enc = mysql_num_rows($select_games);
	
	echo "<center>[ Categoria $categ_nom ]</center>";
	
	if($game_enc >= 1)
	{
		  while($_news = mysql_fetch_assoc($select_games))
		  {
			
				   $url_to_game = (!$mod_rewrite) ? '<center>[ <a href="juego.php?id='.$_news['id'].'&name='.mod_s($_news['name']).'">Ir al Juego '.$_news['name'].'</a> ]</center>' : '<center>[ <a href="juego-'.$_news['id'].'-'.mod_rew($_news['name']).'.html">Jugar '.$_news['name'].'</a> ]</center>';
				   
				   $_cont = '<img align="right" src="'.$_news['img_dir'].'" alt="Flash '.$_news['name'].'" title="Flash '.$_news['name'].'" />'.$_news['descg'].'<p>'.$url_to_game;
				   
			       echo tabla_cont('Juego - '.$_news['name'], $_cont);
		  
			  
		  }
		  
		  $pagi_not = M_Query("SELECT COUNT(id) AS id_c FROM juegos WHERE (categ = '$by_categ') AND (active = '1' AND tipo_id = '0') LIMIT 1");
		  $row_n = mysql_fetch_assoc($pagi_not);
		  mysql_free_result($pagi_not);
		  $pagi_cou = intval($row_n['id_c']);


		  $page = $pagi_cou / $ExP;
		  echo '<p align="center"><font size="2" face="Verdana">';
		  $page2 = $page - 1;
		  if($Sec == ''){ $prev = ''; }

          $categ_nrew = mod_rew($_GET['name']);

		  if($Sec >= 1){ $prev = $Sec - 1; if(!$mod_rewrite) echo '<a href="index.php?modulo=categ&id='.$by_categ.'&name='.$categ_nrew.'&sec='.$prev.'">< Anterior</a> -'; else echo '<a href="categoriap-'.$by_categ.'-'.$categ_nrew.'-'.$prev.'.html">< Anterior</a> -'; }
		  for ($x = 1; $x < $page;$x++) {
		  if($x == $Sec){
			  echo " [$x] ";
		  }
		  else{
		   if(!$mod_rewrite) echo ' [<a href="index.php?modulo=categ&id='.$by_categ.'&name='.$categ_nrew.'&sec='.$x.'">'.$x.'</a>] '; else echo ' [<a href="categoriap-'.$by_categ.'-'.$categ_nrew.'-'.$x.'.html">'.$x.'</a>] ';
		  }
		  }
		  if($Sec >= 0 and $Sec < $page2 and $page >= 1){ $next = $Sec + 1; if(!$mod_rewrite) echo '- <a href="index.php?modulo=categ&id='.$by_categ.'&name='.$categ_nrew.'&sec='.$next.'">Siguiente ></a>'; else echo '- <a href="categoriap-'.$by_categ.'-'.$categ_nrew.'-'.$next.'.html">Siguiente ></a>'; }
          
		  echo '</font></p>';
		  
	}

?>