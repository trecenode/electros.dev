<?

if(!defined("flash_script")) die("Error");

$url_action = (!$mod_rewrite) ? "index.php?modulo=$tipo" : "$tipo.html" ;    

$_selectcategs = M_Query("SELECT id, nombre FROM categ WHERE active = '1'");
while($_cteg = mysql_fetch_assoc($_selectcategs))
{
	$_categories .= "<option value=\"$_cteg[id]\">$_cteg[nombre]</option>";
}
mysql_free_result($_selectcategs);

if(!$_POST['search_send'])
{
$_tabla_search = '<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
<form method="POST" action="'.$url_action.'"> 
 <tr>
    <td width="50%"><font face="Verdana" size="2">Buscar por Titulo:</font></td>
    <td width="50%"><input type="text" size="20" name="by_name"></td>
  </tr>
 <tr>
    <td width="50%">&nbsp;</td>
    <td width="50%"><select name="add_desc"><option value="NOT">NO</option><option value="AND">AND</option><option value="OR">OR</option></select></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Buscar por Descripci�n:</font></td>
    <td width="50%">
   <textarea name="by_desc" rows="3" cols="20"></textarea></td>
  </tr>
  <tr>
    <td width="50%"></td>
    <td width="50%"><select name="add_categ"><option value="NOT">NO</option><option value="AND">AND</option></select></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Por categoria:</font></td>
    <td width="50%">
    <select name="by_categ">
    <option selected value="0">Todas</option>
    '.$_categories.'
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><center><input type="submit" size="10" name="search_send" value="Buscar"><center>
    <p></p>
    </td>
  </tr>
</table>';

echo tabla_cont('Buscador', $_tabla_search);
}
else
{

	
  $by_name = trim($_POST['by_name']);
  $by_desc = trim($_POST['by_desc']);
  $by_categ = trim($_POST['by_categ']);

  $add_desc = trim($_POST['add_desc']);
  $add_categ = trim($_POST['add_categ']);
  
  if($add_desc == 'NOT')
  {
	  $descg_ops = "";
  }
  else
  {
  	 $descg_ops = "$add_desc descg LIKE '%$by_desc%'"; 
  }
  
  if($add_desc == 'NOT')
  {
	  $categ_ops = "";
  }
  else
  {
  	 $categ_ops = "$add_categ categ = '$by_categ'"; 
  }
	

   
    if(empty($by_name) && empty($by_desc)) $error .= 'Error: Debes escribir al menos un criterio de busqueda.<br>';

          if(isset($error))
               {
	               $_search_body = $error;
               } 
           else
               { 
                  $_search_query = M_Query("SELECT id, name, descg, categ FROM juegos WHERE (name LIKE '%$by_name%' $descg_ops $categ_ops) AND (active = '1' AND tipo_id = '0')");
                   
                   $_search_count = mysql_num_rows($_search_query);
                   if($_search_count >= 1)
                   {
	                   while($_srow = mysql_fetch_assoc($_search_query))
	                   {
		                   $sc++;
		                   $url_result = (!$mod_rewrite) ? 'juego.php?id='.$_srow['id'].'&name='.mod_s($_srow['name']) : 'juego-'.$_srow['id'].'-'.mod_rew($_srow['name']).'.html';
		                   $_search_body .= $sc.'.- <a href="'.$url_result.'">'.$_srow['name'].'</a><br>';   
	                   }
                   }
                   else
                   {
	                   $_search_body = 'No se encontraron resultados.<br>'.mysql_error();
                   }
                  
                   
               }
      echo tabla_cont('Resultados de la Busqueda...', "<center>$_search_body</center>");
}

?>