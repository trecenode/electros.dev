<?

if(!defined("flash_script")) die("Error");
    
    

//Cantidad de Noticias por Pagina ////	
$ExP = 10;                           //
//////////////////////////////////////

$Sec = intval($_GET['sec']);
$Des = $ExP * $Sec;

	$select_news = M_Query("SELECT id, name, descg, img_dir, tipo_id FROM juegos WHERE active = '1' ORDER BY id DESC LIMIT $Des, $ExP");	
	
	if(mysql_num_rows($select_news) >= 1)
	{
		  while($_news = mysql_fetch_assoc($select_news))
		  {
			 if($_news['tipo_id'] == 0) 
			   {
				   $url_to_game = (!$mod_rewrite) ? '<center>[ <a href="juego.php?id='.$_news['id'].'&name='.mod_s($_news['name']).'">Ir al Juego '.$_news['name'].'</a> ]</center>' : '<center>[ <a href="juego-'.$_news['id'].'-'.mod_rew($_news['name']).'.html">Ir al Juego '.$_news['name'].'</a> ]</center>';
				   
				   $_cont = '<img align="right" src="'.$_news['img_dir'].'" alt="Flash '.$_news['name'].'" title="Flash '.$_news['name'].'" />'.$_news['descg'].'<p>'.$url_to_game;
				   
			       echo tabla_cont('Juego - '.$_news['name'], $_cont);
		       } 
		     else
		       {
			       echo tabla_cont('Noticia - '.$_news['name'], $_news['descg']);
		       }
			  
		  }
		  
		  mysql_free_result($select_news);
		  
		  $pagi_not = M_Query("SELECT COUNT(id) AS id_c FROM juegos LIMIT 1");
		  $row_n = mysql_fetch_assoc($pagi_not);
		  mysql_free_result($pagi_not);
		  $pagi_cou = intval($row_n['id_c']);


		  $page = $pagi_cou / $ExP;
		  echo '<p align="center"><font size="2" face="Verdana">';
		  $page2 = $page - 1;
		  if($Sec == ''){ $prev = ''; }



		  if($Sec >= 1){ $prev = $Sec - 1; if(!$mod_rewrite) echo '<a href="index.php?sec='.$prev.'">< Anterior</a> -'; else echo '<a href="pag-'.$prev.'.html">< Anterior</a> -'; }
		  for ($x = 1; $x < $page;$x++) {
		  if($x == $Sec){
			  echo " [$x] ";
		  }
		  else{
		   if(!$mod_rewrite) echo ' [<a href="index.php?sec='.$x.'">'.$x.'</a>] '; else echo ' [<a href="pag-'.$x.'.html">'.$x.'</a>] ';
		  }
		  }
		  if($Sec >= 0 and $Sec < $page2 and $page >= 1){ $next = $Sec + 1; if(!$mod_rewrite) echo '- <a href="index.php?sec='.$next.'">Siguiente ></a>'; else echo '- <a href="pag-'.$next.'.html">Siguiente ></a>'; }
          echo '</font></p>';

		  
	}
	
?>