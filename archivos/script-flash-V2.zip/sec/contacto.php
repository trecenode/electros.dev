<?

if(!defined("flash_script")) die("Error");

$url_action = (!$mod_rewrite) ? "index.php?modulo=$tipo" : "$tipo.html" ;    


if(!$_POST['mail_send'])
{
$_tabla_mail = '<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
             <form method="POST" action="'.$url_action.'"> 
 <tr>
    <td width="50%"><font face="Verdana" size="2">Tu Nombre:</font></td>
    <td width="50%"><input type="text" size="20" name="name_user"></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Tu Correo:</font></td>
    <td width="50%"><input type="text" size="20" name="mail_user"></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Tema:</font></td>
    <td width="50%">
    <select name="mail_subject">
    <option selected value="Comentarios">Comentarios</option>
    <option value="Sugerencias">Sugerencias</option>
    <option value="Errores">Errores</option>
    <option value="Intercambio de Enlaces">Intercambio de Enlaces</option>
    <option value="Publicidad">Publicidad</option>
    </select>
    </td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><font face="Verdana" size="2">
    <center>
   Mensaje:</font>
   <br>
   <textarea name="mail_text" rows="9" cols="45"></textarea>
   </center>
   </td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><center><input type="submit" size="20" name="mail_send" value="Enviar Mensaje"><center>
    <p></p>
    </td>
  </tr>
</table>';

echo tabla_cont('Enviar Mensaje', $_tabla_mail);
}
else
{
   require "class/class.phpmailer.php";
	
  $name_user = trim($_POST['name_user']);
  $mail_user = trim($_POST['mail_user']);
  $mail_subject = trim($_POST['mail_subject']);
  $mail_text = trim($_POST['mail_text']);
	

  $mail = new phpmailer();
  $mail->PluginDir = "class/";
  $mail->Mailer = "smtp";
  
  $mail->Host = $_servidorsmtp;
  $mail->Username = $_usuariosmtp; 
  $mail->Password = $_passwordsmtp;
  
  $mail->SMTPAuth = true;
  $mail->IsHTML(true);


  $mail->From = $mail_user;
  $mail->FromName = $name_user;
  $mail->Timeout=30;

  
  $mail->AddAddress("$webmaster");
  $mail->Subject = $mail_subject;
     
  $mail->Body = $mail_text;
  $mail->AltBody = $mail_text;
   
    if(empty($name_user) || strlen($name_user) < 4) $error .= 'Error: Debes escribir tu nombre y debe ser de 4 o mas caracteres.<br>';
    if(empty($mail_user) || !es_correo($mail_user)) $error .= 'Error: Debes escribir tu correo y debe ser Valido.<br>';                
    if(empty($mail_text) || strlen($mail_text) < 10) $error .= 'Error: Debes escribir tu mensaje y debe ser de 10 o mas caracteres.<br>';                
  
          if(isset($error))
               {
	               $_contacto_body = $error;
               } 
           else
               { 
                   $_contacto_body = (!$mail->Send()) ? 'Error al enviar el mensaje, intenta mas tarde.<br>'.$mail->ErrorInfo : 'Mensaje Enviado Correctamente.';
               }
      echo tabla_cont('Enviando Mensaje...', "<center>$_contacto_body</center>");
}

?>