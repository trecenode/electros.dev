<?

if(!defined("flash_script")) die("Error");
$id_g = intval($_GET['rid']);

$url_action = (!$mod_rewrite) ? "index.php?modulo=$tipo&rid=$id_g" : "$tipo-$id_g.html" ;    

$_select_g = M_Query("SELECT id, name, descg FROM juegos WHERE id = '$id_g' AND (active = '1' AND tipo_id = '0') LIMIT 1");
$_num_rows = mysql_num_rows($_select_g);

$_rrow = mysql_fetch_assoc($_select_g);

$_juegoi = $_rrow['id'];
$_juegon = $_rrow['name'];
$_juegod = $_rrow['descg'];

mysql_free_result($_select_g);


$_boton_send = ($_num_rows == 1) ? '<input type="submit" size="20" name="mail_send" value="Recomendar">' : '[ Error ]';

if(!$_POST['mail_send'])
{
$_tabla_mail = '<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <form method="POST" action="'.$url_action.'">   
 <tr>
    <td width="100%" colspan="2"><font face="Verdana" size="2">
   <center>Recomendar Juego - '.$_juegon.'</center></font></td>
  </tr>
    
 <tr>
    <td width="50%"><font face="Verdana" size="2">Tu Nombre:</font></td>
    <td width="50%"><input type="text" size="20" name="name_user"></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Tu Correo:</font></td>
    <td width="50%"><input type="text" size="20" name="mail_user"></td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Nombre de tu Amigo:</font></td>
    <td width="50%">
    <input type="text" size="20" name="to_user">
    </td>
  </tr>
  <tr>
    <td width="50%"><font face="Verdana" size="2">Correo de tu Amigo:</font></td>
    <td width="50%"><input type="text" size="20" name="to_mail"></td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><center>'.$_boton_send.'<center>
    <p></p>
    </td>
  </tr>
</table>';

echo tabla_cont('Recomendar', $_tabla_mail);
}
else
{
   require "class/class.phpmailer.php";
	
  $name_user = trim($_POST['name_user']);
  $mail_user = trim($_POST['mail_user']);
  $to_user = trim($_POST['to_user']);
  $to_mail = trim($_POST['to_mail']);
  
  $url_rec_game = (!$mod_rewrite) ? $url_web.'/juego.php?id='.$_juegoi.'&name='.mod_s($_juegon) : $url_web.'/juego-'.$_juegoi.'-'.mod_rew($_juegon).'.html';
  
  $_message_rec = '<font face="Verdana" size="2">Hola '.$to_user.', tu amigo '.$name_user.' con correo '.$mail_user.' te 
recomienda el juego '.$_juegon.', el cual trata de:</font></p>
<p><font face="Verdana" size="2">'.$_juegod.'</font></p>
<font face="Verdana" size="2">
<a href="'.$url_rec_game.'">Ir al Juego</a><br>
Url: '.$url_rec_game.' </font>
<p><font face="Verdana" size="2">Este y mas juegos encontraras en : <a href="'.$url_web.'">'.$web.'</a>
<br>
'.$url_web.' </font>';
	

  $mail = new phpmailer();
  $mail->PluginDir = "class/";
  $mail->Mailer = "smtp";
  
  $mail->Host = $_servidorsmtp;
  $mail->Username = $_usuariosmtp; 
  $mail->Password = $_passwordsmtp;
  
  $mail->SMTPAuth = true;
  $mail->IsHTML(true);


  $mail->From = $mail_user;
  $mail->FromName = $name_user;
  $mail->Timeout=30;

  
  $mail->AddAddress("$to_mail");
  $mail->Subject = "Juego Recomendado";
     
  $mail->Body = $_message_rec;
  $mail->AltBody = $_message_rec;
   
    if(empty($name_user) || strlen($name_user) < 4) $error .= 'Error: Debes escribir tu nombre y debe ser de 4 o mas caracteres.<br>';
    if(empty($mail_user) || !es_correo($mail_user)) $error .= 'Error: Debes escribir tu correo y debe ser Valido.<br>';                
    if(empty($to_user) || strlen($to_user) < 4) $error .= 'Error: Debes escribir el nombre de tu amigo y debe ser de 4 o mas caracteres.<br>';
    if(empty($to_mail) || !es_correo($to_mail)) $error .= 'Error: Debes escribir el correo de tu amigo y debe ser Valido.<br>';     
    
    
       if(isset($error))
               {
	               $_contacto_body = $error;
               } 
           else
               { 
                   $_contacto_body = (!$mail->Send()) ? 'Error al enviar el mensaje, intenta mas tarde.<br>'.$mail->ErrorInfo : 'Juego Recomendado Correctamente.';
               }
      echo tabla_cont('Enviando Mensaje...', "<center>$_contacto_body</center>");
}

?>