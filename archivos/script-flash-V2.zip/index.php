<?
include 'config.inc.php';
include 'class/funciones.php';
include 'class/temp.php';
$tiempo_inicio = tiempo_carga();

    $nom_categ = trim($_GET['name']);

    if(!$mod_rewrite) $categ_nom = urldecode($nom_categ); else $categ_nom = str_replace("-", "", $nom_categ);
    $categ_nom = ucfirst($categ_nom);
    
    $titulo = $web;
    if(!empty($categ_nom)) $titulo = $web.' Categoria '.$categ_nom;
    
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><? echo $titulo; ?></title>
<link rel="StyleSheet" href="imagenes/style.css" type="text/css">


</head>

<body>
<table width="776" border="0" align="center" cellpadding="0" cellspacing="0" height="623">
  <tr>
    <td height="250" background="imagenes/h01.jpg">&nbsp;</td>
  </tr>
  <tr>
    <td background="imagenes/bg.jpg" height="235">
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="150" valign="top">
        
             <!-- BLOQUES IZQUIERDA -->
             
              <?
              include 'block/menu.php';
              ?>

              <br>
 
              <?
              include 'block/categs.php';
              ?>
              
              <br>
              
              <?
              include 'block/banner-1.php';
              ?>

             <br>
         
              <?
              include 'block/links.php';
              ?>
     
         <!-- FIN BLOQUES IZQUIERDA -->

           </td>
            <td valign="top">
        
              <?
              include 'home.php';
              ?>
        
        </td>
        <td width="150" valign="top">
        
        <!-- BLOQUES DERECHOS -->
        

           <?
              include 'block/last-flash.php';
           ?>

        <br>

           
           <?
              include 'block/pop-flash.php';
           ?>
           
        <br>
        
           <?
              include 'block/search.php';
           ?>   
 
        <br>
        
           <?
              include 'block/stats.php';
           ?>   
 
        <br>

     
            <?
              include 'block/rand-flash.php';
            ?>

       
        
         <!-- FIN BLOQUES DERECHOS -->
        
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="138" background="imagenes/f01.jpg">&nbsp;</td>
  </tr>
</table>
<?
include 'footer.php';
?>
</body>
</html>