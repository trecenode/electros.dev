<?php
///////////////////////////////////////////*/
// Script Juegos Flash V2
// Programador: Pablo Ramirez
// Correo: pablo@celwebs.com
// Licencia: Gratuita
// Nota: El script es totalmente gratuito
//       y se prohibe su venta.
// http://www.celwebs.com
///////////////////////////////////////////*/


$dbhost = "localhost"; 
$dbuser = "usuario";
$dbpass = "password";
$db = "base_de_datos";

$conect = @MySql_Connect($dbhost,$dbuser,$dbpass);
@MySql_Select_DB($db);


$web = 'FlashGame';

$url_web = 'http://www.webflash.com';

//Datos para el envio de correo
//Estos datos deben de ser validos

$webmaster = "webmaster@servidor.com"; //Correo a donde se enviaran los mensajes

$_servidorsmtp = "mail.servidor.com"; // Ej: smtp.mail.yahoo.com
$_usuariosmtp = "mi_usuario";        // Ej: juanperez Con o sin @servidor.com dependiendo del servicio
$_passwordsmtp = "mi_password";   // Ej: password de la cuenta de correo

//Si quieres un mismo tama�o para todos los archivos flash dale valor a estas variables:
$width = 500;
$height = 500;

//Minutos de tolerancia para mostrar los usuarios online, por default 5 minutos

$_minutes = 5;

//Con esta opcion activada los Passwords de los administradores 
//Deberan ser Alfanumericos y mayores a 6 caracteres
//Recomendable para mayor seguridad

$password_seguro = false;

//Con esta opcion activada se revisara en la administracion si existe ya algun administrador
//Y en caso de no haberlo se activara un formulario para crearlo.
//Es aconsejable desactivarlo despues de crear el primer administrador
//Para Desactivarlo cambie el valor true por false

$seach_if_admin_exist = true;

//Activa o desactiva la opcion para url amigables
//true para activar y false para desactivar

$mod_rewrite = false;


$errordb = Mysql_Error();
if($errordb != ''){
	die('<html>
         <head>
         <title>'.$web.': Error</title>
         </head>
         <body>
         <p align="center"><font size="2" face="Verdana">Error en la conexi�n con la Base de Datos.<br>
         Error: <b>'.$errordb.'<br>Error N�: <b>'.mysql_errno().'</b></b>
         <br>
         Estaremos online lo antes posible.</font></p>
         <p align="center"><font size="2" face="Verdana">Staff de '.$web.'</font></p>
         </body>
         </html>');
}

define("flash_script", true);

//Para Versiones Antiguas de PHP

if(!isset($_POST)) $_POST = $HTTP_POST_VARS;
if(!isset($_GET)) $_GET = $HTTP_GET_VARS;
if(!isset($_COOKIE)) $_COOKIE = $HTTP_COOKIE_VARS;

//Verificamos si esta disponible la libreria GD para creacion de Imagenes
$gd_lib = (function_exists("imagecreatefromjpeg")) ? true : false; 
?>
