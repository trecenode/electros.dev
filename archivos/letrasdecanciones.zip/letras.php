<table>
<tr>
<td colspan=2><font class=resaltado>Letras de canciones</font></td>
</tr>
<?
include("config.php") ;
if($l) {
$resp = mysql_query("select * FROM letras where id='$l'") ;
$datos = mysql_fetch_array($resp) ;
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Se agregan los <br> a la letra de la canci�n
$letra = $datos[letra] ;
$letra = str_replace("\r\n","<br>",$letra) ;
if($datos[usuario] == $_COOKIE["unick"]) { $editar = "<a href='?ver=letraseditar&id=$datos[id]' style='font-face:Verdana;font-size:12;color:white;font-weight:bold'>Editar</a>" ; }
elseif($_COOKIE["unick"] == "Juli�n Esteban") { $editar = "<a href='?ver=letraseditar&id=$datos[id]' style='font-face:Verdana;font-size:12;color:white;font-weight:bold'>Editar</a>" ; }
else { $editar = "" ; }
echo "
<tr>
<td valign=top><font class=noticiastitulo>Titulo:</font><font color=white size=2 face=Verdana> $datos[titulo] $editar</font><br>
<font class=noticiasabajo>Interprete:</font><font color=white size=2 face=Verdana> $datos[interprete]</font><br>
<font class=noticiasabajo>Enviado por:</font><font color=white size=2 face=Verdana> $datos[usuario]</font></td>

<td valign=top><div align=right valign=top><font class=resaltado>$fecha</font></div><p></td>
</tr>

<tr>
<td colspan=2><font face=Verdana color=white size=2><p>$letra</font>
<p><a href=letras.php style=font-size:10;font-family:Verdana;color:white;font-weight:bold>Volver a Letras de Canciones</a>
<p>
" ;
mysql_free_result($resp) ;
echo "<p><font class=noticiastitulo>Comentarios</font>" ;
$mostrar = 5 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * FROM letrascom where letra='$l' ORDER BY id desc LIMIT $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p><font face=Verdana color=white size=2>No se encontraron comentarios.</font>" ; }
else {
$comentarios = mysql_num_rows($resp) ;
echo "
<p><font class=noticiasabajo>Total de comentarios:</font> <font face=Verdana size=2 color=white>$comentarios</font>
<p>
" ;
while($datos = mysql_fetch_array($resp)) {
// Mostrar fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
echo "
<table width=100% cellpadding=1 cellspacing=0 style=\"border: red ; background: red; margin: 1; padding: 1\">
<tr>
<td bgcolor=brown><div class=noticiastitulo style=color:yellow;font-size:10>&lt;<b>$datos[usuario]</b>&gt;</div></td>
<td bgcolor=brown><div align=right><b class=noticiastitulo style=color:white;font-size:10>$fecha</b></div></td>
</tr>
<tr>
<td colspan=2>
<font color=white face=Arial size=2>$datos[comentario]</font>
</td>
</tr>
</table><br>
" ;
}
?>
<? if($comentarios == "0") { ?>
<p align="right"><a style=\"color:white; font-weight: bold; font-family: Verdana; size: 10\" href="?ver=letras&l=<? echo $n ?>&desde=<? echo $desde ?>">Siguientes <? echo $desde ?> comentarios</a>
<? } ?>
<?
}
mysql_free_result($resp) ;
echo "
<p>
<p><font face=Verdana color='white'><b>Escribir comentario</b></font>
<p>
<form method=post action=letrascom.php>
<input type=hidden name=letra value=$l>
<font color='white'>Comentario:</font><br>
<textarea name=comentario cols=30 rows=5></textarea><br><br>
<input type=submit name=enviar value=Enviar>
</form>
</td>
</tr>
" ;
}
else {
$mostrar = 20 ;
if($edicion) {
$edicion = str_replace("_"," ",$edicion) ;
$resp = mysql_query("select * FROM letras where edicion='$edicion' ORDER BY id desc LIMIT $mostrar") ;
} else {
$resp = mysql_query("select * FROM letras ORDER BY id desc LIMIT $mostrar") ;
}
while($datos = mysql_fetch_array($resp)) {
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
$resp2 = mysql_query("select id FROM letrascom where letra='$datos[id]'") ;
$comentarios = mysql_num_rows($resp2) ;
echo "
<tr>
<td width=50%><a href='?ver=letras&l=$datos[id]' style='font-face:Verdana;font-size:12;color:white;font-weight:bold'>$datos[titulo]</font></td>
<td width=50%><div align=right><font face=Verdana color=yellow size=2><b>Enviado por:</b></font> <font face=Verdana color=white size=2>$datos[usuario]</font></div></td>
</tr>
" ;
}
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>
</table>