<style>
input, textarea, select, option { background: red; border-style: ridge;
border-color: #FF0000; color: white; font-family: Verdana; font-size: 12 }

input { font-weight:bold }
</style>

<table>
<tr><td width=100%>
<font class=resaltado>Enviar Letras de Canciones</font>
<?
include("ulogin.php") ;
?><?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = $_COOKIE["unick"] ;
$comentario = quitar($comentario) ;
$titulo= quitar($titulo) ;
$interprete= quitar($interprete) ;
$edicion= quitar($edicion) ;
$letra= quitar($letra) ;
mysql_query("insert INTO letras (fecha,usuario,interprete,titulo,letra) values ('$fecha','$usuario','$interprete','$titulo','$letra')") ;
echo "<p><table cellspacing=0 bgcolor=red width=100%><td><font color=white size=2
face=Verdana>La letra de la canci�n ha sido enviada con �xito,<br>para verla solo debes ir a
<a href=letras.php style=color:white;font-weight:bold;font-size:10>letras de canciones</a>.</font></td></table>" ;
mysql_close($conectar) ;
}
?>

<form name="formulario" method="post" action="letrasenviar.php">
<font face=Verdana size=2 color=white><b>T�tulo:</b></font><br>
<input type="text" name="titulo" maxlength="100"><br>
<font face=Verdana size=2 color=white><b>Interprete:</b></font><br>
<input type="text" name="interprete" maxlength="100"><br>
<font face=Verdana size=2 color=white><b>Letra:</b></font><br>
<textarea name="letra" cols="30" rows="5" style=width:100%></textarea><br><br>
<input type="submit" name="enviar" value="Enviar">
</form></td></tr>
</table>