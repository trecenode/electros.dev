<style>
<!--
input, textarea, select, option { background: red; border-style: ridge;
border-color: #FF0000; color: white; font-family: Verdana; font-size: 12 }

input { font-weight:bold }
-->
</style>

<table>
<tr>
<td width=100%>
<?
include("config.php") ;
if($HTTP_GET_VARS[administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
// Administrador del foro (s�lo el administrador del foro puede editar mensajes)
$administrador = "Juli�n Esteban" ;
// Se comprueba que el mensaje pertenezca al usuario que desea editar el mensaje
// Si el que desea editarlo es el administrador ya no se hace la comprobaci�n
if($HTTP_COOKIE_VARS[unick] != $administrador) {
$resp = mysql_query("select id from letras where id='$id' and usuario='$HTTP_COOKIE_VARS[unick]'") ;
if(mysql_num_rows($resp) == 0) {
echo "<table cellspacing=0 bgcolor=red width=100%><td><font color=white size=2
face=Verdana>No puedes editar esta letra. Haz click <a href=javascript:history.back() style=color:white;font-weight:bold;font-size:10>aqu�</a> para regresar.</font></td></table>" ;
exit ;
}
mysql_free_result($resp) ;
}
if($enviar) {
function quitar($texto) { 
$texto = trim($texto) ;
if($_COOKIE["unick"] != "$administrador") {
$texto = htmlspecialchars($texto) ; 
}
return $texto ; 
}
$titulo= quitar($titulo) ;
$interprete= quitar($interprete) ;
$letra= quitar($letra) ;
mysql_query("update letras set titulo='$titulo',interprete='$interprete',letra='$letra' where id='$id'") ;
echo "<p><table cellspacing=0 bgcolor=red width=100%><td><font color=white size=2
face=Verdana>La letra de tu canci�n ha sido editada con �xito. Haz click <a href='letras.php?l=$id' style=color:white;font-weight:bold;font-size:10>aqu�</a> para regresar a la canci�n.</font></td></table>" ;
}
$resp = mysql_query("select titulo,interprete,letra from letras where id=$id") ;
while($datos = mysql_fetch_array($resp)) {
echo "
<form name='formulario' method='post' action='letraseditar.php?id=$id'>
  <font face=Verdana size=2 color=white><b>T�tulo:</b></font><br>
  <input type='text' name='titulo' size='40' maxlength='100' value='$datos[titulo]'><br>
  <font face=Verdana size=2 color=white><b>Interprete:</b></font><br>
  <input type='text' name='interprete' size='40' maxlenght='100' value='$datos[interprete]'><br>
  <font face=Verdana size=2 color=white><b>Letra:</b></font><br>
  <textarea name='letra' cols='50' rows='10'>$datos[letra]</textarea>
  <br>
  <br>
<input type='submit' name='enviar' value='Editar letra canci�n'>
</form>
" ;
} 
mysql_free_result($resp) ;
@mysql_close($conectar) ;
?>
</td>
</tr>
</table>