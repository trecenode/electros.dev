
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Jeremias</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
/* Cuerpo del modulo */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
/* descargas */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
</head>
<body>
<center><br>
  <font size="5">Jeremias</font> <br>
  <br>
  <br>
  <!-- ver imagenes --><table width='40%' border='0' cellpadding='5' cellspacing='0' align='center'>
<tr>
</tr>
<tr>
<table width='30%' border='0' cellpadding='5' cellspacing='0' align='center'>

<?php
// Le damos valor a las variables de configuraci�n
$Config['Path'] = "."; // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20; // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0; // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0; // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0; // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']); // Abrimos el directorio donde estan los archivos
$Plus = $c; // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['20 Anteriores'] = 1;
$c--;
}

$Counter = 0; // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
$c = 2;
while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['20 Anteriores'] = 1;
$c--;
}
}
echo"<tr>";
// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
$Counter++;

$extensiones = explode(".",$elemento) ;
$nombre = $extensiones[0] ;
$nombre2  = $extensiones[1] ;
$tipo = array ("gif", "jpg");
if(in_array($nombre2, $tipo)){

if (($i % 3) == 0) {
	echo "</tr><tr>";
}
?>
<td height='7' ><a href="<?php echo $elemento ?>" target='_blank'><img src="imagenes2.php?img=<?php echo $elemento ?>" border="0" height="140" width="180"> </a></td>
<?
$i++;
}
}
echo"</tr>";

// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
$Show['20 Siguientes'] = 1;
}
//Cerramos el directorio
closedir($dir);
?>
</table>
<div align="center"> 
  <table width="10%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td colspan="2">&nbsp; </td>
    </tr>
    <tr> 
      <td><div align="right"> 
          <?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."\">20 Siguientes</a></p>");
?>
        </div></td>
    </tr>
  </table>
  </div> 

</tr>
</table><!-- fin ver imagenes -->
  <table width="40%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="100%" height="18"><br>
        <br> <div align="left"> 
          <? 
// Contrasena admin
$pass = "123456";
// Subida de archivos
if($enviar && $_POST["contrasena"] == $pass) {
if($archivo != "" ) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "gif" && $extensiones[$num] != "jpg" && $extensiones[$num] != "ace" ) { $error = "S�lo se permiten archivos .gif y .jpg<br>" ; }

if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}

$file = "contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

copy($archivo,"$clicks.jpg") ;
echo "<div aling=left>El archivo <a href='$clicks.jpg' target='_blank'>$clicks.jpg</a> ha sido subido con �xito. <a href='$_SERVER[REQUEST_URI]'>pulsa aqui</a></div>" ;
}
else {
echo "El archivo <b>$archivo_name</b> supera los 250 Kb" ;
}
}
?>
          <br>
          <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
            <br>
            <strong>Subir archivo :</strong><br>
            <br>
            Contrase&ntilde;a<strong></strong><br>
            <input type="text" name="contrasena" class="form">
            <br>
            Archivo :<br>
            <input type="file" name="archivo" class="form">
            <br>
            <br>
            <input type="submit" name="enviar" value="Enviar" class="form">
          </form>
        </div>
        
        <br> 
        <?
if($borrar) {
if ($pass != "123456") { exit; }{
unlink("$archivo") ;
echo "Archivo <b>$archivo</b> borrado satisfactoriamente. <a href='$_SERVER[REQUEST_URI]'>pulsa aqui</a>";
}
}
?>
        <br> <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
          <strong>Borrar archivo :</strong><br>
          <br>
          Contrase&ntilde;a: 
          <input type="text" name="pass" class="form">
          <br>
          Archivo: 
          <select name="archivo" class="form">
            <?
//definimos el path de acceso
$path = ".";
//abrimos el directorio
$dir = opendir($path);
//Mostramos las informaciones
while ($elemento = readdir($dir))
{
$element = strtolower($elemento);
if (strpos($element, ".jpg") > 1 || strpos($element, ".gif")  > 1) {
echo "<option value='$elemento'>$elemento</option>";
}
}
//Cerramos el directorio
closedir($dir); 
?>
          </select>
          <br>
          <input name="borrar" type="submit" class="form" id="borrar" value="Borrar">
        </form></td>
    </tr>
  </table>
  <br>
  <br>
  <a href="http://recursosphp.iefactory.com/jeremias/jeremias.zip">Jeremias</a> 
  by elcidop 
</center>
</body>
</html>
