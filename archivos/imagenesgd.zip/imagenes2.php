<?
Header("Content-type: image/jpeg");
$im = imagecreatefromjpeg("$img");
Imagejpeg($im,'',15);
ImageDestroy($im);
?> 