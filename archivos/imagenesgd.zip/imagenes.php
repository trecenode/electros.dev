<? 
header("Content-type: image/jpeg");
$x=180;
$y=140;
$im = imagecreate($x, $y);
$bg=imagecolorallocate($im, 0,0,0);
imagefill($im, 0,0, $bg);


$negro=imagecolorallocate($im, 0,0,0);
$blanco=imagecolorallocate($im, 255,255,255);
$naranja=imagecolorallocate($im, 220, 210, 60);
$rojo=imagecolorallocate($im, 255, 0, 0);
$amarillo=imagecolorallocate($im, 255,204,0);
$verde=imagecolorallocate($im, 0,204,0);
$azul=imagecolorallocate($im, 51,153,255);
$gris=imagecolorallocate($im, 187,187,187);
$rosa=imagecolorallocate($im, 255,153,255);
$marron=imagecolorallocate($im, 204,102,0);



for ($i = 0; $i < 255; $i++){


$c[i]=imagecolorallocate($im, $c[i], $c[i], $c[i]);


}




$em= $img;
$size = getimagesize($em);
$anc=$size[0];
$alt=$size[1];
$source = imagecreatefromjpeg($em);
imagecopyresized($im, $source, 0, 0, 0, 0, 180, 140, $anc, $alt);
imagejpeg($im);   
imagedestroy($source); 
imagedestroy($im); 

?>