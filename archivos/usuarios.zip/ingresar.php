<html>
<head>
<title>Documento sin t&iacute;tulo</title>
</head>
<?php 
      //AQUI CONEXION O include() DE ARCHIVO DE CONEXION CON BASE DE DATOS. 
      include("config.php");
      function quitar($mensaje) 
        { 
        $mensaje = str_replace("<","&lt;",$mensaje); 
        
        $mensaje = str_replace(">","&gt;",$mensaje); 
        
        $mensaje = str_replace("\'","&#39;",$mensaje); 
        
        $mensaje = str_replace('\"',"&quot;",$mensaje); 

        $mensaje = str_replace("\\\\","&#92",$mensaje); 
        
        return $mensaje; 
        }
      if(trim($HTTP_POST_VARS["nick"]) != "" && 
        trim($HTTP_POST_VARS["password"]) != "") 
        { 

        $nickN = quitar($HTTP_POST_VARS["nick"]); 
        $passN = quitar($HTTP_POST_VARS["password"]);
      $result = mysql_query("SELECT password FROM usuarios WHERE nick='$nickN'"); 
        
        if($row = mysql_fetch_array($result)) 
        { 
        if($row["password"] == $passN) 
        { 
        //90 dias dura la cookie 
        setcookie("usNick",$nickN,time()+7776000); 
        setcookie("usPass",$passN,time()+7776000); 
        ?> 
        Ingreso exitoso, ahora sera dirigido a la pagina principal. 

        <SCRIPT LANGUAGE="javascript"> 
        location.href = "index.php"; 
        </SCRIPT> 
        <? 
        } 

        else 
        { 
        echo "Password incorrecto"; 
        } 
        } 
        else 

        { 
        echo "Usuario no existente en la base de datos <script LANGUAGE=\"JavaScript\"> 
var pagina=\"ingreso.html\" 
function redireccionar() 
{ 
location.href=pagina 
} 
setTimeout (\"redireccionar()\", 500); 
</script>";
		 
        } 
        mysql_free_result($result); 
        } 
        else 

        { 
        echo "Debe especificar un nick y password"; 
        } 
        mysql_close();
		
		?>
        
<body>
</body>
</html>
