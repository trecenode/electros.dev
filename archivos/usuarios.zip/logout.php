<html>
<head>
<title>Documento sin t&iacute;tulo</title>
</head>
<? 
{  
//Destruimos las cookies.  
setcookie("usNick","x",time()-3600);  
setcookie("usPass","x",time()-3600);  
}  
?> 
<style type="text/css">
<!--
.Estilo1 {
	font-size: 12px;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
<span class="Estilo1">Cerrando Sesi&oacute;n ... momento porfavor</span>
<script LANGUAGE="JavaScript"> 
var pagina="../index.html" 
function redireccionar() 
{ 
location.href=pagina 
} 
setTimeout ("redireccionar()", 1000); 
</script>

<body>
</body>
</html>
