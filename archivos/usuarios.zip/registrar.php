<html>
<head>
<title>Documento sin t&iacute;tulo</title>
</head>
<?php 
      //AQUI CONEXION O include() DE ARCHIVO DE CONEXION CON BASE DE DATOS. 
      include("config.php");
      function quitar($mensaje) 
      { 
      $mensaje = str_replace("<","&lt;",$mensaje); 
      
      $mensaje = str_replace(">","&gt;",$mensaje); 
      

      $mensaje = str_replace("\'","&#39;",$mensaje); 
      $mensaje = str_replace('\"',"&quot;",$mensaje); 
      $mensaje = str_replace("\\\\","&#92;",$mensaje); 
      
      return $mensaje; 
      }
      if(trim($HTTP_POST_VARS["nick"]) != "" && 
        trim($HTTP_POST_VARS["email"]) != "") 
        { 
        $sql = "SELECT id FROM usuarios WHERE nick='".quitar($HTTP_POST_VARS["nick"])."'"; 
        
        $result = mysql_query($sql); 
        if($row = mysql_fetch_array($result)) 
        { 
        echo "Error, nick escogido por otro usuario <script LANGUAGE=\"JavaScript\"> 
var pagina=\"nuevo_usuario.html\" 
function redireccionar() 
{ 
location.href=pagina 
} 
setTimeout (\"redireccionar()\", 500); 
</script>"; 

        } 
        else 
        { 
        $sql = "INSERT INTO usuarios (nick,password,nombre,email) VALUES 
        ("; 
        $sql .= "'".quitar($HTTP_POST_VARS["nick"])."'"; 
        
        $sql .= ",'".quitar($HTTP_POST_VARS["password"])."'"; 
        

        $sql .= ",'".quitar($HTTP_POST_VARS["nombre"])."'"; 
        
        $sql .= ",'".quitar($HTTP_POST_VARS["email"])."'"; 
        
        $sql .= ")"; 
        mysql_query($sql); 
        echo "Registro exitoso! <script LANGUAGE=\"JavaScript\"> 
var pagina=\"index.php\" 
function redireccionar() 
{ 
location.href=pagina 
} 
setTimeout (\"redireccionar()\", 500); 
</script>"; 
        } 
        mysql_free_result($result); 
        } 
        else 
        { 
        echo "Debe llenar como minimo los campos de email y password <script LANGUAGE=\"JavaScript\"> 
var pagina=\"nuevo_usuario.html\" 
function redireccionar() 
{ 
location.href=pagina 
} 
setTimeout (\"redireccionar()\", 500); 
</script>"; 
        
        } 

        mysql_close(); 
        ?>   


<body>
</body>
</html>
