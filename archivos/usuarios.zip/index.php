<html>
<head>
<title>Documento sin t&iacute;tulo</title>
</head>
<?php      
 //AQUI CONEXION O include() DE ARCHIVO DE CONEXION CON BASE DE DATOS. 
include("config.php");

include("login.php"); 
if($loginCorrecto) 
{ 
echo "Aqui el contenido solo para usuarios registrados"; }
 else { echo "El sistema no lo ha identificado, solo los usuarios registrados 
tienen acceso a esta area"; } 
?>

<body>
</body>
</html>
