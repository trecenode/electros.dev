
<html>
<head>
<title> Colores hex por yeeliberto</title>
<style>
body {
  cursor:  url(imagenes/cursor.cur); 
}
</style>
</head>
<div id="a1a0c6a1a" style="text-align: center; margin: 0px; padding: 0px;" align="center"></div>
<p>
<center>
    
<SCRIPT LANGUAGE="JavaScript">

<!--

var HexD = new Array('00', '33', '66', '99', 'CC', 'FF'); 



document.write('<table cellspacing=0 cellpadding=0 border=1><tr>');



for(i=0; i<=5; i++){



var temp = (i%6);

var current = HexD[temp];





for(b_i=0; b_i<=5; b_i++){



var b_temp = (b_i%6);

var b_current = HexD[b_temp];



for(c_i=0; c_i<=5; c_i++){



var c_temp = (c_i%6);

var c_current = HexD[c_temp];

var all = c_current+''+b_current+''+current;

document.write('<td bgcolor="#'+all+'">'+

'<a href="javascript:void(document.uno.dos.value=\'#'+all+'\')"><image src="k.gif" width=14 height=14 border=0></a></td>\n');

}



}

if(i!=6){document.write('</tr><tr>\n');}
}                   





<!--

var HexD = new Array('11', '44', '55', '88', 'EE', 'GG'); 



document.write('<table cellspacing=0 cellpadding=0 border=1><tr>');



for(i=0; i<=5; i++){



var temp = (i%6);

var current = HexD[temp];





for(b_i=0; b_i<=5; b_i++){



var b_temp = (b_i%6);

var b_current = HexD[b_temp];



for(c_i=0; c_i<=5; c_i++){



var c_temp = (c_i%6);

var c_current = HexD[c_temp];

var all = c_current+''+b_current+''+current;

document.write('<td bgcolor="#'+all+'">'+

'<a href="javascript:void(document.uno.dos.value=\'#'+all+'\')"><image src="k.gif" width=14 height=14 border=0></a></td>\n');

}



}

if(i!=6){document.write('</tr><tr>\n');}

}





<!--

var HexD = new Array('22', '44', '77', '00', 'CC', 'EE'); 



document.write('<table cellspacing=0 cellpadding=0 border=1><tr>');



for(i=0; i<=5; i++){



var temp = (i%6);

var current = HexD[temp];





for(b_i=0; b_i<=5; b_i++){



var b_temp = (b_i%6);

var b_current = HexD[b_temp];



for(c_i=0; c_i<=5; c_i++){



var c_temp = (c_i%6);

var c_current = HexD[c_temp];

var all = c_current+''+b_current+''+current;

document.write('<td bgcolor="#'+all+'">'+

'<a href="javascript:void(document.uno.dos.value=\'#'+all+'\')"><image src="k.gif" width=14 height=14 border=0></a></td>\n');

}



}

if(i!=6){document.write('</tr><tr>\n');}

}

document.write('</tr></table>');

//--> </SCRIPT>

  <FORM name="uno">

  <ALIGN="justify">

Color HEX equivalente al pulsado: <INPUT type=text name="dos"></FORM>

</center>
</html>
</xmp></noscript>
<script language="javascript" src="http://ads.tripod.lycos.es/ad/test_frame_size.js"></script>
<script language="javascript">x6f37e8c46cd = "818d60c5";
if (!AD_clientWindowSize()) {document.write("<NOSC"+"RIPT>");}</script>


<script language="JavaScript" type="text/javascript"><!--
  var _rsCI='lycos-es';
  var _rsCG='internet.school';
  var _rsDT=1;
  var _rsSI=escape(window.location);
  var _rsLP=location.protocol.indexOf('https')>-1?'https:':'http:';
  var _rsRP=escape(document.referrer);
  var _rsND=_rsLP+'//secure-uk.imrworldwide.com/';

  if (parseInt(navigator.appVersion)>=4) {
    var _rsRD=(new Date()).getTime();
    var _rsSE=0;
    var _rsSV='';
    var _rsSM=0;
    _rsCL='<scr'+'ipt language="JavaScript" type="text/javascript" src="'+_rsND+'v5.js"><\/scr'+'ipt>';
  } else {
    _rsCL='<img src="'+_rsND+'cgi-bin/m?ci='+_rsCI+'&cg='+_rsCG+'&si='+_rsSI+'&rp='+_rsRP+'">';
  }
  document.write(_rsCL);
//--></script>
<noscript>
