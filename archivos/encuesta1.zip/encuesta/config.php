<?
// CONFIGURACION DE LA ENCUESTA
$file="base.txt"; //nombre del txt en el que guardaremos los resultados

//Escribe tus respuestas para la encuesta
$c1="N� 1"; //Encuesta n� 1
$c2="N� 2"; //Encuesta n� 2
$c3="N� 3"; //Encuesta n� 3
$c4="N� 4"; //Encuesta n� 4
?>