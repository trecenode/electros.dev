<?
include("config.php"); //incluimos el fichero config.php donde tenemos la configuraci�n del script
if(!file_exists($file)) //si el txt no existe...
	{
	$fp=fopen($file,"w"); //creamos un txt por si no t� creado
	fputs($fp,"0\n0\n0\n0"); //le ponemos las respuestas desde 0
	fclose($fp); //cerramos el txt
	}


?>
<form method=POST action="enc_ver.php">
	<input type="radio" name="En" value="E1" checked><? echo $c1;?><br>
	<input type="radio" name="En" value="E2"><? echo $c2;?><br>
	<input type="radio" name="En" value="E3"><? echo $c3;?><br>
	<input type="radio" name="En" value="E4"><? echo $c4;?><br>
	<input type="submit" value="OK" name="Bot">
</form>
<p>