<?
include("config.php"); //incluimos el fichero config.php donde tenemos la configuraci�n del script

$file2=file($file); //creamos el array con las lineas del archivo
$lineas=count($file2);//contamos los elementos del array, es decir el total de lineas
$n1=$file2[0]; //asignamos a la variable el n� de votos(la l�nea 1 del txt)
$n2=$file2[1]; //asignamos a la variable el n� de votos(la l�nea 2 del txt)
$n3=$file2[2]; //asignamos a la variable el n� de votos(la l�nea 3 del txt)
$n4=$file2[3]; //asignamos a la variable el n� de votos(la l�nea 4 del txt)


if($En=="E1") //si la respuesta es la opci�n 1...
{$nn1=intval($n1)+1;}else{$nn1=intval($n1);} //entonces sumamos uno a $nn1, si no, se keda igual
if($En=="E2") //si la respuesta es la opci�n ...
{$nn2=intval($n2)+1;}else{$nn2=intval($n2);} //entonces sumamos uno a $nn2, si no, se keda igual
if($En=="E3") //si la respuesta es la opci�n 3...
{$nn3=intval($n3)+1;}else{$nn3=intval($n3);} //entonces sumamos uno a $nn3, si no, se keda igual
if($En=="E4") //si la respuesta es la opci�n 4...
{$nn4=intval($n4)+1;}else{$nn4=intval($n4);} //entonces sumamos uno a $nn4, si no, se keda igual

	$fp=fopen($file,"w+"); //abrimos de nuevo el txt borr�ndolo todo
	fwrite($fp,"$nn1\n$nn2\n$nn3\n$nn4"); //escribimos en el txt los votos.. en su respectiva l�nea. NOTA: \n <- cambia de l�nea ;)
	fclose($fp); //cerramos el txt

$ntotal=$nn1+$nn2+$nn3+$nn4; //contamos el n� total de votos

?>

<table border=0 cellpadding=0 cellspacing=0 width=188>
  <tr>
    <td colspan=3 width=186><strong><font face=Arial>Resultados Encuesta</font></strong></td>
  </tr>
  <tr>
    <td width=46><font face=Arial><? echo $c1;?></font></td>
    <td width=101><table border=0 cellpadding=0 cellspacing=1 width=100
    bgcolor="#000080">
      <tr>
        <td><table border=0 cellpadding=0 cellspacing=0 width=<? echo $nn1*100/$ntotal;?> bgcolor=#FFFFFF
        height=5>
          <tr>
            <td></td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
    <td width=37><p align=center><font face=Arial size=2><? echo $nn1;?></font></td>
  </tr>
  <tr>
    <td width=46><font face=Arial><? echo $c2;?></font></td>
    <td width=101><table border=0 cellpadding=0 cellspacing=1 width=100%
    bgcolor=#000080>
      <tr>
        <td width=100%><table border=0 cellpadding=0 cellspacing=0 width=<? echo $nn2*100/$ntotal;?>
        bgcolor=#FFFFFF height=5>
          <tr>
            <td></td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
    <td width=37><p align=center><font face=Arial size=2><? echo $nn2;?></font></td>
  </tr>
  <tr>
    <td width=46><font face=Arial><? echo $c3;?></font></td>
    <td width=101><table border=0 cellpadding=0 cellspacing=1 width=100%
    bgcolor=#000080>
      <tr>
        <td width=100%><table border=0 cellpadding=0 cellspacing=0 width=<? echo $nn3*100/$ntotal;?>
        bgcolor=#FFFFFF height=5>
          <tr>
            <td></td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
    <td width=37><p align=center><font face=Arial size=2><? echo $nn3;?></font></td>
  </tr>
  <tr>
    <td width=46><font face=Arial><? echo $c4;?></font></td>
    <td width=101><table border=0 cellpadding=0 cellspacing=1 width=100%
    bgcolor=#000080>
      <tr>
        <td width=100%><table border=0 cellpadding=0 cellspacing=0 width=<? echo $nn4*100/$ntotal;?>
        bgcolor=#FFFFFF height=5>
          <tr>
            <td></td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
    <td width=37><p align=center><font face=Arial size=2><? echo $nn4;?></font></td>
  </tr>
  <tr>
    <td width=184 colspan=3><font face=Arial>Total encuesta: </font><font
    color=#004080 face=Arial size=2><strong><? echo $ntotal;?></strong></font></td>
  </tr>
</table>

<br>
<a href="index.php">Volver</a>

