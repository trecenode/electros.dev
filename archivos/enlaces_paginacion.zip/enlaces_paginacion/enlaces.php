<title>Paginacion enlaces</title>
<link href="enlaces.css" rel="stylesheet" type="text/css">
<p><strong><font size="2">Enlaces</font></strong><strong><font size="2"><br>
  </font></strong><br>
  Para agregar enlaces debes ser un usuario habitual, para enviar enlaces haz 
  click <a href="enlacesenviar.php">aqui<br>
  </a>Si eres el administrador de la pagina y deseas borrar algun enlace roto 
  (para luego actualizarlo) debes pulsar <a href="administrar.php">aqui</a><br>
  <br>
  <?php

# Paginaci�n de registros de un fichero de texto plano.
# http://www.quikescripts.tk
# Modificado por quikescripts.tk para que muestre los resultados por orden ascendente

# Numero de registros que se mostraran por p�gina.
$limiteRegistros = 3;

# Ubicaci�n del fichero de texto.
$ficheroTexto = "enlaces.txt";

# Leemos el contenido del fichero.
$fd = fopen($ficheroTexto, "r");
$contenido = fread($fd, filesize($ficheroTexto));
fclose($fd);

# Creamos el array.
$ficheroTexto = explode("\n", $contenido);

# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 0, -1);

# Ordenamos los elementos del array en orden inverso.
$ficheroTexto = array_reverse($ficheroTexto);

# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);

# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];

# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}

# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;

# Mostramos total de enlaces
echo "Total de enlaces: $registrosTotales<br><br>";

# Mostramos los registros limitandolos por medio de las variables de arriba.
for($i = $mostrarDesde;  $i < $registrosTotales AND $i < $mostrarHasta; $i++)
{
    $columna = split("\|",$ficheroTexto[$i]);
	#fecha
	$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
    $mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
    $diasemana = date(w,$columna[4]) ; $diames = date(j,$columna[4]) ; $mesano = date(n,$columna[4]) - 1 ; $ano = date(Y,$columna[4]) ;
    $columna[4] = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
	# Resultados
	echo "<table width='100%' height='1' border=0 align='center' cellpadding=0 cellspacing=1 bgcolor=#000000>
  <tbody>
    <tr> 
      <td width='100%' height='1' align='center' valign='top' bgcolor=#dddddd><div align='center'> 
          <div align='left'> 
            <table width='100%' border='0' cellpadding='3' cellspacing='0'>
              <tr> 

                <td width='100%' height='1'><a href='$columna[2]' target='_blank'> $columna[1]</a><br> 
                  $columna[3]<br>
                  <table width='100%' border='0' cellpadding='1' cellspacing='0'>
                    <tr> 
                      <td> <b>Fecha:</b> $columna[4] | <b>Enviado por:</b> $columna[0] 
                      </td>
                    </tr>
                  </table> </td>
              </tr>
            </table>
          </div>
        </div></tr>
</table><br>";
}

echo "";
# Solo si el total de registros es mayor a el limite de registros por p�gina
# mostraremos los enlaces para cada p�gina.
if($registrosTotales > $limiteRegistros)
{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);

	# Mostramos los enlaces.
echo "<div align='right'>";
	for($i = 1; $i <= $numeroPaginas; $i++)
	{

		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $i)
		{
			echo "| <b>".$i."</b> |";
		}
		else
		{
			echo "| <a href=".$_SERVER["PHP_SELF"]."?pag=".$i.">".$i."</a> |";
		}
	}
}
echo "</div>";
?>
</p>
