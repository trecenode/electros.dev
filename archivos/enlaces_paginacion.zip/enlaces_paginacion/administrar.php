<?
//Configuracion
$nombre_archivo = "enlaces.txt";
$contrasena = "123456";
?>
<title>Administrar enlaces</title>
<link href="enlaces.css" rel="stylesheet" type="text/css">
<strong><font size="2">Administrar enlaces</font></strong><br>
<br>
Para volver a la zona de enlaces pulsa <a href="enlaces.php">aqui</a><br>
Recuerda que la contrase&ntilde;a puedes cambiarla desde el codigo fuente de administrar.php 
y que por defecto es 123456<br>
Si deseas cambiar el estilo de la pagina solo tienes que cambiar el documento 
estilo.css<br>
<br>
<form method='post' action='<? echo $_SERVER[REQUEST_URI] ?>'>
<?php
// Funciones
$espacio = "\r\n";
function abrirf($filename)		//funcion para leer un archivo a una variable
{								//recimos como parametro el nombre del fichero
$fd = fopen ($filename, "a+");	//abrimos el archivo y oasamos el apuntador a $fd
$archivo = fread ($fd, filesize ($filename));//leemos el archivo apuntado por $fd y pasamos -> $archivo
fclose ($fd);					//cerramos el apuntador del archivo
return $archivo;				//devolvemos contenido del archivo
}

function guardarf($filename,$valor)//funcion para guardar el contenido de una variable a un archivo
{								//recibimos nombre del archivo en q se guarda la variable $valor
$fe = fopen ($filename, "w+");	//abrimos el archivo para escritura
fputs ($fe,$valor);				//escribimos en el fichero apuntado por $fe
fclose ($fe);					//cerramos el apuntador 
}
// Borramos el archivo
if($borrar && $_POST["contrasena_enlace"] == $contrasena)
{
	$filename = $nombre_archivo;
	$archivo = abrirf ($filename);
	$limite = substr_count($archivo, $espacio);
	for ($i = 0 ; $i < $limite ; $i++)	//recorremos todos los registros del archivo
	{
	$aux = "tupla".$i;					//para recuperar el valor que envio desde indexuser.php creo la 
	$busco = $$aux.$espacio;				//variable aux que sera = a "tupla0".... y la declaro variable con
										//$$aux se agrego $espacio para completar la cadena a borrar 
		if($busco != $espacio)				//si se envio la variable $busco dera != de $espacio
			$archivo = str_replace ("$busco","", "$archivo");//borramos el registro 
	}
	guardarf ($filename,$archivo);
	echo "<script>location.href='$_SERVER[REQUEST_URI]'</script>";
}
?>
  <table width='100%' border='1' cellspacing='1' cellpadding='3'>
    <tr> 
      <td width="17%"><b>Usuario</b></td>
      <td width="18%"><b>Titulo</b></td>
      <td width="18%"><b>Url</b></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <?
// Abrimos el archivo
$archivo = abrirf ($nombre_archivo);
$limite = substr_count($archivo, $espacio
 ); 
$tupla = split($espacio, $archivo, $limite + 1 );
for($i=0 ; $i < $limite ; ++$i)
{
	$borrado = trim($tupla[$i]);
	$columna = split( "\|" , $tupla[$i] , 5 );
?>
    <tr> 
      <td><? echo $columna[0] ?></td>
      <td><? echo $columna[1] ?></td>
      <td><? echo $columna[2] ?></td>
      <td><input type='checkbox' name='<? echo "tupla".$i ?>' value='<? echo $borrado ?>'></td>
    </tr>
    <?
}
// Fin formulario para poder enviar un enlace
?>
  </table>
<br>
<div align=right>Contrase�a : <input name='contrasena_enlace' type='text' class='form' size='12'> 
<input name='borrar' type='submit' class='form'  value='Borrar'></div><br>
</form>