<title>Enviar enlaces</title>
<link href="enlaces.css" rel="stylesheet" type="text/css">
<p><strong><font size="2">Enviar enlaces<br>
  </font></strong><br>
  Para volver a la zona de enlaces pulsa <a href="enlaces.php">aqui </a><br>
  Recuerda que en el campo usuario debes poner tu nombre o nick y en campo url 
  puedes poner <br>
  una direccion http:// o ftp:// comprueba no dejar ningun dato en blanco antes 
  de enviar el enlace.<a href="enlaces.php"><br>
  </a><br>
  <?
if($enviar){
# htmlspecialchars,stripslashes,trim
$usuario = htmlspecialchars(stripslashes(trim($_POST["usuario"])));
$titulo = htmlspecialchars(stripslashes(trim($_POST["titulo"])));
$url = htmlspecialchars(stripslashes(trim($_POST["url"])));
$descripcion = htmlspecialchars(stripslashes(trim($_POST["descripcion"])));
$descripcion = str_replace("\r\n", "<br>", $descripcion);
$seccion = htmlspecialchars(stripslashes(trim($_POST["seccion"])));
$fecha = time();
# Comprobamos que los datos no estan vacios
if($usuario == ""){ $error .= "No has puesto el usuario<br>";}
if($titulo == ""){ $error .= "No has puesto el titulo<br>";}
if($url == "http://"){ $error .= "No has puesto la url<br>";}
if($descripcion == ""){$error .= "No has puesto una descripcion<br>";}
if($error) {
echo "<b>Error</b>
<p><font color='#FF0000'>$error</font> 
<p><a href='javascript:history.back()'>Regresar</a>" ;
exit ;
}
# Insertamos los datos
$fecha = time();
$crea = fopen("$seccion.txt","a"); 
fwrite($crea, "$usuario|$titulo|$url|$descripcion|$fecha\r\n");
fclose($crea);
echo "Insertado correctamente, pulsa <a href='enlaces.php'>aqui</a><br><br>";
}
?>
</p>
<form name="form" method="post" action="<? $_SERVER['REQUEST_URI'] ?>" enctype="multipart/form-data">
  Usuario: 
  <input name="usuario" type="text" id="usuario">
  <br>
  Titulo : 
  <input name="titulo" type="text" id="titulo">
  <br>
  Url : 
  <input name="url" type="text" id="url" value="http://">
  <br>
  Descripcion: <br>
  <textarea name="descripcion" cols="34" rows="8" id="descripcion"></textarea>
  <br>
  Seccion : 
  <input name="seccion" type="text" id="seccion" value="<? if(!$secciones) { echo "principal";} if($secciones != "") { echo $secciones ;}?>">
  <br>
  <br>
  <input name="enviar" type="submit" id="enviar" value="Enviar">
</form>
