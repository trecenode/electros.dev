<?
//Configuracion
$contrasena = "123456";
?>
<title>Administrar enlaces</title>
<link href="enlaces.css" rel="stylesheet" type="text/css">
<p><strong><font size="2">Administrar enlaces</font></strong></p>
<div align="center"> 
  <table width="30%" border="0" cellpadding="0" cellspacing="0">
    <tr> 
      <td> 
        <?
# Crear secciones
if(!$secciones) { $fichero = "principal.txt";}
if($secciones != "") { $fichero = "$secciones.txt"; }
if($secciones) { $sec = "&secciones=$secciones";}
if($_GET[c]){
$cec = "&c=$_GET[c]";
}
# Mostrar directorio
echo "<table width='90%' border='0' cellpadding='1' cellspacing='0' align='center'>";
 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "."; // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 30; // Numero de archivos a mostrar por p�ginas.

$Show['30 Anteriores'] = 0; // Por defecto no se mostrara 10 Anteriores
$Show['30 Siguientes'] = 0; // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0; // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']); // Abrimos el directorio donde estan los archivos
$Plus = $c; // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['30 Anteriores'] = 1;
$c--;
}

$Counter = 0; // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['30 Anteriores'] == 0) $Counter=$Counter-2; else {
$c = 2;
while ($c > 0 && $elemento = readdir($dir)) // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['30 Anteriores'] = 1;
$c--;
}
}
echo"<tr>";
// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
$Counter++;

$extensiones = explode(".",$elemento) ;
$nombre = $extensiones[0] ;
$nombre2  = $extensiones[1] ;

$elemento1 = strtolower($elemento);
if (strpos($elemento1, ".txt") > 1) {

if (($i % 2) == 0) {
echo "</tr><tr>";
}
echo "
<td><div align=left><img src='carpeta.gif' border='0'> <a href='?secciones=$nombre$cec'>
$nombre</a></div></td>
";
$i++;
}
}
echo "</tr>";

// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
$Show['30 Siguientes'] = 1;
}

//Cerramos el directorio
closedir($dir);
echo "</table>";
echo "<br><div align='right'>";
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['30 Anteriores'] == 1) echo("<a href=\"?c=".($Plus-$Config['Show'])."$sec\"> Anteriores | </a>");
if ($Show['30 Siguientes'] == 1) echo("&nbsp;<a href=\"?c=".($Plus+$Config['Show'])."$sec\"> Siguientes</a></p>");
echo "</div>";
?>
      </td>
    </tr>
  </table>
</div>
<p><br>
  <br>
  Para volver a la zona de enlaces pulsa <a href="enlaces.php">aqui</a><br>
  Recuerda que la contrase&ntilde;a puedes cambiarla desde el codigo fuente de 
  administrar.php y que por defecto es 123456<br>
  Si deseas cambiar el estilo de la pagina solo tienes que cambiar el documento 
  estilo.css</p> </p>
<form method='post' action='<? echo $_SERVER[REQUEST_URI] ?>'>
<?php
// Funciones
$espacio = "\r\n";
function abrirf($filename)		//funcion para leer un archivo a una variable
{								//recimos como parametro el nombre del fichero
$fd = fopen ($filename, "a+");	//abrimos el archivo y oasamos el apuntador a $fd
$archivo = fread ($fd, filesize ($filename));//leemos el archivo apuntado por $fd y pasamos -> $archivo
fclose ($fd);					//cerramos el apuntador del archivo
return $archivo;				//devolvemos contenido del archivo
}

function guardarf($filename,$valor)//funcion para guardar el contenido de una variable a un archivo
{								//recibimos nombre del archivo en q se guarda la variable $valor
$fe = fopen ($filename, "w+");	//abrimos el archivo para escritura
fputs ($fe,$valor);				//escribimos en el fichero apuntado por $fe
fclose ($fe);					//cerramos el apuntador 
}
// Borramos el archivo
if($borrar && $_POST["contrasena_enlace"] == $contrasena)
{
	$filename = $fichero;
	$archivo = abrirf ($filename);
	$limite = substr_count($archivo, $espacio);
	for ($i = 0 ; $i < $limite ; $i++)	//recorremos todos los registros del archivo
	{
	$aux = "tupla".$i;					//para recuperar el valor que envio desde indexuser.php creo la 
	$busco = $$aux.$espacio;				//variable aux que sera = a "tupla0".... y la declaro variable con
										//$$aux se agrego $espacio para completar la cadena a borrar 
		if($busco != $espacio)				//si se envio la variable $busco dera != de $espacio
			$archivo = str_replace ("$busco","", "$archivo");//borramos el registro 
	}
	guardarf ($filename,$archivo);
	echo "<script>location.href='$_SERVER[REQUEST_URI]'</script>";
}
?>
  <table width='100%' border='1' cellspacing='1' cellpadding='3'>
    <tr> 
      <td width="17%"><b>Usuario</b></td>
      <td width="18%"><b>Titulo</b></td>
      <td width="18%"><b>Url</b></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <?
// Abrimos el archivo
$archivo = abrirf ($fichero);
$limite = substr_count($archivo, $espacio
 ); 
$tupla = split($espacio, $archivo, $limite + 1 );
for($i=0 ; $i < $limite ; ++$i)
{
	$borrado = trim($tupla[$i]);
	$columna = split( "\|" , $tupla[$i] , 5 );
?>
    <tr> 
      <td><? echo $columna[0] ?></td>
      <td><? echo $columna[1] ?></td>
      <td><? echo $columna[2] ?></td>
      <td><input type='checkbox' name='<? echo "tupla".$i ?>' value='<? echo $borrado ?>'></td>
    </tr>
    <?
}
// Fin formulario para poder enviar un enlace
?>
  </table>
<br>
<div align=right>Contrase�a : <input name='contrasena_enlace' type='text' class='form' size='12'> 
<input name='borrar' type='submit' class='form'  value='Borrar'></div><br>
</form>