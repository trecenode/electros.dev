<?php
// Funciones
function abrir($filename)
{								
$fd = @fopen ($filename, "a+");	
$archivo = @fread ($fd, filesize ($filename));
@fclose ($fd);
return $archivo;				
}

function leer($filename)
{
$fd = @fopen ($filename, "r");
$archivo = @fread ($fd, filesize ($filename));
@fclose ($fd);
return $archivo;
}

function guardar($filename,$valor)
{								
$fe = @fopen ($filename, "w+");	
@fputs ($fe,$valor);
@fclose ($fe);					
}


if($leer){
$archi = "$leer.log";
$abrir = @fopen($archi,"r");
$contenido = @fread($abrir, @filesize($archi));
@fclose($abrir);

if(file_exists("$leer.log")){
echo "document.write('$contenido');";
}
if(!file_exists("$leer.log")){
echo "document.write('0');";
}

exit;
}
// Detailed information found in the readme file
if($pagina == "") { exit; }
// Enable referer validation? 1 = YES, 0 = NO
$check_referer = 0;
// Domains that are allowed to access this script
$referers = array ("localhost","yourdomain.com");
// Get archivo and log file names
$archivo = htmlentities($_GET['archivo']);
$logfile = $archivo . ".log";

// If $check_referer is set to 1 and if HTTP_REFERER is set to
// a value let's check refering site
if ($check_referer == 1 && !(empty($_SERVER['HTTP_REFERER'])))
{
check_referer($_SERVER['HTTP_REFERER']);
}
// If the log file doesn't exist we start count from 1 ...
if (! @$file = fopen($logfile,"r+"))
{
$count="1";
}
// If the log file exist lets read count from it
else {
$count = @fread($file, filesize($logfile)) or $count=0;
fclose($file);
// Raise the value of $count by 1
$count++;
}
// Write the new $count in the log file
$file = fopen($logfile,"w+") or die("Can't open/write the log file, please CHMOD logs folder to 777 (rwx-rwx-rwx)!");
fputs($file, $count);
fclose($file);
// Print out Javascript code and exit
echo "<script>location.href='$_GET[pagina]'</script>";
exit();
// function that will check refering URL
function check_referer($thisurl) {
	global $referers;
		for ($i=0;$i<count($referers);$i++)
        	{
				if (preg_match("/$referers[$i]/i",$thisurl)) {return true;}
			}
	die("Invalid referer!");
}
?>