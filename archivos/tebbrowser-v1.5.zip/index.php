<?
// T E B B R O W S E R - 1 . 5

// Tebbrowser 1.5
// Programado por Tebb
// tebbxtreme@hotmail.com
// http://www.areazone.net

//
// Configuraci�n del Script
//

$titulo="Tebbrowser v1.5 Beta"; // t�tulo de la p�gina
$mode=2; // modo directorio por defecto (1 para lista, 2 para iconos grandes)
$open_files=1; // intentar abrir archivos en el script? (1 para si, 2 para no)
$lang="spanish.php"; // archivo de idioma

$color_fondo="#9AA49A"; // color fondo pagina
$color_letras="#000000"; // color texto general

$directory=""; //directorio a ver, relativo a donde se ejecuta este script, para ver el directorio actual dejar en blanco

$max_letras=12; // max de caracteres en nombres de archivo / carpeta

$color2="#959E95"; // color de las barras (solo se muestra en modo directorio
$color_hdrs="#869186"; // color barra superior e inferior

$color_links="#000000"; // color de los links
$links_encima="#CCCCCC"; // color de los links cuando se pasa el raton por encima
$subrallar_modo="underline"; // subrallar links cuando se pasa el raton por encima? (underline para si, none para no)

$carpeta_img="b_img"; // nombre de la carpeta donde se alojan las imagenes usadas por el script
						// debe ser relativo al directorio donde este situado el script

$carpeta_ico="icons"; // carpeta relativa a la carpeta de imagenes donde se alojan los iconos usados por el script
					  // (esta debe estar dentro de la carpeta de imagenes)

$version="1.5 Beta"; // no tocar

// definir iconos por tipos de archivo
// para agregar tipos agregar un una lineas dentro de $tipos=array(); de la siguente manera:
// array("nombre_icono.gif","extension","extension","extension","extension","extension","extension"),
// cada extension es la extension del archivo, ej: "zip","rar"...
// IMPORTANTE escribir las extensiones EN MINUSCULAS

$tipos=array(
		array("zipped.gif","zip","rar","cab","arj","lzh","ace","tar","gzip","uue","bz2"),
		array("imagenes.gif","gif","jpg","jpeg","png","bmp","jpe"),
		array("musica.gif","mp3","wav","snd","au","aif","aifc","aiff","wma","rm","rmx","rmj","rms"),
		array("video.gif","mpeg","mpg","avi","wmv","mov"),
		array("texto.gif","txt","doc","rtf"),
		array("webs.gif","htm","html","asp","php","shtml","xlm","as","jsp","asa","aspx","cfm","php4","php3","vbs","css","js"),
		array("exe.gif","exe")
);

// definir la forma con la que tebbrowser abre los archivos..

// en el primer array (codigo) hay que poner las extensiones de los archivos que quieras mostrar el codigo (codigo fuente)
// como pueden ser htm, php..

// en el segundo array (imagenes) hay que poner las extensiones de los archivos que quieras mostrar como imagenes
// obviamente tienen que ser abribles por el explorador, no puedes poner por ejemplo un .psd

// en el tercer array (incluibles) hay que poner los archivos que sean texto y puedan ser incluidos
$abrir=array(
		array("codigo","htm","html","asp","php","shtml","xlm","as","jsp","asa","aspx","cfm","php4","php3","vbs","css","js"),
		array("imagenes","gif","jpg","jpeg","png","bmp","jpe"),
		array("incluibles","txt","rtf")
);

/////////////////////////////////////////
/////////////////////////////////////////
////NO MODIFICAR A PARTIR DE AQUI////////
////A NO SER QUE SEPAS LO QUE HACES!/////
/////////////////////////////////////////
/////////////////////////////////////////

if(ereg("\.\./",$dir) || ereg("/\.\.",$dir) || ereg("\\\\.\.",$dir) || ereg("\.\.\\\\",$dir)){
	die("Hacking Attempt");
}

function getExtension($archivo){
	$a=explode(".",$archivo);
	return $a[count($a)-1];
}
function getName($archivo){
	$a=explode(".",$archivo);
	return $a[0];
}
function carpeta($archivo){
	$a=explode("/",$archivo);
	$lol=array_pop($a);
	$a=implode("/",$a);
	return $a;
}
function sacar_dire($archivo){
	$a=explode("/",$archivo);
	$lol=array_pop($a);
	$a=implode("/",$a);
	return $a;
}
function size($file){
	$size = filesize($file);
	$sizes = Array(' Bytes', ' Kbs', ' Mbs', 'Gbs', 'Tbs', 'Pbs', 'Ebs');
	$ext = $sizes[0];
	for ($i=1; (($i < count($sizes)) && ($size >= 1024)); $i++) {
	$size = $size / 1024;
	$ext  = $sizes[$i];}
	clearstatcache();
	return round($size, 2).$ext;
}
function bus($extension,$array){
	$a="unknown.gif";
	for($x=0;$x<count($array);$x++){
		if(in_array($extension,$array[$x])){
			$a=$array[$x][0];
		}
	}
	return $a;
}
function que_hacer($extension,$array){
	$a="enviar";
	for($x=0;$x<count($array);$x++){
		if(in_array($extension,$array[$x])){
			$a=$array[$x][0];
		}
	}
	return $a;
}
function ShowCode($archivo) { 
echo "<style> 
.x { 
text-align:right; 
font-family:courier; 
font-size:10pt; 
margin: 0px; 
line-height :12pt; 
filter:alpha(opacity=70); 
} 

.y { 
background-color:#C0C6C0; 
font-family:courier; 
font-size:10pt; 
margin: 0px; 
line-height :12pt; 
} 
</style>"; 
$archiv = file($archivo); 
echo "<DIV id=php><TABLE cellspacing=0><TR><TD class='x' vAlign=top><CODE>"; 
for ($x=1;$x<=count($archiv);$x++) { 
echo "&nbsp;".$x."&nbsp;<br>"; 
} 
echo "</CODE></TD><TD class='y' vAlign=top><CODE>"; 
show_source($archivo); 
echo "</CODE></TD></TR></TABLE></DIV>"; 
}

echo"<style type='text/css'>
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	color: ".$color_letras.";
}
body {
	background-color: ".$color_fondo.";
	margin-left: 5px;
	margin-top: 5px;
	margin-right: 5px;
	margin-bottom: 5px;
}
a {
	font-size: 10px;
	color: ".$color_links.";
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: ".$color_links.";
}
a:hover {
	text-decoration: ".$subrallar_modo.";
	color: ".$links_encima.";
}
a:active {
	text-decoration: none;
	color: ".$color_links.";
}
-->
</style>
<title>$titulo</title>";

echo"<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
  <tr>
    <td width='528'><a href='/'><img src='".$carpeta_img."/logo.gif' border='0'></a></td>
    <td>&nbsp;</td>
  </tr>
</table>";

include("b_lang/".$lang);

if(isset($modo)){ $mode=$modo; $mod_link="&modo=".$modo; }else{ $mod_link=""; }

if($dir!=""){
	$url=carpeta($dir);
	$url="href='?dir=".$url.$mod_link."'";
	
	$direccion=explode("/",$dir);
	
	$array=array();
	for($i=0;$i<count($direccion);$i++){
		
		if(isset($dir2)){
			$dir2=sacar_dire($dir2);
			$array[]=$dir2;
		}else{
			$dir2=$dir;
			$array[]=$dir2;
		}
	}
	$array=array_reverse($array);
	
	for($i=0;$i<count($direccion);$i++){
		$direc[]="<a href='?dir=".$array[$i].$mod_link."'><font size='3'><b>".$direccion[$i]."</b></font></a>";
	}
	$direccion=implode("<b><font size='3'>&nbsp;/&nbsp;</font></b>",$direc);
	
}else{
	$url="";
}

$archivo=explode("/",$file);
$archivo=$archivo[count($archivo)-1];

echo "<br> <font size='3'><b>�</b></font> <a href='?".$mod_link."'><font size='3'><b>Index</b></font></a>".$direccion."<font size='3'><b> / ".$archivo."</b></font><br>";

if(isset($file)){ $url=""; }

echo"<tr>
		<td>
			<table width='100%'  border='0' cellspacing='0' cellpadding='8'>
		  		<tr>
			<td  width='50'><div align='center'><a href='javascript:history.go(-1)'><img src='".$carpeta_img."/atras.gif' border='0'><br>
			  ".$palabra[atras]."</a>
				</div></td>
				<td  width='50'><div align='center'><a href='javascript:history.go(1)'><img src='".$carpeta_img."/adelante.gif' border='0'><br>
				  ".$palabra[adelante]."</a>
				</div></td>
				<td  width='50'><div align='center'><a ".$url."><img src='".$carpeta_img."/subir.gif' border='0'><br>
				  ".$palabra[arriba]."</a>
				</div></td>
				<td width='300'><div align='center'>".$palabra[m_vista].": <a href='?dir=".$dir."&modo=1'><b>".$palabra[lista]."</b></a> - <a href='?dir=".$dir."&modo=2'><b>".$palabra[carpetas_g]."</b></a></div></td>
				<td>&nbsp;</td>
			  </tr>
			</table>
		</td>
	</tr>";

if(isset($file)){

	if(ereg("\.\./",$file) || ereg("/\.\.",$file) || ereg("\\\\.\.",$file) || ereg("\.\.\\\\",$file)){
	die("Hacking Attempt");
	}
	
	if(!isset($referer)){
		$referer=$_SERVER['HTTP_REFERER'];
	}
	
	echo"<table width='100%' border='0' cellpadding='5' cellspacing='0'>
	  <tr>
		<td bgcolor='".$color_hdrs."'><a href='".$referer."'><strong>".$palabra[volver]."</strong></a></td>
	  </tr>
	  <tr>
		<td valign='middle'>
		<table width='75%' height='20' border='0' align='center' cellpadding='0' cellspacing='0'>
          <tr>
            <td><div align='center'></div></td>
          </tr>
        </table>
		<div align='center'>
		<table width='75%' border='0' cellpadding='10' cellspacing='1' bgcolor='".$color_hdrs."'>
            <tr>
              <td bgcolor='".$color2."'><div align='center'>";
				
				// DATOS
			  	
				if(isset($file)){
				$archivo=explode("/",$file);
				$archivo=$archivo[count($archivo)-1];
				$extension=getExtension($archivo);
				$full_file=".".$directory.$file;
				$path=".".$directory.$dir."/".$archivo;
				$tamanio=size($path);
				$ultimamod=date("d-M-Y :: H:i",filemtime($path));
				
				echo"<table width='100%' border='0' cellspacing='0' cellpadding='5'>
					  <tr>
						<td width='20%'><div align='right'><b>".$palabra[nombre].":</b><br>
						</div></td>
						<td width='80%'>".$archivo."</td>
					  </tr>
					  <tr>
						<td><div align='right'><b>".$palabra[extension].":</b><br>
						</div></td>
						<td>".$extension."</td>
					  </tr>
					  <tr>
						<td><div align='right'><b>".$palabra[tamanio].":</b><br>
						</div></td>
						<td>".$tamanio."</td>
					  </tr>
					  <tr>
						<td><div align='right'><b>".$palabra[ultima_mod].":</b><br>
						</div></td>
						<td>".$ultimamod."</td>
					  </tr>
					  <tr>
						<td><div align='right'><b>".$palabra[carpeta].":</b><br>
						</div></td>
						<td>".$dir."/</td>
					  </tr>
					</table>";
				
              echo"</div></td>
			</tr>
					<tr>
              	<td bgcolor='".$color2."'><div align='center'>";
			  
				$a=que_hacer($extension,$abrir);
				
				switch($a){
				
				case imagenes:
					echo"<img src='$full_file'>";
				break;
				case codigo:
					ShowCode($full_file);
				break;
				case incluibles:
					include($full_file);
				break;
				default:
					echo"<a href='$full_file'><font size='3'><b>".$palabra[descarg_abrir]."</b></font></a>";
				break;
			  }
			  }
			  
			  echo"</div></td>
					</tr>
		  </table>
		  </div>
		</td>
	  </tr>
			</table>";

}else{

	if($mode=="1"){
		echo"<table width='100%' border='0' cellspacing='0' cellpadding='0'>
		  <tr bgcolor='".$color_hdrs."'>
			<td width='25' height='20'><div align='center'>*</div></td>
			<td><strong>".$palabra[nombre]." </strong></td>
			<td width='20%'><strong>".$palabra[ultima_mod]."</strong></td>
			<td width='10%'><strong>".$palabra[tamanio]."</strong></td>
			<td width='10%'><strong>".$palabra[tipo]."</strong></td>
		  </tr>";
	}elseif($mode=="2"){
		echo"<table width='100%' border='0' cellspacing='0' cellpadding='0'>
		  <tr bgcolor='".$color_hdrs."'>
			<td height='20'>&nbsp;&nbsp;".$palabra[m_vista].": <b>".$palabra[carpetas_g]."</b></td>
		  </tr>
		  </table>
		  <table width='100%'  border='0' cellspacing='0' cellpadding='0'><tr>";
	}else{}
	
	$directorio=@opendir("./".$directory.$dir) or die($palabra[err_dir]);
	while($archivo = readdir($directorio)){ $fichero[]=$archivo; }
	sort($fichero);
	$num_ficheros=count($fichero)-2;
	if($num_ficheros!=""){
		for($i=0;$i<count($fichero);$i++){ 
			
			$exsiste=".".$directory.$dir."/".$fichero[$i];
			$path=".".$directory.$dir."/".$fichero[$i];
			
			if($i%2==0){ $color="";	}else{ $color=$color2; }
			
			if($fichero[$i]=="."){
			}elseif($fichero[$i]==".."){
			}elseif(is_file($exsiste)){	
				$n_ficheros[]=$fichero[$i];
				$extension=strtolower(getExtension($fichero[$i]));
				$icono=bus($extension,$tipos);
				$nombre=$fichero[$i];
				$nombre_c=getName($fichero[$i])."<br>[".$extension."]";
				
				if(strlen(getName($fichero[$i])) > $max_letras){
					$nombre_c=substr(getName($fichero[$i]),0,$max_letras)."...<br>[".$extension."]";
				}
							
				$tamanyo=size($path);
				$url="?file=".$dir."/".$fichero[$i].$mod_link."&dir=".$dir."&";
				$url_directo=$directory.$dir."/".$fichero[$i];
				$ultimamod=date("d-M-Y :: H:i",filemtime($path));
				clearstatcache();
				
				if($open_files==2){
					$url=$url_directo;
				}
				
				if($mode=="1"){
					echo"<tr>
							<td height='20' bgcolor='".$color."'>
								<div align='center'><img src='".$carpeta_img."/archivo.gif' border='0'></div>
							</td>
							<td bgcolor='".$color."'>
								<a href='".$url."'>".$nombre."</a>
							</td>
							<td bgcolor='".$color."'>
								".$ultimamod."
							</td>
							<td bgcolor='".$color."'>
								".$tamanyo."
							</td>
							<td bgcolor='".$color."'>
								[".$extension."]
							</td>
						 </tr>";
				}elseif($mode=="2"){
					echo"<td width='10%' height='65'><div align='center'><a href='".$url."'><img src='".$carpeta_img."/".$carpeta_ico."/".$icono."' alt='".$nombre."\n".$palabra[tamanio].": ".$tamanyo."\n ".$palabra[ultima_mod].": ".$ultimamod."' border='0'><br>
						  ".$nombre_c."</a>
						</div></td>";
				}
					 
			}elseif(is_dir($exsiste)){
				$n_carpetas[]=$fichero[$i];
				$url="?dir=".$dir."/".$fichero[$i].$mod_link;
				$url_directo=$directory.$dir."/".$fichero[$i];
				$ultimamod=date("d-M-Y :: H:i",filemtime($path));
				$nombre=$fichero[$i];
				$nombre_c=$fichero[$i];
				
				if(strlen($fichero[$i]) > $max_letras){
					$nombre_c=substr($fichero[$i],0,$max_letras)."...";
				}
				
				if($mode=="1"){
					echo"<tr>
							<td height='20' bgcolor='".$color."'>
								<div align='center'><img src='".$carpeta_img."/carpeta.gif' border='0'></div>
							</td>
							<td bgcolor='".$color."'>
								<a href='".$url."'>".$nombre."</a>
							</td>
							<td bgcolor='".$color."'>
								".$ultimamod."
							</td>
							<td bgcolor='".$color."'>
								-
							</td>
							<td bgcolor='".$color."'>
								[".$palabra[carpeta]."]
							</td>
						</tr>";
				}elseif($mode==2){
					echo"<td width='10%' height='65'><div align='center'><a href='".$url."'><img alt='".$nombre."' src='".$carpeta_img."/".$carpeta_ico."/carpeta.gif' border='0'><br>
						  ".$nombre_c."</a>
					</div></td>";
				}
			}else{
				$n_desconocidos[]=$fichero[$i];
			}
			
			if($mode=="2"){
				if($i%10==1){ echo"</tr><tr>"; }
			}
		}
		
		$n_carpetas=count($n_carpetas);
		$n_ficheros=count($n_ficheros);
		$n_desconocidos=count($n_desconocidos);
		$num_arch=$n_carpetas+$n_ficheros+$n_desconocidos;
		
		$p_carpeta=round($n_carpetas/$num_arch*100,0)."%";
		$p_ficheros=round($n_ficheros/$num_arch*100,0)."%";
		$p_desconocidos=round($n_desconocidos/$num_arch*100,0)."%";
		$stats="<td>".$palabra[no_tot_obj].": <b>".$num_arch."</b>, ".$palabra[d_los_cuales]." <b>".$n_carpetas."</b> (".$p_carpeta.") ".$palabra[son_crpetas].", <b>".$n_ficheros."</b> (".$p_ficheros.") ".$palabra[son_archivs]." ".$palabra[y]." <b>".$n_desconocidos."</b> (".$p_desconocidos.") ".$palabra[son_desconocds].".</td>";
	}else{
		if($mode=="1"){ echo"<td height='20'>&nbsp;&nbsp;".$palabra[no_obj].".</td>"; }else{ echo"<td height='20'>&nbsp;&nbsp;".$palabra[no_obj].".</td>"; }
		$stats="<td height='20'>-</td>";
	}
	
	if($mode=="1"){ echo"</table>"; }else{ echo"</tr></table>"; }
	
	echo"<table width='100%' border='0' cellspacing='0' cellpadding='5'>
	  <tr bgcolor='".$color_hdrs."'>
		".$stats."
	  </tr>";
	  
	closedir($directorio);

}
echo"</table>";
echo"<br><br><div align='center'><b>Tebbrowser v".$version."</b><br>Php browser, ".$palabra[por]." <a href='mailto:tebbxtreme@hotmail.com'><b>Tebb</b></a><br><a target='_blank' href='http://www.areazone.net'>AreaZone.NET</a></div><br>";
?>