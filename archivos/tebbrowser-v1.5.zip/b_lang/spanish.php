<?
// T E B B R O W S E R - 1 . 5

// Tebbrowser 1.5
// Programado por Tebb
// tebbxtreme@hotmail.com
// http://www.areazone.net
// TRADUCCION ESPA�OL by Tebb

// PALABRAS

$palabra=array();
$palabra[atras] = "Atras";
$palabra[adelante] = "Adelante";
$palabra[arriba] = "Arriba";
$palabra[m_vista] = "Modo Vista";
$palabra[lista] = "Lista";
$palabra[carpetas_g] = "Carpetas Grandes";
$palabra[carpeta] = "Carpeta";
$palabra[volver] = "Volver";
$palabra[nombre] = "Nombre";
$palabra[tipo] = "Tipo de archivo";
$palabra[extension] = "Extensi&oacute;n";
$palabra[tamanio] = "Tama&ntilde;o";
$palabra[ultima_mod] = "&Uacute;ltima modificaci&oacute;n";
$palabra[carpeta] = "Carpeta";
$palabra[no_tot_obj] = "N&ordm; Total de objetos";
$palabra[d_los_cuales] = "de los cuales";
$palabra[son_crpetas] = "son carpetas";
$palabra[son_archivs] = "son archivos";
$palabra[y] = "y";
$palabra[son_desconocds] = "son desconocidos";
$palabra[por] = "por";
$palabra[descarg_abrir] = "Descargar / Abrir archivo";
$palabra[err_dir] = "No se pudo abrir el directorio.";
$palabra[no_obj] = "No hay objetos en esta carpeta";


?>