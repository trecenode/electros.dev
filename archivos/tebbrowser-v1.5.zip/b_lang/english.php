<?
// T E B B R O W S E R - 1 . 5

// Tebbrowser 1.5
// Programado por Tebb
// tebbxtreme@hotmail.com
// http://www.areazone.net
// English translation by Tebb

// Words

$palabra=array();
$palabra[atras] = "Back";
$palabra[adelante] = "Forward";
$palabra[arriba] = "Up";
$palabra[m_vista] = "View Mode";
$palabra[lista] = "List";
$palabra[carpetas_g] = "Big Folders";
$palabra[carpeta] = "Folder";
$palabra[volver] = "Go Back";
$palabra[nombre] = "Name";
$palabra[extension] = "Extension";
$palabra[tamanio] = "Size";
$palabra[ultima_mod] = "Last modified";
$palabra[carpeta] = "Folder";
$palabra[no_tot_obj] = "Total num of files";
$palabra[d_los_cuales] = "that";
$palabra[son_crpetas] = "are folders";
$palabra[son_archivs] = "are files";
$palabra[y] = "and";
$palabra[son_desconocds] = "are unknown";
$palabra[por] = "by";
$palabra[descarg_abrir] = "Download / Open file";
$palabra[err_dir] = "It was impossible to open this directory.";
$palabra[no_obj] = "There are no objects in this directory";


?>