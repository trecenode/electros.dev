<?
/*
************************************************
*** eForo v3.0
*** Creado por: Electros <electros@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
************************************************

--- P�gina: menu.php ---

eForo - Una comunidad para tus visitantes
Copyright � 2003-2004 Daniel Osorio "Electros"

Este programa es software libre, puedes redistribuirlo y/o modificarlo bajo los t�rminos
de la GNU General Public License publicados por la Free Software Foundation; desde la
versi�n 2 de la licencia, o (si lo deseas) cualquiera m�s reciente.
*/

# * Men� de navegaci�n del foro
$titulo_subforo = false ;
if($_GET[foro]) {
	$con = mysql_query("select foro from eforo_foros where id='$_GET[foro]'") ;
	$datos = mysql_fetch_array($con) ;
	$titulo_subforo = " � <a href=\"$url1"."forotemas$url2$url3"."foro=$_GET[foro]\" class=\"eforo\">$datos[foro]</a>" ;
	$titulo_subforo_2 = $datos[foro] ;
	mysql_free_result($con) ;
}
$titulo_tema = false ;
if($_GET[foro] && $_GET[tema]) {
	$con = mysql_query("select tema from eforo_mensajes where id='$_GET[tema]'") ;
	$datos = mysql_fetch_array($con) ;
	$titulo_tema = " � <a href=\"$url1"."foromensajes$url2$url3"."foro=$_GET[foro]&tema=$_GET[tema]\" class=\"eforo\">$datos[tema]</a>" ;
	$titulo_tema_2 = $datos[tema] ;
	mysql_free_result($con) ;
}
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" align="center" class="eforo_tabla_defecto">
<tr>
<td><a href="<?=$url1.'foro'.$url2?>" class="eforo">Indice de subforos</a><?=$titulo_subforo.$titulo_tema?></td>
</tr>
<tr>
<td>
<?
if($_GET[foro]) {
	echo "<a href=\"$url1"."foroescribir$url2$url3"."foro=$_GET[foro]\" class=\"eforo\">Nuevo tema</a>" ;
}
if($_GET[foro] && $_GET[tema]) {
	echo " | <a href=\"$url1"."foroescribir$url2$url3"."foro=$_GET[foro]&tema=$_GET[tema]\" class=\"eforo\">Responder</a>" ;
}
?>
</td>
</tr>
<tr>
<td>
<?
if(!$_COOKIE[unick]) {
?>
<script type="text/javascript">
function revisar_usuario() {
	document.u_formulario.u_nick.value = document.u_formulario.u_nick.value.replace(/^\s*|\s*$/g,'') ;
	document.u_formulario.u_contrasena.value = document.u_formulario.u_contrasena.value.replace(/^\s*|\s*$/g,'') ;
	if(document.u_formulario.u_nick.value.length == 0) {
		alert('Debes escribir un nick') ;
		return false ;
	}
	if(document.u_formulario.u_contrasena.value.length == 0) {
		alert('Debes escribir una contrase�a') ;
		return false ;
	}
}
</script>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<form name="u_formulario" method="post" action="forousuariopro.php?que=entrar" onsubmit="return revisar_usuario()">
<b>Nick:</b>
<input type="text" name="u_nick" size="10" maxlength="20" class="eforo_formulario">
<b>Contrase�a:</b>
<input type="password" name="u_contrasena" size="10" maxlength="10" class="eforo_formulario">
<input type="submit" name="enviar" value="Entrar" class="eforo_formulario">
</td></form>
<td valign="top"><div align="right"><a href="<?=$url1.'forousuario'.$url2.$url3?>que=registrar" class="eforo">Nuevo usuario</a> | <a href="<?=$url1.'forousuario'.$url2.$url3?>que=contrasena" class="eforo">Perd� mi contrase�a</a></div></td>
</tr>
</table>
<?
}
else {
$con = mysql_query("select count(id) from eforo_privados where leido='0' and id_destinatario='$usuario[id]'") ;
if($p_nuevos = mysql_result($con,0,0)) {
	if($p_nuevos == 1) {
		$p_nuevos = 'tienes '.$p_nuevos.' mensaje nuevo' ;
	}
	else {
		$p_nuevos = 'tienes '.$p_nuevos.' mensajes nuevos' ;
	}
}
mysql_free_result($con) ;
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>Bienvenid@ <b><?=$_COOKIE[unick]?></b><? if($p_nuevos) { echo ', <a href="'.$url1.'foroprivados'.$url2.'" class="eforo">'.$p_nuevos.'</a>' ; } ?></td>
<td>
<center>
<select onchange="if(value) location = options[selectedIndex].value" class="eforo_formulario">
<option>Opci�n ...
<option value="<?=$url1.'foroprivados'.$url2?>">Mensajes privados
<option value="<?=$url1.'forousuario'.$url2.$url3.'que=perfil&u='.$usuario[id]?>">Editar mi perfil
<?
	foreach($conf[admin_id] as $id_admin) {
		if($id_admin == $usuario[id]) {
			echo '<option value="eforo_admin">Panel de administraci�n' ;
			break ;
		}
	}
?>
</select>
</center>
</td>
<td><div align="right"><a href="forousuariopro.php?que=salir" class="eforo">Salir del foro</a></div></td>
</tr>
</table>
<?
}
?>
</td>
</tr>
</table>
