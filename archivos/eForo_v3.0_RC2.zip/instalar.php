<style>
body {
font-family: verdana ;
font-size: 10pt ;
color: #000000 ;
margin: 100 ;
}
.f {
text-align: center ;
}
</style>
<p><b>eForo v3.0 - Instalaci�n</b>
<?
if(!$_POST[enviar]) {
?>
<p>Gracias por tu inter�s en eForo, antes de comenzar con la instalaci�n recuerda haber configurado el archivo <b>config.php</b> con tus datos
de conexi�n a la base de datos. Ahora se comprobar� la configuraci�n de <b>config.php</b>.
<p>
<div style="border-color: #000000 ; border-width: 1 ; border-style: solid ; background: #cddff0">
<div style="margin: 5">
Comprobando configuraci�n de <b>config.php</b>...<br><br>
<?
include('config.php') ;
if(!$conectar) {
echo '<b>Error: Los datos de conexi�n est�n incorrectos</b>' ;
}
else {
echo 'El archivo <b>config.php</b> est� configurado correctamente' ;
}
?>
</div>
</div>
<p>A continuaci�n deber�s completar la configuraci�n previa a la instalaci�n.
<form method="post" action="instalar.php">
<b>�C�mo deseas instalar eForo?</b><br>
<input type="radio" id="1" name="tabla_usuarios" value="1" checked> <label for="1">Instalaci�n t�pica</label> <input type="radio" id="2" name="tabla_usuarios" value="2"> <label for="2">Compatibilidad con sistema "Registro de usuarios"</label><br><br>
<b>Nick del usuario que ser� administrador del foro:</b><br>
<input type="text" size="30" name="administrador"><br>
URL donde est� instalado eForo (ej. http://www.pagina.com/foro/):<br>
<input type="text" size="30" name="urlforo" value="http://<?=$_SERVER[HTTP_HOST].str_replace("\\",'',dirname($_SERVER[SCRIPT_NAME]))?>/"><br><br>
<b>Forma de URL (Si deseas integrar eForo como una secci�n de tu web) :</b><br>
<b>URL:</b> / <input type="text" size="18" name="url1" value="" class="f"> foromensajes <input type="text" size="3" name="url2" value=".php" class="f"> <input type="text" size="3" name="url3" value="?" class="f"> foro=1&tema=1&mensaje=1#1<br>
Si usas secciones del tipo "index.php?seccion=noticias&n=1" los campos quedar�an as�:
<input type="text" size="18" value="index.php?seccion=" class="f" disabled> <input type="text" size="3" value="" class="f" disabled> <input type="text" size="3" value="&" class="f" disabled><br>
Con estos campos se formar�a la URL "index.php?seccion=foromensajes&foro=1&tema=1&mensaje=1#1" dejando a eForo dentro del formato de la web.
As�, s�lo tendr�as que hacer un enlace a "index.php?seccion=foro" para tener integrado eForo en tu web.<br>
Si deseas usar eForo de forma individual deja todo como est�.<br><br>
<input type="submit" name="enviar" value="Comenzar Instalaci�n">
</form>
<?
}
else {
include('config.php') ;
$_POST[tabla_usuarios] = ($_POST[tabla_usuarios] == 1) ? 'eforo_usuarios' : 'usuarios' ; 
$con = mysql_query("select id from $_POST[tabla_usuarios] where nick='$_POST[administrador]'") ;
if(!@mysql_num_rows($con)) {
$fecha = strtotime(gmdate('d M Y H:i:s')) ;
$usuario = "insert into $_POST[tabla_usuarios] (fecha,nick,contrasena,conectado) values ('$fecha','$_POST[administrador]',md5(md5('12345678')),'$fecha')" ;
}
else {
$datos = mysql_fetch_array($con) ;
$id_administrador = $datos[id] ;
}
$codigo =
"create table eforo_adjuntos (
  id smallint(5) unsigned not null auto_increment,
  id_mensaje smallint(5) unsigned not null,
  archivo varchar(64) not null,
  descargas smallint(5) unsigned not null,
  primary key (id)
)
;
create table eforo_categorias (
  id tinyint(3) unsigned not null auto_increment,
  orden tinyint(3) unsigned not null,
  categoria varchar(100) not null,
  primary key (id),
  key orden (orden)
)
;
create table eforo_config (
  id tinyint(3) unsigned not null auto_increment,
  administrador varchar(20) not null,
  email varchar(100) not null,
  urlforo varchar(100) not null,
  titulo varchar(100) not null,
  temas tinyint(3) unsigned not null,
  mensajes tinyint(3) unsigned not null,
  ultimos tinyint(3) unsigned not null,
  codigo enum('0','1') not null,
  caretos enum('0','1') not null,
  url enum('0','1') not null,
  firma enum('0','1') not null,
  censurar enum('0','1') not null,
  notificacion enum('0','1') not null,
  estilo varchar(100) not null,
  avatarlargo smallint(5) unsigned not null,
  avatarancho smallint(5) unsigned not null,
  avatartamano smallint(5) unsigned not null,
  privados tinyint(3) unsigned not null,
  adjuntotamano smallint(5) unsigned not null,
  adjuntoext text not null,
  adjuntonombre tinyint(3) unsigned not null,
  primary key (id)
)
;
create table eforo_enlinea (
  fecha int(10) unsigned not null,
  ip varchar(15) not null,
  id_usuario smallint(5) not null,
  key fecha (fecha)
)
;
create table eforo_foros (
  id tinyint(3) unsigned not null auto_increment,
  orden tinyint(3) unsigned not null,
  id_categoria tinyint(3) unsigned not null,
  foro varchar(100) not null,
  descripcion tinytext not null,
  num_temas smallint(5) unsigned not null,
  num_mensajes smallint(5) unsigned not null,
  p_leer smallint(5) not null,
  p_nuevo smallint(5) not null,
  p_responder smallint(5) not null,
  p_editar smallint(5) not null,
  p_borrar smallint(5) not null,
  p_importante smallint(5) not null,
  p_adjuntar smallint(5) not null,
  primary key (id),
  key orden (orden),
  key categoria (id_categoria)
)
;
create table eforo_mensajes (
  id mediumint(8) unsigned not null auto_increment,
  id_foro tinyint(3) unsigned not null,
  id_tema smallint(5) unsigned not null,
  num_visitas smallint(5) unsigned not null,
  num_respuestas smallint(5) unsigned not null,
  fecha int(10) unsigned not null,
  id_usuario smallint(5) unsigned not null,
  tema varchar(100) not null,
  mensaje text not null,
  o_caretos enum('0','1') not null,
  o_codigo enum('0','1') not null,
  o_url enum('0','1') not null,
  o_firma enum('0','1') not null,
  o_importante enum('0','1') not null,
  o_notificacion enum('0','1') not null,
  o_notificacion_email enum('0','1') not null,
  fecha_editado int(10) unsigned not null,
  fecha_ultimo int(10) unsigned not null,
  primary key (id),
  key id_indice (id_foro,id_tema)
)
;
create table eforo_moderadores (
  id smallint(5) unsigned not null auto_increment,
  id_foro smallint(5) unsigned not null,
  id_usuario smallint(5) not null,
  primary key (id)
)
;
create table eforo_privados (
  id smallint(5) unsigned not null auto_increment,
  leido tinyint(1) unsigned not null,
  fecha int(10) unsigned not null,
  id_remitente varchar(20) not null,
  id_destinatario varchar(20) not null,
  mensaje text not null,
  primary key (id),
  key destinatario (id_destinatario)
)
;
create table eforo_rangos (
  rango smallint(5) not null,
  minimo smallint(5) unsigned not null,
  descripcion varchar(100) not null,
  primary key (rango)
)
;
create table eforo_recientes (
  id_usuario smallint(5) unsigned not null,
  fecha int(10) unsigned not null,
  id_foro smallint(5) unsigned not null,
  id_mensaje smallint(5) unsigned not null,
  key id_usuario (id_usuario)
)
;
create table $_POST[tabla_usuarios] (
  id smallint(5) unsigned not null auto_increment,
  fecha int(10) unsigned not null,
  nick varchar(20) not null,
  contrasena varchar(32) not null,
  email varchar(40) not null,
  pais varchar(20) not null,
  edad tinyint(2) unsigned not null,
  sexo enum('0','1') not null,
  descripcion tinytext not null,
  web varchar(100) not null,
  ip varchar(15) not null,
  firma text not null,
  mensajes smallint(5) unsigned not null,
  rango smallint(5) not null,
  rango_fijo enum('0','1') not null,
  conectado int(10) unsigned not null,
  gmt tinyint(3) not null,
  avatar char(3) not null,
  primary key (id),
  key nick (nick,contrasena)
)
;
insert into eforo_categorias (orden,categoria) values ('10','Categor�a de ejemplo')
;
insert into eforo_foros (orden,id_categoria,foro,descripcion,num_temas,num_mensajes) values ('10','1','Foro de ejemplo','Descripci�n','1','1')
;
insert into eforo_mensajes (id_foro,id_tema,fecha,tema,mensaje,fecha_editado,fecha_ultimo) values ('1','1','$fecha','Gracias por usar eForo v3.0','eForo es el resultado de meses de trabajo, el atraso de su salida se debe m�s que nada a que dispongo de poco tiempo para desarrollar nuevos scripts, sin embargo aprovecho mis ratos libres para hacer lo que pueda.\r\n\r\neForo fue reescrito desde cero, con esto se consigui� reducir el c�digo a 1/3 del c�digo original adem�s de lograr un m�nimo consumo de recursos.\r\n\r\nAgradezco tu inter�s por usar eForo y espero que lo disfrutes :D\r\n\r\nElectros\r\nWebmaster\r\n\r\nPD: Por cierto si tienes un foro phpBB, vBulletin � alg�n otro parecido y deseas transferir tus mensajes a eForo pronto estar�n disponibles parches que har�n todo el trabajo por t�, si apoyas esta propuesta enviame un correo a electros@electros.net o escribe un mensaje en el foro de la web http://www.electros.net','$fecha','$fecha')
;
insert into eforo_rangos (rango,descripcion) values ('-1','Banead@')
;
insert into eforo_rangos (rango,descripcion) values ('0','An�nim@')
;
insert into eforo_rangos (rango,descripcion) values ('1','Nuev@')
;
insert into eforo_rangos (rango,descripcion) values ('500','Moderador')
;
insert into eforo_rangos (rango,descripcion) values ('999','Administrador')
" ;
$codigo = explode(';',$codigo) ;
foreach($codigo as $linea) {
@mysql_query($linea) ;
}
if($_POST[tabla_usuarios] == 'usuarios') {
$codigo =
"alter table $_POST[tabla_usuarios] add firma text not null
;
alter table $_POST[tabla_usuarios] add mensajes smallint(5) unsigned not null
;
alter table $_POST[tabla_usuarios] add rango smallint(5) not null
;
alter table $_POST[tabla_usuarios] add rango_fijo enum('0','1') not null
;
alter table $_POST[tabla_usuarios] add conectado int(10) unsigned not null
;
alter table $_POST[tabla_usuarios] add gmt tinyint(3) not null
;
alter table $_POST[tabla_usuarios] add avatar char(3) not null
;
update $_POST[tabla_usuarios] set rango_fijo='1' where rango='-1'
;
update $_POST[tabla_usuarios] set rango_fijo='1' where rango='500'
;
update $_POST[tabla_usuarios] set rango_fijo='1' where rango='999'
" ;
$codigo = explode(';',$codigo) ;
foreach($codigo as $linea) {
@mysql_query($linea) ;
}
}
if($usuario) {
mysql_query($usuario) ;
$id_administrador = mysql_insert_id() ;
}
mysql_query("insert into eforo_config
(administrador,email,urlforo,temas,mensajes,ultimos,codigo,caretos,url,firma,censurar,notificacion,estilo,avatarlargo,avatarancho,avatartamano,privados,adjuntotamano,adjuntoext,adjuntonombre)
values
('$id_administrador','nombre@email.com','$_POST[urlforo]','25','20','20','1','1','1','1','0','1','electros','150','150','30','100','512','zip\r\nrar\r\ntxt\r\nrtf\r\ngif\r\njpg\r\njpeg\r\npng\r\ndoc\r\nxls\r\nppt\r\npps\r\npdf\r\nmid\r\nswf\r\nmpg\r\nmpeg\r\navi\r\nwma\r\nwmv','32')
") ;
?>
<p style="font-size: 12pt"><b>Instalaci�n completada</b>
<p>La instalaci�n se ha completado. Ya puedes disfrutar de eForo.
<p>Recuerda darle permiso CHMOD 777 a la carpeta <b>avatares</b> que se encuentra dentro de <b>eforo_imagenes</b>, para esto entra desde cualquier
programa FTP, haz click derecho sobre la carpeta y busca una opci�n que diga CHMOD, Permisos o Propiedades.
<?
if($usuario) {
echo '<p>Se ha creado un nuevo usuario llamado <b>'.$_POST[administrador].'</b> el cu�l ser� administrador, la contrase�a es <b>12345678</b>
pero se recomienda cambiarla desde el perfil lo antes posible. Para administrar eForo inicia sesi�n con este usuario y en el men� selecciona la opci�n
<b>Panel de control</b>.' ;
}
else {
echo '<p>Se ha seleccionado al usuario <b>'.$_POST[administrador].'</b> como administrador. Para administrar eForo inicia sesi�n con este usuario y en el men� selecciona la opci�n
<b>Panel de control</b>.' ;
}
$foroconfig = file_get_contents('foroconfig.txt') ;
$foroconfig = str_replace("\$tabla_usuarios = 'eforo_usuarios' ;","\$tabla_usuarios = '$_POST[tabla_usuarios]' ;",$foroconfig) ;
$foroconfig = str_replace("\$url1 = '' ;","\$url1 = '$_POST[url1]' ;",$foroconfig) ;
$foroconfig = str_replace("\$url2 = '.php' ;","\$url2 = '$_POST[url2]' ;",$foroconfig) ;
$foroconfig = str_replace("\$url3 = '?' ;","\$url3 = '$_POST[url3]' ;",$foroconfig) ;
$abrir = fopen('foroconfig.php',w) ;
fwrite($abrir,$foroconfig) ;
fclose($abrir) ;
?>
<p><span style="color: #aa0000"><b>No te olvides de eliminar los archivos instalar.php y foroconfig.txt una vez terminada la instalaci�n.</b></span>
<p><input type="button" value="Finalizar" onclick="location='foro.php'">
<?
}
?>
