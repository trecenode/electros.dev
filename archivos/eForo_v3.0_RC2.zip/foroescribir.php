<?
/*
************************************************
*** eForo v3.0
*** Creado por: Electros <electros@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
************************************************

--- P�gina: foroescribir.php ---

eForo - Una comunidad para que tus visitantes se comuniquen y se sientan parte de tu web
Copyright � 2003-2005 Daniel Osorio "Electros"

Este programa es software libre, puedes redistribuirlo y/o modificarlo bajo los t�rminos
de la GNU General Public License publicados por la Free Software Foundation; desde la
versi�n 2 de la licencia, o (si lo deseas) cualquiera m�s reciente.
*/

require('foroconfig.php') ;
require('eforo_funciones/aviso.php') ;
require('eforo_funciones/sesion.php') ;
require('eforo_funciones/menu.php') ;

# * Mostrar la cabecera (definida desde el panel de control en foroadmin.php)
if($conf[html_cabecera]) {
	echo $conf[html_cabecera] ;
}

# * Comportamiento del formulario (escribir, responder o editar un mensaje)
$permiso = false ;
switch(true) {
	# Escribir nuevo tema
	case $_GET[foro] && !$_GET[tema] && !$_GET[mensaje] :
	$que = 1 ;
	$permiso = 'p_nuevo' ;
	$formulario_titulo = 'Escribir nuevo tema' ;
	$formulario_tema = false ;
	$formulario_mensaje = false ;
	break ;
	# Responder al tema
	case $_GET[foro] && $_GET[tema] && !$_GET[mensaje] :
	$que = 2 ;
	$permiso = 'p_responder' ;
	$formulario_titulo = 'Responder al tema' ;
	$formulario_tema = false ;
	$formulario_mensaje = false ;
	break ;
	# Editar el mensaje
	case $_GET[foro] && $_GET[tema] && $_GET[mensaje] :
	$que = 3 ;
	$permiso = 'p_editar' ;
	$formulario_titulo = 'Editar el mensaje' ;
}

# * Comprobar permiso de usuario
if(!$es_moderador) {
	permiso($permiso) ;
}

# * Se comprueba si el mensaje pertenece al usuario (se ignora la comprobaci�n en caso de ser moderador o administrador)
if($que == 3) {
	$con = mysql_query("select * from eforo_mensajes where id='$_GET[mensaje]'") ;
	$datos = mysql_fetch_array($con) ;
	if($datos[id_usuario] != $usuario[id] && !$es_moderador) {
		aviso('Error','<p>Tu no puedes editar este mensaje.<p><a href="javascript:history.back()" class="eforo">� Regresar</a>') ; exit ;
	}
	if($datos[id] == $datos[id_tema]) {
		$es_tema = true ;
	}
	# --> Se rellenan los campos del formulario con el mensaje a editar
	$formulario_tema = $datos[tema] ;
	$formulario_mensaje = $datos[mensaje] ;
	$formulario_caretos = $datos[o_caretos] ;
	$formulario_codigo = $datos[o_codigo] ;
	$formulario_url = $datos[o_url] ;
	$formulario_firma = $datos[o_firma] ;
	$formulario_imp = $datos[o_importante] ;
	$formulario_not = $datos[o_notificacion] ;
	mysql_free_result($con) ;
}
?>
<script type="text/javascript">
function codigo(a,b) {
	if(navigator.appName == 'Microsoft Internet Explorer') {
		if(seleccionado = document.selection.createRange().text) {
			document.selection.createRange().text = a + seleccionado + b ;
			document.m_formulario.m_mensaje.focus() ;
		}
		else {
			document.m_formulario.m_mensaje.focus() ;
			document.selection.createRange().text = a + b ;
		}
	}
	else {
		document.m_formulario.m_mensaje.value += a + b ;
		document.m_formulario.m_mensaje.focus() ;
	}
}
function ayuda1(a) {
	m_ayuda.innerHTML = '<b>'+a+'</b>' ;
}
function ayuda2() {
	m_ayuda.innerHTML = '' ;
}
function caretos(a) {
	if(navigator.appName == 'Microsoft Internet Explorer') {
		document.m_formulario.m_mensaje.focus() ;
		document.selection.createRange().text = a ;
	}
	else {
		document.m_formulario.m_mensaje.value += a ;
		document.m_formulario.m_mensaje.focus() ;
	}
}
function vista_previa() {
	m_formulario.method = 'post' ;
	m_formulario.action = '<?=$url1.'forovistapre'.$url2.$url3?>foro=<?=$_GET[foro]?>&tema=<?=$_GET[tema]?>&mensaje=<?=$_GET[mensaje]?>' ;
	m_formulario.target = '_blank' ;
	m_formulario.submit() ;
	m_formulario.action = '<?=$url1.'foroescribirpro'.$url2.$url3?>foro=<?=$_GET[foro]?>&tema=<?=$_GET[tema]?>&mensaje=<?=$_GET[mensaje]?>' ;
}
enviado = 0 ;
function revisar() {
<? if($que == 1 || $es_tema) { echo "document.m_formulario.m_tema.value = document.m_formulario.m_tema.value.replace(/^\s*|\s*$/g,'') ;\n" ; } ?>
document.m_formulario.m_mensaje.value = document.m_formulario.m_mensaje.value.replace(/^\s*|\s*$/g,'') ;
<? if($que == 1 || $es_tema) { echo "if(document.m_formulario.m_tema.value.length < 3) { alert('Debes escribir un tema') ; return false ; }\n" ; } ?>
if(document.m_formulario.m_mensaje.value.length < 3) { alert('Debes escribir un mensaje') ; return false ; }
if(enviado == 0) { enviado++ ; } else { alert('El mensaje se est� enviando por favor espera.') ; return false ; }
}
</script>
<table width="100%" border="0" cellpadding="3" cellspacing="1" align="center" class="eforo_tabla_principal">
<form name="m_formulario" method="post" action="<?=$url1.'foroescribirpro'.$url2.$url3?>foro=<?=$_GET[foro]?>&tema=<?=$_GET[tema]?>&mensaje=<?=$_GET[mensaje]?>&pag=<?=$_GET[pag]?>" enctype="multipart/form-data" onsubmit="return revisar()">
<input type="hidden" name="que" value="<?=$que?>">
<input type="hidden" name="permiso" value="<?=$permiso?>">
<tr>
<td colspan="2" class="eforo_tabla_titulo"><div align="center" class="eforo_titulo_1"><?=$formulario_titulo?></div></td>
</tr>
<tr>
<td valign="top" class="eforo_tabla_defecto"><b>T�tulo:</b><br>T�tulo del mensaje.</td>
<td valign="top" class="eforo_tabla_defecto"><input type="text" name="m_tema" size="75" value="<?=$formulario_tema?>" maxlength="60" class="eforo_formulario"></td>
</tr>
<tr>
<td valign="top" class="eforo_tabla_defecto"><b>Mensaje:</b><br>Contenido del mensaje.</td>
<td valign="top" class="eforo_tabla_defecto">
<b>C�digo especial:</b>
<div style="margin-top: 3"></div>
<input type="button" onclick="codigo('[b]','[/b]')" value="[b]" onmouseover="ayuda1('Texto en negrita')" onmouseout="ayuda2()" class="eforo_formulario">
<input type="button" onclick="codigo('[i]','[/i]')" value="[i]" onmouseover="ayuda1('Texto en cursiva')" onmouseout="ayuda2()" class="eforo_formulario">
<input type="button" onclick="codigo('[u]','[/u]')" value="[u]" onmouseover="ayuda1('Texto subrayado')" onmouseout="ayuda2()" class="eforo_formulario">
<input type="button" onclick="codigo('[img]','[/img]')" value="[img]" onmouseover="ayuda1('Poner una imagen')" onmouseout="ayuda2()" class="eforo_formulario">
<input type="button" onclick="codigo('[url]','[/url]')" value="[url]" onmouseover="ayuda1('Crear un enlace')" onmouseout="ayuda2()" class="eforo_formulario">
<input type="button" onclick="codigo('[cod]','[/cod]')" value="[cod]" onmouseover="ayuda1('Colorear c�digo')" onmouseout="ayuda2()" class="eforo_formulario">
<span id="m_ayuda"></span>
<div style="margin-top: 3"></div>
<a href="javascript:caretos(':D')"><img src="eforo_imagenes/caretos/alegre.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':8')"><img src="eforo_imagenes/caretos/asustado.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':P')"><img src="eforo_imagenes/caretos/burla.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':S')"><img src="eforo_imagenes/caretos/confundido.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':(1')"><img src="eforo_imagenes/caretos/demonio.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':(2')"><img src="eforo_imagenes/caretos/demonio2.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':?')"><img src="eforo_imagenes/caretos/duda.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':-\(')"><img src="eforo_imagenes/caretos/enojado.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(';)')"><img src="eforo_imagenes/caretos/guino.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':\'(')"><img src="eforo_imagenes/caretos/llorar.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':lol:')"><img src="eforo_imagenes/caretos/lol.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':M')"><img src="eforo_imagenes/caretos/moda.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':|')"><img src="eforo_imagenes/caretos/neutral.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':)')"><img src="eforo_imagenes/caretos/risa.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':-)')"><img src="eforo_imagenes/caretos/sonrisa.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':R')"><img src="eforo_imagenes/caretos/sonrojado.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':O')"><img src="eforo_imagenes/caretos/sorprendido.gif" width="15" height="15" border="0"></a>
<a href="javascript:caretos(':(')"><img src="eforo_imagenes/caretos/triste.gif" width="15" height="15" border="0"></a>
<div style="margin-top: 3"></div>
<?
if($que == 2 && ereg('^[0-9]+$',$_GET[citar])) {
	$con = mysql_query("select id_usuario,mensaje from eforo_mensajes where id='$_GET[citar]'") ;
	$datos = mysql_fetch_array($con) ;
	$con2 = mysql_query("select nick from $tabla_usuarios where id='$datos[id_usuario]'") ;
	$datos2 = mysql_fetch_array($con2) ;
	$formulario_mensaje = "[citar autor=$datos2[nick]]$datos[mensaje][/citar]" ;
	mysql_free_result($con2) ;
	mysql_free_result($con) ;
?>
<script>
function citar() {
	document.m_formulario.m_mensaje.focus() ;
	document.m_formulario.m_mensaje.value += '\n\n' ;
}
onload = citar ;
</script>
<?
}
?>
<textarea name="m_mensaje" cols="75" rows="25" class="eforo_formulario"><?=$formulario_mensaje?></textarea>
</td>
</tr>
<?
# * Borrar archivo adjunto
if($_GET[borrar_adjunto]) {
	$con = mysql_query("select id from eforo_adjuntos where id_mensaje='$_GET[mensaje]'") ;
	$datos = mysql_fetch_array($con) ;
	$id_adjunto = $datos[id] ;
	mysql_free_result($con) ;
	mysql_query("delete from eforo_adjuntos where id='$id_adjunto'") ;
	unlink('eforo_adjuntos/'.$id_adjunto.'.dat') ;
}
$adjuntar = false ;
# * Comprobar si el usuario tiene permiso para adjuntar archivos
$con = mysql_query("select p_adjuntar from eforo_foros where id='$_GET[foro]'") ;
$datos = mysql_fetch_array($con) ;
if($usuario[rango] > $datos[p_adjuntar] || $es_moderador) {
	$adjuntar = true ;
	$con = mysql_query("select archivo from eforo_adjuntos where id_mensaje='$_GET[mensaje]' limit 1") ;
	if(mysql_num_rows($con)) {
		$datos = mysql_fetch_array($con) ;
		$adjuntar_titulo = '<b>Archivo adjunto:</b><br>Nombre del archivo adjunto.' ;
		$adjuntar_contenido = '<b>'.$datos[archivo].'</b><br><br><input type="button" value="Borrar" onclick="location=\''.$_SERVER[REQUEST_URI].'&borrar_adjunto=si\'" class="eforo_formulario">' ;
		}
	else {
		$adjuntar_titulo = '<b>Adjuntar archivo (M�x. '.$conf[adjunto_tamano].' KB):</b><br>Anexar un archivo a tu mensaje.' ;
		$adjuntar_contenido = '<input type="file" name="m_archivo" size="50" class="eforo_formulario">' ;
	}
}
mysql_free_result($con) ;
if($adjuntar) {
?>
<tr>
<td valign="top" class="eforo_tabla_defecto"><?=$adjuntar_titulo?></td>
<td valign="top" class="eforo_tabla_defecto"><?=$adjuntar_contenido?></td>
</tr>
<?
}
?>
<tr>
<td valign="top" class="eforo_tabla_defecto">&nbsp;</td>
<td valign="top" class="eforo_tabla_defecto">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="50%" valign="top">
<? if($conf[permitir_caretos]) { ?><input type="checkbox" name="m_caretos" value="1" id="m_caretos" <? if(!$_GET[mensaje] || $formulario_caretos) { echo ' checked' ; } ?>><label for="m_caretos"><b>Usar caretos en el mensaje</b></label><br><? } ?>
<? if($conf[permitir_codigo]) { ?><input type="checkbox" name="m_codigo" value="1" id="m_codigo" <? if(!$_GET[mensaje] || $formulario_codigo) { echo ' checked' ; } ?>><label for="m_codigo"><b>Usar c�digo especial en el mensaje</b></label><br><? } ?>
<? if($conf[transformar_url]) { ?><input type="checkbox" name="m_url" value="1" id="m_url" <? if(!$_GET[mensaje] || $formulario_url) { echo ' checked' ; } ?>><label for="m_url"><b>Transformar URLs en enlaces</b></label><br><? } ?>
</td>
<td width="50%" valign="top">
<input type="checkbox" name="m_firma" value="1" id="m_firma"<? if(!$_GET[mensaje] || $formulario_firma) { echo ' checked' ; } ?>><label for="m_firma"><b>Agregar firma en el mensaje</b></label><br>
<?
$con = mysql_query("select p_importante from eforo_foros where id='$_GET[foro]'") ;
$datos = mysql_fetch_array($con) ;
if($usuario[rango] >= $datos[p_importante] || $es_moderador) {
?>
<input type="checkbox" name="m_importante" value="1" id="m_importante"<? if($formulario_imp) { echo ' checked' ; } ?>><label for="m_importante"><b>Marcar el tema como importante</b></label><br>
<?
}
mysql_free_result($con) ;
?>
<? if($_GET[tema] == $_GET[mensaje] && $conf[notificacion_email]) { ?><input type="checkbox" name="m_notificacion" value="1" id="m_notificacion"<? if($formulario_not) { echo ' checked' ; } ?>><label for="m_notificacion"><b>Notificarme por email cuando haya respuestas</b></label><br><? } ?>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td class="eforo_tabla_defecto">&nbsp;</td>
<td class="eforo_tabla_defecto">
<center><input type="button" onclick="vista_previa()" value="Vista Previa" class="eforo_formulario"> <input type="submit" name="enviar" value="Enviar Mensaje" class="eforo_formulario"></center>
</td>
</tr>
</table>
</form>
<?
# * Si el formulario est� en modo "responder" se muestran los �ltimos mensajes del tema
if($que == 2) {
	require('eforo_funciones/codigo.php') ;
?>
<script>
function proteger_email(usuario,servidor) {
	document.write('<a href="mailto:'+usuario+'@'+servidor+'" class="eforo">'+usuario+'@'+servidor+'</a>') ;
}
</script>
<table width="100%" border="0" cellpadding="3" cellspacing="1" align="center" class="eforo_tabla_principal">
<tr>
<td colspan="2" class="eforo_tabla_titulo"><div class="eforo_titulo_1">Ultimos <?=$conf[max_ultimos]?> mensajes del tema</div></td>
</tr>
<tr>
<td class="eforo_tabla_subtitulo"><div class="eforo_titulo_1">Autor</div></td>
<td class="eforo_tabla_subtitulo"><div class="eforo_titulo_1">Mensaje</div></td>
</tr>
<?
	$con = mysql_query("select * from eforo_mensajes where id_tema='$_GET[tema]' order by id desc limit $conf[max_ultimos]") ;
	while($datos = mysql_fetch_array($con)) {
		if($num == 2) {
			$num-- ;
		}
		else {
			$num++ ;
		}
		$con2 = mysql_query("select nick from $tabla_usuarios where id='$datos[id_usuario]'") ;
		if(mysql_num_rows($con2)) {
			$datos2 = mysql_fetch_array($con2) ;
			$autor_mensaje = "<a href='$url1"."forousuarios$url2$url3"."miembro=$datos[id_usuario]' target='_blank' class='eforo'>$datos2[nick]</a>" ;
		}
		else {
			$autor_mensaje = 'Invitad@' ;
		}
		if($conf[permitir_caretos] && $datos[o_caretos]) {
			$datos[mensaje] = caretos($datos[mensaje]) ;
		}
		if($conf[permitir_codigo] && $datos[o_codigo]) {
			$datos[mensaje] = codigo($datos[mensaje]) ;
		}
		if($conf[transformar_url] && $datos[o_url]) {
			$datos[mensaje] = url($datos[mensaje]) ;
		}
		if($conf[censurar_palabras]) {
			$datos[mensaje] = censurar($datos[mensaje]) ;
		}
		$datos[mensaje] = str_replace("\r",'<br>',$datos[mensaje]) ;
		if($datos[fecha_editado] > $datos[fecha]) {
			$editado = '<br><br><i><b>Editado por �ltima vez el '.fecha($datos[fecha_editado]).'</b></i>' ;
		}
		else {
			$editado = false ;
		}
?>
<tr>
<td width="20%" valign="top" class="eforo_tabla_mensaje_<?=$num?>">
<?=$autor_mensaje?><br>
</td>
<td width="80%" valign="top" class="eforo_tabla_mensaje_<?=$num?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<td>Tema: <b><?=$datos[tema]?></b></td>
<td><div align="right">Fecha: <b><?=fecha($datos[fecha])?></b></div></td>
</tr>
</table>
<hr width="100%" color="505050"><?=$datos[mensaje].$editado?>
</td>
</tr>
<?
	}
?>
</table>
<?
}
?>
<br><br>
<center>
<span style="font-size: 7pt">
<a href="http://www.electros.net" target="_blank" class="eforo">eForo v3.0</a> � 2003-2005 Bajo licencia GNU General Public License<br>
<?
# * Obtener tiempo de carga del foro (la funci�n tiempo() se encuentra en foroconfig.php)
$tiempo_b = tiempo() ;
$tiempo = round($tiempo_b - $tiempo_a,4) ;
echo 'Tiempo de carga del servidor: <b>'.$tiempo.'</b>' ;
?>
</span>
</center>
