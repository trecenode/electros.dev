<?
/*
************************************************
*** eForo v3.0
*** Creado por: Electros <electros@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
************************************************

--- P�gina: eforo_admin/index.php ---

eForo - Una comunidad para tus visitantes
Copyright � 2003-2004 Daniel Osorio "Electros"

Este programa es de C�digo Abierto, puedes redistribuirlo y/o modificarlo bajo los t�rminos
de la GNU General Public License publicados por la Free Software Foundation; desde la
versi�n 2 de la licencia, o (si lo deseas) cualquiera m�s reciente.
*/
?>
<title>eForo v3.0 � Panel de administraci�n</title>
<frameset cols="20%,80%" frameborder="0" framespacing="0">
	<frame name="menu" src="menu.php" scrolling="no">
	<frame name="contenido" src="foros.php">
</frameset>
