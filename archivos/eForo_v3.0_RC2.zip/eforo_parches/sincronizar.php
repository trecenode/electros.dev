<?
include('../config.php') ;
$con = mysql_query('select id,foro from eforo_foros order by id asc') ;
while($datos = mysql_fetch_array($con)) {
	$con2 = mysql_query("select id from eforo_mensajes where id=id_tema and id_foro='$datos[id]'") ;
	$total_temas = mysql_num_rows($con2) ;
	mysql_free_result($con2) ;
	$con2 = mysql_query("select id from eforo_mensajes where id_foro='$datos[id]'") ;
	$total_mensajes = mysql_num_rows($con2) ;
	mysql_free_result($con2) ;
	mysql_query("update eforo_foros set num_temas='$total_temas',num_mensajes='$total_mensajes' where id='$datos[id]'") ;
	echo 'Se sincronizaron correctamente los mensajes en el foro <b>'.$datos[foro].'</b><br>' ;
}
mysql_free_result($con) ;
?>