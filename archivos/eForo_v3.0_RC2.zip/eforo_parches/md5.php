<?
// Conversi�n de contrase�as a md5()
if(!$_GET[tabla_usuarios]) {
?>
<script>
tabla_usuarios = prompt('Escribe el nombre de la tabla donde est�n almacenados tus usuarios (ej. eforo_usuarios)','eforo_usuarios') ;
if(tabla_usuarios) location = 'md5.php?tabla_usuarios='+tabla_usuarios ;
</script>
<p>Debes indicar la tabla donde est�n almacenados tus usuarios.
<?
}
else {
	include('../config.php') ;
	$con = mysql_query("select id,contrasena from $_GET[tabla_usuarios] order by id asc") ;
	while($datos = mysql_fetch_array($con)) {
		$contrasena = md5(md5($datos[contrasena])) ;
		mysql_query("update $_GET[tabla_usuarios] set contrasena='$contrasena' where id='$datos[id]'") ;
		echo 'Contrase�a cambiada en ID '.$datos[id].'<br>' ;
	}
	echo '<br>Se encriptaron correctamente las contrase�as' ;
}
?>