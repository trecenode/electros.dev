<?
/*
************************************************
*** eForo v3.0
*** Creado por: Electros <electros@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
************************************************

--- P�gina: config.php ---

eForo - Una comunidad para que tus visitantes se comuniquen y se sientan parte de tu web
Copyright � 2003-2005 Daniel Osorio "Electros"

Este programa es software libre, puedes redistribuirlo y/o modificarlo bajo los t�rminos
de la GNU General Public License publicados por la Free Software Foundation; desde la
versi�n 2 de la licencia, o (si lo deseas) cualquiera m�s reciente.

Cuando se habla de Open Source o C�digo Abierto no se refiere a precio, sino a la libertad
de poder accesar al c�digo fuente, con el cu�l puedes aprender y realizar modificaciones,
adem�s de distribuirlo, inclusive puedes agregar tus cr�ditos pero sin eliminar los del
autor original (ej. Modificado por: XXXXX Creado por: Electros).
*/

# * Conexi�n a la base de datos
$bdservidor = 'localhost' ; # Com�nmente es "localhost" aunque puede ser una IP (32.64.128.255) o una URL (www.electros.net)
$bdusuario = 'usuario' ; # Nombre de usuario de la base de datos
$bdcontrasena = 'contrasena' ; # Contrase�a de la base de datos
$bd = 'eforo' ; # Nombre de la base de datos
if(!$conectar = @mysql_connect($bdservidor,$bdusuario,$bdcontrasena)) {
	if(mysql_errno() == 1040) {
		$error = 'Too many connections (El servidor se encuentra saturado debido al exceso de tr�fico)' ;
	}
	else {
		$error = mysql_error() ;
	}
?>
<style>
body { font-family: verdana ; font-size: 10pt }
</style>
<p><b>Error</b>
<p>No se pudo conectar a la base de datos debido a:
<p><b><?=$error?></b>
<?
	exit ;
}
mysql_select_db($bd,$conectar) ;
?>
