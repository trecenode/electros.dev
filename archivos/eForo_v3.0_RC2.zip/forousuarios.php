<?
/*
************************************************
*** eForo v3.0
*** Creado por: Electros <electros@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
************************************************

--- P�gina: forousuarios.php ---

eForo - Una comunidad para que tus visitantes se comuniquen y se sientan parte de tu web
Copyright � 2003-2005 Daniel Osorio "Electros"

Este programa es software libre, puedes redistribuirlo y/o modificarlo bajo los t�rminos
de la GNU General Public License publicados por la Free Software Foundation; desde la
versi�n 2 de la licencia, o (si lo deseas) cualquiera m�s reciente.
*/

require('foroconfig.php') ;
require('eforo_funciones/paginar.php') ;
?>
<p><a href="<?=$url1.'foro'.$url2?>" class="eforo">� Regresar</a>
<p>
<table width="100%" border="0" cellpadding="3" cellspacing="1" align="center" class="eforo_tabla_principal">
<tr>
<td colspan="8" class="eforo_tabla_titulo"><div class="eforo_titulo_1">Lista de usuarios</div></td>
</tr>
<?
if(!ereg('^[0-9]+$',$_GET[u])) {
	$letra = ereg('[a-z]{1}',$_GET[letra]) ? " where nick like '$_GET[letra]%'" : false ;
	$orden = $letra ? 'nick asc' : 'id desc' ;
	$paginar = new paginar("select * from $tabla_usuarios$letra order by $orden") ;
	$paginar->mostrar(30) ;
	$con = $paginar->procesar_codigo() ;
?>
<tr>
<td colspan="8" class="eforo_tabla_defecto">
<center>
<a href="<?=$url1.'forousuarios'.$url2?>" class="eforo">M�s recientes</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=a'?>" class="eforo">A</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=b'?>" class="eforo">B</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=c'?>" class="eforo">C</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=d'?>" class="eforo">D</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=e'?>" class="eforo">E</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=f'?>" class="eforo">F</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=g'?>" class="eforo">G</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=h'?>" class="eforo">H</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=i'?>" class="eforo">I</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=j'?>" class="eforo">J</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=k'?>" class="eforo">K</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=l'?>" class="eforo">L</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=m'?>" class="eforo">M</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=n'?>" class="eforo">N</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=o'?>" class="eforo">O</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=p'?>" class="eforo">P</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=q'?>" class="eforo">Q</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=r'?>" class="eforo">R</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=s'?>" class="eforo">S</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=t'?>" class="eforo">T</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=u'?>" class="eforo">U</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=v'?>" class="eforo">V</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=w'?>" class="eforo">W</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=x'?>" class="eforo">X</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=y'?>" class="eforo">Y</a> |
<a href="<?=$url1.'forousuarios'.$url2.$url3.'letra=z'?>" class="eforo">Z</a>
</center>
</td>
</tr>
<tr>
<td colspan="8" class="eforo_tabla_defecto"><?$paginar->crear_paginas()?></td>
</tr>
<tr>
<td class="eforo_tabla_titulo"><b>Nick</b></td>
<td class="eforo_tabla_titulo"><b>Sexo</b></td>
<td class="eforo_tabla_titulo"><b>Edad</b></td>
<td class="eforo_tabla_titulo"><b>Pa�s</b></td>
<td class="eforo_tabla_titulo"><b>Fecha de registro</b></td>
</tr>
<?
	$num = 1 ;
	while($datos = mysql_fetch_array($con)) {
?>
<tr>
<td class="eforo_tabla_mensaje_<?=$num?>"><a href="<?=$url1.'forousuarios'.$url2.$url3.'u='.$datos[id]?>" class="eforo"><?=$datos[nick]?></a></td>
<td class="eforo_tabla_mensaje_<?=$num?>"><?=!$datos[sexo] ? 'Masculino' : 'Femenino'?></td>
<td class="eforo_tabla_mensaje_<?=$num?>"><?=$datos[edad] ? $datos[edad] : '&nbsp;'?></td>
<td class="eforo_tabla_mensaje_<?=$num?>"><?=$datos[pais] ? $datos[pais] : '&nbsp;'?></td>
<td class="eforo_tabla_mensaje_<?=$num?>"><?=fecha($datos[fecha])?></td>
</tr>
<?
		$num = ($num == 1) ? 2 : 1 ; 
	}
	mysql_free_result($con) ;
?>
<tr>
<td colspan="8" class="eforo_tabla_defecto"><?$paginar->crear_paginas()?></td>
</tr>
<?
}
else {
	# * Se almacenan todos los rangos en un array
	$con = mysql_query('select * from eforo_rangos order by rango asc') ;
	while($datos = mysql_fetch_array($con)) {
		$rangos[$datos[rango]] = $datos[minimo].'||'.$datos[descripcion] ;
	}
	mysql_free_result($con) ;
	$con = mysql_query("select * from $tabla_usuarios where id='$_GET[u]'") ;
	if(mysql_num_rows($con)) {
		$datos = mysql_fetch_array($con) ;
		$avatar = !$datos[avatar] ? '0.gif' : $datos[id].'.'.$datos[avatar] ;
		$datos[descripcion] = str_replace("\n",'<br>',$datos[descripcion]) ;
		$datos[firma] = str_replace("\n",'<br>',$datos[firma]) ;
		$datos[firma] = preg_replace('/\[.*\]/U','',$datos[firma]) ;
		if($datos[rango_fijo]) {
			list($minimo,$descripcion) = explode('||',$rangos[$datos[rango]]) ;
			$usuario_rango = $datos[rango].' - '.$descripcion ;
		}
		else {
			list($minimo,$descripcion) = explode('||',$rangos[1]) ;
			$usuario_rango = '1 - '.$descripcion ;
			foreach($rangos as $a => $b) {
				list($minimo,$descripcion) = explode('||',$b) ;
				if($minimo != 0 && $datos[mensajes] >= $minimo) {
					$usuario_rango = $a.' - '.$descripcion ;
				}
			}
		}
?>
<tr>
<td class="eforo_tabla_subtitulo"><div class="eforo_titulo_2">Perfil de <?=$datos[nick]?></div></td>
</tr>
<tr>
<td class="eforo_tabla_defecto">
<p><a href="<?=$url1.'forousuarios'.$url2?>" class="eforo">� Regresar a Lista de usuarios</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
<tr>
<td width="30%" valign="top"><b>Sexo:</b></td>
<td width="30%" valign="top"><?=!$datos[sexo] ? 'Masculino' : 'Femenino'?></td>
<td width="35%" rowspan="6" valign="top"><img src="eforo_imagenes/avatares/<?=$avatar?>" alt="Avatar de <?=$datos[nick]?>"></td>
</tr>
<tr>
<td valign="top"><b>Edad:</b></td>
<td valign="top"><?=$datos[edad] ? $datos[edad] : '<i>No indicada</i>'?></td>
</tr>
<tr>
<td valign="top"><b>Pa�s:</b></td>
<td valign="top"><?=$datos[pais] ? $datos[pais] : '<i>No indicado</i>'?></td>
</tr>
<tr>
<td valign="top"><b>Descripci�n:</b></td>
<td valign="top"><?=$datos[descripcion] ? $datos[descripcion] : '<i>Sin descripci�n</i>'?></td>
</tr>
<tr>
<td valign="top"><b>Web:</b></td>
<td valign="top"><?=$datos[web] ? "<a href=\"$datos[web]\" target=\"_blank\" class=\"eforo\">$datos[web]</a>" : '<i>Sin web</i>'?></td>
</tr>
<tr>
<td valign="top"><b>Firma en los mensajes:</b></td>
<td valign="top"><?=$datos[firma] ? $datos[firma] : '<i>Sin firma</i>'?></td>
</tr>
<tr>
<td valign="top"><b>Mensajes publicados:</b></td>
<td valign="top"><?=$datos[mensajes]?></td>
</tr>
<tr>
<td valign="top"><b>Rango o nivel:</b></td>
<td valign="top"><?=$usuario_rango?></td>
</tr>
<tr>
<td valign="top"><b>Fecha de registro:</b></td>
<td valign="top"><?=fecha($datos[fecha])?></td>
</tr>
<tr>
<td valign="top"><b>Conectado por �ltima vez:</b></td>
<td valign="top"><?=fecha($datos[conectado])?></td>
</tr>
</table>
</td>
</tr>
<?
	}
	else {
?>
<tr>
<td class="eforo_tabla_defecto"><center><b>El usuario no existe.</b></center></td>
</tr>
<?
	}
}
?>
</table>
<br><br>
<center>
<span style="font-size: 7pt">
<a href="http://www.electros.net" target="_blank" class="eforo">eForo v3.0</a> � 2003-2005 Bajo licencia GNU General Public License<br>
<?
# * Obtener tiempo de carga del foro (la funci�n tiempo() se encuentra en foroconfig.php)
$tiempo_b = tiempo() ;
$tiempo = round($tiempo_b - $tiempo_a,4) ;
echo 'Tiempo de carga del servidor: <b>'.$tiempo.'</b>' ;
?>
</span>
</center>
