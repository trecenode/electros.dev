<?
if($_POST[enviar]) {
	if($_FILES[archivo][size] <= 100000) {
		move_uploaded_file($_FILES[archivo][tmp_name],'carpeta/'.$_FILES[archivo][name]) ;
		echo 'El archivo ha sido subido con �xito.' ;
	}
	else {
		echo 'El archivo supera los 100 Kb.' ;
	}
}
?>
<form method="post" action="<?=$_SERVER[PHP_SELF]?>" enctype="multipart/form-data">
<input type="file" name="archivo">
<input type="submit" name="enviar" value="Enviar">
</form>