<?php
include("config.php"); // INCLUIMOS EL ARCHIVO PARA CONECTARNOS A LA BD.
# AUTORIZACION PARA ENTAR A LA ZONA DE ADMINISTRACION DE LOS MENSAJES
if (!isset($PHP_AUTH_USER)) {
header('WWW-Authenticate: Basic realm="Acceso restringido"');
header('HTTP/1.0 401 Unauthorized');
echo 'Authorization Required.';
exit;
}


if (($PHP_AUTH_USER==$usuario) && ($PHP_AUTH_PW==chop($password))){ $validado=true;
$i++;
}

if (!$validado) {
header('WWW-Authenticate: Basic realm="Acceso restringido"');
header('HTTP/1.0 401 Unauthorized');
echo 'Authorization Required.';
exit;
}
?>
<html>
<head>
<title>Mensajes recividos.</title>
</head>
<div align="right">
<font size="1" face="arial">Bienvenido <font color="blue"><?php echo $PHP_AUTH_USER?></font> a tu panel de mensajes.</font>
</div><br><br> 

<!-- CSS PARA TRATAR A LOS LIKS  -->

<STYLE TYPE="text/css">
a:link {text-decoration: none}
a:visited {text-decoration: none}
a:active {text-decoration: none}
a:hover {text-decoration: underline}
</STYLE>

<!-- --------------------------- --> 
<?


# SI NOS PIDEN BORRAR. BORRAMOS jejeje xD. QUEDARIA ASI 'mensajes?borrar=ID'
if($_GET["borrar"])
{ 
?>
<body alink="336699" vlink="336699" link="336699"><?
$borrar= $_GET["borrar"]; 
mysql_query("delete from contacto where id=$borrar limit 1");
echo "<center><font face=Verdana size=1 color=red><b>Mensaje borrado correctamente<br>Haz click <a href='mensajes.php'>aqui</a> para regresar.</b></font></center>";
}
else
{
if($_GET["id"])
{ 
?>
<body alink="336699" vlink="336699" link="336699">
<?

# SI NOS PIDEN VER. 'mensajes.php?id=ID' 
$ver= $_GET["id"]; 

$sql = mysql_query("select * from contacto where id=$ver");
$contacto = mysql_fetch_array($sql);
# SI EL MENSAJE QUE SE VA A MOSTRAR ES NUEVO(nuevo=0) SE LE CAMBIA (nuevo=1) EL VALOR PARA QUE YA NO SE TOME COMO TAL 
if($contacto[nuevo] == 0){
$nuevoborrar= mysql_query("update contacto set nuevo=1 where id=$ver");
} 
# SE LE SUMA UNA VISITA AL MENSAJE
$sumar= $contacto["cliks"] + 1;
$upd= mysql_query("update contacto set cliks=$sumar where id=$ver");
# SI LA ID DEL MENSAJE NO SE ENCUENTRA SE MUESTRA UN ERROR
if($contacto == ""){
echo "<center><font face=Verdana size=1><b>El mensaje no existe en la base de datos.<br>Haz click <a href='mensajes.php'>aqui</a> para regresar.</b></font></center>";
}else{
include("func.php");//INCLUIMOS EL ARCHIVO QUE CONTIENE LAS FUNCIONES

# LE DAMOS PRESENTACION AL MENSAJE
?>
<table align="center" border="0" width="80%">
	<tr>
		<td bgcolor="#663333">
		   <table border="0" bgcolor="#663333" width="100%">
	         <tr>
		        <td width="70%"><center><font face="Verdana" size="3" color="ffffff"><b><? echo $contacto[asunto]; ?></b></font></center></td>
		        <td width="20%" align="right"><font face="Verdana" color="ffffff" size="1"><b>Fecha: <? echo $contacto[fecha]; ?></b></font></td>
	        </tr>
           </table>
		</td>
	</tr>
	<tr>
		<td><br><font face="Verdana" size="1"><b><? echo quitar($contacto[mensaje]); ?></b></font><br><br></td>
	</tr>
	<tr>
		<td bgcolor="#969696">
		     <table width="90%" align="center" border="0" summary="">
	            <tr>
		          <td bgcolor="#969696" width="10%"><div align="left"><font face="Verdana" size="2"><b><a href="mensajes.php">Volver</a></b></div></td>		          
				  <td bgcolor="#969696" width="15%"><font face="Verdana" size="1" color="ffffff"><b>Enviado por:  <? echo $contacto[nombre]; ?></b></font></td>
		          <td bgcolor="#969696" width="25%"><font face="Verdana" size="1" color="ffffff"><b>IP del remitente:  <? echo $contacto[ip]; ?></b></font></td>
		          <td bgcolor="#969696" width="10%"><div align="right"><font face="Verdana" size="2"><b><a href="mensajes?borrar=<?=$contacto[id]?>">Borrar</a></b></div></td>
	           </tr>
             </table>   
	   </td>
	</tr>
</table>

<?
}
}
else{
// MOSTRAMOS LOS MENSAJES RECIVIDOS	
# SELECCIONAMOS LOS MENSAJES NUEVOS Y.....
$nuevos = mysql_query("select * from contacto where nuevo=0");
# LOS CONTAMOS
$contarnuevos= mysql_num_rows($nuevos);
# RECIVIMOS TODOS LOS MENSAJES Y LOS ORDENAMOS DE MANERA DECENDENTE Y....
$sql = mysql_query("select * from contacto order by id desc");
# LOS CONTAMOS
$contar= mysql_num_rows($sql);
?>
<body alink="ffffff" vlink="ffffff" link="ffffff">
<font face="arial" size="6" color="#663333"><center><b>MENSAJES RECIVIDOS</b></center></font>
<table width="46%" align="center" bgcolor="#663333" border="0" cellspacing="0" cellpading="0">
	<tr>
		<td align="center"><font face="arial" color="ffffff" size="1">Mensajes Nuevos: <?=$contarnuevos?></font></b></td>
		<td align="center"><font face="arial" color="ffffff" size="1">Total de Mensajes: <b><?=$contar?></b></font></td>
	</tr>
</table><br><br>
<?
# SI NO HAY MENSAJES INFORMAMOS
if($contar == 0){
echo "<center><font face=Verdana size=1><b>No hay mensajes recividos</b></font></center>";
}
else
{
while($contacto = mysql_fetch_array($sql))
{
$id=$contacto["id"];
# LE DAMOS PRESENTACION A LOS MENSAJES ACOMODANDOLOS EN UNA TABLA.
?> 
<body alink="FFFFFF" vlink="FFFFFF" link="FFFFFF">
<table align="center">
	<tr>
		<td width="70%" bgcolor="#663333"><div align="rigth"><font face=Verdana size=2 color="FFFFFF"><b>Remitente: </b> <a href=mailto:<?=$contacto['email']?>><?=$contacto['nombre']?></a></font></div></td>
		
		<td width="80%" bgcolor="#663333"><div align="left"><font face=Verdana size=1 color="ffffff"><b>IP del remitente:</b><?=$contacto[ip]?></font></div></td>
	</tr>
	<tr>	
		<td width="70%"><font face=Verdana size=1><b>Asunto:</b> <?=$contacto[asunto]?></font></td>
		<td><font face="arial" size="-1">ID de la noticia: <b><?=$id?></b></font></td> 
	</tr>
	<tr>	
		<td width="70%" bgcolor="#969696">
		  <table border="0" summary="">
	      <tr>
		  <td width="60%"><a href="mensajes.php?id=<?=$id?>"><font face="verdana" size="1"><b>Ver Mas...</b></font></a></td>
		  <td><center><font color="ffffff" face="verdana" size="1"><b>Visitado <b><?=$contacto["cliks"]?></b> veces</b></center></td>
	      </tr>
         </table> 
	    </td>
		<td width="70%" bgcolor="#969696">
		 <a href="mensajes.php?borrar=<?=$id?>"><font face="verdana" size="1"><b>Borrar</b></font></a>
		</td>
	 </tr>
	<tr>
</table><hr color="#663333" width="50%"><br>
<?
}
}
}
}
?>
