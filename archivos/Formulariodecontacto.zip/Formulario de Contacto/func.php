<?php 
/* DEFINIMOS ALGUNAS FUNCINES QUE MAS ADELANTE VAN A SER USADAS	*/

# FUNCION PARA OBTENER LA DIRECCION IP DE LOS USUARIOS
function obtener_ip() { 
  global $HTTP_SERVER_VARS; 
  if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"] != "") { 
   $ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]; 
  }else{ $ip = $HTTP_SERVER_VARS["REMOTE_ADDR"]; } 
  return($ip); 
} 

# FUNCION PDAR FORMATO A LOS MENSAJES RECIVIDOS.
function quitar($texto) {

// Quita los espacios al principio y al final
$texto = trim($texto);

// Esta funci�n intenta eliminar todas las etiquetas HTML y PHP de la cadena dada. (Quitar los // si queremos desactivar el html)
$texto = strip_tags($texto);

// Convierte el texto en html con sus etiquetas
$texto = htmlspecialchars($texto);

// convierte las ' " ' en ' " ' para que no den problemas con mysql
$texto = addslashes($texto);

// Reemplaza los saltos de linea por <br>
$texto = nl2br($texto);

return $texto ;
}
 

?>
