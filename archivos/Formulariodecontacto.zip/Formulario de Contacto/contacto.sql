CREATE TABLE contacto (
id INT(44) NOT NULL auto_increment,
nuevo BIGINT( 1 ) NOT NULL,
nombre VARCHAR(255),
email VARCHAR(255),
ip VARCHAR(255),
asunto VARCHAR(255),
mensaje LONGTEXT,
fecha VARCHAR( 20 ) NOT NULL,
cliks VARCHAR( 5 ) NOT NULL, 
PRIMARY KEY (id)
)

 