<html>
<head>
<title>Formulario de contacto</title>

</head>
<body alink="336699" link="336699" vlink="336699">
<STYLE TYPE="text/css">
a:link {text-decoration: none}
a:visited {text-decoration: none}
a:active {text-decoration: none}
a:hover {text-decoration: underline}
</STYLE> 
<? 
# SI NO SE HA PULSADO ENVIAR SE MUESTRA EL FORMULARIO
if(!isset($enviar))
{
?>
<script languaje="javascript">
function contar(form)

{
n = form.texto.value.length;
t = 200; 
    {
    form.escritos.value = n;
    form.restantes.value = (t-n);
    }
} 
function maximo(form) { 
var max=200; 
if (form.texto.value.length > max) { 
alert("Tu mensaje sobrepasa el numero de caracteres admitidos.Reducelo por favor!"); 
return false; 
   } 
else return true; 
} 
</script>

<form action="contacto.php" method="post" onsubmit="return maximo(this)"> 
<table border="0" align="center">
  <tr>
    <td colspan="2"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Contacto</font></div></td>
    </tr>
  <tr>
    <td><div align="right"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre :</font></strong></div></td>
    <td><input name="nombre"  id="nombre" class="campos" type="text" maxlength="20" >&nbsp;</td>
  </tr>
  <tr>
    <td><div align="right"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">E-Mail:</font></strong></div></td>
    <td><input name="email" id="email" class="campos" type="text" maxlength="40">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="right"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Asunto:</font></strong></div></td>
    <td><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">          <em>
    <input name="asunto"  id="asunto"  class="campos"type="text" maxlength="25">
&nbsp;</em></font></div></td>
  </tr>
  <tr>
    <td><div align="right"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Mensaje:</font></strong></div></td>
    <td rowspan="2"><textarea name="texto" id="texto" class="textok" cols="50" rows="15"  onKeyUp="contar(this.form)"></textarea>
	<br>
    <font face="arial" size="2">Escritos: </font><input type="text" ReadOnly name="escritos" size="2" value="0"> 
    <font face="arial" size="2">Restantes: </font><input type="text" ReadOnly name="restantes" size="2" value="200">
    &nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><br><br>&nbsp;</td>
    <td><input type="submit" id="enviar"  class="botones" name="enviar" value="Enviar">
      <input type="reset" id="borrar"  class="botones" name="borrar" value="Borrar"></td>
  </tr>
</table>  
<?
}
#SI YA SE PULSO ENVIAR SE PROCESA EL FORMULARIO 
else
{
include("func.php");//INCLUYO EL ARCHIVO CON LAS FUNCIONES 
if(trim($_POST["nombre"]) != "" && trim($_POST["email"]) != "" && trim($_POST["asunto"]) != "" && trim($_POST["texto"]) != ""){
$email = $_POST["email"] ;
# COMPROVAMOS QUE EL EMAIL INTRODUCIDO SEA VALIDO
if(!eregi("[0-9a-z_\-]+@[0-9a-z\-\.]+\.[a-z]{2,3}",$email)) {
echo "<center><font face=Verdana size=1><b>El email que has introducido <font face=Verdana size=1 color=336699>$email</font> no es valido.<br><a href=javascript:history.go(-1)>Volver</a>.</b></font></center>"; 
}
else {
include("config.php"); // SE INCLUYE EL ARCHIVO DE CONEXION
$nuevo= 0; 
$nombre= $_POST["nombre"]; // TOMAMOS EL NOMBRE DEL FORMULARIO.
$email= $_POST["email"]; // TOMAMOS EL EMAIL DEL FORMULARIO.(YA COMPROVADO)
$ip= obtener_ip();	// OBTENEMOS LA IP DEL REMITENTE
$asunto= $_POST["asunto"];	// TOMAMOS EL ASUNTO DEL FORMULARIO.
$mensaje= $_POST["texto"]; // TOMAMOS EL MENSAJE DEL FORMULARIO.
$fecha= date("d-m-Y"); // SE TOMA LA FECHA 
$cliks= 0; 
$sql = mysql_query("insert into contacto (nuevo, nombre, email, ip, asunto, mensaje, fecha, cliks) values ('$nuevo', '$nombre','$email','$ip','$asunto','$mensaje', '$fecha', '$cliks')")
or exit("<center><font face=Verdana size=1><b>A ocurrido un error al introducir los datos en la DB.</b></font></center>");
echo "<center><font face=Verdana size=1><b>Mensaje enviado correctamente. TU ip: <font face=Verdana size=1 color=336699>$ip</font> a sido guadada.</b></font></center>";
}
}
else
{
echo "<center><font face=Verdana size=1><b>Todos los campos son obligatorios.<br><a href=javascript:history.go(-1)>Volver</a>.</b></font></center>"; 
}
}

?>
