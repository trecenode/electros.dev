<?
$variable �ls -l�
echo $variable;
?>