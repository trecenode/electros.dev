<?
include("ulogin.php") ;
?>
<?
include("config.php") ;
$usuario = $nick ;
if($editar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}

$msg = quitar($msg) ;
mysql_query("update usuarios set msg='$msg' where nick='$usuario'") ;
header("location: msgread.php?editarconfirmacion=si") ;
}
mysql_close($conectar) ;
?>