<?
include("ulogin.php") ;
?>
<?
include("config.php") ;
$resp = mysql_query("select * from usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
?>
<right><table align="right" border="0" width="300" height="1" cellspacing="0" cellpadding="0" style="font-size: 8 pt">
  <tr>
    <td style="border-left: 1 solid #000000; border-bottom: 1 solid #000000" bgcolor="#D3A963"><b><font color="#000000">Mensajes
      del webmaster para t�</font></b></td>
  </tr>
  <tr>
    <td style="border-left: 1 solid #000000; border-bottom: 1 solid #000000"><? echo $datos[msg] ?></td>
  </tr>
</table></right>
<p>
<?
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>
