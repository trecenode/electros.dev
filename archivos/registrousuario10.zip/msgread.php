<?
include("ulogin.php") ;
?>
<?
include("config.php") ;
$resp = mysql_query("select * from usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($resp) ;
if($editarconfirmacion) {
echo "Mensaje enviado y guardado." ;
}
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
echo "<p class=titulo>Mensajes
<p><b>$nick</b> est� registrado desde el: $fecha

<form method=post action=msgenviar.php>
<b>* Nick:</b><br>
<input type=text name=nick maxlength=20 value=$nick class=form readonly><br>
<b>Mensaje</b><b>:</b><br>
<textarea name=msg cols=30 rows=5 class=form verdana>$datos[msg]</textarea><br><br>
<input type=submit name=editar value=Enviar class=form>
</form>
" ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>