<?
include("ulogin.php") ;
?>
<p><b>Mensajes</b>
<?
include("config.php") ;
if($mensaje == "nuevo") {
echo "
<script>
function revisar() {
if(formulario.destinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.mensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p><b>Nuevo</b>
<p>
<form name=formulario method=post action=mensajes.php onsubmit=\"return revisar()\">
<b>Destinatario:</b><br>
<input type=text name=destinatario maxlength=20><br>
<b>Mensaje:</b><br>
<textarea name=mensaje cols=30 rows=5></textarea><br><br>
<input type=submit name=enviar value=Enviar>
</form>
" ;
}
else {
echo "<p><a href=mensajes.php?mensaje=nuevo>Nuevo mensaje</a>" ;
}
if($responder) {
echo "
<script>
function revisar() {
if(formulario.destinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.mensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p><b>Responder</b>
<p>
<form name=formulario method=post action=mensajes.php onsubmit=\"return revisar()\">
<b>Destinatario:</b><br>
<input type=text name=destinatario maxlength=20 value=\"$responder\"><br>
<b>Mensaje:</b><br>
<textarea name=mensaje cols=30 rows=5></textarea><br><br>
<input type=submit name=enviar value=Enviar>
</form>
";
}
if($borrar) {
$usuario = $_COOKIE["unick"] ;
mysql_query("delete from mensajes where id='$borrar' and destinatario='$usuario'") ;
echo "<p>El mensaje ha sido borrado con �xito. Haz click <a href=mensajes.php>aqu�</a> para regresar." ;
}
else {
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() - 25200 ;
$destinatario = quitar($destinatario) ;
$mensaje = quitar($mensaje) ;
$resp = mysql_query("select id from usuarios where nick='$destinatario'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) == 0) {
echo "<p>Este usuario no existe en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.";
}
else {
$remitente = $_COOKIE["unick"] ;
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$destinatario','$remitente','$mensaje')") ;
echo "<p>El mensaje ha sido enviado con �xito. Haz click <a href=mensajes.php>aqu�</a> para regresar." ;
}
mysql_free_result($resp) ;
}
else {
$usuario = $_COOKIE["unick"] ;
$resp = mysql_query("select id from mensajes where destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 5 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from mensajes where destinatario='$usuario' order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mensajes." ; }
else {
echo "
<p><b>Total de mensajes:</b> $mensajes
<p>
" ;
while($datos = mysql_fetch_array($resp)) {
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano $hora" ;
echo "
<table width=100% border=0 cellpadding=1 cellspacing=0>
<tr>
<td><b>$datos[remitente]</b></td>
<td><div align=right><b>$fecha</b></div></td>
</tr>
<tr>
<td colspan=2>$datos[mensaje]</td>
</tr>
<tr>
<td colspan=2>
<div align=right>
<a href=\"mensajes.php?responder=$datos[remitente]\">Responder</a> |
<a href=\"mensajes.php?borrar=$datos[id]\">Borrar</a>
</div>
</td>
</tr>
</table><br>
" ;
if($datos[nuevo] == 0) {
mysql_query("update mensajes set nuevo='1' where id='$datos[id]'") ;
}
}
echo "
<p align=right><a href=mensajes.php?desde=$desde>Siguientes $mostrar mensajes</a>
" ;
}
mysql_free_result($resp) ;
}
}
mysql_close($conectar) ;
?>