<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Login a la Zona Privada</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?
// Comparamos a ver si son correctos
if ($usuario=="tuuser" && $password=="tupass")
{
$valido="si";
}
else
{
$valido="no";
}
?>
<html>
<head>
<title>Pagina privada</title>
<body>
<? if ($valido=="si")
{
?>
' A continuaci�n todo el contenido de nuestra pagina privada
<p>BIENVENIDO A LA PAGINA PRIVADA</p>
<? }
else
{
?>
<p>USUARIO O CONTRASE�A INCORRECTA</p>
<? } ?>
</body>
</html>
