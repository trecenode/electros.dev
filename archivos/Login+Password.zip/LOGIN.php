<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Login Zona PRIVADA</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form method="POST" action="password.php">
Usuario: <input type="text" name="usuario" size="10"><br>
Password: <input type="password" name="password" size="10"><br>
<input type="submit" value="Enviar" name="privado">
</body>
</html>
