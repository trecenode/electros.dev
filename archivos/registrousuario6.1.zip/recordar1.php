<form method="POST" action="recordar.php">
<p><a href="index.php">Principal</a> ><b> Recordar contrase�a</b></p>
  <p>&nbsp;&nbsp; Nick<br>
  &nbsp; <input type="text" name="nick" size="20" class="form"><br>
  &nbsp;&nbsp; Frase secreta:<br>
  &nbsp;
  <input type="text" name="reco" size="20" class="form" maxlength="100"></p>
  <p>&nbsp;&nbsp; <input type="submit" value="  Enviar  " name="B1" class="form"></p>
</form>