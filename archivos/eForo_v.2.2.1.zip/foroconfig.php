<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("config.php") ;

$url_a = false ; $url_b = false ; $url_c = false ;

// *************************************************
// *** Compatibilidad con "Registro de usuarios" ***
// *************************************************
// Si usas el script "Registro de usuarios" y quieres que eForo utilice la base de datos de los usuarios
// escribe aqu� el nombre de la tabla (si no sabes nada de esto d�jalo como est�)
$tabla_usuarios = "eforo_usuarios" ;

// **********************************************************************
// *** Integrar el foro dentro de tu web (Por el momento no funciona) ***
// **********************************************************************
// Si te interesa integrar el foro dentro de tu web y as� evitarte la molestia de modificar todos los enlaces del foro
// solamente debes poner aqu� la forma en que tienes los enlaces dentro de tu web, si lo quieres usar de la forma normal
// entonces d�jalo como est�
// Ejemplo de uso para enlaces del tipo index.php?id=pagina:
// $url_a = "index.php?id=" ;
// $url_b = "" ;
// $url_c = "&" ;
// Resultado final:     index.php?id=foro&foroid=10&temaid=10
$url_a = "" ;
$url_b = ".php" ;
$url_c = "?" ;

// ********** Fin de configuraci�n **********

$resp = mysql_query("select * from eforo_config") ;
$datos = mysql_fetch_array($resp) ;
$administrador = false ;
$administrador = $datos[administrador] ; $administrador_email = $datos[email] ; $titulo_foro = $datos[titulo] ;
$num_temas = $datos[temas] ; $num_mensajes = $datos[mensajes] ; $num_ultimos = $datos[ultimos] ;
$codigo = $datos[codigo] ; $caretos = $datos[caretos] ; $url = $datos[url] ;
$censurar = $datos[censurar] ; $estilo = $datos[estilo] ; $tam_largo = $datos[avatarlargo] ;
$tam_ancho = $datos[avatarancho] ; $tam_archivo = $datos[avatartamano] ; $max_privados = $datos[privados] ;
if($datos[htmlcab] || $datos[htmlpie]) {
function codificar($texto) {
$texto = stripslashes($texto) ;
return $texto ;
}
$htmlcab = codificar($datos[htmlcab]) ;
$htmlpie = codificar($datos[htmlpie]) ;
}
mysql_free_result($resp) ;
// Obtiene el rango del usuario que est� conectado en el foro
$usuario_rango = false ;
$resp = mysql_query("select rango from $tabla_usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$usuario_rango = $datos[rango] ;
mysql_free_result($resp) ;
if(!$_COOKIE[unick]) { $usuario_rango = 0 ; }
// Guarda todos los rangos en un array para hacer una s�la consulta y ahorrar recursos del servidor
$resp = mysql_query("select * from eforo_rangos order by rango asc") ;
while($datos = mysql_fetch_array($resp)) {
if($datos[minimo] == 0) { $rangos_fijos[$datos[rango]] = $datos[descripcion] ; }
if($datos[minimo] != 0 || $datos[rango] == 1) { $rangos_normales[$datos[minimo]] = $datos[descripcion] ; }
$rangos_todos[$datos[rango]] = $datos[descripcion] ;
}
mysql_free_result($resp) ;
// Comprobaci�n de datos insertados mediante la URL (foro.php?foroid=5&temaid=10&mensajeid=100)
$error = false ;
switch(true) {
case !ereg("^[0-9]*$",$foroid) :
$error = "Intento de ataque" ;
break ;
case !ereg("^[0-9]*$",$temaid) :
$error = "Intento de ataque" ;
break ;
case !ereg("^[0-9]*$",$mensajeid) :
$error = "Intento de ataque" ;
break ;
default :
if($foroid) {
$resp = mysql_query("select id from eforo_foros where id='$foroid'") ;
if(mysql_num_rows($resp) == 0) { $error .= "No existe el subforo seleccionado<br>" ; }
mysql_free_result($resp) ;
}
if($temaid) {
$resp = mysql_query("select id from eforo_mensajes where id='$temaid'") ;
if(mysql_num_rows($resp) == 0) { $error .= "No existe el tema seleccionado<br>" ; }
mysql_free_result($resp) ;
}
}
if($error) {
echo "
<style>
body {
font-family: verdana ;
font-size: 10pt ;
}
</style>
<p><b>Error al intentar acceder al foro</b>
<p>$error
<script>setTimeout(\"history.back()\",1800)</script>
" ;
exit ;
}
?>
