<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************
$dbhost = "localhost" ; // Com�nmente es "localhost" aunque puede ser una IP (32.64.128.255) o una URL (www.electros.tk)
$dbuser = "usuario" ; // Nombre de usuario de la base de datos
$dbpass = "12345" ; // Contrase�a de la base de datos
$db = "base_de_datos" ; // Nombre de la base de datos
if(!$conectar = @mysql_connect($dbhost,$dbuser,$dbpass)) {
$error = mysql_error() ;
echo "
<p><b>Error</b>
<p>No se pudo conectar a la base de datos debido a:
<p><b>$error</b>
" ;
exit ;
}
mysql_select_db($db,$conectar) ;
?>
