<?
// ******************************
// *** eForo v.2.2.1          ***
// *** Creado por: Electros   ***
// *** Web: www.electros.tk   ***
// ******************************

include("foroconfig.php") ;

// ****************************************
// *** Comprobar si hay mensajes nuevos ***
// ****************************************
if($_COOKIE[unick]) {
$fecha = time() ;
$limite = $fecha - 259200 ;
mysql_query("delete from eforo_recientes where fecha<'$limite'") ;
$resp = mysql_query("select conectado from $tabla_usuarios where nick='$_COOKIE[unick]'") ; $datos = mysql_fetch_array($resp) ; $conectado = $datos[conectado] ; mysql_free_result($resp) ;
$resp = mysql_query("select id from eforo_foros order by id asc") ;
for($a = 0 ; $datos = mysql_fetch_array($resp) ; $a++) { $foros[$a] = $datos[id] ; }
mysql_free_result($resp) ;
foreach($foros as $id) {
$resp = mysql_query("select * from eforo_mensajes where foro='$id' and foromostrar='1' order by ultimo desc limit 15") ;
while($datos = mysql_fetch_array($resp)) {
if($datos[ultimo] > $conectado) { mysql_query("insert into eforo_recientes (usuario,fecha,foro,mensaje) values ('$_COOKIE[unick]','$fecha','$id','$datos[id]')") ; }
}
}
$conectado = time() ;
mysql_query("update $tabla_usuarios set conectado='$conectado' where nick='$_COOKIE[unick]'") ;
}
// ********** Fin **********
?>
<html>
<head>
<?
if($temaid) {
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid' and foromostrar='1'") ;
$datos = mysql_fetch_array($resp) ;
if($datos[tema]) { $titulo_tema = $datos[tema] ; }
mysql_free_result($resp) ;
}
?>
<title><?=$titulo_foro?><? if($titulo_tema) { echo " :: $titulo_tema" ; } ?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?=$htmlcab?>
<?
// *******************************
// *** Inicio de configuraci�n ***
// *******************************
// En esta parte podr�s modificar varias opciones del eForo como la forma en que se muestra la fecha, el eCodigo que es el
// c�digo especial como [b]negrita[/b], agregar m�s caretos y palabras censuradas

// Muestra la fecha en el formato 1 Ene 2003 12:00 AM
function fecha1($fecha) {
$tiempo_ultimo = time() - $fecha ;
switch (true) {
case $tiempo_ultimo > 0 && $tiempo_ultimo < 3600 :
$minutos = round($tiempo_ultimo / 60) ; if($minutos == 0 || $minutos == 1) { $fecha = "Hace 1 minuto" ; } else { $fecha = "Hace $minutos minutos" ; }
break ;
case $tiempo_ultimo >= 3600 && $tiempo_ultimo < 86400 :
$horas = round($tiempo_ultimo / 3600) ; if($horas == 1) { $fecha = "Hace 1 hora" ; } else { $fecha = "Hace $horas horas" ; }
break ;
default :
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ; $fecha = "$diames $mesesano[$mesano] $ano $hora" ;
}
return $fecha ;
}

// Muestra la fecha en el formato Lunes 1 de Enero del 2003 12:00 AM
function fecha2($fecha) {
$semana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ; $mes = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ; $diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ; $fecha = "$semana[$diasemana] $diames de $mes[$mesano] del $ano $hora" ;
return $fecha ;
}

// Sustituye el c�digo especial por su respectivo c�digo HTML
if($codigo == "ON") {
function codigo($texto) {
// *** Colorear el c�digo ***
if(strstr($texto,"[codigo]")) {
$partes = explode("[codigo]",$texto) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = str_replace("&lt;","<",$codigo) ; $codigo = str_replace("&gt;",">",$codigo) ; $codigo = str_replace("&quot;","\"",$codigo) ; $codigo = str_replace("&amp;","&",$codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"codigo\"><tr><td>$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$texto = implode("",$partes) ;
}
// *** Fin ***
$texto = str_replace("[b]","<b>",$texto) ; $texto = str_replace("[/b]","</b>",$texto) ;
$texto = str_replace("[img]","<img src=\"",$texto) ; $texto = str_replace("[/img]","\" border=\"0\">",$texto) ;
$texto = preg_replace("/\[color=((#)?[0-9a-z]+)\]/i","<font color=\"\\1\">",$texto) ; $texto = str_replace("[/color]","</font>",$texto) ;
$texto = preg_replace("/\[url\](www\..+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\1</a>",$texto) ;
$texto = preg_replace("/\[url\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>",$texto) ;
$texto = preg_replace("/\[url=(www\..+)\](.+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\2</a>",$texto) ;
$texto = preg_replace("/\[url=(.+)\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\2</a>",$texto) ;
$texto = str_replace("\r\n","<br>",$texto) ;
return $texto ;
}
}

// Pone caretos en los mensajes
if($caretos == "ON") {
function caretos($texto) {
// --> Inicio caretos
$caretos = array(
":D"   => "alegre.gif",
":P"   => "burla.gif",
":(1"  => "demonio.gif",
":?"   => "duda.gif",
";)"   => "guino.gif",
":lol" => "lol.gif",
":|"   => "neutral.gif",
":-)"  => "sonrisa.gif",
":O"   => "sorprendido.gif",
":8"   => "asustado.gif",
":S"   => "confundido.gif",
":(2"  => "demonio2.gif",
":-("  => "enojado.gif",
":'("  => "llorar.gif",
":M"   => "moda.gif",
":)"   => "risa.gif",
":R"   => "sonrojado.gif",
":("   => "triste.gif",
) ;
// --> Fin caretos
foreach($caretos as $a => $b) {
$texto = str_replace($a,"<img src=\"eforo_imagenes/caretos/$b\" width=\"15\" height=\"15\">",$texto) ;
}
return $texto ;
}
}

// Transforma URLs en enlaces
if($url == "ON") {
function url($texto) {
$texto = preg_replace("/(?<!')(?<!<a href=\")(?<!<img src=\")(http|ftp)(s)?:\/\/[^,<\'\"\s]+/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$texto) ;
return $texto ;
}
}

// Censura palabras
if($censurar == "ON") {
function censurar($texto) {
// --> Inicio palabras
$palabras = array(
"insulto1" => "*****",
"insulto2" => "*****",
"insulto3" => "*****"
) ;
// --> Fin palabras
foreach($palabras as $a => $b) {
$texto = str_replace($a,$b,$texto) ;
}
return $texto ;
}
}

// ****************************
// *** Fin de configuraci�n ***
// ****************************
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
  <tr>
    <td colspan="2" class="tabla_mensaje">
      <?
      if($temaid) { echo "<p class=\"tema\"><a href=\"foro.php?foroid=$foroid&temaid=$temaid\">� $titulo_tema</a><p>" ; }
      if($foroid) {
      $resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
      $datos = mysql_fetch_array($resp) ;
      $foro = " � <a href=\"foro.php?foroid=$foroid\">$datos[foro]</a>" ;
      mysql_free_result($resp) ;
      }
      ?>
      <p><a href="foro.php">Indice del foro</a><?=$foro?>
      <p>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <?
          if($foroid) {
					if($temaid) { if($pag) { $responder = "&pag=$pag" ; } $responder = " <b>|</b> <a href=\"fororesponder.php?foroid=$foroid&temaid=$temaid$responder\">Responder</a>" ; }
          ?>
          <td><a href="foronuevo.php?foroid=<?=$foroid?>">Nuevo tema</a><?=$responder?></td>
          <?
					}
          $resp = mysql_query("select id from eforo_privados where nuevo='0' and destinatario='$_COOKIE[unick]'") ;
          $total = mysql_num_rows($resp) ;
          if($total == 0) {
          $mensajes = "<a href=\"foroprivados.php\">Mensajes</a>" ;
          }
          else {
          ?>
          <script>
          function aviso() {
          texto = document.getElementsByTagName('blink') ;
          for(a = 0 ; a < texto.length ; a++) {
          if(texto[a].style.visibility == 'hidden')
          texto[a].style.visibility = 'visible' ;
          else
          texto[a].style.visibility = 'hidden' ;
          }
          setTimeout('aviso()',100) ;
          }
          onload = aviso ;
          </script>
          <?
          $mensajes = "<a href=\"foroprivados.php\"><blink>Mensajes nuevos ($total)</blink></a>" ;
          }
          mysql_free_result($resp) ;
          if(!$_COOKIE[unick]) {
          $usuario = "<a href=\"fororegistrar.php\">Nuevo usuario</a> <b>|</b> <a href=\"forocontrasena.php\">Perd� mi contrase�a</a>" ;
          }
          else {
          $usuario = "$mensajes <b>|</b> <a href=\"foroperfil.php\">Perfil</a> <b>|</b> <a href=\"forosalir.php\">Salir</a>" ;
          }
          ?>
          <td><div align="right"><?=$usuario?></div></td>
        </tr>
      </table>
      <?
      if(!$_COOKIE[unick]) {
      ?>
      <br>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>
            <form method="post" action="foroentrar.php">
              <div align="right">
              <b>Nick:</b>
              <input type="text" name="nick" size="10" maxlength="20" class="form">
              <b>Contrase�a:</b>
              <input type="password" name="contrasena" size="10" maxlength="20" class="form">
              <input type="submit" name="entrar" value="Entrar" class="form">
              </div>
            </td></form>
        </tr>
      </table>
      <?
      }
      ?>
    </td>
  </tr>
  <tr>
    <?
    $resp = mysql_query("select id from $tabla_usuarios") ;
    $total = mysql_num_rows($resp) ;
    mysql_free_result($resp) ;
    $resp = mysql_query("select nick from $tabla_usuarios order by id desc limit 1") ;
    $datos = mysql_fetch_array($resp) ;
    $ultimo = $datos[nick] ;
    mysql_free_result($resp) ;
    include("foroenlinea.php") ;
    ?>
    <td width="50%" class="tabla_mensaje" valign="top">Nos visitan <b><?=$usuarios?></b> usuarios: <b><?=$anonimos?></b> anonimos y <b><?=$registrados?></b> registrados<br><br><?=$renlinea?></td>
    <td width="50%" class="tabla_mensaje" valign="top">Total de usuarios registrados en el foro: <b><?=$total?></b><br>Ultimo usuario registrado: <a href="forousuarios.php?u=<?=$ultimo?>"><?=$ultimo?></a><br><a href="forousuarios.php">Ver usuarios</a></td>
  </tr>
</table><br>
<?
switch(true) {
// *****************************************************************************
// *** Muestra los subforos ****************************************************
// *****************************************************************************
case !$foroid && !$temaid :
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <tr>
    <td colspan="2" class="tabla_titulo"><div class="t1" align="center">Categor�a</div></td>
    <td class="tabla_titulo"><div class="t1" align="center">Tem</div></td>
    <td class="tabla_titulo"><div class="t1" align="center">Men</div></td>
    <td class="tabla_titulo"><div class="t1" align="center">Ultimo mensaje</div></td>
  </tr>
  <?
  $resp = mysql_query("select * from eforo_categorias order by orden asc") ;
  while($datos = mysql_fetch_array($resp)) {
  ?>
  <tr>
    <td colspan="5" class="tabla_subtitulo"><div class="t1"><?=$datos[categoria]?></div></td>
  </tr>
  <?
  $resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
  while($datos2 = mysql_fetch_array($resp2)) {
  $iluminado = "foco_off_grande.gif" ;
  // Si hay mensajes recientes se muestran iluminados
  if($_COOKIE[unick]) {
  $resp3 = mysql_query("select * from eforo_recientes where usuario='$_COOKIE[unick]' and foro='$datos2[id]'") ;
  if(mysql_num_rows($resp3) != 0) { $iluminado = "foco_on_grande.gif" ; }
  mysql_free_result($resp3) ;
  }
  // Obtener el ultimo mensaje enviado
  $resp3 = mysql_query("select id,forotema,fecha,usuario from eforo_mensajes where foro='$datos2[id]' order by id desc limit 1") ;
  if(mysql_num_rows($resp3) != 0) {
  $datos3 = mysql_fetch_array($resp3) ;
  if(!$datos3[usuario]) { $usuario = "No registrad@" ; } else { $usuario = "<b>$datos3[usuario]</b>" ; }
  mysql_free_result($resp3) ;
  $fecha = fecha1($datos3[fecha]) ;
  $ultimo = "$usuario <a href=\"foro.php?foroid=$datos2[id]&temaid=$datos3[forotema]#$datos3[id]\"><img src=\"eforo_imagenes/ultimo.gif\" width=\"18\" height=\"9\" border=\"0\"></a><br><span style=\"font-size: 7pt\">$fecha</span>" ;
  }
  else {
  $ultimo ="Ninguno" ;
  }
  ?>
  <tr>
    <td width="10%" class="tabla_mensaje"><div align="center"><img src="eforo_imagenes/<?=$iluminado?>" width="36" height="35" border="0"></div></td>
    <td width="50%" class="tabla_mensaje"><a href="foro.php?foroid=<?=$datos2[id]?>"><?=$datos2[foro]?></a><br><?=$datos2[descripcion]?></td>
    <td width="10%" class="tabla_mensaje"><div align="center"><?=$datos2[temas]?></div></td>
    <td width="10%" class="tabla_mensaje"><div align="center"><?=$datos2[mensajes]?></div></td>
    <td width="20%" class="tabla_mensaje"><div align="center"><?=$ultimo?></div></td>
  </tr>
  <?
  }
  mysql_free_result($resp2) ;
  }
  ?>
</table>
<?
break ;
// *****************************************************************************
// *** Muestra los temas *******************************************************
// *****************************************************************************
case $foroid && !$temaid :
$resp = mysql_query("select leer from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
if($usuario_rango < $datos[leer]) {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <tr>
    <td class="tabla_titulo"><div align="center" class="t1">Nivel m�nimo insuficiente</div></td>
  </tr>
  <tr>
    <td class="tabla_mensaje"><div align="center">No tienes el nivel requerido para poder entrar a este subforo.</div></td>
  </tr>
</table><br>
<?
}
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <?
  $resp = mysql_query("select id from eforo_mensajes where foro='$foroid' and foromostrar='1'") ;
  $total = mysql_num_rows($resp) ;
  mysql_free_result($resp) ;
  if($total == 0) {
  echo "
  <tr>
    <td class=\"tabla_mensaje\"><div class=\"tema\" align=\"center\">No se encontraron mensajes.</div></td>
  </tr>
  " ;
  }
  else {
  // *** Paginado ***
  $mostrar = $num_temas ;
  if(!$pag) { $pag = 1 ; }
  $max_paginas = 9 ;
  $mensajes = $total ;
  $n = 0 ;
  for($a = 1 ; $mensajes > 0 ; $a++) {
  if($a != $pag) { $pagina = false ; } else { $pagina = " style=\"color: #c0c0c0\"" ; }
  if($a == 1) { $paginas .= "P�ginas: <a href=\"foro.php?foroid=$foroid&pag=$a\"$pagina>$a</a>" ; } else { $paginas .= ", <a href=\"foro.php?foroid=$foroid&pag=$a\"$pagina>$a</a>" ; }
  $mensajes = $mensajes - $mostrar ; $n++ ;
  }
  if(round($total/$mostrar) > $max_paginas) {
  $paginas = substr($paginas,0,strpos($paginas,"$max_paginas</a>") + 5) ;
  if($pag > $max_paginas && $pag < $n) { $paginas .= ", <a href=\"foro.php?foroid=$foroid&pag=$pag\" style=\"color: #c0c0c0\">$pag</a>" ; }
  if($pag != $n) { $paginas .= " ... <a href=\"foro.php?foroid=$foroid&pag=$n\">$n</a>" ; } else { $paginas .= " ... <a href=\"foro.php?foroid=$foroid&pag=$n\" style=\"color: #c0c0c0\">$n</a>" ; }
  }
  if($pag > 1) { $anterior = $pag - 1 ; $paginas .= " <a href=\"foro.php?foroid=$foroid&pag=$anterior\"><img src=\"eforo_imagenes/anterior.gif\" width=\"12\" height=\"12\" border=\"0\" alt=\"Anterior\" align=\"absmiddle\"></a>" ; }
  if($pag < $n) { $siguiente = $pag + 1 ; $paginas .= " <a href=\"foro.php?foroid=$foroid&pag=$siguiente\"><img src=\"eforo_imagenes/siguiente.gif\" width=\"12\" height=\"12\" border=\"0\" alt=\"Siguiente\" align=\"absmiddle\"></a>" ; }
  $desde = $pag * $mostrar - $mostrar ;
  // *** Fin ***
  $resp = mysql_query("select * from eforo_mensajes where foro='$foroid' and foromostrar='1' order by ultimo desc limit $desde,$mostrar") ;
  ?>
  <tr>
    <td class="tabla_titulo">&nbsp;</td>
    <td class="tabla_titulo"><div align="center" class="t1">Tema</div></td>
    <td class="tabla_titulo"><div align="center" class="t1">Vis</div></td>
    <td class="tabla_titulo"><div align="center" class="t1">Res</div></td>
    <td class="tabla_titulo"><div align="center" class="t1">Autor</div></td>
    <td class="tabla_titulo"><div align="center" class="t1">Ultimo</div></td>
  </tr>
  <tr>
    <td colspan="6" class="tabla_mensaje">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>Total de temas: <b><?=$total?></b></td>
          <td><div align="right"><?=$paginas?></div></td>
        </tr>
      </table>
    </td>
  </tr>
  <?
  while($datos = mysql_fetch_array($resp)) {
  $iluminado = "foco_off.gif" ;
  if($_COOKIE[unick]) {
  $resp2 = mysql_query("select * from eforo_recientes where usuario='$_COOKIE[unick]' and mensaje='$datos[id]'") ;
  if(mysql_num_rows($resp2) != 0) { $iluminado = "foco_on.gif" ; }
  mysql_free_result($resp2) ;
  }
  $resp2 = mysql_query("select id,fecha,usuario from eforo_mensajes where forotema='$datos[id]' order by id desc limit 1") ;
  $datos2 = mysql_fetch_array($resp2) ;
  if($datos[usuario]) { $datos[usuario] = "<b>$datos[usuario]</b>" ; } else { $datos[usuario] = "No registrad@" ; }
  if($datos2[usuario]) { $datos2[usuario] = "<b>$datos2[usuario]</b>" ; } else { $datos2[usuario] = "No registrad@" ; }
  $primero = fecha1($datos[fecha]) ;
  $ultimo = fecha1($datos2[fecha]) ;
  ?>
  <tr>
    <td class="tabla_mensaje"><div align="center"><img src="eforo_imagenes/<?=$iluminado?>" width="22" height="23" border="0"></div></td>
    <td class="tabla_mensaje"><a href="foro.php?foroid=<?=$foroid?>&temaid=<?=$datos[id]?>">� <?=$datos[tema]?></a></td>
    <td class="tabla_mensaje"><div align="center"><?=$datos[visitas]?></div></td>
    <td class="tabla_mensaje"><div align="center"><?=$datos[mensajes]?></div></td>
    <td class="tabla_mensaje"><div align="center"><?=$datos[usuario]?><br><span style="font-size: 7pt"><?=$primero?></span></div></td>
    <td class="tabla_mensaje"><div align="center"><?=$datos2[usuario]?><br><span style="font-size: 7pt"><?=$ultimo?></span></div></td>
  </tr>
  <?
  mysql_free_result($resp2) ;
  }
  ?>
  <tr>
    <td colspan="6" class="tabla_mensaje">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>Total de temas: <b><?=$total?></b></td>
          <td><div align="right"><?=$paginas?></div></td>
        </tr>
      </table>
    </td>
  </tr>
  <?
  mysql_free_result($resp) ;
  }
  ?>
</table><br>
<?
}
?>
<table width="100%" border="0" cellpadding="3" cellspacing="0">
  <tr>
    <td width="50%" valign="top" class="tabla_mensaje">
		<img src="eforo_imagenes/foco_on.gif" width="22" height="23" border="0" alt="" align="absmiddle"> <b>Mensajes sin leer</b><br><br>
		<img src="eforo_imagenes/foco_off.gif" width="22" height="23" border="0" alt="" align="absmiddle"> <b>Mensajes le�dos</b>
	</td>
	<td width="50%" valign="top" class="tabla_mensaje">
		<?
		$puedes = false ;
		$nopuedes = false ;
		$resp = mysql_query("select id from eforo_moderadores where foro='$foroid' and moderador='$_COOKIE[unick]'") ;
		if(mysql_num_rows($resp) != 0 || $_COOKIE[unick] == $administrador) { $moderador = true ; }
		mysql_free_result($resp) ;
		$resp = mysql_query("select leer,nuevo,responder,editar,borrar from eforo_foros where id='$foroid' limit 1") ;
		$datos = mysql_fetch_array($resp) ;
		if($datos[leer] <= $usuario_rango) { $puedes .= "Leer mensajes<br>" ; } else { $nopuedes .= "Leer mensajes<br>" ; }
		if($datos[nuevo] <= $usuario_rango) { $puedes .= "Escribir nuevos temas<br>" ; } else { $nopuedes .= "Escribir nuevos temas<br>" ; }
		if($datos[responder] <= $usuario_rango) { $puedes .= "Responder temas<br>" ; } else { $nopuedes .= "Responder temas<br>" ; }
		if($datos[editar] <= $usuario_rango) { $puedes .= "Editar mensajes<br>" ; } else { $nopuedes .= "Editar mensajes<br>" ; }
		if($datos[borrar] <= $usuario_rango) { $puedes .= "Borrar mensajes<br>" ; } else { $nopuedes .= "Borrar mensajes<br>" ; }
		if($moderador) { $puedes .= "Moderar el foro" ; }
		mysql_free_result($resp) ;
		?>
		<? if($puedes) { echo "<b>Puedes:</b><br>$puedes" ; } ?>
		<? if($nopuedes) { echo "<b>No puedes:</b><br>$nopuedes" ; } ?>
	</td>
</tr>
</table>
<?
break ;
// *****************************************************************************
// *** Muestra el tema junto con todos los mensajes ****************************
// *****************************************************************************
case $foroid && $temaid :
$resp = mysql_query("select leer from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
if($usuario_rango < $datos[leer]) {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <tr>
    <td class="tabla_titulo"><div align="center" class="t1">Nivel m�nimo insuficiente</div></td>
  </tr>
  <tr>
    <td class="tabla_mensaje"><div align="center">No tienes el nivel requerido para poder entrar a este subforo.</div></td>
  </tr>
</table>
<?
}
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <?
  // Se guardan a todos los usuarios en l�nea en un array
  $resp = mysql_query("select * from eforo_enlinea where usuario!=''") ;
  for($a = 0 ; $datos = mysql_fetch_array($resp) ; $a++) {
  $uenlinea[$a] = $datos[usuario] ;
  }
  // ********** Fin **********
  mysql_free_result($resp) ;	
	if($_COOKIE[unick]) { mysql_query("delete from eforo_recientes where usuario='$_COOKIE[unick]' and mensaje='$temaid'") ; }	
  mysql_query("update eforo_mensajes set visitas=visitas+1 where id='$temaid'") ;
  $resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
  $total = mysql_num_rows($resp) ;
  mysql_free_result($resp) ;
  // ***** Paginado *****
  $mostrar = $num_mensajes ;
  if(!$pag) { $pag = 1 ; }
  $max_paginas = 9 ;
  $mensajes = $total ;
  $n = 0 ;
  for($a = 1 ; $mensajes > 0 ; $a++) {
  if($a != $pag) { $pagina = false ; } else { $pagina = " style=\"color: #c0c0c0\"" ; }
  if($a == 1) {
  $paginas .= "P�ginas: <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$a\"$pagina>$a</a>" ;
  }
  else {
  $paginas .= ", <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$a\"$pagina>$a</a>" ;
  }
  $mensajes = $mensajes - $mostrar ; $n++ ;
  }
  if(round($total/$mostrar) > $max_paginas) {
  $paginas = substr($paginas,0,strpos($paginas,"$max_paginas</a>") + 5) ;
  if($pag > $max_paginas && $pag < $n) { $paginas .= ", <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$pag\" style=\"color: #c0c0c0\">$pag</a>" ; }
  if($pag != $n) { $paginas .= " ... <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$n\">$n</a>" ; } else { $paginas .= " ... <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$n\" style=\"color: #c0c0c0\">$n</a>" ; }
  }
  if($pag > 1) { $anterior = $pag - 1 ; $paginas .= " <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$anterior\"><img src=\"eforo_imagenes/anterior.gif\" width=\"12\" height=\"12\" border=\"0\" alt=\"Anterior\" align=\"absmiddle\"></a>" ; }
  if($pag < $n) { $siguiente = $pag + 1 ; $paginas .= " <a href=\"foro.php?foroid=$foroid&temaid=$temaid&pag=$siguiente\"><img src=\"eforo_imagenes/siguiente.gif\" width=\"12\" height=\"12\" border=\"0\" alt=\"Siguiente\" align=\"absmiddle\"></a>" ; }
  $total = $total - 1 ;
  $desde = $pag * $mostrar - $mostrar ;
  // ***** Fin *****
  $resp = mysql_query("select * from eforo_mensajes where forotema='$temaid' order by id asc limit $desde,$mostrar") ;
  ?>
  <tr>
    <td colspan="2" class="tabla_mensaje">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>Respuestas al tema: <b><?=$total?></b></td>
          <td><div align="right"><?=$paginas?></div></td>
        </tr>
      </table>
    </td>
  </tr>
  <script>
  function borrar(foroid,temaid,mensajeid,borrar) {
  if(borrar == 'tema') { mensaje = 'tema completo junto con todos los mensajes' ; } else { mensaje = 'mensaje' ; }
  if(confirm('Deseas borrar el '+mensaje)) { location = 'foroborrar.php?foroid='+foroid+'&temaid='+temaid+'&mensajeid='+mensajeid+'&borrar='+borrar ; }
  }
  </script>
  <?
  $conectado = false ;
	$resp2 = mysql_query("select * from eforo_enlinea where usuario!=''") ;
	for($a = 0 ; $datos2 = mysql_fetch_array($resp2) ; $a++) {
	$u_conectado[$a] = $datos2[usuario] ;
	}
	mysql_free_result($resp2) ;
  while($datos = mysql_fetch_array($resp)) {
  $fecha = fecha2($datos[fecha]) ;
  $resp2 = mysql_query("select id,rango,mensajes,firma,avatar from $tabla_usuarios where nick='$datos[usuario]'") ; $datos2 = mysql_fetch_array($resp2) ;
  $u_id = $datos2[id] ;
	$u_rango = $datos2[rango] ;
	$u_mensajes = $datos2[mensajes] ;
	$u_firma = $datos2[firma] ;
	$u_avatar = $datos2[avatar] ;
  mysql_free_result($resp2) ;
	if($datos[usuario]) { $usuario = "<a href=\"forousuarios.php?u=$u_id\">$datos[usuario]</a>" ; } else { $usuario = "No registrad@" ; }
	// Si el usuario tiene un rango fijo se ignora el ascenso de rango por n�mero de mensajes
	$subir_de_rango = true ;
	if($u_rango != 1) {
	foreach($rangos_fijos as $a => $b) {
	if($a == $u_rango) { $subir_de_rango = false ; $rango = "<br><span style=\"font-size: 7pt\">$b</span>" ; }
	}
	}
	if($subir_de_rango) {
	foreach($rangos_normales as $a => $b) {
	if($u_mensajes >= $a) { $rango = "<br><span style=\"font-size: 7pt\">$b</span>" ; }
	}
	}
	if($u_avatar) {
	$avatar = "<br><br><img src=\"eforo_imagenes/avatares/$u_id.$u_avatar\">" ;
	}
	else {
	$avatar = false ;
	}
	$conectado = "Desconectad@" ;
	if($u_conectado) {
	foreach($u_conectado as $a) {
	if($a == $datos[usuario]) { $conectado = "En l�ne@" ; }
	}
	}
	$mensajes = $u_mensajes ;
	if($codigo == "ON" && $datos[codigo] == 1) { $datos[mensaje] = codigo($datos[mensaje]) ; }
	if($caretos == "ON" && $datos[caretos] == 1) { $datos[mensaje] = caretos($datos[mensaje]) ; }
	if($url == "ON" && $datos[url] == 1) { $datos[mensaje] = url($datos[mensaje]) ; }
	if($censurar == "ON") { $datos[mensaje] = censurar($datos[mensaje]) ; }
	$firma = false ;
	if($datos[firma] == 1) {
	$firma = "<hr width=\"100\" color=\"#757575\">$u_firma" ;
	if($codigo == "ON") { $firma = codigo($firma) ; }
	}
	$editado = false ;
	if($datos[fecha] != $datos[editado]) { $editado = "<br><br><b>Editado el ".fecha2($datos[editado])."</b>" ; }
	$datos[mensaje] = str_replace("\r\n","<br>",$datos[mensaje]) ;
	if($datos[foromostrar] == 1) { $borrar = "tema" ; } else { $borrar = "mensaje" ; }
  ?>
  <tr>
    <td width="25%" valign="top" class="tabla_mensaje">
			<?=$usuario?>
			<?=$rango?>
			<?=$avatar?>
			<br><br>Estado: <b><?=$conectado?></b>
			<br>Mensajes: <b><?=$mensajes?></b>
		</td>
    <td width="75%" valign="top" class="tabla_mensaje">
      <a name="<?=$datos[id]?>"></a>
      <b>Tema:</b> <?=$datos[tema]?><br>
      <hr color="#757575"><br>
      <?="$datos[mensaje]$firma$editado"?>
    </td>
  </tr>
  <tr>
    <td class="tabla_mensaje"><div style="font-size: 7pt"><?=$fecha?></div></td>
    <td class="tabla_mensaje">
      <a href="foroeditar.php?foroid=<?=$foroid?>&temaid=<?=$temaid?>&mensajeid=<?=$datos[id]?><?if($pag) { echo"&pag=$pag" ; }?>">Editar</a> | <a href="javascript:borrar('<?=$foroid?>','<?=$temaid?>','<?=$datos[id]?>','<?=$borrar?>')">Borrar</a></td>
  </tr>
  <?
  }
  ?>
  <tr>
    <td colspan="2" class="tabla_mensaje">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>Respuestas al tema: <b><?=$total?></b></td>
          <td><div align="right"><?=$paginas?></div></td>
        </tr>
      </table>
    </td>
  </tr>
  <?
  mysql_free_result($resp) ;
  ?>
</table>
<?
}
}
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
