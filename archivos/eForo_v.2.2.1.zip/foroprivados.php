<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
// *******************************
// *** Comprobaci�n de usuario ***
// *******************************
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if(md5(md5($datos[contrasena])) != $_COOKIE[ucontrasena]) { header("location: foroentrar.php") ; exit ; }
mysql_free_result($resp) ;
// ************* Fin *************
?>
<html>
<head>
<title><?=$titulo_foro?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
echo $htmlcab ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Mensajes privados</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<p>Este es tu buz�n de mensajes privados, para eliminar mensajes selecciona las casillas correspondientes y luego haz click en Borrar.
<?
$maximo = $max_privados ;
$resp = mysql_query("select id from eforo_privados where destinatario='$_COOKIE[unick]'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$porcentaje = round($mensajes/$maximo,2) * 100 ;
if($mensajes < ($maximo - 5)) {
$barra = "#008000" ;
}
else {
$barra = "#800000" ;
$aviso = "<b><span style=\"color: #800000\">Atenci�n:</span></b> Te est�s acercando al l�mite de almacenamiento, recuerda tener despejada la bandeja para poder seguir recibiendo mensajes." ;
}
if($porcentaje == 100) {
$aviso = "<b><span style=\"color: #800000\">Atenci�n:</span></b> Tu bandeja se encuentra al m�ximo de almacenamiento, no podr�s recibir mensajes hasta que te encuentres abajo del l�mite." ;
}
?>
<p>Espacio utilizado: <b><?=$mensajes?>/<?=$maximo?> <?=$porcentaje?>%</b>
<table width="100" border="0" cellpadding="1" cellspacing="0" style="border-color: #000000 ; border-width: 1 ; border-style: solid">
<tr>
<td>
<table width="<?=$porcentaje?>%" border="0" cellpadding="0" style="background: <?=$barra?>">
<tr>
<td></td>
</tr>
</table>
</td>
</tr>
</table>
<p><?=$aviso?>
<?
if($mensaje || $responder) {
?>
<script>
maximo = 1024 ;
function caracteres() {
if(formulario.mensaje.value.length > maximo)
formulario.mensaje.value = formulario.mensaje.value.substring(0,maximo) ;
else
formulario.contador.value = maximo - formulario.mensaje.value.length ; 
}
onload = caracteres ;
</script>
<p class="t1">Escribir mensaje
<p>
<form name="formulario" method="post" action="foroprivados.php" onsubmit="return revisar()">
<b>Destinatario:</b><br>
<input type="text" name="destinatario" maxlength="20" value="<?=$responder?>" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="30" rows="5" onkeyup="caracteres()" class="form"></textarea><br>
<input type="text" name="contador" size="3" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
else {
echo "<p><a href=\"foroprivados.php?mensaje=si\">� Nuevo mensaje</a>" ;
}
if($borrar) {
foreach($POST as $a => $b) {
if(ereg("^mensaje",$a)) {
mysql_query("delete from eforo_privados where id='$b' and destinatario='$_COOKIE[unick]'") ;
}
}
echo "<p>Los mensajes han sido borrados con �xito. Haz click <a href=\"foroprivados.php\">aqu�</a> para regresar." ;
}
else {
if($enviar) {
function quitar($a) {
$a = trim($a) ;
$a = htmlspecialchars($a) ;
return $a ;
}
$fecha = time() - 25200 ;
$destinatario = quitar($destinatario) ;
$mensaje = quitar($mensaje) ;
$resp = mysql_query("select id from $tabla_usuarios where nick='$destinatario'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) == 0) {
echo "<p>Este usuario no existe en la base de datos. Haz click <a href=\"javascript:history.back()\">aqu�</a> para regresar.";
}
else {
$resp = mysql_query("select id from eforo_privados where destinatario='$destinatario'") ;
$mensajes = mysql_num_rows($resp) ;
if($mensajes < $maximo) {
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$destinatario','$_COOKIE[unick]','$mensaje')") ;
echo "<p>El mensaje ha sido enviado con �xito. Haz click <a href=\"foroprivados.php\">aqu�</a> para regresar." ;
}
else {
echo "
<p>La bandeja de este usuario ha superado el l�mite.
<p>No se pudo entregar el siguiente mensaje:
<p>$mensaje
" ;
}
}
mysql_free_result($resp) ;
} // Fin Enviar
else {
$usuario = $_COOKIE[unick] ;
$resp = mysql_query("select id from eforo_privados where destinatario='$usuario'") ;
$total = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 10 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_privados where destinatario='$usuario' order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mensajes." ; }
else {
?>
<p><b>Total de mensajes:</b> <?=$total?>
<p>
<form method="post" action="foroprivados.php">
<input type="submit" name="borrar" value="Borrar" class="form"><br><br>
<?
while($datos = mysql_fetch_array($resp)) {
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano $hora" ;
$datos[mensaje] = str_replace("\r\n","<br>",$datos[mensaje]) ;
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="tabla_subtitulo">
<tr>
<td width="10%"><b><?=$datos[remitente]?></b></td>
<td width="90%"><div align="right"><b><?=$fecha?></b></div></td>
</tr>
<tr>
<td valign="top"><div align="center"><input type="checkbox" name="mensaje<?=$datos[id]?>" value="<?=$datos[id]?>"></div></td>
<td valign="top"><?=$datos[mensaje]?></td>
</tr>
<tr>
<td colspan="2">
<div align="right">
<a href="foroprivados.php?responder=<?=$datos[remitente]?>">� Responder</a>
</div>
</td>
</tr>
</table><br>
<?
if($datos[nuevo] == 0) {
mysql_query("update mensajes set nuevo='1' where id='$datos[id]'") ;
}
}
?>
<input type="submit" name="borrar" value="Borrar" class="form">
</form>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=?ver=scripts>Anteriores $mostrar scripts</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=?ver=scripts&desde=$anteriores>Anteriores $mostrar scripts</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $total) {
echo "<a href=?ver=scripts&desde=$desde>Siguientes $mostrar scripts</a>" ;
}
}
mysql_free_result($resp) ;
}
}
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
<?
echo $htmlpie ;
?>
</body>
</html>
