<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><?=$titulo_foro?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
echo $htmlcab ;
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
<tr>
<td class="tabla_mensaje">
<?
// *******************************
// *** Comprobaci�n de usuario ***
// *******************************
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if(md5(md5($datos[contrasena])) != $_COOKIE[ucontrasena]) { echo "<p class=\"tema\">S�lo los usuarios registrados pueden borrar sus mensajes.<p><a href=\"javascript:history.back()\">� Regresar</a>" ; exit ; }
mysql_free_result($resp) ;
// ************* Fin *************

$permitir = false ;
$resp = mysql_query("select id from eforo_moderadores where foro='$foroid' and moderador='$_COOKIE[unick]'") ;
if(mysql_num_rows($resp) != 0 || $_COOKIE[unick] == $administrador) { $permitir = true ; }
mysql_free_result($resp) ;

if(!$permitir) {
$resp = mysql_query("select borrar from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
if($usuario_rango < $datos[borrar]) { echo "<p class=\"tema\">No tienes suficiente nivel para borrar mensajes.<p><a href=\"javascript:history.back()\">� Regresar</a>" ; exit ; }
mysql_free_result($resp) ;
}

$resp = mysql_query("select usuario from eforo_mensajes where id='$mensajeid'") ;
$datos = mysql_fetch_array($resp) ;
if($datos[usuario] != $_COOKIE[unick] && !$permitir) {
echo "<p class=\"tema\">Tu no puedes editar este mensaje.<p><a href=\"javascript:history.back()\">� Regresar</a>" ;
exit ;
}
mysql_free_result($resp) ;

// Se borra el tema con todos los mensajes que contiene
if($borrar == "tema") {
$resp = mysql_query("select id,usuario from eforo_mensajes where forotema='$temaid'") ;
$mensajes = mysql_num_rows($resp) ;
$datos = mysql_fetch_array($resp) ;
mysql_query("update eforo_foros set temas=temas-1,mensajes=mensajes-$mensajes where id='$foroid'") ;
if(!$datos[usuario]) { mysql_query("update $tabla_usuarios set mensajes=mensajes-1 where nick='$datos[usuario]'") ; }
mysql_query("delete from eforo_mensajes where forotema='$temaid'") ;
echo "
<p><b>Tema borrado:</b> $temaid<br><b>Mensajes borrados en total:</b> $mensajes
<p><a href=foro.php?foroid=$foroid>Regresar al foro</a>
" ;
mysql_free_result($resp) ;
}
// Se borra un s�lo mensaje siempre y cuando no sea un tema
if($borrar == "mensaje") {
mysql_query("update eforo_mensajes set mensajes=mensajes-1 where id='$temaid'") ;
mysql_query("update eforo_foros set mensajes=mensajes-1 where id='$foroid'") ;
mysql_query("delete from eforo_mensajes where id='$mensajeid'") ;
echo "
<p><b>Mensaje borrado:</b> $mensajeid
<p><a href=foro.php?foroid=$foroid&temaid=$temaid>Regresar al tema</a>
" ;
}
mysql_close($conectar) ;
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<?
echo $htmlpie ;
?>
</body>
</html>
