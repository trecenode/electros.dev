<?
// Tiempo que se mantiene el usuario en l�nea en minutos
$tiempo = "10" ;
$fecha = time() ;
$limite = $fecha-$tiempo*60 ;
$ip = $REMOTE_ADDR ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
mysql_query("delete from eforo_enlinea where fecha < $limite") ;
$resp = mysql_query("select * from eforo_enlinea where ip='$ip'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("insert into eforo_enlinea (fecha,ip,usuario) values ('$fecha','$ip','$usuario')") ;
}
else {
mysql_query("update eforo_enlinea set fecha='$fecha',usuario='$usuario' where ip='$ip'") ;
}
$resp = mysql_query("select * from eforo_enlinea") ;
$usuarios = mysql_num_rows($resp) ;
$resp = mysql_query("select * from eforo_enlinea where usuario=''") ;
$anonimos = mysql_num_rows($resp) ;
$registrados = $usuarios - $anonimos ;
$resp = mysql_query("select usuario from eforo_enlinea where usuario!=''") ;
if(mysql_num_rows($resp) != 0) {
$renlinea = "�" ;
while($datos = mysql_fetch_array($resp)) {
$renlinea .= " <a href=\"forousuarios.php?u=$datos[usuario]\">$datos[usuario]</a> �" ;
}
}
?>
