<style>
/*
Tema: Electros
Autor: Electros
Fecha: 3 de Enero del 2004
*/
/* Cuerpo del foro */
body {
background: #ffffff ;
}
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
width: 100% ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
background: url('eforo_estilo/electros/fondo_titulo.gif') ;
}
.tabla_subtitulo {
border-left: #cccccc ; border-top: #cccccc ; border-right: #aaaaaa ; border-bottom: #aaaaaa ;
border-width: 2 ;
border-style: solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee ; border-top: #eeeeee ; border-right: #cccccc ; border-bottom: #cccccc ;
border-width: 2 ;
border-style: solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border-color: #000000 ; border-width: 1 ; border-style: solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
