<style>
/*
Titulo: cafe.php
Autor: -==[ZagreB]==-
Fecha: 14 de Diciembre del 2003
*/
/* Cuerpo del foro */
body {
background: #FCE6C4 ;
}
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #563707 ;
text-align: justify ;
scrollbar-face-color: #FB9B04 ;
scrollbar-darkshadow-color: #905801 ;
scrollbar-shadow-color: #FB9B04 ;
scrollbar-highlight-color: #FB9B04 ;
scrollbar-3dlight-color: #905801 ;
scrollbar-track-color: #FCE6C4 ;
scrollbar-arrow-color: #905801 ;
}
/* Titulos */
.t1 {
color: #F8DCB0 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #B18C51 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #B18C51 ;
}
/* Tablas del foro */
.tabla_principal {
border: #905801 2 solid ;
}
.tabla_titulo {
background: #905801 ;
}
.tabla_subtitulo {
background: #FB9B04 ;
}
.tabla_mensaje {
background: #F9D091 ;
}
/* Formulario */
.form {
border: #905801 1 solid ;
background: #F9D091 ;
font-family: verdana ;
font-size: 8pt ;
color: #905801 ;
}
</style>
