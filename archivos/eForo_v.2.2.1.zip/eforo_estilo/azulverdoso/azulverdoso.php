<style>
/*
Tema: Azul Verdoso
Autor: Electros
Fecha: 3 de Enero del 2004
*/
/* Cuerpo del foro */
body {
background: #000000 ;
}
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
text-align: justify ;
scrollbar-face-color: #005050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #002525 ;
scrollbar-highlight-color: #007575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #00ffff ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #00ffff ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #00ffff ;
}
/* Tablas del foro */
.tabla_principal {
border: #007575 1 solid ;
}
.tabla_titulo {
background: #003030 ;
}
.tabla_subtitulo {
background: #004040 ;
}
.tabla_mensaje {
background: #005050 ;
}
/* Formulario */
.form {
border: #007575 1 solid ;
background: #003030 ;
font-family: verdana ;
font-size: 8pt ;
color: #00ffff ;
}
</style>
