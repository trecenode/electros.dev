<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
// *******************************
// *** Comprobaci�n de usuario ***
// *******************************
if($_COOKIE[unick]) {
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if(md5(md5($datos[contrasena])) != $_COOKIE[ucontrasena]) { header("location: foroentrar.php") ; exit ; }
mysql_free_result($resp) ;
}
// ************* Fin *************
?>
<html>
<head>
<title><?=$titulo_foro?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
$permitir = false ;
$resp = mysql_query("select id from eforo_moderadores where foro='$foroid' and moderador='$_COOKIE[unick]'") ;
if(mysql_num_rows($resp) != 0 || $_COOKIE[unick] == $administrador) { $permitir = true ; }
mysql_free_result($resp) ;

if(!$permitir) {
$resp = mysql_query("select responder from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
if($usuario_rango < $datos[responder]) { echo "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\"><tr><td class=\"tabla_mensaje\"><p class=\"tema\">No tienes suficiente nivel para responder temas.<p><a href=\"javascript:history.back()\">� Regresar</a></td></tr></table>" ; exit ; }
mysql_free_result($resp) ;
}
echo $htmlcab ;
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$tema = quitar($tema) ;
$mensaje = quitar($mensaje) ;
if(!$caretosusar) { $caretosusar = 0 ; } if(!$codigousar) { $codigousar = 0 ; } if(!$urlusar) { $urlusar = 0 ; } if(!$firmausar) { $firmausar = 0 ; }
mysql_query("insert into eforo_mensajes (foro,forotema,foromostrar,fecha,usuario,tema,mensaje,caretos,codigo,url,firma,editado,ultimo) values ('$foroid','$temaid','0','$fecha','$_COOKIE[unick]','$tema','$mensaje','$caretosusar','$codigousar','$urlusar','$firmausar','$fecha','$fecha')") ;
mysql_query("update eforo_mensajes set mensajes=mensajes+1,ultimo='$fecha' where id='$temaid'") ;
mysql_query("update eforo_foros set mensajes=mensajes+1 where id='$foroid'") ;
if($_COOKIE[unick]) { mysql_query("update $tabla_usuarios set mensajes=mensajes+1 where nick='$_COOKIE[unick]'") ; }
$resp = mysql_query("select id from eforo_mensajes where fecha='$fecha'") ;
$datos = mysql_fetch_array($resp) ;
$mensaje = $datos[id] ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Confirmaci�n</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<div align="center">
Tu mensaje ha sido publicado con �xito. Haz click <a href="foro.php?foroid=<?=$foroid?>&temaid=<?=$temaid?>&pag=<?=$pag?>#<?=$mensaje?>">aqu�</a> para ver tu mensaje.
</div>
</td>
</tr>
</table>
<?
mysql_free_result($resp) ;
}
else {
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p class="tema"><a href="foro.php?foroid=<?=$foroid?>&temaid=<?=$temaid?>">� <?=$datos[tema]?></a>
<p>
<?
mysql_free_result($resp) ;
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p><a href="foro.php">Indice del foro</a> � <a href="foro.php?foroid=<?=$foroid?>"><?=$datos[foro]?></a>
<p>
<?
mysql_free_result($resp) ;
?>
<script>
enviado = 0 ;
function caretos(codigo) {
formulario.mensaje.value += codigo ;
formulario.mensaje.focus() ;
}
function revisar() {
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(enviado == 0) { enviado++ ; } else { alert('Los datos se est�n enviando por favor espera.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="fororesponder.php?foroid=<?=$foroid?>&temaid=<?=$temaid?>&pag=<?=$pag?>" onsubmit="return revisar()">
<table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td class="tabla_mensaje" valign="top">
<b>T�tulo:</b><br>
T�tulo del mensaje.
</td>
<td class="tabla_mensaje" valign="top">
<input type="text" name="tema" size="40" maxlength="100" class="form">
</td>
</tr>
<tr>
<td class="tabla_mensaje" valign="top">
<b>Mensaje:</b><br>
Contenido del mensaje.<br><br>
<b>Caretos:</b><br><br>
<table border="0" cellpadding="5" cellspacing="0" align="center">
<tr>
<td><a href="javascript:caretos(':D')"><img src="eforo_imagenes/caretos/alegre.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':8')"><img src="eforo_imagenes/caretos/asustado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':P')"><img src="eforo_imagenes/caretos/burla.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':S')"><img src="eforo_imagenes/caretos/confundido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(1')"><img src="eforo_imagenes/caretos/demonio.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':(2')"><img src="eforo_imagenes/caretos/demonio2.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':?')"><img src="eforo_imagenes/caretos/duda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-\(')"><img src="eforo_imagenes/caretos/enojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(';)')"><img src="eforo_imagenes/caretos/guino.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':\'(')"><img src="eforo_imagenes/caretos/llorar.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':lol:')"><img src="eforo_imagenes/caretos/lol.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':M')"><img src="eforo_imagenes/caretos/moda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':|')"><img src="eforo_imagenes/caretos/neutral.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':)')"><img src="eforo_imagenes/caretos/risa.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-)')"><img src="eforo_imagenes/caretos/sonrisa.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td></td>
<td><a href="javascript:caretos(':R')"><img src="eforo_imagenes/caretos/sonrojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':O')"><img src="eforo_imagenes/caretos/sorprendido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(')"><img src="eforo_imagenes/caretos/triste.gif" width="15" height="15" border="0"></a></td>
<td></td>
</tr>
</table>
</td>
<td class="tabla_mensaje" valign="top">
<textarea name="mensaje" cols="50" rows="20" class="form"></textarea>
</td>
</tr>
<tr>
<td valign="top" class="tabla_mensaje">&nbsp;</td>
<td class="tabla_mensaje">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="50%" valign="top">
<? if($caretos == "ON") {?><input type="checkbox" name="caretosusar" value="1" id="caretosusar" checked><label for="caretosusar"><b>Usar caretos en los mensajes</b></label><br><? }?>
<? if($codigo == "ON") {?><input type="checkbox" name="codigousar" value="1" id="codigousar" checked><label for="codigousar"><b>Usar eCodigo en los mensajes</b></label><br><? }?>
<? if($url == "ON") {?><input type="checkbox" name="urlusar" value="1" id="urlusar" checked><label for="urlusar"><b>Transformar URLs en enlaces</b></label><br><? }?>
</td>
<td width="50%" valign="top">
<input type="checkbox" name="firmausar" value="1" id="firmausar" checked><label for="firmausar"><b>Agregar firma en los mensajes</b></label><br>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td class="tabla_mensaje">&nbsp;</td>
<td class="tabla_mensaje">
<div align="right">
<input type="submit" name="enviar" value="Enviar" class="form">
</div>
</td>
</tr>
</table>
</form>
<div style="height: 175 ; overflow: auto">
<table width="100%" border="0" cellpadding="5" cellspacing="1">
<?
$resp = mysql_query("select id,usuario,mensaje from eforo_mensajes where forotema='$temaid' order by id desc limit $num_ultimos") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td valign="top" class="tabla_mensaje"><a href="forousuarios.php?u=<?=$datos[usuario]?>"><?=$datos[usuario]?></a></td>
<td valign="top" class="tabla_mensaje"><?=$datos[mensaje]?></td>
</tr>
<?
}
mysql_free_result($resp) ;
?>
</table>
</div>
<?
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<?
echo $htmlpie ;
?>
</body>
</html>
