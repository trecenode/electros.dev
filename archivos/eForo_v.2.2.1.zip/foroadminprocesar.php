<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
  <tr>
    <td class="tabla_titulo"><div align="center" class="t1">Confirmaci�n</div></td>
  </tr>
  <tr>
    <td class="tabla_mensaje">
      <div align="center">
      <?
      // --> Agregar categor�a
      if($agregar == "categoria") {
      mysql_query("insert into eforo_categorias (categoria) values ('$categoria')") ;
      $resp = mysql_query("select id from eforo_categorias") ;
      $categorias = mysql_num_rows($resp) ;
      mysql_free_result($resp) ;
      $categorias = $categorias * 10 ;
      $resp = mysql_query("select id from eforo_categorias order by id desc limit 1") ;
      $datos = mysql_fetch_array($resp) ;
      mysql_query("update eforo_categorias set orden='$categorias' where id='$datos[id]'") ;
      mysql_free_result($resp) ;
      echo "La categor�a <b>$categoria</b> ha sido agregada con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      // --> Agregar foro
      if($agregar == "foro") {
      mysql_query("insert into eforo_foros (categoria,foro,descripcion) values ('$categoria','$foro','$descripcion')") ;
      $resp = mysql_query("select id from eforo_foros order by id desc limit 1") ;
      $datos = mysql_fetch_array($resp) ;
      $resp2 = mysql_query("select id from eforo_foros where categoria='$categoria'") ;
      $foros = mysql_num_rows($resp2) ;
      mysql_free_result($resp2) ;
      $foros = $foros * 10 ;
      mysql_query("update eforo_foros set orden='$foros' where id='$datos[id]'") ;
      mysql_free_result($resp) ;
      echo "El foro <b>$foro</b> ha sido agregado con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      // --> Ordenar categor�a
      if($ordenar == "categoria") {
      if($subir) { mysql_query("update eforo_categorias set orden=orden-15 where id='$id'") ; }
      if($bajar) { mysql_query("update eforo_categorias set orden=orden+15 where id='$id'") ; }
      $resp = mysql_query("select id from eforo_categorias order by orden asc") ;
      $orden = 10 ;
      while($datos = mysql_fetch_array($resp)) {
      mysql_query("update eforo_categorias set orden='$orden' where id='$datos[id]'") ;
      $orden = $orden + 10 ;
      }
      mysql_free_result($resp) ;
      echo "La categor�a ha sido cambiada de orden con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      // --> Ordenar foro
      if($ordenar == "foro") {
      if($subir) { mysql_query("update eforo_foros set orden=orden-15 where id='$id'") ; }
      if($bajar) { mysql_query("update eforo_foros set orden=orden+15 where id='$id'") ; }
      $resp = mysql_query("select id from eforo_foros where categoria='$c' order by orden asc") ;
      $orden = 10 ;
      while($datos = mysql_fetch_array($resp)) {
      mysql_query("update eforo_foros set orden='$orden' where id='$datos[id]'") ;
      $orden = $orden + 10 ;
      }
      mysql_free_result($resp) ;
      echo "El foro ha sido cambiado de orden con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      // --> Borrar categor�a
      if($borrar == "categoria") {
      $resp = mysql_query("select id from eforo_foros where categoria='$id'") ;
      if(mysql_num_rows($resp) == 0) {
      mysql_query("delete from eforo_categorias where id='$id'") ;
      echo "La categor�a ha sido borrada con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      else {
      echo "Primero debes eliminar todos los foros de esta categor�a. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      }
      // --> Borrar foro
      if($borrar == "foro") {
      mysql_query("delete from eforo_mensajes where foro='$id'") ;
      mysql_query("delete from eforo_foros where id='$id'") ;
      echo "El foro y todos sus mensajes han sido borrados con �xito. Haz click <a href=\"foroadmin.php\">aqu�</a> para regresar." ;
      }
      // --> Configuraci�n
      if($id == "configuracion") {
      function quitar($texto) {
      $texto = trim($texto) ;
      $texto = addslashes($texto) ;
      return $texto ;
      }
      $c_htmlcab = quitar($c_htmlcab) ;
      $c_htmlpie = quitar($c_htmlpie) ;
      mysql_query("update eforo_config set administrador='$c_administrador',email='$c_administrador_email',titulo='$c_titulo_foro',temas='$c_temas',mensajes='$c_mensajes',
      ultimos='$c_ultimos',codigo='$c_codigo',caretos='$c_caretos',url='$c_url',censurar='$c_censurar',estilo='$c_estilo',
      avatarlargo='$c_avatarlargo',avatarancho='$c_avatarancho',avatartamano='$c_avatartamano',privados='$c_privados',
      htmlcab='$c_htmlcab',htmlpie='$c_htmlpie'") ;
      echo "Los datos han sido actualizados con �xito. Haz click <a href=\"foroadmin.php?administrar=configuracion\">aqu�</a> para regresar." ;
      }
      // --> Rangos
      if($id == "rangos") {
			// Guarda todos los rangos en un array para hacer una s�la consulta y ahorrar recursos del servidor
			$resp = mysql_query("select * from eforo_rangos order by rango asc") ;
			while($datos = mysql_fetch_array($resp)) {
			$rangos_todos[$datos[rango]] = $datos[descripcion] ;
			}
      switch(true) {
      case $agregar :
      $resp = mysql_query("select rango from eforo_rangos where rango='$r_rango'") ;
      if(mysql_num_rows($resp) != 0) {
      echo "Ya existe este rango en la base de datos. Haz click <a href=\"javascript:history.back()\">aqu�</a> para regresar." ;
      }
      else {
      mysql_query("insert into eforo_rangos (rango,minimo,descripcion) values ('$r_rango','$r_minimo','$r_descripcion')") ;
      echo "El rango ha sido agregado con �xito. Haz click <a href=\"foroadmin.php?administrar=rangos\">aqu�</a> para regresar." ;
      }
      break ;
      case isset($modificar) :
      mysql_query("update eforo_rangos set minimo='$r_minimo',descripcion='$r_descripcion' where rango='$modificar'") ;
      echo "El rango ha sido modificado con �xito. Haz click <a href=\"foroadmin.php?administrar=rangos\">aqu�</a> para regresar." ;
      break ;
      case $borrar :
      mysql_query("delete from eforo_rangos where rango='$borrar'") ;
      echo "El rango ha sido borrado con �xito. Haz click <a href=\"foroadmin.php?administrar=rangos\">aqu�</a> para regresar." ;
      }
      }
      // --> Permisos
      if($id == "permisos") {
      foreach($_POST as $a => $b) {
      switch(true) {
      case ereg("leer$",$a) :
      $foro = explode("_",$a) ;
      $foro = $foro[1] ;
      mysql_query("update eforo_foros set leer='$b' where id='$foro'") ;
      break ;
      case ereg("nuevo$",$a) :
      $foro = explode("_",$a) ;
      $foro = $foro[1] ;
      mysql_query("update eforo_foros set nuevo='$b' where id='$foro'") ;
      break ;
      case ereg("responder$",$a) :
      $foro = explode("_",$a) ;
      $foro = $foro[1] ;
      mysql_query("update eforo_foros set responder='$b' where id='$foro'") ;
      break ;
      case ereg("editar$",$a) :
      $foro = explode("_",$a) ;
      $foro = $foro[1] ;
      mysql_query("update eforo_foros set editar='$b' where id='$foro'") ;
      break ;
      case ereg("borrar$",$a) :
      $foro = explode("_",$a) ;
      $foro = $foro[1] ;
      mysql_query("update eforo_foros set borrar='$b' where id='$foro'") ;
      }
      }
      echo "Los permisos han sido modificados con �xito. Haz click <a href=\"foroadmin.php?administrar=permisos\">aqu�</a> para regresar." ;
      }
      // --> Usuarios
      if($id == "usuarios") {
      switch(true) {
      case $u_rango :
      foreach($_POST as $a => $b)
      if(ereg("^u[0-9]+$",$a)) {
      if($u_rango == "defecto") {
      $u_rango = false ;
      $resp = mysql_query("select mensajes from $tabla_usuarios where id='$b'") ; $datos = mysql_fetch_array($resp) ; $u_mensajes = $datos[mensajes] ; mysql_free_result($resp) ;
      foreach($rangos_todos as $rango => $minimo) {
      if($u_mensajes >= $minimo && $minimo != 0) { $u_rango = $rango ; }
      }
      }
      if(!$u_rango) { $u_rango = 1 ; }
      mysql_query("update $tabla_usuarios set rango='$u_rango' where id='$b'") ;
      }
      echo "El rango ha sido asignado con �xito. Haz click <a href=\"foroadmin.php?administrar=usuarios&letra=$letra&desde=$desde\">aqu�</a> para regresar." ;
      break ;
      case $moderador :
			mysql_query("delete from eforo_moderadores where moderador='$moderador'") ;
      foreach($_POST as $a => $b) {
      if(ereg("^foro[0-9]+$",$a)) { mysql_query("insert into eforo_moderadores (foro,moderador) values ('$b','$moderador')") ; }
      }
      mysql_query("update $tabla_usuarios set rango='500' where nick='$moderador'") ;
      echo "El moderador ha sido designado con �xito. Haz click <a href=\"foroadmin.php?administrar=usuarios&letra=$letra&desde=$desde\">aqu�</a> para regresar." ;
      break ;
      case $borrar :
      mysql_query("delete from $tabla_usuarios where id='$borrar'") ;
      echo "El usuario ha sido borrado con �xito. Haz click <a href=\"foroadmin.php?administrar=usuarios&letra=$letra&desde=$desde\">aqu�</a> para regresar." ;
      }
      }
      ?>
      </div>
    </td>
  </tr>
</table><br>
