<?
setcookie("unick") ;
setcookie("ucontrasena") ;
header("location: $HTTP_REFERER") ;
?>
