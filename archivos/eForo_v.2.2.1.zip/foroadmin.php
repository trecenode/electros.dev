<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><?=$titulo_foro?> :: Panel de administraci�n</title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
if($_GET[administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$administrador'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($administrador != $_COOKIE[unick] || $datos[contrasena] != $_COOKIE[ucontrasena]) {
header("location: foroentrar.php") ;
exit ;
}
mysql_free_result($resp) ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<?
// *** Procesamiento de datos ***
if($enviar) {
include("foroadminprocesar.php") ;
}
else {
// *** Panel de administraci�n ***
?>
<table width="850" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="150" valign="top">
<!-- Inicio Menu -->
      <table width="150" border="0" cellpadding="0" cellspacing="1" class="tabla_principal">
        <tr>
          <td class="tabla_titulo"><div align="center" class="t1">eForo</div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php">Administrar</a></div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?administrar=configuracion">Configuraci�n</a></div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?administrar=rangos">Rangos</a></div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?administrar=permisos">Permisos</a></div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?administrar=usuarios">Usuarios</a></div></td>
        </tr>
      </table>
<!-- Fin Menu -->
    </td>
    <td width="25"></td><!-- Separador -->
    <td width="675" valign="top">
<!-- Inicio Principal -->
      <?
      if(!$administrar) {
      ?>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td>
            <table border="0" cellpadding="0" cellspacing="0" align="center">
              <tr>
                <td valign="top">
                  <p class="t1">Agregar categor�as
                  <p>
                  <form method="post" action="foroadmin.php?agregar=categoria">
                    <div style="position: absolute ; visibility: hidden"><input type="text" name="a"></div>
                    <b>Categor�a:</b><br>
                    <input type="text" name="categoria" maxlength="100" size="30" class="form"><br><br>
                    <input type="submit" name="enviar" value="Agregar Categor�a" class="form">
                  </form>
                </td>
                <td width="25">&nbsp;</td>
                <td valign="top">
                  <p class="t1">Agregar foros
                  <p>
                  <form method="post" action="foroadmin.php?agregar=foro">
                    <b>Foro:</b><br>
                    <input type="text" name="foro" maxlength="100" size="30" class="form"><br>
                    <b>Categor�a:</b><br>
                    <select name="categoria" class="form">
                    <?
                    $resp = mysql_query("select id,categoria from eforo_categorias order by orden asc") ;
                    while($datos = mysql_fetch_array($resp)) {
                    ?>
                    <option value="<?=$datos[id]?>"><?=$datos[categoria]?>
                    <?
                    }
                    mysql_free_result($resp) ;
                    ?>
                    </select><br>
                    <b>Descripci�n:</b><br>
                    <textarea name="descripcion" cols="30" rows="5" class="form"></textarea><br><br>
                    <input type="submit" name="enviar" value="Agregar Foro" class="form">
                  </form>
                </td>
              </tr>
            </table><br>
            <table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
              <tr>
                <td width="30%" class="tabla_titulo"><div class="t1" align="center">Orden</div></td>
                <td width="50%" class="tabla_titulo"><div class="t1" align="center">Categor�a</div></td>
                <td width="20%" class="tabla_titulo">&nbsp;</td>
              </tr>
              <?
              $resp = mysql_query("select * from eforo_categorias order by orden asc") ;
              while($datos = mysql_fetch_array($resp)) {
              ?>
              <tr>
                <td class="tabla_subtitulo">
                  <div align="center">
                  <a href="foroadmin.php?id=<?=$datos[id]?>&ordenar=categoria&bajar=si&enviar=si">Bajar</a> |
                  <a href="foroadmin.php?id=<?=$datos[id]?>&ordenar=categoria&subir=si&enviar=si">Subir</a><br><br>
                  </div>
                </td>
                <td class="tabla_subtitulo"><div class="t1"><?=$datos[categoria]?></div></td>
                <td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?id=<?=$datos[id]?>&borrar=categoria&enviar=si">Borrar</a></div></td>
              </tr>
              <?
              $resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
              while($datos2 = mysql_fetch_array($resp2)) {
              ?>
              <tr>
                <td class="tabla_mensaje">
                  <div align="center">
                  <a href="foroadmin.php?id=<?=$datos2[id]?>&c=<?=$datos[id]?>&ordenar=foro&bajar=si&enviar=si">Bajar</a> |
                  <a href="foroadmin.php?id=<?=$datos2[id]?>&c=<?=$datos[id]?>&ordenar=foro&subir=si&enviar=si">Subir</a>
                  </div>
                </td>
                <td class="tabla_mensaje"><a href="foro.php?foroid=<?=$datos2[id]?>"><?=$datos2[foro]?></a><br><?=$datos2[descripcion]?></td>
                <td class="tabla_mensaje"><div align="center"><a href="foroadmin.php?id=<?=$datos2[id]?>&borrar=foro&enviar=si">Borrar</a></div></td>
              </tr>
              <?
              }
              mysql_free_result($resp2) ;
              }
              ?>
            </table>
          </td>
        </tr>
      </table>
      <?
      }
      if($administrar == "configuracion") {
      ?>
      <form method="post" action="foroadmin.php?id=configuracion">
        <table width="100%" border="0" cellpadding="3" cellspacing="1" class="tabla_principal">
          <tr>
            <td colspan="2" class="tabla_titulo"><div align="center" class="t1">Configuraci�n</div></td>
          </tr>
          <tr>
            <td colspan="2" class="tabla_subtitulo"><div class="t1">General</div></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Administrador:</b><br>Nick del administrador</td>
            <td class="tabla_mensaje"><input type="text" name="c_administrador" value="<?=$administrador?>" maxlength="20" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Email:</b><br>Este email aparecer� en todos los correos que se env�en a los usuarios del foro</td>
            <td class="tabla_mensaje"><input type="text" name="c_administrador_email" value="<?=$administrador_email?>" maxlength="100" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>T�tulo:</b><br>T�tulo del foro</td>
            <td class="tabla_mensaje"><input type="text" name="c_titulo_foro" value="<?=$titulo_foro?>" maxlength="100" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Temas:</b><br>Numero de temas a mostrar</td>
            <td class="tabla_mensaje"><input type="text" name="c_temas" value="<?=$num_temas?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Mensajes:</b><br>Mensajes a mostrar por tema</td>
            <td class="tabla_mensaje"><input type="text" name="c_mensajes" value="<?=$num_mensajes?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Ultimos mensajes:</b><br>Al querer responder un tema se ver�n los �ltimos mensajes</td>
            <td class="tabla_mensaje"><input type="text" name="c_ultimos" value="<?=$num_ultimos?>" maxlength="3"class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Permitir eCodigo:</b><br>El eCodigo es un c�digo especial que sirve para personalizar los mensajes sin necesidad de usar HTML</td>
            <td class="tabla_mensaje"><input type="text" name="c_codigo" value="<?=$codigo?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Permitir caretos:</b><br>Uso de caretos en los mensajes</td>
            <td class="tabla_mensaje"><input type="text" name="c_caretos" value="<?=$caretos?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Transformar URLs en enlaces:</b><br>Transforma autom�ticamente toda direcci�n del tipo http:// a un enlace</td>
            <td class="tabla_mensaje"><input type="text" name="c_url" value="<?=$url?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Censurar palabras:</b><br>Sustituye las palabras censuradas por otras palabras que puedes definir</td>
            <td class="tabla_mensaje"><input type="text" name="c_censurar" value="<?=$censurar?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Estilo del foro:</b><br>Selecciona el estilo del foro (tipo de letra, colores, formularios)</td>
            <td class="tabla_mensaje">
              <select name="c_estilo" class="form">
              <?
              $directorio = opendir("eforo_estilo") ;
              while($archivo = readdir($directorio)) {
              if($archivo != "." && $archivo != "..") {
              if($archivo == $estilo) {
              echo "<option value=\"$archivo\" selected>$archivo" ;
              }
              else {
              echo "<option value=\"$archivo\">$archivo" ;
              }
              }
              }
              closedir($directorio) ;
              ?>
              </select>
            </td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>HTML Cabecera:</b><br>Aqu� puedes insertar un c�digo HTML que se ver� al principio de todas las p�ginas del foro</td>
            <td class="tabla_mensaje"><textarea name="c_htmlcab" cols="30" rows="5" class="form"><?=htmlspecialchars($htmlcab)?></textarea></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>HTML Pie de p�gina:</b><br>Aqu� puedes insertar un c�digo HTML que se ver� al final de todas las p�ginas del foro</td>
            <td class="tabla_mensaje"><textarea name="c_htmlpie" cols="30" rows="5" class="form"><?=htmlspecialchars($htmlpie)?></textarea></td>
          </tr>
          <tr>
            <td colspan="2" class="tabla_subtitulo"><div class="t1">Mensajes privados</div></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>M�ximo de mensajes privados por usuario:</b><br>Es el n�mero m�ximo de mensajes privados que el usuario podr� recibir</td>
            <td class="tabla_mensaje"><input type="text" name="c_privados" value="<?=$max_privados?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td colspan="2" class="tabla_subtitulo"><div class="t1">Avatares</div></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Tama�o de largo:</b><br>El largo en pixeles de la imagen</td>
            <td class="tabla_mensaje"><input type="text" name="c_avatarlargo" value="<?=$tam_largo?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Tama�o de ancho:</b><br>El ancho en pixeles de la imagen</td>
            <td class="tabla_mensaje"><input type="text" name="c_avatarancho" value="<?=$tam_ancho?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><b>Tama�o de archivo</b><br>El peso m�ximo en Kb</td>
            <td class="tabla_mensaje"><input type="text" name="c_avatartamano" value="<?=$tam_archivo?>" maxlength="3" class="form"></td>
          </tr>
          <tr>
            <td colspan="2" class="tabla_mensaje"><div align="center"><input type="submit" name="enviar" value="Enviar" class="form"></div></td>
          </tr>
        </table>
      </form>
<!-- Fin Principal -->
    </td>
  </tr>
</table>
<?
}
if($administrar == "rangos") {
// Guarda todos los rangos en un array para hacer una s�la consulta y ahorrar recursos del servidor
$resp = mysql_query("select * from eforo_rangos order by rango asc") ;
while($datos = mysql_fetch_array($resp)) {
$rangos_todos[$datos[rango]] = $datos[descripcion] ;
}
?>
<table width="100%" border="0" cellpadding="3" cellspacing="1" class="tabla_principal">
  <tr>
    <td colspan="4" class="tabla_titulo"><div align="center" class="t1">Rangos</div></td>
  </tr>
  <tr>
    <td width="15%" class="tabla_subtitulo"><div class="t1">Rango</div></td>
    <td width="15%" class="tabla_subtitulo"><div class="t1">M�nimo</div></td>
    <td width="50%" class="tabla_subtitulo"><div class="t1">Descripci�n</div></td>
    <td width="20%" class="tabla_subtitulo">&nbsp;</td>
  </tr>
  <?
  $resp = mysql_query("select * from eforo_rangos order by rango asc") ;
  while($datos = mysql_fetch_array($resp)) {
  $bloquear = false ;
  if($datos[rango] == -1 || $datos[rango] == 0 || $datos[rango] == 1 || $datos[rango] == 500 || $datos[rango] == 999) { $bloquear = true ; }
  ?>
  <tr>
    <td class="tabla_mensaje"><form method="post" action="foroadmin.php?id=rangos&modificar=<?=$datos[rango]?>"><?=$datos[rango]?></td>
      <td class="tabla_mensaje"><? if($bloquear) {?><div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>---<? } else {?><input type="text" name="r_minimo" size="5" maxlength="5" value="<?=$datos[minimo]?>" class="form"<?=$bloquear?>><? }?></td>
      <td class="tabla_mensaje"><input type="text" name="r_descripcion" size="25" maxlength="100" value="<?=$datos[descripcion]?>" class="form"> <input type="submit" name="enviar" value="Modificar" class="form"></td>
      <td class="tabla_mensaje"></form><? if($bloquear) {?>&nbsp;<? } else {?><div align="center"><a href="foroadmin.php?id=rangos&borrar=<?=$datos[rango]?>&enviar=si">Borrar</a></div><? }?></td>
  </tr>
  <?
  }
  mysql_free_result($resp)
  ?>
  <tr>
    <td colspan="4" class="tabla_subtitulo"><div class="t1">Agregar nuevo rango</div></td>
  </tr>
  <tr>
    <td class="tabla_mensaje"><form method="post" action="foroadmin.php?id=rangos&agregar=si"><input type="text" name="r_rango" size="3" maxlength="3" class="form"></td>
      <td class="tabla_mensaje"><input type="text" name="r_minimo" size="5" maxlength="5" class="form"></td>
      <td class="tabla_mensaje"><input type="text" name="r_descripcion" size="25" maxlength="100" class="form"> <input type="submit" name="enviar" value="Agregar" class="form"></td>
      <td class="tabla_mensaje"></form>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" class="tabla_subtitulo"><div class="t1">Ayuda</div></td>
  </tr>
  <tr>
    <td colspan="4" class="tabla_mensaje">
      <script>
      a = 0 ;
      function ayuda() {
      if(a == 0) {
      ayuda_enlace.value = 'Ocultar >>' ;
      ayuda_texto.style.position = 'relative' ;
      ayuda_texto.style.visibility = 'visible' ;
      a++ ;
      }
      else {
      ayuda_enlace.value = 'Ver m�s >>' ;
      ayuda_texto.style.position = 'absolute' ;
      ayuda_texto.style.visibility = 'hidden' ;
      a-- ;
      }
      }
      </script>
      <input type="button" id="ayuda_enlace" value="Ver m�s >>" onclick="ayuda()" class="form">
      <div id="ayuda_texto" style="position: absolute ; visibility: hidden">
      <br>
      <b>� Qu� son los rangos ?</b><br>
      El rango es una forma de asignarle diferentes niveles a tus usuarios, el usuario puede subir de nivel ya sea al
      llegar a un determinado n�mero de mensajes, o que sea designado manualmente con un rango fijo. De esta forma puedes poner
      diferentes permisos en cada subforo como por ejemplo que s�lo usuarios con nivel 100 puedan entrar a un subforo.<br><br>
      <b>� Como se agrega un rango ?</b><br>
      En cada rango podr�s definir el m�nimo que se necesita de mensajes y una descripci�n que se mostrar� debajo del nick de
      cada usuario. Si deseas que el rango sea fijo y no cambie con el n�mero de mensajes pon un m�nimo de cero (0) pero este
      rango s�lo puede ser puesto por el administrador. S�lo recuerda que en los rangos especiales -1, 0, 1, 500 y 999 s�lo
      puedes modificar la descripci�n.<br><br>
      <b>� El nivel 500 o 999 hace moderador o administrador a un usuario ?</b><br>
      No, estos niveles son solamente descriptivos y en el caso del nivel 500 se asigna por defecto al usuario que es nombrado
      moderador desde la opci�n <b>Usuarios</b>. M�s adelante puedes modificar el rango del moderador y ponerle cualquier otro,
      esta es una ventaja si por ejemplo deseas que cada moderador tenga una diferente descripci�n.<br><br>
      <b>� C�mo se comportan los rangos ?</b><br>
      -1 - Usuarios que han sido expulsados - Pueden leer mensajes.<br>
      0 - Usuarios no registrados - Pueden leer, escribir nuevos temas y responder mensajes.<br>
      1 al 999 - Usuarios registrados - Pueden leer, escribir nuevos temas, responder mensajes, editar y borrar sus propios mensajes.<br>
      Este es el permiso m�ximo que pueden tener los usuarios que tengan esos rangos, pero tambi�n depende del permiso que hayas
      elegido por subforo.<br><br>
      <b>Aviso:</b> El nivel m�nimo de mensajes siempre debe estar en forma proporcional al rango definido, por ejemplo lo siguiente
      no es v�lido:<br><br>
      <b>10 - 125 - Intermedio<br>
      <font color="aa0000">20 - 175 - Avanzado</font><br>
      30 - 150 - Experto</b><br><br>
      Si te fijas en este caso al llegar a 175 mensajes, el usuario pasar�a del rango 30 al rango 20 con lo que ser�a un error.
      </div>
      <?
      }
      if($administrar == "permisos") {
      $resp = mysql_query("select * from eforo_categorias order by orden asc") ;
      ?>
      <form method="post" action="foroadmin.php?id=permisos">
        <table width="100%" border="0" cellpadding="3" cellspacing="1" class="tabla_principal">
          <tr>
            <td class="tabla_titulo" colspan="5"><div align="center" class="t1">Permisos</div></td>
          </tr>
          <tr>
            <td class="tabla_subtitulo"><div class="t1">Leer</div></td>
            <td class="tabla_subtitulo"><div class="t1">Nuevo tema</div></td>
            <td class="tabla_subtitulo"><div class="t1">Responder</div></td>
            <td class="tabla_subtitulo"><div class="t1">Editar</div></td>
            <td class="tabla_subtitulo"><div class="t1">Borrar</div></td>
          </tr>
          <?
          while($datos = mysql_fetch_array($resp)) {
          ?>
          <tr>
            <td class="tabla_subtitulo" colspan="5"><div class="t1"><?=$datos[categoria]?></div></td>
          </tr>
          <?
          $resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
          while($datos2 = mysql_fetch_array($resp2)) {
          // --> Leer
          $rangos_leer = false ;
          foreach($rangos_todos as $rango => $descripcion) {
          $permiso = false ;
          if($rango == $datos2[leer]) { $permiso = " selected" ; }
          $rangos_leer .= "<option value=\"$rango\"$permiso>$rango - $descripcion" ;
          }
          // --> Nuevo tema
          $rangos_nuevo = false ;
          foreach($rangos_todos as $rango => $descripcion) {
          if($rango != -1) {
          $permiso = false ;
          if($rango == $datos2[nuevo]) { $permiso = " selected" ; }
          $rangos_nuevo .= "<option value=\"$rango\"$permiso>$rango - $descripcion" ;
          }
          }
          // --> Responder
          $rangos_responder = false ;
          foreach($rangos_todos as $rango => $descripcion) {
          if($rango != -1) {
          $permiso = false ;
          if($rango == $datos2[responder]) { $permiso = " selected" ; }
          $rangos_responder .= "<option value=\"$rango\"$permiso>$rango - $descripcion" ;
          }
          }
          // --> Editar
          $rangos_editar = false ;
          foreach($rangos_todos as $rango => $descripcion) {
          if($rango != -1 && $rango != 0) {
          $permiso = false ;
          if($rango == $datos2[editar]) { $permiso = " selected" ; }
          $rangos_editar .= "<option value=\"$rango\"$permiso>$rango - $descripcion" ;
          }
          }
          // --> Borrar
          $rangos_borrar = false ;
          foreach($rangos_todos as $rango => $descripcion) {
          if($rango != -1 && $rango != 0) {
          $permiso = false ;
          if($rango == $datos2[borrar]) { $permiso = " selected" ; }
          $rangos_borrar .= "<option value=\"$rango\"$permiso>$rango - $descripcion" ;
          }
          }
          ?>
          <tr>
            <td class="tabla_mensaje" colspan="5"><div class="tema"><?=$datos2[foro]?></div></td>
          </tr>
          <tr>
            <td class="tabla_mensaje"><select name="p_<?=$datos2[id]?>_leer" class="form" style="font-size: 7pt"><?=$rangos_leer?></select></td>
            <td class="tabla_mensaje"><select name="p_<?=$datos2[id]?>_nuevo" class="form" style="font-size: 7pt"><?=$rangos_nuevo?></select></td>
            <td class="tabla_mensaje"><select name="p_<?=$datos2[id]?>_responder" class="form" style="font-size: 7pt"><?=$rangos_responder?></select></td>
            <td class="tabla_mensaje"><select name="p_<?=$datos2[id]?>_editar" class="form" style="font-size: 7pt"><?=$rangos_editar?></select></td>
            <td class="tabla_mensaje"><select name="p_<?=$datos2[id]?>_borrar" class="form" style="font-size: 7pt"><?=$rangos_borrar?></select></td>
          </tr>
          <?
          }
          mysql_free_result($resp2) ;
          }
          ?>
          <tr>
            <td colspan="5" class="tabla_mensaje"><div align="center"><input type="submit" name="enviar" value="Modificar los permisos" class="form"></div></td></form>
        </tr>
        <tr>
          <td class="tabla_subtitulo" colspan="5"><div class="t1">Ayuda</div></td>
        </tr>
        <tr>
          <td class="tabla_mensaje" colspan="5">
            <script>
            a = 0 ;
            function ayuda() {
            if(a == 0) {
            ayuda_enlace.value = 'Ocultar >>' ;
            ayuda_texto.style.position = 'relative' ;
            ayuda_texto.style.visibility = 'visible' ;
            a++ ;
            }
            else {
            ayuda_enlace.value = 'Ver m�s >>' ;
            ayuda_texto.style.position = 'absolute' ;
            ayuda_texto.style.visibility = 'hidden' ;
            a-- ;
            }
            }
            </script>
            <input type="button" id="ayuda_enlace" value="Ver m�s >>" onclick="ayuda()" class="form">
            <div id="ayuda_texto" style="position: absolute ; visibility: hidden">
            <br>
            Aqu� puedes seleccionar los niveles m�nimos que se requieren ya sea para leer, escribir, editar y borrar mensajes.<br><br>
            Si un usuario no puede leer mensajes, al momento de entrar al subforo ver� un aviso dici�ndole que no cumple con el nivel m�nimo.
            En el caso de no poder escribir, editar y borrar mensajes, se le notificar� al momento.
            </div>
          </td>
        </tr>
        <?
        echo "</table>" ;
      mysql_free_result($resp) ;
      }
      if($administrar == "usuarios") {
      if($moderador) {
      ?>
      <table width="100%" border="0" cellpadding="1" cellspacing="1">
        <tr>
          <td class="tabla_titulo"><div align="center" class="t1">Usuarios</div></td>
        </tr>
        <tr>
          <td class="tabla_subtitulo"><div class="t1">Moderador</div></td>
        </tr>
        <tr>
          <td class="tabla_mensaje">
            <p>Selecciona los foros que moderar� el usuario <b><?=$moderador?></b>:
            <form method="post" action="foroadmin.php?id=usuarios<? if($letra) { echo "&letra=$letra" ; } ?><? if($desde) { echo "&desde=$desde" ; } ?>&moderador=<?=$moderador?>">
              <?
							// Comprobar si el usuario seleccionado ya era moderador
							$resp = mysql_query("select id from eforo_moderadores where moderador='$moderador'") ;
							if(mysql_num_rows($resp) != 0) { $usuario_moderador = true ; }
							mysql_free_result($resp) ;
              $resp = mysql_query("select * from eforo_categorias order by orden asc") ;
              while($datos = mysql_fetch_array($resp)) {
              echo "<p><b>$datos[categoria]</b><br>\n" ;
              $resp2 = mysql_query("select id,foro from eforo_foros where categoria='$datos[id]' order by orden asc") ;
              while($datos2 = mysql_fetch_array($resp2)) {
							if($usuario_moderador) {
							$seleccionar = false ;
							$resp3 = mysql_query("select id from eforo_moderadores where foro='$datos2[id]' and moderador='$moderador'") ;
							if(mysql_num_rows($resp3) != 0) { $seleccionar = " checked" ; }
							mysql_free_result($resp3) ;
							}
              echo "<input type=\"checkbox\" id=\"foro$datos2[id]\" name=\"foro$datos2[id]\" value=\"$datos2[id]\"$seleccionar><label for=\"foro$datos2[id]\">$datos2[foro]</label><br>\n" ;
              }
              mysql_free_result($resp2) ;
              }
              mysql_free_result($resp) ;
              ?>
              <br>
              <div align="center"><input type="submit" name="enviar" value="Designar Moderador" class="form"></div>
            </form>
          </td>
        </tr>
      </table>
      <?
      }
      else {
      ?>
      <script>
      function borrar(usuario) {
      if(confirm('Todos los datos de este usuario ser�n eliminados. Deseas continuar')) {
      location = 'foroadmin.php?id=usuarios<? if($letra) { echo "&letra=$letra" ; } ?><? if($desde) { echo "&desde=$desde" ; } ?>&borrar='+usuario+'&enviar=si' ;
      }
      }
      </script>
      <form name="formulario" method="post" action="foroadmin.php?id=usuarios<? if($letra) { echo"&letra=$letra" ; } ?><? if($desde) { echo"&desde=$desde" ; } ?>&enviar=si">
        <table width="100%" border="0" cellpadding="1" cellspacing="1">
          <tr>
            <td colspan="7" class="tabla_titulo"><div align="center" class="t1">Usuarios</div></td>
          </tr>
          <tr>
            <td colspan="7" class="tabla_subtitulo">
              <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td valign="top">
                    Cambiar rango:<br>
                    <select name="u_rango" onchange="submit()" class="form">
                    <option value="0">
                    <?
                    foreach($rangos_todos as $a => $b) {
                    if($rangos_min[$a] == 0 && $a != 0 && $a != 1) { echo "<option value=\"$a\">$a - $b" ; }
                    }
                    ?>
                    <option value="defecto">Poner por defecto
                    </select>
                  </td>
                  <td width="10"></td>
                  <td valign="top">
                    Ordenar por orden alfab�tico:<br>
                    <a href="foroadmin.php?administrar=usuarios&letra=todos">Todos</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=a">A</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=b">B</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=c">C</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=d">D</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=e">E</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=f">F</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=g">G</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=h">H</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=i">I</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=j">J</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=k">K</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=l">L</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=m">M</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=n">N</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=o">O</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=p">P</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=q">Q</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=r">R</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=s">S</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=t">T</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=u">U</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=v">V</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=w">W</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=x">X</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=y">Y</a>
                    <a href="foroadmin.php?administrar=usuarios&letra=z">Z</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td class="tabla_subtitulo">&nbsp;</td>
            <td class="tabla_subtitulo"><b>Usuario</b></td>
            <td class="tabla_subtitulo"><b>Men</b></td>
            <td class="tabla_subtitulo"><b>Rango</b></td>
            <td class="tabla_subtitulo"><b>Email</b></td>
            <td class="tabla_subtitulo">&nbsp;</td>
            <td class="tabla_subtitulo">&nbsp;</td>
          </tr>
          <?
          $resp = mysql_query("select id from $tabla_usuarios") ;
          $usuarios = mysql_num_rows($resp) ;
          $mostrar = 30 ;
          if(!$desde) { $desde = 0 ; }
          if($letra) { $ordenar_letra = "where nick like '$letra%'" ; }
          if($letra == "todos") { $ordenar_letra = false ; }
          $resp = mysql_query("select * from $tabla_usuarios $ordenar_letra order by id desc limit $desde,$mostrar") ;
          $desde = $desde + $mostrar ;
          function fecha($a) {
          $mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
          $diames = date(j,$a) ; $mesano = date(n,$a) - 1 ; $ano = date(Y,$a) ; $hora = date("h:i A",$a) ;
          $a = "$diames $mesesano[$mesano] $ano $hora" ;
          return $a ;
          }
          while($datos = mysql_fetch_array($resp)) {
          $datos[fecha] = fecha($datos[fecha]) ;
          ?>
          <tr>
            <td class="tabla_mensaje"><div align="center"><input type="checkbox" id="u<?=$datos[id]?>" name="u<?=$datos[id]?>" value="<?=$datos[id]?>"></div></td>
            <td class="tabla_mensaje" title="Fecha de registro: <?=$datos[fecha]?> IP: <?=$datos[ip]?>"><a href="forousuarios.php?u=<?=$datos[nick]?>" target="_blank"><b><?=$datos[nick]?></b></a></td>
            <td class="tabla_mensaje"><div align="center"><?=$datos[mensajes]?></div></td>
            <td class="tabla_mensaje"><div align="center"><?=$datos[rango]?></div></td>
            <td class="tabla_mensaje"><a href="mailto:<?=$datos[email]?>"><?=$datos[email]?></a></td>
            <td class="tabla_mensaje"><div align="center"><input type="button" onclick="location='foroadmin.php?administrar=usuarios<? if($letra) { echo "&letra=$letra" ; } ?><? if($desde) { $d = $desde - $mostrar ; echo "&desde=$d" ; } ?>&moderador=<?=$datos[nick]?>'" value="Moderador" class="form"></td>
            <td class="tabla_mensaje"><div align="center"><input type="button" onclick="borrar('<?=$datos[id]?>')" value="Borrar" class="form" style="color: #aa0000"></td>
          </tr>
          <?
          }
          ?>
          <tr>
            <td colspan="7" class="tabla_subtitulo"><div class="t1">Ayuda</div></td>
          </tr>
          <tr></form>
          <td colspan="7" class="tabla_mensaje">
            <script>
            a = 0 ;
            function ayuda() {
            if(a == 0) {
            ayuda_enlace.value = 'Ocultar >>' ;
            ayuda_texto.style.position = 'relative' ;
            ayuda_texto.style.visibility = 'visible' ;
            a++ ;
            }
            else {
            ayuda_enlace.value = 'Ver m�s >>' ;
            ayuda_texto.style.position = 'absolute' ;
            ayuda_texto.style.visibility = 'hidden' ;
            a-- ;
            }
            }
            </script>
            <input type="button" id="ayuda_enlace" value="Ver m�s >>" onclick="ayuda()" class="form">
            <div id="ayuda_texto" style="position: absolute ; visibility: hidden">
            <br>
						<b>1.</b> Para cambiar el rango de un usuario debes seleccionar los usuarios que deseas modificar y luego seleccionar de la lista el rango
						deseado, si deseas que el usuario tome su rango por defecto, elige "Por n�mero de mensajes".<br><br>
						<b>2.</b> Para designar moderadores haz click en el bot�n "Moderador", luego selecciona los subforos en donde el usuario podr�
						moderar y por �ltimo haz click en "Designar Moderador".<br><br>
						<b>3.</b> Para borrar un moderador, haz click en el bot�n "Moderador", desmarca todas las casillas y haz click en
						"Designar Moderador", por �ltimo selecciona al usuario y cambia su rango a cualquier otro, el nivel por defecto que
						se le asign� al ser moderador fue de 500, aunque el rango no le dar� permisos de moderaci�n y s�lo afectar� la forma
						en que se comporte dentro de los permisos de cada subforo.<br><br>
						<b>4.</b> Para ver la fecha de registro y el IP de cada usuario s�lo pasa el cursor por encima del nick correspondiente.
            </div>
          </td>
        </tr>
      </table>
      <?
      if($desde > $mostrar) {
      $anteriores = $mostrar * 2 ;
      if($desde == $anteriores) {
      ?>
      <p align="right"><a href="foroadmin.php?administrar=usuarios<?if($letra){echo"&letra=$letra";}?>">Anteriores <?=$mostrar?> usuarios</a> | 
      <?
      }
      else {
      $anteriores = $desde - $mostrar * 2 ;
      ?>
      <p align="right"><a href="foroadmin.php?administrar=usuarios<?if($letra){echo"&letra=$letra";}?>&desde=<?=$anteriores?>">Anteriores <?=$mostrar?> usuarios</a> | 
      <?
      }
      }
      else {
      ?>
      <p align="right">
      <?
      }
      if($desde < $usuarios) {
      ?>
      <a href="foroadmin.php?administrar=usuarios<?if($letra){echo"&letra=$letra";}?>&desde=<?=$desde?>">Siguientes <?=$mostrar?> usuarios</a>
      <?
      }
      }
      }
      ?>
    </td>
  </tr>
</table>
<?
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
</body>
</html>
