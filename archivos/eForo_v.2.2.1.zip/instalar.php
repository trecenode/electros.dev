<?
// ***************************************************
// *** Compatibilidad con "Registro de usuarios 1" ***
// ***************************************************
// Si quieres usar la compatibilidad con el script "Registro de usuarios 1" escribe aqu� el nombre de la tabla
$tabla_usuarios = "eforo_usuarios" ;
// ********** Fin **********
if($id == 2) {
$contrasena2 = md5(md5($contrasena)) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena2,time()+7776000) ;
}
?>
<html>
<head>
<title>eForo v.2.2.1 - Instalaci�n</title>
<style>
body,table {
font-family: verdana ;
font-size: 10pt ;
}
.t1 {
font-size: 15pt ;
font-weight: bold ;
}
.form {
font-family: verdana ;
font-size: 8pt ;
border: #000000 1 solid ;
background: #cccccc ;
color: #000000 ;
}
</style>
</head>
<body style="margin-top: 100 ; margin-left: 250 ; margin-right: 250 ; margin-bottom: 100">
<div align="center">
<div class="t1">eForo v.2.2.1 - Instalaci�n</div>
<?
if(!$id) {
?>
<br>
Este archivo crear� las tablas necesarias en la base de datos para el funcionamiento de eForo.
<br><br>
El archivo <b>config.php</b> debe estar previamente configurado con los datos de conexi�n a la base de datos.
<br><br>
<input type="button" value="Siguiente" onclick="location='instalar.php?id=1'" class="form">
<?
}
if($id == 1) {
?>
<p>Para administrar el foro necesitas crear una cuenta de administrador, se crea una cuenta normal como si fueras un usuario,
pero en la configuraci�n se indicar� que eres el administrador, el cu�l m�s adelante puedes cambiar si lo deseas.
<form method="post" action="instalar.php?id=2">
<b>Administrador:</b><br>
<input type="text" name="nick" class="form"><br>
<b>Contrase�a:</b><br>
<input type="password" name="contrasena" class="form"><br>
<b>Email:</b><br>
<input type="text" name="email" class="form"><br><br>
<input type="submit" name="enviar" value="Siguiente" class="form">
</form>
<?
}
if($id == 2) {
include("config.php") ;
$instalacion = "
CREATE TABLE eforo_categorias (
  id tinyint(3) unsigned NOT NULL auto_increment,
  orden tinyint(3) unsigned NOT NULL default '0',
  categoria varchar(100) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY orden (orden)
) TYPE=MyISAM
;
CREATE TABLE eforo_config (
  administrador varchar(20) NOT NULL default '',
  email varchar(100) NOT NULL default '',
  titulo varchar(100) NOT NULL default '',
  temas tinyint(3) unsigned NOT NULL default '0',
  mensajes tinyint(3) unsigned NOT NULL default '0',
  ultimos tinyint(3) unsigned NOT NULL default '0',
  codigo enum('ON','OFF') NOT NULL default 'ON',
  caretos enum('ON','OFF') NOT NULL default 'ON',
  url enum('ON','OFF') NOT NULL default 'ON',
  censurar enum('ON','OFF') NOT NULL default 'ON',
  estilo varchar(30) NOT NULL default '',
  privados tinyint(3) unsigned NOT NULL default '0',
  avatarlargo smallint(5) unsigned NOT NULL default '0',
  avatarancho smallint(5) unsigned NOT NULL default '0',
  avatartamano smallint(5) unsigned NOT NULL default '0',
  htmlcab text NOT NULL,
  htmlpie text NOT NULL
) TYPE=MyISAM
;
CREATE TABLE eforo_enlinea (
  fecha int(10) unsigned NOT NULL default '0',
  ip varchar(15) NOT NULL default '',
  usuario varchar(20) NOT NULL default '',
  KEY fecha (fecha)
) TYPE=MyISAM
;
CREATE TABLE eforo_foros (
  id tinyint(3) unsigned NOT NULL auto_increment,
  orden tinyint(3) unsigned NOT NULL default '0',
  categoria tinyint(3) unsigned NOT NULL default '0',
  foro varchar(100) NOT NULL default '',
  descripcion tinytext NOT NULL,
  temas smallint(5) unsigned NOT NULL default '0',
  mensajes smallint(5) unsigned NOT NULL default '0',
  leer smallint(5) NOT NULL default '0',
  nuevo smallint(5) NOT NULL default '0',
  responder smallint(5) NOT NULL default '0',
  editar smallint(5) NOT NULL default '0',
  borrar smallint(5) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY orden (orden),
  KEY categoria (categoria)
) TYPE=MyISAM
;
CREATE TABLE eforo_mensajes (
  id smallint(5) unsigned NOT NULL auto_increment,
  foro tinyint(3) unsigned NOT NULL default '0',
  forotema smallint(5) unsigned NOT NULL default '0',
  foromostrar enum('0','1') NOT NULL default '0',
  visitas smallint(5) unsigned NOT NULL default '0',
  mensajes smallint(5) unsigned NOT NULL default '0',
  fecha int(10) unsigned NOT NULL default '0',
  usuario varchar(20) NOT NULL default '',
  tema varchar(100) NOT NULL default '',
  mensaje text NOT NULL,
  caretos enum('0','1') NOT NULL default '0',
  codigo enum('0','1') NOT NULL default '0',
  url enum('0','1') NOT NULL default '0',
  firma enum('0','1') NOT NULL default '0',
  aviso enum('0','1') NOT NULL default '0',
  editado int(10) unsigned NOT NULL default '0',
  ultimo int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY foro (foro,forotema,foromostrar)
) TYPE=MyISAM
;
CREATE TABLE eforo_moderadores (
  id smallint(5) unsigned NOT NULL auto_increment,
  foro smallint(5) unsigned NOT NULL default '0',
  moderador varchar(20) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM
;
CREATE TABLE eforo_privados (
  id smallint(5) unsigned NOT NULL auto_increment,
  nuevo enum('0','1') NOT NULL default '0',
  fecha int(10) unsigned NOT NULL default '0',
  remitente varchar(20) NOT NULL default '',
  destinatario varchar(20) NOT NULL default '',
  mensaje text NOT NULL,
  PRIMARY KEY  (id),
  KEY destinatario (destinatario)
) TYPE=MyISAM
;
CREATE TABLE eforo_rangos (
  rango smallint(5) NOT NULL default '0',
  minimo smallint(5) unsigned NOT NULL default '0',
  descripcion varchar(100) NOT NULL default '',
  PRIMARY KEY  (rango)
) TYPE=MyISAM
;
CREATE TABLE eforo_recientes (
  usuario varchar(20) NOT NULL default '',
  fecha int(10) unsigned NOT NULL default '0',
  foro smallint(5) unsigned NOT NULL default '0',
  mensaje smallint(5) unsigned NOT NULL default '0',
  KEY usuarios (usuario)
) TYPE=MyISAM
;
CREATE TABLE $tabla_usuarios (
  id smallint(5) unsigned NOT NULL auto_increment,
  fecha int(10) unsigned NOT NULL default '0',
  nick varchar(20) NOT NULL default '',
  contrasena varchar(20) NOT NULL default '',
  email varchar(40) NOT NULL default '',
  pais varchar(20) NOT NULL default '',
  edad tinyint(2) unsigned NOT NULL default '0',
  sexo enum('0','1') NOT NULL default '0',
  descripcion tinytext NOT NULL,
  web varchar(100) NOT NULL default '',
  firma text NOT NULL,
  ip varchar(15) NOT NULL default '',
  mensajes smallint(5) unsigned NOT NULL default '0',
  rango smallint(5) NOT NULL default '0',
  avatar char(3) NOT NULL default '',
  conectado int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY nick (nick,contrasena)
) TYPE=MyISAM
;
alter table $tabla_usuarios change sexo sexo enum('0','1') not null
;
alter table $tabla_usuarios add web varchar(100) not null after descripcion
;
alter table $tabla_usuarios add firma text not null after web
;
alter table $tabla_usuarios add mensajes smallint(5) unsigned not null after ip
;
alter table $tabla_usuarios add rango smallint(5) unsigned not null
;
alter table $tabla_usuarios add avatar char(3) not null
;
alter table $tabla_usuarios add conectado int(10) unsigned not null
;
insert into eforo_categorias (orden,categoria) values ('10','Categor�a de ejemplo')
;
insert into eforo_foros (orden,categoria,foro,descripcion,temas,mensajes) values ('10','1','Foro de ejemplo','Aqu� va la descripci�n','1','1')
;
insert into eforo_mensajes (foro,forotema,foromostrar,fecha,usuario,tema,mensaje,editado,ultimo) values ('1','1','1','$fecha','Electros','Gracias por usar eForo','Este foro se cre� para que cualquier pudiera tener un foro con todas las opciones que uno pudiera imaginar, que consume el m�nimo de recursos del servidor, es totalmente configurable ya que su c�digo muy sencillo y adem�s est� totalmente en espa�ol, esta es la 4ta versi�n que se ha sacado desde el original que fue la versi�n 1.0 que se public� el 18 de Agosto del 2003, espero que disfrutes de eForo, cualquier comentario o sugerencia son bienvenidos en la web\r\n\r\nAtte.\r\nElectros','$fecha','$fecha')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('-1','0','Banead@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('0','0','Invitad@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('1','0','Nuev@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('500','0','Moderador')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('999','0','Administrador')
;
insert into $tabla_usuarios (fecha,nick,email,contrasena,ip) values ('$fecha','$nick','$email','$contrasena','$REMOTE_ADDR')
;
update $tabla_usuarios set rango='1'
;
update $tabla_usuarios set conectado='$fecha'
;
update $tabla_usuarios set rango='999' where nick='$nick'
;
insert into eforo_config
(administrador,email,titulo,temas,mensajes,ultimos,codigo,caretos,url,censurar,estilo,avatarlargo,avatarancho,avatartamano,privados)
values ('$nick','$email','eForo v.2.2.1','25','15','15','ON','ON','ON','OFF','electros','50','150','150','50')
" ;
$fecha = time() ;
$instalacion = explode(";",$instalacion) ;
foreach($instalacion as $codigo) {
mysql_query("$codigo") ;
}
mysql_close($conectar) ;
?>
<p>La instalaci�n se ha completado con �xito.
<p>Ahora s�lo debes eliminar este archivo y listo, podr�s disfrutar de eForo.
<p><input type="button" value="Finalizar" onclick="location='foroadmin.php'" class="form">
<?
}
?>
</div>
</body>
</html>
