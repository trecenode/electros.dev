<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
if($entrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$contrasena = quitar($contrasena) ;
$resp = mysql_query("select id,contrasena from $tabla_usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) != 0) {
if($datos[contrasena] == $contrasena) {
$contrasena = md5(md5($contrasena)) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena,time()+7776000) ;
mysql_query("update $tabla_usuarios set ip='$REMOTE_ADDR' where id='$datos[id]'") ;
if(!$regresar) { $regresar = $HTTP_REFERER ; }
header("location: $regresar") ;
}
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_mensaje">
<tr>
<td>
La contrase�a es incorrecta. Haz click <a href="javascript:history.back()">aqu�</a> para regresar.
</td>
</tr>
</table>
<?
}
}
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_mensaje">
<tr>
<td>
Este usuario no existe en la base de datos. Haz click <a href="javascript:history.back()">aqu�</a> para regresar.
</td>
</tr>
</table>
<?
}
}
mysql_close($conectar) ;
?>
<html>
<head>
<title><?=$titulo_foro?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
echo $htmlcab ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Conectar</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<div align="center">
<form method="post" action="foroentrar.php">
<input type="hidden" name="regresar" value="<?=$HTTP_REFERER?>">
<b>Nick:</b><br>
<input type="text" name="nick" maxlength="20" class="form"><br>
<b>Contrase�a:</b><br>
<input type="password" name="contrasena" maxlength="20" class="form"><br><br>
<input type="submit" name="entrar" value="Entrar" class="form">
</form>
<p><a href="forocontrasena.php">Perd� mi contrase�a</a><br>
<a href="fororegistrar.php">Registrar nuevo usuario</a>
</div>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
<?
echo $htmlpie ;
?>
</body>
</html>
