<?
// ***************************************************
// *** Compatibilidad con "Registro de usuarios 1" ***
// ***************************************************
// Si quieres usar la compatibilidad con el script "Registro de usuarios 1" escribe aqu� el nombre de la tabla
$tabla_usuarios = "eforo_usuarios" ;
// ********** Fin **********
if($id == 2) {
include("config.php") ;
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($resp) ;
$contrasena = md5(md5($datos[contrasena])) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena,time()+7776000) ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
}
?>
<html>
<head>
<title>eForo v.2.2.1 - Actualizaci�n</title>
<style>
body,table {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
.t1 {
font-size: 15pt ;
font-weight: bold ;
}
.form {
font-family: verdana ;
font-size: 8pt ;
border: #000000 1 solid ;
background: #cccccc ;
color: #000000 ;
}
</style>
</head>
<body style="margin: 100">
<div align="center">
<div class="t1">eForo v.2.2.1 - Actualizaci�n</div>
<?
if(!$id) {
?>
<br>
Con este parche se actualizar� la base de datos para que sea compatible con las nuevas opciones de eForo, esta versi�n actualiza
desde la versi�n 2.0 hasta la m�s actual.
<br><br>
<input type="button" value="Siguiente" onclick="location='instalar_actualizar.php?id=1'" class="form">
<?
}
if($id == 1) {
?>
<p>Escribe aqu� el nick de administrador y tu email, recuerda que debe ser el mismo nick con el que administrabas anteriormente
el foro, estos datos se guardar�n en la configuraci�n del foro.
<form method="post" action="instalar_actualizar.php?id=2">
<b>Administrador:</b><br>
<input type="text" name="nick" class="form"><br>
<b>Email:</b><br>
<input type="text" name="email" class="form"><br><br>
<input type="submit" name="enviar" value="Siguiente" class="form">
</form>
<?
}
if($id == 2) {
include("config.php") ;
$instalacion = "
alter table eforo_foros
add leer smallint(5) not null,
add nuevo smallint(5) not null,
add responder smallint(5) not null,
add editar smallint(5) not null,
add borrar smallint(5) not null
;
alter table eforo_mensajes
change foromostrar foromostrar enum('0','1') not null,
add caretos enum('0','1') not null,
add codigo enum('0','1') not null,
add url enum('0','1') not null,
add firma enum('0','1') not null,
add aviso enum('0','1') not null
;
alter table eforo_privados
change nuevo nuevo enum('0','1') not null,
change mensaje mensaje text not null
;
alter table $tabla_usuarios change sexo sexo enum('0','1') not null
;
alter table $tabla_usuarios add web varchar(100) not null after descripcion
;
alter table $tabla_usuarios add firma text not null after web
;
alter table $tabla_usuarios add mensajes smallint(5) unsigned not null after ip
;
alter table $tabla_usuarios add rango smallint(5) unsigned not null
;
alter table $tabla_usuarios add avatar char(3) not null
;
alter table $tabla_usuarios add conectado int(10) unsigned not null
;
DROP TABLE IF EXISTS eforo_config
;
CREATE TABLE eforo_config (
  administrador varchar(20) NOT NULL default '',
  email varchar(100) NOT NULL default '',
  titulo varchar(100) NOT NULL default '',
  temas tinyint(3) unsigned NOT NULL default '0',
  mensajes tinyint(3) unsigned NOT NULL default '0',
  ultimos tinyint(3) unsigned NOT NULL default '0',
  codigo enum('ON','OFF') NOT NULL default 'ON',
  caretos enum('ON','OFF') NOT NULL default 'ON',
  url enum('ON','OFF') NOT NULL default 'ON',
  censurar enum('ON','OFF') NOT NULL default 'ON',
  estilo varchar(30) NOT NULL default '',
  privados tinyint(3) unsigned NOT NULL default '0',
  avatarlargo smallint(5) unsigned NOT NULL default '0',
  avatarancho smallint(5) unsigned NOT NULL default '0',
  avatartamano smallint(5) unsigned NOT NULL default '0'
) TYPE=MyISAM
;
CREATE TABLE eforo_moderadores (
  id smallint(5) unsigned NOT NULL auto_increment,
  foro smallint(5) unsigned NOT NULL default '0',
  moderador varchar(20) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM
;
CREATE TABLE eforo_rangos (
  rango smallint(5) NOT NULL default '0',
  minimo smallint(5) unsigned NOT NULL default '0',
  descripcion varchar(100) NOT NULL default '',
  PRIMARY KEY  (rango)
) TYPE=MyISAM
;
CREATE TABLE eforo_recientes (
  usuario varchar(20) NOT NULL default '',
  fecha date NOT NULL default '0000-00-00',
  foro smallint(5) unsigned NOT NULL default '0',
  mensaje smallint(5) unsigned NOT NULL default '0',
  KEY usuarios (usuario)
) TYPE=MyISAM
;
insert into eforo_rangos (rango,minimo,descripcion) values ('-1','0','Banead@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('0','0','Invitad@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('1','0','Nuev@')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('500','0','Moderador')
;
insert into eforo_rangos (rango,minimo,descripcion) values ('999','0','Administrador')
;
update $tabla_usuarios set rango='1'
;
update $tabla_usuarios set conectado='$fecha'
;
update $tabla_usuarios set rango='999' where nick='$nick'
;
update eforo_mensajes set caretos='1',codigo='1',url='1',firma='1'
;
insert into eforo_config
(administrador,email,titulo,temas,mensajes,ultimos,codigo,caretos,url,censurar,estilo,privados,avatarlargo,avatarancho,avatartamano)
values ('$nick','$email','eForo v.2.2.1','25','15','15','ON','ON','ON','OFF','electros','50','150','150','50')
;
update eforo_config set email='$email',titulo='eForo v.2.2.1'
;
alter table eforo_config
add email varchar(100) not null after administrador,
add titulo varchar(100) not null after email
;
alter table eforo_config
add htmlcab text not null,
add htmlpie text not null
" ;
$fecha = time() ;
$instalacion = explode(";",$instalacion) ;
foreach($instalacion as $codigo) {
mysql_query("$codigo") ;
}
mysql_close($conectar) ;
?>
<p>La instalaci�n se ha completado con �xito.
<p>Ahora s�lo debes eliminar este archivo y listo, podr�s disfrutar de eForo.
<p><input type="button" value="Finalizar" onclick="location='foroadmin.php'" class="form">
<?
}
?>
</div>
</body>
</html>
