<?
// ****************************
// *** eForo v.2.2.1        ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
ob_start() ;
?>
<html>
<head>
<title><?=$titulo_foro?></title>
<?
include("eforo_estilo/$estilo/$estilo.php") ;
?>
</head>
<body>
<?
echo $htmlcab ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Recuperaci�n de contrase�a</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<?
if($enviar) {
	if(!$_COOKIE[urecuperacion]) {
	$resp = mysql_query("select nick,contrasena from $tabla_usuarios where email='$email'") ;
	$usuarios = mysql_num_rows($resp) ;
		if($usuarios != 0) {
		$datos = mysql_fetch_array($resp) ;
		$mensaje = "
		<style>
		.tabla {
		font-family: verdana ;
		font-size: 10pt ;
		}
		.enlace {
		color: #000000 ;
		text-decoration: none ;
		font-weight: bold ;
		}
		</style>
		<p>Estos son tus datos de registro:
		<p>Nick: <b>$datos[nick]</b><br>
		Contrase�a: <b>$datos[contrasena]</b>
		<p>-----------------------------------<br>
		Estos datos se te enviaron debido a que solicitaste tus datos de registro en el foro de <b>$titulo_foro</b>, si tu no
		pediste estos datos alguien registr� una cuenta en el foro con este email, para eliminar estos datos contacta al
		administrador del foro mediante este email <a href=\"mailto:$administrador_email\">$administrador_email</a>.
		" ;
		mail($email,"$titulo_foro :: Recuperaci�n de contrase�a",$mensaje,"Content-Type: text/html\nFrom: $administrador <$administrador_email>") ;
		setcookie("urecuperacion","urecuperacion",time()+1800) ;
		echo "<p>Se te ha enviado un email con tus datos de registro." ;
		}
		else {
		echo "<p>No existe ning�n usuario con este email. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
		}
	mysql_free_result($resp) ;
	}
	else {
	echo "<p>Por seguridad s�lo puedes pedir tus datos una vez cada media hora." ;
	}
}
else {
?>
<p>Para recuperar tus datos debes escribir el email con el que te registraste en la web.
<script>
enviado = 0 ;
function revisar() {
if(formulario.email.value == "") { alert('Debes poner un email v�lido.') ; return false ; }
if(enviado == 0) { enviado++ ; } else { alert('Los datos se est�n enviando por favor espera.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="forocontrasena.php" onsubmit="return revisar()">
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="email" maxlength="40" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
ob_end_flush() ;
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
<?
echo $htmlpie ;
?>
</body>
</html>
