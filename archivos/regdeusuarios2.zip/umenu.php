<?
if($_COOKIE["unick"]) {
?>
Bienvenido <b><? echo $_COOKIE["unick"] ?></b>
<a href="pagina1.php">Enlace 1</a>
<a href="pagina2.php">Enlace 1</a>
<a href="pagina3.php">Enlace 1</a>
<?
}
else {
?>
<form method="post" action="uentrar.php">
Nick:<br>
<input type="text" name="nick"><br>
Contrase�a:<br>
<input type="password" name="contrasena"><br><br>
<input type="submit" name="entrar" value="Entrar">
</form>
<?
}
?>