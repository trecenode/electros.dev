<?
//************************************
//***********Realizado Por:***********
//*************eliascm36**************
//***************Email:***************
//*********eliascm36@hotmail.com******
//**************Version:**************
//****************1.0*****************
//************************************
?>
<? include("config.php") ?>
<?
$consulta = mysql_query("select email from usuarios order by id desc") ;
while($datos = mysql_fetch_array($consulta)) { 
?>
<? 
$nuevo .= "<?";
$nuevo .= "=";
$nuevo .= "'";
$nuevo .= "$datos[email],";
$nuevo .= "' ;";
$nuevo .= "?>";
$crea = fopen("datos/boletin.php","w");
fputs($crea,$nuevo);
fclose($crea);
?>
<?
}
?>
<?
if($_POST[enviar]) {
mail($_POST[boletin],$_POST[asunto],$_POST[mensaje],"From: $_POST[nombre] <$_POST[email]>") ;
echo "El email ha sido enviado con �xito." ;
}
?>
<form method="post" action="<?=$_SERVER[PHP_SELF]?>">
 Usuarios:<br>
<input name="boletin" type="text" id="boletin" value="<? include("datos/boletin.php") ?>">
<br>
Nombre:<br>
<input name="nombre" type="text">
<br>
Email:<br>
<input name="email" type="text" id="email"><br>
Asunto:<br>
<input name="asunto" type="text" id="asunto">
<br>
Mensaje:<br>
<textarea name="mensaje" cols="30" rows="5"></textarea>
<br>
<br>
<input type="submit" name="enviar" value="Enviar">
</form>
