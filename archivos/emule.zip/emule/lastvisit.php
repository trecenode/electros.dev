<?php
include("config.php");
$lvisit[1] = "select * from users where usuario = '$HTTP_COOKIE_VARS[username]' and password = '$HTTP_COOKIE_VARS[userpass]'";
$lvisit[2] = mysql_query($lvisit[1]);
$finalresult = mysql_num_rows($lvisit[2]); 
if($finalresult >= 1){

$fecha = date("j-n-y");
$unixt = getdate();
$visitaus = "update users set minutos = '$unixt[minutes]', hora = '$unixt[hours]', fecha = '$fecha' WHERE usuario = '$HTTP_COOKIE_VARS[username]' and password = '$HTTP_COOKIE_VARS[userpass]'";                           
$addminut = mysql_query($visitaus);
}
else{
	
$ip = getenv("REMOTE_ADDR");
$fecha = date("j-n-y");
$unixt = getdate();
	//INSERTAR DATOS
$inip = "INSERT INTO visitantes (ip, hora, minutos, fecha) values ('$ip', '$unixt[hours]', '$unixt[minutes]', '$fecha')";
$echoini = mysql_query($inip, $conect);
$actdat = "update visitantes set hora = '$unixt[hours]', minutos = '$unixt[minutes]', fecha = '$fecha', ip = '$ip'  WHERE ip = '$ip'";                           
$actdat2 = mysql_query($actdat, $conect);
}
?>