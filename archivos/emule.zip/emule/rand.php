<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

$rand[0] = "Select * from elinks order by Rand()";
$rand[1] = MySql_Query($rand[0]);
$rande = MySql_Fetch_Array($rand[1]);

$relink = ereg_replace(" ", "-", $rande[nombre]);

echo "<a href=elink/$rande[id]/$relink/><img border=0 alt=$relink src=$rande[imagen] width=113 height=157></a><br><a href=elink/$rande[id]/$relink/>$rande[nombre]</a>";

?>
