<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

include('config.php');


$totalelinks[0] = "Select * from elinks";
$totalelinks[1] = MySql_Query($totalelinks[0]);
$totalelinkss = MySql_Num_Rows($totalelinks[1]);
echo "<br><font face=Verdana size=2>Total de Elinks/Descargas: <b>$totalelinkss</b></br>";
echo "<hr>";


if(empty($elinks) and empty($ficha) and empty($registro) and empty($panel) and empty($perfil) and empty($buscar)){
echo "<title>$title</title>";
$ExP = 15;   
$Des = $ExP * $Pag;
$news[1] = "Select * from elinks order by id desc Limit $Des, $ExP";
$news[2] = MySql_Query($news[1]);
while($new = MySql_Fetch_Array($news[2])){
$fil = ereg_replace(" ", "-", $new[nombre]);	
        if(strlen($new[descripcion]) > 10) {
            $desri = substr($new[descripcion],0,150);
            $desri .= "...";
        }
echo '<font Face="Verdana" Size="1" color="000000">';
echo '<table border="1" cellpadding="0" cellspacing="0"  bordercolor="#111111" width="500" height="1" style="border-style:dotted; border-color:#FF9900; border-collapse: collapse; " bgcolor="#FF9933">
      <tr>
      <td width="100%" colspan="2" height="19" bgcolor="#006699">
      <font face="Verdana" size="1" color="#0099CC"><b>Archivo:</b> </font>
      <font face="Verdana" size="1" color="#FFFFFF">'.$new[nombre].'</font></td>
      </tr>
      <tr>
      <td width="27%" height="1" bgcolor="#FFFFFF">
      <font face="Verdana" size="1" color="#000000">
      <img border="0" src="'.$new[imagen].'" width="110" height="160"></font></td>
      <td width="73%" height="1" bgcolor="#FFFFFF">
      <font face="Verdana" size="1" color="#000000">
      '.$desri.'
      <font face="Verdana" size="1"><b><font color="#0099CC"></font></b><font color="#000000"> </font> <a href=elink/'.$new[id].'/'.$fil.'/>
      Leer Mas</a></font></td>
      </tr>
      </table>';
      echo "</font><p>";
      
}
$pagi[1] = "Select * from elinks";
$pagi[2] = MySql_Query($pagi[1]);
$pagi[3]= MySql_Num_Rows($pagi[2]);
$page = $pagi[3] / $ExP;
echo "<p align=center><font face=Verdana Size=1>";

if($Pag == ''){ $prev = ''; }
if($Pag >= 1){ $prev = $Pag - 1; echo "<a href=noticias/$prev/>< Anterior</a>|"; }

for ($x = 0; $x <= $page;$x++) {
echo "|<a href=noticias/$x/>$x</a>|";
}
if($Pag >= 0 and $Pag < $x){ $next = $Pag + 1; echo "<a href=noticias/$next/>Siguiente ></a>"; }
}








if(isset($elinks)){
//Cantidad de Elinks por Pagina////	
$ExP = 20;                       //
///////////////////////////////////	
$Des = $ExP * $Sec;
$elink[0] = "Select * from elinks where categoria = '$elinks' order by id asc Limit $Des, $ExP";	
$elink[1] = MySql_Query($elink[0]);
$name = "Select * from categorias where id = '$elinks'";
$name = MySql_Query($name);
$name = MySql_Fetch_Array($name);
$name = $name[nombre];
$nca = norepeat (elinks, categoria, $elinks);
echo "<title>Descargar Elinks $name Gratis</title>";
echo "<center><font size=1 face=Verdana color=000000>Numero de Elinks en esta categoria: $nca";
while($file = MySql_Fetch_Array($elink[1]))
{
$cam = ereg_replace(" ", "-", $file[nombre]);	
$c++;	
echo "<div align=left><br>$c.- $file[nombre] - <a href=elink/$file[id]/$cam/>Ver Ficha</a>";	
}
$pagi[1] = "Select * from elinks where categoria = '$elinks'";
$pagi[2] = MySql_Query($pagi[1]);
$pagi[3]= MySql_Num_Rows($pagi[2]);
$page = $pagi[3] / $ExP;
echo "<p align=center>";
$names = ereg_replace(" ", "-", $name);
if($Sec == ''){ $prev = ''; }
if($Sec >= 1){ $prev = $Sec - 1; echo "<a href=elinks/$elinks/$prev/$names/>< Anterior</a>|"; }
for ($x = 0; $x <= $page;$x++) {
echo "|<a href=elinks/$elinks/$x/$names/>$x</a>|";
}
if($Sec >= 0 and $Sec < $x){ $next = $Sec + 1; echo "<a href=elinks/$elinks/$next/$names/>Siguiente ></a>"; }
}








if(isset($ficha)){
$ed2k[0] = "Select * from elinks where id = '$ficha'";
$ed2k[1] = MySql_Query($ed2k[0]);
$elink = MySql_Fetch_Array($ed2k[1]);
echo "<title>Descargar Elink Gratis $elink[nombre]</title>";
if($elink[idioma] == 'Spanish'){ $lang = "Images/spanish.gif"; }
if($elink[idioma] == 'English'){ $lang = "Images/english.gif"; }

echo '<table border="1" cellpadding="0" cellspacing="0" style="border:1px dotted #FF9900; border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber1" height="230">
      <tr>
      <td width="100%" colspan="2" height="19" bgcolor="#336699"><b><font face="Verdana" size="1">
      <font color="#0099FF">Elink:</font><font color="#000000"> </font>
      <font color="#FFFFFF">'.$elink[nombre].'</font></font><font color="#FFFFFF"> </font>
      </b></td>
      </tr>
      <tr>
      <td width="38%" height="209">
      <font face="Verdana" size="1" color="#000000"><b>
      <img border="0" src="'.$elink[imagen].'" align="left" width="150" height="211"></b></font></td>
      <td width="62%" height="209">
      <p align="center"><b><font face="Verdana" size="1" color="#000000">
      '.$elink[descripcion].'</b><br>
      <font face="Verdana" size="1" color="#336699"><b>Lenguaje: <img src="'.$lang.'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </b></font>
      <font color="#336699">
      <br></font><font face="Verdana" size="1" color="#336699"><b>Visitas: '.$elink[hits].'</b></font></p>
      </td>
      </tr>
      <tr>
      <td width="100%" colspan="2" height="1">'; 
      
$usec[0] = "Select * from users where usuario = '$HTTP_COOKIE_VARS[username]' and password = '$HTTP_COOKIE_VARS[userpass]'";
$usec[1] = MySql_Query($usec[0]); 	
$usec[2] = MySql_Num_Rows($usec[1]);
if($usec[2] == 1){
echo "<Font face=Verdana size=2 color=000000>";
if(isset($elink[titulo1]) and isset($elink[elink1])){
echo "Descargar: <a href=$elink[elink1]>$elink[titulo1]</a>";
}
if(isset($elink[titulo2]) and isset($elink[elink2])){
echo " <a href=$elink[elink2]>$elink[titulo2]</a>";
}
if(isset($elink[titulo3]) and isset($elink[elink3])){
echo " <a href=$elink[elink3]>$elink[titulo3]</a>";
}
if(isset($elink[titulo4]) and isset($elink[elink4])){
echo " <a href=$elink[elink4]>$elink[titulo4]</a>";
}
if(isset($elink[titulo5]) and isset($elink[elink5])){
echo " <a href=$elink[elink5]>$elink[titulo5]</a>";
}
}
else{
	echo "<font size=1 face=Verdana>Necesitas <a href=index.php?registro=go>Registrarte</a> Para descargar el Archivo!";
}

echo '</td>
      </tr>
      </table>';
      
$update[0] = $elink[hits] + 1;
$update[1] = "update elinks set hits = '$update[0]' where id = '$ficha'";
$update[2] = MySql_Query($update[1]);
}


if(isset($registro)){
	
	if($registro == 'go'){
	echo "<title>Registro de Usuario</title>";
	echo '<table align="center" border="1" cellpadding="0" cellspacing="0" style="border:1px dashed #C0C0C0; border-collapse: collapse; background-color:#006699" bordercolor="#111111" width="35%" id="AutoNumber1">
    <form method="POST" action="?registro=alta">
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Usuario:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="text" name="usuario" size="20"></b></font></td>
    </tr>
    <tr>
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Password:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="password" name="password" size="20"></b></font></td>
    </tr>
    <tr>
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Confirmar Password:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="password" name="passwordconf" size="20"></b></font></td>
    </tr>
    <tr>
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Pagina:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="text" name="pagina" size="20"></b></font></td>
    </tr>
    <tr>
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Edad:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="text" name="edad" size="20"></b></font></td>
    </tr>
    <tr>
    <td width="50%"><b><font face="Verdana" size="2" color="#000000">Correo:</font></b></td>
    <td width="50%">
    <p align="center"><font color="#000000">
    <b>
    <input type="text" name="correo" size="20" value="@"></b></font></td>
    </tr>
    <tr>
    <td width="100%" colspan="2">
    <p align="center"><b><font color="#000000" face="Verdana" size="2">Suscribir 
    al bolet�n: </font><font color="#000000">
    <br></font><font color="#000000" face="Verdana" size="2">Si<input type="radio" value="1" checked name="R1">No<input type="radio" name="R1" value="2"></font><font color="#000000" face="Verdana" size="2"> </font></b>
    </td>
    </tr>
    <tr>
    <td width="100%" colspan="2">
    <p align="center"><font color="#000000"><input type="submit" name="alta" value="Registro"></font></td>
    </tr>
    </form>
    </table>';
}

if($registro == 'alta'){
if(empty($HTTP_POST_VARS[usuario]) or empty($password) or empty($passwordconf) or empty($edad) or empty($correo)){
echo "<center><font color=000000 size=1 face=Verdana>Todos los campos son requeridos!";	
}
else{
if($password == $passwordconf){
	if(norepeat(users, usuario, $usuario) >= 1){
		echo "<center><font color=000000 size=1 face=Verdana>Ese nombre de Usuario ya esta en uso!";
	}
	else{
		if(norepeat(users, correo, $correo) >= 1){
		echo "<center><font color=000000 size=1 face=Verdana>Ese correo ya esta en uso!";
	   }
	   else{
		   //Insertar Datos
		   $passmd5 = md5($password);
		   $ualta[0] = "Insert Into users (id, usuario, password, pagina, edad, correo, rango, puntos, boletin) Values ('', '$usuario', '$passmd5', '$pagina', '$edad', '$correo', '0', '0', '$R1')";
		   $ualta[1] = MySql_Query($ualta[0]);
		   echo "<center><font color=000000 size=1 face=Verdana>Registro Finalizado!";
		   //Fin de Insertar Datos
	   }
	}
	}

else{
echo "<center><font color=000000 size=1 face=Verdana>Las contrase�as no son iguales!";	
}
}	
}
}


if(isset($panel)){
	
$upan[0] = "Select * from users where usuario = '$HTTP_COOKIE_VARS[username]' and password = '$HTTP_COOKIE_VARS[userpass]'";
$upan[1] = MySql_Query($upan[0]); 	
$upan[2] = MySql_Num_Rows($upan[1]);
$uns = MySql_Fetch_Array($upan[1]);
if($upan[2] == 1){
	echo "<title>Panel de Usuario</title>";
	echo "<p align=center><font color=000000 size=2 face=Verdana>Hola: $uns[usuario]";
	if($uns[avatar] == ''){ $avatar = "Images/blank.gif"; } else{ $avatar = $uns[avatar]; }
	echo "<br><img src=$avatar></p>";
	echo '<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="277" id="AutoNumber1">
          <tr>
          <td width="60">
          <p align="center"><a href="editardatos.html"><img border="0" alt="Editar Datos" src="Images/cuenta/home.gif" width="47" height="46"></a></td>
          <td width="60">
          <p align="center">
          <a href="enviarelink.html">
          <img border="0" alt="Enviar Elink!" src="Images/cuenta/info.gif" width="47" height="46"></a></td>
          <td width="60">
          <p align="center">
          <a href="cambiaravatar.html">
          <img border="0" alt="Cambiar Avatar" src="Images/cuenta/comments.gif" width="47" height="46"></a></td>
          <td width="60">
          <p align="center">
          <a href="salir.php">
          <img border="0" alt="Salir" src="Images/cuenta/exit.gif" width="47" height="46"></a></td>
          </tr>
          </table>';
          
          if($op == 'editdatos'){
	          $edit[0] = "Select * from users where usuario = '$HTTP_COOKIE_VARS[username]'";
	          $edit[1] = MySql_Query($edit[0]);
	          $editus = MySql_Fetch_Array($edit[1]);
	      echo "<p align=center><font face=Verdana size=2 color=000000><b>- Edita tus datos -";
	      echo '<form method="POST" action="editardatos.html">
                <p align="center">
                <font face="Verdana"><b><font size="1">(Solo Para cambiar)Password:
                <br>
                </font>
                <input type="password" name="contrpas" size="20"><font size="1">
                <br>
                Pagina:
                <br>
                </font>
                <input type="text" name="pagina" value="'.$editus[pagina].'" size="20"><font size="1">
                <br>
                Edad:
                <br>
                </font>
                <input type="text" name="edad" value="'.$editus[edad].'" size="20"><font size="1">
                <br>
                Correo:
                <br>
                </font>
                <input type="text" name="correo" value="'.$editus[correo].'" size="20"><font size="1">
                <br>
                </font>
                <input type="submit" value="Editar!" name="editpan"></b></font></p>
                </form>';
                    if($HTTP_POST_VARS[editpan] == True){
	                if(empty($contrpas)){}
	                else{
		                $passmd5s = md5($contrpas);
		                $changep[1] = "UPDATE users SET password = '$passmd5s' WHERE usuario = '$HTTP_COOKIE_VARS[username]'"; 
		                $changep[2] = MySql_Query($changep[1]);
		                echo "<center>Password Cambiado, ahora tiene que <a href=salir.php>Salir</a> y hacer login con el nuevo Password!<br>";
	                    }
	                    $changed[1] = "UPDATE users SET pagina = '$pagina', edad = '$edad', correo = '$correo' WHERE usuario = '$HTTP_COOKIE_VARS[username]'"; 
		                $changed[2] = MySql_Query($changed[1]);
		                echo "<br><center>Datos Cambiados!";
                }
                }
                if($op == 'avatar'){
	                $galer = "avatars";
                    $directorio = opendir("$galer");
                    echo "<form method=post action=cambiaravatar.html>";

                    echo '<p align="center"><select name="newavatar" size="1">';
                    while($archivo = readdir($directorio))
                    {
	               
                    $path = pathinfo($archivo);
                    if($path[extension] == jpg or $path[extension] == gif or $path[extension] == png){
                    echo "<option value=$galer/$archivo>$archivo</option>";
                    }
                    }
                   
                    echo "</select>";
                    echo "<br><input type=submit name=changeavatar value=Cambiar>";
                    echo "</form>";
                    
                 
                  
                    if($HTTP_POST_VARS[changeavatar] == True){
	                    $changea[1] = "UPDATE users SET avatar = '$newavatar' WHERE usuario = '$HTTP_COOKIE_VARS[username]'"; 
		                $changea[2] = MySql_Query($changea[1]);
		                echo "<br><center>Avatar Cambiado!";
                    }
                   
               }
               
               if($op == 'enviarelink'){
	              echo "<p align=center><font size=1 face=Verdana>- Envia Tus Elinks -</p>";
	              echo "<p align=center><font size=1 face=Verdana>*Para que tu elink sea visto antes tiene que ser aprobado por un administrador.</p>";
	              echo '<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="245" id="AutoNumber1" bgcolor="#006699">
                        <form method="POST" action="enviarelink.html" enctype="multipart/form-data">
                        <td align="left" width="51"><b>
                        <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
                        <td align="center" width="191"><font color="#FFFFFF">
                        <input type="text" name="nombre" size="20"></font></td>
                        </tr>
                        <tr>
                        <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Descripci�n:</font></b></td>
                        <td align="center" width="191"><textarea rows="5" name="desc" cols="15"></textarea></td>
                        </tr>
                        <tr>
                        <td align="left" width="51"><b>
                        <font face="Verdana" size="2" color="#FFFFFF">Idioma</font></b></td>
                        <td align="center" width="191"><select size="1" name="lang">
                        <option value="Spanish">Spanish</option>
                        <option value="English">English</option>
                        </select></td>
                        </tr>
                        <tr>
                        <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Imagen:</font></b></td>
                        <td align="center" width="191"><input type="file" name="archivo" size="5"></td>
                        </tr>
                        <tr>
                        <td align="left" width="121">
                        <font face="Verdana" size="2" color="#FFFFFF"><b>Categoria:</b></font></td>
                        <td align="center" width="121">
                        <select size="1" name="categoria">'; 
                        $edon = "Select * from categorias";
                        $edon2 = mysql_query($edon);
                        while($emule = mysql_fetch_array($edon2)){
                        echo "<option value=$emule[id]>$emule[nombre]</option>";
                        }
                 echo  '</select></td>
                        </tr>
                        <tr>
                        <td align="center" width="242" colspan="2">
                        <font face="Verdana" size="2" color="#FFFFFF"><b>Elinks:</b></font></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 1</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="archivo1" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Elink 1</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="elink1" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 2</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="archivo2" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Elink 2</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="elink2" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 3</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="archivo3" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Elink 3</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="elink3" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 4</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="archivo4" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Elink 4</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="elink4" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 5</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="archivo5" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="121">
                        <b><font face="Verdana" size="2" color="#FFFFFF">Elink 5</font></b></td>
                        <td align="center" width="121">
                        <input type="text" name="elink5" size="19"></td>
                        </tr>
                        <tr>
                        <td align="center" width="242" colspan="2">
                        <input type="submit" value="Enviar!" name="addelink"></td>
                        </tr>
                        </form>
                        </table>';
                        if(isset($HTTP_POST_VARS[addelink])){
                        if(empty($nombre)){ die("<center><font size=2 face=Verdana>Campo Nombre Vacio"); }
                        if(empty($desc)){ die("<center><font size=2 face=Verdana>Campo Descripcion Vacio"); }
                        if(empty($archivo)){ die("<center><font size=2 face=Verdana>Campo Imagen Vacio"); }
                        if(norepeat(elinks, nombre, $nombre) >= 1){
		                echo "<center><font size=2 face=Verdana>Error, Elink Repetido";
                        }
                        else{
                        //
                        $ext = explode(".",$archivo_name); 
                        $num = count($ext)-1; 
                        if($ext[$num] == "gif" or $ext[$num] == "jpg") 
                        { 
                        if($archivo_size < 30000) 
                        { 
                        if(!copy($archivo, "users/".$archivo_name) )
                        { 
                        echo "<center><font size=2 face=Verdana>Error al copiar el archivo"; 
                        } 
                        else 
                        { 
                        echo "<center><font size=2 face=Verdana>Archivo subido con exito"; 
                        } 
                        } 
                        else 
                        { 
                        echo "<center><font size=2 face=Verdana>La Imagen supera los 30kb"; 
                        } 
                        } 
                        else 
                        { 
                        echo "El Archivo no es valido, solo .gif o .jpg"; 
                        } 
                        //
                        $img = "users/$archivo_name";
                        if($uns[rango] >= '1'){ $type = 'elinks'; } if($uns[rango] <= '0'){ $type = 'elinksu'; }
                        if($uns[rango] >= '1'){
	                     $punto = $uns[puntos] + 1;
	                     $sumuser[0] = "UPDATE users SET puntos = '$punto' WHERE usuario = '$uns[usuario]'"; 
	                     $sumuser[1] = MySql_Query($sumuser[0]);   
                        }
                        $ed2k[1] = "Insert Into $type (id, nombre, descripcion, idioma, imagen, hits, categoria, titulo1, elink1, titulo2, elink2, titulo3, elink3, titulo4, elink4, titulo5, elink5, uploader) Values 
                        ('', '$nombre', '$desc', '$lang', '$img', '0', '$categoria', '$archivo1', '$elink1', '$archivo2', '$elink2', '$archivo3', '$elink3', '$archivo4', '$elink4', '$archivo5', '$elink5', '$HTTP_COOKIE_VARS[username]')";
                        $ed2k[2] = MySql_Query($ed2k[1]);  
                        if($ed2k[2] == True){
	                    echo "<center><font size=2 face=Verdana>Elink Agregado Correctamente!";
                        }
                        else{
                        echo "<center><font size=2 face=Verdana>Error al Agregar el Elink!";
                        }          
                        }
                        }


}
}
else{
	echo "<p align=center><font color=FF0000 size=2 face=Verdana>No estas autorizado para entrar!";
}
}

if(isset($perfil)){
	echo "<title>Perfil de Usuario</title>";
	$puser[0] = "Select * from users where id = '$perfil'";
	$puser[1] = MySql_Query($puser[0]);
	$puser[2] = MySql_Num_Rows($puser[1]);
	
	if($puser[2] == 1){
	$pus = MySql_Fetch_Array($puser[1]);
	if($pus[avatar] == ''){ $avatar = "Images/blank.gif"; } else{ $avatar = "$pus[avatar]"; }
	if($pus[rango] == '1'){ $rango = "<font color=FF0000>Uploader"; } else{ $rango = "Usuario"; }
	echo '<table align="center" border="1" cellpadding="0" cellspacing="0" style="border:3px double #006699; border-collapse: collapse; font-family:Verdana; font-size:8pt; color:#000080; font-weight:bold; background-color:#CCCCCC" bordercolor="#111111" width="56%" id="AutoNumber1">
          <tr>
          <td width="100%" colspan="2"><b><font face="Verdana" size="1">Usuario: '.$pus[usuario].'</font>
          </b>
          </td>
          </tr>
          <tr>
          <td width="20%">
          <p align="center">
          <img border="0" src="'.$avatar.'" width="69" height="85"></td>
          <td width="80%"><b><font size="1" face="Verdana">Pagina: '.$pus[pagina].'
          <br>Edad: '.$pus[edad].'<br>Correo: '.$pus[correo].'<br> Rango: '.$rango.'<br></font>Elinks Enviados: '.$pus[puntos].'</font></b></td>
          </tr>
          </table>';
      }
      else{
	      echo "<Font size=1 face=Verdana>El Usuario No Existe!</font>";
      }
}

if(isset($buscar)){
	echo "<title>Buscador de Elinks</title>";
	if(empty($word)){
		echo "<Font size=1 face=Verdana>Debes especificar tu busqueda!</font>";
	}
	else{
	
	$buscar1 = "Select * from elinks where nombre like '%$word%'";
	$buscar2 = MySql_Query($buscar1);
	$buscar3 = MySql_Num_Rows($buscar2);
	if($buscar3 >= '1'){
		echo "<Font size=1 face=Verdana>Resultados:</font><p>";
		echo "<div align=left>";
		while($pal = MySql_Fetch_Array($buscar2)){
			$w++;
			$none = ereg_replace(" ", "-", $pal[nombre]);
			echo "$w.- <a href=elink/$pal[id]/$none/>$pal[nombre]</a><br>";
		}
	}
	else{
		echo "<Font size=1 face=Verdana>No se encontraron resultados!</font>";
	}
		
}
}
?>
