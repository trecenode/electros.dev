<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

echo'<form method="POST" action="buscar.html">
     <p align="center">
     <b><font face="Verdana" size="2">Palabra: </font></b>
     <br>
     <input type="text" name="word" size="15">
     <br>
     <input type="submit" value="Buscar!" name="buscar"></p>
     </form>';
?>
