<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

$dbhost = "localhost"; 
$dbuser = "root";
$dbpass = "";
$db = "";
$conect = @mysql_connect("$dbhost","$dbuser","$dbpass");
@mysql_select_db("$db");

$title = "Tupagina.com: Elinks Emule";
$pagina = "http://www.tupagina.com"; // con http:// y sin / (diagonal) al final

$remitente = "webmaster@tuweb.com";

$errordb = Mysql_Error();
if($errordb != ''){
	die('<html>
         <head>
         <title>'.$title.'</title>
         </head>
         <body>
         <p align="center"><font size="2" face="Verdana">Error en la conexi�n con la Base de Datos.<br>
         Estaremos online lo antes posible.</font></p>
         <p align="center"><font size="2" face="Verdana">Staff de '.$title.'</font></p>
         </body>
         </html>');
}
?>
