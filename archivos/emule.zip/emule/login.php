<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

include('config.php');


if(empty($usuario) or empty($password)){
	echo "<center><font size=2 face=Verdana>ERROR!";
}
else{
$passmd5 = md5($password);
$login[0] = "Select * from users where usuario = '$usuario' and password = '$passmd5'";
$login[1] = MySql_Query($login[0]);	
$login[2] = MySql_Num_Rows($login[1]);
if($login[2] == 1){
	setcookie("username", $usuario, time()+604800);
    setcookie("userpass", $passmd5, time()+604800);
	header("Location: index.php");
}
else{
	echo "<center><font size=2 face=Verdana>ERROR, USUARIO O PASSWORD INCORRECTOS!";
}
}

?>
