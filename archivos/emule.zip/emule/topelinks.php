<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////
include('config.php');

$top[0] = "Select * from elinks order by hits desc Limit 0, 10";
$top[1] = MySql_Query($top[0]);
echo "<center><font size=1 face=verdana>";

echo "+ Top Elinks<br>";
echo "<div align=left>";
echo "<marquee behavior=scroll direction = up onmouseover=this.stop() onmouseout=this.start()>";
while($topelinks = MySql_Fetch_Array($top[1])){
	$varnom = ereg_replace(" ", "-", $topelinks[nombre]);
	echo "<li> <a href=elink/$topelinks[id]/$varnom/>$topelinks[nombre]</a><br>";
}
echo "</marquee>";
echo "</div><hr>";
echo "+ Nuevos Elinks<br>";
$new[0] = "Select * from elinks order by id desc Limit 0, 10";
$new[1] = MySql_Query($new[0]);
echo "<font size=1 face=verdana>";
echo "<div align=left>";
echo "<marquee behavior=scroll direction = up onmouseover=this.stop() onmouseout=this.start()>";
while($newelinks = MySql_Fetch_Array($new[1])){

	$varid = ereg_replace(" ", "-", $newelinks[nombre]);
	echo "<li> <a href=elink/$newelinks[id]/$varid/>$newelinks[nombre]</a><br>";
}
echo "</marquee>";
?>
