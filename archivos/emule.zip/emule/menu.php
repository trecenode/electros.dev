<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

include('config.php');



$page[0] = "Select * from categorias";
$page[1] = MySql_Query($page[0]);
echo "<div align=left>:: <a href=index.php>Inicio</a><br>";
echo ":: <a href=/foro/>Foros</a><br>";
while($cen = MySql_Fetch_Array($page[1])){
$newn = ereg_replace(" ", "-", $cen[nombre]);
echo ":: <a href=categorias/$cen[id]/$newn/>$cen[nombre]</a><br>";	
}



?>
