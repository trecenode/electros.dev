<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}
?>

<div align="center">
  <center>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="245" id="AutoNumber1" bgcolor="#006699">
  <form method="POST" action="admin.php?panel=system" enctype="multipart/form-data">
    <td align="left" width="51"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
    <td align="center" width="191"><font color="#FFFFFF">
    <input type="text" name="nombre" size="20"></font></td>
  </tr>
  <tr>
    <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Descripci�n:</font></b></td>
    <td align="center" width="191"><textarea rows="5" name="desc" cols="15"></textarea></td>
  </tr>
  <tr>
    <td align="left" width="51"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Idioma</font></b></td>
    <td align="center" width="191"><select size="1" name="lang">
    <option value="Spanish">Spanish</option>
    <option value="English">English</option>
    </select></td>
  </tr>
  <tr>
    <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Imagen:</font></b></td>
    <td align="center" width="191"><input type="file" name="archivo" size="5"></td>
  </tr>
  <tr>
    <td align="left" width="121">
    <font face="Verdana" size="2" color="#FFFFFF"><b>Categoria:</b></font></td>
    <td align="center" width="121">
    <select size="1" name="categoria">
    <?
    session_start();
    $edon = "Select * from categorias";
    $edon2 = mysql_query($edon);
    while($emule = mysql_fetch_array($edon2)){
    echo "<option value=$emule[id]>$emule[nombre]</option>";
    }
    ?>
    </select></select></td>
  </tr>
  <tr>
    <td align="center" width="242" colspan="2">
    <font face="Verdana" size="2" color="#FFFFFF"><b>Elinks:</b></font></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 1</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo1" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 1</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink1" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 2</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo2" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 2</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink2" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 3</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo3" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 3</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink3" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 4</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo4" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 4</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink4" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 5</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo5" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 5</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink5" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="242" colspan="2">
    <input type="submit" value="Agregar" name="addelink"></td>
  </tr>
  </form>
</table>

  </center>
</div>

