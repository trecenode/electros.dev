<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////



function numrow ($var){
$tabla = "Select * from $var";
$tabla = mysql_query($tabla);
$tabla = mysql_num_rows($tabla);
return $tabla;
}

function norepeat ($var, $var2, $var3){
$vers = "Select * from $var where $var2 = '$var3'";
$vers = mysql_query($vers);
$vers = mysql_num_rows($vers);
return $vers;
}





?>
