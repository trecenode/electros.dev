<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

include('../config.php');
include('funciones.php');

$selecta = "Select * from admin";
$querya = mysql_query($selecta);
$numadmins = mysql_num_rows($querya);

if($numadmins <= 0){
	echo "<title>Primer Administrador</title>";
	echo "<body bgcolor=003366>";
	echo "<center><font color=FFFFFF size=2 face=Verdana>Crea la primera cuenta de administrador:<br>";
	echo '<form method="POST" action="admin.php">
          <center>
          Admin:&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="firstadmin" size="20"><br>Password: <input type="password" name="firstpass" size="20"><br><input type="submit" value="Agregar" name="First"><input type="reset" value="Restablecer" name="B2"></br>
          </form>';
          if($HTTP_POST_VARS[First] == True){
	          if(empty($firstadmin) or empty($firstpass)){
		           echo "<body bgcolor=000000>";
		           echo "<center><font color=FFFFFF size=2 face=Verdana>Debe definir un Nombre de Administrador y Contrase�a!";
	          }
	          else{
		          $passmd5 = md5($firstpass);
		          $insert = "Insert into admin (id, nick, pass, R) values ('', '$firstadmin', '$passmd5', '1')";
		          $adminadd = mysql_query($insert);
		          echo "<body bgcolor=000000>";
		          echo "<center><font color=FFFFFF size=2 face=Verdana>Administrador a�adido!";
		          echo "<a href=admin.php>Clic Aqui</a>";
		         
	          }
          }
	          
}
else{
	$admi = "Select * from admin where nick = '$HTTP_COOKIE_VARS[admin]' and pass = '$HTTP_COOKIE_VARS[pass]'";
	$quer = mysql_query($admi);
	$num = mysql_num_rows($quer);
    if($num <= 0){
	    
	echo "<Title>Login Panel</title>";
	echo "<body bgcolor=003366>";
	echo '<font color="FFFFFF" size="2" face="Verdana"><form method="POST" action="login.php">
          <center>
          Admin: <input type="text" name="admins" size="20"><br>Pass:&nbsp;&nbsp;&nbsp;<input type="password" name="passs" size="20"><br><input type="submit" value="Enviar" name="login"><input type="reset" value="Restablecer" name="B2"></br>
          </form>';
      }
      else{
	      //Administracion
	echo "<title>Panel de Administracion</title>";
	$enviados = numrow(elinksu);
	include('style.php');
	echo '<body bgcolor="#003366" text="#006699">
	      </p>
          <table align="center" border="1" cellpadding="0" cellspacing="0" style="border:1px dotted #FFFFFF; border-collapse: collapse; font-family:Verdana; color:#FFFFFF; font-size:8pt; font-weight:bold; background-color:#000066" bordercolor="#111111" width="263" id="AutoNumber1">
          <tr>
          <td width="260" height="20" bordercolor="#FFFFFF" colspan="2">
          <p align="center">Men� Administraci�n</td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=add_cat">A�adir Categor�a</a></td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=mod_cat">Eliminar Categor�a</a></td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=add_elink">A�adir Elink</a></td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=mod_elink">Editar/Borrar Elinks</a></td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=add_link">A�adir Links</a></td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=mod_link">Borrar Links</a></td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=add_admin">A�adir Admin</a></td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=mod_admin">Borrar Admin</a></td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=elinks_users">Elinks Enviados</a> ('.$enviados.')</td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=mod_user">Editar/Borrar Usuario</a></td>
          </tr>
          <tr>
          <td width="115" height="20" bordercolor="#FFFFFF">
          <a href="?panel=optimize">Optimizar DB</a></td>
          <td width="145" height="20" bordercolor="#FFFFFF">
          <a href="?panel=boletin">Enviar Boletin</a></td>
        
          </tr>
          <tr>
          <td width="260" height="20" bordercolor="#FFFFFF" colspan="2">
          <p align="center"><a href="salir-admin.php">Salir/Logout</a></td>
          </tr>
          <tr>
          <td width="260" height="20" bordercolor="#FFFFFF" colspan="2">
          <p align="center">Programaci�n por 
          <a href="mailto:pablo2004@gmail.com">Elitewebs</a></td>
          </tr>
          </table>
          <table align="center" border="1" cellpadding="0" cellspacing="0" style="border:1px dashed #FFFFFF; border-collapse: collapse" bordercolor="#111111" width="250" id="AutoNumber2" height="100">
          <tr>
          <td width="450" height="50">
          <p align="center">';
          //Contenido
          if($panel == 'add_elink'){
	          include('elinks.php');
          }
          if($panel == 'add_cat'){
	          include('cate.php');
          }
          if($panel == 'system'){
	          include('add.php');
          }
          if($panel == 'mod_elink'){
	          include('elinks_edit.php');
          }
          if($panel == 'elinks_users'){
	          include('elinks_users.php');
          }
          if($panel == 'add_link'){
	          include('add_links.php');
          }
          if($panel == 'mod_link'){
	          include('mod_links.php');
          }
          if($panel == 'add_admin'){
	          include('add_admins.php');
          }
          if($panel == 'mod_admin'){
	          include('mod_admins.php');
          }
          if($panel == 'mod_user'){
	          include('mod_users.php');
          }
          if($panel == 'mod_cat'){
	          include('mod_cats.php');
          }
          if($panel == 'optimize'){
	      include('optimize.php');
          }
          if($panel == 'boletin'){
	      include('boletin.php');
          }
          if(empty($panel)){
	         echo "Bienvenido $HTTP_COOKIE_VARS[admin]!";
          }
          //Fin Contenido
     echo '</td>
           </tr>
           </table>';
	      
	      
	     //FIN Administracion
}
}

?>
