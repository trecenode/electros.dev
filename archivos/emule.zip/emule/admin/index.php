<?
header("Location: admin.php");
?>