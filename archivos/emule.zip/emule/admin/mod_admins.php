<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}


if(empty($del)){
$select = "select * from admin Where R = '2'";
$selecta = mysql_query($select);
echo '<font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Administradores</b></font><br>';
while($adde = mysql_fetch_array($selecta) ){
	$b++;
	echo "<font face=Verdana size=2>$b.-<a href=admin.php?panel=mod_admin&del=$adde[id]>$adde[nick]</a><br>";
}
}


if(isset($del)){
	
$dele[1] = "Delete from admin where id = '$del'";
$dele[2] = mysql_query($dele[1]);
echo "Administrador Borrado";	
}


?>