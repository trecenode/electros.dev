<?
include('../config.php');

if($HTTP_POST_VARS[login] == True){
$passmd5 = md5($passs);
$select = "Select * from admin where nick = '$admins' and pass = '$passmd5'";
$query = mysql_query($select);
$coun = mysql_num_rows($query);

if($coun <= 0){
	echo "<title>Error!</title>";
	echo "<center><font size=2 face=Verdana>Datos Incorrectos!</font>";
}
else{
  setcookie("admin", $admins, time()+604800);
  setcookie("pass", $passmd5, time()+604800);
  header("Location: admin.php");
}

}
?>