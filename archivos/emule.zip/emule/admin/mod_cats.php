<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}


if(empty($del)){
$select = "select * from categorias";
$selecta = mysql_query($select);
echo '<font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Categoria</b></font><br>';
while($adde = mysql_fetch_array($selecta) ){
	$b++;
	echo "<font face=Verdana size=2>$b.-<a href=admin.php?panel=mod_cat&del=$adde[id]>$adde[nombre]</a><br>";
}
echo '<br><font face="Verdana" size="2" color="#FFFFFF"><b>Advertencia!: SE BORRARAN TODOS LOS ELINKS DE ESA CATEGORIA.</b></font><br>';

}

if(isset($del)){
	
$dele[1] = "Delete from categorias where id = '$del'";
$dele[2] = mysql_query($dele[1]);
echo "<br>Categoria Borrada!";

$dele[3] = "Delete from elinks where categoria = '$del'";
$dele[4] = mysql_query($dele[3]);
echo "<br>Elinks Borrados!";	
}


?>