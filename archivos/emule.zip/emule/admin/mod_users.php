<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}

if(empty($search) and empty($edit)){
echo "<form method=post action=?panel=mod_user&search=true>";	
echo '<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="250" id="AutoNumber1" height="51" bgcolor="#FFFFFF">
      <tr>
      <td width="100%" colspan="2" height="16"><b><font color="000000" size="2" face="Verdana">
      Buscar Usuario:</font></b></td>
      </tr>
      <tr>
      <td width="40%" height="14"><b><font color="000000" size="1" face="Verdana">Nombre Usuario:</font></b></td>
      <td width="60%" height="14"><input type="text" name="searchuser" size="20"></td>
      </tr>
      <tr>
      <td width="100%" height="19" colspan="2">
      <p align="center"><input type="submit" value="Buscar!" name="searchu" size="20"></td>
      </tr>
      </table>';
echo "</form>";
}

if(isset($search)){
$viewuser[0] = "Select * from users where usuario =	'$searchuser'";
$viewuser[1] = MySql_Query($viewuser[0]);
$viewuser[2] = MySql_Num_Rows($viewuser[1]);
if($viewuser[2] == '1'){
$us = MySql_Fetch_Array($viewuser[1]);

echo "<form method=post action=admin.php?panel=mod_user&edit=$us[id]>";
echo '<table align="center" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="201" id="AutoNumber1">
  <tr>
    <td width="198" colspan="2">
    <p align="center"><font face="Verdana" size="2"><b>Editar Usuario:</b></font></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Usuario:</font></b></td>
    <td width="124">
    <p align="center"><input type="text" value="'.$us[usuario].'" name="usuario" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Pagina:</font></b></td>
    <td width="124"><input type="text" value="'.$us[pagina].'" name="pagina" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Edad:</font></b></td>
    <td width="124"><input type="text" value="'.$us[edad].'" name="edad" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Correo:</font></b></td>
    <td width="124"><input type="text" value="'.$us[correo].'" name="correo" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Avatar:</font></b></td>
    <td width="124"><input type="text" value="'.$us[avatar].'" name="avatar" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">*Rango:</font></b></td>
    <td width="124"><input type="text" value="'.$us[rango].'" name="rango" size="20"></td>
  </tr>
  <tr>
    <td width="74"><b><font face="Verdana" size="1">Env�os:</font></b></td>
    <td width="124"><input type="text" value="'.$us[puntos].'" name="envios" size="20"></td>
  </tr>
  <tr>
    <td width="198" colspan="2">
    <p align="center"><input type="submit" value="Editar!" name="edituser" size="20"></td>
  </tr>
</table>';
echo "<font face=Verdana color=FFFFFF size=2>(*)Rango 0 = Usuario, Rango 1 = Uploader</font>";
echo "</form>";


}
else{
	echo "<font face=Verdana color=FFFFFF size=2>No se encontro el usuario!</font>";
}
}

if(isset($edit)){
	$newpass = MD5($password);
	$editus[0] = "update users set usuario = '$usuario', pagina = '$pagina', edad = '$edad', correo = '$correo', avatar = '$avatar', rango = '$rango', puntos = '$envios' WHERE id = '$edit'";
	$editus[1] = MySql_Query($editus[0]);
	if($editus[1] == True){
		echo "<font face=Verdana color=FFFFFF size=2>El usuario ha sido editado!</font>";
	}
	else{
	echo "<font face=Verdana color=FFFFFF size=2>Error al editar el usuario!</font>";
	}
}
?>