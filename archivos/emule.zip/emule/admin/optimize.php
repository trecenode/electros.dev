<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}
if(empty($op)){
echo '<form method="post" action="?panel=optimize&op=yes">';
echo "<b>Al hacer clic en optimizar se vaciaran algunas tablas</b>";
echo '<center><input type="submit" value="Optimizar!" name="optimizar">';
echo '</form>';
}

if($op == 'yes'){
$sql[0] = "TRUNCATE TABLE visitantes"; 
$sql[1] = MySql_Query($sql[0]);

$sql[2] = "TRUNCATE TABLE elinksu"; 
$sql[3] = MySql_Query($sql[5]);

if($sql[1] == True and $sql[3] == True){
	echo "Base de datos optimizada!";
}
else{
	echo "Error!";
}
}

?>