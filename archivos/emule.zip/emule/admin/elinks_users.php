<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}
if(empty($envio) and empty($del)){
	$View[1] = "Select * From elinksu";
    $View[2] = MySql_Query($View[1]);
    while($emule = MySql_Fetch_Array($View[2])){
	    echo "$emule[id].- <a href=admin.php?panel=elinks_users&envio=$emule[id]>$emule[nombre]</a> - <a href=admin.php?panel=elinks_users&del=$emule[id]>Borrar</a><br>";
    }
}

if(isset($envio) and is_numeric($envio)){
$Mod[0] = "Select * From elinksu where id = '$envio'";
$Mod[1] = MySql_Query($Mod[0]);
$eo = MySql_Fetch_Array($Mod[1]);
echo '<body bgcolor="#003366">
<div align="center">
  <center>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="245" id="AutoNumber1" bgcolor="#006699">
  <form method="POST" action="admin.php?panel=system" enctype="multipart/form-data">
    <td align="left" width="51"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Nombre:</font></b></td>
    <td align="center" width="191"><font color="#FFFFFF">
    <input type="text" name="nombre" value="'.$eo[nombre].'" size="20"></font></td>
  </tr>
  <tr>
    <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Descripci�n:</font></b></td>
    <td align="center" width="191"><textarea rows="5" name="desc" cols="15">'.$eo[descripcion].'</textarea></td>
  </tr>
  <tr>
    <td align="left" width="51"><b>
    <font face="Verdana" size="2" color="#FFFFFF">Idioma</font></b></td>
    <td align="center" width="191"><select size="1" name="lang">
    <option value="Spanish">Spanish</option>
    <option value="English">English</option>
    </select></td>
  </tr>
  <tr>
    <td align="left" width="51"><b><font face="Verdana" size="2" color="#FFFFFF">Imagen:</font></b></td>
    <td align="center" width="191"><input type="text" name="imagen" value="'.$eo[imagen].'" size="20"></td>
  </tr>
  <tr>
    <td align="left" width="121">
    <font face="Verdana" size="2" color="#FFFFFF"><b>Categoria:</b></font></td>
    <td align="center" width="121">
    <select size="1" name="categoria">';
    $edon = "Select * from categorias";
    $edon2 = mysql_query($edon);
    while($emule = mysql_fetch_array($edon2)){
    echo "<option value=$emule[id]>$emule[nombre]</option>";
    }
    echo '</select></select></td>
  </tr>
  <td align="left" width="121">
    <font face="Verdana" size="2" color="#FFFFFF"><b>Envio Por:</b></font></td>
    <td align="center" width="121">
    <input type="text" name="uploader" value="'.$eo[uploader].'" size="20">
  </tr>
  <tr>
    <td align="center" width="242" colspan="2">
    <font face="Verdana" size="2" color="#FFFFFF"><b>Elinks:</b></font></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 1</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo1" value="'.$eo[titulo1].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 1</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink1" value="'.$eo[elink1].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 2</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo2" value="'.$eo[titulo2].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 2</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink2" value="'.$eo[elink2].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 3</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo3" value="'.$eo[titulo3].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 3</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink3" value="'.$eo[elink3].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 4</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo4" value="'.$eo[titulo4].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 4</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink4" value="'.$eo[elink4].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Archivo 5</font></b></td>
    <td align="center" width="121">
    <input type="text" name="archivo5" value="'.$eo[titulo5].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="121">
    <b><font face="Verdana" size="2" color="#FFFFFF">Elink 5</font></b></td>
    <td align="center" width="121">
    <input type="text" name="elink5" value="'.$eo[elink5].'" size="19"></td>
  </tr>
  <tr>
    <td align="center" width="242" colspan="2">
    <input type="submit" value="Agregar" name="addelinkuser"></td>
  </tr>
  </form>
</table>

  </center>
</div>';
}

if(isset($del) and is_numeric($del)){
$dele[1] = "Delete from elinksu where id = '$del'";
$dele[2] = Mysql_Query($dele[1]);
echo "Elink Borrado!";	
}

?>