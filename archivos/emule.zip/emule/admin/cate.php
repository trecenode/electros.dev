<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<title>Area Restringida</title><p align=center><font size=2 face=verdana>Area Restringida</font></p>");
}
?>
<div align="center">
  <center>

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="245" id="AutoNumber1" bgcolor="#006699">
  <form method="POST" action="admin.php?panel=system">
    <td align="center" width="51"><font face="Verdana" size="2" color="#FFFFFF">Categoria</font></td>
    <td align="center" width="191"><font color="#FFFFFF">
    <input type="text" name="cate" size="20"></font></td>
  </tr>
  <tr>
    <td align="center" width="51"><font face="Verdana" size="2" color="#FFFFFF">Descripci�n:</font></td>
    <td align="center" width="191"><font color="#FFFFFF">
    <input type="text" name="desc" size="20"></font></td>
  </tr>
  <tr>
    <td align="center" width="51"><font face="Verdana" size="2" color="#FFFFFF">Imagen:</font></td>
    <td align="center" width="191"><font color="#FFFFFF">
    <input type="text" name="img" size="20"></font></td>
  </tr>
  <tr>
    <td align="center" width="242" colspan="2">
    <input type="submit" value="Agregar" name="add"></td>
  </tr>
  </form>
</table>
