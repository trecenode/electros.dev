<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}
if(empty($send)){
echo '<form align="center" method="post" action="admin.php?panel=boletin&send=go">
      <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="37%" id="AutoNumber1">
      <tr>
      <td width="100%" colspan="2"><font face="Verdana" size="2"><b>Enviar Bolet�n:</b></font></td>
      </tr>
      <tr>
      <td width="100%" colspan="2"><font size="1" face="Verdana"><b>Tema:<br><input type="text" name="Tema" size="20">
      <br>Mensaje:</b></font><br><textarea name="mensaje" rows="10" cols="33"></textarea>
      </td>
      </tr>
      <tr>
      <td width="50%">
      <p align="center"><input type="submit" value="Enviar!" name="enviar" size="20"></td>
      <td width="50%">
      <p align="center"><input type="reset" value="Borrar" name="enviar" size="20"></td>
      </tr>
      </table>
      </form>';
      echo "Debe enviarlo en formato HTML";
}

if($send == 'go'){
$boletin[0] = "Select * from users where boletin = '1'";
$boletin[1] = MySql_Query($boletin[0]);

$headers = "MIME-Version: 1.0\r\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
$headers .= "From: Boletin <$remitente>\r\n"; 
$headers .= "Return-path: $remitente\r\n";

While($bon = MySql_Fetch_Array($boletin[1])){
	mail($bon[correo],$Tema,$mensaje,$headers);
}
echo "Boletin enviado!";
}

?>