<?
  setcookie("admin");
  setcookie("pass");
  header("Location: admin.php");
?>