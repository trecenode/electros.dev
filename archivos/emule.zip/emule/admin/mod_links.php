<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}

if(empty($del)){
$selectlink = "Select * from links";
$enla = mysql_query($selectlink);
echo '<font face="Verdana" size="2" color="#FFFFFF"><b>Borrar Enlaces</b></font><br>';
while($mien = mysql_fetch_array($enla)){
	echo "<font face=Verdana size=2>$mien[id].-<a href=admin.php?panel=mod_link&del=$mien[id]>$mien[pagina]</a><br>";
}
}

if(isset($del) and is_numeric($del)){
$dele[1] = "Delete from links where id = '$del'";
$dele[2] = mysql_query($dele[1]);
echo "Enlace Borrado";	
}
?>