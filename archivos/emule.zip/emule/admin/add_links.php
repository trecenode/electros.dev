<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}

if(isset($HTTP_POST_VARS[addlink])){
$inslink[0] = "INSERT INTO links (id, pagina, direccion) VALUES ('', '$pagina', '$direccion')";
$inslink[1] = MySql_Query($inslink[0]);
echo "<font size=1 face=Verdana>Link Agregado!";

}

if(empty($HTTP_POST_VARS[addlink])){
echo '<form method="POST" action="admin.php?panel=add_link">
  <p align="center"><font size="1" face="Verdana">Pagina:
  <br>
  <input type="text" name="pagina" size="20">
  <br>
  Direcci�n: </font>
  <br>
  <input type="text" name="direccion" size="20">
  <br>
  <input type="submit" value="Enviar" name="addlink"> </p>
  </form>';
}
?>