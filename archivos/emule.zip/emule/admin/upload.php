<?php 
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<title>Area Restringida</title><p align=center><font size=2 face=verdana>Area Restringida</font></p>");
}
$ext = explode(".",$archivo_name); 
$num = count($ext)-1; 
if($ext[$num] == "gif" or $ext[$num] == "jpg") 
{ 
if($archivo_size < 100000) 
{ 

$var = @mkdir("img/$PHPSESSID");
if(!copy($archivo, "img/$PHPSESSID/".$archivo_name) )
{ 
echo "<center><font size=2 face=Verdana>Error al copiar el archivo"; 
} 
else 
{ 
echo "<center><font size=2 face=Verdana>Archivo subido con exito"; 
} 
} 
else 
{ 
echo "<center><font size=2 face=Verdana>La Imagen supera los 100kb"; 
} 
} 
else 
{ 
echo "El Archivo no es valido, solo .gif o .jpg"; 
} 
?>