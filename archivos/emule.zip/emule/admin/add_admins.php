<?
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<p align=center>Area Restringida");
}

if(empty($addadmin)){
echo "<form method=post action=admin.php?panel=add_admin>";
echo '<table align="center" border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="251" bgcolor="#FFFFFF">
      <tr>
      <td width="249" colspan="2"><b>
      <font face="Verdana" size="2" color="#000066">Agregar 
      Administrador:</font></b></td>
      </tr>
      <tr>
      <td width="77"><b><font face="Verdana" size="1" color="#000066">Nombre:</font></b></td>
      <td width="171">
      <p align="center"><font color="#000066"><input type="text" name="nombre" size="20"></font></td>
      </tr>
      <tr>
      <td width="77"><b><font face="Verdana" size="1" color="#000066">Password: </font></b></td>
      <td width="171">
      <p align="center"><font color="#000066"><input type="password" name="passnewadmin" size="20"></font></td>
      </tr>
      <tr>
      <td width="249" colspan="2">
      <p align="center"><font color="#999999"><input type="submit" value="Agregar!" name="addadmin" size="20"></font></td>
      </tr>
      </table>';
      echo "</form>";
}


if(isset($addadmin)){
	
$adminpassmd5 = md5($passnewadmin);
$adminn[1] = "Insert into admin (id, nick, pass, R) values ('', '$nombre', '$adminpassmd5', '2')";
$adminn[2] = mysql_query($adminn[1]);
echo "<center><font face=Verdana color=FFFFFF size=2>Nuevo Administrador!";	
}


?>