<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////
if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("<title>Area Restringida</title><p align=center><font size=2 face=verdana>Area Restringida</font></p>");
}
include('../config.php');


//Inicio Agregar Categorias
if(isset($HTTP_POST_VARS[add])){
if(empty($cate)){ die("<center><font size=2 face=Verdana>Campo Categoria Vacio"); }
if(empty($desc)){ die("<center><font size=2 face=Verdana>Campo Descripcion Vacio"); }
if(norepeat(categorias, nombre, $cate) >= 1){
	echo "<center><font size=2 face=Verdana>Error, Categoria Repetida";
}
else{
$agregar[0] = "Insert Into categorias (id, nombre, descripcion, imagen) Values ('', '$cate', '$desc', '$img')";
$agregar[1] = mysql_query($agregar[0]);
if($agregar[1] == True){
	echo "<center><font size=2 face=Verdana>Categoria Agregada Correctamente!";
}
else{
    echo "<center><font size=2 face=Verdana>Error al Agregar la Categoria!";
}
}
}
//Fin Agregar Categorias

//Inicio Agregar Elinks
if(isset($HTTP_POST_VARS[addelink])){

if(empty($nombre)){ die("<center><font size=2 face=Verdana>Campo Nombre Vacio"); }
if(empty($desc)){ die("<center><font size=2 face=Verdana>Campo Descripcion Vacio"); }
if(empty($archivo)){ die("<center><font size=2 face=Verdana>Campo Imagen Vacio"); }
	
if(norepeat(elinks, nombre, $nombre) >= 1){
		echo "<center><font size=2 face=Verdana>Error, Elink Repetido";
}
else{
include('upload.php');
$img = "admin/img/$PHPSESSID/$archivo_name";
function limpia($texto) {
static $acentos = "����������������������������������������";
static $validos = "aeiouAEIOUaeiouAEIOUaeiouAEIOUaeiouAEIOU";
return strtr($texto, $acentos, $validos);
}
$nombre = limpia($nombre);
$desc = limpia($desc);

$ed2k[1] = "Insert Into elinks (id, nombre, descripcion, idioma, imagen, hits, categoria, titulo1, elink1, titulo2, elink2, titulo3, elink3, titulo4, elink4, titulo5, elink5) Values 
            ('', '$nombre', '$desc', '$lang', '$img', '0', '$categoria', '$archivo1', '$elink1', '$archivo2', '$elink2', '$archivo3', '$elink3', '$archivo4', '$elink4', '$archivo5', '$elink5')";
$ed2k[2] = MySql_Query($ed2k[1]);  
if($ed2k[2] == True){
	echo "<center><font size=2 face=Verdana>Elink Agregado Correctamente!";
}
else{
    echo "<center><font size=2 face=Verdana>Error al Agregar el Elink!";
}          

	
}
}
//Fin Agregar Elinks

//Inicio Agregar Elinks Usuarios
if(isset($HTTP_POST_VARS[addelinkuser])){

if(empty($nombre)){ die("<center><font size=2 face=Verdana>Campo Nombre Vacio"); }
if(empty($desc)){ die("<center><font size=2 face=Verdana>Campo Descripcion Vacio"); }
if(empty($imagen)){ die("<center><font size=2 face=Verdana>Campo Imagen Vacio"); }
	
if(norepeat(elinks, nombre, $nombre) >= 1){
		echo "<center><font size=2 face=Verdana>Error, Elink Repetido";
}
else{
$ed2k[1] = "Insert Into elinks (id, nombre, descripcion, idioma, imagen, hits, categoria, titulo1, elink1, titulo2, elink2, titulo3, elink3, titulo4, elink4, titulo5, elink5) Values 
            ('', '$nombre', '$desc', '$lang', '$imagen', '0', '$categoria', '$archivo1', '$elink1', '$archivo2', '$elink2', '$archivo3', '$elink3', '$archivo4', '$elink4', '$archivo5', '$elink5')";
$ed2k[2] = MySql_Query($ed2k[1]);  
if($ed2k[2] == True){
	$sumuser[1] = "Select * from users where usuario = '$uploader'";
	$sumuser[2] = MySql_Query($sumuser[1]);
	$sumusers = MySql_Fetch_Array($sumuser[2]);
	$punto = $sumusers[puntos] + 1;
	$sumuser[6] = "UPDATE users SET puntos = '$punto' WHERE usuario = '$sumusers[usuario]'"; 
	$sumuser[7] = MySql_Query($sumuser[6]);
	echo "<center><font size=2 face=Verdana>Elink Agregado Correctamente!";
}
else{
    echo "<center><font size=2 face=Verdana>Error al Agregar el Elink!";
}          

	
}
}
//Fin Agregar Usuarios


?>
