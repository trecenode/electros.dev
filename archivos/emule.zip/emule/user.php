<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////


if(isset($HTTP_COOKIE_VARS[username]) and isset($HTTP_COOKIE_VARS[userpass])){
	echo "<p align=center><font face=verdana size=1 color=000000><center>Bienvenido: $HTTP_COOKIE_VARS[username]<br>";
	$us[0] = "Select * from users where usuario = '$HTTP_COOKIE_VARS[username]' and password = '$HTTP_COOKIE_VARS[userpass]'";
	$us[1] = MySql_Query($us[0]); 
	$usme = MySql_Fetch_Array($us[1]);
	if($usme[avatar] == ''){ $avatar = "Images/blank.gif"; } else{ $avatar = $usme[avatar]; }
	echo "<img src=$avatar>";
	echo "<font face=verdana size=1 color=000000><center><br><a href=panel.html>Panel Usuario</a><br>";
	echo "<font face=verdana size=1 color=000000><center><a href=salir.php>Salir</a><br>";
	echo "<br>Stats:<br>";
	echo "Envios: $usme[puntos]<br>";
	if($usme[rango] == '0'){$rango = "<font face=verdana size=1 color=000000>Usuario"; } else {$rango = "<font face=verdana size=1 color=FF0000><strong>Uploader</font></strong>"; }
	echo "Rango:</font> $rango";
	
}
else{
echo "<p align=center><font face=verdana size=1 color=000000><center>Bienvenido: Anonimo";
echo'<font face="Verdana" color="#000000" size="2">
     <form method="post" action="login.php">
     Usuario:<br><input type="text" name="usuario" size="15"><br>Contrase�a:<br><input type="password" name="password" size="15">
    <br>
     <input type="submit" value="Login!" name="log">
     </form>';
     echo "<font face=verdana size=1 color=000000><center><br><a href=index.php?registro=go>Registrate!</a>";
}
echo "<hr>";
$fecha = date("j-n-y");
$unixt = getdate();
$numonu[0] = "Select * from users where hora = '$unixt[hours]' and minutos = '$unixt[minutes]' and fecha = '$fecha'";
$numonu[1] = MySql_Query($numonu[0]);
echo "<div align = left><img src=Images/user/group-1.gif>En linea ahora:</br>";
while($useron = MySql_Fetch_Array($numonu[1])){
	$n++;
	echo "$n: <a href=perfilusuario-$useron[id].html>$useron[usuario]</a><br>";
}

$numovi[0] = "Select * from visitantes where hora = '$unixt[hours]' and minutos = '$unixt[minutes]' and fecha = '$fecha'";
$numovi[1] = MySql_Query($numovi[0]);
$NM = MySql_Num_Rows($numonu[1]);
$NV = MySql_Num_Rows($numovi[1]);
$NT = $NM + $NV;
echo "<hr>";
echo "<div align = left><img src=Images/user/group-3.gif>Gente en linea:</br>";
echo "<img src=Images/user/ur-member.gif>Miembros: $NM <br><img src=Images/user/ur-anony.gif>Visitantes: $NV<br><Img src=Images/user/ur-registered.gif>Total: $NT";
include('admin/funciones.php');
$all = numrow(users);
if($all < 10){
	$numr = "0000$all";
}
if($all > 10 and $all < 100){
	$numr = "000$all";
}
if($all > 100 and $all < 1000){
	$numr = "00$all";
}
if($all > 1000 and $all < 10000){
	$numr = "0$all";
}
if($all > 10000){
	$numr = "$all";
}
echo "<br><img src=Images/user/group-3.gif>Miembros en Total:<br><font color=FF0000 size=1 face=Verdana><center>$numr";

?>
