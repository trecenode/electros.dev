<?php
include("config.php");

$fechas = date("j-n-y");
$unixtim = getdate();
$formin = $unixtim[minutes] - 10;

$userson = "select * from usuarios order by minutos DESC";
$userson2 = mysql_query($userson, $conect);
    echo "<font color=000000 face=Verdana size=1>";
    echo "<hr>";
	echo "<img src=bloques/imgus/group-3.gif>Miembros en Linea:</br>";
	echo "</br>";
	
while($on = mysql_fetch_array($userson2)) {
    if($on[fecha] == $fechas){
    if($unixtim[hours] == $on[hora]){ 
	    if($on[minutos] >= $formin){
	$dot++;
	echo "$dot:<img src=bloques/imgus/icon_minipost.gif><a href=index.php?action=perfil&user=$on[id]>$on[nick]</a><br>";
   }
  }
 }
}	
echo "</b>";
echo "<hr>";

$visson = "select * from visitantes order by minutos DESC";
$visson2 = mysql_query($visson, $conect);
echo "<img src=bloques/imgus/group-3.gif>Visitantes </br>";
while($vis = mysql_fetch_array($visson2)){
	if($vis[fecha] == $fechas){
    if($unixtim[hours] == $vis[hora]){ 
	if($vis[minutos] >= $formin){
	$rot++;
	echo "$rot:<img src=bloques/imgus/icon_minipost.gif> $vis[ip]</br>";
   }
  }
 }
}
echo "<hr>";

if($rot == ''){ $rot = 0; }
if($dot == ''){ $dot = 0; }
$total = $rot + $dot;
echo "<img height=15 src=bloques/imgus/group-1.gif width=15>En Linea ahora: [$total]<br>";
echo "<img height=15 src=bloques/imgus/ur-anony.gif width=15>Visitantes: [$rot]<br>";
echo "<img height=15 src=bloques/imgus/ur-member.gif width=15>Miembros: [$dot]</br>";
?>