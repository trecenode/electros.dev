<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

	setcookie("username", "");
    setcookie("userpass", "");
	header("Location: index.php");

?>
