<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<base href="http://localhost/emule/">
<?
include('lastvisit.php');
?>
<style type="text/css">
<!--
body, td, th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	color: #000000;
}
body {
	margin-top: 0px;
	background-color: #E9E9E9;
}
a:link {
	color: #003366;
}
a:visited {
	color: #003366;
}
a:hover {
	color: #006699;
}
a:active {
	color: #006699;
}
.style2 {color: #C2C9D1}
.style3 {
	font-size: 12px;
	font-weight: bold;
	color: #8D96A5;
}
-->
</style>

</head>

<body>
<div align="center">
  <table width="800" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="53" colspan="3"><table  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="211" height="66" rowspan="3"><img src="Images/top_left.jpg" width="211" height="66"></td>
          <td height="30" colspan="12"><img src="Images/top_right.jpg" width="562" height="37"></td>
          <td width="27" rowspan="3"><img src="Images/top_rightside.jpg" width="27" height="66"></td>
        </tr>
        <tr>
          <td width="76" height="14" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="3" background="Images/separater.jpg"></td>
          <td width="80" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="4" background="Images/separater.jpg"></td>
          <td width="79" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="4" background="Images/separater.jpg"></td>
          <td width="64" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="4" background="Images/separater.jpg">&nbsp;</td>
          <td width="72" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="4" background="Images/separater.jpg">&nbsp;</td>
          <td width="49" align="center" valign="middle" background="Images/navbar_bg.jpg">&nbsp;</td>
          <td width="123" background="Images/navbar_bg.jpg">&nbsp;</td>
        </tr>
        <tr>
          <td height="12" colspan="12"><img src="Images/top_bottom.jpg" width="562" height="15"></td>
        </tr>
      </table></td>
    </tr>
    <tr background="Images/bg.jpg">
      <td width="27" height="58" background="Images/side_left.jpg">&nbsp;</td>
      <td width="746" align="center" valign="top"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="151" height="63" align="center" valign="top" background="Images/bg.jpg"><br>
            <table width="140"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td colspan="3"><img src="Images/nav_main.jpg" width="140" height="19"></td>
            </tr>
            <tr>
              <td width="1" background="Images/pixel.jpg"></td>
              <td width="138" bgcolor="#FFFFFF">
              <p align="center">
              <?
              include('menu.php');
              ?>
              </td>
              <td width="1" background="Images/pixel.jpg"></td>
            </tr>
            <tr>
              <td height="1" colspan="3" background="Images/pixel.jpg"></td>
            </tr>
          </table>
            <br>
            <table width="140"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="3"><img src="Images/nav_affiliates.jpg" width="140" height="19"></td>
              </tr>
              <tr>
                <td width="1" background="Images/pixel.jpg"></td>
                <td width="138" bgcolor="#FFFFFF">
                <?
                include('links.php');
                ?>
                  <br></td>
                <td width="1" background="Images/pixel.jpg"></td>
              </tr>
              <tr>
                <td height="1" colspan="3" background="Images/pixel.jpg"></td>
              </tr>
            </table>
            <br>
            <table width="140"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="3"><img src="Images/nav_stats.jpg" width="140" height="19"></td>
              </tr>
              <tr>
                <td width="1" background="Images/pixel.jpg"></td>
                <td width="138" bgcolor="#FFFFFF"><p>
                <?
                include('user.php');
                ?>

                  <br>
</p>
                  </td>
                <td width="1" background="Images/pixel.jpg"></td>
              </tr>
              <tr>
                <td height="1" colspan="3" background="Images/pixel.jpg">
                <p></p>
                <p></p>
                <p></td>
              </tr>
            </table>
            &nbsp;<table width="140"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="3"><img src="Images/nav_stats.jpg" width="140" height="19"></td>
              </tr>
              <tr>
                <td width="1" background="Images/pixel.jpg"></td>
                <td width="138" bgcolor="#FFFFFF"><p align="left">
                <?
                include('topelinks.php');
                ?>
                  <br>
</p>
                  </td>
                <td width="1" background="Images/pixel.jpg"></td>
              </tr>
              <tr>
                <td height="1" colspan="3" background="Images/pixel.jpg">
                <p></p>
                <p></p>
                <p>
                <p>
                <p>
                <p></td>
              </tr>
            </table>
          <br>
              <table width="140"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="3" width="140"><img src="Images/nav_stats.jpg" width="140" height="19"></td>
              </tr>
              <tr>
                <td width="1" background="Images/pixel.jpg">
                <p></td>
                <td width="138" bgcolor="#FFFFFF"><p align="center">
                <?
                include('rand.php');
                ?>
                  <br>
</p>
                  </td>
                <td width="1" background="Images/pixel.jpg"></td>
              </tr>
              <tr>
                <td height="1" colspan="3" background="Images/pixel.jpg" width="140">
                <p></p>
                <p></p>
                <p></p>
                <p></p>
                <p></td>
              </tr>
            </table>
          <br>
                   <table width="140"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="3"><img src="Images/nav_stats.jpg" width="140" height="19"></td>
              </tr>
              <tr>
                <td width="1" background="Images/pixel.jpg"></td>
                <td width="138" bgcolor="#FFFFFF"><p align="center">
                <?
                include('buscador.php');
                ?>
                  <br>
</p>
                  </td>
                <td width="1" background="Images/pixel.jpg"></td>
              </tr>
              <tr>
                <td height="1" colspan="3" background="Images/pixel.jpg">
                <p></p>
                <p></p>
                <p></td>
              </tr>
            </table>
            <br></td>
          <td width="595" align="center" valign="top" background="Images/bg.jpg"><br>
            <table width="580"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td colspan="3"><img src="Images/content_top.jpg" width="580" height="19"></td>
            </tr>
            <tr>
              <td width="1" background="Images/pixel.jpg"></td>
              <td width="578" bgcolor="#FFFFFF"><div align="center">
  <? include('home.php'); ?><br>
              </div></td>
              <td width="1" background="Images/pixel.jpg"></td>
            </tr>
            <tr>
              <td height="1" colspan="3" background="Images/pixel.jpg"></td>
            </tr>
          </table>
            <br></td>
        </tr>
      </table>
      </td>
      <td width="27" background="Images/side_right.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3"><img src="Images/bottom.jpg" width="800" height="27"></td>
    </tr>
  </table>
</div>
<p align="center">Ocio-Total.info Web del grupo Elitecentro</p>
</body>
</html>