<?php
/////////////////////////////////////
//Elitewebs Programaciones         //
//Correo: pablo2004@gmail.com      //
//Programacion Emule/Edonkey 1.0   //
/////////////////////////////////////

$viewlinks[0] = "Select * from links";
$viewlinks[1] = MySql_Query($viewlinks[0]);
echo "<div align=left><font face=Verdana Size=1>";
while($web = MySql_Fetch_Array($viewlinks[1])){
	echo "- <a href=$web[direccion]>$web[pagina]</a><br>";
	
}


?>
