<?
require 'config.php' ;
if($_POST[enviar]) {
	function quitar($texto) {
		$texto = trim($texto) ;
		$texto = htmlspecialchars($texto) ;
		# --> Elimina espacios que no pueden ser borrados por trim()
		$texto = str_replace(chr(160),'',$texto) ;
		return $texto ;
	}
	$nick = quitar($_POST[nick]) ;
	$contrasena = md5(md5(quitar($_POST[contrasena]))) ;
	$con = mysql_query("select id,contrasena from usuarios where nick='$nick'") ;
	$datos = mysql_fetch_assoc($con) ;
	if(mysql_num_rows($con)) {
		if($datos[contrasena] == $contrasena) {
			setcookie('uid',$datos[id],time()+604800) ;
			setcookie('unick',$nick,time()+604800) ;
			setcookie('ucontrasena',$contrasena,time()+604800) ;
			header("location: $_SERVER[HTTP_REFERER]") ;
		}
		else {
			echo 'La contrase�a es incorrecta. Haz click <a href="javascript:history.back()">aqu�</a> para regresar.' ;
		}
	}
	else {
		echo 'El nick no existe. Haz click <a href="javascript:history.back()">aqu�</a> para regresar.' ;
	}
}
?>