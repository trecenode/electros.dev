<?
if($_POST[enviar]) {
	require 'config.php' ;
	function quitar($texto) {
		$texto = trim($texto) ;
		$texto = htmlspecialchars($texto) ;
		$texto = str_replace(chr(160),'',$texto) ; # Elimina espacios que no pueden ser borrados por trim()
		return $texto ;
	}
	$nick = quitar($_POST[nick]) ;
	$email = quitar($_POST[email]) ;
	$con = mysql_query("select count(id) from usuarios where nick='$nick' or email='$email'") ;
	if(mysql_result($con,0,0)) {
		echo 'El nick ya existe en la base de datos o ya est� registrado el email. Haz click <a href="javascript:history.back()">aqu�</a> para regresar.' ;
	}
	else {
		$fecha = time() ;
		$contrasena = md5(md5(quitar($_POST[contrasena]))) ;
		$sexo = quitar($_POST[sexo]) ;
		mysql_query("insert into usuarios (fecha,nick,contrasena,email,sexo,ip) values ('$fecha','$nick','$contrasena','$email','$sexo','$_SERVER[REMOTE_ADDR]')") ;
		echo 'Has sido registrad@. Haz click aqu� <a href="index.php">aqu�</a> para regresar a la p�gina principal.' ;
	}
}
else {
?>
<script>
function revisar() {
	if(formulario.nick.value.length < 3) {
		alert('El nick debe contener por lo m�nimo 3 caract�res.') ;
		return false ;
	}
	if(formulario.contrasena.value.length < 8) {
		alert('La contrase�a debe contener por lo m�nimo 8 caract�res.') ;
		return false ;
	}
	if(formulario.contrasena.value != formulario.c_contrasena.value) {
		alert('Las contrase�as no son correctas.') ;
		return false ;
	}
	if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(formulario.email.value)) {
		alert('Debes poner un email v�lido.') ;
		return false ;
	}
}
</script>
<form name="formulario" method="post" action="<?=$_SERVER[PHP_SELF]?>" onsubmit="return revisar()">
<b>Nick:</b><br>
<input type="text" name="nick" maxlength="20"><br>
<b>Contrase�a:</b><br>
<input type="password" name="contrasena" maxlength="10"><br>
<b>Confirmar contrase�a:</b><br>
<input type="password" name="c_contrasena" maxlength="10"><br>
<b>Email:</b><br>
<input type="text" name="email" maxlength="40"><br>
<b>Sexo:</b><br>
<select name="sexo">
<option value="0">Masculino
<option value="1">Femenino
</select><br><br>
<input type="submit" name="enviar" value="Registrar">
</form>
</div>
<?
}
?>