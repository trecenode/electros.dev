<?
require 'config.php' ;
$con = mysql_query("select count(id) from usuarios where id='$_COOKIE[uid]' and nick='$_COOKIE[unick]' and contrasena='$_COOKIE[ucontrasena]'") ;
if(!mysql_result($con,0,0)) {
	exit('<p><b>Esta secci�n es s�lo para usuari@s registrad@s.</b><p><a href="javascript:history.back()">� Regresar</a>') ;
}
?>