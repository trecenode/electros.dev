<?
setcookie('uid') ;
setcookie('unick') ;
setcookie('ucontrasena') ;
header('location: index.php') ;
?>