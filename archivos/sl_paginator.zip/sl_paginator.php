<?php
// este script es una clase que sirve para paginar los resultados de
//una consulta MySQL
class sl_paginator{
  // ahora declaramos 4 variables globales
  var $sql; // aqui almacenamos la consulta SQl
  var $limite = '10'; //Aqui indicamos el limite de resultados x cada pagina
  var $resultado; //aqui el resultado de la paginacion
  var $menu; // y x ultimo el menu (si fuese necesario)
  var $url; // Aqui guardamos la dirreccion a la q apuntara el paginador
  // en el caso de q se a x ejemplo index.php?sec=noticias
  // ahora creamos la funcion que hace toda la magia
  function paginar(){
    // 1� comprobamamos que la variable sql este vacia
    if (empty($this->sql)){
      echo 'Debe de definir una sentencia SQl<br/>';
    }else{
      // si no esta vacia seguimos con el script
      //ahora comprobamos si pg esta o no definida
      if (isset($_GET['pg'])){
        $pg = $_GET['pg']; // si existe asignamos a pg ese valor
      }else{
        $pg = 0; // si es al contrario pg sera igual a 0
      }
      //ahora calculamos desde que registro empezamos
      $inicial = $pg*$this->limite;
      // y creamos la sentencia sql
      $sql1 = $this->sql." LIMIT ".$inicial.",".$this->limite;
      //y finalmente hacemos la consulta
      $this->resultado = mysql_query($sql1) or die (mysql_error());
      // a continuacion calculamos en cuantas paginas metemos los resultados
      $query2 = mysql_query($this->sql) or die (mysql_error());
      $total_co = mysql_num_rows($query2);
      $total_pags = intval($total_co/$this->limite);
      // ahora comprobamos si hay mas de una pagina
      if ($total_pags > 1){
        // si es el caso mostramos el menu
        //si no estamos en la 1� pagina mostramos el enlace para retroceder
        if ($pg <> 0){
          $retro=$pg-1;
          if (isset($this->url)){
            $this->menu .= '<a href='.$this->url.'&amp;pg='.$retro.'> <<</a>';
          }else{
            $this->menu .= '<a href=?pg='.$retro.'> <<</a>';
          }
        }
        //ahora mostramos un menu numerico con los enlaces a las paginas
        for ($i=0; $i<$total_pags; $i++){
          $num_pag=$i+1;
          // ahora comprobamos si pg es igual a i entonces no mostramos ese enlace sino solo texto
          if ($pg==$i){
            $this->menu .= $i + 1;
          }else{
            // ahora comprobamos si le hemos pasado una url mediante la variable url
            if (isset($this->url)){
            $this->menu .= ' <a href='.$this->url.'&amp;pg='.$i.'>'.$num_pag.'</a> ';
            }else{
              $this->menu .= ' <a href=?pg='.$i.'>'.$num_pag.'</a> ';
            }

          }
        }
        if ($pg <> $total_pags -1){
          $avan=$pg+1;
          if (isset($this->url)){
            $this->menu .= '<a href='.$this->url.'&amp;pg='.$avan.'> >></a>';
          }else{
            $this->menu .= '<a href=?pg='.$avan.'> >></a>';
          }
        }
      }
    }
  }
}
?>