<?php
// este es un ejemplo para probar el paginador
$cls_paginar = new sl_paginator;
$cls_paginar->sql='select * from art';
$cls_paginar->limite='5';
$cls_paginar->paginar();
while ($mostrar=mysql_fetch_array($cls_paginar->resultado)){
  echo '('.$mostrar['id'].') '.$mostrar['name'].'<br/>';
}
echo $cls_paginar->menu;
?>