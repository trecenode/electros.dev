<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Contactar</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Comic Sans MS;
	color: #000000;
}
a:link {
	color: #0000CC;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #000000;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}

</style></head>

<body>
<!-- Script de formulario hecho por el webmaster de TretHack.Tk
Usted descargo un archivo en zip con este formulario y con el manual de como modificar este script a su gusto
Puede ver mas scripts en www.trethack.tk
Heste script representa un t�pico formulario para un contacto con el webmaster. Es muy simple pero efectivo. No dude en probarlo -->
<? 
if (!$HTTP_POST_VARS){ 
?> 
<form action="contactar.php" method=post>
  <p>Nombre: 
    <input name="nombre" type="text" id="nombre">
</p>
  <p>Asunto: 
    <input name="asunto" type="text" id="asunto" value="Contacto">
  </p>
  <p>E-mail: 
    <input name="email" type="text" id="email" value="@">
</p>
  <p>Web: 
    <input name="web" type="text" id="web" value="http://">
  </p>
  <p>Opinion de la web: 
    <input name="opinion" type="text" id="opinion" value="tu opinion">
</p>
  <p>Comentario: 
    <textarea name="coment" rows="5" wrap="VIRTUAL" id="coment"></textarea>
</p>
  <p>
    <input type="submit" name="Submit" value="Enviar">
    <input type="reset" name="Submit" value="Borrar todo">
  </p>
</form>
<p>
  <? 

}else{ 

//Estoy recibiendo el formulario, compongo el cuerpo 

$cuerpo = "Formulario enviado desde la pagina web www.trethack.tk\n"; 

$cuerpo .= "Nombre: " . $HTTP_POST_VARS["nombre"] . "\n"; 

$cuerpo .= "Asunto: " . $HTTP_POST_VARS["asunto"] . "\n"; 

$cuerpo .= "E-mail: " . $HTTP_POST_VARS["email"] . "\n"; 

$cuerpo .= "Web: " . $HTTP_POST_VARS["web"] . "\n"; 

$cuerpo .= "Opinion: " . $HTTP_POST_VARS["opinion"] . "\n"; 

$cuerpo .= "Comentario: " . $HTTP_POST_VARS["coment"] . "\n"; 



mail("tumail@tuservidor.com.ar","Formulario recibido",$cuerpo); 





echo "Gracias por rellenar el formulario. Se ha enviado correctamente."; 

} 

?>
</p>
<p>&nbsp;</p>
<p>Script de formulario hecho por el webmaster de <a href="http://www.trethack.tk" title="LA MEJOR WEB DE TODAS WWW.TRETHACK.TK">WwW.TrEtHaCk.Tk</a></p>
</body>
</html>
