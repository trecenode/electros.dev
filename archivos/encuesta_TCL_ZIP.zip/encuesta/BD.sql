CREATE TABLE `encuesta_pre` (
  `ID` int(11) NOT NULL auto_increment,
  `Pregunta` text NOT NULL,
  `Resp1` text NOT NULL,
  `Resp2` text NOT NULL,
  `Resp3` text NOT NULL,
  `Resp4` text NOT NULL,
  `Resp5` text NOT NULL,
  `num_resp` tinyint(4) NOT NULL default '0',
  `activado` tinyint(4) NOT NULL default '0',
  UNIQUE KEY `ID` (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


CREATE TABLE `encuesta_votos` (
  `ID` int(11) NOT NULL auto_increment,
  `ID_pregunta` int(11) NOT NULL default '0',
  `Restringido` varchar(20) NOT NULL default '',
  `Respuesta` tinyint(4) NOT NULL default '0',
  UNIQUE KEY `ID` (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
