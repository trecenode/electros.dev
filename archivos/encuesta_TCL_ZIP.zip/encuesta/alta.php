<?php require_once('config.php'); ?>
<?
// *************** Desactivar ************
if($_GET['accion']==desactivar){
$ID= $_GET['ID'] ;
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "update encuesta_pre set activado='0' where ID='$ID'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
}
// **************** activar **************
if($_GET['accion']==activar){
$ID= $_GET['ID'] ;
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "update encuesta_pre set activado='1' where ID='$ID'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
}
// *************** Borrar ************
if($_GET['accion']==borrar){
$ID = $_GET['ID'] ;
// Eliminamos la encuesta
mysql_select_db($database_encuesta, $encuesta);
$sql = "delete from encuesta_pre where ID='$ID'";
$encuesta_borrar = mysql_query($sql, $encuesta) or die(mysql_error());
// Eliminamos sus votos
mysql_select_db($database_encuesta, $encuesta);
$sql = "delete from encuesta_votos where ID_pregunta='$ID'";
$votos_borrar = mysql_query($sql, $encuesta) or die(mysql_error());
echo "<script> alert('Enquesta borrada amb �xit. '); </script>" ;
}
if($_POST['alta']){
// Recibimos datos del form
$pregunta = $_POST['pregunta'] ;
$sol1 = $_POST['sol1'];
$sol2 = $_POST['sol2'];
$sol3 = $_POST['sol3'];
$sol4 = $_POST['sol4'];
$sol5 = $_POST['sol5'];
$respostes = $_POST['resp'] ;
$activat = $_POST['activat'] ;
if($activat==1){
// Miramos la encuesta activa anterior i la desactivamos
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$ID_encuesta = $row_encuesta_ver['ID'] ;
if($totalRows_encuesta_ver==1){ 
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "update encuesta_pre set activado='0' where ID='$ID_encuesta'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
}}
// Damos de alta la nueva estadistica
mysql_select_db($database_encuesta, $encuesta);
$query_inserta_datos = "insert into encuesta_pre (Pregunta,Resp1,Resp2,Resp3,Resp4,Resp5,num_resp,activado) values ('$pregunta','$sol1','$sol2','$sol3','$sol4','$sol5','$respostes','$activat')";
$inserta_datos = mysql_query($query_inserta_datos, $encuesta) or die(mysql_error());
} 
// ****************** Edicion **************************
if($_POST['editar']){
//recibimos valores
$ID= $_POST['ID'] ;
$pregunta = $_POST['pregunta'] ;
$sol1 = $_POST['sol1'];
$sol2 = $_POST['sol2'];
$sol3 = $_POST['sol3'];
$sol4 = $_POST['sol4'];
$sol5 = $_POST['sol5'];
$respostes = $_POST['resp'] ;
$activat = $_POST['activat'] ;
// Damos de alta la nueva estadistica
mysql_select_db($database_encuesta, $encuesta);
$query_inserta_datos = "update encuesta_pre set Pregunta='$pregunta', Resp1='$sol1',Resp2='$sol2',Resp3='$sol3',Resp4='$sol4',Resp5='$sol5',num_resp='$respostes',activado='$activat' Where ID=$ID";
$inserta_datos = mysql_query($query_inserta_datos, $encuesta) or die(mysql_error());
}
?>
<?php
mysql_select_db($database_encuesta, $encuesta);
$query_votaciones_ver = "SELECT * FROM encuesta_pre";
$votaciones_ver = mysql_query($query_votaciones_ver, $encuesta) or die(mysql_error());
$row_votaciones_ver = mysql_fetch_assoc($votaciones_ver);
$totalRows_votaciones_ver = mysql_num_rows($votaciones_ver);
?>


<table width="442"  border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center"><strong>Pregunta:</strong></div></td>
    <td><div align="center"><strong>Respostes:</strong></div></td>
    <td><div align="center"><strong>Activat:</strong></div></td>
    <td><div align="center"><strong>Acci&oacute;:</strong></div></td>
  </tr>
  <?php do { ?>
  <tr valign="middle">
    <td><? echo $row_votaciones_ver['Pregunta'] ; ?></td>
    <td><? echo $row_votaciones_ver['Resp1']."<br>".$row_votaciones_ver['Resp2']."<br>".$row_votaciones_ver['Resp3']."<br>".$row_votaciones_ver['Resp4']."<br>".$row_votaciones_ver['Resp5'] ; ?></td>
    <td><? if($row_votaciones_ver['activado']==0){ echo "NO"; } else { echo "SI"; } ?></td>
    <td><ul>
      <li><a href="alta.php?accion=borrar&ID=<? echo $row_votaciones_ver['ID'] ; ?>">Borrar</a></li>
      <li><a href="alta.php?accion=editar&ID=<? echo $row_votaciones_ver['ID'] ; ?>">Editar</a></li>
      <li><a href="alta.php?accion=desactivar&ID=<? echo $row_votaciones_ver['ID'] ; ?>">Desactivar</a></li>
      <li><a href="alta.php?accion=activar&ID=<? echo $row_votaciones_ver['ID'] ; ?>">Activar</a></li>
    </ul></td>
  </tr>
  <?php } while ($row_votaciones_ver = mysql_fetch_assoc($votaciones_ver)); ?>
</table>
<p align="center">&nbsp;</p>
<? 
if($_GET['accion']=='editar'){
$ID = $_GET['ID'] ;
mysql_select_db($database_encuesta, $encuesta);
$query_votaciones_ver = "SELECT * FROM encuesta_pre Where ID='$ID'";
$votaciones_ver = mysql_query($query_votaciones_ver, $encuesta) or die(mysql_error());
$row_votaciones_ver = mysql_fetch_assoc($votaciones_ver);
}
?>
<table width="442"  border="1" align="center" cellpadding="0" cellspacing="1">
  <tr>
    <td width="436">Nova enquesta: </td>
  </tr>
  <tr>
    <td align="center" valign="top">      <form name="form1" method="post" action="">
      <div align="center">
        <p>
          <input name="ID" type="hidden" id="ID" value="<? echo $row_votaciones_ver['ID'] ; ?>">
          Pregunta:
            <input name="pregunta" type="text" id="pregunta" value="<? echo $row_votaciones_ver['Pregunta'] ; ?>" size="60">
    </p>
        <table width="100%"  border="0" cellspacing="1" cellpadding="0">
          <tr>
            <td width="43%" rowspan="2"><p>Sol1:
              <input name="sol1" type="text" id="sol1" value="<? echo $row_votaciones_ver['Resp1'] ; ?>">
              <br>Sol2:
              <input name="sol2" type="text" id="sol2" value="<? echo $row_votaciones_ver['Resp2'] ; ?>">
              <br>Sol3:
              <input name="sol3" type="text" id="sol3" value="<? echo $row_votaciones_ver['Resp3'] ; ?>">
              <br>Sol4:
              <input name="sol4" type="text" id="sol4" value="<? echo $row_votaciones_ver['Resp4'] ; ?>">
              <br>Sol5:
              <input name="sol5" type="text" id="sol5" value="<? echo $row_votaciones_ver['Resp5'] ; ?>">
            </p>
              </td>
            <td width="57%" height="57" align="center" valign="top">Numero de respostes: 
              <select name="resp" id="resp">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5" selected>5</option>
              </select></td>
          </tr>
          <tr>
            <td align="center" valign="top">Activat: 
              <select name="activat" id="activat">
                <option value="1" selected>Si</option>
                <option value="0">No</option>
              </select></td>
          </tr>
        </table>
        <p>
          <input type="reset" name="Submit" value="Netejar">
		  <? if($_GET['accion']=='editar'){ ?>
		  <input name="editar" type="submit" id="alta" value="Editar">
		  <? }else { ?>
		  <input name="alta" type="submit" id="alta" value="Alta">
		  <? } ?>
</p> 
      </div>
    </form></td>
  </tr>
</table>
<?php
mysql_free_result($votaciones_ver);
?>
<p align="center">&copy; TCL_ZIP </p>
