<?php require_once('config.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title></title>
</head>

<body leftmargin="0" marginheight="0" marginwidth="0" rightmargin="0" topmargin="0">
<? 
// miramos la pregunta activa i la mostramos los resultados.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
$ID= $row_encuesta_ver["ID"];
mysql_select_db($database_encuesta, $encuesta);
$query_votos = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID'";
$votos = mysql_query($query_votos, $encuesta) or die(mysql_error());
$votos_totales = mysql_num_rows($votos);
?>
<table width="250"  border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3"><strong><? echo $row_encuesta_ver['Pregunta'] ; ?></strong></td>
  </tr>
  <? for ($i = 1; $i <= $maximo_valores; $i++) { ?>
  <tr>
    <td width="84"><? echo $row_encuesta_ver["Resp".$i.""] ;  ?>&nbsp;
    <div align="justify"></div></td>
    <td width="109" valign="middle">
      <table width="99%" height="99%"  border="0" valign="middle" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="middle" bgcolor="#CCCCCC"><?
	mysql_select_db($database_encuesta, $encuesta);
	$query_voto = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID' AND Respuesta = '$i'";
	$voto = mysql_query($query_voto, $encuesta) or die(mysql_error());
	$votos_resp = mysql_num_rows($voto);
	@$percentatge = @( $votos_resp * 100 )/($votos_totales);
	?><table width="<? echo $percentatge ; ?>%"  border="1" align="left" cellpadding="0" cellspacing="0" bgcolor="#CC9900">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
    </table></td>
    <td width="49" valign="middle">    <div align="center"><? $percentatge_redond = floor($percentatge) ; echo $percentatge_redond ; ?>
%</div></td>
  </tr> <? } ?>
  <tr>
    <td colspan="3"><strong>Numero de votos: </strong><? echo $votos_totales ; ?></td>
  </tr> 
 
  
</table>

</body>
</html>
