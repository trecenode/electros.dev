<?
include("ulogin.php") ;
?>
<?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = $_COOKIE["unick"] ;
$comentario = quitar($comentario) ;
$titulo= quitar($titulo) ;
$noticia= quitar($noticia) ;
$noticiaext= quitar($noticiaext) ;
mysql_query("insert INTO noticias (fecha,usuario,titulo,noticia,noticiaext) values ('$fecha','$usuario','$titulo','$noticia','$noticiaext')") ;
echo "La noticia ha sido enviada con �xito. <a href=index.php?id=noticias>volver</a>" ;
mysql_close($conectar) ;
}
?>
<form method="post" action="index.php?id=noticiasenviar">
  T�tulo:<br>
<input type="text" name="titulo" maxlength="100" class="form"><br>
Noticia:<br>
<textarea name="noticia" cols="30" rows="5" class="form"></textarea><br>
Noticia extendida:
<textarea name="noticiaext" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>