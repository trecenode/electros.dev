<?
if($_COOKIE["unick"] ) {
?>
            Bienvenido<br>
<b><? echo $_COOKIE["unick"]  ?></b><br>
            Te encuentras actualmente visitando<br>
            la seccion <a href="index.php?id=<? if($id) { echo $id ; } else { echo "principal" ; } ?>"> 
            <? if($id) { echo $id ; } else { echo "Principal" ; } ?>
            </a> <br> 
            <br>
<a href="index.php?id=uperfil">� Mi perfil</a><a href="index.php?id=usuarios"><br>
</a><a href="usalir.php">� Salir</a><a href="?usuarios"><br>
            <br>
</a><a href="index.php?id=mensajes" >� Mensajes</a> 
<?
include("config.php") ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select id from mensajes where nuevo='0' and destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
if($mensajes == 0) {
?>
<?
}
else {
?>
<script>
function BlinkTxt() {
texto = document.getElementsByTagName('blink');
for (i=0; i<texto.length; i++)
if (texto[i].style.visibility=='hidden') {
texto[i].style.visibility='visible';
} else {
texto[i].style.visibility='hidden';
}
setTimeout('BlinkTxt()',100);
}
onload=BlinkTxt;
</script> <blink>(<? echo $mensajes ; ?>)</blink> <bgsound loop="1" src="newemail.wav">
<?
}
?>
<br>
<br>
<a href="index.php?id=noticiasenviar">� Enviar Noticias<br>
</a><a href="index.php?id=enlacesenviar">� Enviar Enlaces</a><br>
<a href="index.php?id=descargasenviar">� Enviar Descargas</a><br>
<br>
<a href="index.php?id=enlacesenviar&opcion=banner">� Afiliados banner</a><br>
<a href="index.php?id=enlacesenviar&opcion=minibanner">� Afiliados minibanner</a><br>
<?
}
else {
?>
<form method="post" action="uentrar.php">
              Nick:<br>
              <input name="nick" type="text" class="form" size="18">
              <br>
              Contrase�a:<br>
              <input name="contrasena" type="password" class="form" size="18">
			
              <br>
              <br>
              <input type="submit" name="entrar" value="Entrar" class="form">
			  <input type="hidden" name="pagina" value="<? echo $_SERVER['REQUEST_URI'] ?>">
            </form>
            
<a href="index.php?id=uregistrar">� Registrate</a><br>
<a href="index.php?id=ucontrasena">� �Olvide contrase�a?</a><br>
 <br> �Todav�a no tienes una cuenta? Puedes <a href="index.php?id=uregistrar">crearte 
            una</a>. Como usuario registrado tendr�s ventajas como cambiar tu 
            perfil, responder comentarios con tu propio nick y enviar enlaces, 
            descargas y scripts.<br> 
            <?
}
?>