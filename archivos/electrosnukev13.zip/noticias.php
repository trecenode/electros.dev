<?
include("config.php") ;
if($n) {
$resp = mysql_query("select * FROM noticias where id='$n'") ;
$datos = mysql_fetch_array($resp) ;
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Se agregar�n los espacios correspondientes a la noticia extendida
$noticiaext = $datos[noticiaext] ;
$noticiaext = str_replace("\r\n","<br>",$noticiaext) ;
// Funci�n para transformar URLs en enlaces en la noticia extendida
$noticiaext = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$noticiaext) ;
// Codigo especial bbcode en la noticia extendida: [b]texto negrita[/b], [img]eforo_imagenes/carpeta.gif[/img]
$noticiaext = str_replace("[b]","<b>",$noticiaext) ;
$noticiaext = str_replace("[/b]","</b>",$noticiaext) ;
$noticiaext = str_replace("[img]","<img src=\"",$noticiaext) ;
$noticiaext = str_replace("[/img]","\" border=\"0\">",$noticiaext) ;
// Colorear el codigo php en la noticia extendida, utilizar: [codigo]codigo php aqui[/codigo]
if(strstr($noticiaext,"[codigo]")) {
$partes = explode("[codigo]",$noticiaext) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$noticiaext = implode("",$partes) ;
}
// fin colorear codigo php en la noticia extendida
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr>
<td class="tabla_titulo"><p class=t1><? echo $datos[titulo] ?></p></td>
<td class="tabla_titulo"><div align=right><? echo $fecha ?></div></td>
</tr>
<tr>
<td colspan=2 class="tabla_mensaje">
<? echo $datos[noticia] ?><br><br>
<? echo $noticiaext ?><br><br>
<hr>
<b>Enviada por:</b> <? echo $datos[usuario] ?><br>
<a href="index.php?id=noticias">� Regresar a la p�gina principal</a>
<p>
<?
mysql_free_result($resp) ;
echo "<p><b>Comentarios</b>" ;
// Mostrar la lista de comentarios de 5 en 5
$mostrar = 5 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * FROM noticiascom where noticia='$n' ORDER BY id desc LIMIT $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mas comentarios." ; }
else {
$comentarios = mysql_num_rows($resp) ;
// mostrar el total de comentarios
$resp2 = mysql_query("select * FROM noticiascom where noticia='$n' ORDER BY id desc") ;
$comentarios2 = mysql_num_rows($resp2) ;
?>
<p><b>Total de comentarios:</b> <? echo $comentarios2 ?>
<p>
<?
while($datos = mysql_fetch_array($resp)) {
// Mostrar fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Codigo especial bbcode en los comentarios: [b]texto negrita[/b], [img]eforo_imagenes/carpeta.gif[/img]
$datos[comentario] = str_replace("[b]","<b>",$datos[comentario]) ;
$datos[comentario] = str_replace("[/b]","</b>",$datos[comentario]) ;
$datos[comentario] = str_replace("[img]","<img src=\"",$datos[comentario]) ;
$datos[comentario] = str_replace("[/img]","\" border=\"0\">",$datos[comentario]) ;
// Colorear el codigo php en los comentarios, utilizar: [codigo]codigo php aqui[/codigo]
if(strstr($datos[comentario],"[codigo]")) {
$partes = explode("[codigo]",$datos[comentario]) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$datos[comentario] = implode("",$partes) ;
}
// fin colorear codigo php en los comentarios
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
  <tr> 
  <?
$resp3 = mysql_query("select id,avatar from usuarios where nick='$datos[usuario]'") ;
$datos3 = mysql_fetch_array($resp3) ;
if($datos3[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<td width=4% rowspan=2 class=tabla_subtitulo><center><img src=\"eforo_imagenes/avatares/$datos3[id].$datos3[avatar]\"></center> </td>" ;
}
echo $avatar ;
?>
<td  class="tabla_subtitulo"><b>&lt;<? echo $datos[usuario] ?>&gt;</b></td>
<td  class="tabla_subtitulo"><div align=right><b><? echo $fecha ?></b></div></td>
</tr>
<tr> 
<td colspan=2 class="tabla_mensaje"> <? echo $datos[comentario] ?> <br>
<?
// Mostrar la web del usuario que ha escrito en los comentarios
$resp4 = mysql_query("select id,web from usuarios where nick='$datos[usuario]'") ;
$datos4 = mysql_fetch_array($resp4) ;
if($datos4[web] == "") {
$web = "" ;
}
else {
$web = "<hr><a href='$datos4[web]'target='_blank'>$datos4[web]</a>" ;
}
echo $web ;
?>
</td>
</tr>
</table><br>
<?
}
?>
<?
}
// mostrar siguientes 5 comentarios noticias
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=index.php?id=noticias&n=$n>Anteriores $mostrar comentarios noticias</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=index.php?id=noticias&n=$n&desde=$anteriores>Anteriores $mostrar comentarios noticias</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $comentarios2) {
echo "<a href=index.php?id=noticias&n=$n&desde=$desde>Siguientes $mostrar comentarios noticias</a>" ;
}
if($desde > $comentarios2) {
echo "<a href=index.php?id=noticias&n=$n&desde=$desde>Siguientes $mostrar comentarios noticias</a>" ;
}
mysql_free_result($resp) ;
?>
<p>
<p><b>Escribir comentario</b>
<p>
<form method=post action="noticiascom.php">
<input type="hidden" name="noticia" value="<? echo $n ?>" >
Comentario:<br>
<textarea name="comentario" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
</td>
</tr>
</table>
<?
}
else {
$mostrar = 10 ;
$resp = mysql_query("select * FROM noticias ORDER BY id desc LIMIT $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// definir la suma del total de comentarios en una noticia
$resp2 = mysql_query("select id FROM noticiascom where noticia='$datos[id]'") ;
$comentarios = mysql_num_rows($resp2) ;
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr> 
<td colspan="2" class="tabla_titulo"><p class=t1><? echo $datos[titulo] ?></p></td>
<td class="tabla_titulo"><div align=right><? echo $fecha ?></div></td>
</tr>
<tr> 
<td colspan=3 class="tabla_mensaje"> <? echo $datos[noticia] ?>&nbsp;</td>
</tr>
<tr> 
<td class="tabla_mensaje"><a href="index.php?id=noticias&n=<? echo $datos[id] ?>" >Ver 
m�s</a> </td>
<td class="tabla_mensaje"><b>Comentarios:</b> <? echo $comentarios ?></td>
<td class="tabla_mensaje"><div align="right"><b>Enviada por: </b><? echo $datos[usuario] ?></div></td>
</tr>
</table>
<br>
<?
}
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>