<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Registrar nuevo usuario</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<?
include("config.php") ;
if($registrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$email= quitar($email) ;
// Comprobar que el usuario existe en la base de datos
$resp = mysql_query("select id from $tabla_usuarios where nick='$nick' or email='$email'") ;
if(mysql_num_rows($resp) != 0) {
echo "Ya existe un usuario con ese nick o email en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
}
else {
$fecha = time() ;
$contrasena = quitar($contrasena) ;
$ip = $REMOTE_ADDR ;
mysql_query("insert into $tabla_usuarios (fecha,nick,contrasena,email,ip) values ('$fecha','$nick','$contrasena','$email','$ip')") ;
echo "Has sido registrado con �xito. Haz click <a href=foro.php>aqu�</a> para ir a la p�gina principal." ;
}
}
else {
?>
<p>Como usuario registrado podr�s escribir nuevos temas y responder mensajes, adem�s de que podr�s editarlos
en cualquier momento que desees, tambi�n podr�s tener un perfil de usuario y una bandeja de mensajes privados.
Para registrarte s�lo necesitas nick, contrase�a y email, los dem�s datos los puedes completar en tu perfil.
<script>
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo m�nimo 3 caract�res') ; return false ; }
if(formulario.contrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido') ; return false ; }
}
</script>
<div align="center">
<form name="formulario" method="post" action="fororegistrar.php" onsubmit="return revisar()">
<b>Nick:</b><br>
<input type="text" name="nick" maxlength="20" class="form"><br>
<b>Contrase�a:</b><br>
<input type="password" name="contrasena" maxlength="20" class="form"><br>
<b>Email:</b><br>
<input type="text" name="email" maxlength="40" class="form"><br><br>
<input type="submit" name="registrar" value="Registrar" class="form">
</form>
</div>
<?
}
mysql_close($conectar) ;
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
