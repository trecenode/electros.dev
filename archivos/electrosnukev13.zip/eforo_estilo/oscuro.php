<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #aaaaaa ;
text-align: justify ;
background: #000000 ;
scrollbar-face-color: #505050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #252525 ;
scrollbar-highlight-color: #757575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #cccccc ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #cccccc ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #cccccc ;
}
/* Tablas del foro */
.tabla_principal {
border: #757575 1 solid ;
}
.tabla_titulo {
background: #303030 ;
}
.tabla_subtitulo {
background: #404040 ;
}
.tabla_mensaje {
background: #505050 ;
}
/* Formulario */
.form {
border: #757575 1 solid ;
background: #303030 ;
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
}
</style>
