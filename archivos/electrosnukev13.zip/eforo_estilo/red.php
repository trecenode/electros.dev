<!-- Titulo: red.php
Autor: -==[ZagreB]==-
Fecha: 17 de Diciembre del 2003 -->
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #FF0000 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #FF0000 ;
scrollbar-highlight-color: #ff0000 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #FFFFFF ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #FF0000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #FF0000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #CCCCCC 1 solid ;
}
.tabla_titulo {
background: #ff0000 ;
}
.tabla_subtitulo {
background: #FB7575 ;
}
.tabla_mensaje {
background: #EEEEEE ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>