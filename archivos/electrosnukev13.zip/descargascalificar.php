<?
if($enviar) {
if(!$HTTP_COOKIE_VARS["descargas$e"]) {
include("config.php") ;
$resp = mysql_query("select puntos,votos from descargas where id='$e'") ;
$datos = mysql_fetch_array($resp) ;
$puntos = $datos[puntos] + $puntos ;
$votos = $datos[votos] + 1 ;
$calificacion = round($puntos / $votos,2) ;
mysql_query("update descargas set puntos='$puntos',votos='$votos',calificacion='$calificacion' where id='$e'") ;
setcookie("descargas$e","descargas$e",time()+86400) ;
header("location: index.php?id=descargas&calificar=si") ;
}
else {
header("location: index.php?id=descargas&calificar=no") ;
}
}
?>