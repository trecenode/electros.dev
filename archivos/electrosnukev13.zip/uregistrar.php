<?
include("config.php") ;
if($registrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$email= quitar($email) ;
// Comprobar que el usuario existe en la base de datos
$resp = mysql_query("select id from usuarios where nick='$nick' or email='$email'") ;
if(mysql_num_rows($resp) != 0) {
echo "Ya existe un usuario con ese nick o email en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
}
else {
$fecha = time() ;
$contrasena = quitar($contrasena) ;
$ip = $REMOTE_ADDR ;
mysql_query("insert into usuarios (fecha,nick,contrasena,email,ip) values ('$fecha','$nick','$contrasena','$email','$ip')") ;
echo "Has sido registrado con �xito. Haz click <a href=index.php>aqu�</a> para ir a la p�gina principal." ;
}
}
else {
?>
<p>Los datos marcados con un asterisco (*) son obligatorios.
<script>
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo m�nimo 3 caract�res') ; return false ; }
if(formulario.contrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=uregistrar" onsubmit="return revisar()">
<b>* Nick:</b><br>
<input type="text" name="nick" maxlength="20" class="form"><br>
<b>* Contrase�a:</b><br>
<input type="password" name="contrasena" maxlength="20" class="form"><br>
<b>* Email:</b><br>
<input type="text" name="email" maxlength="40" class="form"><br><br>
<input type="submit" name="registrar" value="Registrar" class="form">
</form>
<?
}
mysql_close($conectar) ;
?>