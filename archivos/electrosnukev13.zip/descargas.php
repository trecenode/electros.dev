<?
include("config.php") ;
if($e) {
$resp = mysql_query("select urlsitio,descarga from descargas where id='$e'") ;
if(mysql_num_rows($resp) != 0) {
$datos = mysql_fetch_array($resp) ;
if($datos[descarga] == 1) { $datos[urlsitio] = "$carpetadondeseguardanlosarchivos/$datos[urlsitio]" ; }
mysql_query("update descargas set visitas=visitas+1 where id='$e'") ;
?>
<script>location='<? echo $datos[urlsitio] ?>'</script>
<?
}
else {
echo "No existe esta Descarga en la base de datos." ;
}
}
if($calificar == "si") {
echo "<p><b>Has votado por la Descarga.</b>" ;
}
if($calificar == "no") {
echo "<p><b>S�lo puedes votar una vez por d�a.</b>" ;
}
?>
<p class="t1">Descargas</p>
<?
// clasificar las descargas
if(isset($c)) {
$clasificacion = array("$descarga0","$descarga1","$descarga2","$descarga3","$descarga4","$descarga5","$descarga6","$descarga7","$descarga8","$descarga9") ;
?>
<p><b>Categor�a:</b> <? echo $clasificacion[$c] ?>
<?
$mostrar = 25 ;
$resp = mysql_query("select id from descargas where categoria='$c'") ;
$descargas = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
?>
<p><b>Total de descargas:</b> <? echo $descargas ?> | <a href="index.php?id=descargas">Volver</a>
<p> 
<?
$mostrar = 6 ; 
if(!$desde) { $desde = 0 ; }  
$resp = mysql_query("select * from descargas where categoria='$c' order by titulo asc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
while($datos = mysql_fetch_array($resp)) {
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
<form method='post' action='descargascalificar.php?d=<? echo $datos[id] ?>'>
<tr> 
<?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
<td width='97%' height="70" class="tabla_subtitulo"> <a href='<?
if($c == "6") {
echo "$datos[urlsitio]" ;
}
else {
echo "descargas.php?e=$datos[id]" ;
}
?>' target='<?
if($c == "6") {
echo "_self" ;
}
else {
echo "_blank" ;
}
?>'>� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?><br> 
        <?
if($c == "6") {
echo "" ;
}
else {
?>
        <b>Visitas:</b> <? echo $datos[visitas] ?> 
        <?
}
?>
        <b>Votos:</b> <? echo $datos[votos] ?> <b> 
        <?
if($datos[urlminibanner] == "") {
?>
        <?
}
else {
?>
        | <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
        <?
}
?>
        <b> 
        <? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
        | <a href="index.php?id=descargaseditar&descargasid=<? echo $datos[id] ?>"> 
        Editar</a> | 
        <?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> 
		<select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<br>
<?
} 
mysql_free_result($resp) ;
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=index.php?id=descargas&c=$c>Anteriores $mostrar descargas</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=index.php?id=descargas&c=$c&desde=$anteriores>Anteriores $mostrar descargas</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $descargas) {
echo "<a href=index.php?id=descargas&c=$c&desde=$desde>Siguientes $mostrar descargas</a>" ;
}
if($desde > $descargas) {
echo "<a href=index.php?id=descargas&c=$c&desde=$desde>Siguientes $mostrar descargas</a>" ;
} 
}
else {
?>
<p>Para agregar descargas debes ser un usuario registrado. Si ya estas registrado 
  haz click <a href="index.php?id=descargasenviar">aqu�</a>. 
<p>
<?
$resp = mysql_query("select id from descargas where categoria=0") ;
$c0 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=1") ;
$c1 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=2") ;
$c2 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=3") ;
$c3 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=4") ;
$c4 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=5") ;
$c5 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=6") ;
$c6 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=7") ;
$c7 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=8") ;
$c8 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=9") ;
$c9 = mysql_num_rows($resp) ;
?>
<div align="center"> 
  <table width="80%" border="0" align="center" cellpadding="4" cellspacing="0" class="tabla">
    <tr valign="top"> 
      <td width="285"> <div align="left"><b>� <a href="index.php?id=descargas&c=0"> 
          <?  echo $descarga0 ?>
          <span class="n"> (<? echo $c0 ?></span>)</a></b><br>
          <? echo $descarga0definicion ?> <br>
        </div></td>
      <td width="261"> <div align="left"><b>� <a href="index.php?id=descargas&c=5"> 
          <?  echo $descarga5 ?>
          <span class="n"> (<? echo $c5 ?></span>)</a></b><br>
          <? echo $descarga5definicion ?> </div></td>
    </tr>
    <tr valign="top"> 
      <td><div align="left"><b>� <a href="index.php?id=descargas&c=1"> 
          <?  echo $descarga1 ?>
          <span class="n"> (<? echo $c1 ?></span>)</a></b><br>
          <? echo $descarga1definicion ?> </div></td>
      <td><div align="left"><b>� <a href="index.php?id=descargas&c=6"> 
          <?  echo $descarga6 /*Seccion ideal para edonkey links*/ ?>
          <span class="n"> (<? echo $c6 ?></span>)</a></b><br>
          <? echo $descarga6definicion ?> </div></td>
    </tr>
    <tr valign="top"> 
      <td><div align="left"><b>� <a href="index.php?id=descargas&c=2"> 
          <?  echo $descarga2 ?>
          <span class="n"> (<? echo $c2 ?></span>)</a></b><br>
          <? echo $descarga2definicion ?> </div></td>
      <td><div align="left"><b>� <a href="index.php?id=descargas&c=7"> 
          <?  echo $descarga7 ?>
          <span class="n"> (<? echo $c7 ?></span>)</a></b><br>
          <? echo $descarga7definicion ?> </div></td>
    </tr>
    <tr valign="top"> 
      <td><b>� <a href="index.php?id=descargas&c=3"> 
        <?  echo $descarga3 ?>
        <span class="n"> (<? echo $c3 ?></span>)</a></b><br> <? echo $descarga3definicion ?> 
      </td>
      <td><b>� <a href="index.php?id=descargas&c=8"> 
        <?  echo $descarga8 ?>
        <span class="n"> (<? echo $c8 ?></span>)</a></b><br> <? echo $descarga8definicion ?> 
      </td>
    </tr>
    <tr valign="top"> 
      <td><b>� <a href="index.php?id=descargas&c=4"> 
        <?  echo $descarga4 ?>
        <span class="n"> (<? echo $c4 ?></span>)</a></b><br> <? echo $descarga4definicion ?> 
      </td>
      <td><b>� <a href="index.php?id=descargas&c=9"> 
        <?  echo $descarga9 ?>
        <span class="n"> (<? echo $c9 ?></span>)</a></b><br> <? echo $descarga9definicion ?> 
      </td>
    </tr>
  </table>
</div>
<div align="center"><b>
<div align="center" class="t1">Buscar Descargas</div><br>
<div align="center">
<form method="post" action="index.php?id=descargas" form name="formulario" >
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="palabras" size="30" maxlength="65" class="form"><p>
<input type="submit" name="buscar" value="Buscar" class="form ">
</form>
<?
if($buscar) {
include("config.php") ;
$resp = mysql_query("select * from descargas where descripcion like '%$palabras%'") ;
if(mysql_num_rows($resp) == 0) {
echo "No se encontraron resultados en la b�squeda." ;
}
else {
while($datos = mysql_fetch_array($resp)) {
?>
<table width='100%' border='0' cellpadding='5' cellspacing='0' class='tabla_mensaje'>
  <tr> 
    <td width='75%' height='15' ><div> <a href='descargas.php?e=<? echo $datos[id] ?>' target='_blank'>* 
        <? echo $datos[titulo] ?></a></div></td>
    <td width='25%'></td>
  </tr>
  <tr> 
    <td colspan='2'><? echo $datos[descripcion] ?></td>
  </tr>
  <tr> 
    <td width='100%' colspan='2'>Enviada por: <? echo $datos[usuario] ?></td>
  </tr>
</table><br>
<?
}
}
}
?>
</div>
<p class="t1">Descarga seleccionada aleatoriamente 
<p>
<?
$resp = mysql_query("select * from descargas order by rand() limit 1") ;
$datos = mysql_fetch_array($resp) ;
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
  <form method='post' action='descargascalificar.php?d=<? echo $datos[id] ?>'>
    <tr> 
      <?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
      <td width='97%' height="70" class="tabla_subtitulo"> <a href='<?
if($c == "6") {
echo "$datos[urlsitio]" ;
}
else {
echo "descargas.php?e=$datos[id]" ;
}
?>' target='<?
if($c == "6") {
echo "_self" ;
}
else {
echo "_blank" ;
}
?>'>� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?><br> 
        <?
if($c == "6") {
echo "" ;
}
else {
?>
        <b>Visitas:</b> <? echo $datos[visitas] ?> 
        <?
}
?>
        <b>Votos:</b> <? echo $datos[votos] ?> <b> 
        <?
if($datos[urlminibanner] == "") {
?>
        <?
}
else {
?>
        | <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
        <?
}
?>
        <b> 
        <? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
        | <a href="index.php?id=descargaseditar&descargasid=<? echo $datos[id] ?>"> 
        Editar</a> | 
        <?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> 
		<select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<?
mysql_free_result($resp) ;
?>
<p class="t1">Ultimos 10 descargas
<p>
<?
$mostrar = 10 ;
$resp = mysql_query("select * from descargas order by id desc limit $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
  <form method='post' action='descargascalificar.php?d=<? echo $datos[id] ?>'>
    <tr> 
      <?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
      <td width='97%' height="70" class="tabla_subtitulo"> <a href='<?
if($c == "6") {
echo "$datos[urlsitio]" ;
}
else {
echo "descargas.php?e=$datos[id]" ;
}
?>' target='<?
if($c == "6") {
echo "_self" ;
}
else {
echo "_blank" ;
}
?>'>� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?><br> 
        <?
if($c == "6") {
echo "" ;
}
else {
?>
        <b>Visitas:</b> <? echo $datos[visitas] ?> 
        <?
}
?>
        <b>Votos:</b> <? echo $datos[votos] ?> <b> 
        <?
if($datos[urlminibanner] == "") {
?>
        <?
}
else {
?>
        | <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
        <?
}
?>
        <b> 
        <? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
        | <a href="index.php?id=descargaseditar&descargasid=<? echo $datos[id] ?>"> 
        Editar</a> | 
        <?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> 
		<select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<br>
<?
}
mysql_free_result($resp) ;
?>
<?
}
?>
