<?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$comentario = quitar($comentario) ;
if($_COOKIE["unick"]) { $usuario = $_COOKIE["unick"] ; } else { $usuario = "Invitado" ; }
mysql_query("insert INTO noticiascom (noticia,fecha,usuario,comentario) values ('$noticia','$fecha','$usuario','$comentario')") ;
mysql_close($conectar) ;
header("location: index.php?id=noticias&n=$noticia") ;
}
?>