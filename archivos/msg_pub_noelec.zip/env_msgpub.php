<?
// SCRIPT BASADO EN EL DE PHPMYSQL
//  HECHO EN MYSQL POR PC-Drivers

// ---------------------
// VARIABLES A MODIFICAR
$pagina = "env_msgpub.php"; // Nombre de �sta p�gina


if ($env=="") {
if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
  }  
  elseif (isset($_SERVER['HTTP_VIA'])) {  
    $ip = $_SERVER['HTTP_VIA'];  
  }  
  elseif (isset($_SERVER['REMOTE_ADDR'])) {  
    $ip = $_SERVER['REMOTE_ADDR'];  
  }  
  else {  
    $ip = "Desconocida";  
  }  
  $fecha= date("j-m-20y, H:ia");
  ?>
<div align="center">
  <p><strong>Transmisi&oacute;n de Mensaje P&uacute;blico: </strong></p>
  <form name="form1" method="post" action="<? echo $pagina; ?>?env=1">
    Nick: 
    <input name="nick" type="text" id="nick">
    <br>
    Mensaje:
    <input name="mensaje" type="text" id="mensaje" size="40" maxlength="255">
  <input name="ip" type="hidden" id="ip" value="<? echo $ip; ?>">
    <input name="msm" type="hidden" id="msm" value="1">
  <input name="fecha" type="hidden" id="fecha" value="<? echo $fecha; ?>">
  <br>
  <br>
  <input type="submit" name="Submit" value="Enviar">
  </form>
  <p><strong></strong></p>
</div>
<? } else if ($env=="1") {
include ("config.php");
mysql_query("truncate table mpublico_mensajes") ;
mysql_query("insert into mpublico_mensajes (mensaje,nick,ip,fecha,msm) values ('$mensaje','$nick','$ip','$fecha','$msm')") ;
} 
?>