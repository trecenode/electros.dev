<?
include ("config.php");
$u = "1";
$resp = mysql_query("select * from mpublico_mensajes where msm='$u'") ;
$datos = mysql_fetch_array($resp) ;
$mensaje = $datos[mensaje];
$mensaje = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a class=texto_bansms href=\"\\0\" target=\"_blank\">\\0</a>",$mensaje) ; 
?>
<MARQUEE onMouseOver='stop()' onMouseOut='start()' scrollamount='5' width="100%" height=10 align="middle">
<b><? echo $datos[nick]; ?></b>: <? echo $mensaje; ?>
</marquee>
