<?
/********************************************/
/***SCRIPT CREADO POR RINGOWEB*************/
/***7/11/03*****VISITEN MI WEB*********/
/****HTTP://RINGOWEB.MUNDO-IRC.ORG****/
/****GRACIAS XDDDD*************************/
/*******************************************/
include("config.php");
if($accion=="firmar") {//si a decidido firmar el libro....
	if($enviar) {//si a pulsado enviar.....
	$fecha=date("j/m/y");
	mysql_query("INSERT into libro (nick,mensaje,valoracion,web) VALUES ('$nick','$mensaje','$valoracion','$web')") or die (mysql_error());
	echo "Gracias por firmar nuestro libro de visitas<br><a href=\"ringoBook.php\">Volver</a>";
	}
	if(!$enviar) {//si toavia no a pulsao enviar se muestra el formulario
	echo "<div align=\"center\"><form method=\"POST\" action=\"ringBook.php?accion=firmar\">
       <b>.:Nick:.</b><br>
  	<input type=\"text\" name=\"nick\" size=\"20\"><br>
  	<b>.:Tu Web:.<br>
  	<input type=\"text\" name=\"web\" size=\"20\"><br>
  	.:Valoracion:.<br>
  	<select size=\"1\" name=\"valoracion\">
  	<option>10</option>
  	<option>9</option>
  	<option>8</option>
  	<option>7</option>
  	<option>6</option>
  	<option>5</option>
  	<option>4</option>
 	<option>3</option>
  	<option>2</option>
  	<option>1</option>
  	</select><br>
  	.:Mensaje:.<br>
  	<textarea rows=\"5\" name=\"mensaje\" cols=\"20\"></textarea></b><br>
  	<input type=\"submit\" value=\"Enviar\" name=\"enviar\"></p>
	</form></div>";
	}
}
if(!$accion) {
 $consulta=mysql_query("SELECT nick,mensaje,valoracion,web from libro order by id desc") or die (mysql_error());
 $lineas=mysql_query("SELECT nick,mensaje,valoracion,web from libro");
 $total=mysql_num_rows($lineas);
 echo "<center>";
 echo "<a href=\"ringoBook.php?accion=firmar\"><b>.:Firmar Libro:.</b></a><br>";
 echo "<b>Numero de firmas:</b>$total";
 echo"</center>";
 while($sql=mysql_fetch_array($consulta)) {
 $mensaje=$sql[mensaje];
 /***Emoticonos********************************************/
 $mensaje = str_replace(":D","<img src=\"emoticon/alegre.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":8","<img src=\"emoticon/asustado.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":P","<img src=\"emoticon/burla.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":S","<img src=\"emoticon/confundido.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":!","<img src=\"emoticon/exclamacion.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":>","<img src=\"emoticon/flecha.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":(1","<img src=\"emoticon/demonio.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":(2","<img src=\"emoticon/demonio2.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":?","<img src=\"emoticon/duda.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":y","<img src=\"emoticon/idea.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":-(","<img src=\"emoticon/enojado.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(";)","<img src=\"emoticon/guino.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":'(","<img src=\"emoticon/llorar.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":?","<img src=\"emoticon/pregunta.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":lol","<img src=\"emoticon/lol.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":M","<img src=\"emoticon/moda.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":|","<img src=\"emoticon/neutral.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":)","<img src=\"emoticon/risa.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":-)","<img src=\"emoticon/sonrisa.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":R","<img src=\"emoticon/sonrojado.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":O","<img src=\"emoticon/sorprendido.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 $mensaje = str_replace(":(","<img src=\"emoticon/triste.gif\" width=\"15\" height=\"15\">",$mensaje) ;
 /********HASTA AQUI LOS EMOTICONOS****************/
 echo "
 <table cellspacing=\"1\" style=\"border-collapse: collapse; border-left: 1px solid #F3F3F3; border-right-width: 1; border-top-width: 1; border-bottom: 1px solid #F3F3F3\" width=\"100%\">
 <tr>
 <td width=\"83%\"><a href=\"$sql[web]\" target=\"_blank\"><b>$sql[nick]</b></a></td>
 <td width=\"17%\">$sql[fecha]</td>
 </tr>
 <tr>
 <td width=\"100%\" colspan=\"2\"><b>Valoracion:</b>$sql[valoracion]<br><b>Comentarios:</b>$mensaje</td>
 </tr>
 </table>\n";
 }
}
?>