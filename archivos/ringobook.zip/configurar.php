<?
$dbhost = "localhost" ;
$dbuser = "tuUser" ;
$dbpass = "tu pass" ;
$db = "Nombre de la base de datos" ;
$conectar = mysql_connect($dbhost,$dbuser,$dbpass) ; mysql_select_db($db,$conectar);
?> 