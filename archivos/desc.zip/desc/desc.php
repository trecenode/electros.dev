<SCRIPT type="text/javascript">
<!--
function showimage() {
if (!document.images)
return
document.images.format.src=
'descargas/formato/' + document.formulario.format.options[document.formulario.format.selectedIndex].value
}
//-->
</SCRIPT>
<?
include("config.php");
#espec�fica tu nombre de usuario en tu web (exacto)#
$admin = "Mefisto";
switch ($funcion){
case nd:
$fecha=date("d/m/Y");
if($_POST["titulo"] == ""){
echo "Falt� titulo <a href=javascript:history.back(1)>volver.</a>";
}else if($_POST["url"] == ""){
echo "Falt� <b>url</b> <a href=javascript:history.back(1)>volver.</a>";
}else{
$ins = mysql_query("INSERT INTO desc2 (titulo,categoria,descripcion,formato,cformat,url,autor,fecha) VALUES
('$titulo','$categoria','$descripcion','$format','$cformat','$url','$autor','$fecha')");
echo 'Descarga puesta con exito.';
}
break;
case agc:
if($_POST["cnew"] == ""){
echo "Falt� un titulo para la categor�a <a href=javascript:history.back(1)>volver.</a>";
}else if($_POST["descripcion"] == ""){
echo "Falt� una descripci�n <a href=javascript:history.back(1)>volver.</a>";
}else{
$ins = mysql_query("INSERT INTO desc_cat2 (titulo,descripcion) VALUES
('$cnew','$descripcion')");
echo "Categoria agregada a la mysql.";
}
break;

default:
$result=mysql_query("SELECT * 
FROM `desc_cat2` ORDER BY `titulo`");?>
<SCRIPT type="text/javascript">
<!--
function showimage() {
if (!document.images)
return
document.images.format.src=
'descargas/formato/' + document.formulario.format.options[document.formulario.format.selectedIndex].value
}
//-->
</SCRIPT>

<form action=?id=desc&funcion=nd method=post name="formulario">
  <table border=0>
    <tr> 
      <td>Titulo:</td>
      <td><input name=titulo type=text class="casillas"></td>
    </tr>
    <tr> 
      <td>Categoria:</td>
      <td> <select name=categoria class="casillas">
          <? #hago un listado de todas las categorias ;)
while($cat=mysql_fetch_array($result)){
echo "
<option value='$cat[id]'>$cat[titulo]</option>";
} ?>
        </select></td>
    </tr>
    <tr> 
      <td>Descripci�n:</td>
      <td><textarea name=descripcion cols="35" rows="7" class="casillas"></textarea></td>
    </tr>
    <tr> 
      <td>Url:</td>
      <td><input name=url type=text class="casillas"></td>
    </tr>
    <tr> 
      <td>Formato</td>
      <td><select name="format" id="format" onChange="showimage()" class="casillas">
          <option value="desconocido.gif">Desconocido</option>
          <option value="exe.gif">EXE</option>
          <option value="txt.gif">TXT</option>
          <option value="pdf.gif">PDF</option>
          <option value="htm.gif">HTML</option>
          <option value="php.gif">PHP</option>
		  <option value="img.gif">Imagen</option>
          <option value="word.gif">WORD</option>
        </select>
        <img src="/descargas/formato/desconocido.gif" alt="" name="format"> <br> 
      </td>
    </tr>
    <tr>
      <td>Formato de compresi&oacute;n</td>
      <td> <select name="cformat" class="casillas">
	  <option value="zip.gif">Zip</option>
	  <option value="rar.gif">Rar</option>
	  <option value="another.gif">Otro..</option>
	  
        </select></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input name=autor type=hidden value="<? echo $_COOKIE["unick"];?>"></td>
    </tr>
    <tr> 
      <td colspan=2><input type=submit value=Enviar></td>
    </tr>
  </table>
</form>
<? if($_COOKIE["unick"] == $admin){

//Agregar categorias
echo"<br>
<u>Agregar categorias.</u><br>
<form name=form method=post action=?id=desc&funcion=agc>
  <table border=0>
    <tr>
      <td>Categoria</td>
      <td><input type=text name=cnew class=casillas></td>
    </tr>
	<tr><td>Descripci�n</td><td><textarea name=descripcion class=casillas rows=5 cols=44></textarea></td>
	</tr>
    <tr>
      <td colspan=2><input type=submit name=Submit value=Agregar></td>
    </tr>
  </table>
</form>";
}else{
echo "S�lo el administrador general puede agregar categorias...";
}
break;


}
/*espero ke te guste el script*/
?><p><!--Borra esto si kieres pero me har�as un gran favor si lo dejas-->
<b>By <a href="http://psychomx.cjb.net" target="_blank" title="Psycho MX">Mefisto.</a></b></p>