CREATE TABLE desc2 (
  id int(7) NOT NULL auto_increment,
  titulo varchar(100) NOT NULL default '',
  categoria varchar(10) NOT NULL default '',
  descripcion varchar(250) NOT NULL default '',
  formato varchar(20) NOT NULL default 'desconocido.gif',
  cformat varchar(20) NOT NULL default 'another.gif',
  url text NOT NULL,
  autor text NOT NULL,
  fecha text NOT NULL,
  KEY id (id)
) TYPE=MyISAM;


CREATE TABLE desc_cat2 (
  id int(10) NOT NULL auto_increment,
  titulo varchar(100) NOT NULL default '',
  descripcion varchar(250) NOT NULL default '',
  KEY id (id)
) TYPE=MyISAM COMMENT='ke webaXD';

    