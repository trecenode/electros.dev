<?php 
require("config.php");
$conectar=mysql_connect("$host","$user","$pass");
mysql_select_db("$db",$conectar);
$result=mysql_query("select url from desc2 where id='$id'");
$datos = mysql_fetch_array($result) ;
header("location:$datos[url]");
?>