           <table width=80% border=0><tr><td> <?php 
require("config.php");
switch($da){
default:
echo "<ul>";
$result=mysql_query("select * from desc_cat2");
while($row=mysql_fetch_array($result)){
$resp = mysql_query("select id from desc2 where categoria='$row[id]'") ;
$total = mysql_num_rows($resp) ;

echo "<li><a href=descargas.php?da=ver&categoria=$row[id]>$row[titulo]($total)</a><br>$row[descripcion]</li>";
}
echo"</ul>"; ?>       <form action="?id=descargas" method="post">
	   <table width="85%" border="0">
	   <tr>
                  <td align="center">
<input type="text" name="words" class="casillas">
                  </td>
                </tr>
	   <tr>
                  <td align="center">
<input type="submit" name="buscar" value="Buscar">
                  </td>
                </tr></table></form>
<?php
break;
case ver:
#gracias al script de paginar :)#
if (!isset($pg))
$pg = 0;
$cantidad = 15;
$inicial = $pg * $cantidad;
//realizamos la busqueda en la base de datos
$pegar = "SELECT * FROM desc2 where categoria='$categoria' ORDER BY id DESC LIMIT $inicial,$cantidad";
$cad = mysql_db_query($db,$pegar) or die (mysql_error());

//calculamos las paginas a mostrar

$contar = "SELECT * FROM desc2";
$contarok = mysql_db_query($db,$contar);
$total_records = mysql_num_rows($contarok);
$pages = intval($total_records / $cantidad);

//imprimiendo los resultados
echo "<br>";

while ($row = mysql_fetch_array($cad))
{
if($row[cformat] == ""){
$formato = "<img src=descargas/formato/another.gif alt='Sin compresion o compresion no especificada'>";
}else{
$formato = "<img src=descargas/formato/$row[cformat]>";
}
echo "
<table width=75% border=0 cellspacing=0 cellpadding=0>
  <tr> 
    <td width=153><a href=espejo.php?id=$row[id] target=_blank><img src=descargas/down.gif border=0>$row[titulo]</a></td>
    <td width=190>&nbsp;</td>
    <td width=234>Puesto el: <b>$row[fecha]</b></td>
  </tr>
  <tr> 
    <td colspan=4 class=content><b>Descripci�n:</B><br>
      $row[descripcion]</td>
  </tr>
  <tr> 
    <td width=40%>Puesto por:<b>$row[autor]</b></td>
    <td width=15%>Formato:<img src=descargas/formato/$row[formato]></td>
    <td width=40%>Comprimido en:</td>
	<td width=5%> $formato</td>
  </tr>
</table>


<br>";
} //fin imprimir resultados
echo "<br>";


//creando los enlaces de paginacion de resultados

echo "<center><p>";
if ($pg <>0)
{
$url = $pg - 1;/*Suoniendo que usas el electros nuke para eso de las id*/
echo "<font><a href=?id=descargas&da=ver&categoria=$categoria&id=".$id."&pg=".$url.">&laquo; Anterior</a>&nbsp;</font>";
}
else {
echo " ";
}
for ($i = 0; $i<($pages + 1); $i++) {
if ($i == $pg) {
echo "<font><b>&nbsp;$i&nbsp;</b></font>";
}
else {
echo "<font><a href=?id=descargas&da=ver&categoria=$categoria&id=".$id."&pg=".$i.">".$i."</a>&nbsp;</font>";
}
}
if ($pg < $pages) {
$url = $pg + 1;
echo "<font><a href=?id=descargas&da=ver&categoria=$categoria&id=".$id."&pg=".$url.">Siguiente &raquo;</a></font>";
}
else {
echo " ";
}
echo "</p></center>";
break;
}
?>
   </td>
  </tr></table>
  </td></tr></table>
              <? if($_POST["words"]){
				include("config.php");
				$gaz=mysql_query("select * from desc2 where titulo like '%$words%'");
				if(mysql_num_rows($gaz) == 0) {
				echo "No se encontraron resultados en la b�squeda." ;
}
else {
while($da = mysql_fetch_array($gaz)) {
echo "
<table width=85% border=0 cellspacing=0 cellpadding=0>
  <tr> 
    <td colspan=3><img src=descargas/browse.gif>$da[titulo]</td>
  </tr>
  <tr> 
    <td colspan=3>$da[descripcion]</td>
  </tr>
  <tr> 
    <td width=20%><a href=espejo.php?id=$da[id] target=_blank><img src=descargas/down.gif border=0>Descargar.</a></td>
    <td width=37%>Puesto el $da[fecha]</td>
    <td width=43%>Por: $da[autor]</td>
  </tr>
</table>
<br>" ;
}
}
}else{
}?>
