<style type="text/css">
/*
eForo >> Plantillas de estilo
Tema: electros.net
Autor: Electros <electros@electros.net>
Creado el: Viernes 13 de Agosto del 2004
*****************************************
Tema: eliascm36@hotmail.com
Autor: El�ascm36 <eliascm36@hotmail.com>
Modificado el: S�bado 26 de Noviembre del 2005
*/

/* General */
body {
	background: #f4fbff;
	background-color: #000000;
}
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}

/* T�tulos */
.eforo_titulo_1 {
color: #ffffff ;
font-size: 8pt ;
font-weight: bold ;
text-align: center ;
}
.eforo_titulo_2 {
color: #ffffff ;
font-size: 10pt ;
font-weight: bold ;
}
.eforo_titulo_2a {
font-style: italic ;
font-size: 13pt ;
color: #ffffff ;
}

/* Enlaces */
a.eforo {
color: #ffffff ;
text-decoration: none ;
font-weight: bold ;
}

/* Cuerpo del foro */

.eforo_tabla_principal {
}
.eforo_tabla_titulo {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
}
.eforo_tabla_subtitulo {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
}
.eforo_tabla_mensaje_1 {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
}
.eforo_tabla_mensaje_2 {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
}
.eforo_tabla_codigo {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
margin: 5px ;
}
.eforo_tabla_defecto {
border-left: #ffffff ; border-top: #ffffff ; border-right: #ffffff ; border-bottom: #ffffff ;
border-width: 2px ;
border-style: solid ;
background: #000000 ;
}

/* Formularios */
.eforo_formulario {
border-color: #000000 ; border-width: 1px ; border-style: solid ;
background-image: url('<?=$conf[url_foro]?>eforo_estilo/electros/fondo_form.gif') ;
background-repeat: repeat-x ;
background-color: #e4faff ;
font-family: verdana ;
font-size: 8pt ;
}
body,td,th {
	color: #FFFFFF;
}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #cacaca;
}
a:hover {
	color: #ababab;
}
a:active {
	color: #818181;
}
</style>
