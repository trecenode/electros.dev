<div align="center"><br><br> 
  <? 
function recursive_dirlist($base_dir)
{
global $getDirList_alldirs,$getDirList_allfiles;
   function getDirList($base)
   {
   global $getDirList_alldirs,$getDirList_allfiles;
   if(is_dir($base))
       {
           $dh = opendir($base);
       while (false !== ($dir = readdir($dh)))
           {
           if (is_dir($base ."/". $dir) && $dir !== '.') //note the change in this line
               {
                   $subs = $dir    ;
                   $subbase = $base ."/". $dir;//note the change in this line
                   $getDirList_alldirs[]=$subbase;
               }
           elseif(is_file($base ."/". $dir) && $dir !== '.' && $dir !== '..')//change in this line too
               {
               $getDirList_allfiles[]=$base ."/". $dir;//change in this line too
               }
           }
           closedir($dh);
       }
   }
 
getDirList($base_dir);
$retval['dirs']=$getDirList_alldirs;
$retval['files']=$getDirList_allfiles;
return $retval;
}
 
// Ejemplo de uso
// Si quieres ver los directorios, en $ver debes escribir dirs,
// y si quieres ver los archivos, se debe escribir files.
 
if (!$seccion)
{
 $seccion=".";
}
$ver = dirs;
$llistat=recursive_dirlist($seccion);
$num_files= count($llistat[$ver]);
 
for ($i=0; $i<$num_files; $i++)
{
$mostrar = eregi_replace("$seccion/", "", $llistat[$ver][$i]);
// Esta parte ed�tala como se te plazca (excepto la linea donde dice $llistat...)
 
 echo "<li>";
 echo "<a href=\"$PHP_SELF?seccion=";
 echo $llistat[$ver][$i];
 echo "\">";
 echo $mostrar;
 echo "</a>";
 echo "<br>\n";
}
?>
</div>
<br>
<br>
<table width='56%' border='1' cellpadding='5' cellspacing='1' align='center'>
<tr>
  <td width="68%" height="7" class="tabla_subtitulo"><b>Archivo</b></td>
  <td width="32%" class="tabla_subtitulo"><b>Tama�o</b></td>
</tr>

<?php
if ($seccion) {
$web = $seccion ;
}
else
{
$web = ".";
}
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = $web ;         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 10;             // Numero de archivos a mostrar por p�ginas.

$Show['10 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['10 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['10 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['10 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['10 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
  $Counter++;

  $elemento1 = strtolower($elemento);
  if (strpos($elemento1, ".zip") > 1 || strpos($elemento1, ".rar") > 1 || strpos($elemento1, ".ace") > 1) {
   // extensiones 
   $elemento2 = str_replace(".zip","$secciones",$elemento); 
   $elemento3 = str_replace(".rar","$secciones",$elemento);
   $elemento4 = str_replace(".ace","$secciones",$elemento);
?>
<tr>
    <td height='7' class="tabla_mensaje"><a href="<?php echo $elemento ?>" > 
      <?
// tomamos la imagen de la descripcion de los archivos
// las imagenes se guardan en un archivo tipo archivo.gif o archivo.jpg

if(file_exists("$web/$elemento2.zip")) {
echo "<img src='zip.gif' border='0' width='16' height='16'> ";
} 
else if (file_exists("$web/$elemento3.rar")) { 
echo "<img src='rar.gif' border='0' width='16' height='16'> ";
} 
else if (file_exists("$web/$elemento4.ace")) { 
echo "<img src='ace.gif' border='0' width='16' height='16'> ";
} 
else 
{ 
echo "";
} 
?>
      <? echo $elemento ?></a></td>
    <td height='7' class='tabla_mensaje'>
      <?  
// asignamos el tama�o de los archivo
if ($web) {
$elemento = "$seccion/$elemento";
}
if(filesize($elemento) > 1000000) {
$tamano = filesize($elemento)/1024/1024;
$tamano = ceil($tamano) ;
echo "$tamano Mb";
}
else { 
if(filesize($elemento) > 1000) {
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
echo "$tamano Kb";
} 
else {
$tamano = filesize($elemento);
$tamano = ceil($tamano);
echo "$tamano bytes";
} 
}
?>
    </td>
</tr>
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
  $Show['10 Siguientes'] = 1;
}

//Cerramos el directorio
closedir($dir);
?>
</table>
<div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['10 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."\">10 Anteriores | </a>");
if ($Show['10 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."\">10 Siguientes</a></p>");
?>
</div>

<div align="center"><br>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">phpzip by <a href="http://www.elcidop.com">elcidop</a></font></div>
