<?php
$tiempo_logout = 600; // segundos tras los cuales un usuario es marcado como inactivo
$arr = file("usuarios.dat");
$contenido = $REMOTE_ADDR.":".time()."\n";
for ( $i = 0 ; $i < sizeof($arr) ; $i++ )
{
$tmp = explode(":",$arr[$i]);
if (( $tmp[0] != $REMOTE_ADDR ) && (( time() - $tmp[1] ) < $tiempo_logout ))
{
$contenido .= $REMOTE_ADDR.":".time()."\n";
}
}
$fp = fopen("usuarios.dat","w");
fputs($fp,$contenido);
fclose($fp);
$array = file("usuarios.dat");
$online = count($array);
?>