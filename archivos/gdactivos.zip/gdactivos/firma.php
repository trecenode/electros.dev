<?
include('activosgd.php');
$linea[3] = "USUARIOS VIENDO ESTA FIRMA: $online"; 
$img = imagecreatefromgif("firma.gif");
$crema = ImageColorAllocate($img, 238, 238, 238);
imagettftext($img,8,0,8,56,$crema,"BitDarling10(sRB).TTF","$linea[3]"); 
Header ("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>