<br>
<br>
<html>
<head>
   <title>Calculadora by Wign</title>
</head>
<body>
<?php 
	//Se definen las variables.

	$n1 =$_GET['n1'];
	$n2 =$_GET['n2']; 
	$msn= "<p align=center><font face=tahoma size=2><b><font color=#FF0000>Su resultado es:</font>";
	$back= "calc.php";
//Comprobamos que los campos del formulario se encuentren completos.

if(empty($n1)){
echo "<p align=center><font face=tahoma size=2><b><font color=#FF0000>Error:</font> 
Debes seleccionar 1er numero.</b></font></p>";
}
if(empty($n2)){
echo "<p align=center><font face=tahoma size=2><b><font color=#FF0000>Error:</font> 
Debes seleccionar 2do numero.</b></font></p>";
}
if(empty($_GET['accion'])){
echo "<p align=center><font face=tahoma size=2><b><font color=#FF0000>Error:</font> Debes
seleccionar una accion (sumar, restar, dividir o multiplicar).</b></font></p>";
}
if($_GET['accion'] >= 6){
echo "<p align=center><font face=tahoma size=2><b><font color=#FF0000>Error:</font> Debes
seleccionar una accion (sumar, restar, dividir o multiplicar) valida.</b></font></p>";
}
else
{

//Prosesamos la informacion.

		if($_GET['accion'] == 1)
		{
		echo "$msn ", $n1 + $n2;
		}
		if($_GET['accion'] == 2)
		{
		echo "$msn ", $n1 - $n2;
		}
		if($_GET['accion'] == 3)
		{
		echo "$msn ", $n1 * $n2;
		}
		if($_GET['accion'] == 4)
		{
		echo "$msn ", $n1 / $n2;
		}
		if($_GET['accion'] == 5)
		{
		echo "$msn ", ($n1 + $n2) / 2;
		}
}
	echo "<br><a href=\"$back\">Atras</a>"; 
?>
</body>
</html> 