<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Calculadora simple (PHP) by Wign</title>
</head>

<body bgcolor="#FFFFFF">

<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" width="175" height="56" bgcolor="#0053CE">
    <tr>
      <td width="158" height="22" bgcolor="#005BE6" align="center"><font color="#E6E6E6">Calculadora</font></td>
      <td width="9" height="22" bgcolor="#1171FF" align="center">&nbsp;</td>
      <td width="10" height="22" bgcolor="#3399FF" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td width="180" height="57" bgcolor="#3399FF" align="center" colspan="3">
<FORM ACTION="calc2.php" METHOD="GET">
<font color="#E6E6E6">
Introduzca 1er numero:<INPUT TYPE="text" NAME="n1">
</font>
    <tr>
      <td width="158" height="22" bgcolor="#005BE6" align="center"><font color="#E6E6E6">Operacion:</font></td>
      <td width="9" height="22" bgcolor="#1171FF" align="center">&nbsp;</td>
      <td width="10" height="22" bgcolor="#3399FF" align="center">&nbsp;</td>
    </tr>
      <td height="49" width="158">
        <p align="center">
<font color="#E6E6E6">
<input type="radio" value="1" checked name="accion">sumar<br>
<input type="radio" value="2" name="accion">restar<br>
<input type="radio" value="3" name="accion">multiplicar<br>
<input type="radio" value="4" name="accion">dividir<br>
<input type="radio" value="5" name="accion">promedio</font>
    <tr>
      <td width="158" height="22" bgcolor="#005BE6" align="center">&nbsp;</td>
      <td width="9" height="22" bgcolor="#1171FF" align="center">&nbsp;</td>
      <td width="10" height="22" bgcolor="#3399FF" align="center">&nbsp;</td>
    </tr>
      <td height="9" bgcolor="#3399FF" width="158">
        <p align="center"><font color="#E6E6E6">Introduzca 2do numero:</font><INPUT TYPE="text" NAME="n2"><font color="#E6E6E6"><BR>
        <INPUT TYPE="submit" VALUE="Calcular">
</font>
</FORM>
      <tr>
        <td height="5" width="158" bgcolor="#0000FF">&nbsp;
      </tr>
  </table>
</div>

</body>

</html>
