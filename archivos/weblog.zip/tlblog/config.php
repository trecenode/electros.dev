<?

$numero = "5"; // n�mero de art�culos a mostrar en el home
$mas_articulos = "5"; // n�mero de art�culos a mostrar en el men� "M�s art�culos" de la dcha
$url = "http://www.phplibre.com/weblog"; // URL del weblog
$titulo = "PHP LIBRE"; // t�tulo del weblog
$subtitulo = "Recursos php para webmasters"; // subt�tulo del weblog

////////////////////////////////
// NO TOCAR
///////////////////////////////

include("lang/lang-spanish.php");

$mensaje[0] = _GUARDADO;
$mensaje[1] = _USERINCORRECTO;
$mensaje[2] = _PASSINCORRECTO;
$mensaje[3] = _DEBESAGREGARCAT;
$mensaje[4] = _CAMPOVACIO;
$mensaje[5] = _NOEXISTEARTICULO;
$mensaje[6] = _MENSAJEENVIADO;
$mensaje[7] = _CAMPOVACIO;
$mensaje[8] = _NOCOINCIDENPASS;
$mensaje[9] = _CONTRASENACTUAL;
$mensaje[10] = _CATEGORIAEXISTE;

///////////////////////////////

// Configuraci�n de la bd

$host = "localhost";
$user = ""; // Usuario de la bd 
$pass = ""; // Pass del usuario de la bd
$dbname = ""; // Nombre de la bd

$conecta = @mysql_connect($host, $user, $pass) or die(_ERRORMYSQL);
@mysql_select_db($dbname, $conecta);
?>
