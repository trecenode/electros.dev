<?
include("config.php");
include("funciones.php");

if (isset($_GET['id'])) {
$query = "SELECT link FROM `descargas` WHERE id = '".$_GET['id']."'";
$resp = @mysql_query($query);
$row = @mysql_num_rows($resp);
if ($row) {
   $descarga = @mysql_fetch_array($resp);
   if (file_exists($descarga['link'])) {
	  $query = "UPDATE `descargas` SET contador = contador + 1 WHERE id = '".$_GET['id']."'";
	  $resp = @mysql_query($query);
	  header("location: ".$descarga['link']); 
	  exit;
   } else {
   	  echo _NOEXISTEDESCARGA."<br/>";
	  echo _LINKPROBLEMA;
   }
}	
	
}	

?>
