<?
session_start();
session_cache_limiter('nocache, private');

if (isset($_POST['entrar'])) {
    include("config.php");
    $sql = "SELECT * FROM autores WHERE nombre = '".$_POST['usuario']."'";
    $resp = @mysql_query($sql);
    $rows = @mysql_num_rows($resp);
    if (!$rows) {
        header("Location: index.php?op=admin&msg=1");
        exit;
    } else {
        $datos = mysql_fetch_array($resp);
        if ($datos['pass'] == md5($_POST['pass'])) {
            $_SESSION['usuario_id'] = $datos['idautor'];
            $_SESSION['usuario'] = $datos['nombre'];
            $_SESSION['usuario_rol'] = $datos['rol'];
            header("location: index.php?op=admin");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=2");
            exit;
        }
    }
}
header("location: index.php?op=admin");
?>
