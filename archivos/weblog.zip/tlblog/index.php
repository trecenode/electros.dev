<?
ini_set("arg_separator.output", "&amp;"); 
ini_set("url_rewriter.tags", "a=href,area=href,frame=src,input=src");
session_start();
session_cache_limiter('nocache, private');

include("config.php");
include("funciones.php");
include("visit_stat.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	  <title><?=$titulo; ?></title>
	  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	  <script type="text/javascript">
	  <? include("funciones.js"); ?>
	  </script>
	  <link rel="stylesheet" type="text/css" href="estilo.css"/>
	  </head>
<body>
<div id="holder">
		<div id="header">
			<span class="titulo"><?=$titulo; ?></span><br/>
			<span class="subtitulo"><?=$subtitulo; ?></span>
		</div>
<div id="enlaces">
<ul>
	<li><a href="index.php" class="enlace" title="<?=_PRINCIPAL; ?>"><?=_PRINCIPAL; ?></a></li> 
	<li><a href="index.php?op=archivo" class="enlace" title="<?=_ARCHIVOARTICULOS; ?>"><?=_ARCHIVO; ?></a></li>
	<li><a href="index.php?op=enlaces" class="enlace" title="<?=_ARCHIVOARTICULOS; ?>"><?=_ENLACES; ?></a></li>
	<li><a href="index.php?op=descargas" class="enlace" title="<?=_DESCARGAS; ?>"><?=_DESCARGAS; ?></a></li>
	<li><a href="index.php?op=contactar" class="enlace" title="<?=_CONTACTOWEBMASTER; ?>"><?=_CONTACTO; ?></a></li>
	<li><a href="index.php?op=admin" class="enlace" title="<?=_PANELADMIN; ?>"><?=_ADMIN; ?></a></li>
</ul>
</div>
					<div id="content">
					<div id="contentleft">
<?
if (isset($_GET['op'])) {
switch ($_GET['op']) {
   case "archivo":
   		 echo "<h1>"._ARCHIVO."</h1>";
         include ("archivo.php");
         break;
   case "contactar":
   		echo "<h1>"._CONTACTO."</h1>";
         include ("contacto.php");
         break;
   case "descargas":
   		 echo "<h1>"._DESCARGAS."</h1>";
         include ("descargas.php");
         break;		
   case "enlaces":
   		 echo "<h1>"._ENLACES."</h1>";
         include ("enlaces.php");
         break;			  
	   case "leer":
         include ("leer.php");
         break;	 
	   case "buscar":
	     echo "<h1>"._BUSQUEDA."</h1>";
         include ("buscar.php");
         break;
	   case "mirror":
	     echo "<h1>"._DESCARGAR."</h1>";
         include ("mirror.php");
         break;	 	 
	   case "admin":
         include ("admin.php");
         break;			 
     default:
	 	 echo "<h1>"._ARTICULOS."</h1>";
         include ("articulos.php");
         break;
 }
} else {
	echo "<h1>"._ARTICULOS."</h1>";
	include ("articulos.php");
}
?>
</div>
<div id="contentright">
<h3><?=_BUSCAR; ?></h3>
<div class="menu">
<form method="post" action="index.php?op=buscar">
<fieldset>
<label for="busqueda"><input type="text" id="busqueda" name="busqueda" /></label>
<label for="buscar"><input type="submit" id="buscar" name="buscar" value="<?=_BUSCAR; ?>" /></label>
</fieldset>
</form>
</div>
<?
if (!isset($_GET['op'])) {
?>
<h3><?=_MASARTICULOS; ?></h3>
<div class="menu">
<ul class="items">
<?

while ($articulos = @mysql_fetch_array($resp)) {
	echo "<li> <a href=\"index.php?op=leer&amp;entrada=" . $articulos['id'] . "\" title=\""._LEERARTICULO."\">" . $articulos['titulo'] . "</a> ". $articulos['fecha'] . "</li>";
$mas = 1;
}

if (!isset($mas)) 
	echo "<li>"._NOHAYMASARTICULOS."</li>";
?>
</ul></div>
<h3><?=_ULTIMOSCOMENTARIOS; ?></h3>
<div class="menu">
<ul class="items">
<?
$sql = "SELECT * FROM comentarios order by id desc limit 10";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo "<li>"._NOHAYCOMENTARIOS."</li>";
else {
while ($datos = @mysql_fetch_array($resp)) {
         $lenght = strlen ($datos['texto']);
		 if ($lenght > 30) {
	         $texto = substr_replace($datos['texto'], ' ...', 30, $lenght);
         } else {
             $texto = $datos['texto'];
         }
	echo "<li> <a href=\"index.php?op=leer&amp;entrada=" . $datos['entrada'] . "\" title=\""._LEERCOMENTARIO." (".$datos['fecha'].", ".$datos['hora'].")\">" . $texto . "</a></li>";
}
}
?>
</ul></div>
<h3><?=_TOP; ?></h3>
<div class="menu">
<ul class="items">
<?
$sql = "SELECT * FROM entradas order by lecturas desc limit 10";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo "<li>"._NOHAYARTICULOS."</li>";
else {
while ($masleidos = @mysql_fetch_array($resp)) {
         $lenght = strlen ($masleidos['titulo']);
		 if ($lenght > 30) {
	         $titulo = substr_replace($masleidos['titulo'], ' ...', 30, $lenght);
         } else {
             $titulo = $masleidos['titulo'];
         }
	echo "<li> <a href=\"index.php?op=leer&amp;entrada=" . $masleidos['id'] . "\" title=\""._LECTURAS.": " . $masleidos['lecturas'] . "\">" . $titulo . "</a> (" . $masleidos['lecturas'] . ")</li>";
}
}
?>
</ul></div>
<? } ?>
<h3><?=_CATEGORIAS; ?></h3>
<div class="menu">
<ul class="items">
<?

$query = "SELECT * FROM categorias"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
echo "<li>"._NOHAYCATEGORIAS."</li>";
else {
while ($datos = mysql_fetch_array($resp)) {
    $query = "SELECT * FROM entradas WHERE categoria ='".$datos['id']."'";
    $resp1 = @mysql_query($query);
    $num_articulos = @mysql_num_rows($resp1);
echo "<li> <a href=\"index.php?op=archivo&amp;categoria=" . $datos['id'] . "\" title=\""._VERARTICULOSCATEGORIA."\">" . $datos['nombre'] . "</a> (".$num_articulos.")";
	if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") {
        echo " <a href=\"index.php?op=admin&editarcategoria=".$datos['id']."\">["._EDITAR."]</a>";
		echo " <a href=\"procesar.php?borrar=".$datos['id']."&act=categoria\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
	}
		echo "</li>";
	}
	
}
?>
</ul></div>
<h3><?=_ULTIMOSENLACES; ?></h3> 
<div class="menu">
<ul class="items">
<?

$query = "SELECT * FROM `enlaces` order by id desc LIMIT 10"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows) {
echo "<li>"._NOENLACES."</li>";
} else {
while ($datos = mysql_fetch_array($resp)) {
$query2 = "SELECT nombre FROM `categorias` WHERE id = '".$datos['categoria']."'"; 
$resp2 = @mysql_query($query2);
$cat = @mysql_fetch_array($resp2);
echo "<li> <a onclick=\"enlace(this.href); return false;\" href=\"" . $datos['url'] . "\" title=\""._ENLACEEXTERNO."\">" . $datos['nombre'] . "</a> (" . $cat['nombre']. ")";
    if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") {
        echo " <a href=\"index.php?op=admin&editarenlace=".$datos['id']."\">["._EDITAR."]</a><a href=\"procesar.php?borrar=".$datos['id']."&act=link\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
	}
		echo "</li>";
	}
}

?>
</ul>
</div>
<? if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") { ?>
<h3><?=_ESTADISTICAS; ?></h3>
<div class="umenu">
<img src="stat/stat.png">
</div>
<? } ?>
</div>
<hr class="nofloat" />
</div>
<div class="creditos">
      <h4><a href="http://www.phplibre.com" title="Consigue un weblog gratis">TL Weblog v0.2b</a> | RSS 2.0: <a href="index.xml">XML</a> | <a href="http://validator.w3.org/check?uri=referer">XHTML v�lido</a></h4> <br/>
</div>
</div>
</body>
</html>
