# phpMyAdmin SQL Dump
# version 2.5.3
# http://www.phpmyadmin.net
#
# Servidor: localhost
# Tiempo de generaci�n: 24-10-2004 a las 01:33:51
# Versi�n del servidor: 4.0.15
# Versi�n de PHP: 4.3.3
# 
# Base de datos : `blog`
# 

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `autores`
#

CREATE TABLE `autores` (
  `idautor` int(10) NOT NULL auto_increment,
  `nombre` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default '',
  `rol` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`idautor`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1 ;

#
# Volcar la base de datos para la tabla `autores`
#

INSERT INTO `autores` VALUES (1, 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'superadmin');

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `categorias`
#

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL auto_increment,
  `nombre` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `comentarios`
#

CREATE TABLE `comentarios` (
  `entrada` varchar(10) NOT NULL default '0',
  `id` int(10) NOT NULL auto_increment,
  `nick` varchar(10) NOT NULL default '',
  `texto` text NOT NULL,
  `email` varchar(25) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  `hora` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `contacto`
#

CREATE TABLE `contacto` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL default '',
  `asunto` varchar(255) NOT NULL default '',
  `mensaje` text NOT NULL,
  `fecha` varchar(255) NOT NULL default '',
  `hora` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `day_visit`
#

CREATE TABLE `day_visit` (
  `day` varchar(255) NOT NULL default '',
  `pag` varchar(255) NOT NULL default '',
  `num` int(11) NOT NULL default '0',
  `tot_days` mediumint(255) NOT NULL auto_increment,
  `mes` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`tot_days`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `descargas`
#

CREATE TABLE `descargas` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` text NOT NULL,
  `descripcion` longtext NOT NULL,
  `autor` int(11) NOT NULL default '0',
  `link` text NOT NULL,
  `tamano` varchar(30) NOT NULL default '',
  `categoria` int(11) NOT NULL default '0',
  `contador` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `enlaces`
#

CREATE TABLE `enlaces` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `categoria` int(11) NOT NULL default '0',
  `descripcion` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1 ;

# --------------------------------------------------------

#
# Estructura de tabla para la tabla `entradas`
#

CREATE TABLE `entradas` (
  `id` int(10) NOT NULL auto_increment,
  `fecha` varchar(100) NOT NULL default '',
  `hora` varchar(100) NOT NULL default '',
  `titulo` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `texto` text NOT NULL,
  `autorid` int(11) NOT NULL default '0',
  `categoria` mediumint(9) NOT NULL default '0',
  `lecturas` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `intro` (`intro`),
  FULLTEXT KEY `texto` (`texto`),
  FULLTEXT KEY `texto_2` (`texto`),
  FULLTEXT KEY `fecha` (`fecha`),
  FULLTEXT KEY `fecha_2` (`fecha`)
) TYPE=MyISAM PACK_KEYS=0 AUTO_INCREMENT=1;


# --------------------------------------------------------

#
# Estructura de tabla para la tabla `ip_logs`
#

CREATE TABLE `ip_logs` (
  `ip` varchar(255) NOT NULL default '',
  `dia` varchar(255) NOT NULL default '',
  `mes` varchar(255) NOT NULL default '',
  `ip_num` mediumint(255) NOT NULL auto_increment,
  PRIMARY KEY  (`ip_num`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

