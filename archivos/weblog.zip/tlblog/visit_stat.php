<?

$pag = $PHP_SELF;
if ($HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR'] != "")

{

$IP_REAL = $HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR']; // Muestra la IP real del usuario, es decir, la P�blica
$IP_PROXY = $HTTP_SERVER_VARS['REMOTE_ADDR']; // Muestra la IP de un posible Proxy

$ip = $IP_REAL ;
}

else

{

 $IP_REAL = $HTTP_SERVER_VARS["REMOTE_ADDR"]; // En caso de que no exista un Proxy solo mostrara la IP Publica del visitante

$ip = $IP_REAL  ;

}


$day = strftime("%d");

$mes = strftime("%b");

$datecheck = "SELECT * FROM day_visit WHERE day='$day' && mes='$mes' ";  //Accedemos a la base de datos day_visit
$dateresult = mysql_query($datecheck) or die("Error en la consulta datecheck");
$reg = mysql_fetch_array ($dateresult);
$regnum = $reg['ip'];
$thisnum = $reg['num'];
$que1 = "SELECT * FROM ip_logs  "; //Accedemos a la base de datos de ips
$res1 = mysql_query($que1) or die("NOOOOO");
while($regok = mysql_fetch_array ($res1))
{
$xip = $regok['ip'];
$xday = $regok['dia'];
$xmes = $regok['mes'];
$xnum = $regok['ip_num'];
if (($xip==$ip) && ($xday==$day) && ($xmes==$mes)) { $cont = 'si';}
}
if ($cont=='si') //Control de Ip
{
$plusnum = $thisnum;
} else {
mysql_query("INSERT INTO ip_logs (ip, dia, mes, ip_num) values ('$ip', '$day', '$mes', '')");
$plusnum = $thisnum+1;
}

//Fin control IP
$checkitday = $reg['day'];
$checkitmes = $reg['mes'];
if (($day==$checkitday) && ($mes==$checkitmes)) //A�adir / modificar contador de visitas
 {
mysql_query("UPDATE day_visit SET num='$plusnum' WHERE day='$day' && mes='$mes' ");
 } else {
mysql_query("INSERT INTO day_visit (day, pag, num, tot_days, mes) values ('$day', '$pag', '1', '', '$mes')");
 }
$query = "SELECT * FROM day_visit ORDER BY day DESC LIMIT 0,7"; //Devolver visitas
$restone = mysql_query($query) or die("ups");

$q_tot = "SELECT * FROM ip_logs";
$r_tot = mysql_query($q_tot) or die("no tot");
$num_tot = mysql_num_rows($r_tot);
$tot_width = 90;
$tot_height = 170;
//Funcion max visitas
$mysql_rows = "SELECT * FROM day_visit";
$query_rows = mysql_query($mysql_rows);
$rows = mysql_num_rows($query_rows);
$mysql = "SELECT num FROM day_visit order by num DESC limit 0, $rows";
$query = mysql_query($mysql);
$reg = mysql_fetch_array($query);
$anum = $reg['num'];
$bnum = "0$anum";
//Fin
$im = imagecreate($tot_width,$tot_height);
//Colores
//no hagais mucho caso el nombre de los colores... los iba poniendo mientras escribia el c�digo y algunos colores no coinciden con su nombre

$gray = imagecolorallocate($im,142,142,142); //gris
$otro1 = imagecolorallocate($im,253,180,21);
$otro2 = imagecolorallocate($im,0,116,168);
$mycolor = imagecolorallocate($im,52,45,69);
$mycolor2 = imagecolorallocate($im,255,255,255); //blanco
$mycolor3 = imagecolorallocate($im,242,101,34);
$orange = imagecolorallocate($im, 242, 101, 34);
$orange2 = imagecolorallocate($im, 247, 148, 29);
$blue = imagecolorallocate($im, 250, 168, 101); //anaranjado
$blue2 = imagecolorallocate($im, 247, 216, 191); //anaranjado con blanco
imagefill($im,0,0,$mycolor2);
imagedashedline($im,10,10,10,$tot_height-8,$gray);
imagestring($im,1,8,$tot_height-7,'0%',$mycolor3);
imagedashedline($im,35,10,35,$tot_height-8,$gray);
imagestring($im,1,32,$tot_height-7,'50%',$mycolor3);
imagedashedline($im,60,10,60,$tot_height-8,$gray);
imagestring($im,1,54,$tot_height-7,'100%',$mycolor3);
imagestring($im,1,0,0,'D�a',$mycolor3);
imagestring($im,1,50,0,'Visitas',$mycolor3);
$y1 = $y1+10;
$y2 = $y2+10;
while($regone = mysql_fetch_array ($restone))
{
$var = $regone['num']/$bnum*100;
$width = $var/2;
$y1 = $y1+8;
$y2 = $y1+6;
if($y1<$tot_height-12) {
imagestring($im,1,0,$y1,$regone['day'],$mycolor3);
imagerectangle($im,10,$y1,$width+10,$y2,$blue);
imagestring($im,1,65,$y1,$regone['num'],$mycolor3);
imagefilledrectangle($im,11,$y1+1,$width+9,$y2-1,$blue2);
                       }
}
//Guardamos la imagen donde queramos
imagepng($im,"stat/stat.png");
$clean = "SELECT * FROM ip_logs";
$clean2 = mysql_query($clean) or die("no tot2");
while($clean3 = mysql_fetch_array ($clean2))
{
$clean4 = $clean3['mes'];
//Cuando acaba el mes borramos la BDD del mes anterior... para no llenar la BDD :)
if($mes!=$clean4)
{
$delsql = "DELETE FROM ip_logs";
mysql_query($delsql);
$delsql2 = "DELETE FROM day_visit";
mysql_query($delsql2);

}
}

?>