<div style="text-align: left">
<?
if (isset($_GET['msg']))
	echo "<p style=\"color: #cc0000\"><strong>".$mensaje[$_GET['msg']]."</strong></p>";
?>
<form method="post" action="contactar.php">
<fieldset>
<label for="email"><input type="text" id="email" size="41" name="email" value="<?=_EMAIL; ?>"/> </label>
<br /><br />
<label for="asunto"><input type="text" id="asunto" size="41" name="asunto" value="<?=_ASUNTO; ?>"/></label>
<br /><br />
<label for="mensaje">
<textarea id="mensaje" name="mensaje" cols="40" rows="10"><?=_COMENTARIO; ?></textarea></label>
<br/> <br/> <input name="enviar" type="submit" value="<?=_ENVIAR ?>"/>
</fieldset>
</form>
</div>
