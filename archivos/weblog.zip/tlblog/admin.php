<?
if (isset($_GET['msg']))
	echo "<div style=\"text-align: center\"><strong>".$mensaje[$_GET['msg']]."</strong></div><br/>";
crearRSS();
	
if (isset($_SESSION['usuario'])) {
?>
<strong><?=_ADMINISTRACION; ?></strong>: <?=$_SESSION['usuario']; ?>,
<? if ($_SESSION['usuario_rol'] == "superadmin") { ?>
<a href="index.php?op=admin&ver=1">[<?=_ENVIOS; ?>]</a> <a href="index.php?op=admin&editardatos=1">[<?=_EDITARPERFIL; ?>]</a>
<? } ?>
<a href="salir.php">[<?=_SALIR; ?>]</a><br/><br/>
<?
if (isset($_GET['ver']) && $_SESSION['usuario_rol'] == "superadmin") {
$query = "SELECT * FROM contacto ORDER BY id desc";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOENVIOS."<br/>";
else {
	while ($datos = @mysql_fetch_array($resp)) {
		echo "<div class=\"menu\"><strong>".$datos['email']."</strong>, ".$datos['fecha']." ".$datos['hora']." <a href=\"procesar.php?borrar=".$datos['id']."&act=envio\" onclick=\"return deleteremember()\">["._BORRAR."]</a><br/>";
		echo "<strong>"._ASUNTO.":</strong> ".$datos['asunto']."<br/>";
		echo "<strong>"._MENSAJE."</strong><br/>".$datos['mensaje']."</div>";
	}
}
} else if (!isset($_GET['editarenlace']) && !isset($_GET['editarcomentario']) && !isset($_GET['editardatos']) && !isset($_GET['edit']) && !isset($_GET['editardescarga']) && !isset($_GET['editarcategoria'])) {
?>
<div style="text-align: center">Agregar: 
<a href="#" onclick="mostrar('agregarcategoria');"><?=_CATEGORIA; ?></a> |
<a href="#" onclick="mostrar('agregararticulo');"><?=_ARTICULO; ?></a> | 
<a href="#" onclick="mostrar('agregarenlace');"><?=_ENLACE; ?></a> |
<a href="#" onclick="mostrar('agregardescarga');"><?=_DESCARGA; ?></a> </div>
<div class="menu" id="agregararticulo" style="display: none;">
	<u><?=_ARTICULOS; ?></u><br/><br/>
<? 
$query = "SELECT * FROM categorias"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOHAYCATEGORIAS."<br/>";
else {
?>	
	<form name="form" method="post" action="procesar.php"> 
    <input type="hidden" name="id" value=""/>
	<input type="hidden" name="fecha" value="<? echo date("j/n/Y") ?>"/> 
    <input type="hidden" name="hora" value="<? echo date("g:i a") ?>"/>
	<input type="text" name="titulo" value="<?=_TITULO; ?>" size="70"/><br/><br/>
	<?=_CATEGORIA; ?>: <select name="categoria"> 
<? 
	while ($datos = @mysql_fetch_array($resp)) {
		$content .= "<option value=\"".$datos['id']."\""; 
		$content .= ">".$datos['nombre']."</option>\n"; 
	} 

echo $content; 
?> 
</select><br/>
<?=_INTRO; ?><br/>
<a title='<?=_NEGRITA; ?>' href='javascript:;'  onClick="negrita('intro')"><strong>[b]</strong></a>
<a title='<?=_CURSIVA; ?>' href='javascript:;' onClick="cursiva('intro')"><em>[i]</em></a>
<a title='<?=_SUBRAYADO; ?>' href='javascript:;' onClick="subrayado('intro')"><u>[u]</u></a>
<a title='<?=_TACHADO; ?>' href='javascript:;' onClick="tachado('intro')"><del>[del]</del></a>
<a title='PHP' href='javascript:;' onClick="codigo('intro')">[PHP]</a>
<a title='<?=_CITAR; ?>' href='javascript:;' onClick="citar('intro')">[<?=_CITAR; ?>]</a> 
<a title='URL' href='javascript:;' onClick='url("intro")'>[http://]</a> 
<a title='<?=_IMAGEN; ?>' href='javascript:;' onClick='imagen("intro")'>[<?=_IMAGEN; ?>]</a>
<textarea name="intro" cols="70" rows="5"></textarea><br/> 

<?=_TEXTO; ?><br/>
<a title='Negrita' href='javascript:;'  onClick="negrita('texto')"><strong>[b]</strong></a>
<a title='Cursiva' href='javascript:;' onClick="cursiva('texto')"><em>[i]</em></a>
<a title='Subrayado' href='javascript:;' onClick="subrayado('texto')"><u>[u]</u></a>
<a title='Tachado' href='javascript:;' onClick="tachado('texto')"><del>[del]</del></a>
<a title='PHP' href='javascript:;' onClick="codigo('texto')">[PHP]</a>
<a title='<?=_CITAR; ?>' href='javascript:;' onClick="citar('texto')">[<?=_CITAR; ?>]</a> 
<a title='URL' href='javascript:;' onClick='url("texto")'>[http://]</a>
<a title='<?=_IMAGEN; ?>' href='javascript:;' onClick='imagen("texto")'>[<?=_IMAGEN; ?>]</a>
    <textarea name="texto" cols="70" rows="5"></textarea><br/> 
    <input type="submit" name="enviararticulo" value="<?=_ENVIAR; ?>"/> 
    </form>
	<? } ?>
	</div>
	<div class="menu" id="agregarcategoria" style="display: none;">
	<u><?=_AGREGARCAT; ?></u><br/><br/>
	<form method="post" action="procesar.php">
    <input type="text" name="nombre" value="<?=_NOMBRE; ?>" size="30"/><br/>
    <input type="submit" name="enviarcategoria" value="<?=_ENVIAR; ?>"/>
    </form>
	</div>
<div class="menu" id="agregarenlace" style="display: none;">
    <u><?=_AGREGARENLACE; ?></u><br/><br/>
<? 
$query = "SELECT * FROM categorias"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOHAYCATEGORIAS."<br/>";
else {
?>
    <form method="post" action="procesar.php"> 
    <input type="text" name="nombreweb" value="<?=_WEB; ?>" size="30"/><br/> 
    <input type="text" name="url" value="URL" size="30"/><br/> 
    	<?=_CATEGORIA; ?>: <select name="categoria"> 
<?
$content = "";
	while ($datos = @mysql_fetch_array($resp)) {
		$content .= "<option value=\"".$datos['id']."\""; 
		$content .= ">".$datos['nombre']."</option>\n"; 
	}

echo $content; 
?> 
</select><br/> 
<?=_DESCRIPCION; ?><br/>
<textarea name="descripcion" rows="2" cols="30"></textarea><br/>
    <input type="submit" name="enviarenlace" value="<?=_ENVIAR; ?>"/> 
    </form>
	<? } ?>
</div>	
<div class="menu" id="agregardescarga" style="display:none;">
	<u><?=_AGREGARDESCARGA; ?></u><br/><br/>
	<? 
$query = "SELECT * FROM categorias"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOHAYCATEGORIAS."<br/>";
else {
?>
    <form method="post" action="procesar.php"> 
    <input type="text" name="nombre" value="<?=_NOMBRE; ?>" size="30"/><br/> 
    <input type="text" name="link" value="<?=_LINK; ?>" size="30"/><br/> 
    <input type="text" name="tamano" value="<?=_TAMANO; ?>" size="30"/><br/> 
    <?=_CATEGORIA; ?>: <select name="categoria"> 
<?
$content = "";
	while ($datos = @mysql_fetch_array($resp)) {
		$content .= "<option value=\"".$datos['id']."\""; 
		$content .= ">".$datos['nombre']."</option>\n"; 
	}

echo $content; 
?> 
</select><br/>
	<?=_DESCRIPCION; ?><br/>
	<textarea name="descripcion" rows="2" cols="30"></textarea><br/>
	<input type="submit" name="enviardescarga" value="<?=_ENVIAR; ?>"/> 
    </form>
	<? } ?>
	</div>
<?
} else if (isset($_GET['editarcategoria'])) {
$sql = "SELECT * FROM categorias WHERE id = '".$_GET['editarcategoria']."'";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTECAT."<br/>";
else {
$rows = @mysql_fetch_array($resp);
?>
<u><?=_EDITARCAT; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php?editarcategoria=yes">
    <input type="hidden" name="id" value="<?=$_GET['editarcategoria'] ?>" />
	<?=_NOMBRE; ?>:<br/>
	<input type="text" name="categoria" value="<?=$rows['nombre'] ?>" size="35"/><br/><br/>
	<input type="submit" name="enviar" value="<?=_ENVIAR; ?>"/>
</form>
<?
}
} else if (isset($_GET['editarenlace'])) {
$sql = "SELECT * FROM enlaces WHERE id = '".$_GET['editarenlace']."'";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTEENLACE."<br/>";
else {
$rows = @mysql_fetch_array($resp);
?>
<u><?=_EDITARENLACE; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php?editarenlace=yes">
    <input type="hidden" name="id" value="<?=$_GET['editarenlace'] ?>" />
	<?=_NOMBRE; ?>:<br/>
	<input type="text" name="nombre" value="<?=$rows['nombre'] ?>" size="30"/><br/>
	URL:<br/>
	<input type="text" name="url" value="<?=$rows['url'] ?>" size="30" /><br/>
		<?=_CATEGORIA; ?>: <select name="categoria">
<?
$query2 = "SELECT * FROM categorias";
$resp2 = @mysql_query($query2);
$rows2 = @mysql_num_rows($resp2);
if (!$rows2) {
	echo _NOHAYCATEGORIAS."<br/>";
} else {
	while ($datos = @mysql_fetch_array($resp2)) {
		$content .= "<option value=\"".$datos['id']."\"";
		if ($rows['categoria'] == $datos['id'])
            $content .= "selected";
		$content .= ">".$datos['nombre']."</option>\n";
	}
}

echo $content;
?>
</select><br/>
<?=_DESCRIPCION; ?><br/>
<textarea name="descripcion" rows="2" cols="30"><?=$rows['descripcion']; ?></textarea><br/>
	<input type="submit" name="enviar" value="<?=_ENVIAR; ?>"/>
</form>
<?
}
} else if (isset($_GET['editardatos'])) {
$sql = "SELECT * FROM autores WHERE nombre = '".$_SESSION['usuario']."'";
$resp = mysql_query($sql);
$rows = mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTEUSER."<br/>";
else {
?>
<u><?=_EDITARPERFIL; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php">
	<?=_NOMBRE; ?>:<br/>
	<input type="text" name="nombre" value="<?=$_SESSION['usuario']; ?>" size="35"/> <br/>
    <?=_CONTRASENAACTUAL; ?>:<br/>
	<input type="password" name="passactual" value="" size="35"/> <br/>
	<?=_NUEVACONTRASENA; ?>:<br/>
	<input type="password" name="pass" value="" size="35" /><br/>
	<?=_REPITENUEVACONTRASENA; ?>:<br/>
	<input type="password" name="pass2" value="" size="35" /><br/>
	
	<input type="submit" name="editardatos" value="<?=_ENVIAR; ?>"/>
</form>
<?
}
?>
<?
} else if (isset($_GET['editarcomentario'])) {
$sql = "SELECT * FROM comentarios WHERE id = '".$_GET['editarcomentario']."'";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTECOMENTARIO."<br/>";
else {
$rows = @mysql_fetch_array($resp);
?>
<u><?=_EDITARCOMENTARIO; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php?editarcomentario=yes">
    <input type="hidden" name="id" value="<?=$_GET['editarcomentario'] ?>" />
	<?=_NOMBRE; ?>:<br/>
	<input type="text" name="nick" value="<?=$rows['nick'] ?>" size="35"/> IP: <?=$rows['ip'] ?><br/>
	URL:<br/>
	<input type="text" name="url" value="<?=$rows['url'] ?>" size="35" /><br/>
	Email:<br/>
	<input type="text" name="email" value="<?=$rows['email'] ?>" size="35" /><br/>
	<?=_COMENTARIO; ?>:<br/>
	<textarea name="texto" rows="5" cols="50"><?=$rows['texto'] ?></textarea><br/>
	<input type="submit" name="enviar" value="<?=_ENVIAR; ?>"/>
</form>
<?
}
} else if (isset($_GET['edit'])) {
$sql = "SELECT * FROM entradas WHERE id = '".$_GET['edit']."'";
$resp = @mysql_query($sql);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTEARTICULO."<br />";
else {
$rows = @mysql_fetch_array($resp);
if ($_SESSION['usuario_id'] == $rows['autorid'] || $_SESSION['usuario_rol'] == "superadmin") {

?>
	<u><?=_EDITARARTICULO; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php?edit=yes">
    <input type="hidden" name="id" value="<?=$_GET['edit'] ?>"/>
	<input type="hidden" name="fecha" value="<?=$rows['fecha'] ?>"/>
    <input type="hidden" name="hora" value="<?=$rows['hora'] ?>"/>
	<?=_TITULO; ?>: <input type="text" name="titulo" value="<?=$rows['titulo'] ?>" size="64"/><br/><br/>
	<?=_CATEGORIA; ?>: <select name="categoria">
<?
$query2 = "SELECT * FROM categorias";
$resp2 = @mysql_query($query2);
$rows2 = @mysql_num_rows($resp2);
if (!$rows2) {
	echo _NOHAYCATEGORIAS."<br/>";
} else {
	while ($datos = @mysql_fetch_array($resp2)) {
		$content .= "<option value=\"".$datos['id']."\"";
		if ($rows['categoria'] == $datos['id'])
            $content .= "selected";
		$content .= ">".$datos['nombre']."</option>\n";
	}
}

echo $content;
?>
</select><br/>
	<?=_INTRO; ?><br/>
	<a title='<?=_NEGRITA; ?>' href='javascript:;'  onClick="negrita('intro')"><strong>[b]</strong></a>
<a title='<?=_CURSIVA; ?>' href='javascript:;' onClick="cursiva('intro')"><em>[i]</em></a>
<a title='<?=_SUBRAYADO; ?>' href='javascript:;' onClick="subrayado('intro')"><u>[u]</u></a>
<a title='<?=_TACHADO; ?>' href='javascript:;' onClick="tachado('intro')"><del>[del]</del></a>
<a title='PHP' href='javascript:;' onClick="codigo('intro')">[PHP]</a>
<a title='<?=_CITAR; ?>' href='javascript:;' onClick="citar('intro')">[<?=_CITAR; ?>]</a> 
<a title='URL' href='javascript:;' onClick='url("intro")'>[http://]</a> 
<a title='<?=_IMAGEN; ?>' href='javascript:;' onClick='imagen("intro")'>[<?=_IMAGEN; ?>]</a>

	<textarea name="intro" cols="70" rows="5"><?=$rows['intro']?></textarea><br/>
	<?=_TEXTO; ?><br>
<a title='<?=_NEGRITA; ?>' href='javascript:;'  onClick="negrita('intro')"><strong>[b]</strong></a>
<a title='<?=_CURSIVA; ?>' href='javascript:;' onClick="cursiva('intro')"><em>[i]</em></a>
<a title='<?=_SUBRAYADO; ?>' href='javascript:;' onClick="subrayado('intro')"><u>[u]</u></a>
<a title='<?=_TACHADO; ?>' href='javascript:;' onClick="tachado('intro')"><del>[del]</del></a>
<a title='PHP' href='javascript:;' onClick="codigo('intro')">[PHP]</a>
<a title='<?=_CITAR; ?>' href='javascript:;' onClick="citar('intro')">[<?=_CITAR; ?>]</a> 
<a title='URL' href='javascript:;' onClick='url("intro")'>[http://]</a> 
<a title='<?=_IMAGEN; ?>' href='javascript:;' onClick='imagen("intro")'>[<?=_IMAGEN; ?>]</a>
    <textarea name="texto" cols="70" rows="5"><?=$rows['texto']?></textarea><br/>
    <input type="submit" name="enviar" value="<?=_ENVIAR; ?>"/>
    </form>
<?
} else
	echo _NOEDITARARTICULO;
}
?>
<?
} else if (isset($_GET['editardescarga'])) {
$query = "SELECT * FROM descargas WHERE id = '".$_GET['editardescarga']."'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
	echo _NOEXISTEDESCARGA."<br/>";
else {
$des = @mysql_fetch_array($resp);
if ($_SESSION['usuario_id'] == $rows['autor'] || $_SESSION['usuario_rol'] == "superadmin") {

?>
	<u><?=_EDITARDESCARGA; ?></u><br/><br/>
	<form name="form" method="post" action="procesar.php?editardescarga=yes">
    <input type="hidden" name="id" value="<?=$_GET['editardescarga'] ?>"/>
	<?=_NOMBRE; ?>:<br/><input type="text" name="nombre" value="<?=$des['nombre'] ?>" size="30"/><br/> 
    <?=_LINK; ?>:<br/><input type="text" name="link" value="<?=$des['link'] ?>" size="30"/><br/> 
    <?=_TAMANO; ?>:<br/><input type="text" name="tamano" value="<?=$des['tamano'] ?>" size="30"/><br/> 
		<?=_CATEGORIA; ?>: <select name="categoria">
<?
$query = "SELECT * FROM categorias";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows) {
	echo _NOHAYCATEGORIAS."<br/>";
} else {
	while ($datos = @mysql_fetch_array($resp)) {
		$content .= "<option value=\"".$datos['id']."\"";
		if ($des['categoria'] == $datos['id'])
            $content .= "selected";
		$content .= ">".$datos['nombre']."</option>\n";
	}
}

echo $content;
?>
</select><br/>
	<?=_DESCRIPCION; ?> <br/>
	<textarea name="descripcion" rows="2" cols="30"><?=$des['descripcion'] ?></textarea><br/>
	<br/>
	
    <input type="submit" name="editandodescarga" value="<?=_ENTRAR; ?>"/>
    </form>
<?
} else
	echo _NOEDITARDESCARGA;
}
}
} else { ?>

<div style="text-align: center"><br/>
    <form method="post" action="entrar.php" name="entrar">
	<fieldset>
	<label for="usuario"><input onfocus="borrarCampoUsuario();" type="text" id="usuario" name="usuario" value="<?=_USUARIO; ?>" /></label> <br /> 
    <label for="pass"><input onfocus="borrarCampoPass();" type="password" id="pass" name="pass" value="<?=_PASS; ?>" /></label> <br /> 
    <input type="submit" name="entrar" value="<?=_ENTRAR; ?>" />
	</fieldset>
    </form> 
</div>	
<? } ?>
