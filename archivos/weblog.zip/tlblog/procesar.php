<?
session_start();
session_cache_limiter('nocache, private');

if (isset($_SESSION['usuario'])) { 
    include("config.php");
	include("funciones.php");

    if (isset($_POST['enviararticulo'])) {
        $titulo = htmlspecialchars(trim($_POST['titulo']));
        $intro = htmlspecialchars(trim($_POST['intro']));
        $texto = htmlspecialchars(trim($_POST['texto']));
        if ($titulo != "" && $intro != "") {
                $query = "insert into entradas (id, fecha, hora, titulo, intro, texto, autorid, categoria, lecturas) values ('".$_POST['id']."', '".$_POST['fecha']."', '".$_POST['hora']."', '$titulo', '$intro', '$texto', ".$_SESSION['usuario_id'].", ".$_POST['categoria'].", 0)";
                mysql_query($query);
			    mysql_close($conecta);
                header("Location: index.php?op=admin&msg=0");
                exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
    } 
	
	if (isset($_POST['enviarcategoria'])) { 
     $nombre = htmlentities(trim($_POST['nombre']));
     if ($nombre != "") {
	 	$query = "SELECT * FROM categorias WHERE nombre = '".$nombre."'";
        $resp = mysql_query($query); 
		$rows = mysql_num_rows($resp);
		if (!$rows) {
        	$query = "insert into categorias (id, nombre) values ('$id', '".$nombre."')";
        	mysql_query($query); 
		} else {
			header("Location: index.php?op=admin&msg=10");
        	exit;
		}
        mysql_close($conecta);
        header("Location: index.php?op=admin&msg=0");
        exit;
     } else {
         header("Location: index.php?op=admin&msg=4");
         exit;
     }
    } 


    if (isset($_POST['enviarenlace'])) { 
        $nombreweb = htmlentities(trim($_POST['nombreweb']));
        $url = htmlentities(trim($_POST['url']));
		$descripcion = htmlentities(trim($_POST['descripcion']));
        if ($nombreweb != "" && $url != "" && $descripcion != "") {
            $query = "insert into enlaces (id, nombre, url, categoria, descripcion) values ('$id', '$nombreweb', '$url', '".$_POST['categoria']."', '".$descripcion."')";
            mysql_query($query);
            mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
    } 
	
	if (isset($_POST['enviardescarga'])) { 
        $nombre = htmlentities(trim($_POST['nombre']));
		$link = htmlentities(trim($_POST['link']));
		$tamano = htmlentities(trim($_POST['tamano']));
		$descripcion = htmlentities(trim($_POST['descripcion']));
        if ($nombre != "" && $link != "" && $tamano != "" && $descripcion != "") {
            $query = "insert into descargas (nombre, descripcion, autor, link, tamano, categoria, contador) values ('$nombre', '$descripcion', '".$_SESSION['usuario_id']."', '$link', '$tamano', '".$_POST['categoria']."', '0')";
            mysql_query($query);
            mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
    } 
	
	if (isset($_GET['edit'])) {
        $titulo = htmlspecialchars(trim($_POST['titulo']));
        $intro = htmlspecialchars(trim($_POST['intro']));
        $texto = htmlspecialchars(trim($_POST['texto']));
        if ($titulo != "" && $intro != "") {
            $sql = "UPDATE entradas SET titulo = '".$titulo."', intro = '".$intro."', texto = '".$texto."', categoria = '".$_POST['categoria']."' WHERE id = ".$_POST['id']."";
            @mysql_query($sql);
            @mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
	}
	
	if (isset($_GET['editarcategoria'])) {
        $nombre = htmlspecialchars(trim($_POST['categoria']));
        if ($nombre != "") {
            $sql = "UPDATE categorias SET nombre = '".$nombre."' WHERE id = ".$_POST['id']."";
            @mysql_query($sql);
            @mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
	}
	
	if (isset($_GET['editarenlace'])) {
        $nombre = htmlspecialchars(trim($_POST['nombre']));
		$url = htmlspecialchars(trim($_POST['url']));
		$descripcion = htmlentities(trim($_POST['descripcion']));
        if ($nombre != "" && $url !="" && $descripcion  != "") {
            $sql = "UPDATE enlaces SET nombre = '".$nombre."', url ='".$url."', categoria = '".$_POST['categoria']."', descripcion = '".$descripcion ."' WHERE id = ".$_POST['id']."";
            @mysql_query($sql);
            @mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
		 
	}
	
	if (isset($_GET['editarcomentario'])) {
        $nick = htmlspecialchars(trim($_POST['nick']));
		$url = htmlspecialchars(trim($_POST['url']));
		$email = htmlspecialchars(trim($_POST['email']));
		$texto = htmlspecialchars(trim($_POST['texto']));
        if ($nick != "" && $texto !="") {
            $sql = "UPDATE comentarios SET nick = '".$nick."', texto ='".$texto."', email = '".$email."', url = '".$url."' WHERE id = ".$_POST['id']."";
            @mysql_query($sql);
            @mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
	
	}
	
	if (isset($_POST['editardatos'])) {
		$nombre = htmlentities(trim($_POST['nombre']));
        $passactual = trim($_POST['passactual']);
		$pass = trim($_POST['pass']);
		$pass2 = trim($_POST['pass2']);
		$query = "SELECT pass FROM autores WHERE nombre  = '".$_SESSION['usuario']."'";
		$resp = mysql_query($query) or die(mysql_error());
		$rows = mysql_fetch_array($resp);
		$passbase = $rows['pass'];

		if ($nombre == "") {
			header ("Location: index.php?op=admin&msg=4");
			exit;
		} else if ($passactual != "" && ($pass == "" || $pass2 == "")) {	
				header ("Location: index.php?op=admin&msg=4");
				exit;
		} else if ($passactual == "" && ($pass != "" || $pass2 != "")) {	
				header ("Location: index.php?op=admin&msg=4");
				exit;		
		} else if ($pass != $pass2) {
				header ("Location: index.php?op=admin&msg=8");
				exit;
		} else if ($passactual != "" && (md5($passactual) != $passbase)) {
					header ("Location: index.php?op=admin&msg=9");
					exit;
		} else {
			if ($passactual != "" && md5($passactual) == $passbase) {
				$pass = md5($pass);
				$query = "UPDATE autores SET pass = '".$pass."' WHERE idautor = '".$_SESSION['usuario_id']."'";
				mysql_query($query) or die(mysql_error());
				}
			if ($nombre != "") {
				$query = "UPDATE autores SET nombre = '".$nombre."' WHERE idautor = '".$_SESSION['usuario_id']."'";
				mysql_query($query) or die(mysql_error());
				$_SESSION['usuario'] = $nombre;
			}	
			header ("Location: index.php?op=admin&msg=0");
			exit;
		}
	} 
	
	if (isset($_GET['borrar'])) {
		if (isset($_GET['act']) && $_GET['act'] == "categoria") {
			$query = "DELETE FROM categorias WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
			$query = "SELECT * FROM entradas WHERE categoria = '".$_GET['borrar']."'";
			$resp = @mysql_query($query);
			$rows = @mysql_num_rows($resp);
			if ($rows) {
				while ($art = @mysql_fetch_array($resp)) {
					$query2 = "DELETE FROM entradas WHERE categoria = '".$_GET['borrar']."'";
					@mysql_query($query2);
					$query2 = "DELETE FROM comentarios WHERE entrada = '".$art['id']. "'";
					@mysql_query($query2);
				}
			}
			$query = "DELETE FROM descargas WHERE categoria = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
			$query = "DELETE FROM enlaces WHERE categoria = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;
		} else if (isset($_GET['act']) && $_GET['act'] == "coment") {
			$query = "DELETE FROM comentarios WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;
		} else if (isset($_GET['act']) && $_GET['act'] == "envio") {
			$query = "DELETE FROM contacto WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;
		} else if (isset($_GET['act']) && $_GET['act'] == "link") {
			$query = "DELETE FROM enlaces WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;
		} else if (isset($_GET['act']) && $_GET['act'] == "descarga") {
			$query = "DELETE FROM descargas WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;	
		} else {
			$query = "DELETE FROM entradas WHERE id = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
			$query = "DELETE FROM comentarios WHERE entrada = '" . $_GET['borrar'] . "'";
			@mysql_query($query);
	    	header("Location: index.php?op=admin&msg=0");
	    	exit;
	    }
	
	}
	
	if (isset($_GET['editardescarga'])) {
       $nombre = htmlentities(trim($_POST['nombre']));
		$link = htmlentities(trim($_POST['link']));
		$tamano = htmlentities(trim($_POST['tamano']));
		$descripcion = htmlentities(trim($_POST['descripcion']));
        $categoria = htmlentities(trim($_POST['categoria']));
        if ($_POST['id'] != "" && $nombre != "" && $link != "" && $tamano != "" && $descripcion != "" && $categoria != "" ) {
            $query = "UPDATE descargas SET nombre = '".$nombre."', link = '".$link."', tamano = '".$tamano."', descripcion = '".$descripcion."', categoria = '".$categoria."' WHERE id = ".$_POST['id']."";
            @mysql_query($query);
            @mysql_close($conecta);
            header("Location: index.php?op=admin&msg=0");
            exit;
        } else {
            header("Location: index.php?op=admin&msg=4");
            exit;
        }
	}
}	
header("Location: index.php?op=admin");
?>