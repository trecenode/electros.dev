<?

$query = "SELECT * FROM entradas WHERE id= '" . $_GET['entrada'] . "'"; 
$resp = mysql_query($query);
$rows = mysql_num_rows($resp);
if (!$rows)
echo "<h1>"._NOEXISTEARTICULO."</h1>";
else {
$query = "UPDATE entradas SET lecturas = lecturas + 1 WHERE id ='" . $_GET['entrada'] . "'";
mysql_query($query);

while ($datos = mysql_fetch_array($resp)) {
	$query2 = "SELECT nombre FROM categorias WHERE id = " . $datos['categoria'] . ""; 
	$resp2 = mysql_query($query2);
	$datos2 = mysql_fetch_array($resp2); 
	$query3 = "SELECT nombre FROM autores WHERE idautor = " . $datos['autorid'] . "";
	$resp3 = mysql_query($query3);
	$datos3 = mysql_fetch_array($resp3);
	$intro = bbcodes($datos['intro']);
	$intro = nl2br($intro);
	$texto = bbcodes($datos['texto']);
	$texto = nl2br($texto);
	echo "<h1>" . $datos['titulo'] . "</h1><div class=\"editorial\"><p>"._AUTOR.": <strong>".$datos3['nombre']."</strong>, "._CATEGORIA.": <strong>".$datos2['nombre']."</strong><br/>" . $datos['fecha'] . ", " . $datos['hora'] . "</p> <p>".$intro."</p> <p>".$texto."</p></div> <br />";
	}
?>
<div style="border-top: 1px dotted #ccc">
<?
echo "<h1>"._COMENTARIOS."</h1>";
$query = "SELECT * FROM comentarios WHERE entrada = '" . $_GET['entrada'] . "' order by id"; 
$resp = mysql_query($query);
$rows = mysql_num_rows($resp);
if (!$rows)
	echo _NOHAYCOMENTARIOS;
else {
$i = 0;
while ($datos = mysql_fetch_array($resp)) {
$texto = nl2br($datos['texto']);
if ($datos['email'] == "") {
				$mostrarmail = "";
			} else {
				$mostrarmail = "<a href=\"mailto:".$datos['email']."\">Email</a>";			
			}
			
			// Comprobamos direccion web
			if ($datos['url'] == "") {
				$mostrarurl = "";	
			} else {
				$mostrarurl = "<a href=\"". $datos['url'] . "\" onclick=\"enlace(this.href); return false;\">Web</a>";
			}
if ($i % 2 == 0)
	echo "<p class=\"comentarios1\">";
else
 	echo "<p class=\"comentarios2\">";
echo "<span class=\"point\"><strong>" . $datos['nick'] . "</strong> ".$datos['fecha']." "._ALAS." ".$datos['hora']." </span><br /> " . $mostrarmail . " " . $mostrarurl . " <br />" . $texto . "";
$i ++;
    if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") {
        echo "<br/> <a title=\""._EDITARCOMENTARIO."\" href=\"index.php?op=admin&editarcomentario=".$datos['id']."\">["._EDITAR."]</a>";
		echo "<a title=\""._BORRARCOMENTARIO."\" href=\"procesar.php?borrar=".$datos['id']."&act=coment\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
	}
		echo "</p>";
	}


}
?>
<h1><?=_ENVIARCOMENTARIO; ?></h1>
<form action="insertar.php" onSubmit="return enviado()" method="post" name="formulario">
<fieldset>
<label for="id"><input type="hidden" name="id" value=""/></label>
<label for="ip"><input type="hidden" name="ip" value="<? echo getIP(); ?>" /></label>
<label for="entrada"><input type="hidden" name="entrada" value="<?=$_GET['entrada'] ?>"/></label>
<p>
<? echo "<label for=\"nick\">"._NICK.": </label>";
if (isset($_SESSION['usuario'])) {
	echo "<strong>".$_SESSION['usuario']."</strong><br/><br/>";
	echo "<input type=\"hidden\" name=\"nick\" value=\"".$_SESSION['usuario']."\"/>";
} else { ?>
<br/>
<input type="text" name="nick" size="20" maxlength="40" /> <br />
<label for="email">Email:</label><br/><input type="text" name="email" size="33" maxlength="40"/><br />
<label for="url">URL:</label> <br/> <input name="url" value="<?=$web; ?>" size="33" /><br/>
<? } ?>
<label for="texto"><?=_COMENTARIO; ?></label><br/>
<textarea name="texto" cols="50" rows="4"></textarea><br/><br/>
<input type="submit" name="enviar" value="<?=_ENVIAR; ?>"/></p>
</fieldset>
</form>
</div><? } ?>
