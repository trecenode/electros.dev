<?
session_start();
session_cache_limiter('nocache, private');

session_destroy();
header("Location: index.php");

?>
