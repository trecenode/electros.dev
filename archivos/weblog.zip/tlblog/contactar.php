<?

if(isset($_POST['enviar'])) {
        $email = htmlentities(trim($_POST['email']));
        $asunto = htmlentities(trim($_POST['asunto']));
        $msg = htmlentities(trim($_POST['mensaje']));
        if ($email != "" && $asunto != "" && $msg != "") {
                include("config.php");
                $fecha = date("j/n/Y");
				$hora = date("g:i a");
                $query = "INSERT INTO contacto (id, email, asunto, mensaje, fecha, hora) values ('', '".$email."', '".$asunto."', '$msg', '$fecha', '$hora')";
                @mysql_query($query);
                @mysql_close($conecta);
                header ("Location: index.php?op=contactar&msg=6");
                exit;
        } else {
            header("Location: index.php?op=contactar&msg=7");
            exit;
        }

}
?>
