<?php 
if (isset($_GET['cat'])) {
	$query = "SELECT * FROM `categorias` WHERE id = '".$_GET['cat']."'";
	$resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows) {
		echo _NOEXISTECAT;
	} else {
		$nombre = @mysql_fetch_array($resp);
		echo _CATEGORIA." > <strong>".$nombre['nombre']."</strong>";
		$query = "SELECT * FROM `descargas` WHERE categoria = '".$_GET['cat']."' ORDER BY `id` DESC LIMIT 0, 30"; 
		$resp = mysql_query($query); 
		$rows = mysql_num_rows($resp);
		echo "<br />  "._TOTALDESCARGAS." ".$rows.""; 
		if ($rows) {
			while ($row = mysql_fetch_assoc($resp)) { 
				$id = $row['id']; 
				$categoria = $row['categoria']; 
				$link = "index.php?op=descargas&id=$id";  
				$linkdesc = "mirror.php?id=$id"; 
				echo "<br/> + <a href=\"".$link."\">".$row[nombre]."</a>  <a href=\"".$linkdesc."\">"._DESCARGAR."</a> ";
	if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") {
echo "<a href=\"index.php?op=admin&editardescarga=".$row['id']."\">["._EDITAR."]</a> <a href=\"procesar.php?borrar=".$row['id']."&act=descarga\" onclick=\"return deleteremember()\">["._BORRAR."]</a>"; 
}
			} 
		}
	}
} else { 
if(!isset($_GET['id'])) { 
echo "> "._CATEGORIAS;   
$query = "SELECT * FROM `categorias` LIMIT 0, 30";
$resp = @mysql_query($query); 
$rows = @mysql_num_rows($resp);
	if (!$rows) {
		echo "<br/>"._NOHAYCATEGORIAS;
	} else {	
		while($row = @mysql_fetch_array($resp)) { 
			$categoria = $row['id']; 
			$link = "index.php?op=descargas&cat=".$categoria; 
			echo "<br /><a href=\"".$link."\">".$row[nombre]."</a> "; 
			$query2 = "SELECT * FROM `descargas` WHERE categoria = '".$row['id']."'"; 
			$resp2 = @mysql_query($query2);
			$rows = @mysql_num_rows($resp2);
			echo "(".$rows.")"; 
			} 
		}
} else { 
$query = "SELECT * FROM descargas WHERE id = '".$_GET['id']."'";
$resp = mysql_query($query); 
if ($datos = mysql_fetch_array($resp)) { 
	$query2 = "SELECT nombre FROM `autores` WHERE idautor = '".$datos['autor']."'";
	$resp2 = @mysql_query($query2);
	$autor = @mysql_fetch_array($resp2);
	echo "<div class=\"editorial\"><p>"._INFODESCARGA." <strong>".$datos['nombre']."</strong>"; 
	$link = "mirror.php?id=".$datos['id']; 
	echo "<br/>  "; 
	echo "<br/>"._DESCRIPCION.": ".$datos['descripcion'];
	echo "<br/> "._TAMANO.": <strong>".$datos['tamano']."</strong>";
	echo " | "._AGREGADO.": <strong>".$autor['nombre']."</strong>";
	$query2 = "SELECT * FROM `categorias` WHERE id = '".$datos['categoria']."'";
	$resp2 = @mysql_query($query2);
	$cat = @mysql_fetch_array($resp2);
	echo " | "._CATEGORIA.": <strong>".$cat['nombre']."</strong>";
	echo " | "._DESCARGAS.": <strong>".$datos['contador']."</strong>"; 
	echo "<br/> > <a href=\"".$link."\">"._DESCARGAR."</a></p></div>"; 
} else 
	echo _NOEXISTEDESCARGA;  
} 
} 
?> 