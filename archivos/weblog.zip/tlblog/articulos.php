<?php

function contarComentarios($id) {
    $query = "SELECT * FROM `comentarios` WHERE `entrada`='$id'";
    $resp = mysql_query($query);
    return mysql_num_rows($resp);
}

$n = $numero + $mas_articulos;
$query = "SELECT * FROM `entradas` order by id desc limit $n"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
	echo _NOHAYARTICULOS;
} else {
$n = 0;
while (($n < $numero) && ($articulos = mysql_fetch_array($resp))) {
	$query2 = "select * from categorias WHERE id = '".$articulos['categoria']."'";
    $resp2 = @mysql_query($query2);
	$datos2 = @mysql_fetch_array($resp2);
	
	$query3 = "SELECT * FROM autores WHERE idautor = '". $articulos['autorid'] ."'";
	$resp3 = @mysql_query($query3);
	$datos3 = mysql_fetch_array($resp3);
	$intro = bbcodes($articulos['intro']); 
	$intro = nl2br($intro);
	
echo "<h1><a href=\"index.php?op=leer&amp;entrada=" . $articulos['id'] . "\" title=\""._LEERRESTO."\">" . $articulos['titulo'] . "</a></h1>
<div class=\"editorial\">". $articulos['fecha'] . ", " . $articulos['hora']."<br />";
echo $intro . "<div class=\"separador\">"._AUTOR.": <a href=\"index.php?op=archivo&amp;autor=" . $articulos['autorid'] . "\" title=\""._VERARTICULOSAUTOR."\">".$datos3['nombre']."</a> | "._CATEGORIA.": <a href=\"index.php?op=archivo&amp;categoria=" . $articulos['categoria'] . "\" title=\""._VERARTICULOSCATEGORIA."\">".$datos2['nombre']."</a>  | ";
if ($articulos['texto'] != "")
	echo "<a href=\"index.php?op=leer&amp;entrada=" . $articulos['id'] . "\" title=\""._LEERRESTO."\">"._LEERMAS." ...</a> | ";
echo "<a href=\"index.php?op=leer&amp;entrada=" . $articulos['id'] . "\" title=\""._LEERCOMENTARIOS."\">"._COMENTARIOS." (" . contarComentarios($articulos['id']) . ")</a> | ".$articulos['lecturas']." "._LECTURAS."</div></div><br />";
$n ++;
	}
}
?>
