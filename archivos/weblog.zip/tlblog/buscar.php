<?

if (isset($_POST['busqueda'])) {
    $consulta = trim($_POST['busqueda']);
	if($consulta == "") {
	echo _NORESULTADOS;
} else if ($resp = search_query("$consulta","entradas","entradas.titulo|entradas.intro|entradas.texto")) { 
	while($sql = search_fetch_array($resp)) { 
		$query2 = "SELECT nombre FROM categorias WHERE id = " . $sql['categoria'] . ""; 
     	$resp2 = mysql_query($query2); 
     	$sql2 = mysql_fetch_array($resp2); 
     	echo "- <a href=\"index.php?op=leer&amp;entrada=" . $sql['id'] . "\">" . $sql['titulo'] . "</a> - ".$sql2['nombre'].", (" . $sql['fecha'] . ")<br/>"; 
    } 
} else { 
   echo _NORESULTADOS;
} 
}
?> 
