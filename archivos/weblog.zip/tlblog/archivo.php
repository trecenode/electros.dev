<?

function mes($fecha) {
global $fecha_vieja;
$meses = array(_ENERO, _FEBRERO, _MARZO, _ABRIL, _MAYO, _JUNIO, _JULIO, _AGOSTO, _SEPTIEMBRE, _OCTUBRE, _NOVIEMBRE, _DICIEMBRE);
$nueva_fecha = explode("/", $fecha);
$mes = $nueva_fecha[1];
$anno = $nueva_fecha[2];

if ($fecha_vieja != $mes) {
    $mes = $meses[$mes-1];
	echo $mes." "._DE." ". $anno ."<br/>";
	$fecha_vieja = $nueva_fecha[1];
    }
}

if (!isset($_GET['categoria']) && !isset($_GET['autor'])) {
echo _TODOSARTICULOS."<br/>";
$query = "SELECT * FROM entradas order by id desc limit 100"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if (!$rows)
    echo _NOHAYARTICULOS;
else {
$fecha_vieja = "0";
while ($datos = mysql_fetch_array($resp)) {
    mes($datos['fecha']);
	$query2 = "SELECT * FROM categorias WHERE id = ". $datos['categoria'] ."";
	$resp2 = @mysql_query($query2);
	$datos2 = mysql_fetch_array($resp2); 
    echo "- <a href=\"index.php?op=leer&amp;entrada=" . $datos['id'] . "\">" . $datos['titulo'] . "</a> - ".$datos2['nombre'].", (" . $datos['fecha'] . ")";
    if ((isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] == $datos['idautor']) || $_SESSION['usuario_rol'] == "superadmin") {
        echo " <a href=\"index.php?op=admin&edit=".$datos['id']."\">["._EDITAR."]</a>";
        echo " <a href=\"procesar.php?borrar=".$datos['id']."\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
    }
    echo "<br/>";
	}
}
} else if (!isset($_GET['autor'])) {
$query = "SELECT * FROM categorias WHERE id = '". $_GET['categoria'] ."'";
    $resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows) {
	echo _NOEXISTECAT;
	} else {
	$datos = @mysql_fetch_array($resp);
    echo _CATEGORIA." "._DE." <strong>".$datos['nombre']."</strong><br/>";
	$query = "SELECT * FROM entradas WHERE categoria = '". $_GET['categoria'] ."' order by id desc limit 100";
	$resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows)
		echo _NOHAYARTICULOS;
	else {
	    $fecha_vieja = "0";
		while ($datos = @mysql_fetch_array($resp)) {
		mes($datos['fecha']);
			echo "- <a href=\"index.php?op=leer&amp;entrada=" . $datos['id'] . "\">" . $datos['titulo'] . "</a> (" . $datos['fecha'] . ")";
            if ((isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] == $datos['autorid']) || $_SESSION['usuario_rol'] == "superadmin") {
                echo " <a href=\"index.php?op=admin&edit=".$datos['id']."\">["._EDITAR."]</a>";
                echo " <a href=\"procesar.php?borrar=".$datos['id']."\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
            }
            echo "<br/>";
        	}	
	}
	}
} else {
	$query = "SELECT * FROM autores WHERE idautor = '". $_GET['autor'] ."'";
    $resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows) {
	echo _NOEXISTEUSER;
	} else {
	$datos = @mysql_fetch_array($resp);
    echo _TODOSARTICULOS." "._DE." <strong>".$datos['nombre']."</strong><br/>";
	$query = "SELECT * FROM entradas WHERE autorid = '". $_GET['autor'] ."' order by id desc limit 100";
	$resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows)
		echo _NOHAYARTICULOS;
	else {
	    $fecha_vieja = "0";
		while ($datos = @mysql_fetch_array($resp)) {
		mes($datos['fecha']);
		$query2 = "SELECT * FROM categorias WHERE id = ". $datos['categoria'] ."";
	    $resp2 = @mysql_query($query2);
	    $datos2 = mysql_fetch_array($resp2);
			echo "- <a href=\"index.php?op=leer&amp;entrada=" . $datos['id'] . "\">" . $datos['titulo'] . "</a>, ".$datos2['nombre']." (" . $datos['fecha'] . ")";
            if ((isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] == $datos['autor']) || $_SESSION['usuario_rol'] == "superadmin") {
                echo " <a href=\"index.php?op=admin&edit=".$datos['id']."\">["._EDITAR."]</a>";
                echo " <a href=\"procesar.php?borrar=".$datos['id']."\" onclick=\"return deleteremember()\">["._BORRAR."]</a>";
            }
            echo "<br/>";
            }
	}
	}
}
?>
