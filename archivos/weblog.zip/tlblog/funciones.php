<?

function getIP() {
	// Cogemos la IP
	if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  	else if ($_SERVER['HTTP_VIA'] != "") 
         	$ip = $_SERVER['HTTP_VIA'];   
  	else if ($_SERVER['REMOTE_ADDR'] != "") 
         	$ip = $_SERVER['REMOTE_ADDR'];  
       	else 
         	$ip = _UNKNOWIP; 
		 
	return $ip;		 
}

function search_query ($buscar,$tablas,$campos) { 
    $campos = explode('|',$campos); 
    $tablas = explode('|',$tablas); 
    $buscar = explode(' ',$buscar); 
     
    // Hago un query por cada tabla 
    foreach($tablas as $tabla) { 
        $condiciones = array(); 
        // Comienzo a definir la sintaxis 
        $sintax = 'SELECT * FROM ' . addslashes($tabla) . ' WHERE '; 
        foreach($campos as $campo) { 
            // Busco en cada campo cada palabra del texto que as puesto en buscar. 
            foreach($buscar as $buscarr) { 
                $campoo = explode('.',$campo); 
                // Si el campo es perteneciente a la tabla que estoy haciendo el query ejecuto: 
                if($tabla == $campoo[0]) { 
                    // A�ado el like 
                    $condiciones[] = addslashes($campoo[1]) . ' LIKE \'%' . addslashes($buscarr) . '%\''; 
                } 
            } 
        } 
         
        // Con este implode pongo todos los OR 
        $sintax .= implode(" OR ",$condiciones); 
         
        $resp = mysql_query($sintax) or die(mysql_error()); 
        // Meto en el array los resultados de esta busqueda 
        while($encontrado = mysql_fetch_assoc($resp)) $retorno[] = $encontrado; 
    } 
    return $retorno; 
} 

function search_fetch_array(&$resp) { 
    if (is_array($resp)) { 
        $return = ($sql = current($resp)) ? $sql : false ; 
        next($resp); 
      
        return $return; 
    } 
} 

/* Parses Code de PHPHISPANO.net */
// Para ejecutar esto pondras [echo bbcodes ($texto);] $texto es la variable que tiene el 
// contenido que le implantara los bbcodes. 
function bbcodes ($text) { 
    // Links para URLs. Formato: [web=http://php-hispano.net]PHPHispano[/web] 
    $finaltext = eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]", "<a onclick=\"enlace(this.href); return false;\" href=\"\\1\">\\2</a>", $text); 

    // Si no ponen atributos en [web]. Formato: [web]http://PHPHispano.net[/web] 
    $finaltext = eregi_replace("\\[url\\]([^\\[]*)\\[/url\\]","<a onclick=\"enlace(this.href); return false;\" href=\"\\1\">\\1</a>",$finaltext); 

	$finaltext = eregi_replace("\\[img\\](http:\/\/[a-z0-9\/\\._\-\?\&= ]+)\[/img\\]", "<br /><img src=\"\\1\" alt=\"\" />", $finaltext);

    /* Este bucle lo hacemos por si ejempo usan u i y b en un solo texto :D */ 
    while($bucle < 5) { 
        // Para poner linea al texto. Formato: [u]PHPHispano[/u] 
        $finaltext = eregi_replace("\\[u\\]([^\\[]*)\\[/u\\]","<u>\\1</u>", $finaltext); 

        // Para poner el text en italic. Formato: [i]PHPHispano[/i] 
        $finaltext = eregi_replace("\\[i\\]([^\\[]*)\\[/i\\]","<em>\\1</em>", $finaltext); 

        // Para poner texto en negrita Formato: [b]PHPHispano[/b] 
        $finaltext = eregi_replace("\\[b\\]([^\\[]*)\\[/b\\]","<strong>\\1</strong>", $finaltext);
		
		// Para poner texto tachado Formato: [del]PHPHispano[/del] 
        $finaltext = eregi_replace("\\[del\\]([^\\[]*)\\[/del\\]","<del>\\1</del>", $finaltext); 

        $bucle++; 
    } 

    // Para centralizar un text. Formato: [center]PHPHispano[/center] 
    $finaltext = eregi_replace("\\[center\\]([^\\[]*)\\[/center\\]","<center>\\1</center>", $finaltext); 

    // Pone el texto como una cita. Formato: [cita]La calidad nunca es un accidente; siempre es el resultado de un esfuerzo de la inteligencia[/cita] 
    $finaltext = eregi_replace("\\[cita\\]([^\\[]*)\\[/cita\\]","\n<div class=\"css_title\"> <div class=\"css\">\\1</div></div>", $finaltext); 

    // Sacamos el color al codigo PHP. Formato: [php]codigo[/php] 
    preg_match_all ("/(\[)(php)(])(.*)(\[\/php\])/iU", $finaltext, $l); 
    for ($i=0; $i< count($l[0]); $i++) { $finaltext = str_replace($l[0][$i],phpcojecolor($l[4][$i]),$finaltext); } 

    // Retorno como queda el bbcode. 
    return $finaltext; 
} 

function phpcojecolor ($php) { 
// Remplaza los <br \> por lineas. 
$php = str_replace("<br \>","\n",$php); 

ob_start(); // Abirmos el OB 
highlight_string($php); // Tiramos el codigo coloreado 
$cfinal = ob_get_contents(); // COjo el codigo que tire despues de haber abierto el ob 
ob_end_clean(); // Borro el ob para que no se vea en la web 

// A continuaci�n hemos hecho uso de una funci�n realizada por Anonimo y que copi� de la web www.pastebin.com. Sirve para mostrar informaci�n sobre las funciones... [Proximas 7 lineas] 
$keycol=ini_get("highlight.keyword"); 
$manual="http://www.php.net/manual-lookup.php?lang=es&amp;pattern="; 

$cfinal=preg_replace( 
'{([\w_]+)(\s*</font>)'. 
'(\s*<font\s+color="'.$keycol.'">\s*\()}m', 
'<a href="'.$manual.'$1" title="Ayuda en PHP.net sobre $1" target="_blank">$1</a>$2$3', 
$cfinal); 

return "\n<div class=\"css_title\">C&oacute;digo PHP:\n<div class=\"css\">".$cfinal."</div></div>"; // Retorno el codigo PHP Coloreado 
}

function crearRSS() {
	global $filename, $titulo, $url, $tema;

	$filename = strtolower(str_replace(" ", "", "index")) . ".xml";

	if (file_exists($filename)) {
    	@unlink($filename);
  	}

  $handler = fopen($filename, 'w+');

  // Creamos las cabeceras para el RSS 
  $rssfile = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"
  xmlns=\"http://purl.org/rss/2.0/\">
   <channel rdf:about=\"".$url."\">
      <title>".$titulo."</title>
      <link>".$url ."/".$filename ."</link>
      <description>
         Generado desde nuesta DB
         ".$titulo."
      </description>
      <items>
         <rdf:Seq>\n";
  /* Sacamos la informacion de las noticias con una consulta anidada */
  $SQL_query = mysql_query('SELECT e.id,e.autorid,e.fecha,e.titulo,e.intro,e.texto,a.nombre,a.idautor'
                           . ' FROM entradas AS e'
                           . ' LEFT JOIN autores AS a ON(e.autorid=a.idautor)'
                           . ' ORDER by e.id DESC LIMIT 0, 10');

   while($noticias = @mysql_fetch_array($SQL_query))
  {
    /* Set Variables */
    $time = $noticias['fecha'];
    $titulo = $noticias['titulo'];
    $intro = $noticias['intro'];
    $nombre = $noticias['nombre'];

    if (!$nombre) {
      $usuario = $noticias['nombre'];
    }
    /* Mostramos el link hacia cada articulo */
    if ($noticias['texto'] != '') {
      $enlace = $url . '/index.php?op=leer&amp;entrada=' . $noticias['id'] . '';
    } else if ($noticias['texto'] != '') {
      $enlace = $url . '/index.php?op=leer&amp;entrada=' . $noticias['id'] . '';
    } else {
      $enlace = $url;
    }

    // Creamos la tabla de contenido
    $rssfile .= "            <rdf:li resource=\"".$titulo."\" />\n";

        // Creamos la <item> constructora para cada noticia
        $items .= "   <item rdf:about=\"".$enlace."\">
      <title>".str_replace('&quot;', '"', $titulo) ."</title>
      <link>".$enlace."</link>
      <description>
         $intro
      </description>
	  <pubDate>".$time."</pubDate> 

   </item>\n";
  }

  // Cerramos la tabla de contenido
  $rssfile .= "         </rdf:Seq>
      </items>
   </channel>\n";

  // Agregamos noticias por item
  $rssfile .= $items;

  // Creamos el pie del archivo de RSS
  $rssfile .= "</rdf:RDF>\n";

  // Pone la secuencia $rssfile en el archivo de RSS
  if(!fputs($handler, $rssfile)) {
    echo _NORSS;
  }

  fclose($handler);
}  
?>