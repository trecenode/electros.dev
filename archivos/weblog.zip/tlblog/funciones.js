var cuenta=0; 

function enviado() { 
	if (cuenta == 0) { 
		cuenta++; 
		return true; 
	} else { 
		alert("<?=_ALERTFLOOD; ?>"); 
		return false; 
	} 
}

function borrarCampoUsuario() {
  if (document.forms["entrar"].usuario.value == '<?=_USUARIO; ?>')
    document.forms["entrar"].usuario.value='';
}

function borrarCampoPass() {
  if (document.forms["entrar"].pass.value == '<?=_PASS; ?>')
    document.forms["entrar"].pass.value='';
}

	function deleteremember() {
		if (confirm('<?=_CONTINUAR; ?>')) {
			return true;
		} else {
		  return false;
		}
	}

	function mostrar(accion) {
		if (accion == 'agregararticulo') {
				document.getElementById(accion).style.display = 'block';
				document.getElementById('agregarenlace').style.display = 'none';
				document.getElementById('agregardescarga').style.display = 'none';
				document.getElementById('agregarcategoria').style.display = 'none';
		} else if (accion == 'agregarenlace') {
				document.getElementById(accion).style.display = 'block';
				document.getElementById('agregararticulo').style.display = 'none';
				document.getElementById('agregarcategoria').style.display = 'none';
				document.getElementById('agregardescarga').style.display = 'none';
		} else if (accion == 'agregardescarga') {
				document.getElementById(accion).style.display = 'block';
				document.getElementById('agregararticulo').style.display = 'none';
				document.getElementById('agregarcategoria').style.display = 'none';
				document.getElementById('agregarenlace').style.display = 'none';
		} else if (accion == 'agregarcategoria') {
				document.getElementById(accion).style.display = 'block';
				document.getElementById('agregararticulo').style.display = 'none';
				document.getElementById('agregarenlace').style.display = 'none';
				document.getElementById('agregardescarga').style.display = 'none';
		}
	}		
	
     function enlace(enlace) {
		window.open(enlace,this.target,'width=780,height=500, status=yes, toolbar=yes, menubar=yes, location=yes, resizable=yes,scrollbars=yes');
     }

     function negrita(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[b][/b]'");
		eval("document.form."+campo+".focus()");
     }

     function cursiva(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[i][/i]'");
		eval("document.form."+campo+".focus()");
     }

     function subrayado(campo) {
       eval("document.form."+campo+".value=document.form."+campo+".value+'[u][/u]'");
       eval("document.form."+campo+".focus()");
     }

     function tachado(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[del][/del]'");
		eval("document.form."+campo+".focus()");
     }

     
     function codigo(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[php][/php]'");
		eval("document.form."+campo+".focus()");
     }
	 
     function citar(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[cita][/cita]'");
		eval("document.form."+campo+".focus()");
     }

     function imagen(campo) {
		eval("document.form."+campo+".value=document.form."+campo+".value+'[img][/img]'");
		eval("document.form."+campo+".focus()");
     }

	function url(campo) {
		eval("mensaje_actual=document.form."+campo+".value");

       		var url = prompt("Introduzca la URL de la web: ", "http://");

       		if ((url==null)||(url=="")) 
			return;

       		var titulo = prompt("Nombre para el enlace (Pulse ESC si desea que sea la URL)", "Titulo de la pagina");

       		if((titulo==null)||(titulo==''))
           		var url_codigo = "[URL]"+url+"[/URL]";
       		else
           		var url_codigo = "[URL="+url+"]"+titulo+"[/URL]";

       		mensaje = mensaje_actual+url_codigo;
       
       		eval("document.form."+campo+".value=mensaje");
       		eval("document.form."+campo+".focus()");
     }