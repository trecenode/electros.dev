<?
session_start();
session_cache_limiter('nocache, private');

if (isset($_POST['enviar'])) {
    $nick = trim($_POST['nick']);
	$texto = trim($_POST['texto']);
	$email = trim($_POST['email']);
	$url = trim($_POST['url']);
	if($texto == "" || $nick == "") {
		header("Location: ".$_SERVER['HTTP_REFERER']);
		exit; 
	} else {		
    	include("config.php");
	
		$nick = htmlentities($nick);
		$sql = "SELECT * FROM autores WHERE nombre = '".$nick."'";
		$resp = @mysql_query($sql);
		$existe = @mysql_num_rows($resp);

		if ($existe && !isset($_SESSION['usuario']))
		    $nick = _ANONIMO;
		else if (isset($_SESSION['usuario']))
				$nick = $_SESSION['usuario'];
		    
		$texto = htmlentities($texto);
	
		$palabras = explode(" ", $texto);
		$n = count($palabras);
	
		for ($i = 0; $i < $n; $i ++) {
		  if (strlen($palabras[$i]) > 40) {
                // Dividimos las palabras que excedan el m�ximo  (40)
                $texto_nuevo .= wordwrap($palabras[$i],40,"<br/>",1);
              } else
		   	   $texto_nuevo .= $palabras[$i];
				   $texto_nuevo .= " ";
		} 
		if (isset($_POST['url'])) 
        $url = $_POST['url'];
		if (isset($_POST['email'])) 
        $email = $_POST['email'];
		$ip = $_POST['ip'];
		$fecha = date("j/n/Y");
		$hora = date("g:i a");
		$query = "INSERT INTO comentarios (entrada, id, nick, texto, email, url, fecha, hora, ip) VALUES ('".$_POST['entrada']."', '".$_POST['id']."', '".$nick."', '".$texto_nuevo."', '".$email."', '".$url."', '".$fecha."', '".$hora."', '".$ip."')";
		@mysql_query($query);
	}
}	

header("Location: ".$_SERVER['HTTP_REFERER']);
?>
