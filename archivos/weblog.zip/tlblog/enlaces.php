<?php 
if (isset($_GET['cat'])) {
	$query = "SELECT * FROM `categorias` WHERE id = '".$_GET['cat']."'";
	$resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp);
	if (!$rows) {
		echo _NOEXISTECAT;
	} else {
		$nombre = @mysql_fetch_array($resp);
		echo _CATEGORIA." > <strong>".$nombre['nombre']."</strong>";
		$query = "SELECT * FROM `enlaces` WHERE categoria = '".$_GET['cat']."' ORDER BY `id` DESC LIMIT 0, 30"; 
		$resp = mysql_query($query); 
		$rows = mysql_num_rows($resp);
		echo "<br />  "._TOTALENLACES." ".$rows.""; 
		if ($rows) {
			while ($row = mysql_fetch_assoc($resp)) { 
				echo "<br/><br/> + <a onclick=\"enlace(this.href); return false;\" href=\"".$row['url']."\">".$row['nombre']."</a>";
				if (isset($_SESSION['usuario']) && $_SESSION['usuario_rol'] == "superadmin") {
					echo " <a href=\"index.php?op=admin&editarenlace=".$row['id']."\">["._EDITAR."]</a> <a href=\"procesar.php?borrar=".$row['id']."&act=enlace\" onclick=\"return deleteremember()\">["._BORRAR."]</a>"; 
				}
				echo "<br/>".$row['descripcion'];
			} 
		}
	}
} else { 
echo "> "._CATEGORIAS;   
$query = "SELECT * FROM `categorias` LIMIT 0, 30";
$resp = @mysql_query($query); 
$rows = @mysql_num_rows($resp);
	if (!$rows) {
		echo "<br/>"._NOHAYCATEGORIAS;
	} else {	
		while($row = @mysql_fetch_array($resp)) { 
			$categoria = $row['id']; 
			$link = "index.php?op=enlaces&cat=".$categoria; 
			echo "<br /><a href=\"".$link."\">".$row[nombre]."</a> "; 
			$query2 = "SELECT * FROM `enlaces` WHERE categoria = '".$row['id']."'"; 
			$resp2 = @mysql_query($query2);
			$rows = @mysql_num_rows($resp2);
			echo "(".$rows.")"; 
			} 
		}
}
?> 