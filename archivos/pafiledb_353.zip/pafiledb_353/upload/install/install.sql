-- phpMyAdmin SQL Dump
-- version 2.6.4-pl4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 25, 2006 at 05:14 PM
-- Server version: 4.0.26
-- PHP Version: 5.0.4
-- 
-- Database: `pafiledb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

DROP TABLE IF EXISTS `##PREFIX##admin`;
CREATE TABLE `##PREFIX##admin` (
  `admin_id` int(5) NOT NULL auto_increment,
  `admin_username` varchar(20) default NULL,
  `admin_password` varchar(32) default NULL,
  `admin_email` varchar(50) default NULL,
  `admin_status` int(1) default NULL,
  PRIMARY KEY  (`admin_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `admin`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `cat`
-- 

DROP TABLE IF EXISTS `##PREFIX##cat`;
CREATE TABLE `##PREFIX##cat` (
  `cat_id` int(5) NOT NULL auto_increment,
  `cat_name` varchar(75) default NULL,
  `cat_desc` varchar(150) default NULL,
  `cat_files` int(10) default NULL,
  `cat_parent` int(5) default NULL,
  `cat_order` int(5) default NULL,
  `cat_sort` varchar(25) default NULL,
  PRIMARY KEY  (`cat_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `cat`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `custom`
-- 

DROP TABLE IF EXISTS `##PREFIX##custom`;
CREATE TABLE `##PREFIX##custom` (
  `custom_id` int(5) NOT NULL auto_increment,
  `custom_name` varchar(50) NOT NULL default '',
  `custom_description` varchar(150) NOT NULL default '',
  PRIMARY KEY  (`custom_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `custom`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `customdata`
-- 

DROP TABLE IF EXISTS `##PREFIX##customdata`;
CREATE TABLE `##PREFIX##customdata` (
  `customdata_file` int(5) NOT NULL default '0',
  `customdata_custom` int(5) NOT NULL default '0',
  `data` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `customdata`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `emaillog`
-- 

DROP TABLE IF EXISTS `##PREFIX##emaillog`;
CREATE TABLE `##PREFIX##emaillog` (
  `e_id` int(6) NOT NULL auto_increment,
  `e_date` int(20) NOT NULL default '0',
  `e_ip` varchar(15) NOT NULL default '',
  `e_fromname` text NOT NULL,
  `e_fromaddress` text NOT NULL,
  `e_toname` text NOT NULL,
  `e_toaddress` text NOT NULL,
  `e_headers` text NOT NULL,
  `e_subject` text NOT NULL,
  `e_message` text NOT NULL,
  PRIMARY KEY  (`e_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `emaillog`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `files`
-- 

DROP TABLE IF EXISTS `##PREFIX##files`;
CREATE TABLE `##PREFIX##files` (
  `file_id` int(10) NOT NULL auto_increment,
  `file_name` varchar(150) default NULL,
  `file_desc` varchar(200) default NULL,
  `file_creator` varchar(100) default NULL,
  `file_version` varchar(20) default NULL,
  `file_longdesc` text,
  `file_ssurl` text,
  `file_dlurl` text,
  `file_mirrors` text NOT NULL,
  `file_time` int(50) default NULL,
  `file_catid` int(5) default NULL,
  `file_posticon` varchar(30) default NULL,
  `file_license` int(5) default NULL,
  `file_dls` int(10) default NULL,
  `file_last` int(50) default NULL,
  `file_pin` int(1) default NULL,
  `file_docsurl` text,
  `file_rating` int(10) NOT NULL default '0',
  `file_totalvotes` int(10) NOT NULL default '0',
  PRIMARY KEY  (`file_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `files`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `license`
-- 

DROP TABLE IF EXISTS `##PREFIX##license`;
CREATE TABLE `##PREFIX##license` (
  `license_id` int(5) NOT NULL auto_increment,
  `license_name` varchar(30) default NULL,
  `license_text` text,
  PRIMARY KEY  (`license_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `license`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `settings`
-- 

DROP TABLE IF EXISTS `##PREFIX##settings`;
CREATE TABLE `##PREFIX##settings` (
  `id` int(1) NOT NULL auto_increment,
  `dbname` text NOT NULL,
  `dburl` text NOT NULL,
  `topnumber` int(5) NOT NULL default '0',
  `homeurl` text NOT NULL,
  `timeoffset` int(5) NOT NULL default '0',
  `timezone` varchar(100) NOT NULL default '',
  `skin` varchar(20) NOT NULL default '',
  `stats` int(1) NOT NULL default '0',
  `lang` varchar(20) NOT NULL default '',
  `viewall` int(1) NOT NULL default '0',
  `showss` int(1) NOT NULL default '0',
  `date_format` varchar(40) NOT NULL default '',
  `time_format` varchar(40) NOT NULL default '',
  `dropdown` text NOT NULL,
  `enable_email` int(1) NOT NULL default '0',
  `perpage` int(3) NOT NULL default '0',
  `enable_report` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `settings`
-- 

INSERT INTO `##PREFIX##settings` VALUES (1, 'My Files', '', 5, 'http://www.yoursite.com', 0, 'Central Time', 'default', 0, 'english', 1, 0, '%b %d, %Y', '%I:%M %p', '', 1, 20, 1);
