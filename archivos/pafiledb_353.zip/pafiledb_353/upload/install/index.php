<?php

/**
  * paFileDB 3.5
  *
  * This is the installer for paFileDB.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */


function printheader($header) {
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">    <html xmlns="http://www.w3.org/1999/xhtml">    <head>    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />    <title>paFileDB Installer</title>    <link href="../skins/default/style.css" rel="stylesheet" type="text/css" />
    <script language="javascript">		function verify(form, mail) {			for (i=0; i<form.elements.length; i++ ) {				form.elements[i].focus();				if ((form.elements[i].type=="text" || form.elements[i].type !== "textarea" || form.elements[i].type=="password") && form.elements[i].value == "") {					alert("All fields are required. Please fill out all fields.");					return;				}
				if (mail == 1) {
                    if (form.pass.value != form.cpass.value) {
                        alert("The two passwords you entered did not match. Please go back and try again.");
                        return;
                    }
                }			}

            everify(form, mail);
		}		function everify(form, mail) {			if (mail == 1) {
                if (form.email.value == "" || form.email.value.indexOf('@') == -1 || form.email.value.indexOf('.') == -1 || 			form.email.value.length<6) {                    alert("The e-mail address you entered is not valid. Please enter a valid e-mail address.");                    form.email.focus();                    return;                }
			}
			form.submit();		}	</script>
    </head>    <body>    <table width="75%" border="1" align="center" cellpadding="3" cellspacing="0" class="border">      <tr>        <td class="header" width="50%">paFileDB Installer</td>
        <td width="50%" align="right"><span style="font-size:15px;"><?php echo($header); ?></span>      </tr>
    <?php
}
error_reporting(E_ALL);
require('../includes/db/mysql.php');

class installer extends padb_mysql {
    function send_query($query) {
        if (!mysql_query($query, $this->link)) {
            echo "<b>Error!</b> " . mysql_error();
            die();
        }
    }

    function get_prefix() {
        return $this->prefix;
    }
}
$db = new installer; // must be done to get added functions;


if (!isset($_GET['act'])) {
    printheader('Welcome');
    ?>
    <tr>
    <td colspan="2" width="100%">
    Welcome to the paFileDB 3.5 Installer. This script will guide you through
    the setup process. Please make sure you have upload all files as outlined
    in install_guide.html, and modified mysql.php with your mySQL settings. Once
    you have done all that, please click Continue below.
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><a href="./index.php?act=checkperms">Continue &raquo;</a></td></tr>
    <?php
} elseif ($_GET['act'] == "checkperms") {
    printheader('Check CHMOD');
    ?>
    <tr>
    <td colspan="2" width="100%">
    paFileDB is now testing file permissions. If no errors appear below,
    everything was a success! If there are errors, please visit
    <a href="http://www.phparena.net" target="_blank">PHP Arena</a> for more info
    or to open a support ticket.<p>&nbsp;</p>
    <?php
    $checkdirs = array("../skins/default/compile/");
    
    foreach ($checkdirs as $curdir)
    {
        $randfile = time() . "-" . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) . ".txt";
        $ofile = fopen($curdir . $randfile, "w");
        fwrite($ofile, $curdir . $randfile);
        fclose($ofile);
        $ofile = file($curdir . $randfile);
        if ($ofile[0] != $curdir . $randfile)
        {
            echo "{$curdir} is not writable or your host is incompatible with paFileDB file commands!";
            exit;
        }
        unlink($curdir . $randfile);
    }
    
    ?>
    Everything was a success! Please click Continue below to go onto the next step.
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><a href="./index.php?act=insert">Continue &raquo;</a></td></tr>
    <?php
} elseif ($_GET['act'] == "insert") {
    printheader('Setup Database');
    ?>
    <tr>
    <td colspan="2" width="100%">
    paFileDB is now setting up your mySQL database. If no errors appear below,
    everything was a success! If there are errors, please visit
    <a href="http://www.phparena.net" target="_blank">PHP Arena</a> for more info
    or to open a support ticket.<p>&nbsp;</p>
    <?php
    require("./read_dump.lib.php");
    $ofile = fopen("./install.sql", "r");
    $contents = fread($ofile, filesize("./install.sql"));
    fclose($ofile);
    $queries = array();
    PMA_splitSqlFile($queries, $contents, "thisdoesntmatter");
    foreach ($queries as $q) {
        $q['query'] =  str_replace("##PREFIX##", $db->get_prefix(), $q['query']);
        $db->send_query($q['query']);
    }
    ?>
    Everything was a success! Please click Continue below to go onto the next step.
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><a href="./index.php?act=settings">Continue &raquo;</a></td></tr>
    <?php
} elseif ($_GET['act'] == "settings") {
    printheader('Settings');
    ?>
    <tr>
    <td colspan="2" width="100%">
    There is only one setting you need to change immediatley to get up and running,
    and that is the URL to where paFileDB is installed. Please enter the URL below and click
    Continue. paFileDB guessed at the installation location, however, you need to verify its
    accuracy to continue. Do not add a trailing slash at the end.</td></tr>
    <?php
    $url = "http://{$_SERVER['HTTP_HOST']}:{$_SERVER['SERVER_PORT']}". $_SERVER['REQUEST_URI'];
    $url = str_replace(":80/", "/", $url);
    if (!(false === strpos($url, "/install/index.php")))
    {
        $url = substr($url, 0, strpos($url, "/install/index.php"));
    }

    ?>
    <tr><td width="50%">paFileDB URL:</td>
    <td width="50%">
    <form action="index.php?act=admin" method="post" name="form">
    <input type="text" size="50" name="url" value="<?php echo $url; ?>" />
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><input type="button" onclick="verify(this.form, 0);" value="Continue &raquo;" /></form></td></tr>
    <?php
} elseif ($_GET['act'] == "admin") {
    printheader('Setup Admin Account');

    // Remove the trailing slash for the dumbasses who can't read.
    $_POST['url'] = preg_replace("/(\/*)$/", "", $_POST['url']);
    $db->update('settings', array(array('dburl', $_POST['url'])));
    ?>
    <tr>
    <td colspan="2" width="100%">
    Now you need to create an administrator account. Please enter a username, password and e-mail address below
    to make your first admin account.</td></tr>
    <form action="index.php?act=finish" method="post" name="form">
    <tr><td width="50%">Username:</td><td width="50%"> <input type="text" name="uname" size="50" /><br /></td></tr>
    <tr><td width="50%">Password:</td><td width="50%"> <input type="password" name="pass" size="50" /><br /></td></tr>
    <tr><td width="50%">Confirm Password:</td><td width="50%"> <input type="password" name="cpass" size="50" /><br /></td></tr>
    <tr><td width="50%">E-mail:</td><td width="50%"> <input type="text" name="email" size="50" /><br /></td></tr>
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><input type="button" value="Continue &raquo;" onclick="verify(this.form, 1);" /></form></td></tr>
    <?php
} elseif ($_GET['act'] == "finish") {
    printheader('Finished!');
    $db->truncate('admin');
    $db->insert('admin', array(array('admin_username', $_POST['uname']), array('admin_password', md5($_POST['pass'])), array('admin_email', $_POST['email']), array('admin_status', 3)));
    ?>
    <tr>
    <td colspan="2" width="100%">
    You're finished installing paFileDB! In order to use paFileDB, <b>you must delete the "install" directory from your server!</b>
    <p align="left"><a href="index.php?act=delinstdir">Try to delete it now.</a></p>
    <p align="center"><a href="../index.php">Your paFileDB Home</a><br /><a href="../admin.php?act=settings">Your paFileDB Admin Center</a><br />It is recommended that you login to your admin center ASAP and change paFileDB's settings to suit your needs.</p>

    </td></tr>
    <?php
} elseif ($_GET['act'] == "delinstdir") {
printheader('Finished!');

if ($handle = opendir('./'))
{
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != "..")
        {
            unlink($file);
        }
    }

    closedir($handle);
}
rmdir("./");

if ($handle = opendir('../upgrade'))
{
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != "..")
        {
            unlink('../upgrade/' . $file);
        }
    }

    closedir($handle);
}
rmdir("../upgrade");

?>
<tr>
<td colspan="2" width="100%">
You're finished installing paFileDB!</b>
<p align="center"><a href="../index.php">Your paFileDB Home</a><br /><a href="../admin.php?act=settings">Your paFileDB Admin Center</a><br />It is recommended that you login to your admin center ASAP and change paFileDB's settings to suit your needs.</p>
</td></tr>
<?php
}

?>
</table>
</body></html>