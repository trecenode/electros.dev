<?php

/**
  * paFileDB 3.5
  *
  * This is the upgrader for paFileDB 3.5.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */


function printheader($header) {
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">    <html xmlns="http://www.w3.org/1999/xhtml">    <head>    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />    <title>paFileDB Upgrader</title>    <link href="../skins/default/style.css" rel="stylesheet" type="text/css" />
    <script language="javascript"> 		function verify(form, mail) { 			for (i=0; i<form.elements.length; i++ ) { 				form.elements[i].focus();				if ((form.elements[i].type=="text" || form.elements[i].type !== "textarea" || form.elements[i].type=="password") && form.elements[i].value == "") { 					alert("All fields are required. Please fill out all fields.");					return;				} 
				if (mail == 1) {
                    if (form.pass.value != form.cpass.value) {
                        alert("The two passwords you entered did not match. Please go back and try again.");
                        return;
                    }
                }			}
			
            everify(form, mail);
            		} 		function everify(form, mail) { 			if (mail == 1) {
                if (form.email.value == "" || form.email.value.indexOf('@') == -1 || form.email.value.indexOf('.') == -1 || 			form.email.value.length<6) {                     alert("The e-mail address you entered is not valid. Please enter a valid e-mail address.");                    form.email.focus();                    return;                }
			}
						form.submit();		} 	</script> 
    </head>        <body>    <table width="75%" border="1" align="center" cellpadding="3" cellspacing="0" class="border">      <tr>        <td class="header" width="50%">paFileDB Upgrader</td>
        <td width="50%" align="right"><span style="font-size:15px;"><?php echo($header); ?></span>      </tr>
    <?php
}
error_reporting(E_ALL);
require('../includes/db/mysql.php');
require('../includes/functions.php');

class upgrader extends padb_mysql {
    function send_query($query) {
        if (!mysql_query($query, $this->link)) {
            echo "<b>Error!</b> " . mysql_error();
            die();
        }
    }
    
    function get_prefix() {
        return $this->prefix;
    }
}
$db = new upgrader; // must be done to get added functions;

if (!isset($_GET['act'])) {
    printheader('Welcome');
    ?>
    <tr>
    <td colspan="2" width="100%">
    Welcome to the paFileDB 3.5.2 Upgrader. This script will guide you through
    the upgrade process. Please make sure you have upload all files as outlined
    in upgrade_guide.html, and modified mysql.php with your mySQL settings. Once
    you have done all that, please select the version of paFileDB you are upgrading from:
    <div align="center">
    <a href="index.php?act=db&version=3.1">3.1</a><br />
    <a href="index.php?act=db&version=3.5">3.5</a><br />
    <a href="index.php?act=db&version=3.5.2">3.5.1 <b>or</b> 3.5.2</a><br />
    </div>
    </td></tr>
    <?php
} elseif ($_GET['act'] == "db") {
    printheader('Setup Database');
    ?>
    <tr>
    <td colspan="2" width="100%">
    paFileDB is now modifying your mySQL database. If no errors appear below,
    everything was a success! If there are errors, please visit
    <a href="http://www.phparena.net" target="_blank">PHP Arena</a> for more info
    or to open a support ticket.</a><p>&nbsp;</p>
    <?php
    require("./read_dump.lib.php");
    $ofile = fopen("./".$_GET['version'].".sql", "r");
    $contents = fread($ofile, filesize("./".$_GET['version'].".sql"));
    fclose($ofile);
    $queries = array();
    PMA_splitSqlFile($queries, $contents, "thisdoesntmatter");
    foreach ($queries as $q) {
        $q['query'] =  str_replace("##PREFIX##", $db->get_prefix(), $q['query']);
        $db->send_query($q['query']);
    }
    if ($_GET['version'] == '3.1') {
        $license = $db->fetch(array(), 'license');
        foreach ($license as $l) {
            $db->update('license', array(array('license_text', base64_encode(str_replace('<br>', '<br />', $l['license_text'])))), array(array('license_id', '=', $l['license_id'])));
        }
        $db->update('files', array(array('file_rating', 0), array('file_totalvotes', 0)));
        $db->update('files', array(array('file_posticon', '')), array(array('file_posticon', '=', 'none')));
    }
    ?>
    Everything was a success! Please click Continue below to go onto the next step.
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><a href="./index.php?act=settings">Continue &raquo;</a></td></tr>
    <?php
} elseif ($_GET['act'] == "settings") {
    printheader('Settings');
    ?>
    <tr>
    <td colspan="2" width="100%">
    There is only one setting you need to change immediatley to get up and running,
    and that is the URL to where paFileDB is installed. Please enter the URL below and click
    Continue. paFileDB guessed at the installation location, however, you need to verify its
    accuracy to continue. Do not add a trailing slash at the end.</td></tr>
    <?php
    $url = "http://{$_SERVER['HTTP_HOST']}:{$_SERVER['SERVER_PORT']}". $_SERVER['REQUEST_URI'];
    $url = str_replace(":80/", "/", $url);
    if (!(false === strpos($url, "/upgrade/index.php")))
    {
        $url = substr($url, 0, strpos($url, "/upgrade/index.php"));
    }
    ?>
    <tr><td width="50%">paFileDB URL:</td>
    <td width="50%">
    <form action="index.php?act=finish" method="post" name="form">
    <input type="text" size="50" name="url" value="<?php echo $url; ?>" />
    </td></tr>
    <tr><td colspan="2" class="header" align="center"><input type="button" onclick="verify(this.form, 0);" value="Continue &raquo;" /></form></td></tr>
    <?php
} elseif ($_GET['act'] == "finish") {
    printheader('Finished!');
    $_POST['url'] = preg_replace("/(\/*)$/", "", $_POST['url']);
    $db->update('settings', array(array('dburl', $_POST['url']), array('date_format', xhtml_convert('%b %d, %Y')), array('time_format', xhtml_convert('%I:%M %p')), array('enable_email', 1), array('lang', 'english'), array('skin', 'default')));
    rebuildDrop();
    ?>
    <tr>
    <td colspan="2" width="100%">
    You're finished upgrading paFileDB! In order to use paFileDB, <b>you must delete the "upgrade" directory from your server!</b>
    <p align="left"><a href="index.php?act=delinstdir">Try to delete it now.</a></p>
    <p align="center"><a href="../index.php">Your paFileDB Home</a><br /><a href="../admin.php?act=settings">Your paFileDB Admin Center</a><br />It is recommended that you login to your admin center ASAP and change paFileDB's settings to suit your needs.</p>
    
    </td></tr>
    <?php
} elseif ($_GET['act'] == "delinstdir") {
    printheader('Finished!');
    

if ($handle = opendir('./'))
{
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != "..")
        {
            unlink($file);
        }
    }

    closedir($handle);
}
rmdir("./");

if ($handle = opendir('../install'))
{
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != "..")
        {
            unlink('../install/' . $file);
        }
    }

    closedir($handle);
}
rmdir("../install");

    ?>
    <tr>
    <td colspan="2" width="100%">
    You're finished upgrading paFileDB!</b>
    <p align="center"><a href="../index.php">Your paFileDB Home</a><br /><a href="../admin.php?act=settings">Your paFileDB Admin Center</a><br />It is recommended that you login to your admin center ASAP and change paFileDB's settings to suit your needs.</p>
    
    </td></tr>
    <?php
}
?>
</table>
</body></html>