ALTER TABLE `##PREFIX##settings` ADD `perpage` INT( 3 ) NOT NULL;
UPDATE `##PREFIX##settings` SET `perpage` = '20' WHERE `id` =1;
ALTER TABLE `##PREFIX##cat` ADD `cat_sort` VARCHAR( 25 ) NOT NULL;
UPDATE `##PREFIX##cat` SET `cat_sort` = 'time|desc';
ALTER TABLE `##PREFIX##files` ADD `file_mirrors` TEXT NOT NULL AFTER `file_dlurl`;
ALTER TABLE `##PREFIX##settings` ADD `enable_report` INT( 1 ) DEFAULT '1' NOT NULL;