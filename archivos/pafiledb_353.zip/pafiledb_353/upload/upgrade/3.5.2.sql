ALTER TABLE `##PREFIX##files` ADD `file_mirrors` TEXT NOT NULL AFTER `file_dlurl`;
ALTER TABLE `##PREFIX##settings` ADD `enable_report` INT( 1 ) DEFAULT '1' NOT NULL;