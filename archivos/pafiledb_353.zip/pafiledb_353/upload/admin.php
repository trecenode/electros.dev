<?php

/**
  * paFileDB 3.5
  *
  * This file is the main admin center file for paFileDB.
  * It's also very similar to index.php, as both files to similar things.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

if (file_exists('install')) { die("Please remove the install directory to use paFileDB!"); }
if (file_exists('upgrade')) { die("Please remove the upgrade directory to use paFileDB!"); }

//Start the execution timer
$starttime = microtime();	
$starttime = explode(" ",$starttime);
$starttime = $starttime[1] + $starttime[0];


//Require the important files so paFileDB isn't paUselessScript
require('./includes/smarty/Smarty.class.php');
require('./includes/functions.php');
require('./includes/db/mysql.php');

//Load paFileDB settings into $settings array
$settings = $db->fetch(array(), 'settings');
$version = '3.5.3';

//Get Smarty set up and load the right language file
$smarty = new Smarty();
$smarty->config_booleanize = false;
init_smarty($settings[0]['skin']);
$smarty->config_load('english.conf');
if ($settings[0]['lang'] != "english") { $smarty->config_load($settings[0]['lang'].'.conf'); }
$smarty->config_load('config.conf');
$smarty->assign('settings', $settings[0]);
require('./includes/admin/auth.php');

/*Get $act from the query string, set to main if $act is unset 
 (only time its unset is on the main page */
if (!$adminloggedin && @$_GET['act'] != 'resetadminpass') { $act = 'login'; }
else if (!$adminloggedin && $_GET['act'] == 'resetadminpass') { $act = 'resetadminpass'; }
else if ($adminloggedin && !isset($_GET['act'])) { $act = 'main'; }
else { $act = $_GET['act']; }

// If you want to allow the admin password recovery, please comment the following line:
if ($act == 'resetadminpass') { if (!$adminloggedin) { $act = 'login'; } else { $act = 'main'; } }

//This stops any l33t h4x0ring of paFileDB. Just an extra security measure
$allowed_acts = array('login', 'main', 'files', 'categories', 'license', 'custom', 'admins', 'settings', 'log', 'phpinfo', 'versioncheck', 'myoptions', 'rebuilddrop', 'resetadminpass');
if (!in_array($act, $allowed_acts))
{
    die("Invalid Action!");
}
if ($act == 'phpinfo') { define('PHP_INFO', true); }

$smarty->assign('act', $act);
$smarty->assign('version', $version);

//Require the file that actually does what we want
require('./includes/admin/'.$act.'.php');

//Display the header
$smarty->display('admin/header.tpl');

//Display the template for whatever page we're showing
$smarty->display('admin/'.$act.'.tpl');

//Calculate execution time
$endtime = microtime();
$endtime = explode(" ",$endtime);
$endtime = $endtime[1] + $endtime[0];
$stime = $endtime - $starttime;

//Send exec time and queries used to Smarty
$smarty->assign('debug_info', array(count($db->queries), round($stime,5)));

//Display the footer
$smarty->display('admin/footer.tpl');
?>