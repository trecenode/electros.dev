<?php

/**
  * paFileDB 3.5
  *
  * This file contains all the code for logging in and out
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

//If the user wants to logout, delete the cookies
if (isset($_GET['logout'])) { 
    setcookie('pafiledb_user', '', time()-31536000);
    setcookie('pafiledb_pass', '', time()-31536000);
    smarty_redirect(lang('acp_logout_redir'));
}

//Assign the Smarty navbar
$smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => lang('login'), 'url' => '?act=login')));
$smarty->assign('title', $settings[0]['dbname'].' &raquo; '.lang('login'));

//Process the login
if (isset($_GET['process'])) {
    $smarty->assign('logact', 'process');
    
    //Check the username and password to make sure they're correct
    $a = array();
    if (checkpass($_POST['username'], md5($_POST['password']), $a)) {
        
        //Set the cookies and redirect to the main page
        setcookie('pafiledb_user', $_POST['username']);
        setcookie('pafiledb_pass', md5($_POST['password']));
        smarty_redirect(lang('acp_login_redir').' '.$_POST['username'], 'admin.php'.$_POST['qs']);
    } else {
        
        //Password is wrong, give them an error.
        smarty_error(lang('loginerr'));
        $adminloggedin = false;
    }
} else {
    if (!empty($_SERVER['QUERY_STRING'])) {
        $smarty->assign('qs', "?".$_SERVER['QUERY_STRING']);
    } else {
        $smarty->assign('qs', '?act=main');
    }
}

?>