<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for viewing the e-mail log
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

checkaccess(2);

if (isset($_GET['view'])) { //Fetch from DB for detailed view
    $l = $db->fetch(array(), 'emaillog', array(array('e_id', '=', $_GET['id'])));
    $smarty->assign('v', 1);
    $smarty->assign('l', $l[0]);
} elseif (isset($_GET['delete'])) { //Delete from DB
    $db->deldata('emaillog', array(array('e_id', '=', $_GET['id'])));
    smarty_redirect(lang('acp_del_e_redir'), 'admin.php?act=log');
} else { //Fetch from DB for list view
    $l = $db->fetch(array(), 'emaillog', '', 'e_date', 'DESC');
    $smarty->assign('logs', $l);
}
?>