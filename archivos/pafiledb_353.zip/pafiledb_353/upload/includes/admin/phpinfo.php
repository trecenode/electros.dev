<?php

/**
  * paFileDB 3.5
  *
  * This file runs phpinfo(); for the admin center.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

checkaccess(2);

if (defined('PHP_INFO')) { phpinfo(); }
exit();

//I wish all PHP files were that easy to write
?>