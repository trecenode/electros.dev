<?php

/**
  * paFileDB 3.5
  *
  * This file checks if paFileDB is up to date or not.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

if (isset($_GET['do'])) {
    rebuildDrop();
    smarty_redirect(lang('rebuild_drop_redir'), 'admin.php');
}

?>