<?php

/**
  * paFileDB 3.5
  *
  * This file resets the admin password.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

$security = array();

if (file_exists('./reset.txt') && filesize('./reset.txt') > 0)
{
    $security = file('./reset.txt');
}
else
{
    $security = array(0 => '');
}

// Simple security precaution
if (!class_exists('padb_mysql') && !class_exists('padb_mysqli'))
{
    echo 'No soup for you!';exit;
}

$real   = array();
$real[] = $_SERVER["SERVER_SOFTWARE"];
$real[] = $_SERVER["SERVER_NAME"];
$real[] = $_SERVER["SERVER_ADDR"];
$real[] = $_SERVER["SERVER_PORT"];
$real[] = $_SERVER["REMOTE_ADDR"];
$real[] = $_SERVER["DOCUMENT_ROOT"];
$real   = md5($version . "|" . date('l dS \of F Y') . "|" . md5(implode("|", $real)));

if ($security[0] != $real)
{
    echo "Please create a file called reset.txt in the paFileDB install directory with only the following text:<br /><br />\r\n";
    echo $real;
    exit;
}

if ($_GET['time'] - time() < 300 && $_GET['code'] == md5($_GET['time'] . $real))
{
    $results = $db->fetch(array('admin_id', 'admin_username'), 'admin', array(array('admin_status', '=', '3')), 'admin_id', 'ASC');
    if (count($results) > 0)
    {
        $db->update('admin', array(array('admin_password', md5('admin'))), array(array('admin_id', '=', $results[0]['admin_id'])));
        echo "Username: ".$results[0]['admin_username']."<br />\r\nPassword: admin";
        exit;
    }
    else
    {
        // No Admin Users
        $db->insert('admin', array(array('admin_username', 'admin'), array('admin_password', md5('admin')), array('admin_email', 'noreply@hotmail.com'), array('admin_status', 3)));
        echo "Username: admin<br />\r\nPassword: admin";
        exit;
    }
}
else
{
    echo "<a href='admin.php?act=resetadminpass&amp;time=".time()."&amp;code=".md5(time() . $real)."'>Reset!</a>";
    exit;
}

?>