<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for managing files
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */


$smarty->assign('f', $_GET['f']);
if ($_GET['f'] == 'add'){
    if (isset($_GET['process'])) {
        
        //Check...........
        if (!check_input($_POST, array('creator', 'version', 'ss', 'documentation', 'upfile', 'posticon', 'license', 'pin', 'mirrors'))) {
            smarty_error(lang('emptyfield'));
        }
        
        if (!empty($_FILES['upfile']['name'])) {
            if (!move_uploaded_file($_FILES['upfile']['tmp_name'], 'uploads/'.$_FILES['upfile']['name'])) {
                smarty_error(lang('upload_err').' <b>PHP Error Code: '.$_FILES['upfile']['error'].'</b>');
            } else {
                @chmod('uploads/'.$_FILES['upfile']['name'], 0666);
                $_POST['dlurl'] = $settings[0]['dburl'].'/uploads/'.$_FILES['upfile']['name'];
            }
        }
        if (!empty($_FILES['ssfile']['name'])) {
            if (!move_uploaded_file($_FILES['ssfile']['tmp_name'], 'uploads/'.$_FILES['ssfile']['name'])) {
                smarty_error(lang('upload_err').' <b>PHP Error Code: '.$_FILES['ssfile']['error'].'</b>');
            } else {
                @chmod('uploads/'.$_FILES['ssfile']['name'], 0666);
                $_POST['ss'] = $settings[0]['dburl'].'/uploads/'.$_FILES['ssfile']['name'];
            }
        }
        $_POST['mirrors'] = trim($_POST['mirrors']);
        if (!empty($_POST['mirrors'])) {
            $mirror_array = array();
            $mirrors = str_replace("\r", "", $_POST['mirrors']);
            $mirrors = explode("\n", $mirrors);
            foreach ($mirrors as $m) {
                $mirror = explode("|", $m);
                $mirror_array[] = array("name" => xhtml_convert($mirror[0]), "url" => $mirror[1]);
            }
        } else {
            $mirror_array = "";
        }
        
       $newID = $db->insert('files', array(array('file_name', xhtml_convert($_POST['name'])),
                                  array('file_desc', xhtml_convert($_POST['sdesc'])),
                                  array('file_creator', xhtml_convert($_POST['creator'])),
                                  array('file_version', ',,force_as_string,,'.xhtml_convert($_POST['version'])),
                                  array('file_longdesc', xhtml_convert($_POST['ldesc'])),
                                  array('file_ssurl', $_POST['ss']),
                                  array('file_dlurl', $_POST['dlurl']),
                                  array('file_time', time()),
                                  array('file_mirrors', serialize($mirror_array)),
                                  array('file_catid', $_POST['cat']),
                                  array('file_posticon', $_POST['posticon']),
                                  array('file_license', $_POST['license']),
                                  array('file_dls', 0),
                                  array('file_last', ''),
                                  array('file_pin', $_POST['pin']),
                                  array('file_docsurl', $_POST['documentation']),
                                  array('file_rating', 0),
                                  array('file_totalvotes', 0)));
        $db->update('cat', array(array('cat_files', '++1++')), array(array('cat_id', '=', $_POST['cat'])));
        $fcat = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_POST['cat'])));
        if ($fcat[0]['cat_parent'] > 0) {
            $db->update('cat', array(array('cat_files', '++1++')), array(array('cat_id', '=', $fcat[0]['cat_parent'])));
        }
        
        foreach ($_POST['custom'] as $k => $v) {
            $v = trim($v);
            if (!empty($v)) {
                $db->insert('customdata', array(array('customdata_file', $newID),
                                                array('customdata_custom', $k),
                                                array('data', xhtml_convert($v))));
            }
        }
        
        smarty_redirect(lang('acp_add_f_redir'), 'admin.php?act=files&f');
    
    } else{
        
        //Setup the category selection menu
        $c_id = array(); $c_name = array();
        $a = unserialize($settings[0]['dropdown']);
        foreach ($a as $b) {
            if ($b['sub']) {
                $c_id[] = $b['id'];
                $c_name[] = "--".$b['name'];
            } else {
                $c_id[] = $b['id'];
                $c_name[] = $b['name'];
            }
        }
        
        if (count($c_id) == 0) {
            smarty_error(lang('no_cat'));
        }
        $smarty->assign('c_id', $c_id);
        $smarty->assign('c_name', $c_name);
        $icons = get_file_list('posticons', 'f', false);
        $icon_name = array(); $icon_img = array();
        $icon_name[] = "";
        $icon_img[] = lang('none');
        foreach ($icons as $i) {
            $icon_name[] = $i;
            $icon_img[] = '<img src="posticons/'.$i.'" alt="" />';
        }
        $smarty->assign('i_name', $icon_name);
        $smarty->assign('i_img', $icon_img);
        
        $license = $db->fetch(array(), 'license');
        $l_id = array(); $l_id = array();
        $l_id[] = 0; $l_name[] = lang('none');
        foreach ($license as $l) {
            $l_id[] = $l['license_id']; $l_name[] = $l['license_name'];
        }
        $fields = $db->fetch(array(), 'custom');
        $smarty->assign('fields', $fields);
        $smarty->assign('l_id', $l_id);
        $smarty->assign('l_name', $l_name);
        $smarty->assign('yesno', array(lang('yes'), lang('no')));
        $smarty->assign('zeroone', array(1, 0));
    
    }
} elseif ($_GET['f'] == 'edit') {
    if (isset($_GET['process'])) {
        
        //Check again...........
        if (!check_input($_POST, array('creator', 'version', 'ss', 'documentation', 'upfile', 'posticon', 'license', 'pin', 'reset_downloads', 'reset_rating', 'reset_date', 'oldcat', 'mirrors'))) {
            smarty_error(lang('emptyfield'));
        }
        
        if (!empty($_FILES['upfile']['name'])) {
            if (!move_uploaded_file($_FILES['upfile']['tmp_name'], 'uploads/'.$_FILES['upfile']['name'])) {
                smarty_error(lang('upload_err').' <b>PHP Error Code: '.$_FILES['upfile']['error'].'</b>');
            } else {
                @chmod('uploads/'.$_FILES['upfile']['name'], 0666);
                $_POST['dlurl'] = $settings[0]['dburl'].'/uploads/'.$_FILES['upfile']['name'];
            }
        }
        if (!empty($_FILES['ssfile']['name'])) {
            if (!move_uploaded_file($_FILES['ssfile']['tmp_name'], 'uploads/'.$_FILES['ssfile']['name'])) {
                smarty_error(lang('upload_err').' <b>PHP Error Code: '.$_FILES['ssfile']['error'].'</b>');
            } else {
                @chmod('uploads/'.$_FILES['ssfile']['name'], 0666);
                $_POST['ss'] = $settings[0]['dburl'].'/uploads/'.$_FILES['ssfile']['name'];
            }
        }
        $_POST['mirrors'] = trim($_POST['mirrors']);
        if (!empty($_POST['mirrors'])) {
            $mirror_array = array();
            $mirrors = str_replace("\r", "", $_POST['mirrors']);
            $mirrors = explode("\n", $mirrors);
            foreach ($mirrors as $m) {
                $mirror = explode("|", $m);
                $mirror_array[] = array("name" => xhtml_convert($mirror[0]), "url" => $mirror[1]);
            }
        } else {
            $mirror_array = "";
        }
        $updateArray = array(array('file_name', xhtml_convert($_POST['name'])),
                             array('file_desc', xhtml_convert($_POST['sdesc'])),
                             array('file_creator', xhtml_convert($_POST['creator'])),
                             array('file_version', ',,force_as_string,,'.xhtml_convert($_POST['version'])),
                             array('file_longdesc', xhtml_convert($_POST['ldesc'])),
                             array('file_ssurl', $_POST['ss']),
                             array('file_dlurl', $_POST['dlurl']),
                             array('file_catid', $_POST['cat']),
                             array('file_mirrors', serialize($mirror_array)),
                             array('file_posticon', $_POST['posticon']),
                             array('file_license', $_POST['license']),
                             array('file_pin', $_POST['pin']),
                             array('file_docsurl', $_POST['documentation']));
        if ($_POST['reset_downloads'] == 1) {
            $updateArray[] = array('file_dls', 0);
        }
        if ($_POST['reset_date'] == 1) {
            $updateArray[] = array('file_time', time());
            $updateArray[] = array('file_last', time());
        }
        if ($_POST['reset_rating'] == 1) {
            $updateArray[] = array('file_rating', 0);
            $updateArray[] = array('file_totalvotes', 0);
        }
        $db->update('files', $updateArray , array(array('file_id', '=', $_GET['id'])));
        if ($_POST['cat'] != $_POST['oldcat']) {
            $old = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_POST['oldcat'])));
            $new = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_POST['cat'])));
            
            $db->update('cat', array(array('cat_files', '++1++')), array(array('cat_id', '=', $_POST['cat'])));
            if ($new[0]['cat_parent'] > 0) {
                $db->update('cat', array(array('cat_files', '++1++')), array(array('cat_id', '=', $new[0]['cat_parent'])));
            }
            
            $db->update('cat', array(array('cat_files', '--1--')), array(array('cat_id', '=', $_POST['oldcat'])));
            if ($old[0]['cat_parent'] > 0) {
                $db->update('cat', array(array('cat_files', '--1--')), array(array('cat_id', '=', $old[0]['cat_parent'])));
            }
        }
        $db->deldata('customdata', array(array('customdata_file', '=', $_GET['id'])));
        foreach ($_POST['custom'] as $k => $v) {
            $v = trim($v);
            if (!empty($v)) {
                $db->insert('customdata', array(array('customdata_file', $_GET['id']),
                                                array('customdata_custom', $k),
                                                array('data', xhtml_convert($v))));
            }
        }
        
        smarty_redirect(lang('acp_edit_f_redir'), 'admin.php?act=files&f');
    } else {
    
        //Setup category menu and other template junk
        $file = $db->fetch(array(), 'files', array(array('file_id', '=', $_GET['id'])));
        $c_id = array(); $c_name = array();
        $a = unserialize($settings[0]['dropdown']);
        foreach ($a as $b) {
            if ($b['sub']) {
                $c_id[] = $b['id'];
                $c_name[] = "--".$b['name'];
            } else {
                $c_id[] = $b['id'];
                $c_name[] = $b['name'];
            }
        }
        $smarty->assign('c_id', $c_id);
        $smarty->assign('c_name', $c_name);
        $file[0]['file_longdesc'] = str_replace('<br />', "\n", $file[0]['file_longdesc']);
        $smarty->assign('target', $file[0]);
        $icons = get_file_list('posticons', 'f', false);
        $icon_name = array(); $icon_img = array();
        $icon_name[] = "";
        $icon_img[] = lang('none');
        foreach ($icons as $i) {
            $icon_name[] = $i;
            $icon_img[] = '<img src="posticons/'.$i.'" alt="" />';
        }
        $smarty->assign('i_name', $icon_name);
        $smarty->assign('i_img', $icon_img);
        
        $license = $db->fetch(array(), 'license');
        $l_id = array(); $l_id = array();
        $l_id[] = 0; $l_name[] = lang('none');
        foreach ($license as $l) {
            $l_id[] = $l['license_id']; $l_name[] = $l['license_name'];
        }
        $fields = $db->fetch(array(), 'custom');
        foreach($fields as $k => $v) {
            $data = $db->fetch(array(), 'customdata', array(array('customdata_custom', '=', $fields[$k]['custom_id']), array('customdata_file', '=', $_GET['id'])));
            @$fields[$k]['data'] = $data[0]['data'];
        }
        $mirrors = unserialize($file[0]['file_mirrors']);
        $mirror_list = "";
        if (is_array($mirrors)) {
            foreach ($mirrors as $m) {
                if (!empty($m['name'])) {
                    $mirror_list .= $m['name']."|".$m['url']."\r\n";
                }
            }
        }
        $smarty->assign('mirror_list', $mirror_list);
        $smarty->assign('fields', $fields);
        $smarty->assign('l_id', $l_id);
        $smarty->assign('l_name', $l_name);
        $smarty->assign('yesno', array(lang('yes'), lang('no')));
        $smarty->assign('zeroone', array(1, 0));
    }

} elseif ($_GET['f'] == 'delete') {

    $oldcat = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_GET['cat'])));
    if ($oldcat[0]['cat_parent'] > 0) {
        $db->update('cat', array(array('cat_files', '--1--')), array(array('cat_id', '=', $oldcat[0]['cat_parent'])));
    }
    $db->update('cat', array(array('cat_files', '--1--')), array(array('cat_id', '=', $_GET['cat'])));
    $db->deldata('files', array(array('file_id', '=', $_GET['id'])));
    $db->deldata('customdata', array(array('customdata_file', '=', $_GET['id'])));
    
    smarty_redirect(lang('acp_del_f_redir'), 'admin.php?act=files&f');
} else {
    
    
    if (!isset($_GET['start'])) { $start = 0; } else { $start = intval($_GET['start']); }
    $files = $db->fetch(array(), 'files');
    list($f, $pages) = paginate($files, $start, 20);
    $smarty->assign('files', $f);
    $smarty->assign('count', count($files));
    $smarty->assign('pages', $pages);
}
?>