<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for displaying the main
  * admin page.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

//This file serves no purpose. Everything is done in the template file


?>