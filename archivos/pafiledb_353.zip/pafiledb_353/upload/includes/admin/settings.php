<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for changing the settings.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

checkaccess(2);

if (isset($_GET['process'])) {
    if (!check_input($_POST, array('topnumber', 'timeoffset', 'viewall', 'showss', 'stats', 'enable_email', 'enable_report'))) {
        smarty_error(lang('emptyfield'));
    }
    
    $_POST['dburl'] = preg_replace("/(\/*)$/", "", $_POST['dburl']);
    
    //Update the DB
    $db->update('settings', array(array('skin', $_POST['skin']),
                                  array('lang', $_POST['lang']),
                                  array('dbname', xhtml_convert($_POST['dbname'])),
                                  array('dburl', $_POST['dburl']),
                                  array('topnumber', $_POST['topnumber']),
                                  array('homeurl', xhtml_convert($_POST['homeurl'])),
                                  array('timeoffset', $_POST['timeoffset']),
                                  array('timezone', xhtml_convert($_POST['timezone'])),
                                  array('viewall', $_POST['viewall']),
                                  array('showss', $_POST['showss']),
                                  array('stats', $_POST['stats']),
                                  array('enable_email', $_POST['enable_email']),
                                  array('enable_report', $_POST['enable_report']),
                                  array('perpage', $_POST['perpage']),
                                  array('date_format', xhtml_convert($_POST['date_format'])),
                                  array('time_format', xhtml_convert($_POST['time_format']))));
    smarty_redirect(lang('acp_settings_redir'), 'admin.php?act=main');
} else {
    
    //Send stuff to Smarty
    $smarty->assign('skins', get_file_list('./skins', 'd'));
    $smarty->assign('langs', get_file_list('./lang', 'f', true));
    $smarty->assign('yesno', array(lang('yes'), lang('no')));
    $smarty->assign('zeroone', array(1, 0));

}

?>