<?php

/**
  * paFileDB 3.5
  *
  * This file checks if paFileDB is up to date or not.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

$new_version = file('http://www.phparena.net/versioncheck.php?s=pafiledb');
$new_version = $new_version[0];
$smarty->assign('new_version', $new_version);
?>