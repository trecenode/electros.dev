<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for changing user options.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */


if (isset($_GET['process'])) {

    //Check input *yawn*
    if (!check_input($_POST, array('new_password', 'new_confirm', 'current_password'))) {
        smarty_error(lang('emptyfield'));
    }
    
    
    //Check e-mail address *yawn*
    if (!eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$', $_POST['email'])) {
        smarty_error(lang('emailinvalid'));
    }
    
    if(md5($_POST['current_password']) != $admininfo[0]['admin_password']) {
        smarty_error(lang('wrongpass'));
    }
    
    if ($_POST['new_password'] != $_POST['new_confirm']) {
        smarty_error(lang('nomatch'));
    }
    
    $updates = array(array('admin_email', $_POST['email']));
    if (!empty($_POST['new_password'])) {
        $updates [] = array('admin_password', md5($_POST['new_password']));
        setcookie('pafiledb_pass', md5($_POST['new_password']));
    }
    
    //Update DB *yawn*
    $db->update('admin', $updates, array(array('admin_id', '=', $admininfo[0]['admin_id'])));
    smarty_redirect(lang('myoptions_redir'), 'admin.php');
    
} else {
    $me = $db->fetch(array(), 'admin', array(array('admin_id', '=', $admininfo[0]['admin_id'])));
    $smarty->assign('me', $me[0]);
}
?>