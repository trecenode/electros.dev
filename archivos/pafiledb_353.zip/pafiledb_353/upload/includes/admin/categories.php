<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for managing the
  * categories in the admin center.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.1
  * Copyright 2005 PHP Arena
  */


$smarty->assign('c', $_GET['c']);
if ($_GET['c'] == 'add'){
    if (isset($_GET['process'])) { //Add to DB
        
        //Make sure the input is valid
        if (!check_input($_POST, array('desc', 'order', 'parent'))) {
            smarty_error(lang('emptyfield'));
        }
        $name = xhtml_convert($_POST['name']);
        $desc = xhtml_convert($_POST['desc']);
        $db->insert('cat', array(array('cat_name', $name),
                                 array('cat_desc', $desc),
                                 array('cat_files', 0),
                                 array('cat_sort', $_POST['sort'].'|'.$_POST['sorder']),
                                 array('cat_parent', $_POST['parent']),
                                 array('cat_order', $_POST['order']))); 
        rebuildDrop();
        smarty_redirect(lang('acp_add_c_redir'), 'admin.php?act=categories&c');
    
    }
    $cats = $db->fetch(array(), 'cat', array(array('cat_parent', '=', 0)), 'cat_order', 'ASC');
    $cat_id = array(); $cat_name = array();
    $cat_id[] = 0; $cat_name[] = lang('none');
    foreach ($cats as $c) {
        $cat_id[] = $c['cat_id'];
        $cat_name[] = $c['cat_name'];
    }
    $smarty->assign('cat_id', $cat_id);
    $smarty->assign('cat_name', $cat_name);
    $smarty->assign('sort_val', array('name', 'dls', 'time'));
    $smarty->assign('sort_name', array(lang('name'), lang('downloads'), lang('date_added')));
    $smarty->assign('order_val', array('DESC', 'ASC'));
    $smarty->assign('order_name', array(lang('descending'), lang('ascending')));

} elseif ($_GET['c'] == 'edit') { //Edit category
    if (isset($_GET['process'])) {
        if (!check_input($_POST, array('desc', 'order', 'parent'))) {
            smarty_error(lang('emptyfield'));
        }
        $name = xhtml_convert($_POST['name']);
        $desc = xhtml_convert($_POST['desc']);
        $db->update('cat', array(array('cat_name', $name),
                                 array('cat_desc', $desc),
                                 array('cat_sort', $_POST['sort'].'|'.$_POST['sorder']),
                                 array('cat_parent', $_POST['parent']),
                                 array('cat_order', $_POST['order'])),
                           array(array('cat_id', '=', $_GET['id']))); 
        rebuildDrop();
        
        smarty_redirect(lang('acp_edit_c_redir'), 'admin.php?act=categories&c');
    } else {
        $category = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_GET['id'])));
        $cats = $db->fetch(array(), 'cat', array(array('cat_parent', '=', 0)), 'cat_order', 'ASC');
        $cat_id = array(); $cat_name = array();
        $cat_id[] = 0; $cat_name[] = lang('none');
        foreach ($cats as $c) {
            $cat_id[] = $c['cat_id'];
            $cat_name[] = $c['cat_name'];
        }
        $sortstuff = explode('|', $category[0]['cat_sort']);
        $smarty->assign('sort', $sortstuff[0]);
        $smarty->assign('order', $sortstuff[1]);
        $smarty->assign('sort_val', array('name', 'dls', 'time'));
        $smarty->assign('sort_name', array(lang('name'), lang('downloads'), lang('date_added')));
        $smarty->assign('order_val', array('DESC', 'ASC'));
        $smarty->assign('order_name', array(lang('descending'), lang('ascending')));
        $smarty->assign('cat_id', $cat_id);
        $smarty->assign('cat_name', $cat_name);
        $smarty->assign('target', $category[0]);
    }

} elseif ($_GET['c'] == 'delete') { //Delete category
    $cat = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_GET['id'])));
    if ($cat[0]['cat_parent'] > 0) {
        $db->update('cat', array(array('cat_files', '--'.$cat[0]['cat_files'].'--')), array(array('cat_id', '=', $cat[0]['cat_parent'])));
    }
    $db->deldata('cat', array(array('cat_id', '=', $_GET['id'])));
    $db->update('cat', array(array('cat_parent', 0)), array(array('cat_parent', '=', $_GET['id'])));
    $db->update('files', array(array('file_catid', 0)), array(array('file_catid', '=', $_GET['id'])));
    rebuildDrop();
    smarty_redirect(lang('acp_del_c_redir'), 'admin.php?act=categories&c');
} else {
    if ($_GET['c'] == 'recount') { //Recount, Florida style!
        $total = 0;
        $files = $db->fetch(array(), 'files', array(array('file_catid', '=', $_GET['id'])));
        $total += count($files);
        $children = $db->fetch(array(), 'cat', array(array('cat_parent', '=', $_GET['id'])));
        foreach ($children as $c) {
            $files = $db->fetch(array(), 'files', array(array('file_catid', '=', $c['cat_id'])));
            $total += count($files);
        }
        $db->update('cat', array(array('cat_files', $total)), array(array('cat_id', '=', $_GET['id'])));
    }
    $categories = array();
    if (!empty($settings[0]['dropdown'])) {
        $a = unserialize($settings[0]['dropdown']);
        foreach ($a as $b) {
            if ($b['sub']) {
                $categories[] = array('cat_id' => $b['id'], 'cat_name' => $b['name'], 'sub' => true);
            } else {
                $categories[] = array('cat_id' => $b['id'], 'cat_name' => $b['name'], 'sub' => false);
            }
        }
    }
    $smarty->assign('categories', $categories);
}
?>