<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for managing admins.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

checkaccess(3);

$smarty->assign('a', $_GET['a']);

if ($_GET['a'] == 'add') {
    if (isset($_GET['process'])) { //Add admin to DB
    
        //Check input *yawn*
        if (!check_input($_POST)) {
            smarty_error(lang('emptyfield'));
        }
        
        
        //Check e-mail address *yawn*
        if (!eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$', $_POST['email'])) {
            smarty_error(lang('emailinvalid'));
        }
        
        //Check username for invalid characters *yawn*
        if (!preg_match('/^([A-Za-z0-9 ]{1,})$/', $_POST['uname'])) {
            smarty_error(lang('invalidchars'));
        }
        
        //Make sure username doesn't exist *yawn*
        $a = $db->fetch(array(), 'admin', array(array('admin_username', '=', $_POST['uname'])));
        if (count($a) > 0) {
            smarty_error(lang('usernametaken'));
        }
        
        //Insert to DB *yawn*
        $db->insert('admin', array(array('admin_username', $_POST['uname']),
                                   array('admin_email', $_POST['email']),
                                   array('admin_password', md5($_POST['password'])),
                                   array('admin_status', $_POST['status'])));
        smarty_redirect(lang('acp_add_a_redir'), 'admin.php?act=admins&a');
        
        
    } else {
        $stat_id = array(1,2,3);
        $stat_name = array(lang('moderator'), lang('administrator'), lang('super_administrator'));
        $smarty->assign('stat_id', $stat_id);
        $smarty->assign('stat_name', $stat_name);
    }
} elseif ($_GET['a'] == 'edit') { 
    //To prevent issues, admins cant edit themselves via ACP, gotta use my options
    if ($admininfo[0]['admin_id'] == $_GET['id']) { smarty_error(lang('edit_self')); }
    if (isset($_GET['process'])) {
    
        //Not going to bother commenting next few lines
        if (!check_input($_POST, array('password'))) {
            smarty_error(lang('emptyfield'));
        }
        if (!eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$', $_POST['email'])) {
            smarty_error(lang('emailinvalid'));
        }
        if (!preg_match('/^([A-Za-z0-9 ]{1,})$/', $_POST['uname'])) {
            smarty_error(lang('invalidchars'));
        }
        if ($_POST['oldname'] != $_POST['uname']) {
            $a = $db->fetch(array(), 'admin', array(array('admin_username', '=', $_POST['uname'])));
            if (count($a) > 0) {
                smarty_error(lang('usernametaken'));
            }
        }
        
        $pass = trim($_POST['password']);
        
        $updates = array();
        $updates[] = array('admin_username', $_POST['uname']);
        $updates[] = array('admin_email', $_POST['email']);
        $updates[] = array('admin_status', $_POST['status']);
        if (!empty($pass)) { $updates[] = array('admin_password', md5($pass)); }
        
        $db->update('admin', $updates, array(array('admin_id', '=', $_GET['id'])));
        smarty_redirect(lang('acp_edit_a_redir'), 'admin.php?act=admins&a');
    } else {
        $stat_id = array(1,2,3);
        $stat_name = array(lang('moderator'), lang('administrator'), lang('super_administrator'));
        $smarty->assign('stat_id', $stat_id);
        $smarty->assign('stat_name', $stat_name);
        $a = $db->fetch(array(), 'admin', array(array('admin_id', '=', $_GET['id'])));
        $smarty->assign('target', $a[0]);
    }
} elseif ($_GET['a'] == 'delete') {
    //Can't delete yourself. 
    if ($admininfo[0]['admin_id'] == $_GET['id']) { smarty_error(lang('delete_self')); }
    
    //Delete from DB
    $db->deldata('admin', array(array('admin_id', '=', $_GET['id'])));
    smarty_redirect(lang('acp_del_a_redir'), 'admin.php?act=admins&a');
} else {
    $admins = $db->fetch(array(), 'admin');
    $smarty->assign('admins', $admins);
}

?>