<?php

/**
  * paFileDB 3.5
  *
  * This is the authentication file for the paFileDB Admin CP . It contains
  * routines for authenticating users and reading cookies
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

/**
  * This function checks the database to see if a user with the
  * given username and password combination exists. Returns true
  * or false.
  *
  * Parameters:
  *    $username: The username you are checking
  *    $password: The string that you want to check, should be MD5 encrypted
  *    $u: Optional, but if the username and password are correct,
  *       the member's info will be placed into this array.
  *
  */      
function checkpass($username, $password, &$u)
{
    global $db;
    
    //Run the query and put the resulting array in the $u array
    $u = $db->fetch(array(), 'admin', array(array('admin_username', '=', $username), array('admin_password', '=', $password)));
    
    /* Count the elements in $u. If the result is 0, no username exists with that
    password, so return false. Otherwise, it will be 1, which means the username
    and password combo exists, so you guessed it, return true. */
    if (count($u) == 0) { return false; }
    else { return true; }
}


/**
  * checkaccess() will check if the user can access the section
  * of the admin center, and will error out if not.
  *
  * Parameters:
  *  $level: The minimum user level required for access,
  *    1 for moderator, 2 for admin, 3 for uber admin
  *
  */
function checkaccess($level) {
    global $admininfo;
    if ($admininfo[0]['admin_status'] < $level) {
        smarty_error(lang('perm_denied'));
    }
}

if (isset($_COOKIE['pafiledb_user']) && isset($_COOKIE['pafiledb_pass'])) { //If the cookie exists, do all this:
    
    $admininfo = array();
    if (checkpass($_COOKIE['pafiledb_user'], $_COOKIE['pafiledb_pass'], $admininfo)) {
        //checkpass() returned true, so the user exists
        
        //$adminloggedin is a var used throughout the script to see if someone's logged in.
        $adminloggedin = true;
        $smarty->assign('admininfo', $admininfo[0]);
        
    } else { //The cookie exists, but the user/pass don't match
        
        //set $adminloggedin to false and trash the cookie so they're recognized as a guest
        $adminloggedin = false;
        setcookie('pafiledb_user', '', time()-3600);
        setcookie('pafiledb_pass', '', time()-3600);
    }
} else {
    $adminloggedin = false;
}

$smarty->assign('adminloggedin', $adminloggedin); //Send the stuff to Smarty

?>