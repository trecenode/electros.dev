<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for managing the
  * custom data fields in the admin center.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

checkaccess(2);

$smarty->assign('c', $_GET['c']);
if ($_GET['c'] == 'add'){
    if (isset($_GET['process'])) { //Add to DB
        
        //Make sure the input is valid
        if (!check_input($_POST)) {
            smarty_error(lang('emptyfield'));
        }
        $db->insert('custom', array(array('custom_name', xhtml_convert($_POST['name'])),
                                    array('custom_description', xhtml_convert($_POST['desc']))));
        smarty_redirect(lang('acp_add_cu_redir'), 'admin.php?act=custom&c');
    
    }

} elseif ($_GET['c'] == 'edit') { //Edit field
    if (isset($_GET['process'])) {
        if (!check_input($_POST)) {
            smarty_error(lang('emptyfield'));
        }
        $db->update('custom', array(array('custom_name', xhtml_convert($_POST['name'])),
                                    array('custom_description', xhtml_convert($_POST['desc']))),
                             array(array('custom_id', '=', $_GET['id']))); 
        
        smarty_redirect(lang('acp_edit_cu_redir'), 'admin.php?act=custom&c');
    } else {
        $field = $db->fetch(array(), 'custom', array(array('custom_id', '=', $_GET['id'])));
        $smarty->assign('target', $field[0]);
    }

} elseif ($_GET['c'] == 'delete') { //Delete field

    $db->deldata('custom', array(array('custom_id', '=', $_GET['id'])));
    $db->deldata('customdata', array(array('customdata_custom', '=', $_GET['id'])));
    smarty_redirect(lang('acp_delete_cu_redir'), 'admin.php?act=custom&c');
} else {
    $fields = $db->fetch(array(), 'custom');
    $smarty->assign('fields', $fields);
}
?>