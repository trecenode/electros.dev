<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for managing licenses
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

checkaccess(2);

$smarty->assign('l', $_GET['l']);
if ($_GET['l'] == 'add'){
    if (isset($_GET['process'])) {
        
        //Check...........
        if (!check_input($_POST)) {
            smarty_error(lang('emptyfield'));
        }
        $_POST['text'] = str_replace("\n", "<br />", $_POST['text']);
        $db->insert('license', array(array('license_name', xhtml_convert($_POST['name'])),
                                     array('license_text', base64_encode($_POST['text']))));
                                     
        smarty_redirect(lang('acp_add_l_redir'), 'admin.php?act=license&l');
    }
} elseif ($_GET['l'] == 'edit') {
    if (isset($_GET['process'])) {
        
        //Check again...........
        if (!check_input($_POST)) {
            smarty_error(lang('emptyfield'));
        }
        
        $_POST['text'] = str_replace("\n", "<br />", $_POST['text']);
        $ltext = str_replace("&lt;", "<", $_POST['text']);
        $ltext = str_replace("&gt;", ">", $ltext);
        $db->update('license', array(array('license_name', xhtml_convert($_POST['name'])),
                                     array('license_text', base64_encode($ltext))),
                               array(array('license_id', '=', $_GET['id'])));
        
        smarty_redirect(lang('acp_edit_l_redir'), 'admin.php?act=license&l');
    } else {
        $license = $db->fetch(array(), 'license', array(array('license_id', '=', $_GET['id'])));
        $license[0]['license_text'] = base64_decode($license[0]['license_text']);
        $license[0]['license_text'] = str_replace("<br />", "\n", $license[0]['license_text']);
        $license[0]['license_text'] = str_replace("<", "&lt;", $license[0]['license_text']);
        $license[0]['license_text'] = str_replace(">", "&gt;", $license[0]['license_text']);
        $smarty->assign('target', $license[0]);
    }
} elseif ($_GET['l'] == 'delete') {

    $db->update('files', array(array('file_license', 0)), array(array('file_license', '=', $_GET['id'])));
    $db->deldata('license', array(array('license_id', '=', $_GET['id'])));
    
    smarty_redirect(lang('acp_del_l_redir'), 'admin.php?act=license&l');
} else {
    
    $licenses = $db->fetch(array(), 'license');
    $smarty->assign('licenses', $licenses);
}
?>