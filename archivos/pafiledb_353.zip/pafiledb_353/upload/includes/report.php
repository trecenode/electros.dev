<?php

/**
  * paFileDB 3.5
  *
  * This file contains the code for reporting broken links to admins.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

//Check if reporting is disabled
if ($settings[0]['enable_report'] == 0) {
    smarty_error(lang('feature_disabled'));
}

//Get file info
$file = $db->fetch(array(), 'files', array(array('file_id', '=', $_GET['id'])));
if (count($file) == 0) {
    smarty_error(lang('file_exist'));
}
$file = $file[0];
    
//Send the mail
if (isset($_GET['process'])) {
    if (!check_input($_POST, array('message'))) {
        smarty_error(lang('emptyfield'));
    }
    
    //Make sure the "from" address is valid
    if (!eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$', $_POST['fromemail'])) {
        smarty_error(lang('emailinvalid'));
    }
    $usermessage = trim($_POST['message']);
    $message = $_POST['fromname'].'('.$_POST['fromemail'].') has reported a broken link at '.$settings[0]['dbname'].".\n\n";
    $message .= "File: ".$file['file_name']."\n";
    $message .= "Please visit this link to view the file:\n";
    $message .= $settings[0]['dburl'].'/index.php?act=view&id='.$_GET['id']."\n\n";
    $message.= "If you have verified that the link is broken, you may edit the download URL in the paFileDB admin center at ".$settings[0]['dburl']."/admin.php\n\n";
    if (!empty($usermessage)) {
        $message .= $_POST['fromname']." has included this message:\n";
        $message .= $usermessage."\n\n";
    }
    $message .= "The IP address of the person who reported the broken link is: ".$_SERVER['REMOTE_ADDR']."\n\n";
    $message .= "Please note that ".$settings[0]['dbname']." cannot be held responsible for the contents of this message. To report abuse, please visit ".$settings[0]['dburl'];
    
    $to = array();
    $admins = $db->fetch(array(), 'admin');
    foreach ($admins as $a) {
        $to[] = array("name" => $a['admin_username'], "address" => $a['admin_email']);
    }
    pafiledb_mail($_POST['fromname'], $_POST['fromemail'], $to, 'Broken link reported at '.$settings[0]['dbname'], $message);

    smarty_redirect(lang('report_sent'), 'index.php?act=view&amp;id='.$_GET['id']);
}

$smarty->assign('id', $_GET['id']);
$smarty->assign('navbar',  array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $file['file_name'], 'url' => '?act=view&amp;id='.$_GET['id'])));
$smarty->assign('title', $settings[0]['dbname']." &raquo; ".$file['file_name']." &raquo; ".lang('emailfriend'));

?>