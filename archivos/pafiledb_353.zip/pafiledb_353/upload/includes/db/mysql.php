<?php

/**
  * This is the MySQL driver for paDB.
  *
  * @author Andrew (andyl56) <andyl56@phparena.net>
  * @version 1.0
  * @copyright 2005 phpArena.net
  * @package paDB
  */

/**
  * This is the MySQL driver for paDB.
  *
  * @author Andrew (andyl56) <andyl56@phparena.net>
  * @version 1.0
  * @copyright 2005 phpArena.net
  * @package paDB
  */
class padb_mysql {
    /**
      * @var mixed This stores the connection to the database.
      */
    var $link = '';
    /**
      * @var string This usually is the last message received by the MySQL server.
      */
    var $msg = '';
    /**
      * @var string This stores all executed queries for debugging purposes.
      */
    var $queries = array();
    /**
      * @var string This is the server this program should try to connect to. 'localhost' or '127.0.0.1' is almost always fine.
      */
    var $host = 'SERVER';
    /**
      * @var int This is the port number this program should try to connect to. The default is 3306.
      */
    var $port = 3306;
    /**
      * @var string This is the username on the MySQL server to use. It is a HUGE security risk to use a root-access user!
      */
    var $username = 'USERNAME';
    /**
      * @var string This is the password on the MySQL server to use. It's a HUGE security risk to use a null or simple password!
      */
    var $password = 'PASSWORD';
    /**
      * @var string This is the database on the MySQL server to use.
      */
    var $dbname = 'DATABASE';
    /**
      * @var string This is the string to prefix each table name with (including the underscore and the end if desired).
      */
    var $prefix = '';
    /**
      * @var bool This sets whether or not to use persistent connections. When in doubt, use false.
      */
    var $persist = false;

    /**
      * Initialize the connection to the MySQL database.
      *
      * @since 1.0
      * @return bool Will return TRUE (1) or else the MySQL error will be displayed and all loading will cease.
      */
    function connect() {
        if ($this->link)
        {
            echo 'You can\'t have two database connections in the same instance of the same database class!';
            exit;
        }
        else
        {
            /* $this->host is the format to use for non-PHP5 instances. */
            if ($this->persist)
            {
                $this->link = @mysql_pconnect($this->host.':'.$this->port, $this->username, $this->password);
            }
            else
            {
                $this->link = @mysql_connect($this->host.':'.$this->port, $this->username, $this->password);
            }
            if (!$this->link)
            {
                printf("Connection failed: %s\r\n", mysql_error());
                exit;
            }
            else if (!mysql_select_db($this->dbname, $this->link))
            {
                printf("Connection failed: %s\r\n", mysql_error($this->link));
                exit;
            }
            else
            {
                $this->msg = sprintf("Host information: %s - Server version %s\n", mysql_get_host_info($this->link), mysql_get_server_info($this->link));
                return true;
            }
        }
    }

    /**
      * Automatically connect to the server upon class initialization.
      *
      * @since 1.0
      */
    function padb_mysql() {
        // Check if this is the installer
        if (preg_match("/\/install\/index\.php/", $_SERVER["SCRIPT_FILENAME"]) && md5($this->host . $this->username . $this->password . $this->dbname) == 'a68efcf22828c5133f4baf910442bc2e')
        {
            echo "Please read the installation instructions.";
            exit;
        }

        $this->connect();
    }

    /**
      * Terminate the connection to the MySQL database.
      *
      * @since 1.0
      * @return bool Whether or not the disconnect was a success.
      */
    function disconnect() {
        if ($this->link)
        {
            @mysqli_close($this->link);
            $this->link = '';
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
      * "Fetch" data from the MySQL server.
      *
      * <pre>
      * ---------------------------------------------
      * -- "SIMPLE QUERIES" - FETCH FROM ONE TABLE --
      * ---------------------------------------------
      * </pre>
      *
      * <b>$what</b> is as follows:
      * <code>
      * array("col1", "col2", "col3", "col4", "col5")
      * </code>
      * <b>$table</b> is a string with the table name (don't use table prefixes!).
      *
      * <pre>
      * ---------------------------------------------------------
      * -- "ADVANCED QUERIES" - FETCH FROM MORE THAN ONE TABLE --
      * ---------------------------------------------------------
      * </pre>
      *
      * <b>$what</b> is as follows:
      * <code>
      * $what = array();
      * // First Table - ONLY one that can have WHERE statements and ORDERing
      * $what[] = array("col1", "col2", "col3", "col4", "col5");
      * // Table Two
      * $what[] = array("col1", "col2", "col3", "col4", "col5");
      * // Etc...
      * $what[] = array("col1", "col2", "col3", "col4", "col5");
      * </code>
      * <b>$table</b> is as follows:
      * <code>
      * $table = array();
      * // First Table - Values of matchingcol are how matching rows are matched across tables.
      * $table[] = array("tablename1", "matchingcol");
      * // Table Two - machingcol doesn't have to be named the same
      * $table[] = array("tablename2", "matchingcol");
      * // Etc...
      * $table[] = array("tablename3", "matchingcol");
      * </code>
      *
      * <pre>
      * -----------------------------------------------
      * -- APPLICABLE TO SIMPLE AND ADVANCED QUERIES --
      * -----------------------------------------------
      * </pre>
      *
      * <b>$where</b> is as follows (only can match for the first table):<br>
      * <code>
      * $where = array();
      * $where[] = array("col1", ">", "val1");
      * $where[] = array("col2", "<", "val2");
      * $where[] = array("col3", ">=", "val3");
      * $where[] = array("col4", "<=", "val4");
      * $where[] = array("col5", "!=", "val5");
      * $where[] = array("col6", "=", "val6");
      * $where[] = array("col7", "?", "*val7*"); // Not case sensitive. Allows * wildcard.
      * $where[] = array("col8", "?", array('a', 'b', 'c')); // Values are one of a, b, or c
      * </code>
      *
      * @since 1.0
      * @return array The fetched MySQL data as an array.
      * @param array What columns to select for retrieval
      * @param string The database table to get the information from (Don't use prefixes!)
      * @param array The conditions for what to retrieve
      * @param string What column to sort the information by
      * @param string How to sort the data ASC(ending) or DESC(ending)
      */
    function fetch($what=array(), $table='',  $where=array(), $sort='', $order='ASC') {
        if (!$this->link)
        {
            return '-1_no_connection';
        }

        $query = 'SELECT %what% FROM %table%%leftj% %where% %sort%';
        $query_leftj = ' LEFT JOIN %table% ON %col1table%=%thiscoltable%';

        if (!$table)
        {
            return '-1_bad_field_table';
        }
        else
        {
            if (is_array($table))
            {
                foreach ($table as $a => $b)
                {
                    if (!is_array($b) || count($b) != 2)
                    {
                        return '-1_bad_fieldval_table';
                    }
                    else if ((is_scalar($b[0]) || is_numeric($b[0])) && (is_scalar($b[1]) || is_numeric($b[1])))
                    {
                        if (preg_match('/(`|,)/', $b[0]))
                        {
                            return '-1_bad_fieldval_what';
                        }
                        if (preg_match('/(`|,)/', $b[1]))
                        {
                            return '-1_bad_fieldval_what';
                        }
                        $table[$a] = array('`' . $this->prefix . $b[0] . '`', '`' . $this->prefix . $b[0] . '`.`' . $b[1] . '`');
                    }
                    else
                    {
                        return '-1_bad_fieldval_table';
                    }
                }
            }
            else
            {
                if (is_scalar($table) || is_numeric($table))
                {
                    if (preg_match('/(`|,)/', $table))
                    {
                        return '-1_bad_fieldval_what';
                    }
                    $table = array('`' . $this->prefix . $table . '`');
                }
                else
                {
                    return '-1_bad_fieldval_table';
                }
                $table = array($table);
            }
        }

        $newwhat = array();
        if (is_array($what))
        {
            if (count($table) > 1)
            {
                if (count($what) == count($table))
                {
                    foreach ($what as $a => $b)
                    {
                        $newwhat2 = array();
                        foreach ($b as $c)
                        {
                            if (is_scalar($c) || is_numeric($c))
                            {
                                if (preg_match('/(`|,)/', $c))
                                {
                                    return '-1_bad_fieldval_what';
                                }
                            }
                            else
                            {
                                return '-1_bad_fieldval_what';
                            }
                            $newwhat2[] = $table[$a][0] . '.`' . $c . '`';
                        }
                        if (count($newwhat2))
                        {
                            $newwhat[] = implode(', ', $newwhat2);
                            unset($newwhat2);
                        }
                        else
                        {
                            $newwhat[] = $table[$a][0] . '.*';
                            unset($newwhat2);
                        }
                    }
                    if (count($newwhat))
                    {
                        $what = implode(', ', $newwhat);
                        unset($newwhat);
                    }
                    else
                    {
                        $what = '*';
                        unset($newwhat);
                    }
                }
                else
                {
                    return '-1_bad_field_what';
                }
            }
            else if (count($table) == 1)
            {
                foreach ($what as $a)
                {
                    if (is_scalar($a) || is_numeric($a))
                    {
                        if (preg_match('/(`|,)/', $a))
                        {
                            return '-1_bad_fieldval_what';
                        }
                    }
                    else
                    {
                        return '-1_bad_fieldval_what';
                    }
                    $newwhat[] = '`' . $a . '`';
                }
                if (count($newwhat))
                {
                    $what = implode(', ', $newwhat);
                    unset($newwhat);
                }
                else
                {
                    $what = '*';
                    unset($newwhat);
                }
            }
            else
            {
                return '-1_bad_field_what';
            }
        }
        else
        {
            return '-1_bad_field_what';
        }

        if (!$where)
        {
            $where = '';
        }
        else
        {
            if (!is_array($where))
            {
                return '-1_bad_field_where';
            }
            else
            {
                $newwhere = '';
                if (count($where) > 0)
                {
                    foreach ($where as $a => $b)
                    {
                        if (!is_array($b) || count($b) != 3)
                        {
                            return '-1_bad_fieldval_where';
                        }
                        else
                        {
                            if (preg_match('/(`|,)/', $b[0]))
                            {
                                return '-1_bad_fieldval_where';
                            }
                            else
                            {
                                $b[0] = $table[0][0].'.`'. $b[0] . '`';
                            }

                            switch($b[1])
                            {
                                case '>':
                                    $b[1] = '>';
                                    break;
                                case '<':
                                    $b[1] = '<';
                                    break;
                                case '>=':
                                    $b[1] = '>=';
                                    break;
                                case '<=':
                                    $b[1] = '<=';
                                    break;
                                case '!=':
                                    $b[1] = '<>';
                                    break;
                                case '=':
                                    $b[1] = '=';
                                    break;
                                case '?':
                                    $b[1] = 'like';
                                    break;
                                default:
                                    return '-1_bad_fieldval_where';
                                    break;
                            }

                            if ($b[1] == 'like' && is_array($b[2]))
                            {
                                $temp = array();
                                foreach ($b[2] as $c)
                                {
                                    if (is_numeric($c))
                                    {
                                    }
                                    else if (preg_match('/(`|,)/', $c))
                                    {
                                        return '-1_bad_fieldval_where';
                                    }
                                    else
                                    {
                                        $c = '\'' . addslashes($c) . '\'';
                                    }
                                    $temp[] = $c;
                                }
                                $newwhere[] = $b[0].' IN( '. implode(', ', $temp) . ' )';
                                unset($temp);
                            }
                            else
                            {
                                if ($b[1] == 'like')
                                {
                                    $b[2] = str_replace('*', '%', $b[2]);
                                    $b[2] = str_replace('_', '\_', $b[2]);
                                }
                                if (is_numeric($b[2]))
                                {
                                }
                                else if (preg_match('/(`|,)/', $b[2]))
                                {
                                    return '-1_bad_fieldval_where';
                                }
                                else
                                {
                                    $b[2] = '\'' . addslashes($b[2]) . '\'';
                                }
                                $newwhere[] = $b[0].' '.$b[1].' '.$b[2];
                            }
                        }
                    }
                    $where = 'WHERE '.implode(' AND ', $newwhere);
                    unset($newwhere);
                }
                else
                {
                    $where = '';
                }
            }
        }

        if (!$sort)
        {
            $sort = '';
            $order = '';
        }
        else
        {
            if (is_scalar($sort) || is_numeric($sort))
            {
                if (preg_match('/(`|,)/', $sort))
                {
                    return '-1_bad_fieldval_sort';
                }
                $sort = 'ORDER BY '.$table[0][0].'.`' . $sort . '`';
                switch (strtolower($order))
                {
                    case 'asc':
                        $sort .= ' ASC';
                        break;
                    case 'desc':
                        $sort .= ' DESC';
                        break;
                    default:
                        return '-1_bad_fieldval_sortorder';
                        break;
                }
            }
            else
            {
                return '-1_bad_fieldval_sort';
            }
        }

        $query_realleftj = '';
        for ($x = 1; $x < count($table); $x++)
        {
            $curleft = $query_leftj;
            $curleft = str_replace('%table%',        $table[$x][0],  $curleft);
            $curleft = str_replace('%col1table%',    $table[0][1],   $curleft);
            $curleft = str_replace('%thiscoltable%', $table[$x][1],  $curleft);
            $query_realleftj .= $curleft;
        }

        $query = str_replace('%what%',  $what,            $query);
        $query = str_replace('%table%', $table[0][0],     $query);
        $query = str_replace('%leftj%', $query_realleftj, $query);
        $query = str_replace('%where%', $where,           $query);
        $query = str_replace('%sort%',  $sort,            $query);
        $query = preg_replace("/([\r\n])[\s]+/", '', $query);

        if ($result = mysql_query($query, $this->link))
        {
            $this->queries[] = $query;
            $returns = array();
            while ($row = mysql_fetch_array($result))
            {
                foreach ($row as $a => $b)
                {
                    $row[$a] = stripslashes($b);
                }
                $returns[] = $row;
            }

            mysql_free_result($result);
        }
        else
        {
            die("MySQL Error: ".mysql_error($this->link)."\r\n"
            . "Query: " . $query);
        }

        return $returns;
    }

    /**
      * "Insert" data into the MySQL server.
      *
      * <b>$vals</b> is as follows:<br>
      * <code>
      * $vals = array();
      * $vals[] = array("column1", "value1");
      * $vals[] = array("column2", "value2");
      * $vals[] = array("column3", "value3");
      * $vals[] = array("column4", "value4");
      * </code>
      * @since 4.0a1
      * @return int The row id of the inserted row
      * @param string The table to insert the data into
      * @param array The values to insert into the new row
      */
    function insert($table='',  $vals=array()) {
        if (!$this->link)
        {
            return '-1_no_connection';
        }

        $query = 'INSERT INTO %table% (%cols%) VALUES (%vals%)';

        if (!$table)
        {
            return '-1_bad_field_table';
        }
        else
        {
            if (is_scalar($table) || is_numeric($table))
            {
                if (preg_match('/(`|,)/', $table))
                {
                    return '-1_bad_fieldval_what';
                }
                $table = '`' . $this->prefix . $table . '`';
            }
            else
            {
                return '-1_bad_fieldval_table';
            }
        }

        if (!is_array($vals) || count($vals) < 1)
        {
            return '-1_bad_field_vals';
        }
        else
        {
            $newfields = array();
            $newvals   = array();
            foreach ($vals as $b)
            {
                if (!is_array($b) || count($b) != 2)
                {
                    return '-1_bad_field_vals';
                }
                else
                {
                    if (preg_match('/(`|,)/', $b[0]))
                    {
                        return '-1_bad_fieldval_vals';
                    }

                    if (is_numeric($b[1]))
                    {
                    }
                    else if ((preg_match('/(`|,)/', $b[1]) && substr($b[1], 0, 19) != ",,force_as_string,,") || (preg_match('/(`|,)/', substr($b[1], 19)) && substr($b[1], 0, 19) == ",,force_as_string,,"))
                    {
                        return '-1_bad_fieldval_vals';
                    }
                    else
                    {
                        if (substr($b[1], 0, 19) == ",,force_as_string,,")
                        {
                            $b[1] = substr($b[1], 19);
                        }

                        $b[1] = '\'' . addslashes($b[1]) . '\'';
                    }

                    $newfields[] = '`'.$b[0].'`';
                    $newvals[]   = $b[1];
                }
            }
            $fields = implode(', ', $newfields);
            $vals   = implode(', ', $newvals);
            unset($newfields);
            unset($newvals);
        }

        $query = str_replace('%table%', $table,  $query);
        $query = str_replace('%cols%',  $fields, $query);
        $query = str_replace('%vals%',  $vals,   $query);

        $query = preg_replace("/([\r\n])[\s]+/", '', $query);

        if (mysql_query($query, $this->link))
        {
            $this->queries[] = $query;
            $retid = mysql_insert_id($this->link);
        }
        else
        {
            die("MySQL Error: ".mysql_error($this->link)."\r\n"
            . "Query: " . $query);
        }

        return $retid;
    }

    /**
      * "Update" data to the MySQL server.
      *
      * <b>$sets</b> is as follows:<br>
      * <code>
      * $sets = array();
      * $sets[] = array("column1", "value1");
      * $sets[] = array("column2", "value2");
      * $sets[] = array("column3", "value3");
      * $sets[] = array("column4", "value4");
      * $sets[] = array("column5", "++1++"); # Adds 1 to the current value of the column. (Can only be an integer)
      * $sets[] = array("column6", "--1--"); # Subtracts 1 to the current value of the column. (Can only be an integer)
      * </code>
      * <b>$where</b> is as follows:<br>
      * <code>
      * $where = array();
      * $where[] = array("col1", ">", "val1");
      * $where[] = array("col2", "<", "val2");
      * $where[] = array("col3", ">=", "val3");
      * $where[] = array("col4", "<=", "val4");
      * $where[] = array("col5", "!=", "val5");
      * $where[] = array("col6", "=", "val6");
      * $where[] = array("col7", "?", "*val7*"); // Not case sensitive. Allows * wildcard.
      * $where[] = array("col8", "?", array('a', 'b', 'c')); // Values are one of a, b, or c
      * </code>
      *
      * @since 1.0
      * @return bool Will always result in "TRUE" except for SQL injection attempts.
      * @param string The table to update the information on
      * @param array The updated values to send to the server
      * @param array The conditions to determine what rows to update
      */
    function update($table='',  $sets=array(), $where=array()) {
        if (!$this->link)
        {
            return '-1_no_connection';
        }

        $query = 'UPDATE %table% SET %values% %where%';

        if (!$table)
        {
            return '-1_bad_field_table';
        }
        else
        {
            if (is_scalar($table) || is_numeric($table))
            {
                if (preg_match('/(`|,)/', $table))
                {
                    return '-1_bad_fieldval_what';
                }
                $table = '`' . $this->prefix . $table . '`';
            }
            else
            {
                return '-1_bad_fieldval_table';
            }
        }

        if (!is_array($sets) || count($sets) < 1)
        {
            return '-1_bad_field_sets';
        }
        else
        {
            $newsets = array();
            foreach ($sets as $b)
            {
                if (!is_array($b) || count($b) != 2)
                {
                    return '-1_bad_field_sets';
                }
                else
                {
                    $querytype = 1;
                    $matches   = array();
                    if (preg_match('/(`|,)/', $b[0]))
                    {
                        return '-1_bad_fieldval_sets';
                    }

                    if (is_numeric($b[1]))
                    {
                    }
                    else if ((preg_match('/(`|,)/', $b[1]) && substr($b[1], 0, 19) != ",,force_as_string,,") || (preg_match('/(`|,)/', substr($b[1], 19)) && substr($b[1], 0, 19) == ",,force_as_string,,"))
                    {
                        return '-1_bad_fieldval_where';
                    }
                    else if (preg_match('/^(([+][+]|[-][-])([0-9]{1,})(\\2))$/', $b[1], $matches))
                    {
                        $newsets[] = '`'.$b[0].'` = `'.$b[0].'`'.substr($matches[1],0,1).$matches[3];
                        $querytype = 2;
                    }
                    else
                    {
                        if (substr($b[1], 0, 19) == ",,force_as_string,,")
                        {
                            $b[1] = substr($b[1], 19);
                        }

                        $b[1] = '\'' . addslashes($b[1]) . '\'';
                    }

                    if ($querytype == 1)
                    {
                        $newsets[] = '`'.$b[0].'` = '.$b[1];
                    }
                    unset($querytype);
                }
            }
            $sets = implode(', ', $newsets);
            unset($newsets);
        }

        if (!$where)
        {
            $where = '';
        }
        else
        {
            if (!is_array($where))
            {
                return '-1_bad_field_where';
            }
            else
            {
                $newwhere = '';
                if (count($where) > 0)
                {
                    foreach ($where as $b)
                    {
                        if (!is_array($b) || count($b) != 3)
                        {
                            return '-1_bad_fieldval_where';
                        }
                        else
                        {
                            if (preg_match('/(`|,)/', $b[0]))
                            {
                                return '-1_bad_fieldval_where';
                            }
                            else
                            {
                                $b[0] = '`'. $b[0] . '`';
                            }

                            switch($b[1])
                            {
                                case '>':
                                    $b[1] = '>';
                                    break;
                                case '<':
                                    $b[1] = '<';
                                    break;
                                case '>=':
                                    $b[1] = '>=';
                                    break;
                                case '<=':
                                    $b[1] = '<=';
                                    break;
                                case '!=':
                                    $b[1] = '<>';
                                    break;
                                case '=':
                                    $b[1] = '=';
                                    break;
                                case '?':
                                    $b[1] = 'like';
                                    break;
                                default:
                                    return '-1_bad_fieldval_where';
                                    break;
                            }

                            if ($b[1] == 'like' && is_array($b[2]))
                            {
                                $temp = array();
                                foreach ($b[2] as $c)
                                {
                                    if (is_numeric($c))
                                    {
                                    }
                                    else if (preg_match('/(`|,)/', $c))
                                    {
                                        return '-1_bad_fieldval_where';
                                    }
                                    else
                                    {
                                        $c = '\'' . addslashes($c) . '\'';
                                    }
                                    $temp[] = $c;
                                }
                                $newwhere[] = $b[0].' IN( '. implode(', ', $temp) . ' )';
                                unset($temp);
                            }
                            else
                            {
                                if ($b[1] == 'like')
                                {
                                    $b[2] = str_replace('*', '%', $b[2]);
                                    $b[2] = str_replace('_', '\_', $b[2]);
                                }
                                if (is_numeric($b[2]))
                                {
                                }
                                else if (preg_match('/(`|,)/', $b[2]))
                                {
                                    return '-1_bad_fieldval_where';
                                }
                                else
                                {
                                    $b[2] = '\'' . addslashes($b[2]) . '\'';
                                }
                                $newwhere[] = $b[0].' '.$b[1].' '.$b[2];
                            }
                        }
                    }
                    $where = 'WHERE '.implode(' AND ', $newwhere);
                    unset($newwhere);
                }
                else
                {
                    $where = '';
                }
            }
        }

        $query = str_replace('%table%',  $table, $query);
        $query = str_replace('%values%', $sets,  $query);
        $query = str_replace('%where%',  $where, $query);
        $query = preg_replace("/([\r\n])[\s]+/", '', $query);

        if (mysql_query($query, $this->link))
        {
            $this->queries[] = $query;
        }
        else
        {
            die("MySQL Error: ".mysql_error($this->link)."\r\n"
            . "Query: " . $query);
        }

        return true;
    }

    /**
      * Delete data from the MySQL server
      *
      * <b>$where</b> is as follows:<br>
      * <code>
      * $where = array();
      * $where[] = array("col1", ">", "val1");
      * $where[] = array("col2", "<", "val2");
      * $where[] = array("col3", ">=", "val3");
      * $where[] = array("col4", "<=", "val4");
      * $where[] = array("col5", "!=", "val5");
      * $where[] = array("col6", "=", "val6");
      * $where[] = array("col7", "?", "*val7*"); // Not case sensitive. Allows * wildcard.
      * $where[] = array("col8", "?", array('a', 'b', 'c')); // Values are one of a, b, or c
      * </code>
      *
      * @since 1.0
      * @return bool Will always result in "TRUE" except for SQL injection attempts.
      * @param string The table to remove the information from
      * @param array The conditions to determine what rows to remove
      */
    function deldata($table='', $where=array()) {
        if (!$this->link)
        {
            return '-1_no_connection';
        }

        $query = 'DELETE FROM %table% %where%';

        if (!$table)
        {
            return '-1_bad_field_table';
        }
        else
        {
            if (is_scalar($table) || is_numeric($table))
            {
                if (preg_match('/(`|,)/', $table))
                {
                    return '-1_bad_fieldval_what';
                }
                $table = '`' . $this->prefix . $table . '`';
            }
            else
            {
                return '-1_bad_fieldval_table';
            }
        }

        if (!$where)
        {
            $where = '';
        }
        else
        {
            if (!is_array($where))
            {
                return '-1_bad_field_where';
            }
            else
            {
                $newwhere = '';
                if (count($where) > 0)
                {
                    foreach ($where as $b)
                    {
                        if (!is_array($b) || count($b) != 3)
                        {
                            return '-1_bad_fieldval_where';
                        }
                        else
                        {
                            if (preg_match("/(`|,)/", $b[0]))
                            {
                                return '-1_bad_fieldval_where';
                            }
                            else
                            {
                                $b[0] = '`'. $b[0] . '`';
                            }

                            switch($b[1])
                            {
                                case '>':
                                    $b[1] = '>';
                                    break;
                                case '<':
                                    $b[1] = '<';
                                    break;
                                case '>=':
                                    $b[1] = '>=';
                                    break;
                                case '<=':
                                    $b[1] = '<=';
                                    break;
                                case '!=':
                                    $b[1] = '<>';
                                    break;
                                case '=':
                                    $b[1] = '=';
                                    break;
                                case '?':
                                    $b[1] = 'like';
                                    break;
                                default:
                                    return '-1_bad_fieldval_where';
                                    break;
                            }

                            if ($b[1] == 'like' && is_array($b[2]))
                            {
                                $temp = array();
                                foreach ($b[2] as $c)
                                {
                                    if (is_numeric($c))
                                    {
                                    }
                                    else if (preg_match('/(`|,)/', $c))
                                    {
                                        return '-1_bad_fieldval_where';
                                    }
                                    else
                                    {
                                        $c = '\'' . addslashes($c) . '\'';
                                    }
                                    $temp[] = $c;
                                }
                                $newwhere[] = $b[0].' IN( '. implode(', ', $temp) . ' )';
                                unset($temp);
                            }
                            else
                            {
                                if ($b[1] == 'like')
                                {
                                    $b[2] = str_replace('*', '%', $b[2]);
                                    $b[2] = str_replace('_', '\_', $b[2]);
                                }
                                if (is_numeric($b[2]))
                                {
                                }
                                else if (preg_match('/(`|,)/', $b[2]))
                                {
                                    return '-1_bad_fieldval_where';
                                }
                                else
                                {
                                    $b[2] = '\'' . addslashes($b[2]) . '\'';
                                }
                                $newwhere[] = $b[0].' '.$b[1].' '.$b[2];
                            }
                        }
                    }
                    $where = 'WHERE '.implode(' AND ', $newwhere);
                    unset($newwhere);
                }
                else
                {
                    $where = '';
                }
            }
        }

        $query = str_replace('%table%', $table, $query);
        $query = str_replace('%where%', $where, $query);
        $query = preg_replace("/([\r\n])[\s]+/", '', $query);

        if (mysql_query($query, $this->link))
        {
            $this->queries[] = $query;
        }
        else
        {
            die("MySQL Error: ".mysql_error($this->link)."\r\n"
            . "Query: " . $query);
        }

        return true;
    }

    /**
      * Clear out all data in a MySQL table
      *
      * @since 1.0
      * @return bool Will always result in "TRUE" except for SQL injection attempts.
      * @param string The table to remove all data from
      */
    function truncate($table='') {
        if (!$this->link)
        {
            return '-1_no_connection';
        }

        $query = 'TRUNCATE TABLE %table%';

        if (!$table)
        {
            return '-1_bad_field_table';
        }
        else
        {
            if (is_scalar($table) || is_numeric($table))
            {
                if (preg_match('/(`|,)/', $table))
                {
                    return '-1_bad_fieldval_what';
                }
                $table = '`' . $this->prefix . $table . '`';
            }
            else
            {
                return '-1_bad_fieldval_table';
            }
        }

        $query = str_replace('%table%', $table, $query);

        if (mysql_query($query, $this->link))
        {
            $this->queries[] = $query;
        }
        else
        {
            die("MySQL Error: ".mysql_error($this->link)."\r\n"
            . "Query: " . $query);
        }

        return true;
    }
}
$db = new padb_mysql();

?>