<?php

/**
  * paFileDB 3.5
  *
  * This file handles file downloads.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

    

//Fetch the file info from the database
$file = $db->fetch(array(), 'files', array(array('file_id', '=', $_GET['id'])));
if (count($file) == 0) {

    smarty_error(lang('file_exist'));
}
$file = $file[0];

//Update stuff
$db->update('files', array(array('file_dls', '++1++'), array('file_last', time())), array(array('file_id', '=', $_GET['id'])));

if (isset($_GET['mirror'])) {
    $mirrors = unserialize($file['file_mirrors']);
    smarty_redirect(str_replace('{fileurl}',$file['file_dlurl'], lang('download_message')), $mirrors[$_GET['mirror']]['url'], true);
} else {
    smarty_redirect(str_replace('{fileurl}',$file['file_dlurl'], lang('download_message')), $file['file_dlurl'], true);
}
?>