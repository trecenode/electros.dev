<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for viewing a file.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

if (isset($_GET['rate'])) { //Rate file
    
    /* So users can't rate files more than once, paFileDB sends them a cookie that
    keeps track of what files they rated. This code updates the cookie. */
    $rated_array = array();
    if (isset($_COOKIE['pafiledb_rate'])) {
        $rated_array = explode('|', $_COOKIE['pafiledb_rate']);
        if (in_array($_GET['id'], $rated_array)) {
            smarty_error(lang('rate_error'));
        }
    }
    
    /* Update the file with the new rating. A note on how ratings work:
    The rating system used by paFileDB may be different than other scripts.
    When a file is rated, the rating chosen (1-5) is added to the existing
    rating in the database. So lets say, 7 users rate the file, with ratings of
    1, 4, 2, 5, 4, 3, 5. A total is kept, and for this file, it would be 24.
    That number is then divided by the number of times the file was rated.
    24 / 7 is 3.42857, and is then rounded to 3.5 to display 3 and a half stars
    on the page. */
    $db->update('files', array(array('file_rating', '++'.$_POST['rating'].'++'), array('file_totalvotes', '++1++')), array(array('file_id', '=', $_GET['id'])));
    
    $rated_array[] = $_GET['id'];
    setcookie('pafiledb_rate', implode('|', $rated_array), time()+63072000);
    smarty_redirect(lang('rate_redir'), 'index.php?act=view&id='.$_GET['id']);

}

//Fetch the file info from the database
$file = $db->fetch(array(), 'files', array(array('file_id', '=', $_GET['id'])));
if (count($file) == 0) {

    smarty_error(lang('file_exist'));
}
$file = $file[0];

//Fetch the category info from the database
$category = $db->fetch(array(), 'cat', array(array('cat_id', '=', $file['file_catid'])));
$category = $category[0];

if ($category['cat_parent'] != 0) {
    $parent = $db->fetch(array(), 'cat', array(array('cat_id', '=', $category['cat_parent'])));
    $parent = $parent[0];
    $smarty->assign('navbar',  array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $parent['cat_name'], 'url' => '?act=category&amp;id='.$parent['cat_id']), array('name' => $category['cat_name'], 'url' => '?act=category&amp;id='.$category['cat_id']), array('name' => $file['file_name'], 'url' => '?act=view&amp;id='.$_GET['id'])));
    $smarty->assign('title', $settings[0]['dbname']." &raquo; ".$parent['cat_name'] ." &raquo; ".$category['cat_name']." &raquo; ".$file['file_name']);
} else {
    $smarty->assign('navbar',  array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $category['cat_name'], 'url' => '?act=category&amp;id='.$category['cat_id']), array('name' => $file['file_name'], 'url' => '?act=view&amp;id='.$_GET['id'])));
    $smarty->assign('title', $settings[0]['dbname']." &raquo; ".$category['cat_name']." &raquo; ".$file['file_name']);
}

/* Calculate the file rating and round it off. The if/else
statement prevents a divide by zero. If the number of ratings 
is zero, no work has to be done, since obviously, the file's
rating is zero. */
if($file['file_totalvotes'] > 0)
{
    $f_rating = $file['file_rating'] / $file['file_totalvotes'];
    $rating_round_half = round($f_rating / 0.5) * 0.5;
    $remainder = fmod($rating_round_half, 1);
    $whole_rating = (int) $rating_round_half - $remainder; //Rating rounded to whole number
    $half_star = $remainder == 0.5; //True if the rating needs a half star
} else {
    $whole_rating = (int) 0;
    $half_star = false;
}

/* The rating is displayed using whole and half stars. So if the
rating is 2.5, it shows 2 full stars, 1 half star, and then 2
grey stars at the end (just to make it look pretty). This code
sets up an array with the file names of the star gifs to use */
$stars = array();

//Add X amount of stars (where X is whole number of the rating)
for ($i=0; $i<$whole_rating; $i++)
{
    $stars[] = 'star_full.gif';
}

//If a half star is needed, add it to the array
if ($half_star) {
    $stars[] = 'star_half.gif';
}

//Fill in the remaining grey stars
$remaining = 5 - count($stars);
for ($j=0; $j<$remaining; $j++)
{
    $stars[] = 'star_grey.gif';
}

/* Check to see if the user already rated the file, if
they didn't, we tell Smarty so it can show the rating dropdown menu */
$already_rated = false;
if (isset($_COOKIE['pafiledb_rate'])) {
    $rated_q = explode('|', $_COOKIE['pafiledb_rate']);
    if (in_array($_GET['id'], $rated_q)) {
       $already_rated = true;
    }
}

$file['file_time'] = $file['file_time']+($settings[0]['timeoffset']*3600);
if ($file['file_last'] > 0) {
    $file['file_last'] = $file['file_last']+($settings[0]['timeoffset']*3600);
}
$mirrors = unserialize($file['file_mirrors']);
if (is_array($mirrors)) {
    $smarty->assign('has_mirrors', true);
} else {
    $smarty->assign('has_mirrors', false);
}
$custom = $db->fetch(array(array(), array()), array(array('customdata', 'customdata_custom'), array('custom', 'custom_id')), array(array('customdata_file', '=', $_GET['id'])), 'customdata_custom', 'ASC');
$smarty->assign('custom', $custom);
$smarty->assign('category', $category);
$smarty->assign('file', $file);
$smarty->assign('stars', $stars);
$smarty->assign('already_rated', $already_rated);


?>