<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for displaying the categories
  * on the main page.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

//Fetch the categories from the database and place them into an array
$categories = $db->fetch(array(), 'cat', array(array('cat_parent', '=', 0)), 'cat_order', 'ASC');

//Send the array and navbar to Smarty
$smarty->assign('categories', $categories);
$smarty->assign('navbar', array(array('url' => '', 'name' => $settings[0]['dbname'])));
$smarty->assign('title', $settings[0]['dbname']);

?>