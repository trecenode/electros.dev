<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines for searching the database
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5
  * Copyright 2005 PHP Arena
  */

if (isset($_GET['process'])) {
    $smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => lang('search'), 'url' => '?act=search'), array('name' => lang('search_results').' '.$_POST['query'], 'url' => '?act=search')));
    $smarty->assign('title', $settings[0]['dbname'].' &raquo; '.lang('search').' &raquo; '.lang('search_results').' '.$_POST['query']);
    $smarty->assign('act', 'process');
    
    //Make sure the input is valid
    if (!check_input($_POST)) {
        smarty_error(lang('emptyfield'));
    }
    
    
    $query = xhtml_convert($_POST['query']);
    
    $results = $db->fetch(array(), 'files', array(array('file_name', '?', '*'.$query.'*')));
    
    $ids = array();
    foreach ($results as $r) {
        $ids[] = $r['file_id'];
    }
    $r2 = $db->fetch(array(), 'files', array(array('file_desc', '?', '*'.$query.'*')));
    foreach ($r2 as $r) {
        if (!in_array($r['file_id'], $ids)) {
            $results[] = $r;
        }
    }
    
    if (count($results) == 0) {
        smarty_error(str_replace('{keyword}', $query, lang('no_results')));
    }
    
    $smarty->assign('results', $results);
} else {
    $smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => lang('search'), 'url' => '?act=search')));
    $smarty->assign('title', $settings[0]['dbname'].' &raquo; '.lang('search'));
}

?>