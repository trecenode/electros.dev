<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines to display the files in a
  * category.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.1
  * Copyright 2005 PHP Arena
  */

//Get the files in the category from the database


//Get the category info; we need the category name for page title and navbar
$category = $db->fetch(array(), 'cat', array(array('cat_id', '=', $_GET['id'])));
if (count($category) == 0) {
    smarty_error(lang('category_exist'));
}
$sort = explode('|', $category[0]['cat_sort']);
//Get the unpinned files
$files = $db->fetch(array(), 'files', array(array('file_catid', '=', $_GET['id']), array('file_pin', '=', 0)), 'file_'.$sort[0], $sort[1]);


if (!isset($_GET['start'])) { $start = 1; } else { $start = intval($_GET['start']); }

//Get pinned files
if ($start == 1) {
    $pinned = $db->fetch(array(), 'files', array(array('file_catid', '=', $_GET['id']), array('file_pin', '=', 1)));
    $smarty->assign('pinned', $pinned);
}

//Subcategory stuff. PITA!
$smarty->assign('hassubs', false);
if ($category[0]['cat_parent'] == 0) {
    $subs = $db->fetch(array(), 'cat', array(array('cat_parent', '=', $_GET['id'])));
    $smarty->assign('subcats', $subs);
    if (count($subs) > 0) { $smarty->assign('hassubs', true); $smarty->assign('subs', $subs); }
    $smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $category[0]['cat_name'], 'url' => '?act=category&amp;id='.$_GET['id'])));
    $smarty->assign('title', $settings[0]['dbname']." &raquo; ".$category[0]['cat_name']);
} else {
    $parent = $db->fetch(array(), 'cat', array(array('cat_id', '=', $category[0]['cat_parent'])));
    $smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $parent[0]['cat_name'], 'url' => '?act=category&amp;id='.$parent[0]['cat_id']), array('name' => $category[0]['cat_name'], 'url' => '?act=category&amp;id='.$_GET['id'])));
    $smarty->assign('title', $settings[0]['dbname']." &raquo; ".$parent[0]['cat_name']." &raquo; ".$category[0]['cat_name']);
}

foreach ($files as $k => $v) {
    $files[$k]['file_time'] = $files[$k]['file_time'] + ($settings[0]['timeoffset']*3600);
}

//Split the data into pages and get the data for the page we're viewing
list($f, $pages) = paginate($files, $start, $settings[0]['perpage']);

//Assign stuff to Smarty
$smarty->assign('files', $f);
$smarty->assign('pages', $pages);
$smarty->assign('id', $_GET['id']);
$smarty->assign('count', count($files)+count($pinned));

?>