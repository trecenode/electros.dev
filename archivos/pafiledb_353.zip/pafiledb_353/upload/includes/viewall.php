<?php

/**
  * paFileDB 3.5
  *
  * This file contains the routines to display all files.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.1
  * Copyright 2005 PHP Arena
  */

//Get the files from the database

$files = $db->fetch(array(), 'files', array(array('file_pin', '=', 0)));


if (!isset($_GET['start'])) { $start = 1; } else { $start = intval($_GET['start']); }

if ($start == 1) {
    $pinned = $db->fetch(array(), 'files', array(array('file_pin', '=', 1)));
    $smarty->assign('pinned', $pinned);
}

$smarty->assign('navbar', array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => lang('viewallfiles'), 'url' => '?act=viewall')));
$smarty->assign('title', $settings[0]['dbname']." &raquo; ".lang('viewallfiles'));

//Split the data into pages and get the data for the page we're viewing
list($f, $pages) = paginate($files, $start, $settings[0]['perpage']);

//Assign stuff to Smarty
$smarty->assign('files', $f);
$smarty->assign('pages', $pages);
$smarty->assign('count', count($files));

?>