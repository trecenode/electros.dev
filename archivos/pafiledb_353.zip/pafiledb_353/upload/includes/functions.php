<?php

/**
  * paFileDB 3.5
  *
  * This is the functions file for paFileDB. It contains
  * various functions used throughout the script.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */


/**
  * The init_smarty() function sets up the Smarty template
  * class by setting the variables required.
  *
  * Parameters:
  *  $smarty_skin: The current skin in use
  */ 
function init_smarty($smarty_skin)
{
    global $smarty;
    $smarty->template_dir = './skins/'.$smarty_skin.'/templates';
    $smarty->compile_dir = './skins/'.$smarty_skin.'/compile';
    $smarty->cache_dir = './skins/'.$smarty_skin.'/cache';
    $smarty->config_dir = array('./lang/', './skins/'.$smarty_skin.'/configs');
}


/**
  * smarty_error() will display an error using the skin's error
  * template. Then, it will exit execution of paFileDB.
  *
  * Parameters:
  *  $message: The error message to display
  */
function smarty_error($message)
{
    global $smarty;
    $smarty->assign('message', $message);
    $smarty->display('error.tpl');
    die();
}

/**
  * smarty_redirect() will display a message and then redirect
  * the user to the url after a few seconds.
  *
  * Parameters:
  *  $message: The message to show the user
  *  $url: The URL to redirect to. If blank, will redir to index.php
  *  $ext: set to true if the link is an external link. If false
  *   the paFileDB URL from the settings will be added to the URL,
  *   since the script will usually just pass in 'index.php?blah'
  *   as the URL. However, if the URL passed in is
  *   http://www.blah.com, you don't want the paFileDB URL added
  *   before it, so set $ext to true.
  */
function smarty_redirect($message, $url='index.php', $ext=false) {
    global $smarty, $settings;
    $smarty->assign('message', $message);
    if ($ext) {
        $smarty->assign('url', $url);
    } else {
        $smarty->assign('url', $settings[0]['dburl'].'/'.$url);
    }
    $smarty->display('redirect.tpl');
    exit();
}

/**
  * pafiledb_mail() will send an e-mail using the proper headers since
  * PHP's mail() does not use the right headers, sometimes causing
  * spam blockers to block the e-mail. The function will return true
  * or false depending if sending the mail was a success. Additonally,
  * it will add an entry to paFileDB's e-mail log containing the details
  * of the e-mail that was sent.
  *
  * This function taken from the php.net documentation comments for mail().
  * Thanks to whoever wrote it.
  *
  * Parameters:
  *  $fromname: Name of the sender
  *  $fromaddress: E-mail address of the sender
  *  $to: Recipients of the e-mail in a 2D array: 
       Ex: $to = array(array("name" => "foo", "address" => "foo@foobar.com"),
                       array("name" => "bar", "address" => "bar@foobar.com"));
  *  $subject: The subject of the e-mail
  *  $message: The body of the e-mail
  */
function pafiledb_mail($fromname, $fromaddress, $to, $subject, $message)
{
    global $db;
    //Copyright 2005 ECRIA LLC, http://www.ECRIA.com
    //Please use or modify for any purpose but leave this notice unchanged.
    $headers  = "MIME-Version: 1.0\n";
    $headers .= "Content-type: text/plain; charset=iso-8859-1\n";
    $headers .= "X-Priority: 3\n";
    $headers .= "X-MSMail-Priority: Normal\n";
    $headers .= "X-Mailer: php\n";
    $headers .= "From: \"".$fromname."\" <".$fromaddress.">\n";
    $toaddress = "";
    foreach ($to as $recip) {
        $toaddress .= $recip['name']." <".$recip['address'].">, ";
    }
    $toaddress = substr($toaddress, 0, strlen($toaddress)-2);
    $db->insert('emaillog', array(array('e_ip', $_SERVER['REMOTE_ADDR']),
                                  array('e_fromname', xhtml_convert($fromname)),
                                  array('e_fromaddress', xhtml_convert($fromaddress)),
                                  array('e_toaddress', xhtml_convert($toaddress)),
                                  array('e_headers', xhtml_convert($headers)),
                                  array('e_subject', xhtml_convert($subject)),
                                  array('e_date', time()),
                                  array('e_message', xhtml_convert($message))));
    return mail($toaddress, $subject, $message, $headers);
}

//It's 2 AM as I type this, I won't begin to fully explain the 2 functions
//below. If you really need to know what something does, post on our forums

/**
  * dropDown() will build HTML for the category dropdown menu.
  * 
  * Parameters:
  *  $cats: The category cache from the settings
  *  $onlyid: If true, the option values will be the cat ID. If false,
  *           be the URL to the category.
  */
function dropDown($cats, $onlyid = false) {
    global $smarty;
    $drop = '<select name="menu1" onChange="MM_jumpMenu(\'parent\',this,0)">'."\n";
    $drop .= '<option value="'.$_SERVER['REQUEST_URI'].'">'.lang('categories').'</option>';
    
    if (empty($cats)) {
        $drop .= '</select>';
        $smarty->assign('drop', $drop);
        return;
    }
    $a = unserialize($cats);
    foreach ($a as $b) {
        if ($b['sub']) {
            $drop .= '<option value="index.php?act=category&id='.$b['id'].'">--'.$b['name']."</option>\n";
        } else {
            $drop .= '<option value="index.php?act=category&id='.$b['id'].'">'.$b['name']."</option>\n";
        }
    }
    $drop .= '</select>';
    $smarty->assign('drop', $drop);
}


/**
  * rebuildDrop() will rebuild the category cache in the DB.
  * Takes no parameters and returns nothing. Simple, eh?
  * 
  */
function rebuildDrop() {
    global $db;
    $drop = array();
    $categories = $db->fetch(array(), 'cat', array(array('cat_parent', '=', 0)), 'cat_order', 'ASC');
    foreach ($categories as $k => $c) {
        $drop[] = array('name' => $c['cat_name'], 'id' => $c['cat_id'], 'sub' => false);
        $subs = $db->fetch(array(), 'cat', array(array('cat_parent', '=', $c['cat_id'])));
        foreach ($subs as $j => $s) {
            $drop[] = array('name' => $s['cat_name'], 'id' => $s['cat_id'], 'sub' => true);
        }
        
    }
    
    $db->update('settings', array(array('dropdown', serialize($drop))), array(array('id', '=', 1)));
}


/**
  * xhtml_convert() converts a string into an XHTML-compliant form.

  * The comma is also converted to help prevent SQL injections.
  * Function written by Andrew
  *
  * Parameters:
  *  $text: The text to convert
  */
function xhtml_convert($text) {
    $text = htmlentities($text, ENT_QUOTES);
    $text = str_replace(',', '&#44;', $text);
    $text = str_replace("\r", '', $text);
    $text = str_replace("\n", '<br />', $text);

    // Fix a small glitch in some versions of PHP
    if (htmlentities('&') == '&amp;amp;')
    {
        $text = str_replace('&amp;amp;', '&amp;', $text);
    }

    return $text;
}

/**
  * lang() will return a value from the language file.
  * This function does the same as $smarty->get_config_vars(),
  * but the PHP Arena developers are lazy and would rather type
  * 4 letters instead of 24.
  *
  * Parameters:
  *  $term: The term we want to get from the lang file
  */
function lang($term) {
    global $smarty;
    return $smarty->get_config_vars($term);
}

/**
  * check_input() will return false if one of the items in
  * the array passed into it (typically $_POST) is empty.
  *
  * Parameters:
  * $a: The array of values to check
  * $excep: Array of any exceptions to the empty 
  *  requirement. Function will not return false if one of these
  *  is empty. The values for this array are the keys, so if you
  *  pass in $_POST, and the form field 'url' can be empty, put 'url'
  *  in the $excep array. However, if there is a field in the exception
  *  that is empty, but another field that is empty and not in the
  *  exception, function will still return false.
  */
function check_input($a, $excep=array()) {
    foreach($a as $key => $val) {
        if (!is_int($val) && !is_array($val)) {
            $val = trim($val);
            if (empty($val) && !in_array($key, $excep)) { return false; }
        }
    }
    return true;
}

/**
  * get_file_list() will read the specified directory and return an
  * array of the files and folders in the directory.
  *
  * Parameters:
  *  $dir: The directory to search
  *  $mode: a (default): Return files and directories in the list
  *         f: Only return files in the list
  *         d: Only return directories in the list
  *  $ext: If true, function will strip file extensions
  */
function get_file_list($dir, $mode='a', $ext=true) {
    if ($handle = opendir($dir)) {
        $listing = array();
        while (false !== ($file = readdir($handle))) {
            if ($mode == 'a') {
                if ($file != '.' && $file != '..' && $file != '.DS_Store' && $file != 'index.html') {
                    if (is_file($dir.'/'.$file) && $ext) {
                        $fext = strrchr($file, '.');
                        if ($fext != false) {
                            $file = substr($file, 0, -strlen($fext));
                        }
                    }
                    $listing[] = $file;
                }
            }
            if ($mode == 'f') {
                if ($file != '.' && $file != '..' && is_file($dir.'/'.$file) && $file != '.DS_Store' && $file != 'index.html') {
                    if ($ext) {
                        $fext = strrchr($file, '.');
                        if ($fext != false) {
                            $file = substr($file, 0, -strlen($fext));
                        }
                    }
                    $listing[] = $file;
                }
            }
            if ($mode == 'd') {
                if ($file != '.' && $file != '..' && is_dir($dir.'/'.$file) && $file != '.DS_Store' && $file != 'index.html') {
                    $listing[] = $file;
                }
            }
        }
        closedir($handle);
    }
    return $listing;
} 

/**
  * xhtml_reverse() will undo xhtml_convert. This is used for
  * editing stuff, as textboxes don't like the & codes.
  *
  * Parameters:
  *  $text: The text to convert
  */
function xhtml_reverse($text) {
    $text = str_replace("<br />", "\n", $text);
    $text = str_replace('&#44;', ',', $text);
    $text = html_entity_decode($text, ENT_QUOTES);
    return $text;
}

/**
  * This function sperates given data into pages. Written by
  * Andrew, if you have any further questions, bother him ;)
  */ 
function paginate($data=array(), $start=1, $perpage=10, $groupby=5) {
    $start = intval($start) > 0 ? intval($start) : 1;
    $pages = ceil(count($data) / $perpage);
    $start = ($start >= $pages) ? $pages-1 : $start-1;
    $start = intval($start * $perpage);
    $stop = ($start + $perpage) >= count($data) ? count($data) : ($start + ($perpage-1));
    
    $newdata = array();

    for($x=0; $x < count($data); $x++)
    {
        if ($x < $start || $x > $stop) {}
        else
        {
            $newdata[] = $data[$x];
        }
    }
    $data = $newdata;
    unset($newdata);

    $groupby = ((1&$groupby) && ($groupby > 2)) ? $groupby : 3;
    $groupstart = ((($start / $perpage)+1) - (($groupby-1)/2));

    if ($groupstart < 2)
    {
        $groupstart = 2;
    }
    $groupstop = $groupstart + $groupby;

    if ($groupstop > ($pages-1))
    {
        $groupstop = ($pages-1);

    }

    if (($groupstop - $groupstart) <= $groupby)
    {
        $groupstart = $groupstop - $groupby;
    }

    if ($groupstart < 2)
    {
        $groupstart = 2;
    }

    $newpages = array();

    if (($start / $perpage) > 0)
    {
        $newpages[] = array('back', ($start / $perpage));
    }

    if (1 == (($start / $perpage)+1))
    {
        $newpages[] = array('[ 1 ]', 1);
    }
    else
    {
        $newpages[] = array(1, 1);
    }

    for($x = $groupstart; $x <= $groupstop; $x++)
    {
        if ($x == (($start / $perpage)+1))
        {
            $newpages[] = array('[ '.$x.' ]', $x);
        }
        else
        {
            $newpages[] = array($x, $x);
        }
    }

    if ($pages > 1)
    {
        if ($pages == (($start / $perpage)+1))
        {
            $newpages[] = array('[ '.$pages.' ]', $pages);
        }
        else
        {
            $newpages[] = array($pages, $pages);
        }
    }
    if (($start / $perpage)+1 < $pages) {
        $newpages[] = array('forward', ($start / $perpage)+2);
    }
    return array($data, $newpages);
}

?>