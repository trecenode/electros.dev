<?php

/**
  * paFileDB 3.5
  *
  * This file handles file mirrors.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

    

//Fetch the file info from the database
$file = $db->fetch(array(), 'files', array(array('file_id', '=', $_GET['id'])));
if (count($file) == 0) {

    smarty_error(lang('file_exist'));
}
$file = $file[0];
$smarty->assign('navbar',  array(array('name' => $settings[0]['dbname'], 'url' => ''), array('name' => $file['file_name'], 'url' => '?act=view&amp;id='.$file['file_id'])));
$smarty->assign('title', $settings[0]['dbname']." &raquo; ".$file['file_name']);
$mirrors = unserialize($file['file_mirrors']);
if (!is_array($mirrors)) { exit(); }
$smarty->assign('mirrors', $mirrors);
$smarty->assign('file', $file);

?>