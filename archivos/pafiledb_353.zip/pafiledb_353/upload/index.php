<?php

/**
  * paFileDB 3.5
  *
  * This is the master file for paFileDB. This is the only
  * page at this time that is designed to be run straight
  * from the browser.
  *
  * Author: Todd <http://www.phparena.net>
  * Version 3.5.3
  * Copyright 2005 PHP Arena
  */

if (file_exists('install')) { die("Please remove the install directory to use paFileDB!"); }
if (file_exists('upgrade')) { die("Please remove the upgrade directory to use paFileDB!"); }

//Start the execution timer
$starttime = microtime();	
$starttime = explode(" ",$starttime);
$starttime = $starttime[1] + $starttime[0];


//Require the important files so paFileDB isn't paUselessScript
require('./includes/smarty/Smarty.class.php');
require('./includes/functions.php');
require('./includes/db/mysql.php');

/*Get $act from the query string, set to main if $act is unset 
 (only time its unset is on the main page */
if (!isset($_GET['act'])) { $act = 'main'; } else { $act = $_GET['act']; }


//Load paFileDB settings into $settings array
$settings = $db->fetch(array(), 'settings');
$version = '3.5.3';

//This stops any l33t h4x0ring of paFileDB. Just an extra security measure
$allowed_acts = array('main', 'category', 'view', 'download', 'viewall', 'search', 'email', 'license', 'mirror', 'report');
if (!in_array($act, $allowed_acts))
{
    die("Invalid Action!");
}

//Get Smarty set up and load the right language file
$smarty = new Smarty();
$smarty->config_booleanize = false;
init_smarty($settings[0]['skin']);
$smarty->config_load('english.conf');
if ($settings[0]['lang'] != "english") { $smarty->config_load($settings[0]['lang'].'.conf'); }
$smarty->config_load('config.conf');
$smarty->assign('settings', $settings[0]);
$smarty->assign('act');
$smarty->assign('version', $version);
require('./includes/admin/auth.php');

//Require the file that actually does what we want
require('./includes/'.$act.'.php');

//Display the header
$smarty->display('header.tpl');

//Display the template for whatever page we're showing
$smarty->display($act.'.tpl');

//Calculate execution time
$endtime = microtime();
$endtime = explode(" ",$endtime);
$endtime = $endtime[1] + $endtime[0];
$stime = $endtime - $starttime;

dropDown($settings[0]['dropdown']);
//Send exec time and queries used to Smarty
$smarty->assign('debug_info', array(count($db->queries), round($stime,5)));

//Display the footer

$smarty->display('footer.tpl');
?>