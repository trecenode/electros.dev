<html>
<head>
<title>NosferatuSoft Libro De Visitas</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<script src="ajax.js"></script>
<div id="estilo"></div>
<?
echo "
<script>
function ordenar(){
	enlace('$cant',document.getElementById('orden').value);
	}
</script>";
?>
<div id="contenido">
<?
include("config.php");
include("clases_libro.php");
if(!$_GET["cant"]){
	echo "<script>enlace('0');</script>";
	}	
if(!$_GET["asdf"]){
?><br>
<div class="coment">
	<div class="texto">
		Deja tu comentario:<br>
		<input type="text" id="autor" value="tu nombre" style="width:180px;"><br>
<img src="caritas/bien.gif" onclick="caras('(Y)')" style='cursor:hand;'>
<img src="caritas/desepcion.gif" onclick="caras(':|')" style='cursor:hand;'>
<img src="caritas/enojado.gif" onclick="caras(':@')" style='cursor:hand;'>
<img src="caritas/feliz.gif" onclick="caras(':)')" style='cursor:hand;'>
<img src="caritas/fumar.gif" onclick="caras('[fumar]')" style='cursor:hand;'>
<img src="caritas/gino.gif" onclick="caras(';)')" style='cursor:hand;'>
<img src="caritas/lengua.gif" onclick="caras(':P')" style='cursor:hand;'>
<img src="caritas/llorando.gif" onclick="caras(':\'(')" style='cursor:hand;'>
<img src="caritas/ops2.gif" onclick="caras('[ups]')" style='cursor:hand;'>
<img src="caritas/pena.gif" onclick="caras(':$')" style='cursor:hand;'>
<img src="caritas/presumido.gif" onclick="caras('(H)')" style='cursor:hand;'>
<img src="caritas/risa.gif" onclick="caras(':D')" style='cursor:hand;'>
<input type="button" id="codigo" value="[n][/n]" title="[n]Texto en negritas[/n]" onclick="caras('[n]Texto en negritas[/n]')">
<input type="button" id="codigo" value="[s][/s]" title="[s]Texto subrallado[/s]" onclick="caras('[s]Texto subrallado[/s]')">
<input type="button" id="codigo" value="[c][/c]" title="[c]Texto en cursiva[/c]" onclick="caras('[c]Texto en cursiva[/c]')">
<br>
		<textarea id="cuerpo" cols="30" rows="5" style="width:400px; height:120;">tu comentario</textarea><br>
		<input type="button" id="sub" value="Dejar Comentario" onclick="firmar()">
	</div><br>
<?
	}
?>
</body>
</html>
