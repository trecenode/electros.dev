function ajax_objeto(){
	try{
		ajax = new ActiveXObject("Msxml2.XMLHTTP");
		}
	catch(e){
		try{
			ajax = new ActiveXObject("Microsoft.XMLHTTP");
			}
		catch(E){
				ajax = false;
				}
			}
	if(!ajax && typeof XMLHttpRequest!='undefined'){
		ajax = new XMLHttpRequest();
	}
	return ajax;
}
function firmar(){
	var msg_error="";
	var cuerpo = document.getElementById('cuerpo').value;
	var autor = document.getElementById('autor').value;
	if(!cuerpo || cuerpo=="tu comentario"){
		msg_error+="El mensaje no est� escrito\n";
		}
	if(!autor || autor=="tu nombre"){
		msg_error+="El autor no est� escrito";
		}
	if(msg_error!=""){
		alert(msg_error);
		return false;
		}
	ajax=ajax_objeto();
	ajax.open("POST", "firmar.php",true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById('contenido').innerHTML=ajax.responseText+document.getElementById('contenido').innerHTML;
			document.getElementById('cuerpo').disabled = true;
			document.getElementById('autor').disabled = true;
			document.getElementById('sub').disabled = true;
			alert("Gracias por tu Comentario ;-)");
			}
		}
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	ajax.send("autor="+autor+"&cuerpo="+cuerpo)	
	}
function caras(q){
	document.getElementById("cuerpo").value+=q;
	}

function enlace(gets,por){
	var ordenar="";
	if(por!=""){
		ordenar = "&por="+por;
		}
	else{
		ordenar="";
		}
	ajax=ajax_objeto();
	ajax.open("GET", "libro.php?cant=" + gets + "&asdf=asdf"+ordenar,true);
	ajax.onreadystatechange=function(){
		if(ajax.readyState==4){
			document.getElementById('contenido').innerHTML = ajax.responseText;
			}
		}
	ajax.setRequestHeader("Content-Type", "text/html; charset=windows-1252");
	ajax.send(null);	
	}