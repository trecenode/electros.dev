<?//nosfertuSoft.com.ar
include("config.php");
class firmar{
	function guardar(){
		$hoy = date("d/m/y");
		$cuerpo = trim(htmlspecialchars($_POST["cuerpo"]));
		$autor = trim(htmlspecialchars($_POST["autor"]));
		$caritas = Array(
			"(Y)" => "bien",
			":|" => "desepcion",
			":@" => "enojado",
			":)" => "feliz",
			"[fumar]" => "fumar",
			";)" => "gino",
			":P" => "lengua",
			":\'(" => "llorando",
			"[ups]" => "ops2",
			":$" => "pena",
			"(H)" => "presumido",
			":D" => "risa");
		$codigo = Array(
			"[n]" => "<b>",
			"[N]" => "<b>",
			"[c]" => "<i>",
			"[C]" => "<i>",
			"[s]" => "<u>",
			"[S]" => "<u>",
			"[/n]" => "</b>",
			"[/N]" => "</b>",
			"[/c]" => "</i>",
			"[/C]" => "</i>",
			"[/s]" => "</u>",
			"[/S]" => "</u>");
		foreach($caritas as $comando => $src){
			$cuerpo = str_replace($comando,"<img src=\"caritas/$src.gif\">",$cuerpo);
			}
		foreach($codigo as $comando => $html){
			$cuerpo = str_replace($comando,$html,$cuerpo);
			}
		@mysql_query("insert into ns_libro (autor,cuerpo,fecha) values ('$autor','$cuerpo','$hoy')") or die(mysql_error());
?>
<div class="coment">
	<span class="datos">Escrito por <?=$autor?> (<?=$hoy?>):</span>
	<div class="texto">
		<?=nl2br($cuerpo)?></b></u></i>
	</div>
</div><br>
<?	
		}
	}
$firma = new firmar();
$firma->guardar();
?>
