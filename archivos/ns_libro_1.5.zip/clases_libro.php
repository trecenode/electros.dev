<?
class ordenar{
	var $defecto = "fecha";
	var $sentencia;
	function ob_sentencia($que){
		$this->que = $que;
		$this->que = htmlspecialchars(trim($this->que));
		$this->que = str_replace("'","",$this->que);
		switch($this->que){
			default:
				$this->sentencia = "select * from ns_libro order by id desc";
				$this->selecion["id_desc"] = "selected";
			break;
			case "id_asc":
				$this->sentencia = "select * from ns_libro order by id asc";
				$this->selecion["id_asc"] = "selected";
			break;
			case "autor_desc":
				$this->sentencia = "select * from ns_libro order by autor desc";
				$this->selecion["autor_desc"] = "selected";
			break;
			case "autor_asc":
				$this->sentencia = "select * from ns_libro order by autor asc";
				$this->selecion["autor_asc"] = "selected";
			break;
			}
		}
	}
class paginar{
	var $cuantos = 10; 	//cuantos mensajes por p�gina...
	var $enlace_sig;
	var $enlace_ant;
	var $sepa = 0;
	function mostrar($que,$sentencia){
		$cant = $que;
		if(!$que){	
			$cant = 0; 
			}
		$sig = $cant + $this->cuantos;
		$ant = $cant - $this->cuantos;
		$temp = "$sentencia limit $cant,".$this->cuantos;
		$por = $_GET["por"] ? $_GET["por"] : "";
		$this->enlace_ant = $cant<=0 ? "" : "<a href=\"javascript: enlace('$ant','$por')\">$this->cuantos Anteriores<a/>";
		$temp2 = @mysql_query($temp) or die(mysql_error());
		while($leer = mysql_fetch_array($temp2)){
?>
<div class="coment">
	<span class="datos">Escrito por <?=$leer["autor"]?> (<?=$leer["fecha"]?>):</span>
	<div class="texto">
		<?=nl2br($leer["cuerpo"])?></b></u></i>
	</div>
</div><br>
<?
			$this->sepa++;
			}
		$this->enlace_sig = $this->sepa!=$this->cuantos ? "" : "<a href=\"javascript: enlace('$sig','$por')\">$this->cuantos siguientes</a>";

		}
	
	}
	$get_por = $_GET["por"];
	$get_por = str_replace("'","",$get_por);
	$ordenar = new ordenar();
	$ordenar->ob_sentencia($get_por);
	$paginar = new paginar();
	$paginar->mostrar($_GET["cant"],$ordenar->sentencia);
?>
<div id="enlaces">
<div class="ant">
<?=$paginar->enlace_ant?></div>
<div class="central">
<select id="orden" onchange="ordenar()">
	<option value="id_desc" <?=$this->selecion["id_desc"];?>> Id (...3,2,1)</option>
	<option value="id_asc" <?=$this->selecion["id_asc"];?>> Id (1,2,3...)</option>
	<option value="autor_desc" <?=$this->selecion["autor_desc"];?>> Autor (Z - A)</option>
	<option value="autor_asc" <?=$this->selecion["autor_asc"];?>> Autor (A - Z)</option>
</select></div>
<div class="sig"><?=$paginar->enlace_sig?></div>
</div></div></div>