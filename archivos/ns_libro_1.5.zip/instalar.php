<?//nosfertuSoft.com.ar
include("config.php");
$ns = "CREATE TABLE ns_libro(
id int auto_increment NOT NULL,
autor char(50) NOT NULL,
cuerpo longtext NOT NULL,
fecha char(25) NOT NULL,
PRIMARY KEY (id) 
		);";
mysql_query($ns) or die(mysql_error());
echo "se instalo correctamente el libro de vistias ahora borrar instalar.php";
?>