<?
//nosfertuSoft.com.ar
$mysql_host = "localhost"; //tu host
$mysql_usuario = "";
$mysql_contrasena = "";
$mysql_db = ""; //tu bd
$conectar = @mysql_connect($mysql_host,$mysql_usuario,$mysql_contrasena) or die("Los d�tos para conectar con la base de datos son incorrectos.") ;
mysql_select_db($mysql_db,$conectar) or die("No existe la base de datos...") ;
?>
