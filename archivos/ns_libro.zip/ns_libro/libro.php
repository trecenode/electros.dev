<?
//NosferatuSoft
//www.nosferatusoft.ya.st
$nombre = $HTTP_POST_VARS["nombre"];
$correo = $HTTP_POST_VARS["correo"];
$comentario = $HTTP_POST_VARS["comentario"];
$comentario = str_replace("\n","<br>",$comentario);
$nombre = str_replace("<","&lt;",$nombre);
$correo = str_replace("<","&lt;",$correo);
$comentario = str_replace("<","&lt;",$comentario);
$comentario = str_replace(":)","<img src=\"caritas/sonrisa.gif\">", $comentario);
$comentario = str_replace(":(","<img src=\"caritas/triste.gif\">", $comentario);
$comentario = str_replace(";)","<img src=\"caritas/ginando.gif\">", $comentario);
$comentario = str_replace("8)","<img src=\"caritas/ojotes.gif\">", $comentario);
$comentario = str_replace(":P","<img src=\"caritas/lengua.gif\">", $comentario);
$comentario = str_replace(":D","<img src=\"caritas/risa.gif\">", $comentario);
$comentario = str_replace("8-)","<img src=\"caritas/cool.gif\">", $comentario);
$comentario = str_replace(":'(","<img src=\"caritas/llorando.gif\">", $comentario);
$comentario = str_replace(":@","<img src=\"caritas/enojado.gif\">", $comentario);
$comentario = str_replace(":S","<img src=\"caritas/duda.gif\">", $comentario);
$comentario = str_replace("(Y)","<img src=\"caritas/bien.gif\">", $comentario);
$comentario = str_replace("(B)","<img src=\"caritas/mal.gif\">", $comentario);
$comentario = str_replace("[b]","<b>",$comentario);
$comentario = str_replace("[/b]","</b>",$comentario);
$comentario = str_replace("[u]","<u>",$comentario);
$comentario = str_replace("[/u]","</u>",$comentario);
$comentario = str_replace("[i]","<i>",$comentario);
$comentario = str_replace("[/i]","</i>",$comentario);
$comentario_nuevo="
<table width='500' cellspacing='0' border='1' bordercolor='000000'>
	<tr>
		<td>
		<b>Escrito por:</b> <a href='mailto:$correo'>$nombre</a><br>
		$comentario
		</td>
	</tr>
</table><p>";
$firmar="
<form name='libro' action='libro.php?accion=guardar' onsubmit='return checar()' method='post'>
<b>Nombre:</b><br>
<input type='text' name='nombre' size='40'><br>
<b>Correo:</b><br>
<input type='text' name='correo' size='40'><br>
<b>comentario:</b><br>
<table width='345' border='0' cellpadding='0' cellspacing='0' summary=''>
	<tr>
		<td>
<input type='button' value='[b][/b]' onclick='negritas()'>  <input type='button' value='[i][/i]' onclick='cursiva()'>  <input type='button' value='[u][/u]' onclick='subrayado()'>  
		</td>
	</tr>
</table>
<textarea name='comentario' cols='40' rows='8'>
</textarea><br>
<script>
function negritas(){
libro.comentario.value = libro.comentario.value + '[b] [/b]';i++;}
function cursiva(){
libro.comentario.value = libro.comentario.value + '[i] [/i]';b++;}
function subrayado(){
libro.comentario.value = libro.comentario.value + '[u] [/u]';c++}
function carita(object,cara){
libro.comentario.value =  libro.comentario.value + cara;
}
function carita(object,cara){
libro.comentario.value =  libro.comentario.value + cara;
}
</script>
</script>
<a href=\"javascript: carita(this,':)')\"><img src=\"caritas/sonrisa.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':(')\"><img src=\"caritas/triste.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,';)')\"><img src=\"caritas/ginando.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,'8)')\"><img src=\"caritas/ojotes.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':P')\"><img src=\"caritas/lengua.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':D')\"><img src=\"caritas/risa.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,'8-)')\"><img src=\"caritas/cool.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':-(')\"><img src=\"caritas/llorando.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':@')\"><img src=\"caritas/enojado.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,':S')\"><img src=\"caritas/duda.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,'(Y)')\"><img src=\"caritas/bien.gif\" border=\"0\"></a>
<a href=\"javascript: carita(this,'(B)')\"><img src=\"caritas/mal.gif\" border=\"0\"></a><br>
<input type='submit' value='Firmar'>
</form>
<script>
function checar(){
if (libro.nombre.value==false){
	alert('el nombre no esta escrito');
	return false;
	}
if (libro.correo.value==false){
	alert('el correo no esta escrito');
	return false;
	}
if (libro.comentario.value==false){
	alert('el comentario no est� escrito');
	return false;
	}
}
</script>
";
	if ($accion==""){
		include ("libro.txt");
		}
		if ($accion=="firmar"){
			echo "$firmar";
			}
		if ($accion=="guardar"){
			$leer = file_get_contents("libro.txt");
			$nuevo = "$comentario_nuevo$leer";
			$abrrir = fopen("libro.txt","w+");
			fwrite($abrrir, $nuevo);
			fclose($abrrir);
			echo "Gracias por firmar el libro<br>
				<a href='libro.php'>Regresar al libro</a>";
			}
?>