<script language=JavaScript>
<!--
////////////////////////////////////////////////////////////////////////////
// Source Code Encrypter v1.0                                            //
//////////////////////////////////////////////////////////////////////////
//                                                                     // 
// This JavaScript can be freely used as long as this message         //
// stays here in the header of the script. Any modifications         //
// and bugs found (and fixed) are appreciated.                      //
// Script submitted/featured on shortydesigns.gratishost.com       //
// Visit http://www.shortydesigns.tk for source code              //
// SHoRtY, admin@barrioantioquia.tk                              //
//////////////////////////////////////////////////////////////////

var i=0;
var ie=(document.all)?1:0;
var ns=(document.layers)?1:0;

function initStyleElements() /* Styles for Buttons Init */
{
var c = document.pad;
if (ie)
{
//c.text.style.backgroundColor="#DDDDDD";
c.compileIt.style.backgroundColor="#C0C0A8";
c.compileIt.style.cursor="hand";
c.select.style.backgroundColor="#C0C0A8";
c.select.style.cursor="hand";
c.view.style.backgroundColor="#C0C0A8";
c.view.style.cursor="hand";
c.retur.style.backgroundColor="#C0C0A8";
c.retur.style.cursor="hand";
c.clear.style.backgroundColor="#C0C0A8";
c.clear.style.cursor="hand";
}
else return;
}

/* Buttons Enlightment of "Compilation" panel */
function LightOn(what)
{
if (ie) what.style.backgroundColor = '#E0E0D0';
else return;
}
function FocusOn(what)
{
if (ie) what.style.backgroundColor = '#EBEBEB';
else return;
}
function LightOut(what)
{
if (ie) what.style.backgroundColor = '#C0C0A8';
else return;
}
function FocusOff(what)
{
if (ie) what.style.backgroundColor = '#DDDDDD';
else return;
}
/* Buttons Enlightment of "Compilation" panel */

function generate() /* Generation of "Compilation" */
{
code = document.pad.text.value;
if (code)
{
document.pad.text.value='Encryptando........por favor espere!';
setTimeout("compile()",1000);
}
else alert('First enter something to compile and then press CompileIt')
}
function compile() /* The "Compilation" */
{
document.pad.text.value='';
compilation=escape(code);
document.pad.text.value="<script>\n<!--\ndocument.write(unescape(\""+compilation+"\"));\n//-->\n<\/script>";
i++;
if (i=1) alert("Pagina Encryptada 1 vez!");
else alert("Pagina Encryptada "+i+" veces!");
}
function selectCode() /* Selecting "Compilation" for Copying */
{
if(document.pad.text.value.length>0)
{
document.pad.text.focus();
document.pad.text.select();
}
else alert('Nada para seleccionar!')
}
function preview() /* Preview for the "Compilation" */
{
if(document.pad.text.value.length>0)
{
pr=window.open("","Preview","scrollbars=1,menubar=1,status=1,width=700,height=320,left=50,top=110");
pr.document.write(document.pad.text.value);
}
else alert('Nada para ensayar!')
}
function uncompile() /* Decompiling a "Compilation" */
{
if (document.pad.text.value.length>0)
{
source=unescape(document.pad.text.value);
document.pad.text.value=""+source+"";
}
else alert('Debes escribir algo para desencryptar!')
}
// -->
</script>
            </p>
            <p> 
              <!-- Compilation Panel -->
            </p>
            <form method=post name=pad align=center>
              <textarea rows=11 name=text cols=58 style="background-color:#EBEBEB;width:95%"></textarea>
              <br>
              <br>
              <input type=button value=Encryptar name=compileIt onClick=generate() onMouseOver=LightOn(this) onMouseOut=LightOut(this)>
              <input type=button value=Seleccionar name=select onClick=selectCode() onMouseOver=LightOn(this) onMouseOut=LightOut(this)>
              <input type=button value=Preview name=view onClick=preview() onMouseOver=LightOn(this) onMouseOut=LightOut(this)>
              <input type=button value=descomprimir name=retur onClick=uncompile() onMouseOver=LightOn(this) onMouseOut=LightOut(this)>
              <input type=reset value=Clear name=clear onMouseOver=LightOn(this) onMouseOut=LightOut(this)>
            </form>
            <!-- Compilation Panel -->
<br>
              <font size="1" face="Verdana, Arial, Helvetica, sans-serif" color="#333333"><br>
              Script by :</font><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
              <font color="#333333">Shortydesigns.tk</font></font>
            <p>&nbsp; </p></td>
        </tr>
      </table></td>
  </tr>
</table>