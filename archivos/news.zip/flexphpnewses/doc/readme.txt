FlexPHPNews is a simple, free and open source website news admin system. You can add multi-level sub-categories and upload pictures for the news. All the text in this program is put in one file. Once you edit this file, you can generate a new language version or customize the text in your program. Users can search the contents of the news by keywords and rate for the news.

Before you install this system, please make sure that you have php and mysql installed.
1. Please make sure that your const.inc.php and /photo/ is writable. 
2. Run /admin/install.php. Set database username and password, delete install.php and installfinish.php.
3. /admin/ is the admin program. You can rename it for the sake of security.

We also offer customization service. If you want to add new functions to your program, or want to give your program a new look and feel, please let us know your need.The most important, we charge you the incredible low price--only $5/h. (flexcustom@china-on-site.com) Meanwhile,if you have other project like website design, you can also outsource it to us.We offer the best service and the lowest price. ( outsource@china-on-site.com)

For more information, please visit: http://www.china-on-site.com/flexphpnews/

Other free scripts made by me:
http://www.china-on-site.com/flexphpsite/other.php
