<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<form enctype="multipart/form-data" action="<?PHP echo $PHP_SELF ?>" 
method="post">
<div align="left">
<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
Enviar un archivo: 
<input name="userfile" type="file">
<input type="submit" name="submit" value="Enviar">
</div>
</form>
<?PHP 

// copy to this directory 
$dir="./"; 

// copy the file to the server 
if (isset($submit)){ 

if (!is_uploaded_file ($userfile)){ 

echo "<b>$userfile_name</b> ERROR DE ARCHIVO !!"; 
} 

// check whether it has been uploaded 
if (is_uploaded_file ($userfile)){ 
move_uploaded_file($userfile,$dir.$userfile_name) ;} 

echo "Archivo correctamente copiado !! <a href=\"$userfile_name\" target=\"_blank\" >abrirlo</a>"; 
} 

?>
<br>
<br>
<?
//definimos el path de acceso
$path="./";

//instanciamos el objeto
$dir=dir($path);

//Mostramos las informaciones
echo "Directorio ".$dir->path.":<br><br>";

while ($elemento = $dir->read())
{
echo $elemento."<br>";
}
//Cerramos el directorio
$dir->close();
?></body>
</html>
