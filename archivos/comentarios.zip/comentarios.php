 <?
 /*********************************************************/
 /***    Adaptacion del minichat de electros a un      ***/
 /***            script de comentarios                ***/
 /*************   por Nacho martinez     ***************/
 /********** http://ringoweb.webcindario.com **********/
 /****************************************************/
 // Mensajes a mostrar (0 para mostrar todos)
$mostrar = 10 ;
// Maximo de caracteres por nick
$max_nick = 20 ;
// Maximo de caracteres por mensaje
$max_mensaje = 260 ;
// Altura de la tabla de mensajes (cuando los mensajes mostrados rebasan la altura marcada
// aparece una barra de desplazamiento) 
$altura = 100 ;
//*******************************
//*** Fin de la configuraci�n ***
//*******************************

// *** Guardar mensaje ***
/* debes crear el archivo comentarios.txt */
if($enviar) {
$comentario = fopen("comentarios.txt",a) ;
fwrite($comentario,"\n<b>[$nick]</b> $mensaje") ;
fclose($comentario) ;
}
?>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="../style.css">
<style>
.mensaje {
border: #33cccc 1 solid ;
background: #ffffff ;
}
/*** Formulario ***/
.formulario {
font-size: 8pt ;
border: #33cccc 1 solid ;
background: #ffffff ;
color: #000000 ;
font-weight: bold ;
text-align: center ;
}
</style>
</head>
<body>
<div style="height: <? echo $altura ?> ; overflow: auto">
<?
// *** Mostrar los mensajes ***
/* debes crear el archivo comentarios.txt */
$mensajes = file("comentarios.txt") ;
$total = count($mensajes) ;
if($total < $mostrar || $mostrar == 0) {
$maximo = 0 ;
}
else {
$maximo = $total - $mostrar ;
}
while($total > $maximo) {
$total-- ;
$mensaje = $mensajes[$total] ;
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="mensaje">
<tr>
<td>
<? echo $mensaje ?>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?
}
?>
</div>
<script>
function revisar(campo) {
if(campo.value=='Tu nick') { campo.value='' ; }
}
function validar() {
if(formulario.nick.value == '' || formulario.nick.value == 'Tu nick') { alert('Debes escribir un nick') ; return false ; }
if(formulario.mensaje.value == '' || formulario.mensaje.value == 'Tu mensaje') { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<div align="center">
<form name="formulario" method="post" action="<? echo $PHP_SELF?>" onsubmit="return validar()">
<input type="text" name="nick" size="10" maxlength="<? echo $max_nick ?>" value="Tu nick" onfocus="revisar(this)" class="formulario"><br>
<b><font color="cc3300">.::Tu mensaje::.</font></b><br>
<textarea name="mensaje" size="20" rows="4" cols="20" maxlength="<? echo $max_mensaje ?>" class="formulario"></textarea>
<br>
<input type="submit" name="enviar" value="Enviar" class="formulario">
  </form>
</div>
</body>
</html>
