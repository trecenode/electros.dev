CREATE TABLE libro (
  ID int(5) NOT NULL auto_increment,
  name text NOT NULL,
  email text NOT NULL,
  comments text NOT NULL,
  time datetime NOT NULL default '0000-00-00 00:00:00',
  ip text,
  PRIMARY KEY  (ID)
)
