<?php
//Configura tus datos de acceso al tu BD 
$DBhost = "localhost";   // servidor
   $DBuser = "root";            // usuario base
   $DBpass = "";            // contrase�a del host
   $DBName = "libro";            // nombre de la base de datos
   $table = "libro";
  $DBConn = mysql_connect($DBhost,$DBuser,$DBpass) or die("Error  " .mysql_error());
?> 