<style type="text/css">
<!--
body {
	background-color: #B9CEC0;
}
.Estilo5 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FFFFFF; }
.Estilo6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Estilo8 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; color: #FF0000; }
-->
</style>
<?php
   $DBhost = "localhost";   // servidor
   $DBuser = "";            // usuario base
   $DBpass = "";            // contrase�a del host
   $DBName = "";            // nombre de la base de datos
   $table = "libro";
  $DBConn = mysql_connect($DBhost,$DBuser,$DBpass) or die("Error  " .mysql_error());
   // seleccion de MySQL servidor
  mysql_select_db($DBName, $DBConn) or die("Error en el libro de visitas: " . mysql_error());
  
//  $sql="SELECT * FROM".$table."ORDER BY time DESC";
$sql="SELECT * FROM $table ORDER BY time DESC";

?>
<table width="728" border="1" align="center">
  <tr>
    <td width="51"><div align="center" class="Estilo8">Id</div></td>
    <td width="154"><div align="center" class="Estilo8">nombre</div></td>
    <td width="145"><div align="center" class="Estilo8">email</div></td>
    <td width="180"><div align="center" class="Estilo8">comentario</div></td>
    <td width="65"><div align="center" class="Estilo8">tiempo</div></td>
    <td width="93"><div align="center" class="Estilo8">Ip</div></td>
  </tr>
  <?php
  $rs=mysql_query($sql);
  while($campo=mysql_fetch_row($rs))
  {
  ?>
  
  <tr>
    <td><?php echo $campo[0];?>
    <div align="center"></div></td>
    <td><?php echo $campo[1];?></td>
    <td><?php echo $campo[2];?></td>
    <td><?php echo $campo[3];?></td>
    <td><?php echo $campo[4];?></td>
    <td><?php echo $campo[5];?></td>
	<?php
	}
	?>
  </tr>
</table>
<p class="Estilo6"> aver si e hace un poco de marcketing mi web www.abancaycito.tk </p>
<p>&nbsp; </p>
