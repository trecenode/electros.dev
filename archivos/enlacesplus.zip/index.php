<title>Enlacesplus</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>

<div class="t1">Enlacesplus<br>
</div>
<table width='50%' border='0' cellpadding='0' cellspacing='0' align='center' >
  <tr> 
  <td width="25%"></td>
  <td width="25%"></td>
  </tr>
  <tr> 
    <?
//definimos el path de acceso
$path = ".";
//abrimos el directorio
$dir = opendir($path);
//Mostramos las informaciones
while ($elemento = readdir($dir))
{

if (($i % 2) == 0) {
echo "</tr>\n";
}
if(is_dir($elemento)&&$elemento!==".."&&$elemento!==".."){
// remplazamos . por principal en las carpetas
$elemento2 = $elemento ;
$elemento2 = str_replace(".","principal",$elemento);
?>
    <td height='7' ><a href="index.php?secciones=<? echo "$elemento/"; ?>" ><img src="carpeta.gif" border="0"> 
      <? echo $elemento2 ?></a></td>
    <?
$i++;
}
}
//Cerramos el directorio
closedir($dir);
?>
  </tr>
</table>
<br>
<br>
Para agregar enlaces debes ser un usuario habitual. Para enviar un enlace pulsa 
<a href="index.php?archivon=<? echo $secciones ?>nuevo%20%20descripcionamp&secciones=<? echo $secciones ?>">aqu�</a>.<br>
Si eres administrador o un usuario privilegiado y deseas crear secciones pulsa 
<a href="index.php?directorio=<? echo $secciones ?>nuevo%20%20directorio&secciones=<? echo $secciones ?>">aqu&iacute;.</a><br>
<p> <b>Categor�a:</b> 
  <?
// Nombre del archivo
if($secciones != "") {
$secciones2 = str_replace("/","",$secciones);
echo "$secciones2";
}
else 
{ 
echo "principal";
}
?>
  <br>
  <br>
  <b>Total de enlaces:</b> 
  <?
// abrimos el directorio
if($secciones == "") { $secciones6 = "." ; }
if($secciones != "") { $secciones6 = "$secciones" ; }
$dirdd = opendir("$secciones6");
while ($elemento = readdir($dirdd)) {
// leemos solo los que tengan ese tipo de extension
$elementodd = strtolower($elemento); 
if ((strpos($elementodd, ".txt") > 1)) 
// mostramos el total de ficheros
$idd++;
}
echo $idd ;
?>
  | <a href="index.php">Volver</a><br>
  <br>
<tr> 
    
  <td width="14%" valign="top"> 
     <?php
// Script 'descargasplus' realizado  por elcidop en colaboracion con $$felipe$$
/// Web del autor: wwww.phpmysql.tk www.elcidop.com wwww.elcidop.webcindario.com
if ($a) {
$fichero = $a ;
$fp=@fopen("$fichero.dat","r");
$numero=@fread($fp,@filesize("$fichero.dat"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.dat", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

echo "a:$a";
include ("$a.php");
if(file_exists("$a.zip")) { echo "<script>location='$a.zip'</script>"; }
if($idurl != "no") { echo "<script>location='$idurl'</script>"; }
}
// inicio path
if($secciones != "" ) {
$secciones = "$secciones";
}
else {
$secciones = "./";
}
// fin path
								 // Le damos valor a las variables de configuraci�n
 $Config['Path'] = "$secciones"; 		// Directorio donde stan los archivos a mostrar.
 $Config['Show'] = 20; 			// Numero de archivos a mostrar por p�ginas.

 $Show['20 Anteriores'] = 0;		// Por defecto no se mostrara 10 Anteriores
 $Show['20 Siguientes'] = 0;		// Por defecto no se mostrara 10 Siguientes
 
 if ($c == "") $c = 0;			// Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
 $dir = @opendir($Config['Path']); 		// Abrimos el directorio donde estan los archivos
 $Plus = $c;					// Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

 while ($c > 0 && $elemento = @readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
 {
  $Show['20 Anteriores'] = 1;
  $c--;
 }

 $Counter = 0;			// Ponemos a 0 el contador

 // Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
 if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
 }
 
 // Mostramos el numero de archivos que se tienen que mostrar por p�gina.
 while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
 {
  $Counter++;
  
  $elemento1 = strtolower($elemento); 
  
  if (strpos($elemento1, ".txt") > 1) {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".txt","",$elemento); 
?> <table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#000000">
  <tr>

    <td bordercolor="#dddddd" bgcolor="#dddddd"><table width='100%' border='0' cellpadding='3' cellspacing='0' style='border: #000000 1 solid ; background: #dddddd'>
            <tr> 
              <td width='97%' height="63"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="80%"><a href='<?
if($c == "6") {
echo "$datos[urlsitio]" ;
}
else {
echo "descargas.php?e=$datos[id]" ;
}
?>' target='<?
if($c == "6") {
echo "_self" ;
}
else {
echo "_blank" ;
}
?>'><img src="html.gif" alt="" width="16" height="16" border="0"></a> <a href="index.php?a=<? echo $secciones ?><?php echo $elemento2 ?>&secciones=<? echo $secciones ?>" target="_blank" ><? echo $elemento2 ?></a><br> 
                      <?
// Buscamos si el archivo existe y lo leemos
// $codigo seria el contenido del archivo en si
if(file_exists("$secciones$elemento2.txt")) {  
$archi = "$secciones$elemento2.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// bbcode o codigo especial, este codigo lo que hace
// es sustituir determinadas expresiones de letras
// por codigo html seguro
// para desactivarlo pon if ($bbcode == "on" ) {
// index.php?tutorial=aaa&bbcode=on
if ($bbcode != "off" ) {
$codigo = str_replace("[b]","<b>",$codigo) ;
$codigo = str_replace("[/b]","</b>",$codigo) ;

$codigo = str_replace("[azul]","<font color=blue>",$codigo) ;
$codigo = str_replace("[/azul]","</font>",$codigo) ;
$codigo = str_replace("[red]","<font color=red>",$codigo) ;
$codigo = str_replace("[/red]","</font>",$codigo) ;
$codigo = str_replace("[u]","<u>",$codigo) ; 
$codigo = str_replace("[/u]","</u>",$codigo) ; 
$codigo = str_replace("[s]","<strike>",$codigo) ; 
$codigo = str_replace("[/s]","</strike>",$codigo) ; 
$codigo = str_replace("[sup]","<sup>",$codigo) ; 
$codigo = str_replace("[/sup]","</sup>",$codigo) ; 
$codigo = str_replace("[sub]","<sub>",$codigo) ; 
$codigo = str_replace("[/sub]","</sub>",$codigo) ; 
$codigo = str_replace("[left]","<p align=left>",$codigo) ; 
$codigo = str_replace("[/left]","</p>",$codigo) ; 
$codigo = str_replace("[center]","<p align=center>",$codigo) ;
$codigo = str_replace("[/center]","</p>",$codigo) ;
$codigo = str_replace("[right]","<p align=right>",$codigo) ;
$codigo = str_replace("[/right]","</p>",$codigo) ;
// Inicio caretos : por defecto desactivados
// ya que esta demostrado que puede interferir con colorear el codigo
// para activarlos permanetemente pon if ($caretos != "off" ) {
if ($caretos == "on" ) {
$codigo = str_replace("[[","",$codigo) ;
$codigo = str_replace("]]","",$codigo) ;
$codigo = str_replace(":D","[[alegre.gif]]",$codigo) ;
$codigo = str_replace(":8","[[asustado.gif]]",$codigo) ;
$codigo = str_replace(":P","[[burla.gif]]",$codigo) ;
$codigo = str_replace(":S","[[confundido.gif]]",$codigo) ;
$codigo = str_replace(":(1","[[demonio.gif]]",$codigo) ;
$codigo = str_replace(":(2","[[demonio2.gif]]",$codigo) ;
$codigo = str_replace(":?","[[duda.gif]]",$codigo) ;
$codigo = str_replace(":-(","[[enojado.gif]]",$codigo) ;
$codigo = str_replace(";)","[[guino.gif]]",$codigo) ;
$codigo = str_replace(":'(","[[llorar.gif]]",$codigo) ;
$codigo = str_replace(":lol","[[lol.gif]]",$codigo) ;
$codigo = str_replace(":M","[[moda.gif]]",$codigo) ;
$codigo = str_replace(":|","[[neutral.gif]]",$codigo) ;
$codigo = str_replace(":)","[[risa.gif]]",$codigo) ;
$codigo = str_replace(":-)","[[sonrisa.gif]]",$codigo) ;
$codigo = str_replace(":R","[[sonrojado.gif]]",$codigo) ;
$codigo = str_replace(":O","[[sorprendido.gif]]",$codigo) ;
$codigo = str_replace(":(","[[triste.gif]]",$codigo) ;
$codigo = str_replace("[[","<img src=\"caretos/",$codigo) ;
$codigo = str_replace("]]","\" width=\"15\" height=\"15\">",$codigo) ;
}
// anti-insultos
$codigo = str_replace("capullo","***",$codigo) ;
$codigo = str_replace("cabron","***",$codigo) ;
$codigo = str_replace("hijo puta","***",$codigo) ;
$codigo = str_replace("maricon","***",$codigo) ;
$codigo = str_replace("puta","***",$codigo) ;
$codigo = str_replace("gay","***",$codigo) ;
// convertir enlaces a url
$codigo = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$codigo) ;
// colorear el codigo 
// by wwww.electros.tk
if(strstr($codigo,"[codigo]")) {
$partes = explode("[codigo]",$codigo) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$codigo = implode("",$partes) ;
} 
}
// Ponemos en el codigo los puntos y los espacios correspondientes.
$codigo = str_replace("\r\n","<br>",$codigo) ;
// Mostramos el codigo de la pagina
echo "$codigo";
} 
else 
{ 
echo "Este tutorial se esta actualizando o ya no existe.";
} 
?>
                    </td>
                    <td width="20%" valign="top"><div align="left">
                        <?
// minibanner
include ("$secciones$elemento2.php");
if($idminibanner != "no") {
if($idminibanner != "") {
?>
<img src="<? echo $idminibanner ; ?>" width="88" height="31">
<?
}
}
else 
{ 
echo "";
}
?>
                      </div></td>
                  </tr>
                </table>
                <table width="100%" border='0' cellpadding='1' cellspacing='0'>
                  <tr> 
                      <td><b>Visitas:</b> 
                        <?
// asignamos el tama�o de los archivo
if(file_exists("$secciones$elemento2.dat")) {
include ("$secciones$elemento2.dat") ;
}
else 
{ 
echo "0";
}
?>
                        | <a href="index.php?archivo=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>" >Editar</a> | <a href="index.php?borrar=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>">Borrar</a> | <a href="index.php?renombrar=<? echo $secciones ?><?
echo "$elemento2";
?>&secciones=<? echo $secciones ?>">Renombrar</a></td>
                  </tr>
                </table></td>
            </tr>
          </table></td>
  </tr>
</table><br>
<?php
  }
 }
  
 // Si sobran archivos pondremos el "10 Siguientes"
 if ($elemento = @readdir($dir))
 {
  $Show['20 Siguientes'] = 1;
 }

 //Cerramos el directorio 
 @closedir($dir); 
?>        
      <div align="right">  
    <?php
 // Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
 if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."&secciones=$secciones\">20 Anteriores | </a>");
 if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."&secciones=$secciones\">20 Siguientes</a></p>");
?>
    </div>  <br> 
          <?
// Crear un nuevo descripcionamp: si el archivo no tiene nombre 
// y comprobamos si no existe nuevo%20%20descripcionamp.txt
if ($archivon != "") {
if(!file_exists("nuevo%20%20descripcionamp.txt")) { 
 function write_fil2($arch, $titulo) {
 if ($fp = @fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left"> 
                  Nuevo descarga 
                  <script>function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
                </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="623" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
                  <form method="post" action='index.php?action=new&archivon=<? echo $archivon ?>&secciones=<? echo $secciones ?>' id="formulario" name="formulario" enctype="multipart/form-data">
              Nombre del enlace :<br>
                    <input name='archivon' type='text' class='form' value="<? /*si el archivo es 'nuevo descripcionamp' evitaremos que ponga eso mismo en el formulario */  if ($archivon ="nuevo%20%20descripcionamp"){$archivon ="";}  else {} echo $archivon ?>" size="33">
                    <br>
              Autor del enlace :<br>
                    <input name='cnautor' type='text' class='form' id="cnautor" size="33">
                    <br>
              Contrase&ntilde;a atribuida al enlace :<br>
                    <input name='cnpass' type='text' class='form' id="cnpass" size="33">
                    <br>
              Breve descripcion del enlace :<br>
                    <textarea rows="3" cols="50"  name="cndesc" id="cndesc" class='form'><? echo $cndesc; ?>
</textarea>
                    <br>
              Descripcion del enlace :<br>
                    <br>
                    <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> 
                    Insertar un codigo php.<br>
                    <a href="javascript:descargar('[azul][/azul]')">[azul][/azul]</a> 
                    Insertar codigo azul.<br>
                    <a href="javascript:descargar('[red][/red]')">[red][/red]</a> 
                    Insertar un codigo rojo.<br>
                    <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar 
                    un texto en negrita.<br>
              <br>
                    <br>
                    <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. 
                    <br>
                    <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. 
                    <br>
                    <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> 
                    Superindice. <br>
                    <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> 
                    Subindice. <br>
                    <a href="javascript:descargar('[left][/left]')">[left][/left]</a> 
                    Alinear texto a la izquierda . <br>
                    <a href="javascript:descargar('[right][/right]')">[right][/right]</a> 
                    Alinear texto a la derecha . <br>
                    <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
                    Alinear texto al centro . <br>
                    <br>
                    <br>
                    <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
              <b><br>
              
              </b> 
              <label for="envioarchivo1"></label>
              <b><br>
              <font color="#FF0000">URL del enlace :</font></b><br>
                    <input type="text" name="url" size="30" maxlenght="100" value="http://" class="form">
              <br>
              URL minibanner (88x31) :<br>
              <input type="text" name="minibanner" size="30" maxlenght="100" value="http://" class="form">
              <br>
                    <br>
                    <input type='submit' name='enviar' value='Enviar' class='form'>
                  </form>
                </div></td>
            </tr>
          </table>
          <?
$descargar = $HTTP_POST_VARS['descargar'];
}
else if($action == "new")
{
// Comprobamos si en el form se envia $descargar y $descargar no esta vacio
// comprobamos que no haya otro descripcionamp con el mismo nombre
// comprobamos si existe  nuevo%20%20descripcionamp.txt
if($url == "http://") { $cnurl = "no" ; }
if($url != "http://") { $cnurl = $url ; }
if($minibanner == "http://") { $cnminibanner = "no" ; }
if($minibanner != "http://") { $cnminibanner = $minibanner ; }
}
if (isset($descargar)&&isset($url)&&($descargar!="")&&($url!="")){
// creamos el archivo.php fisicamente con los datos
$cnpass = htmlspecialchars(trim($_POST['cnpass']));
$cnautor = htmlspecialchars(trim($_POST['cnautor']));
$cnfecha = htmlspecialchars(trim($_POST['cnfecha']));
$cndesc = htmlspecialchars(trim($_POST['cndesc']));
$cndesc = htmlspecialchars(trim($_POST['cndesc']));
$cnpass = md5($cnpass) ;

$cnfecha = Date("d.m.y")." a las ".Date("H:i:s");

$nuevo .= "<"."?\n";
$nuevo .="\$idpass = \"$cnpass\";\n";
$nuevo .="\$idautor = \"$cnautor\";\n";
$nuevo .="\$idfecha = \"$cnfecha\";\n";
$nuevo .="\$iddesc = \"$cndesc\";\n";
$nuevo .="\$idurl = \"$cnurl\";\n";
$nuevo .="\$idminibanner = \"$cnminibanner\";\n";
$nuevo .= "?".">";

$fich = fopen("$secciones$archivon.php","w");
fputs($fich,$nuevo);
fclose($fich);

if(!file_exists("$secciones$archivon.txt")) {
if(!file_exists("$seccionesnuevo%20%20descripcionamp.txt")) {  
// creamos el achivo .txt fisicamente
$contrasena = htmlspecialchars(trim($_POST['contrasena']));
$descargar = htmlspecialchars(trim($_POST['descargar']));

$rs = write_fil2("$secciones$archivon.txt", "$descargar");
$archi = "$secciones$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
}
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Nuevo 
            enlace </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
            Nuevo enlace creado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
            aqui</a></div></td>
            </tr>
          </table>
          <?
}
}
}
}
?>
          <br> 
          <?
if ($archivo != "") { 
 function write_fil($arch, $titulo) {
 if ($fp = fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
// Leemos la informacion del archivo.txt y la mostarmos
$archi = "$archivo.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
include ("$archivo.php");
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
            Editar un enlace 
            <script>
function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
                </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="572" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
                  <form method="post" action='index.php?action=ver&archivo=<? echo $archivo ?>&secciones=<? echo $secciones ?>' id="formulario" name="formulario" enctype="multipart/form-data">
                    Contrase&ntilde;a :<br>
                    <input type='text' name='contrasena' class='form'>
                    <br>
              Nombre del enlace :<br>
                    <input name='none' type='text' class='form' value="<?  $none = str_replace("$secciones","",$archivo);  echo $none ?>" size="33" readonly>
                    <input name='archivo' type='hidden' class='form' value="<? echo $archivo ?>" size="33" readonly>
              <br>
              Breve descripcion del enlace :<br>
              <textarea rows="3" cols="50"  name="cndesc" id="cndesc" class='form'><? echo $iddesc; ?>
</textarea>
              <br>
              Contenido del enlace :<br>
                    <br>
                    <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> 
                    Insertar un codigo php.<br>
                    <a href="javascript:descargar('[azul][/azul]')">[azul][/azul]</a> 
                    Insertar codigo azul.<br>
                    <a href="javascript:descargar('[red][/red]')">[red][/red]</a> 
                    Insertar un codigo rojo.<br>
                    <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar 
                    un texto en negrita.<br>
              <br>
                    <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. 
                    <br>
                    <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. 
                    <br>
                    <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> 
                    Superindice. <br>
                    <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> 
                    Subindice. <br>
                    <a href="javascript:descargar('[left][/left]')">[left][/left]</a> 
                    Alinear texto a la izquierda . <br>
                    <a href="javascript:descargar('[right][/right]')">[right][/right]</a> 
                    Alinear texto a la derecha . <br>
                    <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
                    Alinear texto al centro .<br>
                    <br>
                    <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
              <label for="radio6"></label>
              <br>
              <b>URL del enlace :</b><br>
              <input type="text" name="url" size="30" maxlenght="100" value="<? echo $idurl ?>" class="form">
              <br>
              URL minibanner (88x31) :<br>
              <input name="minibanner" type="text" class="form" id="minibanner" value="<? if($idminibanner =="no") { echo "http://"; } else { echo $idminibanner ; } ?>" size="30" maxlenght="100">
              <br>
              <br>
                    <input type='submit' name='enviar' value='Enviar' class='form'>
                  </form>
                </div></td>
            </tr>
          </table>
          <? 
$descargar = $HTTP_POST_VARS['descargar'];
}
else if($action == "ver")
{
if(file_exists("$archivo.php")) {
require ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// si la contrase�a codificaa en md5 es distinta de la que en archivo.php salimos
if (md5($contrasena) != $idpass) { exit; }{ 
if (isset($descargar)&&isset($contrasena)&&($descargar!="")&&($contrasena!=""))
{
if($url == "http://") { $cnurl = "no" ; }
if($url != "http://") { $cnurl = $url ; }
if($minibanner == "http://") { $cnminibanner = "no" ; }
if($minibanner != "http://") { $cnminibanner = $minibanner ; }
// leer el archivo archivo.txt
$contrasena = htmlspecialchars(trim($_POST['contrasena']));
$descargar = htmlspecialchars(trim($_POST['descargar']));

$rs = write_fil("$archivo.txt", "$descargar");
$archi = "$archivo.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// Editamos el archivo .php
$cnpass = htmlspecialchars(trim($_POST['cnpass']));
$cnautor = htmlspecialchars(trim($_POST['cnautor']));
$cnfecha = htmlspecialchars(trim($_POST['cnfecha']));
$cndesc = htmlspecialchars(trim($_POST['cndesc']));
$cnurl = htmlspecialchars(trim($_POST['url']));

$cnpass = $idpass ;
$cnautor = $idautor ;
$cnpuntos = $idpuntos ;
$cnvotos = $idvotos ;
$cncalificacion = $idcalificacion ;
$cnfecha = Date("d.m.y")." a las ".Date("H:i:s");

$codigo2 .= "<"."?\n";
$codigo2 .="\$idpass = \"$cnpass\";\n";
$codigo2 .="\$idautor = \"$cnautor\";\n";
$codigo2 .="\$idfecha = \"$cnfecha\";\n";
$codigo2 .="\$iddesc = \"$cndesc\";\n";
$codigo2 .="\$idurl = \"$cnurl\";\n";
$codigo2 .="\$idminibanner = \"$cnminibanner\";\n";
$codigo2 .= "?".">";

$fichdatos2 = fopen("$archivo.php","w");
fputs($fichdatos2,$codigo2);
fclose($fichdatos2);
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Editar 
            un enlace </div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
            * Enlace editado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
            aqui</a> </div></td>
            </tr>
          </table>
          <?
}
}
}
}
?>
          <br> 
          <?
if ($borrar != "") {
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
            Borrar un enlace</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
                  <form method=post action='index.php?action=borrar&archivo=<? echo $borrar ?>&secciones=<? echo $secciones ?>' id=form1 name=form1 enctype="multipart/form-data">
              Se dispone a borrar el siguiente enlace, para confirmar la accion 
              intruduzca la contrase&ntilde;a y pulse enviar.<br>
                    <br>
                    Contrase&ntilde;a :<br>
                    <input name='contrasena' type='text' class='form' id="contrasena">
                    <br>
              Nombre del enlace:<br>
                    <input name='none2' type='text' class='form' value="<?  $none2 = str_replace("$secciones","",$borrar);  echo $none2 ?>" size="33" readonly>
                    <input name='archivo' type='hidden' class='form' value="<? echo $borrar ?>" size="33" readonly>
                    <br>
                    <input type='submit' name='enviar' value='Enviar' class='form'>
                  </form>
                </div></td>
            </tr>
          </table>
          <?
$archivo = $HTTP_POST_VARS['archivo'];
}
else if($action == "borrar")
{
if(file_exists("$archivo.php")) {
include ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// si la contrase�a codificaa en md5 es distinta de la que en archivo.php salimos
if (md5($contrasena) != $idpass) { exit; }{ 
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
// se borra el archivo
unlink("$archivo.txt") ;
// se borra los posibles restos del archivo, como su contrase�a, comentario, lecturas, zip y clicks en el zip
// a los cuales le ponemos una @ para que no muestre el error en pantalla
@unlink("$archivo.php") ;
@unlink("$archivo.dat") ;
@unlink("$archivo.zip.dat") ;
@unlink("$archivo.zip") ;
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Borrar 
            un enlace</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
            Enlace borrado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
            aqui</a></div></td>
            </tr>
          </table>
          <?
}
}
}
?>
          <br> 
          <?
if ($renombrar != "") {
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
            Renombrar un enlace</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
                  <form method=post action='index.php?action=renombrar&archivo=<? echo $renombrar ?>&secciones=<? echo $secciones ?>' id=form1 name=form1 enctype="multipart/form-data">
              Se dispone a renombrar el siguiente enlace, para confirmar la accion 
              intruduzca la contrase&ntilde;a y pulse enviar.<br>
                    <br>
                    Contrase&ntilde;a :<br>
                    <input name='contrasena' type='text' class='form' id="contrasena">
                    <br>
              Nombre del enlace antiguo:<br>
                    <input name='none3' type='text' class='form' value="<?  $none3 = str_replace("$secciones","",$renombrar);  echo $none3 ?>" size="33" readonly>
                    <input name='archivo' type='hidden' class='form' value="<? echo $renombrar ?>" size="33" readonly="">
                    <br>
                    Nuevo nombre:<br>
                    <input name='nuevo' type='text' class='form' size="33">
                    <br>
                    <input type='submit' name='enviar' value='Enviar' class='form'>
                  </form>
                </div></td>
            </tr>
          </table>
          <?
$archivo = $HTTP_POST_VARS['archivo'];
$nuevo = $HTTP_POST_VARS['nuevo'];
}
else if($action == "renombrar")
{
if(file_exists("$archivo.php")) {
include ("$archivo.php") ;
}
else 
{ 
echo "Contrase�a incorrecta. <a href=\"javascript:history.back()\">Regresar</a><br>";
}
// si la contrase�a codificaa en md5 es distinta de la que en archivo.php salimos
if (md5($contrasena) != $idpass) { exit; }{
if(isset($archivo)&&isset($contrasena)&&isset($nuevo)&&($archivo!="")&&($contrasena!="")&&($nuevo!=""))
{
// Renombramos el archivo del descripcionamp
rename("$archivo.txt", "$secciones$nuevo.txt");
// Renombramos el resto de archivos que pudiera tener
@rename("$archivo.dat", "$secciones$nuevo.dat");
@rename("$archivo.zip.dat", "$secciones$nuevo.zip.dat");
@rename("$archivo.zip", "$secciones$nuevo.zip");
@rename("$archivo.php", "$secciones$nuevo.php");
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Renombrar 
            un enlace</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
            Enlace renombrado satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
            aqui</a></div></td>
            </tr>
          </table>
          <?
}
}
}
?>
          <br> 
          <?
// solo el admin puede crear directorios, la contrase�a se especifica mas abajo
if ($directorio != "") {
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
                  Crear una nueva seccion</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
                  <form method=post action='index.php?action=directorio&archivo=<? echo $directorio ?>&secciones=<? echo $secciones ?>' id="directorio" name="directorio" enctype="multipart/form-data">
                    Se dispone a crear una nueva seccion ,cada seccion que cree 
                    sera en realidad un nuevo <font color="#0000FF">directorio 
                    web<br>
              fisico</font> con el nombre de la seccion. Una vez creado podra 
              guardar sus enlaces y vera en el menu la su susodicha seccion, para 
              confirmar la accion intruduzca la contrase&ntilde;a y pulse enviar. 
              <br>
                    <br>
                    Contrase&ntilde;a :<br>
                    <input name='contrasena' type='text' class='form' id="contrasena">
                    <? if ($secciones != "./") { ?>
                    <br>
                    <font color="#FF0000">Advertencia : La subseccion<br>
                    se guardara dentro del directorio</font><font color="#FF0000"><br>
                    <input name='none5' type='text' class='form' id="none" value="<?  $none5 = str_replace("nuevo  directorio","",$directorio);  echo $none5 ?>" readonly>
                    </font> 
                    <? } ?>
                    <br>
                    Nombre de la seccion :<br>
                    <input name='archivo' type='text' class='form' value="<? if ($directorio ="nuevo%20%20directorio"){ $directorio ="";}  else {} echo $directorio ?>" size="33">
                    <br>
                    <input type='submit' name='enviar' value='Enviar' class='form'>
                  </form>
                </div></td>
            </tr>
          </table>
          <?
$archivo = $_POST['archivo'];
}
else if($action == "directorio")
{
if(!file_exists("$secciones$archivo")) {  
if ($contrasena != "123456") { exit; }{  // aqui tu contrase�a
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
// creamos el directorio
mkdir("$secciones$archivo", 0777);
?>
          <table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
            <tr> 
              <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Crear 
                  una nueva seccion</div></td>
              <td width="3%" align="center" class="tabla_subtitulo"><a href="index.php">x</a></td>
            </tr>
            <tr> 
              <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
                  Seccion creada satisfactoriamente, <a href="index.php?secciones=<? echo $secciones ?>">pulsa 
                  aqui</a></div></td>
            </tr>
          </table>
          
    <?
}
}
}
}
?>
    <div align="center"><br>
      <br>
      <a href="enlacesplus.zip">Enlacesplus</a> by elcidop</div>