<?php
// -------------------------------------------------------------
//
// $Id: index.php,v 1.23 2004/02/06 12:17:50 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

include('./../includes/common.php');

$mysql->query('SELECT `user_level`
		FROM `' . TABLE_USERS . '`
		WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
$table_users = $mysql->fetch();

if (!$table_users['user_level'])
{
	error_template($lang['ADMIN_AREA1_ERROR']);
}
else
{
	if ($_GET['action'] == 'add_news')
	{
		if ($table_users['user_level'] < 2)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT `allow_html`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			$mysql->query('SELECT `category_id`, `category_name`
					FROM `' . TABLE_CATEGORIES . '`
					ORDER BY `category_name`');
			while ($table_categories = $mysql->fetch())
			{
				$category_name_options .= '<option value="' . $table_categories['category_id'] . '">' . $table_categories['category_name'] . '</option>';
			}
			if ($table_settings['allow_html'] == 0)
			{
				$html_support = $lang['HTML_DISABLED'];
			}
			else
			{
				$html_support = $lang['HTML_ENABLED'];
			}
			$template->set_file('admin', 'admin/news/add.tpl');
			$template->set_var(array(
				'ADD' => $lang['ADD'],
				'ADMIN_NEWS_HEADER1' => $lang['ADMIN_NEWS_HEADER1'],
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1'],
				'CATEGORY_NAME_OPTIONS' => $category_name_options,
				'FORM_NEWS_CATEGORY' => $lang['FORM_NEWS_CATEGORY'],
				'FORM_NEWS_SOURCE' => $lang['FORM_NEWS_SOURCE'],
				'FORM_NEWS_SUBJECT' => $lang['FORM_NEWS_SUBJECT'],
				'FORM_NEWS_TEXT' => $lang['FORM_NEWS_TEXT'],
				'HTML_SUPPORT' => $html_support));
		}
	}
//
	elseif ($_POST['add_news'])
	{
		if (!trim($_POST['news_subject']))
		{
			$error .= $lang['NO_NEWS_SUBJECT'];
		}
		if (!trim($_POST['news_text']))
		{
			$error .= $lang['NO_NEWS_TEXT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$news_subject = htmlspecialchars($_POST['news_subject']);
			$mysql->query('SELECT `allow_html`, `allow_smilies`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			if ($table_settings['allow_html'] == 0)
			{
				$news_text = htmlspecialchars($_POST['news_text']);
				$news_source = htmlspecialchars($_POST['news_source']);
				$news_text = do_bbcode($news_text);
				$news_source = do_bbcode($news_source);
			}
			else
			{
				$news_text = $_POST['news_text'];
				$news_source = $_POST['news_source'];
			}
			if ($table_settings['allow_smilies'] == 1)
			{
				$mysql->query('SELECT `smiley_code`, `smiley_image`
						FROM `' . TABLE_SMILIES . '`');
				while ($table_smilies = $mysql->fetch())
				{
					$news_text = str_replace($table_smilies['smiley_code'], '<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $news_text);
				}
			}
			$mysql->query('INSERT INTO `' . TABLE_NEWS . '`
					VALUES (\'\', \'' . $_POST['category_id'] . '\', \'' . $_SESSION['user_id'] . '\', \'1\', \'' . $news_subject . '\', \'' . $news_text . '\', \'' . $news_source . '\', \'\', \'' . time() . '\', \'' . date('m', time()) . '\', \'' . date('Y', time()) . '\')');
			make_backend_rss();
			make_backend_txt();
			success_template($lang['ADMIN_NEWS_ADDED']);
			header('Refresh: 3; URL= ./../admin/index.php');
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'view_submitted_news')
	{
		if ($table_users['user_level'] < 2)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			if (!$_GET['page'])
			{
				$_GET['page'] = 1;
			}
			$mysql->query('SELECT `news_order`, `news_per_page`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			$news_order = $table_settings['news_order'];
			$news_per_page = $table_settings['news_per_page'];
			$news_offset = (($_GET['page'] - 1) * $news_per_page);
			$mysql->query('SELECT `news_id`
					FROM `' . TABLE_NEWS . '`
					WHERE `news_active` = \'0\'');
			$num_news = $mysql->num_rows();
			$num_pages = ceil($num_news / $news_per_page);
			if ($_GET['page'] != 1)
			{
				$pages_list .= '<a href="./../admin/index.php?action=view_submitted_news&amp;page=' . ($_GET['page'] - 1) . '" title="' . $lang['PREVIOUS_PAGE'] . '">&lt;</a> ';
			}
			for ($current_page = 1; $current_page <= $num_pages; $current_page++)
			{
				if ($_GET['page'] == $current_page)
				{
					$pages_list .= $_GET['page'] . ' ';
				}
				else
				{
					$pages_list .= '<a href="./../admin/index.php?action=view_submitted_news&amp;page=' . $current_page . '" title="' . $current_page . '">' . $current_page . '</a> ';
				}
			}
			if (($num_pages > 1) && ($_GET['page'] != $num_pages))
			{
				$pages_list .= '<a href="./../admin/index.php?action=view_submitted_news&amp;page=' . ($_GET['page'] + 1) . '" title="' . $lang['NEXT_PAGE'] . '">&gt;</a>';
			}
			$date_format = get_date_format();
			$date_offset = get_date_offset();
			$template->set_file('admin', 'admin/news/view_submitted.tpl');
			$template->set_block('admin', 'NEWS_BLOCK', 'news');
			$mysql->query('SELECT ' . TABLE_NEWS . '.news_date, ' . TABLE_NEWS . '.news_id, ' . TABLE_NEWS . '.news_subject, ' . TABLE_USERS . '.user_id, ' . TABLE_USERS . '.user_name
					FROM `' . TABLE_NEWS . '`, `' . TABLE_USERS . '`
					WHERE ' . TABLE_NEWS . '.news_active = \'0\' AND ' . TABLE_NEWS . '.user_id = ' . TABLE_USERS . '.user_id
					ORDER BY `' . $news_order . '` DESC
					LIMIT ' . $news_offset . ', ' . $news_per_page . '');
			while ($table_news = $mysql->fetch())
			{
				$news_date = date($date_format, ($table_news['news_date'] + $date_offset));
				$template->set_var(array(
					'ADD' => $lang['ADD'],
					'DELETE' => $lang['DELETE'],
					'NEWS_ID' => $table_news['news_id'],
					'NEWS_RELEASE' => sprintf($lang['ADMIN_NEWS_RELEASE'], $table_news['user_id'], $table_news['user_name'], $news_date),
					'NEWS_SUBJECT' => $table_news['news_subject']));
				$template->parse('news', 'NEWS_BLOCK', true);
			}
			$template->set_var(array(
				'ADMIN_NEWS_HEADER2' => $lang['ADMIN_NEWS_HEADER2'],
				'ADMIN_NEWS_PAGES' => sprintf($lang['ADMIN_NEWS_PAGES'], $pages_list),
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1']));
		}
	}
//
	elseif ($_GET['action'] == 'add_submitted_news')
	{
		if ($table_users['user_level'] < 2)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT ' . TABLE_CATEGORIES . '.category_name, ' . TABLE_NEWS . '.news_source, ' . TABLE_NEWS . '.news_subject, ' . TABLE_NEWS . '.news_text, ' . TABLE_NEWS . '.user_id
					FROM ' . TABLE_CATEGORIES . ', ' . TABLE_NEWS . '
					WHERE ' . TABLE_CATEGORIES . '.category_id = ' . TABLE_NEWS . '.category_id AND ' . TABLE_NEWS . '.news_id = \'' . $_GET['news_id'] . '\'');
			$table_news = $mysql->fetch();
			$mysql->query('SELECT `category_id`, `category_name`
					FROM `' . TABLE_CATEGORIES . '`');
			while ($table_categories = $mysql->fetch())
			{
				if ($table_categories['category_name'] == $table_news['category_name'])
				{
					$category_name_options .= '<option value="' . $table_categories['category_id'] . '" selected="selected">' . $table_categories['category_name'] . '</option>';
				}
				else
				{
					$category_name_options .= '<option value="' . $table_categories['category_id'] . '">' . $table_categories['category_name'] . '</option>';
				}
			}
			$mysql->query('SELECT `smiley_code`, `smiley_image`
					FROM `' . TABLE_SMILIES . '`');
			while ($table_smilies = $mysql->fetch())
			{
				$table_news['news_text'] = str_replace('<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $table_smilies['smiley_code'], $table_news['news_text']);
			}
			$table_news['news_text'] = undo_bbcode($table_news['news_text']);
			$table_news['news_source'] = undo_bbcode($table_news['news_source']);
			$template->set_file('admin', 'admin/news/add_submitted.tpl');
			$template->set_var(array(
				'ADD' => $lang['ADD'],
				'ADMIN_NEWS_HEADER3' => $lang['ADMIN_NEWS_HEADER3'],
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1'],
				'CATEGORY_NAME_OPTIONS' => $category_name_options,
				'FORM_NEWS_CATEGORY' => $lang['FORM_NEWS_CATEGORY'],
				'FORM_NEWS_SOURCE' => $lang['FORM_NEWS_SOURCE'],
				'FORM_NEWS_SUBJECT' => $lang['FORM_NEWS_SUBJECT'],
				'FORM_NEWS_TEXT' => $lang['FORM_NEWS_TEXT'],
				'NEWS_ID' => $_GET['news_id'],
				'NEWS_SUBJECT' => $table_news['news_subject'],
				'NEWS_SOURCE' => $table_news['news_source'],
				'NEWS_TEXT' => $table_news['news_text'],
				'USER_ID' => $table_news['user_id']));
		}
	}
//
	elseif ($_POST['add_submitted_news'])
	{
		if (!trim($_POST['news_subject']))
		{
			$error .= $lang['NO_NEWS_SUBJECT'];
		}
		if (!trim($_POST['news_text']))
		{
			$error .= $lang['NO_NEWS_TEXT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$news_subject = htmlspecialchars($_POST['news_subject']);
			$mysql->query('SELECT `allow_html`, `allow_smilies`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			if ($table_settings['allow_html'] == 0)
			{
				$news_text = htmlspecialchars($_POST['news_text']);
				$news_source = htmlspecialchars($_POST['news_source']);
				$news_text = do_bbcode($news_text);
				$news_source = do_bbcode($news_source);
			}
			else
			{
				$news_text = $_POST['news_text'];
				$news_source = $_POST['news_source'];
			}
			if ($table_settings['allow_smilies'] == 1)
			{
				$mysql->query('SELECT `smiley_code`, `smiley_image`
						FROM `' . TABLE_SMILIES . '`');
				while ($table_smilies = $mysql->fetch())
				{
					$news_text = str_replace($table_smilies['smiley_code'], '<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $news_text);
				}
			}
			$mysql->query('UPDATE `' . TABLE_NEWS . '`
					SET `category_id` = \'' . $_POST['category_id'] . '\', `user_id` = \'' . $_POST['user_id'] . '\', `news_active` = \'1\', `news_subject` = \'' . $news_subject . '\', `news_text` = \'' . $news_text . '\', `news_source` = \'' . $news_source . '\', `news_date` = \'' . time() . '\', `news_month` = \'' . date('m', time()) . '\', `news_year` = \'' . date('Y', time()) . '\'
					WHERE `news_id` = \'' . $_POST['news_id'] . '\'
					LIMIT 1');
			make_backend_rss();
			make_backend_txt();
			success_template($lang['ADMIN_NEWS_ADDED']);
			header('Refresh: 3; URL= ./../admin/index.php');
		}
	}
//
	elseif ($_GET['action'] == 'delete_submitted_news')
	{
		if ($table_users['user_level'] < 2)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('DELETE FROM `' . TABLE_NEWS . '` WHERE `news_id` = \'' . $_GET['news_id'] . '\'');
			$mysql->query('OPTIMIZE TABLE `' . TABLE_NEWS . '`');
			success_template($lang['ADMIN_NEWS_DELETED']);
			header('Refresh: 3; URL= ./../admin/index.php');
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'view_news')
	{
		if ($table_users['user_level'] < 3)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			if (!$_GET['page'])
			{
				$_GET['page'] = 1;
			}
			$mysql->query('SELECT `news_order`, `news_per_page`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			$news_order = $table_settings['news_order'];
			$news_per_page = $table_settings['news_per_page'];
			$news_offset = (($_GET['page'] - 1) * $news_per_page);
			$mysql->query('SELECT `news_id`
					FROM `' . TABLE_NEWS . '`
					WHERE `news_active` = \'1\'');
			$num_news = $mysql->num_rows();
			$num_pages = ceil($num_news / $news_per_page);
			if ($_GET['page'] != 1)
			{
				$pages_list .= '<a href="./../admin/index.php?action=view_news&amp;page=' . ($_GET['page'] - 1) . '" title="' . $lang['PREVIOUS_PAGE'] . '">&lt;</a> ';
			}
			for ($current_page = 1; $current_page <= $num_pages; $current_page++)
			{
				if ($_GET['page'] == $current_page)
				{
					$pages_list .= $_GET['page'] . ' ';
				}
				else
				{
					$pages_list .= '<a href="./../admin/index.php?action=view_news&amp;page=' . $current_page . '" title="' . $current_page . '">' . $current_page . '</a> ';
				}
			}
			if (($num_pages > 1) && ($_GET['page'] != $num_pages))
			{
				$pages_list .= '<a href="./../admin/index.php?action=view_news&amp;page=' . ($_GET['page'] + 1) . '" title="' . $lang['NEXT_PAGE'] . '">&gt;</a>';
			}
			$date_format = get_date_format();
			$date_offset = get_date_offset();
			$template->set_file('admin', 'admin/news/view.tpl');
			$template->set_block('admin', 'NEWS_BLOCK', 'news');
			$mysql->query('SELECT ' . TABLE_NEWS . '.news_date, ' . TABLE_NEWS . '.news_id, ' . TABLE_NEWS . '.news_subject, ' . TABLE_USERS . '.user_id, ' . TABLE_USERS . '.user_name
					FROM `' . TABLE_NEWS . '`, `' . TABLE_USERS . '`
					WHERE ' . TABLE_NEWS . '.news_active = \'1\' AND ' . TABLE_NEWS . '.user_id = ' . TABLE_USERS . '.user_id
					ORDER BY `' . $news_order . '` DESC
					LIMIT ' . $news_offset . ', ' . $news_per_page . '');
			while ($table_news = $mysql->fetch())
			{
				$news_date = date($date_format, ($table_news['news_date'] + $date_offset));
				$template->set_var(array(
					'DELETE' => $lang['DELETE'],
					'EDIT' => $lang['EDIT'],
					'NEWS_ID' => $table_news['news_id'],
					'NEWS_RELEASE' => sprintf($lang['ADMIN_NEWS_RELEASE'], $table_news['user_id'], $table_news['user_name'], $news_date),
					'NEWS_SUBJECT' => $table_news['news_subject']));
				$template->parse('news', 'NEWS_BLOCK', true);
			}
			$template->set_var(array(
				'ADMIN_NEWS_HEADER4' => $lang['ADMIN_NEWS_HEADER4'],
				'ADMIN_NEWS_PAGES' => sprintf($lang['ADMIN_NEWS_PAGES'], $pages_list),
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1']));
		}
	}
//
	elseif ($_GET['action'] == 'edit_news')
	{
		if ($table_users['user_level'] < 3)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT ' . TABLE_CATEGORIES . '.category_name, ' . TABLE_NEWS . '.news_source, ' . TABLE_NEWS . '.news_subject, ' . TABLE_NEWS . '.news_text
					FROM ' . TABLE_CATEGORIES . ', ' . TABLE_NEWS . '
					WHERE ' . TABLE_CATEGORIES . '.category_id = ' . TABLE_NEWS . '.category_id AND `news_id` = \'' . $_GET['news_id'] . '\'');
			$table_news = $mysql->fetch();
			$mysql->query('SELECT `category_id`, `category_name`
					FROM `' . TABLE_CATEGORIES . '`');
			while ($table_categories = $mysql->fetch())
			{
				if ($table_categories['category_name'] == $table_news['category_name'])
				{
					$category_name_options .= '<option value="' . $table_categories['category_id'] . '" selected="selected">' . $table_categories['category_name'] . '</option>';
				}
				else
				{
					$category_name_options .= '<option value="' . $table_categories['category_id'] . '">' . $table_categories['category_name'] . '</option>';
				}
			}
			$mysql->query('SELECT `smiley_code`, `smiley_image`
					FROM `' . TABLE_SMILIES . '`');
			while ($table_smilies = $mysql->fetch())
			{
				$table_news['news_text'] = str_replace('<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $table_smilies['smiley_code'], $table_news['news_text']);
			}
			$table_news['news_text'] = undo_bbcode($table_news['news_text']);
			$table_news['news_source'] = undo_bbcode($table_news['news_source']);
			$template->set_file('admin', 'admin/news/edit.tpl');
			$template->set_var(array(
				'ADMIN_NEWS_HEADER5' => $lang['ADMIN_NEWS_HEADER5'],
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1'],
				'CATEGORY_NAME_OPTIONS' => $category_name_options,
				'EDIT' => $lang['EDIT'],
				'FORM_NEWS_CATEGORY' => $lang['FORM_NEWS_CATEGORY'],
				'FORM_NEWS_SOURCE' => $lang['FORM_NEWS_SOURCE'],
				'FORM_NEWS_SUBJECT' => $lang['FORM_NEWS_SUBJECT'],
				'FORM_NEWS_TEXT' => $lang['FORM_NEWS_TEXT'],
				'NEWS_ID' => $_GET['news_id'],
				'NEWS_SOURCE' => $table_news['news_source'],
				'NEWS_SUBJECT' => $table_news['news_subject'],
				'NEWS_TEXT' => $table_news['news_text']));
		}
	}
//
	elseif ($_POST['edit_news'])
	{
		if (!trim($_POST['news_subject']))
		{
			$error .= $lang['NO_NEWS_SUBJECT'];
		}
		if (!trim($_POST['news_text']))
		{
			$error .= $lang['NO_NEWS_TEXT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$news_subject = htmlspecialchars($_POST['news_subject']);
			$mysql->query('SELECT `allow_html`, `allow_smilies`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			if ($table_settings['allow_html'] == 0)
			{
				$news_text = htmlspecialchars($_POST['news_text']);
				$news_source = htmlspecialchars($_POST['news_source']);
				$news_text = do_bbcode($news_text);
				$news_source = do_bbcode($news_source);
			}
			else
			{
				$news_text = $_POST['news_text'];
				$news_source = $_POST['news_source'];
			}
			if ($table_settings['allow_smilies'] == 1)
			{
				$mysql->query('SELECT `smiley_code`, `smiley_image`
						FROM `' . TABLE_SMILIES . '`');
				while ($table_smilies = $mysql->fetch())
				{
					$news_text = str_replace($table_smilies['smiley_code'], '<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $news_text);
				}
			}
			$mysql->query('UPDATE `' . TABLE_NEWS . '`
					SET `news_subject` = \'' . $news_subject . '\', `category_id` = \'' . $_POST['category_id'] . '\', `news_text` = \'' . $news_text . '\', `news_source` = \'' . $news_source . '\'
					WHERE `news_id` = \'' . $_POST['news_id'] . '\'
					LIMIT 1');
			make_backend_rss();
			make_backend_txt();
			success_template($lang['ADMIN_NEWS_EDITED']);
			header('Refresh: 3; URL= ./../admin/index.php');
		}
	}
//
	elseif ($_GET['action'] == 'delete_news')
	{
		if ($table_users['user_level'] < 3)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT `news_id`
					FROM `' . TABLE_COMMENTS . '`
					WHERE `news_id` = \'' . $_GET['news_id'] . '\'');
			$table_comments = $mysql->fetch();
			if ($table_comments['news_id'])
			{
				error_template($lang['ADMIN_NEWS_ERROR2']);
			}
			else
			{
				$mysql->query('DELETE FROM `' . TABLE_NEWS . '` WHERE `news_id` = \'' . $_GET['news_id'] . '\'');
				$mysql->query('OPTIMIZE TABLE `' . TABLE_NEWS . '`');
				make_backend_rss();
				make_backend_txt();
				success_template($lang['ADMIN_NEWS_DELETED']);
				header('Refresh: 3; URL= ./../admin/index.php');
			}
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'view_advanced_settings')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$template->set_file('admin', 'admin/area2.tpl');
			$template->set_var(array(
				'ADMIN_AREA2_HEADER' => $lang['ADMIN_AREA2_HEADER'],
				'ADMIN_AREA2_LINK1' => $lang['ADMIN_AREA2_LINK1'],
				'ADMIN_AREA2_LINK2' => $lang['ADMIN_AREA2_LINK2'],
				'ADMIN_AREA2_LINK3' => $lang['ADMIN_AREA2_LINK3'],
				'ADMIN_AREA2_LINK4' => $lang['ADMIN_AREA2_LINK4'],
				'ADMIN_AREA2_LINK5' => $lang['ADMIN_AREA2_LINK5'],
				'ADMIN_AREA2_LINK6' => $lang['ADMIN_AREA2_LINK6'],
				'ADMIN_AREA2_LINK7' => $lang['ADMIN_AREA2_LINK7'],
				'ADMIN_AREA2_LINK8' => $lang['ADMIN_AREA2_LINK8'],
				'ADMIN_IMG_CATEGORIES' => $lang['ADMIN_IMG_CATEGORIES'],
				'ADMIN_IMG_SETTINGS' => $lang['ADMIN_IMG_SETTINGS'],
				'ADMIN_IMG_SMILIES' => $lang['ADMIN_IMG_SMILIES'],
				'ADMIN_IMG_TEMPLATES' => $lang['ADMIN_IMG_TEMPLATES'],
				'ADMIN_IMG_USERS' => $lang['ADMIN_IMG_USERS'],
				'BACK_ADMIN_AREA1' => $lang['BACK_ADMIN_AREA1']));
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'edit_advanced_settings')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT *
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			if ($table_settings['language'] == 'dutch')
			{
				$dutch_selected = ' selected="selected"';
				$english_selected = '';
				$french_selected = '';
				$german_selected = '';
				$spanish_selected = '';
			}
			elseif ($table_settings['language'] == 'english')
			{
				$dutch_selected = '';
				$english_selected = ' selected="selected"';
				$french_selected = '';
				$german_selected = '';
				$spanish_selected = '';
			}
			elseif ($table_settings['language'] == 'french')
			{
				$dutch_selected = '';
				$english_selected = '';
				$french_selected = ' selected="selected"';
				$german_selected = '';
				$spanish_selected = '';
			}
			elseif ($table_settings['language'] == 'german')
			{
				$dutch_selected = '';
				$english_selected = '';
				$french_selected = '';
				$german_selected = ' selected="selected"';
				$spanish_selected = '';
			}
			else
			{
				$dutch_selected = '';
				$english_selected = '';
				$french_selected = '';
				$german_selected = '';
				$spanish_selected = ' selected="selected"';
			}
			if ($table_settings['news_order'] == 'news_date')
			{
				$date_selected = ' selected="selected"';
				$month_selected = '';
				$year_selected = '';
			}
			elseif ($table_settings['news_order'] == 'news_month')
			{
				$date_selected = '';
				$month_selected = ' selected="selected"';
				$year_selected = '';
			}
			else
			{
				$date_selected = '';
				$month_selected = '';
				$year_selected = ' selected="selected"';
			}
			if ($table_settings['allow_html'] == 1)
			{
				$html_yes = ' selected="selected"';
				$html_no = '';
			}
			else
			{
				$html_yes = '';
				$html_no = ' selected="selected"';
			}
			if ($table_settings['allow_smilies'] == 1)
			{
				$smilies_yes = ' selected="selected"';
				$smilies_no = '';
			}
			else
			{
				$smilies_yes = '';
				$smilies_no = ' selected="selected"';
			}
			if ($table_settings['submit_news'] == 1)
			{
				$submit_yes = ' selected="selected"';
				$submit_no = '';
			}
			else
			{
				$submit_yes = '';
				$submit_no = ' selected="selected"';
			}
			if ($table_settings['send_news'] == 1)
			{
				$send_yes = ' selected="selected"';
				$send_no = '';
			}
			else
			{
				$send_yes = '';
				$send_no = ' selected="selected"';
			}
			if ($table_settings['register_users'] == 1)
			{
				$register_yes = ' selected="selected"';
				$register_no = '';
			}
			else
			{
				$register_yes = '';
				$register_no = ' selected="selected"';
			}
			$template->set_file('admin', 'admin/settings/edit.tpl');
			$template->set_var(array(
				'ADMIN_SETTINGS_HEADER' => $lang['ADMIN_SETTINGS_HEADER'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'COMMENTS_PER_PAGE' => $table_settings['comments_per_page'],
				'DATE' => $lang['DATE'],
				'DATE_FORMAT' => $table_settings['date_format'],
				'DATE_OFFSET' => $table_settings['date_offset'],
				'DATE_SELECTED' => $date_selected,
				'DUTCH' => $lang['DUTCH'],
				'DUTCH_SELECTED' => $dutch_selected,
				'EDIT' => $lang['EDIT'],
				'ENGLISH' => $lang['ENGLISH'],
				'ENGLISH_SELECTED' => $english_selected,
				'FORM_ALLOW_HTML' => $lang['FORM_ALLOW_HTML'],
				'FORM_ALLOW_SMILIES' => $lang['FORM_ALLOW_SMILIES'],
				'FORM_COMMENTS_PER_PAGE' => $lang['FORM_COMMENTS_PER_PAGE'],
				'FORM_DATE_FORMAT' => $lang['FORM_DATE_FORMAT'],
				'FORM_DATE_OFFSET' => $lang['FORM_DATE_OFFSET'],
				'FORM_HEADLINES_PER_BACKEND' => $lang['FORM_HEADLINES_PER_BACKEND'],
				'FORM_LANGUAGE' => $lang['FORM_LANGUAGE'],
				'FORM_NEWS_ORDER' => $lang['FORM_NEWS_ORDER'],
				'FORM_NEWS_PER_PAGE' => $lang['FORM_NEWS_PER_PAGE'],
				'FORM_REGISTER_USERS' => $lang['FORM_REGISTER_USERS'],
				'FORM_SEND_NEWS' => $lang['FORM_SEND_NEWS'],
				'FORM_SITENAME' => $lang['FORM_SITENAME'],
				'FORM_SITEURL' => $lang['FORM_SITEURL'],
				'FORM_SUBMIT_NEWS' => $lang['FORM_SUBMIT_NEWS'],
				'FRENCH' => $lang['FRENCH'],
				'FRENCH_SELECTED' => $french_selected,
				'GERMAN' => $lang['GERMAN'],
				'GERMAN_SELECTED' => $german_selected,
				'HEADLINES_PER_BACKEND' => $table_settings['headlines_per_backend'],
				'HTML_NO' => $html_no,
				'HTML_YES' => $html_yes,
				'MONTH' => $lang['MONTH'],
				'MONTH_SELECTED' => $month_selected,
				'NEWS_PER_PAGE' => $table_settings['news_per_page'],
				'NO' => $lang['NO'],
				'REGISTER_NO' => $register_no,
				'REGISTER_YES' => $register_yes,
				'SEND_NO' => $send_no,
				'SEND_YES' => $send_yes,
				'SITENAME' => $table_settings['sitename'],
				'SITEURL' => $table_settings['siteurl'],
				'SMILIES_NO' => $smilies_no,
				'SMILIES_YES' => $smilies_yes,
				'SPANISH' => $lang['SPANISH'],
				'SPANISH_SELECTED' => $spanish_selected,
				'SUBMIT_NO' => $submit_no,
				'SUBMIT_YES' => $submit_yes,
				'YEAR' => $lang['YEAR'],
				'YEAR_SELECTED' => $year_selected,
				'YES' => $lang['YES']));
		}
	}
//
	elseif ($_POST['edit_advanced_settings'])
	{
		if (!trim($_POST['sitename']))
		{
			$error .= $lang['NO_SITENAME'];
		}
		if (!trim($_POST['siteurl']))
		{
			$error .= $lang['NO_SITEURL'];
		}
		if (ereg('/$', trim($_POST['siteurl'])))
		{
			$error .= $lang['ADMIN_SETTINGS_ERROR'];
		}
		if (!trim($_POST['date_format']))
		{
			$error .= $lang['NO_DATE_FORMAT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('UPDATE `' . TABLE_SETTINGS . '`
					SET `sitename` = \'' . $_POST['sitename'] . '\', `siteurl` = \'' . $_POST['siteurl'] . '\', `language` = \'' . $_POST['language'] . '\', `news_per_page` = \'' . $_POST['news_per_page'] . '\', `comments_per_page` = \'' . $_POST['comments_per_page'] . '\', `headlines_per_backend` = \'' . $_POST['headlines_per_backend'] . '\', `news_order` = \'' . $_POST['news_order'] . '\', `allow_html` = \'' . $_POST['allow_html'] . '\', `allow_smilies` = \'' . $_POST['allow_smilies'] . '\', `submit_news` = \'' . $_POST['submit_news'] . '\', `send_news` = \'' . $_POST['send_news'] . '\', `register_users` = \'' . $_POST['register_users'] . '\', `date_format` = \'' . $_POST['date_format'] . '\', `date_offset` = \'' . $_POST['date_offset'] . '\'');
			make_backend_rss();
			make_backend_txt();
			success_template($lang['ADMIN_SETTINGS_SUCCESS']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'add_categories')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$template->set_file('admin', 'admin/categories/add.tpl');
			$template->set_var(array(
				'ADD' => $lang['ADD'],
				'ADMIN_CATEGORIES_HEADER1' => $lang['ADMIN_CATEGORIES_HEADER1'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'FORM_CATEGORY_IMAGE' => $lang['FORM_CATEGORY_IMAGE'],
				'FORM_CATEGORY_NAME' => $lang['FORM_CATEGORY_NAME']));
		}
	}
//
	elseif ($_POST['add_category'])
	{
		$mysql->query('SELECT `category_name`
				FROM `' . TABLE_CATEGORIES . '`
				WHERE `category_name` = \'' . $_POST['category_name'] . '\'');
		$table_categories = $mysql->fetch();
		if ($table_categories['category_name'])
		{
			$error .= $lang['ADMIN_CATEGORIES_ERROR1'];
		}
		if (!trim($_POST['category_name']))
		{
			$error .= $lang['NO_CATEGORY_NAME'];
		}
		if (!trim($_POST['category_image']))
		{
			$error .= $lang['NO_CATEGORY_IMAGE'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('INSERT INTO `' . TABLE_CATEGORIES . '`
					VALUES (\'\', \'' . $_POST['category_name'] . '\', \'' . $_POST['category_image'] . '\')');
			success_template($lang['ADMIN_CATEGORIES_ADDED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
//
	elseif ($_GET['action'] == 'edit_categories')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT *
					FROM `' . TABLE_CATEGORIES . '`
					ORDER BY `category_name`');
			$template->set_file('admin', 'admin/categories/view.tpl');
			$template->set_block('admin', 'CATEGORIES_BLOCK', 'categories');
			while ($table_categories = $mysql->fetch())
			{
				$template->set_var(array(
					'CATEGORY_ID' => $table_categories['category_id'],
					'CATEGORY_IMAGE' => $table_categories['category_image'],
					'CATEGORY_NAME' => $table_categories['category_name'],
					'DELETE' => $lang['DELETE'],
					'EDIT' => $lang['EDIT']));
				$template->parse('categories', 'CATEGORIES_BLOCK', true);
			}
			$template->set_var(array(
				'ADMIN_CATEGORIES_HEADER2' => $lang['ADMIN_CATEGORIES_HEADER2'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2']));
		}
	}
//
	elseif ($_GET['action'] == 'edit_category')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT *
					FROM `' . TABLE_CATEGORIES . '`
					WHERE `category_id` = \'' . $_GET['category_id'] . '\'');
			$table_categories = $mysql->fetch();
			$template->set_file('admin', 'admin/categories/edit.tpl');
			$template->set_var(array(
				'ADMIN_CATEGORIES_HEADER3' => $lang['ADMIN_CATEGORIES_HEADER3'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'CATEGORY_ID' => $table_categories['category_id'],
				'CATEGORY_IMAGE' => $table_categories['category_image'],
				'EDIT' => $lang['EDIT'],
				'CATEGORY_NAME' => $table_categories['category_name'],
				'FORM_CATEGORY_IMAGE' => $lang['FORM_CATEGORY_IMAGE'],
				'FORM_CATEGORY_NAME' => $lang['FORM_CATEGORY_NAME']));
		}
	}
//
	elseif ($_POST['edit_category'])
	{
		$mysql->query('SELECT `category_name`
				FROM `' . TABLE_CATEGORIES . '`
				WHERE `category_name` = \'' . $_POST['category_name'] . '\' AND `category_id` != \'' . $_POST['category_id'] . '\'');
		$table_categories = $mysql->fetch();
		if ($table_categories['category_name'])
		{
			$error .= $lang['ADMIN_CATEGORIES_ERROR1'];
		}
		if (!trim($_POST['category_name']))
		{
			$error .= $lang['NO_CATEGORIES_NAME'];
		}
		if (!trim($_POST['category_image']))
		{
			$error .= $lang['NO_CATEGORIES_IMAGE'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('UPDATE `' . TABLE_CATEGORIES . '`
					SET `category_name` = \'' . $_POST['category_name'] . '\', `category_image` = \'' . $_POST['category_image'] . '\'
					WHERE `category_id` = \'' . $_POST['category_id'] . '\'
					LIMIT 1');
			success_template($lang['ADMIN_CATEGORIES_EDITED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
//
	elseif ($_GET['action'] == 'delete_category')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT `category_id`
					FROM `' . TABLE_NEWS . '`
					WHERE `category_id` = \'' . $_GET['category_id'] . '\'');
			$table_categories = $mysql->fetch();
			if ($table_categories['category_id'])
			{
				error_template($lang['ADMIN_CATEGORIES_ERROR2']);
			}
			else
			{
				$mysql->query('DELETE FROM `' . TABLE_CATEGORIES . '` WHERE `category_id` = \'' . $_GET['category_id'] . '\'');
				$mysql->query('OPTIMIZE TABLE `' . TABLE_CATEGORIES . '`');
				success_template($lang['ADMIN_CATEGORIES_DELETED']);
				header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
			}
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'add_smilies')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$template->set_file('admin', 'admin/smilies/add.tpl');
			$template->set_var(array(
				'ADD' => $lang['ADD'],
				'ADMIN_SMILIES_HEADER1' => $lang['ADMIN_SMILIES_HEADER1'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'FORM_SMILEY_CODE' => $lang['FORM_SMILEY_CODE'],
				'FORM_SMILEY_IMAGE' => $lang['FORM_SMILEY_IMAGE']));
		}
	}
//
	elseif ($_POST['add_smiley'])
	{
		$mysql->query('SELECT `smiley_code`
				FROM `' . TABLE_SMILIES . '`
				WHERE `smiley_code` = \'' . $_POST['smiley_code'] . '\'');
		$table_smilies = $mysql->fetch();
		if ($table_smilies['smiley_code'])
		{
			$error .= $lang['ADMIN_SMILIES_ERROR'];
		}
		if (!trim($_POST['smiley_code']))
		{
			$error .= $lang['NO_SMILEY_CODE'];
		}
		if (!trim($_POST['smiley_image']))
		{
			$error .= $lang['NO_SMILEY_IMAGE'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('INSERT INTO `' . TABLE_SMILIES . '`
					VALUES (\'\', \'' . $_POST['smiley_code'] . '\', \'' . $_POST['smiley_image'] . '\')');
			success_template($lang['ADMIN_SMILIES_ADDED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
//
	elseif ($_GET['action'] == 'edit_smilies')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$template->set_file('admin', 'admin/smilies/view.tpl');
			$template->set_block('admin', 'SMILIES_BLOCK', 'smilies');
			$mysql->query('SELECT *
					FROM `' . TABLE_SMILIES . '`');
			while ($table_smilies = $mysql->fetch())
			{
				$template->set_var(array(
					'DELETE' => $lang['DELETE'],
					'EDIT' => $lang['EDIT'],
					'SMILEY_CODE' => $table_smilies['smiley_code'],
					'SMILEY_ID' => $table_smilies['smiley_id'],
					'SMILEY_IMAGE' => $table_smilies['smiley_image']));
				$template->parse('smilies', 'SMILIES_BLOCK', true);
			}
			$template->set_var(array(
				'ADMIN_SMILIES_HEADER2' => $lang['ADMIN_SMILIES_HEADER2'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2']));
		}
	}
//
	elseif ($_GET['action'] == 'edit_smiley')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT *
					FROM `' . TABLE_SMILIES . '`
					WHERE `smiley_id` = \'' . $_GET['smiley_id'] . '\'');
			$table_smilies = $mysql->fetch();
			$template->set_file('admin', 'admin/smilies/edit.tpl');
			$template->set_var(array(
				'ADMIN_SMILIES_HEADER3' => $lang['ADMIN_SMILIES_HEADER3'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'EDIT' => $lang['EDIT'],
				'FORM_SMILEY_CODE' => $lang['FORM_SMILEY_CODE'],
				'FORM_SMILEY_IMAGE' => $lang['FORM_SMILEY_IMAGE'],
				'SMILEY_CODE' => $table_smilies['smiley_code'],
				'SMILEY_ID' => $table_smilies['smiley_id'],
				'SMILEY_IMAGE' => $table_smilies['smiley_image']));
		}
	}
//
	elseif ($_POST['edit_smiley'])
	{
		$mysql->query('SELECT `smiley_code`
				FROM `' . TABLE_SMILIES . '`
				WHERE `smiley_code` = \'' . $_POST['smiley_code'] . '\' AND `smiley_id` != \'' . $_POST['smiley_id'] . '\'');
		$table_smilies = $mysql->fetch();
		if ($table_smilies['smiley_code'])
		{
			$error .= $lang['ADMIN_SMILIES_ERROR'];
		}
		if (!trim($_POST['smiley_code']))
		{
			$error .= $lang['NO_SMILEY_CODE'];
		}
		if (!trim($_POST['smiley_image']))
		{
			$error .= $lang['NO_SMILEY_IMAGE'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('UPDATE `' . TABLE_SMILIES . '`
					SET `smiley_code` = \'' . $_POST['smiley_code'] . '\', `smiley_image` = \'' . $_POST['smiley_image'] . '\'
					WHERE `smiley_id` = \'' . $_POST['smiley_id'] . '\'
					LIMIT 1');
			success_template($lang['ADMIN_SMILIES_EDITED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
//
	elseif ($_GET['action'] == 'delete_smiley')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('DELETE FROM `' . TABLE_SMILIES . '`
					WHERE `smiley_id` = \'' . $_GET['smiley_id'] . '\'');
			$mysql->query('OPTIMIZE TABLE `' . TABLE_SMILIES . '`');
			success_template($lang['ADMIN_SMILIES_DELETED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'view_users')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT `user_id`, `user_name`
					FROM `' . TABLE_USERS . '`
					WHERE `user_id` != \'1\'
					ORDER BY `user_name`');
			while ($table_users = $mysql->fetch())
			{
				$user_name_list .= '<a href="./../admin/index.php?action=edit_users&amp;user_id=' . $table_users['user_id'] . '" title="' . $table_users['user_name'] . '">' . $table_users['user_name'] . '</a>&nbsp;(#' . $table_users['user_id'] . ')<br />';
			}
			$template->set_file('admin', 'admin/users/view.tpl');
			$template->set_var(array(
				'ADMIN_USERS_HEADER1' => $lang['ADMIN_USERS_HEADER1'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'FORM_USER_NAME' => $lang['FORM_USER_NAME'],
				'USER_NAME_LIST' => $user_name_list));
		}
	}
//
	elseif ($_GET['action'] == 'edit_users')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			if ($_GET['user_id'] == 1)
			{
				error_template($lang['ADMIN_USERS_ERROR']);
			}
			else
			{
				$mysql->query('SELECT `user_age`, `user_date_format`, `user_date_offset`, `user_email`, `user_ip`, `user_language`, `user_level`, `user_location`, `user_name`, `user_occupation`, `user_viewemail`, `user_website`
						FROM `' . TABLE_USERS . '`
						WHERE `user_id` = \'' . $_GET['user_id'] . '\'');
				$table_users = $mysql->fetch();
				if ($table_users['user_level'] == 0)
				{
					$level0_selected = ' selected="selected"';
					$level1_selected = '';
					$level2_selected = '';
					$level3_selected = '';
					$level4_selected = '';
				}
				elseif ($table_users['user_level'] == 1)
				{
					$level0_selected = '';
					$level1_selected = ' selected="selected"';
					$level2_selected = '';
					$level3_selected = '';
					$level4_selected = '';
				}
				elseif ($table_users['user_level'] == 2)
				{
					$level0_selected = '';
					$level1_selected = '';
					$level2_selected = ' selected="selected"';
					$level3_selected = '';
					$level4_selected = '';
				}
				elseif ($table_users['user_level'] == 3)
				{
					$level0_selected = '';
					$level1_selected = '';
					$level2_selected = '';
					$level3_selected = ' selected="selected"';
					$level4_selected = '';
				}
				else
				{
					$level0_selected = '';
					$level1_selected = '';
					$level2_selected = '';
					$level3_selected = '';
					$level4_selected = ' selected="selected"';
				}
				if ($table_users['user_language'] == 'dutch')
				{
					$dutch_selected = ' selected="selected"';
					$english_selected = '';
					$french_selected = '';
					$german_selected = '';
					$spanish_selected = '';
				}
				elseif ($table_users['user_language'] == 'english')
				{
					$dutch_selected = '';
					$english_selected = ' selected="selected"';
					$french_selected = '';
					$german_selected = '';
					$spanish_selected = '';
				}
				elseif ($table_users['user_language'] == 'french')
				{
					$dutch_selected = '';
					$english_selected = '';
					$french_selected = ' selected="selected"';
					$german_selected = '';
					$spanish_selected = '';
				}
				elseif ($table_users['user_language'] == 'german')
				{
					$dutch_selected = '';
					$english_selected = '';
					$french_selected = '';
					$german_selected = ' selected="selected"';
					$spanish_selected = '';
				}
				else
				{
					$dutch_selected = '';
					$english_selected = '';
					$french_selected = '';
					$german_selected = '';
					$spanish_selected = ' selected="selected"';
				}
				if ($table_users['user_viewemail'] == 0)
				{
					$no_selected = ' selected="selected"';
					$yes_selected = '';
				}
				else
				{
					$no_selected = '';
					$yes_selected = ' selected="selected"';
				}
				$template->set_file('admin', 'admin/users/edit.tpl');
				$template->set_var(array(
					'ADMIN_USERS_HEADER2' => $lang['ADMIN_USERS_HEADER2'],
					'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
					'DUTCH' => $lang['DUTCH'],
					'DUTCH_SELECTED' => $dutch_selected,
					'EDIT' => $lang['EDIT'],
					'ENGLISH' => $lang['ENGLISH'],
					'ENGLISH_SELECTED' => $english_selected,
					'FORM_USER_AGE' => $lang['FORM_USER_AGE'],
					'FORM_USER_DATE_FORMAT' => $lang['FORM_USER_DATE_FORMAT'],
					'FORM_USER_DATE_OFFSET' => $lang['FORM_USER_DATE_OFFSET'],
					'FORM_USER_EMAIL' => $lang['FORM_USER_EMAIL'],
					'FORM_USER_IP' => $lang['FORM_USER_IP'],
					'FORM_USER_LANGUAGE' => $lang['FORM_USER_LANGUAGE'],
					'FORM_USER_LEVEL' => $lang['FORM_USER_LEVEL'],
					'FORM_USER_LOCATION' => $lang['FORM_USER_LOCATION'],
					'FORM_USER_NAME' => $lang['FORM_USER_NAME'],
					'FORM_USER_OCCUPATION' => $lang['FORM_USER_OCCUPATION'],
					'FORM_USER_VIEWEMAIL' => $lang['FORM_USER_VIEWEMAIL'],
					'FORM_USER_WEBSITE' => $lang['FORM_USER_WEBSITE'],
					'FRENCH' => $lang['FRENCH'],
					'FRENCH_SELECTED' => $french_selected,
					'GERMAN' => $lang['GERMAN'],
					'GERMAN_SELECTED' => $german_selected,
					'LEVEL0_SELECTED' => $level0_selected,
					'LEVEL1_SELECTED' => $level1_selected,
					'LEVEL2_SELECTED' => $level2_selected,
					'LEVEL3_SELECTED' => $level3_selected,
					'LEVEL4_SELECTED' => $level4_selected,
					'NO' => $lang['NO'],
					'NO_SELECTED' => $no_selected,
					'SPANISH' => $lang['SPANISH'],
					'SPANISH_SELECTED' => $spanish_selected,
					'USER_AGE' => $table_users['user_age'],
					'USER_DATE_FORMAT' => $table_users['user_date_format'],
					'USER_DATE_OFFSET' => $table_users['user_date_offset'],
					'USER_EMAIL' => $table_users['user_email'],
					'USER_ID' => $_GET['user_id'],
					'USER_IP' => $table_users['user_ip'],
					'USER_LOCATION' => $table_users['user_location'],
					'USER_NAME' => $table_users['user_name'],
					'USER_OCCUPATION' => $table_users['user_occupation'],
					'USER_VIEWEMAIL' => $table_users['user_viwemail'],
					'USER_WEBSITE' => $table_users['user_website'],
					'YES' => $lang['YES'],
					'YES_SELECTED' => $yes_selected));
			}
		}
	}
//
	elseif ($_POST['edit_user'])
	{
		if (!trim($_POST['user_name']))
		{
			$error .= $lang['NO_USER_NAME'];
		}
		if (!trim($_POST['user_email']))
		{
			$error .= $lang['NO_USER_EMAIL'];
		}
		if (!trim($_POST['user_date_format']))
		{
			$error .= $lang['NO_USER_DATE_FORMAT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('UPDATE `' . TABLE_USERS . '`
					SET `user_age` = \'' . $_POST['user_age'] . '\', `user_date_format` = \'' . $_POST['user_date_format'] . '\', `user_date_offset` = \'' . $_POST['user_date_offset'] . '\', `user_email` = \'' . $_POST['user_email'] . '\', `user_language` = \'' . $_POST['user_language'] . '\', `user_level` = \'' . $_POST['user_level'] . '\', `user_location` = \'' . $_POST['user_location'] . '\', `user_name` = \'' . $_POST['user_name'] . '\', `user_occupation` = \'' . $_POST['user_occupation'] . '\', `user_viewemail` = \'' . $_POST['user_viewemail'] . '\', `user_website` = \'' . $_POST['user_website'] . '\'
					WHERE `user_id` = \'' . $_POST['user_id'] . '\'
					LIMIT 1');
			success_template($lang['ADMIN_USERS_EDITED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
//
	elseif ($_GET['action'] == 'purge_users')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$account_expiry = time() - ACCOUNT_EXPIRY;
			$mysql->query('DELETE FROM `' . TABLE_USERS . '`
					WHERE `user_id` != \'1\' AND `user_creation` < \'' . $account_expiry . '\' AND `user_key` != \'0\'');
			$mysql->query('OPTIMIZE TABLE `' . TABLE_USERS . '`');
			success_template($lang['ADMIN_USERS_PURGED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'edit_comment')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			if (!$_GET['comment_id'])
			{
				error_template($lang['ADMIN_COMMENTS_ERROR']);
			}
			else
			{
				$mysql->query('SELECT `allow_html`
						FROM `' . TABLE_SETTINGS . '`');
				$table_settings = $mysql->fetch();
				if ($table_settings['allow_html'] == 0)
				{
					$html_support = $lang['HTML_DISABLED'];
				}
				else
				{
					$html_support = $lang['HTML_ENABLED'];
				}
				$mysql->query('SELECT `comment_subject`, `comment_text`, `news_id`
						FROM `' . TABLE_COMMENTS . '`
						WHERE `comment_id` = \'' . $_GET['comment_id'] . '\'');
				$table_comments = $mysql->fetch();
				$mysql->query('SELECT `smiley_code`, `smiley_image`
						FROM `' . TABLE_SMILIES . '`');
				while ($table_smilies = $mysql->fetch())
				{
					$table_comments['comment_text'] = str_replace('<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $table_smilies['smiley_code'], $table_comments['comment_text']);
				}
				$table_comments['comment_text'] = undo_bbcode($table_comments['comment_text']);
				$template->set_file('admin', 'admin/comments/edit.tpl');
				$template->set_var(array(
					'ADMIN_COMMENTS_HEADER' => $lang['ADMIN_COMMENTS_HEADER'],
					'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
					'COMMENT_ID' => $_GET['comment_id'],
					'COMMENT_SUBJECT' => $table_comments['comment_subject'],
					'COMMENT_TEXT' => $table_comments['comment_text'],
					'DELETE' => $lang['DELETE'],
					'EDIT' => $lang['EDIT'],
					'FORM_COMMENT_SUBJECT' => $lang['FORM_COMMENT_SUBJECT'],
					'FORM_COMMENT_TEXT' => $lang['FORM_COMMENT_TEXT'],
					'HTML_SUPPORT' => $html_support,
					'NEWS_ID' => $table_comments['news_id']));
			}
		}
	}
//
	elseif ($_POST['edit_comment'])
	{
		if (!trim($_POST['comment_subject']))
		{
			$error .= $lang['NO_COMMENT_SUBJECT'];
		}
		if (!trim($_POST['comment_text']))
		{
			$error .= $lang['NO_COMMENT_TEXT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$comment_subject = htmlspecialchars($_POST['comment_subject']);
			$mysql->query('SELECT `allow_html`, `allow_smilies`
					FROM `' . TABLE_SETTINGS . '`');
			$table_settings = $mysql->fetch();
			if ($table_settings['allow_html'] == 0)
			{
				$comment_text = htmlspecialchars($_POST['comment_text']);
				$comment_text = do_bbcode($comment_text);
			}
			else
			{
				$comment_text = $_POST['comment_text'];
			}
			if ($table_settings['allow_smilies'] == 1)
			{
				$mysql->query('SELECT `smiley_code`, `smiley_image`
						FROM `' . TABLE_SMILIES . '`');
				while ($table_smilies = $mysql->fetch())
				{
					$comment_text = str_replace($table_smilies['smiley_code'], '<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $comment_text);
				}
			}
			$mysql->query('SELECT `comment_id`
					FROM `' . TABLE_COMMENTS . '`
					WHERE `comment_subject` = \'' . $_POST['comment_subject_old'] . '\' AND `news_id` = \'' . $_POST['news_id'] . '\'');
			$num_subject = $mysql->num_rows();
			if ($num_subject != 1)
			{
				$mysql->query('UPDATE `' . TABLE_COMMENTS . '`
						SET `comment_subject` = \'' . $comment_subject . '\'
						WHERE `comment_subject` = \'' . $_POST['comment_subject_old'] . '\'
						LIMIT ' . $num_subject . '');
				$mysql->query('UPDATE `' . TABLE_COMMENTS . '`
						SET `comment_text` = \'' . $comment_text . '\', `comment_edition` = \'' . time() . '\'
						WHERE `comment_id` = \'' . $_POST['comment_id'] . '\'
						LIMIT 1');
			}
			else
			{
				$mysql->query('UPDATE `' . TABLE_COMMENTS . '`
						SET `comment_subject` = \'' . $comment_subject . '\',`comment_text` = \'' . $comment_text . '\', `comment_edition` = \'' . time() . '\'
						WHERE `comment_id` = \'' . $_POST['comment_id'] . '\'
						LIMIT 1');
			}
			success_template($lang['ADMIN_COMMENTS_EDITED']);
			header('Refresh: 3; URL= ./../comments/index.php?news_id=' . $_POST['news_id'] . '');
		}
	}
//
	elseif ($_POST['delete_comment'])
	{
		$mysql->query('SELECT `news_id`, `user_id`
				FROM `' . TABLE_COMMENTS . '`
				WHERE `comment_id` = \'' . $_POST['comment_id'] . '\'');
		$table_comments = $mysql->fetch();
		$mysql->query('UPDATE `' . TABLE_NEWS . '`
				SET `news_comments` = news_comments - 1
				WHERE `news_id` = \'' . $table_comments['news_id'] . '\'
				LIMIT 1');
		$mysql->query('UPDATE `' . TABLE_USERS . '`
				SET `user_comments` = user_comments - 1
				WHERE `user_id` = \'' . $table_comments['user_id'] . '\'
				LIMIT 1');
		$mysql->query('DELETE FROM `' . TABLE_COMMENTS . '`
				WHERE `comment_id` = \'' . $_POST['comment_id'] . '\'');
		$mysql->query('OPTIMIZE TABLE `' . TABLE_COMMENTS . '`');
		success_template($lang['ADMIN_COMMENTS_DELETED']);
		header('Refresh: 3; URL= ./../comments/index.php?news_id=' . $_POST['news_id'] . '');
	}
// ------------------------------------------------------------------------------------------------
	elseif ($_GET['action'] == 'view_templates')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$template->set_file('admin', 'admin/templates/view.tpl');
			$template->set_var(array(
				'ADMIN_TEMPLATES_HEADER1' => $lang['ADMIN_TEMPLATES_HEADER1'],
				'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
				'TEMPLATES_LIST' => list_templates()));
		}
	}
//
	elseif ($_GET['action'] == 'edit_template')
	{
		if ($table_users['user_level'] < 4)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			if (!$_GET['file'])
			{
				error_template($lang['ADMIN_TEMPLATES_ERROR1']);
			}
			else
			{
				if (file_exists($_GET['file']))
				{
					$fp = fopen($_GET['file'], 'r');
					while (!feof($fp))
					{
						$template_content .= fgets($fp, 4096);
					}
					fclose($fp);
					$template_content = preg_replace('#{(.*?)}#', '%\\1%', $template_content);
					$template->set_file('admin', 'admin/templates/edit.tpl');
					$template->set_var(array(
						'ADMIN_TEMPLATES_HEADER2' => $lang['ADMIN_TEMPLATES_HEADER2'],
						'BACK_ADMIN_AREA2' => $lang['BACK_ADMIN_AREA2'],
						'EDIT' => $lang['EDIT'],
						'FILE' => $_GET['file'],
						'FORM_TEMPLATE_CONTENT' => $lang['FORM_TEMPLATE_CONTENT'],
						'TEMPLATE_CONTENT' => htmlspecialchars($template_content)));
				}
				else
				{
					error_template($lang['ADMIN_TEMPLATES_ERROR2']);
				}
			}
		}
	}
//
	elseif ($_POST['edit_template'])
	{
		if (!$_POST['file'])
		{
			error_template($lang['ADMIN_TEMPLATES_ERROR1']);
		}
		elseif (is_writable($_POST['file']))
		{
			$_POST['template_content'] = preg_replace('#%(.*?)%#', '{\\1}', $_POST['template_content']);
			$fp = fopen($_POST['file'], 'w');
			fputs($fp, stripslashes($_POST['template_content']), strlen($_POST['template_content']));
			fclose($fp);
			success_template($lang['ADMIN_TEMPLATES_EDITED']);
			header('Refresh: 3; URL= ./../admin/index.php?action=view_advanced_settings');
		}
		else
		{
			error_template($lang['ADMIN_TEMPLATES_ERROR3']);
		}
	}
// ------------------------------------------------------------------------------------------------
	else
	{
		if ($table_users['user_level'] < 2)
		{
			error_template($lang['ADMIN_LEVEL_ERROR']);
		}
		else
		{
			$mysql->query('SELECT `news_id`
					FROM `' . TABLE_NEWS . '`
					WHERE `news_active` = \'0\'');
			$num_news = $mysql->num_rows();
			if ($table_users['user_level'] > 1)
			{
				$news_management .= $lang['ADMIN_AREA1_LINK1'];
				if ($num_news != 0)
				{
					$news_management .= sprintf($lang['ADMIN_AREA1_LINK2'], $num_news);
				}
			}
			if ($table_users['user_level'] > 2)
			{
				$news_management .= $lang['ADMIN_AREA1_LINK3'];
			}
			if ($table_users['user_level'] > 3)
			{
				$advanced_settings .= $lang['ADMIN_AREA1_LINK4'];
			}
			else
			{
				$advanced_settings .= $lang['ADMIN_AREA2_ERROR'];
			}
			$template->set_file('admin', 'admin/area1.tpl');
			$template->set_var(array(
				'ADMIN_AREA1_HEADER' => $lang['ADMIN_AREA1_HEADER'],
				'ADMIN_IMG_AREA2' => $lang['ADMIN_IMG_AREA2'],
				'ADMIN_IMG_NEWS' => $lang['ADMIN_IMG_NEWS'],
				'ADVANCED_SETTINGS' => $advanced_settings,
				'BACK_HOME' => $lang['BACK_HOME'],
				'NEWS_MANAGEMENT' => $news_management));
		}
	}
}

page_header($lang['ADMIN_INDEX_TITLE']);
$template->pparse('', 'admin');
$template->pparse('', 'error');
$template->pparse('', 'success');
page_footer();

?>