<?php
// -------------------------------------------------------------
//
// $Id: function.php,v 1.12 2004/02/02 22:08:54 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

function close_tags($str)
{
	$tags = array(
		'a',
		'abbr',
		'acronym',
		'address',
// 		'<area />',
		'b',
// 		'<base />',
		'bdo',
		'big',
		'blockquote',
		'body',
// 		'<br />',
		'button',
		'caption',
		'cite',
		'code',
// 		'<col />',
		'colgroup',
		'dd',
		'del',
		'dfn',
		'div',
		'dl',
		'dt',
		'em',
		'fieldset',
		'form',
		'h1',
		'h2',
		'h3',
		'h4',
		'h5',
		'h6',
		'head',
// 		'<hr />',
		'html',
		'i',
// 		'<img />',
// 		'<input />',
		'ins',
		'kbd',
		'label',
		'legend',
		'li',
// 		'<link />',
		'map',
// 		'<meta />',
		'noscript',
		'object',
		'ol',
		'optgroup',
		'option',
		'p',
// 		'<param />',
		'pre',
		'q',
		'samp',
		'script',
		'select',
		'small',
		'span',
		'strong',
		'style',
		'sub',
		'sup',
		'table',
		'tbody',
		'td',
		'textarea',
		'tfoot',
		'th',
		'thead',
		'title',
		'tr',
		'tt',
		'ul',
		'var');
	foreach ($tags as $v)
	{
		$opened_tags = preg_match_all('#<(' . $v . ')( .*?)>#si', $str, $opened_matches, PREG_PATTERN_ORDER);
		$closed_tags = preg_match_all('#</(' . $v . ')>#si', $str, $closed_matches, PREG_PATTERN_ORDER);
		if ($opened_tags > $closed_tags)
		{
			for ($i = 0; $i < $opened_tags; $i++)
			{
				$str = $str . '</' . $opened_matches[1][$i] . '>';
			}
		}
	}
	return $str;
}

function do_bbcode($str)
{
	$str = preg_replace('#\[b\](.*?)\[/b\]#si', '<span style="font-weight: bold">\\1</span>', $str);
	$str = preg_replace('#\[i\](.*?)\[/i\]#si', '<span style="font-style: italic">\\1</span>', $str);
	$str = preg_replace('#\[u\](.*?)\[/u\]#si', '<span style="text-decoration: underline">\\1</span>', $str);
	$str = preg_replace('#\[color=(\#[0-9a-f]{3,6}|aqua|black|blue|fuchsia|gray|green|lime|maroon|navy|olive|purple|red|silver|teal|white|yellow)\](.*?)\[/color\]#si', '<span style="color: \\1">\\2</span>', $str);
	$str = preg_replace('#\[size=([1-2]?[0-9](px|pt)|smaller|larger)\](.*?)\[/size\]#si', '<span style="font-size: \\1; line-height: normal">\\3</span>', $str);
	$str = preg_replace('#\[url\]([\w]+?://[^ "\n\r\t<]*?)\[/url\]#si', '<a href="\\1" title="\\1">\\1</a>', $str);
	$str = preg_replace('#\[url\]((www|ftp)\.[^ "\n\r\t<]*?)\[/url\]#si', '<a href="http://\\1" title="\\1">\\1</a>', $str);
	$str = preg_replace('#\[url=([\w]+?://[^ "\n\r\t<]*?)\](.*?)\[/url\]#si', '<a href="\\1" title="\\2">\\2</a>', $str);
	$str = preg_replace('#\[url=((www|ftp)\.[^ "\n\r\t<]*?)\](.*?)\[/url\]#si', '<a href="http://\\1" title="\\3">\\3</a>', $str);
	$str = preg_replace('#\[img\]((ht|f)tp://)([^ "\r\n\t<]*?)\[/img\]#si', '<img src="\\1\\3" alt="." title="\\1\\3" />', $str);
	$str = preg_replace('#\[email\]([a-z0-9&\-_.]+?@[\w\-]+\.([\w\-\.]+\.)?[\w]+)\[/email\]#si', '<a href="mailto:\\1" title="\\1">\\1</a>', $str);
	return $str;
}

function error_template($msg)
{
	global $lang, $template;
	$template->set_file('error', 'error.tpl');
	$template->set_var(array(
		'BACK_HOME' => $lang['BACK_HOME'],
		'ERROR' => $msg));
}

function get_date_format()
{
	global $mysql;
	if ($_COOKIE['date_format'])
	{
		$date_format = $_COOKIE['date_format'];
	}
	elseif ($_SESSION['user_id'])
	{
		$mysql->query('SELECT `user_date_format`
				FROM `' . TABLE_USERS . '`
				WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
		$table_users = $mysql->fetch();
		$date_format = $table_users['user_date_format'];
	}
	else
	{
		$mysql->query('SELECT `date_format`
				FROM `' . TABLE_SETTINGS . '`');
		$table_settings = $mysql->fetch();
		$date_format = $table_settings['date_format'];
	}
	return $date_format;
}

function get_date_offset()
{
	global $mysql;
	if ($_COOKIE['date_offset'])
	{
		$date_offset = ($_COOKIE['date_offset'] * 3600);
	}
	elseif ($_SESSION['user_id'])
	{
		$mysql->query('SELECT `user_date_offset`
				FROM `' . TABLE_USERS . '`
				WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
		$table_users = $mysql->fetch();
		$date_offset = ($table_users['user_date_offset'] * 3600);
	}
	else
	{
		$mysql->query('SELECT `date_offset`
				FROM `' . TABLE_SETTINGS . '`');
		$table_settings = $mysql->fetch();
		$date_offset = ($table_settings['date_offset'] * 3600);
	}
	return $date_offset;
}

function get_language()
{
	global $mysql;
	if ($_COOKIE['language'])
	{
		$language = $_COOKIE['language'];
	}
	elseif ($_SESSION['user_id'])
	{
		$mysql->query('SELECT `user_language`
				FROM `' . TABLE_USERS . '`
				WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
		$table_users = $mysql->fetch();
		$language = $table_users['user_language'];
	}
	else
	{
		$mysql->query('SELECT `language`
				FROM `' . TABLE_SETTINGS . '`');
		$table_settings = $mysql->fetch();
		$language = $table_settings['language'];
	}
	return $language;
}

function get_new_comments($news_id)
{
	global $mysql;
	$mysql->query('SELECT ' . TABLE_COMMENTS . '.comment_id
			FROM `' . TABLE_COMMENTS . '`, `' . TABLE_USERS . '`
			WHERE ' . TABLE_COMMENTS . '.comment_creation > ' . TABLE_USERS . '.user_lastvisit AND ' . TABLE_COMMENTS . '.news_id = ' . $news_id . ' AND ' . TABLE_USERS . '.user_id = \'' . $_SESSION['user_id'] . '\'');
	if (!$_SESSION['user_id'])
	{
		$new_comments = '-';
	}
	else
	{
		$new_comments = $mysql->num_rows();
	}
	return $new_comments;
}

function get_online_users()
{
	$file = './../online_users.txt';
	$ip = $_SERVER['REMOTE_ADDR'];
	$expiry = 300;
	$n = 0;
	if (file_exists($file))
	{
		$fp = fopen($file, 'r');
		while (!feof($fp))
		{
			$row = fgets($fp, 4096);
			$table = explode('|', $row);
			if ($table[0] != $ip)
			{
				if ((time() - $table[1]) <= $expiry)
				{
					$n++;
					$data .= rtrim($row) . "\n";
				}
			}
		}
		fclose($fp);
	}
	$n++;
	$data .= rtrim($ip) . '|' . rtrim(time()) . "\n";
	$fp = fopen($file, 'w');
	fputs($fp, $data, strlen($data));
	fclose($fp);
	return $n;
}

function list_templates($path = './../templates/')
{
	$dir = dir($path);
	$data .= '<span style="font-weight: bold">' . $path . '</span>';
	$data .= '<blockquote><div>';
	while ($file = $dir->read())
	{
		if ($file != '.' && $file != '..')
		{
			if (is_dir($path . $file))
			{
				$data .= list_templates($path . $file . '/');
			}
			else
			{
				$data .= '<a href="./../admin/index.php?action=edit_template&amp;file=' . $path . $file . '" title="' . $file . '">' . $file . '</a><br />';
			}
		}
	}
	$dir->close();
	$data .= '</div></blockquote>';
	return $data;
}

function make_backend_rss()
{
	global $mysql;
	$mysql->query('SELECT `headlines_per_backend`, `sitename`, `siteurl`
			FROM `' . TABLE_SETTINGS . '`');
	$table_settings = $mysql->fetch();
	$rss .= '<?xml version="1.0" encoding="ISO-8859-1" ?>' . "\n";
	$rss .= '<!DOCTYPE rss PUBLIC "-//Netscape Communications//DTD RSS 0.91//EN" "http://my.netscape.com/publish/formats/rss-0.91.dtd">' . "\n";
	$rss .= '<rss version="0.91">' . "\n";
	$rss .= '<channel>' . "\n";
	$rss .= '<title>' . $table_settings['sitename'] . '</title>' . "\n";
	$rss .= '<link>' . $table_settings['siteurl'] . '</link>' . "\n";
	$rss .= '<description>' . $table_settings['sitename'] . '</description>' . "\n";
	$rss .= '<language>en</language>' . "\n";
	$mysql->query('SELECT `news_id`, `news_subject`
			FROM `' . TABLE_NEWS . '`
			WHERE `news_active` = \'1\'
			ORDER BY `news_date` DESC
			LIMIT 0, ' . $table_settings['headlines_per_backend'] . '');
	while ($table_news = $mysql->fetch())
	{
		$rss .= '<item>' . "\n";
		$rss .= '<title>' . $table_news['news_subject'] . '</title>' . "\n";
		$rss .= '<link>' . $table_settings['siteurl'] . '/index.php?news_id=' . $table_news['news_id'] . '</link>' . "\n";
		$rss .= '</item>' . "\n";
	}
	$rss .= '</channel>' . "\n";
	$rss .= '</rss>';
	$fp = fopen('./../backends/backend.rss', 'w');
	fputs($fp, $rss, strlen($rss));
	fclose($fp);
}

function make_backend_txt()
{
	global $mysql;
	$mysql->query('SELECT `headlines_per_backend`, `siteurl`
			FROM `' . TABLE_SETTINGS . '`');
	$table_settings = $mysql->fetch();
	$mysql->query('SELECT `news_date`, `news_id`, `news_subject`
			FROM `' . TABLE_NEWS . '`
			WHERE `news_active` = \'1\'
			ORDER BY `news_date` DESC
			LIMIT 0, ' . $table_settings['headlines_per_backend'] . '');
	while ($table_news = $mysql->fetch())
	{
		$txt .= '%%' . "\n";
		$txt .= $table_news['news_date'] . "\n";
		$txt .= $table_news['news_subject'] . "\n";
		$txt .= $table_settings['siteurl'] . '/index.php?news_id=' . $table_news['news_id'] . "\n";
	}
	$fp = fopen('./../backends/backend.txt', 'w');
	fputs($fp, $txt, strlen($txt));
	fclose($fp);
}

function page_footer()
{
	global $lang, $mysql, $start_time, $template;
	$mtime = explode(' ', microtime());
	$end_time = $mtime[1] + $mtime[0];
	$total_time = number_format(($end_time - $start_time), 3, '.', ' ') . ' s';
	$mysql->query('SELECT `sitename`
			FROM `' . TABLE_SETTINGS . '`');
	$table_settings = $mysql->fetch();
	$template->set_file('footer', 'footer.tpl');
	$template->set_var(array(
		// --------------------
		'FOOTER_EXTRA_1' => $lang['FOOTER_EXTRA_1'],
		'FOOTER_EXTRA_2' => $lang['FOOTER_EXTRA_2'],
		'FOOTER_EXTRA_3' => $lang['FOOTER_EXTRA_3'],
		'FOOTER_EXTRA_4' => $lang['FOOTER_EXTRA_4'],
		'FOOTER_EXTRA_5' => $lang['FOOTER_EXTRA_5'],
		'FOOTER_EXTRA_6' => $lang['FOOTER_EXTRA_6'],
		'FOOTER_EXTRA_7' => $lang['FOOTER_EXTRA_7'],
		'FOOTER_EXTRA_8' => $lang['FOOTER_EXTRA_8'],
		'FOOTER_EXTRA_9' => $lang['FOOTER_EXTRA_9'],
		'FOOTER_EXTRA_10' => $lang['FOOTER_EXTRA_10'],
		'FOOTER_EXTRA_11' => $lang['FOOTER_EXTRA_11'],
		'FOOTER_EXTRA_12' => $lang['FOOTER_EXTRA_12'],
		'FOOTER_EXTRA_13' => $lang['FOOTER_EXTRA_13'],
		'FOOTER_EXTRA_14' => $lang['FOOTER_EXTRA_14'],
		'FOOTER_EXTRA_15' => $lang['FOOTER_EXTRA_15'],
		// --------------------
		'PAGE_COPYRIGHT' => sprintf($lang['PAGE_COPYRIGHT'], $table_settings['sitename']),
		'PAGE_GENERATION' => sprintf($lang['PAGE_GENERATION'], $total_time, $mysql->num_queries()),
		'PAGE_POWERED' => sprintf($lang['PAGE_POWERED'], GENU_VERSION)));
	$template->pparse('', 'footer');
}

function page_header($page_title)
{
	global $lang, $mysql, $template;
	$mysql->query('SELECT `user_name`
			FROM `' . TABLE_USERS . '`
			WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
	$table_users = $mysql->fetch();
	if (!$_SESSION['user_id'])
	{
		$login_form = '&middot; <a href="./../users/login.php" title="' . $lang['HEADER_BLOCK2_LINK1'] . '">' . $lang['HEADER_BLOCK2_LINK1'] . '</a>';
	}
	else
	{
		$login_form = sprintf($lang['HEADER_BLOCK2_CONTENT'], $table_users['user_name']);
	}
	$mysql->query('SELECT `user_id`
			FROM `' . TABLE_USERS . '`
			WHERE `user_level` != \'0\'');
	$num_users = $mysql->num_rows();
	$mysql->query('SELECT `sitename`, `siteurl`
			FROM `' . TABLE_SETTINGS . '`');
	$table_settings = $mysql->fetch();
	$template->set_file('header', 'header.tpl');
	$template->set_var(array(
		'HEADER_BLOCK1_LINK1' => $lang['HEADER_BLOCK1_LINK1'],
		'HEADER_BLOCK1_LINK2' => $lang['HEADER_BLOCK1_LINK2'],
		'HEADER_BLOCK1_LINK3' => $lang['HEADER_BLOCK1_LINK3'],
		'HEADER_BLOCK1_LINK4' => $lang['HEADER_BLOCK1_LINK4'],
		'HEADER_BLOCK1_TITLE' => $lang['HEADER_BLOCK1_TITLE'],
		'HEADER_BLOCK2_LINK2' => $lang['HEADER_BLOCK2_LINK2'],
		'HEADER_BLOCK2_LINK3' => $lang['HEADER_BLOCK2_LINK3'],
		'HEADER_BLOCK2_TITLE' => $lang['HEADER_BLOCK2_TITLE'],
		'HEADER_BLOCK3_SUBJECT' => $lang['HEADER_BLOCK3_SUBJECT'],
		'HEADER_BLOCK3_TEXT' => $lang['HEADER_BLOCK3_TEXT'],
		'HEADER_BLOCK3_TITLE' => $lang['HEADER_BLOCK3_TITLE'],
		'HEADER_BLOCK4_CONTENT' => sprintf($lang['HEADER_BLOCK4_CONTENT'], get_online_users()),
		'HEADER_BLOCK4_TITLE' => $lang['HEADER_BLOCK4_TITLE'],
		// --------------------
		'HEADER_EXTRA_1' => $lang['HEADER_EXTRA_1'],
		'HEADER_EXTRA_2' => $lang['HEADER_EXTRA_2'],
		'HEADER_EXTRA_3' => $lang['HEADER_EXTRA_3'],
		'HEADER_EXTRA_4' => $lang['HEADER_EXTRA_4'],
		'HEADER_EXTRA_5' => $lang['HEADER_EXTRA_5'],
		'HEADER_EXTRA_6' => $lang['HEADER_EXTRA_6'],
		'HEADER_EXTRA_7' => $lang['HEADER_EXTRA_7'],
		'HEADER_EXTRA_8' => $lang['HEADER_EXTRA_8'],
		'HEADER_EXTRA_9' => $lang['HEADER_EXTRA_9'],
		'HEADER_EXTRA_10' => $lang['HEADER_EXTRA_10'],
		'HEADER_EXTRA_11' => $lang['HEADER_EXTRA_11'],
		'HEADER_EXTRA_12' => $lang['HEADER_EXTRA_12'],
		'HEADER_EXTRA_13' => $lang['HEADER_EXTRA_13'],
		'HEADER_EXTRA_14' => $lang['HEADER_EXTRA_14'],
		'HEADER_EXTRA_15' => $lang['HEADER_EXTRA_15'],
		// --------------------
		'LOGIN_FORM' => $login_form,
		'NUM_USERS' => $num_users,
		'PAGE_REVISION' => date('Ymd', getlastmod()),
		'PAGE_TITLE' => $page_title,
		'SEARCH' => $lang['SEARCH'],
		'SITENAME' => $table_settings['sitename'],
		'SITEURL' => $table_settings['siteurl']));
	$template->pparse('', 'header');
}

function set_user_cookies()
{
	global $mysql;
	$mysql->query('SELECT `user_date_format`, `user_date_offset`, `user_language`
			FROM `' . TABLE_USERS . '`
			WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
	$table_users = $mysql->fetch();
	setcookie('language', $table_users['user_language'], (time() + COOKIE_EXPIRY), '/', '');
	setcookie('date_format', $table_users['user_date_format'], (time() + COOKIE_EXPIRY), '/', '');
	setcookie('date_offset', $table_users['user_date_offset'], (time() + COOKIE_EXPIRY), '/', '');
}

/* Code from phpBB (http://www.phpbb.com/) */
function slash_input_data(&$data)
{
	if (is_array($data))
	{
		foreach ($data as $k => $v)
		{
			$data[$k] = (is_array($v)) ? slash_input_data($v) : addslashes($v);
		}
	}
	return $data;
}

function success_template($msg)
{
	global $lang, $template;
	$template->set_file('success', 'success.tpl');
	$template->set_var(array(
		'BACK_HOME' => $lang['BACK_HOME'],
		'SUCCESS' => $msg));
}

function undo_bbcode($str)
{
	$str = preg_replace('#<span style="font-weight: bold">(.*?)</span>#si', '[b]\\1[/b]', $str);
	$str = preg_replace('#<span style="font-style: italic">(.*?)</span>#si', '[i]\\1[/i]', $str);
	$str = preg_replace('#<span style="text-decoration: underline">(.*?)</span>#si', '[u]\\1[/u]', $str);
	$str = preg_replace('#<span style="color: (.*?)">(.*?)</span>#si', '[color=\\1]\\2[/color]', $str);
	$str = preg_replace('#<span style="font-size: (.*?); line-height: normal">(.*?)</span>#si', '[size=\\1]\\2[/size]', $str);
	$str = preg_replace('#<a href="([\w]+?://[^ "\n\r\t<]*?)" title="(.*?)">(.*?)</a>#si', '[url=\\1]\\3[/url]', $str);
	$str = preg_replace('#<img src="(.*?)" alt="." title="(.*?)" />#si', '[img]\\1[/img]', $str);
	$str = preg_replace('#<a href="mailto:(.*?)" title="(.*?)">(.*?)</a>#si', '[email]\\1[/email]', $str);
	return $str;
}

?>