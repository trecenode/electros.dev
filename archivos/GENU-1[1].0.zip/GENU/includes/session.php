<?php
// -------------------------------------------------------------
//
// $Id: session.php,v 1.1.1.1 2004/01/15 20:04:10 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

function sess_open()
{
	return true;
}

function sess_close()
{
	return true;
}

function sess_read($id)
{
	global $mysql;
	$mysql->query('SELECT `session_value`
			FROM `' . TABLE_SESSIONS . '`
			WHERE `session_id` = \'' . $id . '\' AND `session_expiry` > \'' . time() . '\'');
	$table_sessions = $mysql->fetch();
	if ($table_sessions['session_value'])
	{
		return $table_sessions['session_value'];
	}
	else
	{
		return '';
	}
}

function sess_write($id, $sess_data)
{
	global $mysql;
	$mysql->query('SELECT `session_id`
			FROM `' . TABLE_SESSIONS . '`
			WHERE `session_id` = \'' . $id . '\'');
	$table_sessions = $mysql->fetch();
	if ($table_sessions['session_id'])
	{
		$mysql->query('UPDATE `' . TABLE_SESSIONS . '`
				SET `session_value` = \'' . $sess_data . '\'
				WHERE `session_id` = \'' . $id . '\'
				LIMIT 1');
	}
	else
	{
		$mysql->query('INSERT INTO `' . TABLE_SESSIONS . '` VALUES (\'' . $id . '\', \'\', \'' . (time() + 3600) . '\')');
	}
	return true;
}

function sess_destroy($id)
{
	global $mysql;
	$mysql->query('UPDATE `' . TABLE_USERS . '`
			SET `user_lastvisit` = \'' . time() . '\'
			WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
	$mysql->query('DELETE FROM `' . TABLE_SESSIONS . '`
			WHERE `session_id` = \'' . $id . '\'');
	$mysql->query('OPTIMIZE TABLE `' . TABLE_SESSIONS . '`');
	return true;
}

function sess_gc($maxlifetime)
{
	global $mysql;
	$mysql->query('DELETE FROM `' . TABLE_SESSIONS . '`
			WHERE `session_expiry` < \'' . (time() + $maxlifetime) . '\'');
	$mysql->query('OPTIMIZE TABLE `' . TABLE_SESSIONS . '`');
	return true;
}

session_set_save_handler('sess_open', 'sess_close', 'sess_read', 'sess_write', 'sess_destroy', 'sess_gc');
session_start();

?>