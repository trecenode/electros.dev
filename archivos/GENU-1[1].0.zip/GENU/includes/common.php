<?php
// -------------------------------------------------------------
//
// $Id: common.php,v 1.4 2004/02/01 22:54:12 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

$mtime = explode(' ', microtime());
$start_time = $mtime[1] + $mtime[0];

error_reporting(E_ALL ^ E_NOTICE);
// error_reporting(E_ALL);

$table_prefix = 'genu_';
define('ACCOUNT_EXPIRY', 2592000);
define('COOKIE_EXPIRY', 2592000);
define('GENU_VERSION', '1.0');
define('MAX_NEWS_LENGHT', 1024);
define('MIN_NAME_LENGHT', 3);
define('MIN_PASS_LENGHT', 3);
define('POST_INTERVAL', 30);
define('SEARCH_LIMIT', 30);
define('TABLE_CATEGORIES', $table_prefix . 'categories');
define('TABLE_COMMENTS', $table_prefix . 'comments');
define('TABLE_NEWS', $table_prefix . 'news');
define('TABLE_SESSIONS', $table_prefix . 'sessions');
define('TABLE_SETTINGS', $table_prefix . 'settings');
define('TABLE_SMILIES', $table_prefix . 'smilies');
define('TABLE_USERS', $table_prefix . 'users');
define('WORD_WRAP', 95);

include('./../includes/mysql.php');
$mysql = new mysql;
include('./../includes/function.php');
include('./../includes/session.php');
include('./../includes/template.php');
$template = new template('./../templates');
include('./../languages/' . get_language() . '.php');

set_magic_quotes_runtime(0);
if (!get_magic_quotes_gpc())
{
	$_GET = slash_input_data($_GET);
	$_POST = slash_input_data($_POST);
	$_COOKIE = slash_input_data($_COOKIE);
}

?>