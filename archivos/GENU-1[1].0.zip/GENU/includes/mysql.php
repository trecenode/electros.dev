<?php
// -------------------------------------------------------------
//
// $Id: mysql.php,v 1.1.1.1 2004/01/15 20:04:10 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

class mysql
{
	// ---------------------------
	var $host = 'host';
	var $user = 'user';
	var $password = 'password';
	var $database = 'database';
	// ---------------------------
	var $link_id = 0;
	var $num_queries = 0;
	var $query_id = 0;

	function connect()
	{
		$this->link_id = @mysql_connect($this->host, $this->user, $this->password);
		if (!$this->link_id)
		{
			die('Connection to MySQL server failed.');
		}
		if (!@mysql_select_db($this->database, $this->link_id))
		{
			die('Unable to select database.');
		}
		return $this->link_id;
	}

	function fetch()
	{
		if (!$this->query_id)
		{
			return false;
		}
		return @mysql_fetch_array($this->query_id);
	}

	function num_rows()
	{
		if (!$this->query_id)
		{
			return false;
		}
		return @mysql_num_rows($this->query_id);
	}

	function num_queries()
	{
		return $this->num_queries;
	}

	function query($sql)
	{
		if (!$sql)
		{
			return false;
		}
		if (!$this->connect())
		{
			return false;
		}
		if ($this->query_id)
		{
			$this->free();
		}
		$this->query_id = @mysql_query($sql, $this->link_id);
		if (!$this->query_id)
		{
			die('Something is wrong in your query syntax.');
		}
		$this->num_queries++;
		return $this->query_id;
	}

	function free()
	{
		@mysql_free_result($this->query_id);
		$this->query_id = 0;
	}

	function version()
	{
		return substr(@mysql_get_server_info($this->link_id), 0, 7);
	}

	function close()
	{
		if (!$this->link_id)
		{
			return false;
		}
		return @mysql_close($this->link_id);
	}
}

?>