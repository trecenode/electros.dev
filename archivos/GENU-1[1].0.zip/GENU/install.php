<?php
// -------------------------------------------------------------
//
// $Id: install.php,v 1.12 2004/02/04 21:47:04 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

error_reporting(E_ALL ^ E_NOTICE);
// error_reporting(E_ALL);

include('./includes/mysql.php');
$mysql = new mysql;

/* Code from phpBB (http://www.phpbb.com/) */
function slash_input_data(&$data)
{
	if (is_array($data))
	{
		foreach ($data as $k => $v)
		{
			$data[$k] = (is_array($v)) ? slash_input_data($v) : addslashes($v);
		}
	}
	return $data;
}

set_magic_quotes_runtime(0);
if (!get_magic_quotes_gpc())
{
	$_GET = slash_input_data($_GET);
	$_POST = slash_input_data($_POST);
}

define('MIN_NAME_LENGHT', 3);
define('MIN_PASS_LENGHT', 6);

echo '<html>';
echo '<head>';
echo '<title>GENU installation</title>';
echo '</head>';
echo '<body>';

if ($_GET['step'] == 2)
{
	$mysql->query('CREATE TABLE genu_categories (
	category_id TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
	category_name VARCHAR(16) NOT NULL DEFAULT \'\',
	category_image VARCHAR(255) NOT NULL DEFAULT \'\',
	PRIMARY KEY (category_id)
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_categories</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_comments (
	comment_id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	news_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT \'0\',
	user_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT \'0\',
	comment_subject VARCHAR(64) NOT NULL DEFAULT \'\',
	comment_text TEXT NOT NULL,
	comment_creation INT(11) NOT NULL DEFAULT \'0\',
	comment_edition INT(11) NOT NULL DEFAULT \'0\',
	PRIMARY KEY (comment_id)
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_comments</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_news (
	news_id SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
	category_id TINYINT(3) UNSIGNED NOT NULL DEFAULT \'0\',
	user_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT \'0\',
	news_active ENUM(\'0\',\'1\') NOT NULL DEFAULT \'0\',
	news_subject VARCHAR(64) NOT NULL DEFAULT \'\',
	news_text TEXT NOT NULL,
	news_source VARCHAR(255) NOT NULL DEFAULT \'\',
	news_comments SMALLINT(5) UNSIGNED NOT NULL DEFAULT \'0\',
	news_date INT(11) NOT NULL DEFAULT \'0\',
	news_month VARCHAR(2) NOT NULL DEFAULT \'\',
	news_year VARCHAR(4) NOT NULL DEFAULT \'\',
	PRIMARY KEY (news_id),
	FULLTEXT KEY news_subject (news_subject),
	FULLTEXT KEY news_text (news_text)
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_news</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_sessions (
	session_id VARCHAR(32) NOT NULL DEFAULT \'\',
	session_value VARCHAR(255) NOT NULL DEFAULT \'\',
	session_expiry INT(11) NOT NULL DEFAULT \'0\'
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_sessions</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_settings (
	sitename VARCHAR(64) NOT NULL DEFAULT \'\',
	siteurl VARCHAR(255) NOT NULL DEFAULT \'\',
	language ENUM(\'dutch\',\'english\',\'french\',\'german\',\'spanish\') NOT NULL DEFAULT \'english\',
	news_per_page TINYINT(2) UNSIGNED NOT NULL DEFAULT \'7\',
	comments_per_page TINYINT(2) UNSIGNED NOT NULL DEFAULT \'7\',
	headlines_per_backend TINYINT(2) UNSIGNED NOT NULL DEFAULT \'7\',
	news_order ENUM(\'news_date\',\'news_month\',\'news_year\') NOT NULL DEFAULT \'news_date\',
	allow_html ENUM(\'0\',\'1\') NOT NULL DEFAULT \'0\',
	allow_smilies ENUM(\'0\',\'1\') NOT NULL DEFAULT \'1\',
	submit_news ENUM(\'0\',\'1\') NOT NULL DEFAULT \'1\',
	send_news ENUM(\'0\',\'1\') NOT NULL DEFAULT \'1\',
	register_users ENUM(\'0\',\'1\') NOT NULL DEFAULT \'1\',
	date_format VARCHAR(64) NOT NULL DEFAULT \'D, M jS Y, g:i a\',
	date_offset TINYINT(3) NOT NULL DEFAULT \'0\'
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_settings</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_smilies (
	smiley_id TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
	smiley_code VARCHAR(16) NOT NULL DEFAULT \'\',
	smiley_image VARCHAR(255) NOT NULL DEFAULT \'\',
	PRIMARY KEY (smiley_id)
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_smilies</span> created successfully.<br />';
	$mysql->query('CREATE TABLE genu_users (
	user_id SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
	user_level ENUM(\'0\',\'1\',\'2\',\'3\',\'4\') NOT NULL DEFAULT \'1\',
	user_name VARCHAR(16) NOT NULL DEFAULT \'\',
	user_password VARCHAR(32) NOT NULL DEFAULT \'\',
	user_email VARCHAR(64) NOT NULL DEFAULT \'\',
	user_viewemail ENUM(\'0\',\'1\') NOT NULL DEFAULT \'0\',
	user_website VARCHAR(255) NOT NULL DEFAULT \'\',
	user_location VARCHAR(64) NOT NULL DEFAULT \'\',
	user_occupation VARCHAR(64) NOT NULL DEFAULT \'\',
	user_age VARCHAR(3) NOT NULL DEFAULT \'\',
	user_comments SMALLINT(5) UNSIGNED NOT NULL DEFAULT \'0\',
	user_creation INT(11) NOT NULL DEFAULT \'0\',
	user_ip VARCHAR(15) NOT NULL DEFAULT \'\',
	user_language ENUM(\'dutch\',\'english\',\'french\',\'german\',\'spanish\') NOT NULL DEFAULT \'english\',
	user_date_format VARCHAR(64) NOT NULL DEFAULT \'D, M jS Y, g:i a\',
	user_date_offset TINYINT(3) NOT NULL DEFAULT \'0\',
	user_lastvisit INT(11) NOT NULL DEFAULT \'0\',
	user_key VARCHAR(32) NOT NULL DEFAULT \'\',
	PRIMARY KEY (user_id)
	) TYPE=MyISAM');
	echo 'Table <span style="font-weight: bold">genu_users</span> created successfully.<br /><br />';
	echo '<a href="./install.php?step=3" title="next step">next step</a>';
}
elseif ($_GET['step'] == 3)
{
	echo 'Please fill in the form with a username, a password and a <span style="font-weight: bold">valid e-mail address</span>:<br /><br />';
	echo '<form method="post" action="./install.php">';
	echo '<table cellspacing="0" cellpadding="5">';
	echo '	<tr>';
	echo '		<td align="right">Username:</td>';
	echo '		<td><input type="text" name="user_name" size="25" maxlength="16" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td align="right">Password:</td>';
	echo '		<td><input type="password" name="user_password" size="25" maxlength="32" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td align="right">Password (confirmation):</td>';
	echo '		<td><input type="password" name="user_password2" size="25" maxlength="32" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td align="right">E-mail:</td>';
	echo '		<td><input type="text" name="user_email" size="25" maxlength="64" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td colspan="2" align="right"><input type="submit" value="Send" name="add_user" /></td>';
	echo '	</tr>';
	echo '</table>';
	echo '</form>';
}
elseif ($_POST['add_user'])
{
	if (!trim($_POST['user_name']))
	{
		$error .= 'You must supply a username.<br />';
	}
	if ($_POST['user_name'])
	{
		if (strlen(trim($_POST['user_name'])) < MIN_NAME_LENGHT)
		{
			$error .= sprintf('Username must be at least %s characters long.<br />', MIN_NAME_LENGHT);
		}
	}
	if (!trim($_POST['user_password']))
	{
		$error .= 'You must supply a password.<br />';
	}
	if ($_POST['user_password'])
	{
		if (strlen(trim($_POST["user_password"])) < MIN_PASS_LENGHT)
		{
			$error .= sprintf('Password must be at least %s characters long.<br />', MIN_PASS_LENGHT);
		}
	}
	if (trim($_POST['user_password2']) != trim($_POST['user_password']))
	{
		$error .= 'Passwords don\'t match.<br />';
	}
	if (!trim($_POST['user_email']))
	{
		$error .= 'You must supply an e-mail address.<br />';
	}
	if ($error)
	{
		echo $error;
	}
	else
	{
		$mysql->query('INSERT INTO `genu_users` (`user_level`, `user_name`, `user_password`, `user_email`, `user_creation`, `user_ip`)
				VALUES (\'4\', \'' . $_POST['user_name'] . '\', \'' . md5($_POST['user_password']) . '\', \'' . $_POST['user_email'] . '\', \'' . time() . '\', \'' . $_SERVER['REMOTE_ADDR'] . '\')');
		echo 'User created successfully.<br /><br />';
		echo '<a href="./install.php?step=4" title="next step">next step</a>';
	}
}
elseif ($_GET['step'] == 4)
{
	echo 'Please fill in the form with your site name and URL (without trailing slash /):<br /><br />';
	echo '<form method="post" action="./install.php">';
	echo '<table cellspacing="0" cellpadding="5">';
	echo '	<tr>';
	echo '		<td align="right">Site name:</td>';
	echo '		<td><input type="text" name="sitename" size="20" maxlength="64" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td align="right">Site URL:</td>';
	echo '		<td><input type="text" name="siteurl" size="20" maxlength="255" value="http://" /></td>';
	echo '	</tr>';
	echo '	<tr>';
	echo '		<td colspan="2" align="right"><input type="submit" value="Send" name="add_smilies" /></td>';
	echo '	</tr>';
	echo '</table>';
	echo '</form>';
}
elseif ($_POST['add_smilies'])
{
	if (!trim($_POST['sitename']))
	{
		$error .= 'You must supply a site name.<br />';
	}
	if (!trim($_POST['siteurl']))
	{
		$error .= 'You must supply a site URL.<br />';
	}
	if (ereg('/$', trim($_POST['siteurl'])))
	{
		$error .= 'Trailing slash is not allowed in site URL.<br />';
	}
	if ($error)
	{
		echo $error;
	}
	else
	{
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':)\', \'' . $_POST['siteurl'] . '/images/smilies/01.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':(\', \'' . $_POST['siteurl'] . '/images/smilies/02.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':D\', \'' . $_POST['siteurl'] . '/images/smilies/03.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \';)\', \'' . $_POST['siteurl'] . '/images/smilies/04.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':o\', \'' . $_POST['siteurl'] . '/images/smilies/05.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \'8)\', \'' . $_POST['siteurl'] . '/images/smilies/06.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':|\', \'' . $_POST['siteurl'] . '/images/smilies/07.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':p\', \'' . $_POST['siteurl'] . '/images/smilies/08.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':lol:\', \'' . $_POST['siteurl'] . '/images/smilies/09.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':confused:\', \'' . $_POST['siteurl'] . '/images/smilies/10.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':rolleyes:\', \'' . $_POST['siteurl'] . '/images/smilies/11.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':mad:\', \'' . $_POST['siteurl'] . '/images/smilies/12.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':shock:\', \'' . $_POST['siteurl'] . '/images/smilies/13.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':cry:\', \'' . $_POST['siteurl'] . '/images/smilies/14.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':redface:\', \'' . $_POST['siteurl'] . '/images/smilies/15.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':evil:\', \'' . $_POST['siteurl'] . '/images/smilies/16.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':!:\', \'' . $_POST['siteurl'] . '/images/smilies/17.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':?:\', \'' . $_POST['siteurl'] . '/images/smilies/18.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':idea:\', \'' . $_POST['siteurl'] . '/images/smilies/19.gif\')');
		$mysql->query('INSERT INTO `genu_smilies`
				VALUES (\'\', \':arrow:\', \'' . $_POST['siteurl'] . '/images/smilies/20.gif\')');
		$mysql->query('INSERT INTO `genu_settings` (`sitename`, `siteurl`)
				VALUES (\'' . $_POST['sitename'] . '\', \'' . $_POST['siteurl'] . '\')');
		echo 'Settings updated and smilies added successfully.<br /><br />';
		echo 'Installation is finished, please delete <span style="font-weight: bold">install.php</span> file from your server.<br />';
		echo 'You can now access to the <a href="' . $_POST['siteurl'] . '/index.php" title="index page">index page</a> of your website.';
	}
}
else
{
	echo 'Welcome to GENU installation.<br /><br />';
	echo 'In order to have GENU working completely, the following is required:<br />';
	echo '&middot; A webserver or web hosting account<br />';
	echo '&middot; PHP 4.1.0 or higher (with mail function enabled, preferably)<br />';
	echo '&middot; A MySQL database (3.23.23 or higher)<br /><br />';
	echo '<a href="./install.php?step=2" title="next step">next step</a>';
}

echo '</body>';
echo '</html>';

?>