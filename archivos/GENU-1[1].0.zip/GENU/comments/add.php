<?php
// -------------------------------------------------------------
//
// $Id: add.php,v 1.2 2004/01/20 20:27:43 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

include('./../includes/common.php');

if ($_SESSION['user_id'])
{
	$mysql->query('SELECT `news_id`
			FROM ' . TABLE_NEWS . '
			WHERE `news_id` = \'' . $_REQUEST['news_id'] . '\'');
	$table_news = $mysql->fetch();
	if ($table_news['news_id'])
	{
		if ($_POST['add_comment'])
		{
			if (!trim($_POST['comment_subject']))
			{
				$error .= $lang['NO_COMMENT_SUBJECT'];
			}
			if (!trim($_POST['comment_text']))
			{
				$error .= $lang['NO_COMMENT_TEXT'];
			}
			$mysql->query('SELECT `comment_creation`
					FROM ' . TABLE_COMMENTS . '
					WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'');
			while ($table_comments = $mysql->fetch())
			{
				if ($table_comments['comment_creation'] >= (time() - POST_INTERVAL))
				{
					$error .= sprintf($lang['COMMENTS_ADD_ERROR1'], POST_INTERVAL);
				}
			}
			if ($error)
			{
				error_template($error);
			}
			else
			{
				$comment_subject = htmlspecialchars($_POST['comment_subject']);
				$mysql->query('SELECT `allow_html`, `allow_smilies`
						FROM `' . TABLE_SETTINGS . '`');
				$table_settings = $mysql->fetch();
				if ($table_settings['allow_html'] == 0)
				{
					$comment_text = htmlspecialchars($_POST['comment_text']);
					$comment_text = do_bbcode($comment_text);
				}
				else
				{
					$comment_text = $_POST['comment_text'];
				}
				if ($table_settings['allow_smilies'] == 1)
				{
					$mysql->query('SELECT `smiley_code`, `smiley_image`
							FROM `' . TABLE_SMILIES . '`');
					while ($table_smilies = $mysql->fetch())
					{
						$comment_text = str_replace($table_smilies['smiley_code'], '<img src="' . $table_smilies['smiley_image'] . '" alt="." title="' . $table_smilies['smiley_code'] . '" />', $comment_text);
					}
				}
				$mysql->query('INSERT INTO `' . TABLE_COMMENTS . '`
						VALUES (\'\', \'' . $_POST['news_id'] . '\', \'' . $_SESSION['user_id'] . '\', \'' . $comment_subject . '\', \'' . $comment_text . '\', \'' . time() . '\', \'\')');
				$mysql->query('UPDATE `' . TABLE_USERS . '`
						SET `user_comments` = user_comments + 1, `user_ip` = \'' . $_SERVER['REMOTE_ADDR'] . '\'
						WHERE `user_id` = \'' . $_SESSION['user_id'] . '\'
						LIMIT 1');
				$mysql->query('UPDATE `' . TABLE_NEWS . '`
						SET `news_comments` = news_comments + 1
						WHERE `news_id` = \'' . $_POST['news_id'] . '\'
						LIMIT 1');
				success_template($lang['COMMENTS_ADD_SUCCESS']);
				header('Refresh: 3; URL= ./../comments/index.php?news_id=' . $_POST['news_id'] . '');
			}
		}
		else
		{
			error_template($lang['COMMENTS_ADD_ERROR2']);
		}
	}
	else
	{
		error_template($lang['COMMENTS_ADD_ERROR2']);
	}
}
else
{
	error_template($lang['COMMENTS_ADD_ERROR3']);
}

page_header($lang['COMMENTS_ADD_TITLE']);
$template->pparse('', 'error');
$template->pparse('', 'success');
page_footer()

?>
