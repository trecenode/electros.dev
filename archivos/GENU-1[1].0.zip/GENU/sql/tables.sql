# --------------------------------------------------------------
#
# $Id: tables.sql,v 1.7 2004/02/01 18:13:42 raoul Exp $
#
# Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
# License:	GNU GPL (see COPYING)
# Website:	http://genu.org/
#
# --------------------------------------------------------------

# CATEGORIES

CREATE TABLE genu_categories (
category_id TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
category_name VARCHAR(16) NOT NULL DEFAULT '',
category_image VARCHAR(255) NOT NULL DEFAULT '',
PRIMARY KEY (category_id)
) TYPE=MyISAM;

# COMMENTS

CREATE TABLE genu_comments (
comment_id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
news_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
user_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
comment_subject VARCHAR(64) NOT NULL DEFAULT '',
comment_text TEXT NOT NULL,
comment_creation INT(11) NOT NULL DEFAULT '0',
comment_edition INT(11) NOT NULL DEFAULT '0',
PRIMARY KEY (comment_id)
) TYPE=MyISAM;

# NEWS

CREATE TABLE genu_news (
news_id SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
category_id TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
user_id SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
news_active ENUM('0','1') NOT NULL DEFAULT '0',
news_subject VARCHAR(64) NOT NULL DEFAULT '',
news_text TEXT NOT NULL,
news_source VARCHAR(255) NOT NULL DEFAULT '',
news_comments SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
news_date INT(11) NOT NULL DEFAULT '0',
news_month VARCHAR(2) NOT NULL DEFAULT '',
news_year VARCHAR(4) NOT NULL DEFAULT '',
PRIMARY KEY (news_id),
FULLTEXT KEY news_subject (news_subject),
FULLTEXT KEY news_text (news_text)
) TYPE=MyISAM;

# SESSIONS

CREATE TABLE genu_sessions (
session_id VARCHAR(32) NOT NULL DEFAULT '',
session_value VARCHAR(255) NOT NULL DEFAULT '',
session_expiry INT(11) NOT NULL DEFAULT '0'
) TYPE=MyISAM;

# SETTINGS

CREATE TABLE genu_settings (
sitename VARCHAR(64) NOT NULL DEFAULT '',
siteurl VARCHAR(255) NOT NULL DEFAULT '',
language ENUM('dutch','english','french','german','spanish') NOT NULL DEFAULT 'english',
news_per_page TINYINT(2) UNSIGNED NOT NULL DEFAULT '7',
comments_per_page TINYINT(2) UNSIGNED NOT NULL DEFAULT '7',
headlines_per_backend TINYINT(2) UNSIGNED NOT NULL DEFAULT '7',
news_order ENUM('news_date','news_month','news_year') NOT NULL DEFAULT 'news_date',
allow_html ENUM('0','1') NOT NULL DEFAULT '0',
allow_smilies ENUM('0','1') NOT NULL DEFAULT '1',
submit_news ENUM('0','1') NOT NULL DEFAULT '1',
send_news ENUM('0','1') NOT NULL DEFAULT '1',
register_users ENUM('0','1') NOT NULL DEFAULT '1',
date_format VARCHAR(64) NOT NULL DEFAULT 'D, M jS Y, g:i a',
date_offset TINYINT(3) NOT NULL DEFAULT '0'
) TYPE=MyISAM;

# SMILIES

CREATE TABLE genu_smilies (
smiley_id TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
smiley_code VARCHAR(16) NOT NULL DEFAULT '',
smiley_image VARCHAR(255) NOT NULL DEFAULT '',
PRIMARY KEY (smiley_id)
) TYPE=MyISAM;

# USERS

CREATE TABLE genu_users (
user_id SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
user_level ENUM('0','1','2','3','4') NOT NULL DEFAULT '1',
user_name VARCHAR(16) NOT NULL DEFAULT '',
user_password VARCHAR(32) NOT NULL DEFAULT '',
user_email VARCHAR(64) NOT NULL DEFAULT '',
user_viewemail ENUM('0','1') NOT NULL DEFAULT '0',
user_website VARCHAR(255) NOT NULL DEFAULT '',
user_location VARCHAR(64) NOT NULL DEFAULT '',
user_occupation VARCHAR(64) NOT NULL DEFAULT '',
user_age VARCHAR(3) NOT NULL DEFAULT '',
user_comments SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0',
user_creation INT(11) NOT NULL DEFAULT '0',
user_ip VARCHAR(15) NOT NULL DEFAULT '',
user_language ENUM('dutch','english','french','german','spanish') NOT NULL DEFAULT 'english',
user_date_format VARCHAR(64) NOT NULL DEFAULT 'D, M jS Y, g:i a',
user_date_offset TINYINT(3) NOT NULL DEFAULT '0',
user_lastvisit INT(11) NOT NULL DEFAULT '0',
user_key VARCHAR(32) NOT NULL DEFAULT '',
PRIMARY KEY (user_id)
) TYPE=MyISAM;