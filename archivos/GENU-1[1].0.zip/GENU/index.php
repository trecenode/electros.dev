<?php
// -------------------------------------------------------------
//
// $Id: index.php,v 1.3 2004/02/06 22:46:50 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

if (file_exists('./install.php'))
{
	echo 'You must delete install.php file from your server.';
}
else
{
	header('Location: ./news/index.php');
}

?>