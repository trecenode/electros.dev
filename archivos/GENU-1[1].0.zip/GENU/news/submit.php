<?php
// -------------------------------------------------------------
//
// $Id: submit.php,v 1.2 2004/02/01 17:25:39 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

include('./../includes/common.php');

$mysql->query('SELECT `submit_news`, `allow_html`
		FROM `' . TABLE_SETTINGS . '`');
$table_settings = $mysql->fetch();
if (!$_SESSION['user_id'])
{
	error_template($lang['NEWS_SUBMIT_ERROR1']);
}
else
{
	if ($table_settings['submit_news'] == 0)
	{
		error_template($lang['NEWS_SUBMIT_DISABLED']);
	}
	elseif ($_POST['submit'])
	{
		$mysql->query('SELECT `user_id`
				FROM `' . TABLE_NEWS . '`
				WHERE `user_id` = \'' . $_SESSION['user_id'] . '\' AND `news_active` = \'0\'');
		$table_news = $mysql->fetch();
		if ($table_news['user_id'])
		{
			$error .= $lang['NEWS_SUBMIT_ERROR2'];
		}
		else
		{
			if (!trim($_POST['news_subject']))
			{
				$error .= $lang['NO_NEWS_SUBJECT'];
			}
			if (!trim($_POST['news_text']))
			{
				$error .= $lang['NO_NEWS_TEXT'];
			}
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$news_subject = htmlspecialchars($_POST['news_subject']);
			if ($table_settings['allow_html'] == 0)
			{
				$news_text = htmlspecialchars($_POST['news_text']);
				$news_source = htmlspecialchars($_POST['news_source']);
				$news_text = do_bbcode($news_text);
				$news_source = do_bbcode($news_source);
			}
			else
			{
				$news_text = $_POST['news_text'];
				$news_source = $_POST['news_source'];
			}
			$mysql->query('INSERT INTO `' . TABLE_NEWS . '`
					VALUES (\'\', \'' . $_POST['category_id'] . '\', \'' . $_SESSION['user_id'] . '\', \'0\', \'' . $news_subject . '\', \'' . $news_text . '\', \'' . $news_source . '\', \'\', \'' . time() . '\', \'' . date('m', time()) . '\', \'' . date('Y', time()) . '\')');
			$mysql->query('SELECT `news_id`
					FROM `' . TABLE_NEWS . '` WHERE `news_active` = \'0\'');
			$num_submitted_news = $mysql->num_rows();
			success_template(sprintf($lang['NEWS_SUBMIT_SUCCESS'], $num_submitted_news));
		}
	}
	else
	{
		$mysql->query('SELECT `category_id`, `category_name`
				FROM `' . TABLE_CATEGORIES . '`');
		while ($table_categories = $mysql->fetch())
		{
			$category_name_options .= '<option value="' . $table_categories['category_id'] . '">' . $table_categories['category_name'] . '</option>';
		}
		if ($table_settings['allow_html'] == 0)
		{
			$html_support = $lang['HTML_DISABLED'];
		}
		else
		{
			$html_support = $lang['HTML_ENABLED'];
		}
		$template->set_file('submit', 'news/submit.tpl');
		$template->set_var(array(
			'BACK_HOME' => $lang['BACK_HOME'],
			'CATEGORY_NAME_OPTIONS' => $category_name_options,
			'FORM_NEWS_CATEGORY' => $lang['FORM_NEWS_CATEGORY'],
			'FORM_NEWS_SOURCE' => $lang['FORM_NEWS_SOURCE'],
			'FORM_NEWS_SUBJECT' => $lang['FORM_NEWS_SUBJECT'],
			'FORM_NEWS_TEXT' => $lang['FORM_NEWS_TEXT'],
			'HTML_SUPPORT' => $html_support,
			'NEWS_SUBMIT_HEADER' => $lang['NEWS_SUBMIT_HEADER'],
			'SUBMIT' => $lang['SUBMIT']));
	}
}

page_header($lang['NEWS_SUBMIT_TITLE']);
$template->pparse('', 'error');
$template->pparse('', 'submit');
$template->pparse('', 'success');
page_footer();

?>
