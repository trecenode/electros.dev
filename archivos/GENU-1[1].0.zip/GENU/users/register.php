<?php
// -------------------------------------------------------------
//
// $Id: register.php,v 1.10 2004/02/01 18:30:56 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

include('./../includes/common.php');

$mysql->query('SELECT `date_format`, `date_offset`, `register_users`, `sitename`, `siteurl`
		FROM `' . TABLE_SETTINGS . '`');
$table_settings = $mysql->fetch();
if ($table_settings['register_users'] == 0)
{
	error_template($lang['USERS_REGISTER_DISABLED']);
}
else
{
	if ($_GET['user_key'])
	{
		$mysql->query('SELECT `user_id`
				FROM `' . TABLE_USERS . '`
				WHERE `user_key` = \'' . $_GET['user_key'] . '\'');
		$table_users = $mysql->fetch();
		if (!$table_users['user_id'])
		{
			error_template($lang['USERS_REGISTER_ERROR1']);
		}
		else
		{
			$mysql->query('UPDATE `' . TABLE_USERS . '` SET `user_level` = \'1\'
					WHERE `user_key` = \'' . $_GET['user_key'] . '\' LIMIT 1');
			success_template($lang['USERS_REGISTER_SUCCESS1']);
		}
	}
	elseif ($_POST['register'])
	{
		$mysql->query('SELECT `user_email`, `user_name`
				FROM `' . TABLE_USERS . '`
				WHERE `user_name` = \'' . $_POST['user_name'] . '\' OR `user_email` = \'' . $_POST['user_email'] . '\'');
		$table_users = $mysql->fetch();
		if ($table_users['user_name'] == $_POST['user_name'])
		{
			$error .= $lang['USERS_REGISTER_ERROR2'];
		}
		if ($table_users['user_email'] == $_POST['user_email'])
		{
			$error .= $lang['USERS_REGISTER_ERROR3'];
		}
		if (!trim($_POST['user_name']))
		{
			$error .= $lang['NO_USER_NAME'];
		}
		if ($_POST['user_name'])
		{
			if (strlen(trim($_POST['user_name'])) < MIN_NAME_LENGHT)
			{
				$error .= sprintf($lang['SHORT_USER_NAME'], MIN_NAME_LENGHT);
			}
		}
		if (!trim($_POST['user_password']))
		{
			$error .= $lang['NO_USER_PASSWORD'];
		}
		if ($_POST['user_password'])
		{
			if (strlen(trim($_POST['user_password'])) < MIN_PASS_LENGHT)
			{
				$error .= sprintf($lang['SHORT_USER_PASSWORD'], MIN_PASS_LENGHT);
			}
		}
		if (trim($_POST['user_password2']) != trim($_POST['user_password']))
		{
			$error .= $lang['INVALID_USER_PASSWORD'];
		}
		if (!trim($_POST['user_email']))
		{
			$error .= $lang['NO_USER_EMAIL'];
		}
		if (!trim($_POST['user_date_format']))
		{
			$error .= $lang['NO_USER_DATE_FORMAT'];
		}
		if ($error)
		{
			error_template($error);
		}
		else
		{
			$mysql->query('SELECT `user_email`, `user_name`
					FROM `' . TABLE_USERS . '`
					WHERE `user_id` = \'1\'');
			$table_users = $mysql->fetch();
			$user_key = md5(time() . $_POST['user_name']);
			$mysql->query('INSERT INTO `' . TABLE_USERS . '`
					VALUES (\'\', \'0\', \'' . $_POST['user_name'] . '\', \'' . md5($_POST['user_password']) . '\', \'' . $_POST['user_email'] . '\', \'' . $_POST['user_viewemail'] . '\', \'' . $_POST['user_website'] . '\', \'' . $_POST['user_location'] . '\', \'' . $_POST['user_occupation'] . '\', \'' . $_POST['user_age'] . '\', \'\', \'' . time() . '\', \'' . $_SERVER['REMOTE_ADDR'] . '\', \'' . $_POST['user_language'] . '\', \'' . $_POST['user_date_format'] . '\', \'' . $_POST['user_date_offset'] . '\', \'\', \'' . $user_key . '\')');
			$subject = sprintf($lang['USERS_REGISTER_SUBJECT'], $table_settings['sitename']);
			$message = sprintf($lang['USERS_REGISTER_MESSAGE'], $_POST['user_name'], $table_settings['sitename'], $table_settings['siteurl'] . '/users/register.php?user_key=' . $user_key, $table_users['user_name']);
			$header .= 'From: ' . $table_users['user_name'] . ' <' . $table_users['user_email'] . '>' . "\n";
			$header .= 'Reply-To: ' . $table_users['user_name'] . ' <' . $table_users['user_email'] . '>' . "\n";
			$header .= 'X-Mailer: PHP/' . phpversion() . "\n";
			$header .= 'MIME-Version: 1.0' . "\n";
			$header .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
			mail($_POST['user_email'], $subject, $message, $header);
			success_template($lang['USERS_REGISTER_SUCCESS2']);
		}
	}
	else
	{
		$template->set_file('register', 'users/register.tpl');
		$template->set_var(array(
			'BACK_HOME' => $lang['BACK_HOME'],
			'DATE_FORMAT' => $table_settings['date_format'],
			'DATE_OFFSET' => $table_settings['date_offset'],
			'DUTCH' => $lang['DUTCH'],
			'ENGLISH' => $lang['ENGLISH'],
			'FORM_USER_AGE' => $lang['FORM_USER_AGE'],
			'FORM_USER_DATE_FORMAT' => $lang['FORM_USER_DATE_FORMAT'],
			'FORM_USER_DATE_OFFSET' => $lang['FORM_USER_DATE_OFFSET'],
			'FORM_USER_EMAIL' => $lang['FORM_USER_EMAIL'],
			'FORM_USER_LANGUAGE' => $lang['FORM_USER_LANGUAGE'],
			'FORM_USER_LOCATION' => $lang['FORM_USER_LOCATION'],
			'FORM_USER_NAME' => $lang['FORM_USER_NAME'],
			'FORM_USER_OCCUPATION' => $lang['FORM_USER_OCCUPATION'],
			'FORM_USER_PASSWORD' => $lang['FORM_USER_PASSWORD'],
			'FORM_USER_PASSWORD2' => $lang['FORM_USER_PASSWORD2'],
			'FORM_USER_WEBSITE' => $lang['FORM_USER_WEBSITE'],
			'FORM_USER_VIEWEMAIL' => $lang['FORM_USER_VIEWEMAIL'],
			'FRENCH' => $lang['FRENCH'],
			'GERMAN' => $lang['GERMAN'],
			'NO' => $lang['NO'],
			'REGISTER' => $lang['REGISTER'],
			'SPANISH' => $lang['SPANISH'],
			'USERS_REGISTER_HEADER' => $lang['USERS_REGISTER_HEADER'],
			'YES' => $lang['YES']));
	}
}

page_header($lang['USERS_REGISTER_TITLE']);
$template->pparse('', 'error');
$template->pparse('', 'register');
$template->pparse('', 'success');
page_footer();

?>
