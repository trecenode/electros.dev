<?php
// -------------------------------------------------------------
//
// $Id: upgrade.php,v 1.1 2004/02/03 18:26:33 raoul Exp $
//
// Copyright:	(C) 2003, 2004 Raoul Proen�a <raoul@genu.org>
// License:	GNU GPL (see COPYING)
// Website:	http://genu.org/
//
// -------------------------------------------------------------

error_reporting(E_ALL ^ E_NOTICE);
// error_reporting(E_ALL);

include('./includes/mysql.php');
$mysql = new mysql;

echo '<html>';
echo '<head>';
echo '<title>GENU installation</title>';
echo '</head>';
echo '<body>';
$mysql->query('ALTER TABLE `genu_settings` CHANGE `language` `language` ENUM( \'dutch\', \'english\', \'french\', \'german\', \'spanish\' ) DEFAULT \'english\' NOT NULL');
$mysql->query('ALTER TABLE `genu_settings` ADD `register_users` ENUM( \'0\', \'1\' ) DEFAULT \'1\' NOT NULL AFTER `send_news`');
$mysql->query('ALTER TABLE `genu_users` CHANGE `user_language` `user_language` ENUM( \'dutch\', \'english\', \'french\', \'german\', \'spanish\' ) DEFAULT \'english\' NOT NULL');
$mysql->query('ALTER TABLE `genu_users` ADD `user_key` VARCHAR( 32 ) NOT NULL');
$mysql->query('UPDATE `genu_users` SET `user_key` = \'0\'');
echo 'Tables were succesfully updated.';
echo '</body>';
echo '</html>';

?>