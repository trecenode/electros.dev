<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<font size="1" color="#000000" face="Verdana, Arial, Helvetica, sans-serif">We 
have <b>currently</b> - 
<?php include("online.php"); ?>
- <b>people</b> in this site.. </font> 
</body>
</html>
