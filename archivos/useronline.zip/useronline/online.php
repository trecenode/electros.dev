<?php
//CONFIGURACION//
$tiempo = 6; //Tiempo de la cookie en minutos..
$archivo = "ip.txt"; //Archivo donde almacenara las ips de los usuarios
//TERMINO DE VARIABLES//

if (!$datei) $datei = dirname(__FILE__)."/$archivo";
$tiempo = @time();
$ip = $REMOTE_ADDR;
$string = "$ip|$tiempo\n";
$a = fopen("$archivo", "a+");
fputs($a, $string);
fclose($a);

$timeout = time()-(60*$timer);

$all = "";
$i = 0;
$datei = file($archivo);
for ($num = 0; $num < count($datei); $num++) {
	$pieces = explode("|",$datei[$num]);

		if ($pieces[1] > $timeout) {
			$all .= $pieces[0];
			$all .= ",";
		}
	$i++;
}
$all = substr($all,0,strlen($all)-1);

$arraypieces = explode(",",$all);

$useronline = count(array_flip(array_flip($arraypieces)));

if ($useronline == 0) {
	$useronline = 1;
}
echo $useronline;

// L�schen
$dell = "";
for ($numm = 0; $numm < count($datei); $numm++) {
	$tiles = explode("|",$datei[$numm]);
		if ($tiles[1] > $timeout) {
			$dell .= "$tiles[0]|$tiles[1]";
		}
}

if (!$datei) $datei = dirname(__FILE__)."/$archivo";
$tiempo = @time();
$ip = $REMOTE_ADDR;
$string = "$dell";
$a = fopen("$archivo", "w+");
fputs($a, $string);
fclose($a);
?>
