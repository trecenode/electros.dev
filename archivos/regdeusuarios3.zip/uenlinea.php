<?
include("config.php") ;
$fecha = time() ;
// Tiempo en el cu�l se considerar� al usuario en l�nea en minutos
$tiempo = 10 ;
// Se le resta el tiempo en minutos a la fecha actual
$tiempo = $fecha-$tiempo*60 ;
$ip = $REMOTE_ADDR ;
$usuario = $_COOKIE["unick"] ;
// Se eliminan las fechas que sean menores al tiempo l�mite
mysql_query("delete from uenlineavis where fecha < $tiempo") ;
mysql_query("delete from uenlineareg where fecha < $tiempo") ;
// Para los usuarios no registrados
$resp = mysql_query("select ip from uenlineavis where ip='$ip'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("insert into uenlineavis values ('$ip','$fecha')") ;
}
else {
mysql_query("update uenlineavis set fecha='$fecha' where ip='$ip'") ;
}
mysql_free_result($resp) ;
// Para los usuarios registrados
if($_COOKIE["unick"]) {
$resp = mysql_query("select usuario from uenlineareg where usuario='$usuario'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("insert into uenlineareg values ('$usuario','$fecha')") ;
}
else {
mysql_query("update uenlineareg set fecha='$fecha' where usuario='$usuario'") ;
}
mysql_free_result($resp) ;
}
// Se obtiene el n�mero de usuarios en l�nea
$resp = mysql_query("select ip from uenlineavis") ;
// N�mero de usuarios
$usuarios = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$resp = mysql_query("select usuario from uenlineareg") ;
// N�mero de registrados
$registrados = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
// N�mero de anonimos
$anonimos = $usuarios - $registrados ;
// Se obtiene el nick de los usuarios que se encuentran en l�nea
$resp = mysql_query("select usuario from uenlineareg") ;
if(mysql_num_rows($resp) != 0) {
$renlinea = "�" ;
while($datos = mysql_fetch_array($resp)) {
$renlinea .= " <a href=mensajes.php?responder=$datos[usuario]>$datos[usuario]</a> �" ;
}
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>