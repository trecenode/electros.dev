<script>

function Comprobar() 

        {

         if (formulario.email.value == "") {
	 alert("Tienes que Insertar Tu e-Mail");
	 return false;
	} 
              else return true;

</script>

<?

//By DarKx

echo "
<form name=\"formulario\" onsubmit=\"return Comprobar();\" method=\"post\" action=\"index.php?Valido=OK\">

Tu e-Mail: <input type=\"text\" name=\"email\" size=\"30\" maxlength=\"25\"> 

<br>

<input type=\"submit\" name=\"submit\" value=\"Subscribirte\">

</form>";
     
if ($Valido == "OK") {

if (!eregi("[0-9a-z_\-]+@[0-9a-z\-\.]+\.[a-z]{2,3}",$email)) {

echo "<center>El email no es v�lido,no puedes subsribirte.</center>";

} else {

$asunto = " Asunto " ;

$mensaje = " Mensaje " ;

mail("".$email."","".$asunto."","".$mensaje."","From: ".$email." ");

echo "<center>La Subscripcion se a enviado con exito.<br><a href=\"index.php\">Volver</a>";

} 

?>
