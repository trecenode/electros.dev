<?
/*
+---------------------+
| Referers PHP Script |
+---------------------+
Autor: Gohrum & Clan Gatsu 
Email: webmaster@clangatsu.com
Web:   http://www.gatsu-studios.tk
Web:   http://www.clangatsu.com
*/

//--------CONFIGURACI�N----------
$host = "***";            				//Host de la base de datos(suele ser localhost)
$user = "***";        					//nombre de usuario de la base de datos
$pass = "***";      					//contrase�a de la base de datos
$dbname = "***"; 					//nombre de la base de datos 
$tabla = "gts_referrers";        			//nombre de la tabla que hemos creado
$usuarios = "30";					//numero de veces que se ense�aran
$carpeta = "http://www.tupag.com/gts_refv2";		//La carpeta donde tienes los archivos de los refers ATENCION no pongas la / al final
//------FIN CONFIGURACI�N--------


$conecta = mysql_connect($host,$user,$pass);
mysql_select_db($dbname,$conecta);

// querys

//lo xungo
?>
<table width='100%' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td width='5%'><b>#</b></td>
    <td width='75%'><div align='left'><b>Link</b></div></td>
    <td width='20%'><div align='right'><b>Visitas</b></div></td>
  </tr>
<?

$query = "select * from $tabla order by hitsin desc"; 
$result = mysql_query($query); 
$xcontador = 1;
while ($rows = mysql_fetch_array($result)) { 
$i = 1; 
while ($rows = mysql_fetch_array($result)) { 
if ($i <= $usuarios) { 

$query2 = "select * from $tabla where id='$rows[id]'"; 
$result2 = mysql_query($query2); 
$id = mysql_fetch_array($result2); 

$query3 = "select * from $tabla where refername='$rows[refername]'"; 
$result3 = mysql_query($query3); 
$name = mysql_fetch_array($result3); 

$query4 = "select * from $tabla where referurlshort='$rows[referurlshort]'"; 
$result4 = mysql_query($query4); 
$url = mysql_fetch_array($result4); 

$query5 = "select * from $tabla where hitsin='$rows[hitsin]'"; 
$result5 = mysql_query($query5); 
$in = mysql_fetch_array($result5); 

$query6 = "select * from $tabla where hitsout='$rows[hitsout]'"; 
$result6 = mysql_query($query6); 
$out = mysql_fetch_array($result6); 




if (strlen($name[username])) { 
$name[username] = substr($name[username],0,20); 
} 


echo "	<tr>
  		<td >$xcontador</td>
    	<td ><div align='left'><a href='$carpeta/gts_out.php?sOutID=$id[id]' target='_blank' onmouseover=\"window.status='$url[referurlshort]';return true\" title='Entradas: $in[hitsin] Salidas: $out[hitsout]'>$name[refername]</a></div></td>
    	<td ><div align='right'>$in[hitsin]</div></td>
  		</tr>"; 
$i++; 
$xcontador++;
}
} 
} 
echo "
		</table>
		<hr>
	  <div align='center'>Gts Refers v2.0 Creado por <a href='http://www.gatsu-studios.tk' target='_blank'>Gatsu Studios</a> & <a href='http://www.clangatsu.com' target='_blank'>Clan Gatsu </a></div>"; 

//fin de la conexi�n

?>