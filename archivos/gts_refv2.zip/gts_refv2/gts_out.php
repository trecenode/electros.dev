<?
/*
+---------------------+
| Referers PHP Script |
+---------------------+
Autor: Gohrum & Clan Gatsu 
Email: webmaster@clangatsu.com
Web:   http://www.gatsu-studios.tk
Web:   http://www.clangatsu.com
*/

INCLUDE "gts_master.php";

func_sumar($sOutID);
?>