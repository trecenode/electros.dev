<html>
<head>
<title>Gatsu Studios GTS Refers 2.0 Instalar</title>
</head>

<body>

                            <table width="87%" height="64" border="1" align="center" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td height="16" bordercolor="#000033" bgcolor="#000033"> 
                                  <div align="left"><font color="#FFFFFF" size="-4" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; Gatsu Studios GTS Refers 2.0 Instalar </font></div></td>
                              </tr>
                              <tr> 
                                <td height="40" bordercolor="#000000" bgcolor="#FFFFFF"> 
                                  <font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;<FONT COLOR=#ff0000><FONT COLOR=#000000><FONT COLOR=#000000><FONT COLOR=#000000><FONT COLOR=#000000><strong>
                                  <!-- Inicio del discursito-->
<?
$sTime = time();
PRINT"
<FONT FACE=ARIAL><B>En el apartado del phpMyAdmin de tu servidor, elije la pesta�a que pone 'SQL'<BR>
despu�s, copia esto y pegalo en la tabla, justo debajo de 'Ejecute la/s consulta/s SQL en la base de datos'<BR>
para acabar, dale al boton 'contin�e'</B>
<BR><BR>
CREATE TABLE `gts_referrers` (
`id` INT(255) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`ip` VARCHAR(15) NOT NULL,
`refername` VARCHAR(255) NOT NULL,
`referurl` VARCHAR(255) NOT NULL,
`referurlshort` VARCHAR(255) NOT NULL,
`hitsin` INT(255) NOT NULL,
`hitsout` INT(255) NOT NULL,
`date` INT(35) NOT NULL,
`lastdate` INT(35) NOT NULL,
`banned` VARCHAR(10) DEFAULT 'false' NOT NULL)<BR><BR>
<B>Despu�s haz lo mismo con esto:</B><BR>
INSERT INTO gts_referrers (ip, refername, referurl, referurlshort, hitsin, hitsout, date, lastdate, banned) VALUES ('1.1.1.1', 'Gatsu Studios', 'gatsu-studios.tk', 'gatsu-studios.tk', '1', '0', '$sTime', '$sTime', 'false')
<BR><BR>
Gts Refers v2.0 Creado por <a href='http://www.gatsu-studios.tk' target='_blank'>Gatsu Studios</a>";
?>
<!-- Fin del discurso -->
                                  <br>
<hr>
<div align="center">Gts Refers v2.0 Creado por <a href='http://www.gatsu-studios.tk' target='_blank'>Gatsu Studios</a> & <a href='http://www.clangatsu.com' target='_blank'>Clan Gatsu </a></div>
</strong>
</font></font></font></font></font> </font></td>
                              </tr>
                            </table> 
                            
</body>

</html>