<?
/*
+---------------------+
| Referers PHP Script |
+---------------------+
Autor: Gohrum & Clan Gatsu 
Email: webmaster@clangatsu.com
Web:   http://www.gatsu-studios.tk
Web:   http://www.clangatsu.com
*/

//--------CONFIGURACI�N----------
$sScripturl = ("http://tupag.com/gts_refv2/");   		//La url d�nde se encuentra la carpeta (pon la barra final /)
$sMaxdays = ("30");   						//Cuantos dias necesita un refer para considerarse viejo?
$sMysqldbname = "***";    					//Nombre de la base de datos
$sMysqlhost = "***";      					//El host de la Base de datos (Normalmente 'localhost')
$sMysqlusername = "***";       					//Usuario de la base de datos
$sMysqlpassword = "***";            				//Contrase�a de la base de datos
//------FIN CONFIGURACI�N--------

// no editar nada mas si no sabes lo que haces...
// no editar nada mas si no sabes lo que haces...

function func_conectar ()
 {
 global $sMysqldbname;
 global $sMysqlhost;
 global $sMysqlusername;
 global $sMysqlpassword;
 mysql_connect($sMysqlhost,$sMysqlusername,$sMysqlpassword) or die ("Gatsu Studios :: Error: ".mysql_error());
 mysql_select_db($sMysqldbname) or die ("Gatsu Studios :: Error: ".mysql_error());
 }

//Funcion de borrar los refers viejos.

function func_viejos()
 {
  global $sMaxdays;
  $sTotaltime = time() - ($sMaxdays * 86400);
  $sQuery = "DELETE FROM gts_referrers WHERE lastdate < $sTotaltime";
  $sQueryresult = mysql_query($sQuery) or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
  if(mysql_affected_rows())
   {
    $sQuery = "OPTIMIZE TABLE gts_referrers";
    $sQueryresult = mysql_query($sQuery) or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
   }
 }

//funcion cojer refer.


function func_cojer()
 {
  $sIP = getenv("REMOTE_ADDR");
  $sFullurl = getenv("HTTP_REFERER");
  $sFullurl = str_replace("http://", "", $sFullurl);
  $sStripurl = $sFullurl;
  preg_match("/^(http:\/\/)?([^\/]+)/i",$sStripurl, $sMatches);
  $sStripurl = $sMatches[2];
  preg_match("/[^\.\/]+\.[^\.\/]+$/",$sHost,$sMatches);
  $sStripurl == $sMatches[0];
  $sStripurl = str_replace("www.", "", $sStripurl);
  func_conectar();
  $sQuery = "SELECT * FROM gts_referrers WHERE referurlshort='$sStripurl'";
  $sQueryresult = mysql_query($sQuery) or die ("Gatsu Studios :: Error: " . mysql_error());
  $sNum = mysql_numrows(mysql_query($sQuery));
   if ($sNum == 1)
    {
     while ($sRow = mysql_fetch_array($sQueryresult))
      {
       $sHitsin = $sRow["hitsin"];
       $sLastIP = $sRow["ip"];
       $sIsbanned = $sRow["banned"];
      }
     if($sIP != $sLastIP AND $sIsbanned == 'false')
      {
       $sHitsin++;
       $sDate = time();
       $sQuery = "UPDATE gts_referrers SET ip='$sIP', hitsin='$sHitsin', lastdate='$sDate' WHERE referurlshort='$sStripurl'";
       $sQueryresult = mysql_query($sQuery) or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
      }
    }
     else
    {
	 if(!$sFullurl == "")
	  {
       $sDate = time();
       mysql_query ("INSERT INTO gts_referrers (ip, refername, referurl, referurlshort, hitsin, date, lastdate) VALUES ('$sIP', '$sStripurl', '$sFullurl', '$sStripurl', '1', '$sDate', '$sDate')") or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
      }
	}
  func_viejos();
  mysql_close();
 }

// Funcion de sumar una visita de salida a los refers.

function func_sumar($sOutID)
 {
  global $sStyle, $sConfirmheaderHTML, $sAdminbeforeHTML;
  func_conectar();
  $sQuery = "SELECT * FROM gts_referrers WHERE id='$sOutID'";
  $sQueryresult = mysql_query($sQuery) or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
  $sNum = mysql_numrows(mysql_query($sQuery));
   if ($sNum == 0)
    {
     DIE ($sStyle . $sConfirmheaderHTML . $sAdminbeforeHTML . "Gatsu Studios error: Sitio ID # $sOutID no existe!");
    }
     else
    {
     while ($sRow = mysql_fetch_array($sQueryresult))
      {
       $sRefername = $sRow["refername"];
       $sReferurl = str_replace("http://", "", $sRow["referurl"]);
       $sHitsout = $sRow["hitsout"];
      }
     $sHitsout++;
     $sQuery = "UPDATE gts_referrers SET hitsout='$sHitsout' WHERE id='$sOutID'";
     $sQueryresult = mysql_query($sQuery) or trigger_error("MySQL error nr ".mysql_errno().": ".mysql_error());
    }
  PRINT $sStyle . $sConfirmheaderHTML . $sAdminbeforeHTML . "Seras redirigido a <A HREF='http://$sReferurl'>$sRefername</A>. Si tu navegador no te redirecciona, apreta <A HREF='http://$sReferurl'>aqui</A>.<script language=\"JavaScript\">window.location='http://$sReferurl'</script>";
  mysql_close();
 }
?>