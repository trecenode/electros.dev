<title>Editar un archivo</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #aaaaaa ;
text-align: justify ;
scrollbar-face-color: #505050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #252525 ;
scrollbar-highlight-color: #757575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #cccccc ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #cccccc ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #cccccc ;
}
/* Tablas del foro */
.tabla_principal {
border: #757575 1 solid ;
}
.tabla_titulo {
background: #303030 ;
}
.tabla_subtitulo {
background: #404040 ;
}
.tabla_mensaje {
background: #505050 ;
}
/* Formulario */
.form {
border: #757575 1 solid ;
background: #303030 ;
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
}
</style>
<body bgcolor="#404040">
<?
 function write_fil($arch, $titulo) {
 if ($fp = fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$archivo.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="29" align="center" bgcolor="#2A2A2A" ><div align="left"> Editar 
        un comentario</div></td>
  </tr>
  <tr>
    <td height="169" align="center" bgcolor="#444444" ><div align="left"><form method=post action='editar.php?action=ver&archivo=<? echo $archivo ?>' id=form1 name=form1 enctype="multipart/form-data">
          Contrase&ntilde;a :<br>
          <input type='text' name='contrasena' class='form'>
          <br>
          Contenido del archivo :<br>
          <TEXTAREA rows=5 cols=50  name=descargar class='form'><? echo $codigo ?>
</TEXTAREA>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form></div></td>
  </tr>
</table>
<?
$contrasena ="1982"; //tu clave de admin 
$url = $HTTP_POST_VARS['contrasena']; $nombre = $HTTP_POST_VARS['descargar'];
}
else if($action == "ver")
{
if (isset($descargar)&&isset($contrasena)&&($descargar!="")&&($contrasena!=""))
{
$descargar = chunk_split($descargar,100,"\n");
// bbcode
$contrasena = trim($contrasena) ;
$contrasena = htmlspecialchars($contrasena) ;
$descargar = trim($descargar) ;
$descargar = htmlspecialchars($descargar) ;
// fin bbcode
$rs = write_fil("$archivo.txt", "$descargar");
$archi = "$archivo.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="29" align="center" bgcolor="#2A2A2A" ><div align="left">Editar 
        un comentario</div></td>
  </tr>
  <tr>
    <td height="2" align="center" bgcolor="#444444" ><div align="left">* Comentario 
        modificado satisfactoriamente,</div></td>
  </tr>
</table>

<?
}
}
?>
<br>
<a href="index.php">volver a la pagina principal</a>