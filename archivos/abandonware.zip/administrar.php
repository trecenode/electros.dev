<title>Directorio abandonware</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #aaaaaa ;
text-align: justify ;
scrollbar-face-color: #505050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #252525 ;
scrollbar-highlight-color: #757575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #cccccc ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #cccccc ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #cccccc ;
}
/* Tablas del foro */
.tabla_principal {
border: #757575 1 solid ;
}
.tabla_titulo {
background: #303030 ;
}
.tabla_subtitulo {
background: #404040 ;
}
.tabla_mensaje {
background: #505050 ;
}
/* Formulario */
.form {
border: #757575 1 solid ;
background: #303030 ;
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
}
</style>
<body bgcolor="#404040">
<p class="t1"><font size="4"><img src="logo.gif" border="0">&nbsp;elAbandonware</font></p>
Aqui podras encontrar una lista de juegos de abandonware seleccionados y clasificados 
por sus nombre, por su tama&ntilde;o, que los disfrutes.<br>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td align="center" bgcolor="#444444" ><div align="right">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="19%"> Total archivos : 
<?
// abrimos el directorio
$dir = opendir(".");
while ($elemento = readdir($dir)) {
// leemos solo los que tengan ese tipo de extension
$elemento = strtolower($elemento); 
if ((strpos($elemento, ".zip") > 1) || (strpos($elemento, ".rar") > 1) || (strpos($elemento, ".ace") > 1)) 
// mostramos el total de ficheros
$i++;
}
echo $i ;
?>
            </td>
            <td width="81%"><div align="right"><a href="../index.php">Vover a la pagina principal</a> 
                | <a href="index.php">Indice</a></div></td>
          </tr>
        </table>
        
      </div></td>
  </tr>
</table>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td align="center" bgcolor="#2A2A2A" ><div align="left">Comentario</div></td>
    <td align="center" bgcolor="#2A2A2A" ><div align="left">Contenido del comentario</div></td>
    <td colspan="2" align="center" bgcolor="#2A2A2A" >&nbsp;</td>
    <td align="center" bgcolor="#404040">&nbsp;</td>
    <td align="center" bgcolor="#2A2A2A" ><div align="left"> Atribuido al archivo</div></td>
    <td align="center" bgcolor="#2A2A2A" >Imagen</td>
    <td colspan="2" align="center" bgcolor="#2A2A2A" >&nbsp;</td>
  </tr>
  <?php
// Script 'eLAbandonaware' realizado  por elcidop en colaboracion con $$felipe$$
/// Web del autor: wwww.phpmysql.tk www.elcidop.com wwww.elcidop.webcindario.com
if ($a) {
$fichero = $a ; 
$fp=fopen("$fichero.txt","r");
$numero=fread($fp,filesize("$fichero.txt"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.txt", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

if(file_exists("$a.zip")) {
header("Location:$a.zip");
}
else { 
if(file_exists("$a.ace")) { 
header("Location:$a.ace");
} 
else { 
header("Location:$a.rar");
} 
}
}
// Contamos los clicks echo en los archivos
// se pone index.php?a=fichero y dependiendo de la existencia fisica del fichero
// en dicho directorio abriremos un header u otro.

// Script para 'ver el directorio' realizado por $$felipe$$ //
// web del autor de este codigo : portalmusik.elcidop.com //

                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = ".";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 10;             // Numero de archivos a mostrar por p�ginas.

$Show['10 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['10 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['10 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['10 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['10 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
  $Counter++;

  $elemento1 = strtolower($elemento);
  if ((strpos($elemento, ".zip") > 1) || (strpos($elemento, ".rar") > 1) || (strpos($elemento, ".ace") > 1))  {
   // Asignamos el nombre del archivo sin la extension
   // Dependiendo de la extension quitaremos el .zip .rar .ace para mostrarlo como un nombre simple y sin extension
   $elemento2 = str_replace(".zip","",$elemento); 
   $elemento3 = str_replace(".rar","",$elemento);
   $elemento4 = str_replace(".ace","",$elemento);
?>
  <tr> 
    <td width="19%" height="29" align="center" bgcolor="#444444" > <div align="center"></div>
      <div align="left"> 
        <?
// tomamos la imagen de la extension de los archivos
// mostramos sin es un fichero .zip .ace .rar
if(file_exists("$elemento2.desc.txt")) {
echo "<img src='txt.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento3.desc.txt")) {
echo "<img src='txt.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento4.desc.txt")) {
echo "<img src='txt.gif' border='0' width='16' height='16'>";
} 
else 
{ 
echo "";
} 
?>
        &nbsp; 
        <?
// Mostramos el archivo
if(file_exists("$elemento2.desc.txt")) {
echo "$elemento2.desc.txt";
} 
else if(file_exists("$elemento3.desc.txt")) {
echo "$elemento3.desc.txt";
} 
else if(file_exists("$elemento4.desc.txt")) {
echo "$elemento4.desc.txt";
} 
else 
{ 
echo "No existe";
} 
?>
      </div></td>
    <td width="28%" align="center" bgcolor="#444444" > <div align="left"> 
        <?
// Descripcion del archivo
if(file_exists("$elemento2.desc.txt")) {
include("$elemento2.desc.txt");
} 
else if (file_exists("$elemento3.desc.txt")) { 
include("$elemento3.desc.txt"); 
} 
else if (file_exists("$elemento4.desc.txt")) { 
include("$elemento4.desc.txt");
} else 
{ 
echo "Sin descripcion";
} 
?>
      </div></td>
    <td width="8%" align="center" bgcolor="#444444" ><a href="administrar.php?archivo=<?  
// Opinar sobre un archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2.desc";
}
else { 
if(file_exists("$elemento4.ace")) { 
echo "$elemento4.desc";
} 
else { 
echo "$elemento3.desc";
} 
}
?>" > Editar/ Crear</a> </td>
    <td width="5%" align="center" bgcolor="#444444" ><a href="administrar.php?borrar=<?
// Mostramos el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2.desc";
} 
else if(file_exists("$elemento3.rar")) {
echo "$elemento3.desc";
} 
else if(file_exists("$elemento4.ace")) {
echo "$elemento4.desc";
} 
else 
{ 
echo "";
} 
?>.txt">Borrar</a></td>
    <td width="2%" align="center" bgcolor="#404040" >&nbsp;</td>
    <td width="20%" align="center" bgcolor="#444444" ><div align="left"> 
        <?
// tomamos la imagen de la extension de los archivos
// mostramos sin es un fichero .zip .ace .rar
if(file_exists("$elemento2.zip")) {
echo "<img src='zip.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento3.rar")) {
echo "<img src='rar.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento4.ace")) {
echo "<img src='ace.gif' border='0' width='16' height='16'>";
} 
else 
{ 
echo "";
} 
?>
        &nbsp;<a href="administrar.php?a=<?
// Mostramos la url en el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2";
} 
else if (file_exists("$elemento3.rar")) { 
echo "$elemento3";
} 
else if (file_exists("$elemento4.ace")) { 
echo "$elemento4";
} else 
{ 
echo "No existe";
} 
?>" > 
        <?
// Mostramos el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2.zip";
} 
else if(file_exists("$elemento3.rar")) {
echo "$elemento3.rar";
} 
else if(file_exists("$elemento4.ace")) {
echo "$elemento4.ace";
} 
else 
{ 
echo "";
} 
?>
        </a> </div></td>
    <td width="5%" align="center" bgcolor="#444444" ><div align="center">
        <?
// tomamos la imagen de la descripcion de los archivos
// las imagenes se guardan en un archivo tipo archivo.gif o archivo.jpg
if(file_exists("$elemento2.gif")) {
echo "<a href='$elemento2.gif' target='_blank'><img src='gif.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento2.jpg")) { 
echo "<a href='$elemento2.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento3.gif")) { 
echo "<a href='$elemento3.gif' target='_blank'><img src='gif.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}
else if (file_exists("$elemento3.jpg")) { 
echo "<a href='$elemento3.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}
else if (file_exists("$elemento4.gif")) { 
echo "<a href='$elemento4.gif' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento4.jpg")) { 
echo "<a href='$elemento4.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}  
else 
{ 
echo "No";
} 
?>
      </div></td>
    <td width="5%" align="center" bgcolor="#444444" ><a href="administrar.php?borrar=<?
// Mostramos el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2.zip";
} 
else if(file_exists("$elemento3.rar")) {
echo "$elemento3.rar";
} 
else if(file_exists("$elemento4.ace")) {
echo "$elemento4.ace";
} 
else 
{ 
echo "";
} 
?>">Borrar</a></td>
  </tr>
  <?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
  $Show['10 Siguientes'] = 1;
}

//Cerramos el directorio
closedir($dir);
?>
</table>
<div align="right">
  <?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['10 Anteriores'] == 1) echo("<a href=\"administrar.php?c=".($Plus-$Config['Show'])."\">10 Anteriores | </a>");
if ($Show['10 Siguientes'] == 1) echo("<a href=\"administrar.php?c=".($Plus+$Config['Show'])."\">10 Siguientes</a>");
?>
</div>
<br>
<!-- Borrar un archivo -->
<?
if ($borrar != "") {
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="2" align="center" bgcolor="#2A2A2A" ><div align="left"> Borrar 
        un archivo</div></td>
  </tr>
  <tr> 
    <td height="1" align="center" bgcolor="#444444" ><div align="left"> 
        <form method=post action='administrar.php?action=borrar&archivo=<? echo $borrar ?>' id=form1 name=form1 enctype="multipart/form-data">
          Se dispone a borrar el siguiente archivo, para confirmar la accion intruduzca 
          la contrase&ntilde;a y pulse enviar.<br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
          <br>
          Nombre del archivo:<br>
          <input name='archivo' type='text' class='form' value="<? echo $borrar ?>" size="33">
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $HTTP_POST_VARS['archivo'];
}
else if($action == "borrar")
{
if ($contrasena != "123456") { exit; }{ // tu contrase�a aqui
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
unlink("$archivo") ;
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="29" align="center" bgcolor="#2A2A2A" ><div align="left">Borrar 
        un archivo</div></td>
  </tr>
  <tr> 
    <td height="2" align="center" bgcolor="#444444" ><div align="left">* Archivo 
        borrado satisfactoriamente, <a href="administrar.php">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
?>
<!-- fin borrar un archivo -->
<!--editar una imagen-->
<?
if ($archivo != "") { 
 function write_fil($arch, $titulo) {
 if ($fp = fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$archivo.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="29" align="center" bgcolor="#2A2A2A" ><div align="left"> 
        <?
// Mostramos el archivo
if(file_exists("$archivo.txt")) {
echo "Editar un comentario";
} 
else if(file_exists("$archivo.txt")) {
echo "Editar un comentario";
} 
else if(file_exists("$archivo.txt")) {
?>Editar un comentario<?
} 
else 
{ 
?>Crear un comentario<?
} 
?>
      </div></td>
  </tr>
  <tr> 
    <td height="169" align="center" bgcolor="#444444" ><div align="left">
        <form method=post action='administrar.php?action=ver&archivo=<? echo $archivo ?>' id=form1 name=form1 enctype="multipart/form-data">
          Contrase&ntilde;a :<br>
          <input type='text' name='contrasena' class='form'>
          <br>
          Nombre del comentario:<br>
          <input name='archivo' type='text' class='form' value="<? echo $archivo ?>" size="33">
          <br>
          Contenido del comentario :<br>
          <TEXTAREA rows=5 cols=50  name=descargar class='form'><? echo $codigo ?>
</TEXTAREA>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$descargar = $HTTP_POST_VARS['descargar'];
}
else if($action == "ver")
{
if ($contrasena != "123456") { exit; }{ // tu contrase�a aqui
if (isset($descargar)&&isset($contrasena)&&($descargar!="")&&($contrasena!=""))
{
$descargar = chunk_split($descargar,100,"\n");
// bbcode
$contrasena = trim($contrasena) ;
$contrasena = htmlspecialchars($contrasena) ;
$descargar = trim($descargar) ;
$descargar = htmlspecialchars($descargar) ;
// fin bbcode
$rs = write_fil("$archivo.txt", "$descargar");
$archi = "$archivo.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
?>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="29" align="center" bgcolor="#2A2A2A" ><div align="left">Editar 
        un comentario</div></td>
  </tr>
  <tr> 
    <td height="2" align="center" bgcolor="#444444" ><div align="left">* Comentario 
        modificado satisfactoriamente, <a href="administrar.php">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
}
?>
<!-- fin editar una imagen-->
