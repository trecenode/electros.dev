<title>Directorio abandonware</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #aaaaaa ;
text-align: justify ;
scrollbar-face-color: #505050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #252525 ;
scrollbar-highlight-color: #757575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #cccccc ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #cccccc ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #cccccc ;
}
/* Tablas del foro */
.tabla_principal {
border: #757575 1 solid ;
}
.tabla_titulo {
background: #303030 ;
}
.tabla_subtitulo {
background: #404040 ;
}
.tabla_mensaje {
background: #505050 ;
}
/* Formulario */
.form {
border: #757575 1 solid ;
background: #303030 ;
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
}
</style>
<body bgcolor="#404040">
<p class="t1"><font size="4"><img src="logo.gif" border="0">&nbsp;elAbandonware</font></p>
Aqui podras encontrar una lista de juegos de abandonware seleccionados y clasificados 
por sus nombre, por su tama&ntilde;o, que los disfrutes.<br>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td align="center" bgcolor="#444444" ><div align="right">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="19%"> Total archivos : 
<?
// abrimos el directorio
$dir = opendir(".");
while ($elemento = readdir($dir)) {
// leemos solo los que tengan ese tipo de extension
$elemento = strtolower($elemento); 
if ((strpos($elemento, ".zip") > 1) || (strpos($elemento, ".rar") > 1) || (strpos($elemento, ".ace") > 1)) 
// mostramos el total de ficheros
$i++;
}
echo $i ;
?>
            </td>
            <td width="81%"><div align="right"><a href="administrar.php">Administrar </a>
                | <a href="../index.php">Vover a la pagina principal</a> | <a href="index.php">Indice</a></div></td>
          </tr>
        </table>
        
      </div></td>
  </tr>
</table>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr>
    <td width="17%" align="center" bgcolor="#2A2A2A" ><div align="left">Archivo</div></td>
    <td width="48%" align="center" bgcolor="#2A2A2A" ><div align="left">Descripcion</div></td>
    <td width="28%" align="center" bgcolor="#2A2A2A" ><div align="left">Tama�o</div></td>
    <td width="7%" align="center" bgcolor="#2A2A2A" ><div align="left">Clicks</div></td>
  </tr>
<?php
// Script 'eLAbandonaware' realizado  por elcidop en colaboracion con $$felipe$$
/// Web del autor: wwww.phpmysql.tk www.elcidop.com wwww.elcidop.webcindario.com

// Contamos los clicks echo en los archivos
// se pone index.php?a=fichero y dependiendo de la existencia fisica del fichero
// en dicho directorio abriremos un header u otro.
if ($a) {
$fichero = $a ; 
$fp=fopen("$fichero.txt","r");
$numero=fread($fp,filesize("$fichero.txt"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.txt", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

if(file_exists("$a.zip")) {
header("Location:$a.zip");
}
else { 
if(file_exists("$a.ace")) { 
header("Location:$a.ace");
} 
else { 
header("Location:$a.rar");
} 
}
}
// Script para 'ver el directorio' realizado por $$felipe$$ //
// web del autor de este codigo : portalmusik.elcidop.com //

                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = ".";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 10;             // Numero de archivos a mostrar por p�ginas.

$Show['10 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['10 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['10 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['10 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['10 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
{
  $Counter++;

  $elemento1 = strtolower($elemento);
  if ((strpos($elemento, ".zip") > 1) || (strpos($elemento, ".rar") > 1) || (strpos($elemento, ".ace") > 1))  {
   // Asignamos el nombre del archivo sin la extension
   // Dependiendo de la extension quitaremos el .zip .rar .ace para mostrarlo como un nombre simple y sin extension
   $elemento2 = str_replace(".zip","",$elemento); 
   $elemento3 = str_replace(".rar","",$elemento);
   $elemento4 = str_replace(".ace","",$elemento);
?>
  <tr>
	<td height="29" align="center" bgcolor="#444444" ><div align="left"> 
        <?
// tomamos la imagen de la descripcion de los archivos
// las imagenes se guardan en un archivo tipo archivo.gif o archivo.jpg
if(file_exists("$elemento2.gif")) {
echo "<a href='$elemento2.gif' target='_blank'><img src='gif.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento2.jpg")) { 
echo "<a href='$elemento2.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento3.gif")) { 
echo "<a href='$elemento3.gif' target='_blank'><img src='gif.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}
else if (file_exists("$elemento3.jpg")) { 
echo "<a href='$elemento3.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}
else if (file_exists("$elemento4.gif")) { 
echo "<a href='$elemento4.gif' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
} 
else if (file_exists("$elemento4.jpg")) { 
echo "<a href='$elemento4.jpg' target='_blank'><img src='jpg.gif' border='0' width='16' height='16' alt='Imagen del archivo'></a>&nbsp;";
}  
else 
{ 
echo "";
} 
?>
<?
// tomamos la imagen de la extension de los archivos
// mostramos sin es un fichero .zip .ace .rar
if(file_exists("$elemento2.zip")) {
echo "<img src='zip.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento3.rar")) {
echo "<img src='rar.gif' border='0' width='16' height='16'>";
} 
else if(file_exists("$elemento4.ace")) {
echo "<img src='ace.gif' border='0' width='16' height='16'>";
} 
else 
{ 
echo "";
} 
?>
&nbsp; 
<a href="index.php?a=<?
// Mostramos la url en el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2";
} 
else if (file_exists("$elemento3.rar")) { 
echo "$elemento3";
} 
else if (file_exists("$elemento4.ace")) { 
echo "$elemento4";
} else 
{ 
echo "No existe";
} 
?>" > 
<?
// Mostramos el archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2";
} 
else if(file_exists("$elemento3.rar")) {
echo "$elemento3";
} 
else if(file_exists("$elemento4.ace")) {
echo "$elemento4";
} 
else 
{ 
echo "";
} 
?>
        </a> </div></td>
    <td align="center" bgcolor="#444444" ><div align="left"><a href="opinion.php?b=<?  
// Opinar sobre un archivo
if(file_exists("$elemento2.zip")) {
echo "$elemento2";
}
else { 
if(file_exists("$elemento4.ace")) { 
echo "$elemento4";
} 
else { 
echo "$elemento3";
} 
}
?>"> <img src="opinion.gif" width="16" height="16" border="0" alt="Da tu opinion acerca de este archivo"></a> 
        &nbsp; 
        <?
// Descripcion del archivo
if(file_exists("$elemento2.desc.txt")) {
include("$elemento2.desc.txt");
} 
else if (file_exists("$elemento3.desc.txt")) { 
include("$elemento3.desc.txt"); 
} 
else if (file_exists("$elemento4.desc.txt")) { 
include("$elemento4.desc.txt");
} else 
{ 
echo "Sin descripcion";
} 
?>
      </div></td>
    <td align="center" bgcolor="#444444" ><div align="left">
<?  
// asignamos el tama�o de los archivo
if(filesize($elemento) > 1000000) {
$tamano = filesize($elemento)/1024/1024;
$tamano = ceil($tamano) ;
echo "$tamano Mb";
}
else { 
if(filesize($elemento) > 1000) {
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
echo "$tamano Kb";
} 
else {
$tamano = filesize($elemento);
$tamano = ceil($tamano);
echo "$tamano bytes";
} 
}
?>&nbsp; 
        </div></td>
    <td align="center" bgcolor="#444444" ><div align="left">&nbsp;
        <?
// asignamos el tama�o de los archivo
if(file_exists("$elemento2.txt")) {
include("$elemento2.txt");
} 
else if(file_exists("$elemento3.txt")) {
include("$elemento3.txt");
} 
else if(file_exists("$elemento4.txt")) {
include("$elemento4.txt");
} 
else 
{ 
echo "0";
} 
?>
      </div></td>
  </tr>
  <?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = readdir($dir))
{
  $Show['10 Siguientes'] = 1;
}

//Cerramos el directorio
closedir($dir);
?>
</table>
<div align="right">
  <?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['10 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."\">10 Anteriores | </a>");
if ($Show['10 Siguientes'] == 1) echo("<a href=\"index.php?c=".($Plus+$Config['Show'])."\">10 Siguientes</a>");
?>
</div><br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="194" align="center" bgcolor="#444444" > <div align="left"> 
        <?
if($enviar) {
if($archivo != "" ) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "zip" && $extensiones[$num] != "ace" && $extensiones[$num] != "rar" ) { $error = "S�lo se permiten archivos .zip .ace .rar <br>" ; }
if(file_exists("$archivo_name")) { $error = "Ya existe un archivo con este nombre.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
move_uploaded_file($archivo,"$archivo_name") ;
echo "<div aling=left>* El archivo <a href='$archivo_name' target='_blank'>$archivo_name</a> ha sido subido con �xito. <a href='$_SERVER[REQUEST_URI]' target='_top'>pulsa aqui</a></div>" ;
// Asignamos el nombre sin la extension
if (strpos($archivo_name,".zip") > 1) { $nombre = str_replace(".zip","",$archivo_name); }
if (strpos($archivo_name,".rar") > 1) { $nombre = str_replace(".rar","",$archivo_name); }
if (strpos($archivo_name,".ace") > 1) { $nombre = str_replace(".ace","",$archivo_name); }
// imagen adjunta
if($archiv != "" && $envioarchivo == 1) {
$extensiones = explode(".",$archiv_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "gif") { $error = "S�lo se permiten archivos .gif<br>" ; }
if($archiv_size > 250000) { $error= "El archivo debe pesar menos de 250 Kb.<br>" ; }
if($archiv_name != "$nombre.gif") { $error= "El archivo debe tener el mismo nombre del tutorial que es $archivo.gif<br>" ; }
copy($archiv,"$nombre.gif") ;
}
// A�adir una descripcion
$msg = $HTTP_POST_VARS['msg'];
if (isset($nombre)&&isset($msg)&&($nombre!="")&&($msg!=""))
{
// creamos el contador para el enlace
$f1=fopen("$nombre.txt","w+");
fwrite($f1,"0");
fclose($f1);
//a�adimos el enlace en si :D
$date = getdate();
$time = getdate (time());
$msg = str_replace("\n", "<br>", $msg);
// bbcode
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nombre  = quitar($nombre ) ;
$msg = quitar($msg) ;
$nombre = trim($nombre) ;
// fin bbcode
$msg = chunk_split($msg,100,"\n");
$archivo="$nombre.desc.txt"; 
$uusi="$msg\n";
$fp=fopen($archivo, "w+");
$vanha=fread($fp, filesize($archivo));
fseek($fp, 0);
fputs($fp, "${uusi}${vanha}");
fclose($fp);
}
}
else {
echo "El archivo <b>$archivo_name</b> supera los 10 Mb" ;
}
}
?>
        <table width="100%" border="0" cellspacing="0" cellpadding="4">
          <tr> 
            <td width="21%" height="244" valign="top">
			  <script>
            function caracteres() {
            if(formulario.caracteres.value != formulario.msg.value.length) {
            formulario.caracteres.value = formulario.msg.value.length ;
            }
            setTimeout("caracteres()",400) ;
            }
            onload=caracteres ;
            function revisar() {
            if(formulario.archivo.value.length == 0) { alert('Debes especificar un archivo.') ; return false ; } 
            if(formulario.msg.value.length == 0) { alert('Debes escribir un comentario.') ; return false ; }
			if(formulario.msg.value.length > 400) { alert('El comentario supera los 400 caract�res') ; return false ; }

            }
            </script>
			<form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data" name="formulario" id="formulario " onsubmit="return revisar()">
                Imagen adjunta : 
                <input type='radio' name='envioarchivo' value='0' id='radio3' checked>
                <label for='radio3'>No</label>
                <input type='radio' name='envioarchivo' value='1' id='radio4'>
                <label for='radio4'>Si</label>
                <br>
                <input name="archiv" type="file" class="form" id="archiv">
                <br>
                Archivo a subir :<br>
                <input name="archivo" type="file" class="form" id="archivo">
                <br>
                Descripcion del archivo :<br>
                <textarea name="msg" cols="33" rows="5" class="form" id="textarea" onkeypress="caracteres"></textarea>
                <br>
<input type="text" name="caracteres" size="3" value="0" class="form">
                <b>M�ximo 400 caract�res</b><br>
                <input type="submit" name="enviar" value="Enviar" class="form">
              </form></td>
            <td width="79%" valign="top">&iquest; Tienes algun juego de abandonware 
              y quieres que sea publicado?<br>
              Gracias a nuestro sistema de upload podras subir ese juego que tanto 
              aprecias y que te gustaria que todo el mundo viese, solo tienes 
              que seleccionar el destno del archivo<br>
              y pulsar en envia, recuerda respetar las condiciones del upoad aqui 
              expuestas para que todo sea mas facil.<br> <br>
              Condiciones :<br>
              1) Limite por archivo <strong>10 Mb</strong>.<br>
              2) Archivos permitidos <strong>&nbsp;.zip&nbsp;.rar&nbsp;.ace</strong><br>
              3) Nombres de los archivos, sin mayusculas y sin caracteres como 
              : &ntilde;&nbsp -&nbsp _ <br> </td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
