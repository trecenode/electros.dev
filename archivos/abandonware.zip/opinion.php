<title>Comentar un archivo</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #aaaaaa ;
text-align: justify ;
scrollbar-face-color: #505050 ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #252525 ;
scrollbar-highlight-color: #757575 ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #000000 ;
scrollbar-arrow-color: #ffffff ;
}
/* Titulos */
.t1 {
color: #cccccc ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #cccccc ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #cccccc ;
}
/* Tablas del foro */
.tabla_principal {
border: #757575 1 solid ;
}
.tabla_titulo {
background: #303030 ;
}
.tabla_subtitulo {
background: #404040 ;
}
.tabla_mensaje {
background: #505050 ;
}
/* Formulario */
.form {
border: #757575 1 solid ;
background: #303030 ;
font-family: verdana ;
font-size: 8pt ;
color: #ffffff ;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
}
</style>
<body bgcolor="#404040">
<p class="t1"><font size="4"><img src="logo.gif" border="0">&nbsp;elAbandonware</font></p>
Aqui podras encontrar una lista de juegos de abandonware seleccionados y clasificados 
por sus nombre, por su tama&ntilde;o, que los disfrutes.<br>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td align="center" bgcolor="#444444" ><div align="right"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="19%"> Total archivos : 
              <?
// abrimos el directorio
$dir = opendir(".");
while ($elemento = readdir($dir)) {
// leemos solo los que tengan ese tipo de extension
$elemento = strtolower($elemento); 
if ((strpos($elemento, ".zip") > 1) || (strpos($elemento, ".rar") > 1) || (strpos($elemento, ".ace") > 1)) 
// mostramos el total de ficheros
$i++;
}
echo $i ;
?>
            </td>
            <td width="81%"><div align="right"><a href="../index.php">Vover a 
                la pagina principal</a> | <a href="index.php">Indice</a></div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="102" align="center" bgcolor="#444444"><center>
        <br>
        <?  
// tomamos la imagen que se a�ade junto a la descripcion de los archivos
// las imagenes se guardan en un archivo tipo archivo.gif o archivo.jpg
if(file_exists("$b.gif")) { 
echo "<img src='$b.gif'>";
}
else { 
if(file_exists("$b.jpg")) { 
echo "<img src='$b.jpg'>";
} 
else { 
echo "Sin imagen";
} 
} 
?>
        <br>
        <br>
        <b> 
        <div class="t1"> 
          <? 
		// titulo del archivo
		echo $b 
		?>
        </div>
        </b><br>
        <br>
      </center></td>
  </tr>
  <tr> 
    <td height="28" align="center" bgcolor="#444444"><?  
		// tomamos la descripcion en los archivos
   if(file_exists("$b.desc.txt"))  {
   include("$b.desc.txt");
   }
   else {
   $descripcion = "Sin comentarios" ;
   echo $descripcion ;
   } 
   ?>&nbsp;</td>
  </tr>
  <tr>
    <td height="28" align="center" bgcolor="#444444"> 
      <?  
// tomamos la imagen de la extension de los archivos
// mostramos sin es un fichero .zip .ace .rar
if(file_exists("$b.zip")) {
echo "<img src='zip.gif' border='0' width='16' height='16'>";
}
else { 
if(file_exists("$b.ace")) { 
echo "<img src='ace.gif' border='0' width='16' height='16'>";
} 
else {
if(file_exists("$b.ace")) { 
echo "<img src='rar.gif' border='0' width='16' height='16'>"; 
} 
}
}
?>
      &nbsp; 
      <?  
// Mostramos la url en funcion del archivo
// dependiendo de la existencia del archivo
if(file_exists("$b.zip")) {
echo "<a href='index.php?a=$b'>Descargar archivo</a>";
}
else { 
if(file_exists("$b.ace")) { 
echo "<a href='index.php?a=$b'>Descargar archivo</a>";
} 
else { 
if(file_exists("$b.rar")) { 
echo "<a href='index.php?a=$b'>Descargar archivo</a>";
} 
}
}
?>
      &nbsp;</td>
  </tr>
</table>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td width="19%" align="center" bgcolor="#2A2A2A" ><div align="left">Nombre</div></td>
    <td width="81%" align="center" bgcolor="#2A2A2A" ><div align="left">Opinion</div>
      </td>
  </tr>
  <?
$elemento = $b ;  
$file = "$elemento.com.txt"; 
//Se tramita el formulario y se guardan los nuevos datos.
if(!empty($opinion))
{
$fichero = fopen($file, "a");
// bbcode
$nombre = trim($nombre) ;
$nombre = htmlspecialchars($nombre) ;
$opinion = trim($opinion) ;
$opinion = htmlspecialchars($opinion) ;
// fin bbcode
$nombre = chunk_split($nombre,100,"<br>");
fwrite($fichero, "$nombre////$opinion\n");
fclose($fichero);
}
//Se inicia el proceso de impresion de los datos
if(file_exists($file)&&is_file($file))
{
$fichero = fopen($file, "r");
//Se extraen todas las lineas.
while(!feof($fichero))
{
$cadena = fgets($fichero, 4096);
list($nom, $men)=split('////', $cadena);
//Se elimina la lectura de los \n \r
if(!empty($cadena)){
?>
  <tr> 
    <td height="28" align="center" bgcolor="#444444" ><div align="left"><? echo $nom ?> 
      </div></td>
    <td align="center" bgcolor="#444444" >
      <div align="left"><? echo $men ?></div>
      </td>
  </tr>
  <? }
}//END WHILE
fclose($fichero);
}
?>
</table>
<br>
<table border="1" width="100%" cellpadding="4" cellspacing="1" bordercolorlight="#444444" bgcolor="#000000" bordercolordark="#555555">
  <tr> 
    <td height="23" align="center" bgcolor="#2A2A2A" ><div align="center">Deja 
        tu opinion</div></td>
  </tr>
  <tr>
    <td height="191" align="center" bgcolor="#444444" ><div align="left">
	<script>
            function caracteres() {
            if(formulario.caracteres.value != formulario.opinion.value.length) {
            formulario.caracteres.value = formulario.opinion.value.length ;
            }
            setTimeout("caracteres()",400) ;
            }
            onload=caracteres ;
            function revisar() {
            if(formulario.nombre.value.length == 0) { alert('Debes especificar un nombre.') ; return false ; } 
            if(formulario.opinion.value.length == 0) { alert('Debes escribir un comentario.') ; return false ; }
			if(formulario.opinion.value.length > 400) { alert('El comentario supera los 400 caract�res') ; return false ; }

            }
            </script>
			<FORM METHOD="Post" ACTION="<? echo $_SERVER[REQUEST_URI] ?>"  name="formulario" onsubmit="return revisar()">
          <div align="center">Nombre: <b><br>
            <INPUT NAME="nombre" TYPE="Text" id="nombre" SIZE=50 MAXLENGTH=60 class="form">
            <br>
            </b>Mensaje:<b><br>
            <textarea name="opinion" cols="50" rows="6" class="form" onkeypress="caracteres"></textarea>
            <br>
            <input type="text" name="caracteres" size="3" value="0" class="form">
            </b>M�ximo 400 caract�res <b><br>
            <br>
            <INPUT TYPE="Submit" VALUE="Enviar Opini�n" class="form">
            </b></div>
        </FORM></div></td>
  </tr>
</table>
<div align="center"><br>
  <a href="index.php">Volver</a></div>
