<?php

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

//  MODIFICA LAS SIGUIENTES VARIABLES DE ACUERDO A TUS NECESIDADES          //
//////////////////////////////////////////////////////////////////////////////

//El Host de la base de datos
$host = "localhost";

//Login para conectarse con el host
$usuario = "usuario";

//Password de la base de datos
$password = "pass";

//Nombre de la base de datos
$DBname = "nombre_base";

///////////////////////////////////////////////////////////////////////////////

if(!mysql_connect("$host","$usuario","$password"))
{
	echo "No se puede conectar con la base de datos, verifique que halla colocado los datos correctamente!!!.";
	exit();
}
if(!mysql_select_db("$DBname"))
{
	echo "Error seleccionando la base de datos!!!.";
	exit();
}
///////////////////////////////////////////////////////////////////////////////



//  Fin de la configuraci�n de la conexion          ///
////////////////////////////////////////////////////////////////////////////////
?>