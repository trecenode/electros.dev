<?

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

//Configura tu usuario y contrase�a
if(($usuario=="admin")&&($password=="banners")){
setcookie("Uscookie","logeado",time()+7776000); 
?> 
<SCRIPT LANGUAGE="javascript"> 
location.href = "banners.php"; 
</SCRIPT> 
<?
}
else{
echo "<html>
<head><title>Intento fallido al Rota-Banners Versi�n 1.0</title>
<style>
.td1 {  font-family: \"MS Sans Serif\"; font-size: 9pt}
.boton {  font-family: \"MS Sans Serif\"; font-size: 9pt; height: 22px; width: 75px}
.campo {  font-family: \"MS Sans Serif\"; font-size: 9pt; height: 22px; width: 200px}
</style>
</head>
<body bgcolor=\"#004e9b\" link=\"#ffffff\">
<br>
<br>
<br>
<br>
<table border=\"1\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" width=\"450\">
  <tr bgcolor=\"#C6C3C6\">
    <td>
      <table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">
        <tr bgcolor=\"#400080\">
          <td height=\"20\" class=\"td1\" bgcolor=\"#000084\"><b><font color=\"#FFFFFF\">
            &nbsp;Sistema de Rotaci�n de Banners Versi�n 1.0</font></b></td>
          <td height=\"20\" align=\"right\" bgcolor=\"#000084\"><img src=\"images/help.gif\" width=\"16\" height=\"14\">
            <img src=\"images/cross.gif\" width=\"16\" height=\"14\"> </td>
        </tr>
        <tr align=\"center\">
          <td colspan=\"2\">
            <form method=\"post\" action=\"ingreso.php\">
              <table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" width=\"100%\">
                <tr>
                  <td rowspan=\"3\" valign=\"top\" align=\"right\" width=\"12%\"><img src=\"images/key.gif\" width=\"35\" height=\"40\">
                  </td>
                  <td colspan=\"2\" class=\"td1\" height=\"42\"><font color=\"#0000ff\">Nombre de usuario o password incorrectos</font><br>


</tr>
                <tr>
                  <td width=\"18%\" class=\"td1\">Usuario</td>
                  <td width=\"70%\">
                    <input type=\"text\" class=\"campo\" name=\"usuario\" size=\"25\">
                  </td>
                </tr>
                <tr>
                  <td height=\"35\" width=\"18%\" class=\"td1\">Contrase�a</td>
                  <td height=\"35\" width=\"70%\">
                    <input type=\"password\" class=\"campo\" name=\"password\" size=\"25\">
                    </td>
                </tr>
              </table>
              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">
                <tr>
                  <td align=\"right\" width=\"47%\">
                    <input class=\"boton\" type=\"submit\" value=\"Aceptar\">
                  </td>
                  <td align=\"right\" width=\"1%\">&nbsp;</td>
                  <td width=\"52%\">
                    <input class=\"boton\" type=\"reset\" value=\"Restaurar\">
                  </td>
                </tr>
              </table>
            </form>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
<br>
<br>
				<!-- Please Do not Remove this copyright -->
<center><font face=\"tahoma\" size=\"-2\">Rota-Banners Ver 1.0 powered by &copy;<a href=\"http://www.kurt-cobain.info\">Victor Simental - 2002</a></font></center>
</body></html>";
}
?>