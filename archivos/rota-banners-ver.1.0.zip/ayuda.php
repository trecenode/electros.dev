<html>
<head><title>Ayuda del Sistema Rota-Banners Versi�n 1.0</title>
</head>
<body bgcolor="#111111" TEXT="#ffffff" leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0"><center>

<font face="tahoma" size="-2"><b>Solo coloca el siguiente codigo en la parte que quieras que se visualice el banner en tu sitio</b></font><br>
<font face="Tahoma" size="-2">&lt;center&gt;<br>
&lt;iframe marginWidth=0 marginHeight=0 src="http://www.sudominio.com/rotacion/clicks.php" frameBorder=0 noResize width=468 scrolling=no height=60&gt;
&lt;/iframe><br>&lt;/center&gt;</center>
</font>
</body>
</html>
