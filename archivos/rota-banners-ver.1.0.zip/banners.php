<? 

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

if($op){
setcookie("Uscookie");
?>
<SCRIPT LANGUAGE="javascript"> 
location.href = "index.php"; 
</SCRIPT> 
<?
}

if($Uscookie=="logeado"){
include("conectar.php");
if($archivo){
$medidas=GetImageSize($archivo);
mysql_query("INSERT INTO rota_banners (id, tipo, archivo, medidas, url) VALUES ('0', '$medidas[2]', '$archivo_name', '$medidas[3]', '$url')");
@copy($archivo, "banners/".$archivo_name);
echo "<script>window.alert('Upload realizado')</script>";
}
?>
<html>
<head><title>Administracion del Rota-Banners Versi�n 1.0</title>
<STYLE TYPE="TEXT/CSS">
                           BODY { SCROLLBAR-BASE-COLOR: #333333; SCROLLBAR-ARROW-COLOR: #FEC254;; }
                           A:link, A:visited { COLOR: #ffffff; TEXT-DECORATION: none; }
                           A:active, A:hover { COLOR: #FEC254; TEXT-DECORATION: none; }
.input {font-family:tahoma; font-size:8pt; background-color:111111; border-color:333333; color:666666;}
                </STYLE>
</head>
<body bgcolor="#111111" TEXT="#ffffff">
<Table Width=730 Align=center Border=0 Cellspacing=4 Cellpadding=4 Bgcolor="#333333"><Tr><Td>
<Table Width=710 Align=center Border=0 Cellspacing=1 Cellpadding=2 Bgcolor="#000000"><Tr><Td>

<Table Width=100% Align=center Border=0 Cellspacing=1 Cellpadding=0 Bgcolor="#808080">
<Tr><Td Valign=Middle Width=70% Bgcolor="#333333"><center><font face="Tahoma" size="-1"><b>
Rotaci�n de Banners Versi�n 1.0</b></font>
</center>
</td>
<td Valign=Middle Width=30% Bgcolor="#333333"><br>

<table align=center width=468 cellspacing=1 cellpadding=0 bgcolor="#000000">
<tr align="center"><td width="40%" align=left bgcolor="#222222">
<b>&nbsp;<a href="bannners.php"><img src="images/home.gif" border="0"></a></td>

<td width="20%" valign=middle bgcolor="#222222">
&nbsp;<b><a href="javascript:void(window.open('demo.php','3','width=468,height=60,toolbar=no,statusbar=no'))"><font face="Tahoma" size="-2">Demo</a></b></font></td>

<td width="20%" valign=middle bgcolor="#222222"><a href="javascript:void(window.open('ayuda.php','3','width=262,height=130,toolbar=no,statusbar=no'))">&nbsp;<b><font face="Tahoma" size="-2">Ayuda</a></font></b></td>

<td width="20%" valign=middle bgcolor="#222222">&nbsp;<font face="Tahoma" size="-2"><a href="banners.php?op=logout"><b>Salir</a></b></font>
</td></tr>
</table><center><b><font face="Tahoma" size="-2">
<form action="<?=$PHP_SELF?>" method="post" enctype="multipart/form-data">
<input type="file" name="archivo" class="input">

<b><font face="Tahoma" size="-2">Url de destino:</font></b>
<input type="text" size="13" name="url" class="input">&nbsp;<input type="submit" value="Enviar" class="input">
</form></center>

</td></tr></table>

	
<br><br>

<?
include("conectar.php");
$resultado=mysql_query("SELECT * FROM rota_banners");
if($row=mysql_fetch_array($resultado)){
DO{
if($row["tipo"]==4){
?>
<table align="center">
<tr>
<td>
<center>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
  codebase="http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0"
  id="amtl" <?=$row["medidas"]?> >
  <param name="movie" value="banners/<?=$row["archivo"]?>">
  <param name="quality" value="high">
    <embed name="amtl" src="banners/<?=$row["archivo"]?>" quality="high" <?=$row["medidas"]?>
    type="application/x-shockwave-flash"
    pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
  </embed>
</object>
</center>
</td>
<td>
<a href="borrar.php?nombre=<?=$row["archivo"]?>"><img src="images/cross.gif" border=0>&nbsp;<font face="tahoma" size="-2"><b>Borrar</a></font></b>
</td>
</tr>
</table>
<br><br>
<?
}
else{
?>
<table align="center">
<tr>
<td>
<center>
<a href="<?=$row["url"]?>">
<img src="banners/<?=$row["archivo"]?>" <?=$row["medidas"]?> border=0></a>
</center>
</td>
<td>
<a href="borrar.php?nombre=<?=$row["archivo"]?>"><img src="images/cross.gif" border=0>&nbsp;<font face="tahoma" size="-2"><b>Borrar</a></font></b>
</td>
</tr>
</table>
<br><br>
<?
}
}WHILE($row=mysql_fetch_array($resultado));
}
else
 echo "<center><font face=\"tahoma\" size=\"-1\"><b>Bienvenidos a la Administraci�n del Sistema de Rotaci�n de banners Ver 1.0 <br>Actualmente no hay banners en la base de datos.</b></font></center>";
?>
			<!-- Please Do not Remove this copyright -->
<center><font face="tahoma" size="-2">Rota-Banners Ver 1.0 powered by &copy;<a href="http://www.kurt-cobain.info">Victor Simental - 2002</a></font></center>
</td></tr></table>
		</td></tr></table>
</body>
</html>
<?
}
else{
?>
<SCRIPT LANGUAGE="javascript"> 
location.href = "index.php"; 
</SCRIPT> 
<?
}
?>
