<?

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

include("conectar.php");
$res=mysql_query("SELECT * FROM rota_banners");
$filas=mysql_num_rows($res);
for($i=1;$i<=$filas;$i++){
 $ban=mysql_fetch_array($res);
 $banner[$i]=$ban["archivo"];
}

$numero=rand(1,$filas);
$resultado=mysql_query("SELECT * FROM rota_banners WHERE archivo='$banner[$numero]'");
$row=mysql_fetch_array($resultado);
if($row["tipo"]==4){
?>
<center>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
  codebase="http://active.macromedia.com/flash4/cabs/swflash.cab#version=4,0,0,0"
  id="banner" <?=$row["medidas"]?> >
  <param name="movie" value="banners/<?=$row["archivo"]?>">
  <param name="menu" value="false">
  <param name="quality" value="high">
    <embed name="banner" src="banners/<?=$row["archivo"]?>" quality="high" <?=$row["medidas"]?>
    type="application/x-shockwave-flash"
    pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
  </embed>
</object>
</center>
<?
}
elseif($row["tipo"]!=4){
?>
<center>
<a href="<?=$row["url"]?>" target="_blank">
<img src="banners/<?=$row["archivo"]?>" <?=$row["medidas"]?> border=0></a>
</center>
<?
}
?>
