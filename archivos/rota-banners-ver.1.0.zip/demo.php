<html>
<head><title>Demo del Rota-Banners Versi�n 1.0</title>
</head>
<body bgcolor="#111111" TEXT="#ffffff" leftmargin="0" rightmargin="0">
<center>
<iframe marginWidth=0 marginHeight=0 src="clicks.php" frameBorder=0 noResize width=468 scrolling=no height=60>
</iframe>
</center>
</body>
</html>
