<html>
<head><title>Instalaci�n de Tablas del Sistema Rota-Banners Versi�n 1.0</title>
<STYLE TYPE="TEXT/CSS">
                           BODY { SCROLLBAR-BASE-COLOR: #333333; SCROLLBAR-ARROW-COLOR: #FEC254;; }
                           A:link, A:visited { COLOR: #ffffff; TEXT-DECORATION: none; }
                           A:active, A:hover { COLOR: #FEC254; TEXT-DECORATION: none; }
.input {font-family:tahoma; font-size:8pt; background-color:111111; border-color:333333; color:666666;}
                </STYLE>
</head>
<body bgcolor="#111111" TEXT="#ffffff">
<Table Width=730 Align=center Border=0 Cellspacing=4 Cellpadding=4 Bgcolor="#333333"><Tr><Td>
<Table Width=710 Align=center Border=0 Cellspacing=1 Cellpadding=2 Bgcolor="#000000"><Tr><Td>


<?php

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

include("../conectar.php");

$sql = "CREATE TABLE rota_banners (";
$sql .= "id INT NOT NULL AUTO_INCREMENT,";
$sql .= "tipo INT NOT NULL,";
$sql .= "archivo TEXT NOT NULL,";
$sql .= "medidas TEXT NOT NULL,";
$sql .= "url TEXT NULL,";
$sql .= "INDEX (id)";
$sql .= ") TYPE=MyISAM;";

echo "<center><font face=\"tahoma\" size=\"-1\"><b>Instalando Tabla Rota Banners...</b></font></center>";

if(mysql_query($sql))
{
	echo "<center><font face=\"tahoma\" size=\"-1\" color=\"#ff0000\"><b>TABLA INSTALADA EXITOSAMENTE</b></font></center>";
}
else
{
	echo "<center><font face=\"tahoma\" size=\"-1\"><b>ERROR, IMPOSIBLE INSTALAR, MySql Error:".mysql_error();
}

echo "<BR></b></font></center><br>
\t\t<!-- Please Do not Remove this copyright -->\n
<center><font face=\"tahoma\" size=\"-2\">Rota-Banners Ver 1.0 powered by &copy;<a href=\"http://www.kurt-cobain.info\">Victor Simental - 2002</a></font></center>\n";

?></td></tr></table>
		</td></tr></table>
</body>
</html>