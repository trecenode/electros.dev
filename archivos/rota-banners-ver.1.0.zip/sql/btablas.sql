CREATE TABLE rota_banners (
id INT NOT NULL AUTO_INCREMENT, 
tipo INT NOT NULL, 
archivo TEXT NOT NULL, 
medidas TEXT NOT NULL,
url TEXT NULL,
INDEX (id)
); 