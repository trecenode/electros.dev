<?

/**
 * ----------------------------------------------
 * Rota-Banners ver. 1.0 (PHP)
 * Copyright (c)2002 V�ctor Simental
 * URL: http://www.kurt-cobain.info
 * ----------------------------------------------
 */

if($Uscookie=="logeado"){
include("conectar.php");
unlink("banners/$nombre");
mysql_query("DELETE FROM rota_banners WHERE archivo='$nombre'");
echo "<script>location.href='banners.php'; </script>";
}
else{
echo "Lo siento no has ingresado, y no se puede procesar tu petici�n";
}
?>


