<?
$ugserver="wawa.eahd.or.ug";
$ugnomatch="No entries found";
$intserver="whois.crsnic.net";
$intnomatch="No match for";
$orgserver="whois.publicinterestregistry.net";
$orgnomatch="NOT FOUND";
$ukserver="whois.nic.uk";
$uknomatch="No match";
$bizserver="whois.nic.biz";
$biznomatch="Not found";
$roserver="whois.rotld.ro";
$ronomatch="Not Found";

$template = "whois.html";
$registerlink = "registrar.php";
$restrict = 0;
$REFERERS = array('topdog-software.com', 'www.topdog-software.com');

if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $domain = $_GET['domain'];
    $ext = $_GET['ext'];
    $option = $_GET['option'];
}else{
    $domain = $_POST['domain'];
    $ext = $_POST['ext'];
    $option = $_POST['option'];
}
if($restrict ==1){
    check_referer();
}
    namecheck($domain);
    if(($ext=="co.ug")||($ext=="or.ug")||($ext=="ac.ug")||($ext=="sc.ug")||($ext=="ne.ug")){
        $server=$ugserver;
        $nomatch=$ugnomatch;
    }
    if($ext=="co.uk"){
        $server=$ukserver;
        $nomatch=$uknomatch;
    }
    if($ext=="com"||$ext=="net"){
        $server=$intserver;
        $nomatch=$intnomatch;
    }
	if($ext=="org"){
		$server=$orgserver;
		$nomatch=$orgnomatch;
	}
    if($ext=="biz"){
        $server=$bizserver;
        $nomatch=$biznomatch;
    }
    if($ext=="info"){
        $server=$infoserver;
        $nomatch=$infonomatch;
    }
    if($ext=="ro"){
		$server=$roserver;
        $nomatch=$ronomatch;
    }
    if($option=="check"){
        $layout = check_domain($domain,$ext);
        print_results($layout);
    }
    if($option=="whois"){
        whois($domain,$ext);
    }
function check_domain($domain,$ext)
{
    global $nomatch,$server;
    $output="";
    if(($sc = fsockopen($server,43))==false){echo"No se puede conectar con el Whois Server : $server";exit;}
    fputs($sc,"$domain.$ext\n");
    while(!feof($sc)){$output.=fgets($sc,128);}
    fclose($sc);
    if (eregi($nomatch,$output)){
        return 0;
    }else{
        return 1;
    }
}


function whois($domain,$ext)
{   global $template,$server;
    if(($sc = fsockopen($server,43))==false){
        if(($sc = fsockopen($server,43))==false){
            echo"Ocurrio un problema temporal con el servicio, trate luego.";
            exit;
        }
    }
    if($ext=="com"||$ext=="net"){
        //
        fputs($sc, "$domain.$ext\n");
        while(!feof($sc)){
            $temp = fgets($sc,128);
            if(ereg("Whois Server:", $temp)) {
                $server = str_replace("Whois Server: ", "", $temp);
                $server = trim($server);
            }
        }
        fclose($sc);
        if(($sc = fsockopen($server,43))==false){
            echo"Ocurrio un problema temporal con el servicio, trate luego.";
            exit;
        }
    }

    $output="";
    fputs($sc,"$domain.$ext\n");
    while(!feof($sc)){$output.=fgets($sc,128);}
    fclose($sc);
    //print
    if(!is_file($template)){
        print"Error Template";
        exit;
    }
    $template = file ($template);
    $numtlines = count ($template);
    $line = 0;
    while (! stristr ($template[$line], "<!--RESULTADOS-->") && $line < $numtlines) {
	echo $template[$line];
	$line++;
    }
    $line++;
    print   "<div align=\"center\">";
    print   "<table width=\"100%\" border=\"0\" cellPadding=2 class=font1l>";
    print   "<tr><td><b>Informaci�n WHOIS para el dominio: \"$domain.$ext\"</b></td></tr>";
    print   "<tr><td><hr></td></tr><br>";
    print   "<tr><td>";
    $output= explode("\n",$output);
    foreach ($output as $value){
            print "$value<br>\n";
    }
    print "</td></tr></table>";
    print "</div>";
    print "<br>";
    print "<center><font class=font1csm>Powered by WaypointNet</font></center>";
    while ($line < $numtlines) {
	echo $template[$line];
	$line++;
   }

}
function check_referer () {
	global $REFERERS, $HTTP_REFERER;
	if ($HTTP_REFERER != "")
		while (list($val, $ref) = each($REFERERS))
		if (preg_match("/^http:\/\/$ref/", $HTTP_REFERER))
		return;
	print("Acceso negado a: $HTTP_REFERER<br>por favor no haga un link a este script, consiga una copia y instalelo en su servidor.<br> Usa ancho de banda que no le pertenece..");
        exit;
}
function print_results($layout)
{
    global $template,$registerlink,$domain,$ext;
    if(!is_file($template)){
        print"El template que seleccion� no funciona correctamente<br>
        Arreglelo si es el webmaster del site<br>
        El script no puede continuar......";
        exit;
    }
    $template = file ($template);
    $numtlines = count ($template);	//Number of lines in the template
    $line = 0;
    while (! stristr ($template[$line], "<!--RESULTADOS-->") && $line < $numtlines) {
	echo $template[$line];
	$line++;
    }
    if($layout==0){
        $line++;
        print   "<table width=\"100%\" border=\"0\" cellPadding=2 class=font1l>";
        print   "<tr><td><b>Resultados de la busqueda para el dominio: \"$domain.$ext\"</b></td></tr>";
        print   "<tr><td><hr></td></tr>";
        print   "<tr><td>��El dominio puede ser registrado!! <a href=\"$registerlink?domain=$domain.$ext\">Registralo</a> ahora</td></tr>";
        print   "</table>";
    }
    if($layout==1){
        $line++;
        print   "<table width=\"100%\" border=\"0\" cellPadding=2 class=font1l>";
        print 	"<tr><td><b>Resultados de la busqueda para el dominio: \"$domain.$ext\"</b><br></td></tr>";
        print   "<tr><td><hr></td></tr>";
        print   "<tr><td><b>El dominio no esta libre. Vea la informaci�n <a href=\"$PHP_SELF?domain=$domain&ext=$ext&option=whois\">WHOIS</a><br></td></tr>";
        print   "<tr><td>Busque otro dominio <a href=\"javascript:history.back()\">aqu�</a></td></tr>";
        print   "</table>";
    }
    print "<br><br>";
    print "<center><font class=font1csm>Powered by WaypointNet</font></center>";
    while ($line < $numtlines) {
	echo $template[$line];
	$line++;
   }
}
//This checks the name for invaild characters
function namecheck($domain)
{
    if($domain==""){echo"Debes poner un dominio para checkearlo<br>\n";
    echo"Click <a href=\"javascript:history.back()\">here</a> regresar."; exit;}
    if(strlen($domain)< 3){echo"El dominio $domain es muy corto"; exit;}
    if(strlen($domain)>57){echo"El dominio $domain es muy largo"; exit;}
    if(@ereg("^-|-$",$domain)){echo"El dominio no puede comenzar o terminar con una rayita"; exit;}
    if(!ereg("([a-z]|[A-Z]|[0-9]|-){".strlen($domain)."}",$domain))
    {echo"El dominio no puede contener caracteres especiales."; exit;}

}

?>
