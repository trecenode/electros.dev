<?
/*************************************************************************/
/* Este script fuen creado por la necesidad de pagina muchos registros   */
/* Se presta debido a que se quiere ense�ar a la gente                   */
/* Solo de pide mantener estos creditos y saber que, ha sido prestado    */
/* por Pecados-X http://www.pk2x.net/                                    */
/* Cualquier coincidencia con algun otro script parecido que sea paginar */
/* es eso, coincidencia, porque los demas no funcionan correctamente y   */
/* este si, para cualquier duda o aclaracion,                            */ 
/*               webmaster@pk2x.net nik: forber                          */
/*************************************************************************/

//conexion a la base de datos
$host="localhost";
$user="user";
$pass="tu_pass";
$db="Tu_db";
$tabla="tu_tabla";

//conectamos con la base de datos

$con=mysql_connect($host,$user,$pass);
mysql_select_db($db,$con);

//establecemos condiciones de paginacion

if (!isset($pg))
$pg = 0;
$cantidad = 10;
$inicial = $pg * $cantidad;

//realizamos la busqueda en la base de datos
$pegar = "SELECT * FROM $tabla ORDER BY id DESC LIMIT $inicial,$cantidad";
$cad = mysql_db_query($db,$pegar) or die (mysql_error());

//calculamos las paginas a mostrar

$contar = "SELECT * FROM $tabla";
$contarok = mysql_db_query($db,$contar);
$total_records = mysql_num_rows($contarok);
$pages = intval($total_records / $cantidad);

//imprimiendo los resultados
echo "<br>";
echo "<span class=\"14pix\"><b>Id</b> | </span>
	  <span class=\"14pix\"><b>Titulo</b></span>
      <br>";
	  
while ($array = mysql_fetch_array($cad))
{
echo "<tr>
	<font><b>$array[id]</b> | </font>
	<font>$array[titulo] | </font>

    <br>";
} //fin imprimir resultados
echo "<br>";


//creando los enlaces de paginacion de resultados

echo "<center><p>";
if ($pg <>0)
{
$url = $pg - 1;
echo "<font><a href='archivo.php?id=".$id."&pg=".$url."'>&laquo; Anterior</a>&nbsp;</font>";
}
else {
echo " ";
}
for ($i = 0; $i<($pages + 1); $i++) {
if ($i == $pg) {
echo "<font><b>&nbsp;$i&nbsp;</b></font>";
}
else {
echo "<font><a href='archivo.php?id=".$id."&pg=".$i."'>".$i."</a>&nbsp;</font>";
}
}
if ($pg < $pages) {
$url = $pg + 1;
echo "<font><a href='archivo.php?id=".$id."&pg=".$url."'>Siguiente &raquo;</a></font>";
}
else {
echo " ";
}
echo "</p></center>";
?>