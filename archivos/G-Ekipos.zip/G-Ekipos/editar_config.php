<link href="estilo.css" rel="stylesheet" type="text/css">
<?
include("config.php");


    $resp = mysql_query("SELECT * FROM usuarios WHERE nick='$_COOKIE[unick]'");
    
    $datos = mysql_fetch_array($resp);
    $rango = $datos[rango];
    
    if($rango == 999){
    
?>
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
if($_POST['configurar']) {
include('config.php');
@mysql_query("UPDATE `G-Ekipos_config` SET
`grupos` = '$grupos',
`ekiposxgrupo` = '$ekiposxg',
`gruposxpagina` = '$gruposxp',
`titulo` = '$titulo',
`direccion` = '$direccion' WHERE `id` = '1' ");
echo"<div align=center><span class=Estilo1> Configuracion nueva Aceptada </span>
</div>";
}
else {
include('config.php');
$resp = mysql_query("select * from `G-Ekipos_config` where id = '1'");
$config = mysql_fetch_array($resp);
?><body class="Estilo2">
 <div align="center"><img src="images/config2.jpg" width="200" height="120"><br>
 </div>
 <form name="form1" method="post" action="">
   <p>Titulo del torneo:<br>
     <input name="titulo" type="text" class="Estilo2" id="titulo" value="<? echo"$config[titulo]" ?>">
     <br>
     <br>
     Direccion:
     <br>
     <input name="direccion" type="text" class="Estilo2" id="titulo" value="<? echo"$config[direccion]" ?>">
</p>
   <p> Numero de Grupos: (aprox)<br>
     <input name="grupos" type="text" class="Estilo2" id="grupos" value="<? echo"$config[grupos]" ?>"> 
     <br>
     <?
	 if ($config[grupos] =="1") {
	 echo" Usted Tiene Seleccionado Que no desea tener mas de un grupo si desea cambiar eso <br>
     introdusca un valor mayor a 1 para abilitar la funcion agregar grupo y ekipos x grupo y grupos x pagina";
	 }
	 else {
	 echo "Numero de Ekipos x Grupo:<br>
     <input name=\"ekiposxg\" type=\"text\" class=\"Estilo2\" id=\"ekiposxg\" value=\"$config[ekiposxgrupo]\">
     <br>
     <br>
     Grupos Por Pagina:<br>
     <input name=\"gruposxp\" type=\"text\" class=\"Estilo2\" id=\"gruposxp\" value=\"$config[gruposxpagina]\">
";
}
	 ?>
   </p>
   <p>
     <input name="configurar" type="submit" id="configurar" value="Configurar">
     <br>
   </p>
 </form>
 <?
 }
}
else {
echo"acceso denegado";
}
 ?> 
