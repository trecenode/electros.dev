<?
$host = "localhost"; //Host normalmente es localhost
$user = ""; // tu usuario
$pass = ""; // pass o contrase�a
$db = "usuarios2"; // tu base de datos el nombre
$conectar = mysql_connect($host,$user,$pass) ; mysql_select_db($db,$conectar) ;
?>