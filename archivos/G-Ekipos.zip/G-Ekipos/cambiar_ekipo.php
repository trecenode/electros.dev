<link href="estilo.css" rel="stylesheet" type="text/css">
<?
include("config.php");


    $resp = mysql_query("SELECT * FROM usuarios WHERE nick='$_COOKIE[unick]'");
    
    $datos = mysql_fetch_array($resp);
    $rango = $datos[rango];
    
    if($rango == 999){
    
?>
<?

////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
include('config.php');
if ($_GET['cambiar']) {
if ($_POST['editar']) {
@mysql_query("UPDATE `G-Ekipos_ekipos` SET
`nombre` = '$nombre',
 `grupo` = '$grupo' WHERE `id` = '$cambiar' ");
echo "<div align=center><span class=Estilo1> nombre Cambiado con Exito </span>
</div>";
}
else {
$resp = mysql_query("select * from `G-Ekipos_ekipos` where id = '$cambiar'");
$ekipos = mysql_fetch_array($resp);
?>
<form action="" method="post" name="form1" class="Estilo2">
 Nombre del Ekipo:<br>
   <input name="nombre" type="text" class="Estilo2" id="$nombre" value="<? echo"$ekipos[nombre]" ?>">
   <br>
   <input name="editar" type="submit" class="Estilo2" id="editar" value="Editar">
   <br>
   <br>
   Grupo: (grupo en el que estara) <br>
          <select name="grupo" id="gru">
		  "<option value="<? echo "$ekipos[grupo]" ?>"selected><? echo "$ekipos[grupo]" ?></option>
		  <?
		  include('config.php');
		  $gru = mysql_query("select * from `G-Ekipo_grupos` order by id");
		  while ($grupos = mysql_fetch_array($gru)) {
		  echo"<option value=\"$grupos[nombre]\">$grupos[nombre]</option>"; 
		  }
		  ?>
                              </select>
          
</form> 
 <?
 }
 }
 else { 
 echo"intento de Hackeo";
 }
 }
 ?>