<link href="estilo.css" rel="stylesheet" type="text/css">
<?
include("config.php");


    $resp = mysql_query("SELECT * FROM usuarios WHERE nick='$_COOKIE[unick]'");
    
    $datos = mysql_fetch_array($resp);
    $rango = $datos[rango];
    
    if($rango == 999){
    
?>
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
include('config.php');
$con = mysql_query("select * from `G-Ekipos_config` where id = '1'");
$config = mysql_fetch_array($con);
$mas = mysql_query("select * from `G-Ekipos_ekipos`");
$nekipos = mysql_num_rows($mas);
$masg = mysql_query("select * from `G-Ekipos_grupos`");
$ngrupos = mysql_num_rows($masg);
$ekiposxg = $config[ekiposxgrupo];
$grupost = $ngrupos * $ekiposxg;
?>
<body class="Estilo2"><div align="center">
 <p><img src="images/admin.jpg" width="200" height="120"><br>
    <a href="<? echo"$config[direccion]"?>administracion&gk=nuevoe"><?
	if ($nekipos < $grupost) {
echo"<a href=\"$config[direccion]administracion&gk=nuevoe\"><img src=\"images/nek.jpg\" width=\"120\" height=\"15\" border=\"0\"></a>";
}?> </a>     <?
if ($config[grupos] != "1") {
echo"<a href=\"$config[direccion]administracion&gk=nuevog\"><img src=\"images/ngr.jpg\" width=\"120\" height=\"15\"border=\"0\"></a>";
}
?> 
    <a href="<? echo "$config[direccion]" ?>administracion&gk=configuracion"><img src="images/config.jpg" width="120" height="15" border="0"></a><br>
    <?
	if ($nekipos > $grupost) {
echo"Tienes demasiados ekipos Ekipos y ya no hay en que grupo meterlo, necesita crear otro grupo";
}?>
<?
if ($_GET['gk']) {
echo"<br><a href=\"$config[direccion]administracion\">Volver a Administracion</a>";
}
?>
     <?
if ($_GET['gk'] == "") {
?>
    <br> 
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
   <tr>
     <td width="25%" class="Estilo2"><p>Nombre del Ekipo:</p>
      </td>
     <td width="25%" class="Estilo2">Puntos Acomulados:</td>
     <td width="25%" class="Estilo2">Editar</td>
     <td width="25%" class="Estilo2">Puntuar</td>
<?
$mostrar = $config[ekiposxgrupo] ; 
if(!$desde) { $desde = 0 ; }  
$eki = mysql_query("select * from `G-Ekipos_ekipos` order by id desc LIMIT $desde,$mostrar");
$desde = $desde + $mostrar ;
while ( $ekipos = mysql_fetch_array($eki)) {
?>
    <br>
 </p>
   <tr>
     <td width="25%"><a href="<? echo "$config[direccion]"?>tabla&ver=<? echo"$ekipos[id]"?>"><? echo "$ekipos[nombre]"  ?></a>&nbsp;</td>
     <td width="25%"><? echo "$ekipos[puntos]"  ?>&nbsp;</td>
     <td width="25%"><a href="<? echo"$config[direccion]" ?>administracion&gk=editare&cambiar=<? echo "$ekipos[id]"?>"><img src="images/eek.jpg" width="120" height="15" border="0"></a></td>
     <td width="25%"><a href="<? echo"$config[direccion]" ?>administracion&gk=puntuacion&puntos=<? echo "$ekipos[id]"?>"><img src="images/punt.jpg" width="120" height="15" border="0"></a></td>
   </tr>
<?
}
}
?>
</table>
<?
// mostrar siguientes 6 noticias
$siguientes = $_GET[desde] + $config[ekiposxgrupo] ;
$anterior = $_GET[desde] - $config[ekiposxgrupo];
if($_GET[desde] < $config[ekiposxgrupo]) {
echo"|<a href=$config[direccion]administracion&desde=$siguientes>Mas Ekipos</a>";
}
if($_GET[desde] >= $config[ekiposxgrupo]) {
echo"<a href=$config[direccion]administracion&desde=$anterior>Anteriores Ekipos</a> | <a href=$config[direccion]administracion&desde=$siguientes>Mas Ekipos</a>";
}
?>
<?
if ($_GET['gk'] == "editare") {
include ('cambiar_ekipo.php');
}
if ($_GET['gk'] == "nuevog") {
include ('nuevo_grupo.php');
}
if ($_GET['gk'] == "nuevoe") {
include('nuevo_ekipo.php');
}
if ($_GET['gk'] == "editarg") {
include ('grupoed');
}
if ($_GET['gk'] == "puntuacion") {
include ('puntuacion.php');
}
if ($_GET['gk'] == "configuracion") {
include ('editar_config.php');
}
?>

 
 <p>    <br> 
  </p>
</div>
<?
}
else {
echo"acceso denegado";
}
?>
