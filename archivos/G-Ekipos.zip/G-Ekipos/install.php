<style type="text/css">
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
}
.Estilo2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
}

</style>
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
if ($_POST['instalar']) {
$conectar = mysql_connect($host,$usuario,$pass); mysql_select_db($db,$conectar) ;
$drop1 = "DROP TABLE IF EXISTS `g-ekipos_ekipos";
mysql_query($drop1);
$drop2 = "DROP TABLE IF EXISTS `g-ekipos_grupos";
mysql_query($drop2);
$drop3 = "DROP TABLE IF EXISTS `g-ekipos_config";
mysql_query($drop3);
$sql =  "
CREATE TABLE `G-Ekipos_ekipos` (
`id` SMALLINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`nombre` VARCHAR( 30 ) NOT NULL ,
`perdidos` VARCHAR( 5 ) NOT NULL ,
`ganados` VARCHAR( 5 ) NOT NULL ,
`empatados` VARCHAR( 5 ) NOT NULL ,
`puntos` VARCHAR( 6 ) NOT NULL ,
`grupo` VARCHAR( 6 ) NOT NULL ,
`racha` VARCHAR( 20 ) NOT NULL ,
PRIMARY KEY (`id`)
)";
@mysql_query($sql);
$sql2 = "
alter table `$tabla` add `rango` smallint(5) DEFAULT '1' not null after `mensajes`
";
@mysql_query($sql2);
$sql3 = "
update `$tabla` set `rango`='999' where nick = '$nick'";
@mysql_query($sql3);
if ($resp == "si") {
$sql4 = "
CREATE TABLE `G-Ekipos_grupos` (
`id` SMALLINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`nombre` VARCHAR( 30 ) NOT NULL ,
PRIMARY KEY (`id`)
)
";
@mysql_query($sql4);
$sql5 = "
CREATE TABLE `G-Ekipos_config` (
`id` SMALLINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`grupos` VARCHAR( 5 ) NOT NULL ,
`ekiposxgrupo` VARCHAR( 5 ) NOT NULL ,
`gruposxpagina` VARCHAR( 5 ) NOT NULL ,
`titulo` VARCHAR( 30 ) NOT NULL ,
`direccion` VARCHAR( 30 ) NOT NULL ,
PRIMARY KEY (`id`)
)
";
@mysql_query($sql5);
$sql6 = "insert into `G-Ekipos_config`(`grupos`,`ekiposxgrupo`,`gruposxpagina`,`titulo`,`direccion`) Values ('$grupos','$ekiposxg','$gruposxp','$titulo','$direccion')";
@mysql_query($sql6);
echo "<br>
<div align=center class=Estilo2>Instalaci&oacute;n Llevada Acabo Con Exito<br>
  <span class=Estilo1>no se te olvide borrar este archivo al termino de esta instalacion  <br>
   recuerda tener un config.php para los demas archivos<br>
  </span></div>
</body>";
} 
else {
$sql4 = "
CREATE TABLE `G-Ekipos_grupos` (
`id` SMALLINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`nombre` VARCHAR( 30 ) NOT NULL ,
PRIMARY KEY (`id`)
)
";
@mysql_query($sql4);
$sql5 = "
CREATE TABLE `G-Ekipos_config` (
`id` SMALLINT( 3 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`grupos` VARCHAR( 5 ) NOT NULL ,
`ekiposxgrupo` VARCHAR( 5 ) NOT NULL ,
`gruposxpagina` VARCHAR( 5 ) NOT NULL ,
`titulo` VARCHAR( 30 ) NOT NULL ,
`direccion` VARCHAR( 30 ) NOT NULL ,
PRIMARY KEY (`id`)
)
";
@mysql_query($sql5);
$sql6 = "insert into `G-Ekipos_config`(`grupos`,`ekiposxgrupo`,`gruposxpagina`,`titulo`,`direccion`) Values ('1','0','0','$titulo','$direccion')";
@mysql_query($sql6);
echo "<br>
<div align=center class=Estilo2>Instalaci&oacute;n Llevada Acabo Con Exito<br>
  <span class=Estilo1>no se te olvide borrar este archivo al termino de esta instalacion  <br>
   recuerda tener un config.php para los demas archivos<br>
  </span></div>
</body>";
}
}
else {
?>

<body class="Estilo2">
 <div align="center" class="Estilo2"><img src="images/titulo.jpg" width="200" height="120"><br>
   inserccion de ekipos - edicion de ekipos - edicion de grupos -inserccion de puntos - edicion de puntos - administrasion de racha del ekipo - partidos ganados y perdidos<br> 
   <br>
  Instalacion de Tablas <br>
</div>
<form name="form1" method="post" action="">
  <table width="100%" height="100" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="50%" bordercolor="#FFFFFF" class="Estilo2"><p><span class="Estilo2">Host:<br>
          <input name="host" type="text" class="Estilo2" id="host" value="localhost">
          <br>
          <br>
Usuario:<br>
<input name="usuario" type="text" class="Estilo2" id="usuario" value="usuario" onFocus="if(this.value=='usuario')this.value='';"> 
 
<br>
<br>
PassWord:<br>
<input name="pass" type="password" class="Estilo2" id="pass" value="contrasena" onFocus="if(this.value=='contrasena')this.value='';">
<br>
<br>
Base de datos:</span><br>
<input name="db" type="text" class="Estilo2" id="db" value="tu base de datos" onFocus="if(this.value=='tu base de datos')this.value='';">
<br>
<br> 
<span class="Estilo2">Nick del Administrador:
</span><br>
<input name="nick" type="text" class="Estilo2" id="nick" value="de la web" onFocus="if(this.value=='de la web')this.value='';">
<br>
<br>
<span class="Estilo2">Tabla de Usuarios </span><br>
<input name="tabla" type="text" class="Estilo2" id="db" value="usuarios" onFocus="if(this.value=='usuarios')this.value='';">
<br> 
<br> 
Deseas Tener Mas de 1 Grupo<span class="Estilo2"></span><br> 
Si
<input name="resp" type="radio" value="si"> 
No 
<input name="resp" type="radio" value="no">
</p>
        <p>Titulo del Torneo: <br>
          <input name="titulo" type="text" class="Estilo2" id="db" onFocus="if(this.value=='usuarios')this.value='';">
          <br>
          <br>
          Direccion:<br>
          Ejemplo: si tus direcciones son<br>
          index.php?id=noticias solo pones<br>
          index.php?id=<br>
          <input name="direccion" type="text" class="Estilo2" id="db" onFocus="if(this.value=='index.php?secc=')this.value='';" value="index.php?id=">
</p>
        <p>Si Seleccionas si Rellena numero de grupos y sige con lo demas <br>
          <br>
          Si Selecionas no ya no llenes nada mas<br>
          Numero de Grupos: (aproximadamente)<br> 
          <input name="grupos" type="text" class="Estilo2" id="db"  size="5">
          <br>
          Grupos Por Pagina:<br>
          <input name="gruposxp" type="text" class="Estilo2" id="db" onFocus="if(this.value=='5')this.value='';" value="5" size="5">
          <br>
          <br>
          Ekipos Por Grupo:<br>
          <input name="ekiposxg" type="text" class="Estilo2" id="db" onFocus="if(this.value=='5')this.value='';" value="5" size="5">
          <br>
      </p>
      </td>
      <td width="50%"><div align="center">
        <input name="instalar" type="submit" id="instalar" value="Instalar">
      </div></td>
    </tr>
  </table>
</form>
  <?
  }
  ?>
