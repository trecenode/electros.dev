<link href="estilo.css" rel="stylesheet" type="text/css">
<?
include("config.php");


    $resp = mysql_query("SELECT * FROM usuarios WHERE nick='$_COOKIE[unick]'");
    
    $datos = mysql_fetch_array($resp);
    $rango = $datos[rango];
    
    if($rango == 999){
    
?>
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
include('config.php');
if ($_POST['insertar']) {
@mysql_query("insert into `G-Ekipos_grupos` (`nombre`) Values ('$nombre')");
echo"<div align=center><span class=Estilo2> Grupo agregado Con Exito </span>
</div>"; 
}
else {
?><body class="Estilo2">
 <br>
 <form name="form1" method="post" action="">
   Nombre del Grupo: ( Suelen llamarse a,b,c ya si sucesivamente)<br>
   <input name="nombre" type="text" class="Estilo2" id="$nombre">
   <br>
   <input name="insertar" type="submit" id="insertar" value="Insertar">
 </form> 
 <?
 }
}
else {
echo"acceso denegado";
}
 ?>
