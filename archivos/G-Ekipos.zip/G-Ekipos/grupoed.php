<link href="estilo.css" rel="stylesheet" type="text/css">
<?
include("config.php");


    $resp = mysql_query("SELECT * FROM usuarios WHERE nick='$_COOKIE[unick]'");
    
    $datos = mysql_fetch_array($resp);
    $rango = $datos[rango];
    
    if($rango == 999){
    
?>
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
if ($_GET['grupo']) {
include('config.php');
if ($_POST['editar']) {
@mysql_query("
UPDATE `G-Ekipos_grupos` SET
`nombre` = '$nombre' WHERE `id` = '$grupo' 
");
echo"<div align=center><span class=Estilo2> Grupo Editado Con Exito </span>
</div>"; 
}
else {
$resp = mysql_query("select * from `G-Ekipos_grupos` where id = '$grupo'");
$grupos = mysql_fetch_array($resp);
?><body class="Estilo2">
 <br>
 <form name="form1" method="post" action="">
  Nombre del Grupo<br>
   <input name="nombre" type="text" class="Estilo2" id="$nombre" value="<? echo "grupos[nombre]"?>">
   <br>
   <input name="insertar" type="submit" id="insertar" value="Insertar">
 </form> 
 <?
 }
 }
 else {
 echo "intento de hackeo";
 }
}

 ?>
