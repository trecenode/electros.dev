<link href="estilo.css" rel="stylesheet" type="text/css">
<?
////////////////////////////////
//      G-Ekipos Script       //
//   daniel@gdesigns.com.mx   //
//           por              //
//    Daniel Gonzalez Toledo  //
//      www.gdesigns.com.mx   //
//      www.gproyect.info     //
////////////////////////////////
include('config.php');
$con = mysql_query("select * from `G-Ekipos_config` where id = '1'");
$config = mysql_fetch_array($con); 
?>
<title><? echo "$config[titulo]" ?></title>
<style type="text/css">
<!--
.Estilo3 {
	font-size: 18px;
	font-weight: bold;
}
-->
</style>
<body class="Estilo2"><p align="center" class="Estilo2 Estilo3"><? echo "$config[titulo]" ?></p>
<body class="Estilo2">
<?
if($_GET['ver']) {
$eki = mysql_query("select * from `G-Ekipos_ekipos` where `id` = '$ver'");
$ekipos = mysql_fetch_array($eki);
?>
<div align="center"><? echo "$ekipos[nombre]" ?><br>
  <br>
  Victorias<br>
  <? echo "$ekipos[ganados]" ?>
  <br>
  Derrotas<br>
  <? echo "$ekipos[perdidos]" ?>
  <br>
  Empates<br>
  <? echo "$ekipos[empatados]" ?>
  <br>
  Puntos:<br>
  <? echo "$ekipos[puntos]" ?>
  <br>
  Racha:
  <br>
  <? echo "$ekipos[racha]" ?>
  </div>

  
<?
}
else {
$mostrar = $config[gruposxpagina] ; 
if(!$desde) { $desde = 0 ; }  
$gru = mysql_query("select * from `G-Ekipos_grupos` order by nombre  LIMIT $desde,$mostrar");
$desde = $desde + $mostrar ;
while ($grupos = mysql_fetch_array($gru)) {
echo"
<table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
    <tr align=\"center\">
      <td colspan=\"2\"><span class=\"\&quot;Estilo2\&quot;\"><b>Grupo $grupos[nombre]</b></span></td>
  </tr>
    <tr>
      <td width=\"50%\">Nombre:</td>
      <td width=\"50%\">Puntos:</td>
    </tr>";
$eki = mysql_query("select * from `G-Ekipos_ekipos` where `grupo` = '$grupos[nombre]' order by puntos desc limit $config[ekiposxgrupo]");
while ($ekipos = mysql_fetch_array($eki)) {
echo"
    <tr>
	<tr align=\"center\">
      <td width=\"50%\"><a href=\"$config[direccion]tablas&ver=$ekipos[id]\">$ekipos[nombre]</td>
      <td width=\"50%\">$ekipos[puntos]</td>
    </tr>";
	}
	}
}
?>
  </table>
  <?
// mostrar siguientes 6 noticias
$siguientes = $_GET[desde] + $config[gruposxpagina] ;
$anterior = $_GET[desde] - $config[gruposxpagina];
if($_GET[desde] < $config[gruposxpagina]) {
echo"|<a href=$config[direccion]tablas&desde=$siguientes>Mas Ekipos</a>";
}
if($_GET[desde] >= $config[gruposxpagina]) {
echo"<a href=$config[direccion]tablas&desde=$anterior>Anteriores Ekipos</a> | <a href=$config[direccion]tablas&desde=$siguientes>Mas Ekipos</a>";
}
?>
</div>
<p>&nbsp;</p>
</p>