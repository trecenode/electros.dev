<?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = quitar($usuario) ;
$titulo= quitar($titulo) ;
$noticia= quitar($noticia) ;
$noticiaext= quitar($noticiaext) ;
mysql_query("insert into noticias (fecha,usuario,titulo,noticia,noticiaext) values ('$fecha','$usuario','$titulo','$noticia','$noticiaext')") ;
echo "La noticia ha sido enviada con �xito." ;
mysql_close($conectar) ;
}
?>
<form method="post" action="noticiasenviar.php">
Usuario:<br>
<input type="text" name="usuario" maxlength="20"><br>
T�tulo:<br>
<input type="text" name="titulo" maxlength="100"><br>
Noticia:<br>
<textarea name="noticia" cols="30" rows="5"></textarea><br>
Noticia extendida:
<textarea name="noticiaext" cols="30" rows="5"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar">
</form>