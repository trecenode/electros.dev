<?
include("config.php") ;
if($n) {
$resp = mysql_query("select * from noticias where id='$n'") ;
$datos = mysql_fetch_array($resp) ;
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Se agregar�n los <br> correspondientes a la noticia extendida
$noticiaext = $datos[noticiaext] ;
$noticiaext = str_replace("\r\n","<br>",$noticiaext) ;
echo "
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr>
<td>$datos[titulo]</td>
<td><div align=right>$fecha</div></td>
</tr>
<tr>
<td colspan=2>
$datos[noticia]<br><br>
$noticiaext<br><br>
<b>Enviada por:</b> $datos[usuario]<br>
<a href=noticias.php>Regresar a la p�gina principal</a>
<p>
" ;
mysql_free_result($resp) ;
echo "<p><b>Comentarios</b>" ;
$resp = mysql_query("select * from noticiascom where noticia='$n' order by id asc") ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron comentarios." ; }
else {
$comentarios = mysql_num_rows($resp) ;
echo "
<p><b>Total de comentarios:</b> $comentarios
<p>
" ;
$mostrar = 5 ;
while($datos = mysql_fetch_array($resp)) {
if($mostrar > 0) {
// Mostrar fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
echo "
<table width=100% border=0 cellpadding=1 cellspacing=0>
<tr>
<td><b><$datos[usuario]></b></td>
<td><div align=right><b>$fecha</b></div></td>
</tr>
<tr>
<td colspan=2>
$datos[comentario]
</td>
</tr>
</table><br>
" ;
}
$mostrar-- ;
}
}
mysql_free_result($resp) ;
echo "
<p>
<p><b>Escribir comentario</b>
<p>
<form method=post action=noticiascom.php>
<input type=hidden name=noticia value=$n>
Usuario:<br>
<input type=text name=usuario maxlength=20><br>
Comentario:<br>
<textarea name=comentario cols=30 rows=5></textarea><br><br>
<input type=submit name=enviar value=Enviar>
</form>
</td>
</tr>
</table>
" ;
}
else {
$resp = mysql_query("select * from noticias order by id desc") ;
$mostrar = 10 ;
while($datos = mysql_fetch_array($resp)) {
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
$resp2 = mysql_query("select id from noticiascom where noticia='$datos[id]'") ;
$comentarios = mysql_num_rows($resp2) ;
if($mostrar > 0) {
echo "
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr>
<td>$datos[titulo]</td>
<td><div align=right>$fecha</div></td>
</tr>
<tr>
<td colspan=2>
$datos[noticia]
</td>
</tr>
<tr>
<td colspan=2>
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr>
<td><a href=noticias.php?n=$datos[id]>Ver m�s</a></td>
<td><b>Comentarios:</b> $comentarios</td>
<td><div align=right><b>Enviada por:</b> $datos[usuario]</div></td>
</tr>
</table>
</td>
</tr>
</table>
" ;
}
$mostrar-- ;
}
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>