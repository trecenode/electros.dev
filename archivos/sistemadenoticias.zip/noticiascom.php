<?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = quitar($usuario) ;
$comentario = quitar($comentario) ;
mysql_query("insert into noticiascom (noticia,fecha,usuario,comentario) values ('$noticia','$fecha','$usuario','$comentario')") ;
mysql_close($conectar) ;
header("location: noticias.php?n=$noticia") ;
}
?>