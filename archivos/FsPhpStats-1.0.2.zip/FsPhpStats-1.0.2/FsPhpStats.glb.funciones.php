<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

// MATRIZ EXPLORADORES
$nav["Mozilla/5.0"]   = "Mozilla";
$nav["Mozilla/4"]     = "Netscape";
$nav["Mozilla/3"]     = "Netscape";
$nav["Firefox"]       = "Mozilla Firefox";
$nav["Firebird"]      = "Mozilla Firefox";
$nav["MSIE"]          = "Internet Explorer";
$nav["Netscape"]      = "Netscape";
$nav["Galeon"]        = "Galeon";
$nav["Konqueror"]     = "Konqueror";
$nav["Opera"]         = "Opera";
//##

// MATRIZ SISTEMAS OPERATIVOS

$os["Win95"]              = "Windows 95";
$os["Win98"]              = "Windows 98";
$os["WinNT"]              = "Windows NT";
$os["WinNT 5.0"]          = "Windows 2000";
$os["WinNT 5.1"]          = "Windows XP";
$os["Windows 95"]         = "Windows 95";
$os["Windows 98"]         = "Windows 98";
$os["Windows NT 5.0"]     = "Windows 2000";
$os["Windows NT 5.1"]     = "Windows XP";
$os["Linux"]              = "Linux";
$os["OS/2"]               = "OS/2";
$os["Sun"]                = "sun OS";
$os["Macintosh"]          = "Macintosh";
$os["Mac_PowerPC"]        = "Macintosh";
//#

function FsPhpStatsNav()
{
	global $nav;
	$nfo = $_SERVER['HTTP_USER_AGENT'];
	while (list($ndc, $val) = each ($nav)) 
	{
		if(strpos($nfo,$ndc))
		{
			return $nav[$ndc];
		}
	}
	return LNG_OTHER;
}
function FsPhpStatsOs()
{
	global $os;
	$nfo = $_SERVER['HTTP_USER_AGENT'];
	while (list($ndc, $val) = each ($os)) 
	{
		if(strpos($nfo,$ndc))
		{
			return $os[$ndc];
		}
		elseif((strpos($nfo,"Windows NT") or strpos($nfo,"WinNT")) and !(strpos($nfo,"Windows NT 5.0") or strpos($nfo,"WinNT 5.0")) and !(strpos($nfo,"Windows NT 5.1") or strpos($nfo,"WinNT 5.1")))
		{
			return "Windows NT";
		}
	}
	return LNG_OTHER;
}
function FsPhpStatsPais()
{
	if(strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'],"-"))
	{
		$pais      = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,strpos($_SERVER['HTTP_ACCEPT_LANGUAGE'],"-"));
	}
	else
	{
		$pais      = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
	}
	$pais      = substr($pais,0,2);
	if(!$pais)
	{
		return LNG_SHW_NRF;
	}
	return $pais;
}
function FsPhpStatsISP()
{
	$add = gethostbyaddr($_SERVER['REMOTE_ADDR']);
	return $add;
}
function FsPhpStatsPrintErr($err)
{
	global $cfg;
	if(file_exists($cfg["idioma"].".php"))
	{
		include($cfg["idioma"].".php");
	}
	else
	{
		define(LNG_ERR_NM,"Error");
	}
	echo "<b>FsPhpStats ".LNG_ERR_NM."</b> - ".$err;
	exit();
}
function SysMakeNChars($s,$n,$sp)
{
	if(strlen($s) > $n)
	{
		return substr($s,0,$n-2)."...";
	}
	else
	{
		$bc = $n - strlen($s);
		for($a = 0; $a <= $bc; $a++)
		{
			$ins = $ins.$sp;
		}
		return $s.$ins;
	}
}
function SysTextLimit($n,$txt)
{
	if(strlen($txt) > $n)
	{
		return substr($txt,0,$n-2)."...";
	}
	else
	{
		return $txt;
	}
}
?>
