<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

function MysqlMasRepetidos($db,$campo)
{
	if(!($sql = @mysql_db_query($db,"select * from fsphpstats")))
	{
		FsPhpStatsPrintErr(LNG_ERR_AV." [".mysql_error()."]");
	}
	while($res = mysql_fetch_array($sql))
	{
		if(!$val[$res[$campo]])
		{
			$val[$res[$campo]] = 1;
		}
		else
		{
			$val[$res[$campo]]++;
		}
	}
	return $val;
}

class FpsData
{
	var $MYSQL_CNN;
	var $MYSQL_DBN;
	function conectar()
	{
		global $cfg;
		$this -> MYSQL_DBN = $cfg["BD_name"];
		if(@mysql_connect($cfg["BD_host"],$cfg["BD_user"],$cfg["BD_pass"]))
		{
			$this -> MYSQL_CNN = true;
			return 1;
		}
		else
		{
			$this -> MYSQL_CNN = false;
			FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
			return 0;
		}
		
	}
	function addvisita()
	{
		global $cfg;
		if($this -> MYSQL_CNN)
		{
			$url       = $_SERVER['PHP_SELF'];
			$ref       = $_SERVER['HTTP_REFERER'];
			if(!$ref)
			{
				$ref = LNG_SHW_NRF;
			}
			$ip        = $_SERVER['REMOTE_ADDR'];
			$dia       = date("d");
			$mes       = date("n");
			$yr        = date("Y");
			$hora      = date("H:i");
			$pagvis    = 1;
			$so        = FsPhpStatsOs();
			$navegador = FsPhpStatsNav();
			$pais      = FsPhpStatsPais();
			$isp       = FsPhpStatsISP();
			if(date("w") == 0)
			{
				$dsemana = 7;
			}
			else
			{
				$dsemana = date("w");
			}
			if(!$_COOKIE['visitado'])
			{
				if(@mysql_db_query($this -> MYSQL_DBN,"insert into fsphpstats (url,ref,ip,dia,mes,yr,hora,pagvis,so,navegador,pais,isp,dsemana) values ('$url','$ref','$ip','$dia','$mes','$yr','$hora','$pagvis','$so','$navegador','$pais','$isp','$dsemana')"))
				{
					if(!($cns = @mysql_db_query($this -> MYSQL_DBN,"select * from fsphpstats order by id desc limit 1")))
					{
						FsPhpStatsPrintErr(LNG_ERR_AV." [".mysql_error()."]");
					}
					$res = @mysql_fetch_array($cns);
					if(!@setcookie("visitado",2,time()+ $cfg["session_time"]) or !@setcookie("id",$res["id"],time()+ $cfg["session_time"]))
					{
						FsPhpStatsPrintErr(LNG_ERR_CK);
					}
					return true;
				}
			}
			else
			{
				if(!@setcookie("visitado",$_COOKIE['visitado'] + 1,time()+ $cfg["session_time"]))
				{
					FsPhpStatsPrintErr(LNG_ERR_CK);
				}
				if(!@mysql_db_query($this -> MYSQL_DBN,"update fsphpstats set pagvis='".$_COOKIE['visitado']."' where id='".$_COOKIE['id']."'"))
				{
					FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
				}
				return true;
			}
		}
		else
		{
			FsPhpStatsPrintErr(LNG_ERR_DC);
		}
	}
#OBTENCION DE DATOS
	function GetVisitas()
	{
		if(!($this -> MYSQL_CNN))
		{
			FsPhpStatsPrintErr(LNG_ERR_DC);
		}
		if(!($cns = @mysql_db_query($this -> MYSQL_DBN,"select * from fsphpstats")))
		{
			FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
		}
		return mysql_num_rows($cns);	
	}
	function GetLastN($n,$arr,$sep,$spc)
	{
		if($spc == "TXT")
		{
			$sti = " ";
		}
		elseif($spc == "HTML")
		{
			$sti = "&nbsp;";
		}
		else
		{
			FsPhpStatsPrintErr(LNG_ERR_FP." [4]");
		}
		if(!($this -> MYSQL_CNN))
		{
			FsPhpStatsPrintErr(LNG_ERR_DC);
		}
		if(!($cns = @mysql_db_query($this -> MYSQL_DBN,"select * from fsphpstats order by id desc limit $n")))
		{
			FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
		}
		while($res = mysql_fetch_array($cns))
		{
			$lv[]    = SysMakeNChars($res["ip"],15,$sti)." | ".SysMakeNChars($res["dia"]."/".$res["mes"]."/".$res["yr"],12,$sti)." | ".$res["hora"];
			$lvarr[] = $res["ip"]."#".$res["dia"]."/".$res["mes"]."/".$res["yr"]." - ".$res["hora"];
		}
		if($arr == "ARRAY")
		{
			return $lvarr;
		}
		elseif($arr == "PRINT")
		{
			if($lv)
			{
				if(!$sep)
				{
					FsPhpStatsPrintErr(LNG_ERR_FP." [3]");
				}
				return join($sep,$lv);
			}
			else
			{
			return false;
			}
		}
		else
		{
			FsPhpStatsPrintErr(LNG_ERR_NR." [".$arr."]");
		}
	}
	function GetMPV()
	{
		global $cfg;
		$vt = $this -> GetVisitas();
		if(!($this -> MYSQL_CNN))
		{
			FsPhpStatsPrintErr(LNG_ERR_DC);
		}
		if(!($cns = @mysql_db_query($this -> MYSQL_DBN,"select * from fsphpstats")))
		{
			FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
		}
		$nv = 0;
		while($res = mysql_fetch_array($cns))
		{
			$nv = $nv + $res["pagvis"];
		}
		return round($nv/$vt,$cfg["decimales"]);
	}
	function GetTPV($q)
	{
		global $cfg;
		if(!($this -> MYSQL_CNN))
		{
			FsPhpStatsPrintErr(LNG_ERR_DC);
		}
		if(!($cns = @mysql_db_query($this -> MYSQL_DBN,"select * from fsphpstats $q")))
		{
			FsPhpStatsPrintErr(LNG_ERR_IC." [".mysql_error()."]");
		}
		$nv = 0;
		while($res = mysql_fetch_array($cns))
		{
			$nv = $nv + $res["pagvis"];
		}
		return $nv;
	}
	function GetMostCampo($campo,$tipo,$sep,$spc,$limit)
	{
		global $cfg,$LNG_mes,$LNG_dia;
		if($spc == "TXT")
		{
			$sti = " ";
		}
		elseif($spc == "HTML")
		{
			$sti = "&nbsp;";
		}
		
		$res = MysqlMasRepetidos($this -> MYSQL_DBN,$campo);
		arsort($res);
		while (list($ndc, $val) = each ($res)) 
		{
			$tot = $tot + $val;
		}
		reset($res);
		$a = 0;
		while (list($ndc, $val) = each ($res)) 
		{
			if(!$limit)
			{
				$arr[$ndc] = round(($val/$tot)*100,$cfg["decimales"])."%";
			}
			if($limit and $a < $limit)
			{
				$arr[$ndc] = round(($val/$tot)*100,$cfg["decimales"])."%";
			}
			$a++;
		}
		
		if($tipo == "ARRAY")
		{
			return $arr;
		}
		elseif($tipo == "PRINT")
		{
			while (list($ndc, $val) = each ($arr)) 
			{
				if($campo == "mes")
				{
					$dev[] = SysMakeNChars($LNG_mes[$ndc],25,$sti)." | ".SysMakeNChars($val,8,$sti);
				}
				elseif($campo == "dsemana")
				{
					$dev[] = SysMakeNChars($LNG_dia[$ndc],25,$sti)." | ".SysMakeNChars($val,8,$sti);
				}
				else
				{
					$dev[] = SysMakeNChars($ndc,25,$sti)." | ".SysMakeNChars($val,8,$sti);
				}
			}
			return join($sep,$dev);
		}
		else
		{
			FsPhpStatsPrintErr(LNG_ERR_NR." [".$tipo."]");
		}
	}
	function GetOnlyValues($campo)
	{
		$res = MysqlMasRepetidos($this -> MYSQL_DBN,$campo);
		arsort($res);
		return $res;
	}
}
?>
