<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

$cfg["BD_host"]      = "localhost";
$cfg["BD_user"]      = "";
$cfg["BD_pass"]      = "";
$cfg["BD_name"]      = "";
$cfg["idioma"]       = "es";
$cfg["session_time"] = 300;
$cfg["txt_limit"]    = 30;
$cfg["list_limit"]   = 200;
$cfg["decimales"]    = 2;
#COLORES
$cfg["COL_fondo"]    = "#FFFFFF";
$cfg["COL_linea"]    = "#000000";
$cfg["COL_texto"]    = "#000000";
$cfg["COL_barra"]    = "#CCFF00";
?>
