<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

define(LNG_ERR_NM,"Error");
define(LNG_ERR_LL,"Imposible cargar la libreria GD");
define(LNG_ERR_IC,"Imposible conectar a la base de datos");
define(LNG_ERR_AV,"Imposible a�adir la visita");
define(LNG_ERR_CK,"No se ha podido crear el Cookie, asegurate de que previamente a la inclusion de FsPhpStats.php y llamada de FsPhpStats_count() ho hay codigo HTML");
define(LNG_ERR_DC,"Primero debes conectarte a la base de datos");
define(LNG_ERR_NR,"Par�metro no reconocido");
define(LNG_ERR_FP,"Falta el par�metro");
define(LNG_ERR_SZ,"El color debe constar de 7 caracteres");
define(LNG_OTHER,"Otro");
define(LNG_SHW_TTL,"Estad�sticas");
define(LNG_SHW_GIN,"Informaci�n general");
define(LNG_SHW_VIS,"Visitas");
define(LNG_SHW_TTC,"Total de Clicks");
define(LNG_SHW_LST,"�ltimas 10 visitas");
define(LNG_SHW_MVP,"Media de Clicks por p�gina");
define(LNG_SHW_EXP,"Navegadores Web");
define(LNG_SHW_SOP,"Sistemas operativos");
define(LNG_SHW_IDI,"Pa�s de la visita");
define(LNG_SHW_IPS,"Visitas por IP");
define(LNG_SHW_ISP,"Visitas por ISP");
define(LNG_SHW_REF,"Referer");
define(LNG_SHW_NRF,"Desconocido");
define(LNG_SHW_RUT,"Rutas URL");
define(LNG_SHW_VPM,"Visitas por meses");
define(LNG_SHW_VPD,"Visitas por dias de la semana");
define(LNG_SHW_EPM,"Estad�sticas por meses");
define(LNG_SHW_EPD,"Estad�sticas por dias de la semana");
define(LNG_INS_CTN,"A continuaci�n pulse sobre continuar para instalar la tabla 'fsphpstats'");
define(LNG_SHW_NFO,"Estad�sticas generadas mediante");
define(LNG_INS_RMB,"Recuerda haber configurado BD_host, BD_user y BD_pass de configuracion.php");
define(LNG_INS_NEX,"Continuar");
define(LNG_INS_ITB,"Instalando tabla");
define(LNG_INS_FIE,"FsPhpStats Instalado con �xito");
define(LNG_INS_ERR_NPS,"No se ha podido conectar a la base de datos, revisa los par�metros de configuraci�n");
define(LNG_INS_ERR_NPC,"No se ha podido crear a la tabla, revisa los par�metros de configuraci�n o si ya existe");
##=======================
$LNG_dia[1] = "Lunes";
$LNG_dia[2] = "Martes";
$LNG_dia[3] = "Mi�rcoles";
$LNG_dia[4] = "Jueves";
$LNG_dia[5] = "Viernes";
$LNG_dia[6] = "S�bado";
$LNG_dia[7] = "Domingo";
##========================
$LNG_mes[1]  = "Enero";
$LNG_mes[2]  = "Febrero";
$LNG_mes[3]  = "Marzo";
$LNG_mes[4]  = "Abril";
$LNG_mes[5]  = "Mayo";
$LNG_mes[6]  = "Junio";
$LNG_mes[7]  = "Julio";
$LNG_mes[8]  = "Agosto";
$LNG_mes[9]  = "Septiembre";
$LNG_mes[10] = "Octubre";
$LNG_mes[11] = "Noviembre";
$LNG_mes[12] = "Diciembre";
?>
