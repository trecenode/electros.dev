<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

function ImageColorHex($im,$color)
{
	if(substr($color,0,1) != "#")
	{
		FsPhpStatsPrintErr(LNG_ERR_FP." '#'");
	}
	if(strlen($color) != 7)
	{
		FsPhpStatsPrintErr(LNG_ERR_SZ);
	}
	$P[0] = hexdec(substr($color,1,2));
	$P[1] = hexdec(substr($color,3,2));
	$P[2] = hexdec(substr($color,5,2));
	return ImageColorAllocate($im,$P[0],$P[1],$P[2]);
}
function ValueMasAlto($arr,$e)
{
	for($a = 1; $a <= $e; $a++)
	{
		if(!$ntot)
		{
			$ntot = $arr[$a];
		}
		else
		{
			if($arr[$a] > $ntot)
			{
				$ntot = $arr[$a];
			}
		}
	}
	return $ntot;
}
function GrafMeses($meses,$nombre,$ttl)
{
	global $cfg;
	$vma       = ValueMasAlto($meses,12);
	$vf        = round($vma/5,2);
	$im        = ImageCreate(450,220);
	$fondo     = ImageColorHex($im,$cfg["COL_fondo"]);
	$linea     = ImageColorHex($im,$cfg["COL_linea"]);
	$texto     = ImageColorHex($im,$cfg["COL_texto"]);
	$barra     = ImageColorHex($im,$cfg["COL_barra"]);
	$nfo       = ImageColorHex($im,"#ff0000");
	ImageFill($im,0,0,$fondo);
	ImageString($im,2,50,200,$ttl,$texto);
	ImageLine($im,50,20,50,170,$linea);
	ImageLine($im,50,170,400,170,$linea);
	for($a = 1; $a <= 12; $a++)
	{
		ImageString($im,2,37+$a*30,180,$a,$texto);
		ImageLine($im,40+$a*30,175,40+$a*30,170,$linea);
		ImageFilledRectangle($im,30+30*$a,170-150*($meses[$a]/$vma),50+30*$a,170,$barra);
		ImageRectangle($im,30+30*$a,170-150*($meses[$a]/$vma),50+30*$a,170,$linea);
	}
	for($a = 1; $a <= 5; $a++)
	{
		ImageString($im,2,1,165-30*$a,$vf*$a,$texto);
		ImageLine($im,50,170-30*$a,45,170-30*$a,$linea);
	}
	ImageString($im,2,335,200,"FsPhpStats ".FPS_VERSION,$nfo);
	return ImagePNG($im,dirname(__FILE__)."/temp/".$nombre.".png");
}
function GrafDias($dias,$nombre,$ttl)
{
	global $cfg,$LNG_dia;
	$vma       = ValueMasAlto($dias,7);
	$vf        = round($vma/5,2);
	$im        = ImageCreate(450,220);
	$fondo     = ImageColorHex($im,$cfg["COL_fondo"]);
	$linea     = ImageColorHex($im,$cfg["COL_linea"]);
	$texto     = ImageColorHex($im,$cfg["COL_texto"]);
	$barra     = ImageColorHex($im,$cfg["COL_barra"]);
	$nfo       = ImageColorHex($im,"#ff0000");
	ImageFill($im,0,0,$fondo);
	ImageString($im,2,50,200,$ttl,$texto);
	ImageLine($im,50,20,50,170,$linea);
	ImageLine($im,50,170,400,170,$linea);
	for($a = 1; $a <= 7; $a++)
	{
		ImageString($im,1,37+$a*50,180,$LNG_dia[$a],$texto);
		ImageLine($im,40+$a*50,175,40+$a*50,170,$linea);
		ImageFilledRectangle($im,30+50*$a,170-150*($dias[$a]/$vma),50+50*$a,170,$barra);
		ImageRectangle($im,30+50*$a,170-150*($dias[$a]/$vma),50+50*$a,170,$linea);
	}
	for($a = 1; $a <= 5; $a++)
	{
		ImageString($im,2,1,165-30*$a,$vf*$a,$texto);
		ImageLine($im,50,170-30*$a,45,170-30*$a,$linea);
	}
	ImageString($im,2,335,200,"FsPhpStats ".FPS_VERSION,$nfo);
	return ImagePNG($im,dirname(__FILE__)."/temp/".$nombre.".png");
}
function GrafSectores($array,$nombre,$ttl)
{
	$im = ImageCreate(450,220);
	global $cfg;
	$fondo     = ImageColorHex($im,$cfg["COL_fondo"]);
	$borde     = ImageColorHex($im,$cfg["COL_linea"]);
	$texto     = ImageColorHex($im,$cfg["COL_texto"]);
	$nfo       = ImageColorHex($im,"#ff0000");
	ImageFill($im,0,0,$fondo);
	$arc = 270; #�
	$a = 0;
	while (list($name, $porciento) = each ($array)) 
	{
		$color = ImageColorAllocate($im,rand(0,255),rand(0,255),rand(0,255));
		$nmr  = $porciento;
		$nmr  = $nmr / 100;
		$pct  = 360 * $nmr;
		$aa   = $arc + $pct;
		ImageFilledArc($im,100,100,170,170,$arc,$aa,$color,IMG_ARC_PIE);
		ImageFilledRectangle($im,220,40+20*$a,230,50+20*$a,$color);
		ImageRectangle($im,220,40+20*$a,230,50+20*$a,$borde);
		ImageString($im,2,240,40+20*$a,$name,$texto);
		$arc  = $aa;
		$a++;
	}
	if(ceil($arc) < 630)
	{
		$color = ImageColorAllocate($im,rand(0,255),rand(0,255),rand(0,255));
		ImageFilledArc($im,100,100,170,170,$arc,270+360,$color,IMG_ARC_PIE);
		ImageFilledRectangle($im,220,40+20*$a,230,50+20*$a,$color);
		ImageRectangle($im,220,40+20*$a,230,50+20*$a,$borde);
		ImageString($im,2,240,40+20*$a,LNG_OTHER,$texto);
	}
	ImageString($im,2,220,20,$ttl,$texto);
	ImageEllipse($im,100,100,170,170,$borde);
	ImageString($im,2,335,180,"FsPhpStats ".FPS_VERSION,$nfo);
	return ImagePNG($im,dirname(__FILE__)."/temp/".$nombre.".png");
}
?>