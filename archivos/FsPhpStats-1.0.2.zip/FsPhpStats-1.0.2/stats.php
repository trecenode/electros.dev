<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

include("FsPhpStats.php");
$dv = &new FpsData();
$dv -> conectar();

function ListTableArray($arr)
{
	global $cfg;
	while (list($ndc, $val) = each ($arr)) 
	{
        $ndc = SysTextLimit($cfg["txt_limit"],$ndc);
		$tot = $tot.'<tr bgcolor="#CCCCCC"><td width="50%" class="celdas_res">'.$ndc.'</td><td width="50%" class="celdas_res"><strong><font class="textoresalto">'.$val.'</font><strong></td></tr>';
	}
	return $tot;
}
function PzTableArray($arr)
{
    global $cfg;
	while (list($ndc, $val) = each ($arr)) 
	{
		$valr = explode("#",$val);
		$valr[0] = SysTextLimit($cfg["txt_limit"],$valr[0]);
		$tot  = $tot.'<tr bgcolor="#CCCCCC"><td width="50%" class="celdas_res">'.$valr[0].'</td><td width="50%" class="celdas_res"><strong><font class="textoresalto">'.$valr[1].'</font><strong></td></tr>';
	}
	return $tot;
}
# IMAGENES
GrafSectores($dv -> GetMostCampo("navegador","ARRAY",NULL,NULL,NULL),"navegadores",LNG_SHW_EXP);
GrafSectores($dv -> GetMostCampo("so","ARRAY",NULL,NULL,6),"so",LNG_SHW_SOP);
GrafSectores($dv -> GetMostCampo("pais","ARRAY",NULL,NULL,6),"pais",LNG_SHW_IDI);
GrafSectores($dv -> GetMostCampo("ip","ARRAY",NULL,NULL,6),"ip",LNG_SHW_IPS);
GrafSectores($dv -> GetMostCampo("isp","ARRAY",NULL,NULL,6),"isp",LNG_SHW_ISP);
GrafSectores($dv -> GetMostCampo("url","ARRAY",NULL,NULL,6),"url",LNG_SHW_RUT);
GrafSectores($dv -> GetMostCampo("ref","ARRAY",NULL,NULL,6),"ref",LNG_SHW_REF);
GrafMeses(   $dv -> GetOnlyValues("mes"),"MesesBars",LNG_SHW_EPM);
GrafDias(    $dv -> GetOnlyValues("dsemana"),"DiasBars",LNG_SHW_EPD);
?> 
<!--
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title><? echo LNG_SHW_TTL." - FsPHPStats"; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="FsPhpStats.estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2"  class="celdas_titulo"><? echo LNG_SHW_GIN; ?></td>
  </tr>
  <tr> 
    <td width="50%" class="celdas_res"><font color="#000000"><? echo LNG_SHW_VIS; ?></font></td>
    <td width="50%" class="celdas_res"><strong><font class="textoresalto"><? echo $dv -> GetVisitas(); ?></font></strong></td>
  </tr>
  <tr> 
    <td class="celdas_res"><font color="#000000"><? echo LNG_SHW_TTC; ?></font></td>
    <td class="celdas_res"><strong><font class="textoresalto"><? echo $dv -> GetTPV(NULL); ?></font></strong></td>
  </tr>
  <tr> 
    <td width="50%" height="23" class="celdas_res"><font color="#000000"><? echo LNG_SHW_MVP; ?></font></td>
    <td width="50%" class="celdas_res"><strong><font class="textoresalto"><? echo $dv -> GetMPV(); ?></font></strong></td>
  </tr>
</table><br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2"  class="celdas_titulo"><? echo LNG_SHW_LST; ?></td>
  </tr>
    <?
	echo PzTableArray($dv -> GetLastN(10,"ARRAY",NULL,"HTML",NULL));
	?>
</table>
<br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2"  class="celdas_titulo"><? echo LNG_SHW_EXP; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/navegadores.png"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("navegador","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table><br><table width="462" class="tabla">
  <tr class="celdas_titulo"> 
    <td colspan="2"><? echo LNG_SHW_SOP; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/so.png"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("so","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table><br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_IDI; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/pais.png"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("pais","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table>
<br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_IPS; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/ip.png" width="450" height="220"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("ip","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table>
<br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_ISP; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/isp.png"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("isp","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table><br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_RUT; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/url.png" width="450" height="220"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("url","ARRAY",NULL,NULL,$cfg["list_limit"]));
  ?> 
</table><br>
<table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_REF; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/ref.png" width="450" height="220"></font></td>
  </tr>
  <?
	echo ListTableArray($dv -> GetMostCampo("ref","ARRAY",NULL,NULL,$cfg["list_limit"]));
	?>
</table><br><table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_VPM; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/MesesBars.png" width="450" height="220"></font></td>
  </tr>
</table><br><table width="462" class="tabla">
  <tr> 
    <td colspan="2" class="celdas_titulo"><? echo LNG_SHW_VPD; ?></td>
  </tr>
  <tr> 
    <td height="23" colspan="2" class="celdas_img"><font color="#FFFFFF"><img src="temp/DiasBars.png" width="450" height="220"></font></td>
  </tr>
</table>
<br>
<table width="462" border="0">
  <tr> 
    <td width="80"><img src="imagenes/minilogo.jpg"></td>
    <td width="372"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo LNG_SHW_NFO; ?> 
      <a href="http://proyectos.funkybytes.com/fsphpstats" target="_blank">FsPHPStats</a></font></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
