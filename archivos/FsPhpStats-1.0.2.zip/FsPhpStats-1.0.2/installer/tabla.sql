CREATE TABLE fsphpstats (
  id int(255) NOT NULL auto_increment,
  url text NOT NULL,
  ref text NOT NULL,
  ip text NOT NULL,
  dia text NOT NULL,
  mes text NOT NULL,
  yr text NOT NULL,
  hora text NOT NULL,
  pagvis text NOT NULL,
  so text NOT NULL,
  navegador text NOT NULL,
  pais text NOT NULL,
  isp text NOT NULL,
  dsemana text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;