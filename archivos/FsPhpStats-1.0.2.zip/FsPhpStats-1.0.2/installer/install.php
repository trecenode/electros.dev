<?php
#================================================================#
# FsPHPStats :: Programa optimizado para php 4 y librerias GD2   #
#================================================================#
# Creado por: Jos� Fern�ndez Alameda (Funkyslim)                 #
# E-Mail de contacto: Funkyslim@funkybytes.com                   #
#================================================================#
# P�gina web: http://proyectos.funkybytes.com/fsphpstats         #
#========================= Licencia =============================#
# FsPHPStats est� distribuido bajo la licencia GNU/GPL y         #
# Creative commons, por lo que este puede ser modificado bajo la #
# propia responsabilidad de cada uno. En el caso de redistribuir #
# el proyecto se debe notificar al creador e indicar en el mismo #
# el autor original del mismo.                                   #
# Debido a ser gratuito, este no proporciona ninguna garant�a de #
# seguridad y/o funcionamiento.                                  #
#================================================================#
# Este script usa: PHP, MYSQL y la libreria GD                   #
# PHP:   http://www.php.net/                                     #
# MYSQL: http://www.mysql.com/                                   #
# GD:    http://www.boutell.com/gd/                              #
#================================================================#

session_start();
include("../FsPhpStats.defs.php");
include("../configuracion.php");
if($_GET['lng'] == "si" and $_POST['lngv'])
{
	$_SESSION['INST_LNG'] = $_POST['lngv'];
	header("Location: ?paso=1");
}
if($_SESSION['INST_LNG'])
{
	include("../idiomas/".$_SESSION['INST_LNG'].".php");
}
?>
<html>
<head>
<title>FsPHPStats Installer</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p><font size="+7">Fs<font color="#6699CC">PHP</font>Stats <? echo FPS_VERSION; ?></font><br>
  <font color="#FF0000" size="1">INSTALLER </font></p>
<? if(!$_GET['paso']): ?>
<form name="form1" method="post" action="?lng=si">
  <table width="297" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="160">Select your language </td>
      <td width="80"><select name="lngv">
          <?
		  $op = opendir("../idiomas");
		  while($id = readdir($op))
		  {
		  	 if($id != ".." and $id != ".")
			 {
			 	$idn = substr($id,0,strpos($id,"."));
				echo '<option value="'.$idn.'">'.$idn.'</option>';
			 }
		  }
		  ?>
        </select></td>
      <td width="57"><input type="submit" name="Submit" value="OK"></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<? endif;
if($_GET['paso'] == 1): ?>
<? echo LNG_INS_CTN; ?><br><font color="#FF0000"><? echo LNG_INS_RMB; ?></font><p>
<form action="?paso=2" method="post">
  <input type="submit" name="next" value="&gt;&gt; <? echo LNG_INS_NEX; ?> &gt;&gt;">
</form></p>
<p>&nbsp;</p>
<? endif;
if($_GET['paso'] == 2): ?>
<strong><? echo LNG_INS_ITB; ?>...</strong>
<?
chmod("tabla.sql",0777);
$op    = fopen("tabla.sql","r+");
$read  = fread($op,filesize("tabla.sql"));
@chmod("../temp",0777);
if(@mysql_connect($cfg["BD_host"],$cfg["BD_user"],$cfg["BD_pass"]))
{
	if(@mysql_db_query($cfg['BD_name'],$read))
	{
		echo '<script language="JavaScript"> window.location = "?paso=3"; </script>';
	}
	else
	{
		echo "<br><font color=red>".LNG_INS_ERR_NPC." : ".mysql_error()."</font>";
	}
}
else
{
	echo "<br><font color=red>".LNG_INS_ERR_NPS."</font>";
}
?>
<? endif;
if($_GET['paso'] == 3):?>
<strong><? echo LNG_INS_FIE; ?></strong>
<? endif; ?>
</body> 
</html>
