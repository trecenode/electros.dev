<?
$dbhost = "localhost" ;
$dbuser = "" ;
$dbpass = "" ;
$db = "xungo" ;
$conectar = mysql_connect($dbhost,$dbuser,$dbpass) ; mysql_select_db($db,$conectar) ;
?> 