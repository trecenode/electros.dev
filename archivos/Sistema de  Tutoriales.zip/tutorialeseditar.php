<?
include("estilo.php") ;
include("config.php") ;
if($enviar) {
function quitar($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitar($titulo) ;
$tutorial = quitar($tutorial) ;
$tutorialext = quitar($tutorialext) ;
mysql_query("update tutoriales set titulo='$titulo',tutorial='$tutorial',tutorialext='$tutorialext' where id='$tutorialid'") ;
echo "Tu tutorial ha sido editado con �xito. Haz click <a href='etutoriales.php?n=$tutorialid' >aqu�</a> para regresar al tutorial." ;
}
$resp = mysql_query("select titulo,tutorial,tutorialext from tutoriales where id=$tutorialid") ;
while($datos = mysql_fetch_array($resp)) {
echo "
 <form name='formulario' method='post' action='etutorialeseditar.php?tutorialid=$tutorialid'>
  <b>Titulo:</b><br>
<input type='text' name='titulo' size='40' maxlength='100' value='$datos[titulo]'class='form'><br>
  <b>Descripcion:</b><br>
  <input name='tutorial' type='text' class='form' value='$datos[tutorial]' size='50'>
  <br>
  <b>Tutorial:</b><br>
  <textarea name='tutorialext' cols='50' rows='10' class='form'>$datos[tutorialext]</textarea>
  <br>
  <br>
<input type='submit' name='enviar' value='Editar tutorial' class='form'>
</form>
" ;
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>


