CREATE TABLE tutoriales (
  id tinyint(3) unsigned NOT NULL auto_increment,
  fecha int(10) unsigned NOT NULL default '0',
  usuario varchar(20) NOT NULL default '',
  titulo varchar(100) NOT NULL default '',
  tutorial text NOT NULL,
  tutorialext text NOT NULL,
  PRIMARY KEY  (id)
);

CREATE TABLE tutorialescom (
  id smallint(5) unsigned NOT NULL auto_increment,
  tutorial tinyint(3) unsigned NOT NULL default '0',
  fecha int(10) unsigned NOT NULL default '0',
  usuario varchar(20) NOT NULL default '',
  comentario tinytext NOT NULL,
  PRIMARY KEY  (id),
  KEY tutorial (tutorial)
) 