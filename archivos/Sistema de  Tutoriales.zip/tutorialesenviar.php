<?
include("estilo.php") ;
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = quitar($usuario) ;
$titulo= quitar($titulo) ;
$tutorial= quitar($tutorial) ;
$tutorialext= quitar($tutorialext) ;
$eid= quitar($eid) ;
mysql_query("insert INTO tutoriales (eid,fecha,usuario,titulo,tutorial,tutorialext) values ('$eid','$fecha','$usuario','$titulo','$tutorial','$tutorialext')") ;
echo "La tutorial ha sido enviada con �xito. <a href=etutoriales.php>volver</a>" ;
mysql_close($conectar) ;
}
?>
<form method="post" name="formulario" action="tutorialesenviar.php">
Usuario:<br>
<input type="text" name="usuario" maxlength="20" class="form">
  <br>
  Secci&oacute;n:<br>
  <select name="eid" id="eid">
    <option value="1">php</option>
    <option value="2">sql</option>
    <option value="3">otra cosa</option>
    <option value="0" selected>[escoje]</option>
  </select>
  <br>
T�tulo:<br>
<input type="text" name="titulo" maxlength="100" class="form"><br>
  Breve descripcion del tutorial:<br>
  <textarea name="tutorial" cols="35" rows="3" class="form"></textarea>
  <br>
  <script language="Javascript">
<!--
function grabar(graba) { 
var inserta=document.formulario.elements["tutorialext"]; 
inserta.value=inserta.value+graba+' '; 
document.formulario.tutorialext.focus(); 

}
// -->
</script>
  Tutorial :<br>
  <br>
  <b><a href="javascript:grabar('[b][/b]');">Negrita</a></b> - letra en negrita.<br>
  <b><a href="javascript:grabar('[img]http://..[/img]');">Imagen</a></b> - insertar 
  una imagen.<br>
  <b><a href="javascript:grabar('[codigo][/codigo]');">Codigo</a></b> - insertar 
  un codigo php.<br>
  <br>
  <textarea name="tutorialext" cols="40" rows="15" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>