<?
// Incluimos archivo de configuracion
@include("configuracion.php");
if (!$n) {
?>
<?
// Funcion para borrar los directorios
function deldir($dir)
{
  $handle = opendir($dir);
  while (false!==($FolderOrFile = readdir($handle)))
  {
     if($FolderOrFile != "." && $FolderOrFile != "..")
     {
     } 
  }
  closedir($handle);
  if(rmdir($dir))
  { $success = true; }
  return $success; 
} 

if($borrar) {
$_GET["borrar"];
@include("noticias/$borrar.php");
// si el usuario borra un mensaje
if ($_COOKIE[ucnnick] == $nick_noticia or $_COOKIE[ucnnick] == $administador) {
@unlink("noticias/$borrar.php") ;
for($bn=0;$bn<1000;$bn++){
@unlink("noticias/$borrar/contador.txt") ;
@unlink("noticias/$borrar/$bn.php") ;
}
deldir("noticias/$borrar");
echo "<p>La noticia <b>$titulo_noticia</b> ha sido borrada con �xito. Haz click <a href=index.php?id=noticias>aqu�</a> para regresar.<br><br>" ;
}
}
?>
<?php
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "noticias/";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20;             // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['20 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
  $Counter++;
  
  $elemento1 = strtolower($elemento);
  
  if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".php","",$elemento);
?>
<?
if(file_exists("noticias/$elemento2.php")) {
require ("noticias/$elemento2.php");
// Dia en el que se envio la noticia corta
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha_noticia) ; $diames = date(j,$fecha_noticia) ; $mesano = date(n,$fecha_noticia) - 1 ; $ano = date(Y,$fecha_noticia) ;
$fecha_noticia = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
// Espacios en la noticia corta
$noticia_contenido = str_replace("\r\n","<br>",$noticia_contenido) ;
// Acortamos la noticia, por eso se llama noticia corta
if (strlen($noticia_contenido) > 255) { 
$noticia_contenido = substr($noticia_contenido,0,255).".."; }
}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="5" style='border: #757575 1 solid'>
 <tr> 
    <td class="tabla_titulo">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div class="t1"><? echo $titulo_noticia ?></div></td>
            <td><div align="right"><? echo $fecha_noticia ?></div></td>
          </tr>
        </table>
      </td>
  </tr>
  <tr> 
    <td height="28" class="tabla_mensaje"><table width="100%" border="0" cellspacing="0" cellpadding="4">
        <tr> 
          <td colspan="3"><? echo $noticia_contenido ?></td>
        </tr>
        <tr> 
          <td width="40%"><a href="index.php?id=noticias&n=<? echo $elemento2 ?>">Ver 
            comentarios</a> 
            <? if ($_COOKIE[ucnnick] == $nick_noticia or $_COOKIE[ucnnick] == $administador) { echo "| [<a href='index.php?id=noticias&borrar=$secciones$elemento2'>borrar</a>]"; } ?>
          </td>
          <td width="40%"><strong>Comentarios :
<?
if(file_exists("noticias/$elemento2/")) {
// Usuarios en linea
$path2 = "noticias/$elemento2/"; 
// Contar el total
$dir2 = opendir($path2);
$i = 0;
while ($elemento = readdir($dir2))
{
$elemento3 = strtolower($elemento);
if (strpos($elemento3, ".php") > 0) {
$i++;
}
}
echo $i ;
closedir($dir2);
}
else {
echo "0";
}
?>
            </strong></td>
          <td width="20%"><div align="right"><b>Enviada por: </b><? echo $nick_noticia ?> 
            </div></td>
        </tr>
      </table> </td>
  </tr>
</table>
  
<br>
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['20 Siguientes'] = 1;
}

//Cerramos el directorio
@closedir($dir);
?>
<div align="right"> 
  <?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?id=noticias&c=".($Plus-$Config['Show'])."\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=noticias&c=".($Plus+$Config['Show'])."\">20 Siguientes</a></p>");
}
?>
</div>
<? if ($n) {
if(file_exists("noticias/$n.php")) {
require ("noticias/$n.php");
}
// Dia en el que se envio la noticia extendida
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha_noticia) ; $diames = date(j,$fecha_noticia) ; $mesano = date(n,$fecha_noticia) - 1 ; $ano = date(Y,$fecha_noticia) ;
$fecha_noticia = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
// Ponemos los espacios en la noticia extendida
$noticia_contenido = str_replace("\r\n","<br>",$noticia_contenido) ;
// Si en la noticia extendida hay una direccion ftp o http la interpretamos para que pueda ser visitada
$noticia_contenido = preg_replace("/(?<!')(?<!<a href=\")(?<!<img src=\")(http|ftp)(s)?:\/\/[^,<\'\"\s]+/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$noticia_contenido) ;
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr>
<td class="tabla_titulo"><p class=t1><? echo $titulo_noticia ?></p></td>
<td class="tabla_titulo"><div align=right><? echo $fecha_noticia ?></div></td>
</tr>
<tr>
    <td colspan=2 class="tabla_mensaje"> <? echo $noticia_contenido ?><br>
      <br>
<hr>
<b>Enviada por:</b> <? echo $nick_noticia ?><br>
<a href="index.php?id=noticias">� Regresar a la p�gina principal</a>
<p>

      <p><b>Total de comentarios:</b> 
<?
if(file_exists("noticias/$n/")) {
// Usuarios en linea
$path2 = "noticias/$n/"; 
// Contar el total
$dir2 = opendir($path2);
$i = 0;
while ($elemento = readdir($dir2))
{
$elemento2 = strtolower($elemento);
if (strpos($elemento2, ".php") > 0) {
include("noticias/$n/$elemento2");
$i++;
}
}
echo $i ;
closedir($dir2);
}
else {
echo "0" ;
}
?>
<br>
<br>
<?php
if(file_exists("noticias/$n/")) {
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "noticias/$n/";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 5;             // Numero de archivos a mostrar por p�ginas.

$Show['5 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['5 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['5 Anteriores'] = 1;
$c--;
}
$Counter = 0; // Ponemos a 0 el contador
// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['5 Anteriores'] == 0) $Counter=$Counter-2; else {
$c = 2;
while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['5 Anteriores'] = 1;
$c--;
}
}
// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
$Counter++;
$elemento1 = strtolower($elemento); 
if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
include("noticias/$n/$elemento1");
// Asignamos el archivo sin extension
$elemento2 = str_replace(".php","",$elemento);
// fecha
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha_noticiacom) ; $mesano = date(n,$fecha_noticiacom) - 1 ; $ano = date(Y,$fecha_noticiacom) ; $hora = date("h:i A",$fecha_noticiacom) ;
$fecha_noticiacom = "$diames $mesesano[$mesano] $ano $hora" ;
// Espacios correspondientes en comentarios
$comentario = str_replace("\r\n","<br>",$comentario) 
?> 
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
        <tr> 
          <td  class="tabla_subtitulo"><b>&lt;<? echo $nick_noticiacom ?>&gt;</b></td>
          <td  class="tabla_subtitulo"><div align=right><b><? echo $fecha_noticiacom ?></b></div></td>
        </tr>
        <tr> 
          <td height="4" colspan=2 class="tabla_mensaje"> <? echo $comentario_noticiacom ?> 
          </td>
        </tr>
</table>
      <br>
      <?
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['5 Siguientes'] = 1;
}
//Cerramos el directorio
@closedir($dir);
?>
      <div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['5 Anteriores'] == 1) echo("<a href=\"index.php?id=noticias&c=".($Plus-$Config['Show'])."&n=$n\">5 Anteriores | </a>");
if ($Show['5 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=noticias&c=".($Plus+$Config['Show'])."&n=$n\">5 Siguientes</a></p>");
}
?>
</div>

<p><br>
<?
if($enviar){
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
$texto = stripslashes($texto) ;
return $texto ;
}
// distinge entre nick registrado y nick anonimo
if ($_COOKIE[ucnnick]) {
$cnnick = $_COOKIE[ucnnick];
}
else {
$cnnick = "No Registrad@";
}

$cnfechacom = time() ;
$cncomentario = quitar($cncomentario) ;

$nuevo .= "<"."?\n";
$nuevo .="\$nick_noticiacom = \"$cnnick\";\n";
$nuevo .="\$fecha_noticiacom = \"$cnfechacom\";\n";
$nuevo .="\$noticiacom = \"$cnnoticia\";\n";
$nuevo .="\$comentario_noticiacom = \"$cncomentario\";\n";
$nuevo .= "?".">";

// a�adimos la nueva noticia a contador.txt
if(!file_exists("noticias/$n/")) { mkdir("noticias/$n/", 0777); }
if(!file_exists("noticias/$n/contador.txt")) { $ncrea = fopen("noticias/$n/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "noticias/$n/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

$new = fopen("noticias/$n/$clicks.php","w");
fputs($new,$nuevo);
fclose($new);

echo "<script>location='index.php?id=noticias&n=$n'</script>";
}
?>
        <br>
        <b>Escribir comentario</b> 
      <form method=post action="index.php?id=noticias&n=<? echo $n?>">
<input type="hidden" name="cnnoticia" value="<? echo $n ?>" >
Comentario:<br>
<textarea name="cncomentario" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
</td>
</tr>
</table>
<?
}
?>
