<div class="t1">Enlaces</div>
<br>
<br>
<div align="center">
<!-- inicio categorias -->
  <table width='50%' border='0' cellpadding='0' cellspacing='0' align='center' >
<?
// Incluimos archivo de configuracion
@include("configuracion.php");
// configuramos el directorio que queremos listar:
if(!file_exists("enlaces/")) { mkdir("enlaces/", 0777); }
if($secciones != "") { $sec = "<a  href='javascript:history.go(-1);'>- Anterior</a>" ; }
if($secciones == "") { $web = "enlaces/" ; }
if($secciones != "") { $web = "enlaces/$secciones" ; }
$dir = opendir("$web") ;
$parimpar = 0 ;
echo "<table width=50%  border=0 cellspacing=0 cellpadding=0><tr><td>$sec</td></tr></table>";
echo "<table width=50%  border=0 cellspacing=0 cellpadding=0>" ;
while ($file = readdir($dir)) {
$parimpar++ ;
// evitamos q muestre los puntos de volver al directorio superior
if(eregi("config.php", $file)){
echo "<script>location.href='index.php?id=enlaces'</script>";
}

if(strpos($file, ".") < 1&& $file != "." && $file != ".."&& $file != "error_log") {
// Contar el total
$dir2 = opendir("enlaces/".$secciones.$file);

        $i = 0;

        while ($elemento = readdir($dir2))
        {
            $elemento = strtolower($elemento);

            if ((strpos($elemento, ".php") > 0) && $elemento != "index.php")

            $i++;
        }
//mostramos columnas
   if($parimpar % 2 == 1) { echo "<tr>
<td height='30%'><div align='left'>�
<a  href='index.php?id=enlaces&secciones=$secciones$file/'>$file</a> ($i) </div>
" ; }
   if($parimpar % 2 == 0) { echo "
<td height='30%'><div align='left'>�
<a  href='index.php?id=enlaces&secciones=$secciones$file/'>$file</a> ($i) </div>
</tr>" ; }
} }

// si el numero de archivos es impar a�adimos esta columna para no descudrar la tabla
if($parimpar % 2 == 1) { echo "<td>&nbsp;</td></tr>" ; }

closedir($dir);
?>  
</table>
<!-- fin categorias --><br>
<br>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td><div align="center"> 
          <form name="enlaces" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
            <input name="campo" type="text" id="campo" class="form">
            <input name="buscar" type="submit" id="buscar" value="Buscar" class="form">
          </form>
        </div></td>
    </tr>
    <tr> 
      <td><div align="center"> 
          <table width="50%" border="0" cellspacing="0" cellpadding="0">
            <tr> 
              <td><div align="left"> 
                  <?
if($buscar){
// Incluimos todos los enlaces
if($campo != ""){
echo "<center>Resultados de la busqueda :</center><br>";
}
// Tomamos el total de enlaces
$archi = "enlaces/contador.txt";
$abrir = fopen($archi,"r");
$total_enlaces = fread($abrir, filesize($archi));
fclose($abrir);
// Recogemos la informacion de cada archivo
for($bn=0;$bn<$total_enlaces;$bn++){
if(file_exists("enlaces/$secciones$bn.php")) {
include("enlaces/$secciones$bn.php");
// Comprobamos que la palabra coincide
if($campo != ""){
if(eregi("$campo", $titulo_enlace)){
echo "<a href='enlaces.php?e=$secciones$bn'><li> $titulo_enlace</a></li>";
}
}
}
}
}
?>
                </div></td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
  <br>
</div>
<b>Categor�a:</b> 
<? if($secciones != "./") { ?>
<?
// Nombre del archivo
if($secciones != "") {
$secciones2 = str_replace("/"," > ",$secciones);
echo "$secciones2";
}
else
{
echo "Principal";
}
?>
<? } else {echo "principal";}?>
<br>
<br>
<?
// Visitar en enlace
if ($e && file_exists("enlaces/$e.php")) {
include ("enlaces/$e.php");

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($nick_enlace);
$cnfecha = quitar($fecha_enlace) ;
$cntitulo = quitar($titulo_enlace) ;
$cndescripcion = quitar($descripcion_enlace) ;
$cnhits = 1 + $hits_enlace ;
$cnurl = quitar($url_enlace) ;
$imagen = quitar($imagen_enlace) ;

$edita .= "<"."?\n";
$edita .="\$nick_enlace = \"$cnnick\";\n";
$edita .="\$fecha_enlace = \"$cnfecha\";\n";
$edita .="\$titulo_enlace = \"$cntitulo\";\n";
$edita .="\$descripcion_enlace = \"$cndescripcion\";\n";
$edita .="\$url_enlace = \"$cnurl\";\n";
$edita .="\$hits_enlace = \"$cnhits\";\n";
$edita .="\$imagen_enlace = \"$imagen\";\n";
$edita .= "?".">";

$edit = fopen("enlaces/$e.php","w");
fputs($edit,$edita);
fclose($edit);


echo "<script>location='$cnurl'</script>";
}
?>
<?
// Borrar un enlace
if($borrar && file_exists("enlaces/$borrar.php")) {
$_GET["borrar"];
@include("enlaces/$borrar.php");
// si el usuario borra un mensaje
if ($nick_enlace == $_COOKIE[ucnnick] or $_COOKIE[ucnnick] == $administador) {
@unlink("enlaces/$borrar.php") ;
echo "<p>El enlace ha sido borrado con �xito. Haz click <a href=index.php?id=enlaces>aqu�</a> para regresar.<br>" ;
}
}
?>
<?php
  
if($secciones == "") { $web = "enlaces/" ; }
if($secciones != "") { $web = "enlaces/$secciones" ; }

                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "$web";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20;             // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['20 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
  $Counter++;
  
  $elemento1 = strtolower($elemento);
  
  if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".php","",$elemento);
?>
<?
if(file_exists("enlaces/$secciones$elemento2.php")) {
require ("enlaces/$secciones$elemento2.php");
   // Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha_enlace = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
$descripcion_enlace = str_replace("\r\n","<br>",$descripcion_enlace) ;
}
?>
<a name="<? echo $titulo_enlace ?>"></a><br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="3" class="tabla_mensaje"><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
		<? if($imagen_enlace) { if($imagen_enlace != "") { echo "<td width='8%' rowspan='3'><table width='1' border='0' cellpadding='0' cellspacing='1' bordercolor='#000000' bgcolor='#000000'>
        <tr><td><img src='$imagen_enlace' width='80' height='80' border='0' onerror=this.onerror='null';this.src='fondo_titulo.gif'></td></td></tr>
        </table>"; }} ?>
          <td width="92%" valign="baseline"><a href="enlaces.php?e=<? echo $secciones ?><?php echo $elemento2 ?>" target="_blank">� 
            <? echo $titulo_enlace ?></a></td>
        </tr>
        <tr> 
          <td valign="top"><? echo $descripcion_enlace ?></td>
        </tr>
        <tr> 
          <td><b>Visitas: </b><? echo $hits_enlace ?> 
            <? if ($_COOKIE[ucnnick] == $nick_enlace or $_COOKIE[ucnnick] == $administador) { echo "| <a href='index.php?id=enlaces&borrar=$secciones$elemento2&secciones=$secciones'>Borrar</a> | <a href='index.php?id=enlaceseditar&e=$secciones$elemento2&secciones=$secciones'>Editar</a>"; } ?>
          </td>
        </tr>
      </table></td>
  </tr>
</table>
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['20 Siguientes'] = 1;
}

//Cerramos el directorio
@closedir($dir);
?>
<div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?id=enlaces&c=".($Plus-$Config['Show'])."&secciones=$secciones\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=enlaces&c=".($Plus+$Config['Show'])."&secciones=$secciones\">20 Siguientes</a></p>");
?></div>
