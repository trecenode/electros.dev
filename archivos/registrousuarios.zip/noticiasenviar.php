<?
include("login.php") ;
?>
<?
if($enviar) {

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
$texto = stripslashes($texto) ;
return $texto ;
}
$cnnick = $_COOKIE[ucnnick];
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cnnoticia = quitar($cnnoticia) ;

$edita .= "<"."?\n";
$edita .="\$nick_noticia = \"$cnnick\";\n";
$edita .="\$fecha_noticia = \"$cnfecha\";\n";
$edita .="\$titulo_noticia = \"$cntitulo\";\n";
$edita .="\$noticia_contenido = \"$cnnoticia\";\n";
$edita .= "?".">";

// a�adimos la nueva noticia a contador.txt
if(!file_exists("noticias/contador.txt")) { $ncrea = fopen("noticias/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "noticias/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

$edit = fopen("noticias/$clicks.php","w");
fputs($edit,$edita);
fclose($edit);
echo "Tu noticia ha sido enviada con exito. Haz click <a href=index.php?id=noticias>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
?>
<p class="t1">Enviar noticias
<p> 
<script>
function revisar() {
if(formulario.cnnoticia.value.length == 0) { alert('Debes poner un titulo a la noticia.') ; return false ; }
if(formulario.cnnoticiaext.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=noticiasenviar" onsubmit="return revisar()">
  <b>Titulo :</b><br>
<input name="cntitulo" type="text" class="form" id="cntitulo" maxlength="40">
  <br>
  <b>Noticia:</b><br>
  <textarea name="cnnoticia" cols="30" rows="5" class="form" id="cnnoticia"></textarea>
  <br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>