<?
include("login.php") ;
?>
<?
if($editar) {

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($cnnick) ;
// contrasena
if($cncontrasena == "") { $cncontrasena = quitar($contrasena) ; } else { $cncontrasena = md5($cncontrasena); }
$cnemail = quitar($cnemail) ;
$cnfecha = quitar($fecha) ;
$cnip = $REMOTE_ADDR ;
$cnpais = quitar($cnpais) ;
$cnedad = quitar($cnedad) ;
$cndescripcion = quitar($cndescripcion) ;

$edita .= "<"."?\n";
$edita .="\$nick = \"$cnnick\";\n";
$edita .="\$contrasena = \"$cncontrasena\";\n";
$edita .="\$email = \"$cnemail\";\n";
$edita .="\$fecha = \"$cnfecha\";\n";
$edita .="\$ip = \"$cnip\";\n";
$edita .="\$sexo = \"$cnsexo\";\n";
$edita .="\$pais = \"$cnpais\";\n";
$edita .="\$edad = \"$cnedad\";\n";
$edita .="\$descripcion = \"$cndescripcion\";\n";
$edita .= "?".">";

$edit = fopen("usuarios/$cnnick.php","w");
fputs($edit,$edita);
fclose($edit);
echo "Tus datos han sido editados con �xito. Haz click <a href=index.php?id=usuarios>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
// Si no se pone la edad esta se guarda como cero, para evitar mostrar el cero se hace lo siguiente
if($edad == 0) { $edad = "" ; }
// El sexo se guarda como 0 y 1 que es masculino y femenino respectivamente, si se elige femenino la opci�n debe aparecer seleccionada
// aparecer seleccionada
if($sexo == 1) { $sexo = " selected" ; }
// Mostrar la fecha en texto
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
?>
<p class="t1">Perfil
</p><b>Usuario desde el:</b> <? echo $fecha ?>
<p>En esta secci�n puedes editar tus datos de registro. Los campos con un asterisco (*) son obligatorios.
<script>
function revisar() {
if(formulario.cnemail.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=perfil" onsubmit="return revisar()">
<b>* Nick:</b><br>
<input type="text" name="cnnick" value="<? echo $nick ?>" class="form" style="color: #757575" readonly><br>
  <b>* Nueva Contrase�a:</b><br>
<input type="password" name="cncontrasena" maxlength="20" class="form"><br>
<b>* Email:</b><br>
<input type="text" name="cnemail" maxlength="40" value="<? echo $email ?>" class="form"><br>
<b>Pa�s:</b><br>
<input type="text" name="cnpais" maxlength="20" value="<? echo $pais ?>" class="form"><br>
<b>Edad:</b><br>
<input type="text" name="cnedad" maxlength="2" size="3" value="<? echo $edad ?>" class="form"><br>
<b>Sexo:</b><br>
<select name="cnsexo" class="form">
<option value="0">Masculino
<option value="1"<? echo $sexo ?>>Femenino
</select><br>
<b>Descripci�n:</b><br>
<textarea name="cndescripcion" cols="30" rows="5" class="form"><? echo $descripcion ?></textarea><br><br>
<input type="submit" name="editar" value="Editar" class="form">
</form>