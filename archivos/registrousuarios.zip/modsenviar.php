<?
include("login.php") ;
?>
<?
if($enviar) {

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = $_COOKIE[ucnnick];
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cndescmod = quitar($cndescmod) ;

$edita .= "<"."?\n";
$edita .="\$autor_mod = \"$cnnick\";\n";
$edita .="\$fecha_mod = \"$cnfecha\";\n";
$edita .="\$titulo_mod = \"$cntitulo\";\n";
$edita .="\$desc_mod = \"$cndescmod\";\n";
$edita .= "?".">";

// a�adimos la nueva mod a contador.txt
if(!file_exists("mods")) { mkdir("mods", 0777); }
if(!file_exists("mods/contador.txt")) { $ncrea = fopen("mods/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "mods/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);


$edit = fopen("mods/$clicks.php","w");
fputs($edit,$edita);
fclose($edit);

if(!file_exists("mods/$clicks.txt")) { 
$cnmod = htmlspecialchars(stripslashes(trim($_POST["cnmod"])));
$screa = fopen("mods/$clicks.txt","w"); 
fwrite($screa, $cnmod); 
fclose($screa); 
}

if($cnarchivo != "") {
move_uploaded_file($cnarchivo,"mods/$clicks.zip");
@copy($cnarchivo,"mods/$clicks.zip");
}


echo "Tu mod ha sido enviado con exito. Haz click <a href=index.php?id=mods>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
?>
<p class="t1">Enviar mods
<p> 
<script>
function revisar() {
if(formulario.cnmod.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.cnmodext.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=modsenviar" onsubmit="return revisar()" enctype="multipart/form-data">
  <b>Titulo :</b><br>
<input name="cntitulo" type="text" class="form" id="cntitulo" maxlength="60">
  <br>
  <strong>Breve descripcion del mod :</strong><br>
  <textarea name="cndescmod" cols="30" rows="4" class="form" id="cndescmod"></textarea>
  <br>
  <b>Mod :</b><br>
  [codigo]Codigo php[/codigo] <br>
  [b]Negrita[/b] <br>
  <br>
  <textarea name="cnmod" cols="30" rows="10" class="form" id="cnmod"></textarea>
  <br>
  <b>Archivo :</b><br>
  <input name="cnarchivo" type="file" class="form" id="cnarchivo" size="30">
  <br>
  <br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>