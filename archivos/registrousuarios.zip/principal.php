<p><strong>Acerca del registro de usuarios sin mysql :<br>
  <br>
  </strong>Registro de usuarios sin mysql echo por elcidop o phpmysql basandose 
  en varios<br>
  registro de usuarios con mysql y en otros registros sin mysql.<br>
  <br>
  Caracteristicas del script :<br>
  - Es seguro ya que en lugar de guardar la informacion en archivos de texto como 
  cualquier<br>
  otro registro de usuarios, la guarda en archivos php con variables definidas.<br>
  - Los usuarios se guardan en la carpeta usuarios/ y ademas las contrase&ntilde;as 
  se encriptan en md5, el unico defecto<br>
  es que en lo de olvide contrase&ntilde;a te envia la pass codificada en md5 
  no se lo he podido cambiar.<br>
  - Hay que definir las secciones (podemos poner hasta un limte de 4 secciones 
  )<br>
  en las que queremos que se guarden los enlaces y descargar ,auque tambien creando 
  las carpetas manualmente podemos crear un numero ilimitado de secciones (carpetas) 
  y subsecciones (subcarpetas) .<br>
  - Los mods sirve como tutoriales o para que colaboreis con esta web y su script 
  enviando vuestras propias<br>
  mejoras del script o novedades que querais incluirles.<br>
  - Los mensajes y noticias tienen una id predeterminada en contador.txt por ello 
  cuando borres una noticia<br>
  o agreges un mensaje se guardara la id del contador +1<br>
  - Los enlaces, mensajes, noticias pueden ser borrados y editados por los usuarios 
  que los envian desde la pagina<br>
  correspondiente a la seccion (aparecera un enlace que ponga borrar al lado de 
  cada enlace, si tu eres<br>
  el autor del enlace).<br>
  - He incorporado un buscador de enlaces, mods y descargas; el de mods<br>
  busca en todos los mods y el de enlaces e/y descargas busca dentro de los enlaces 
  en la seccion<br>
  en la que nos encontremos.<br>
  - Online.php: es un contador que cuenta el numero de usuarios de forma muy precisa 
  ha sido incluido por eso. he puesto<br>
  un sistema para ver los usuarios totales online y los registrados ademas tiene 
  el numero de total anonimos y registrados.<br>
  Recomiendo cambiar en ese archivo la siguiente linea $dataFile = &quot;online.txt&quot;; 
  por otro archivo txt para mayor seguridad de ti y de tus usuarios, recuerda 
  tambien dar chmod 777 al fichero.<br>
  - Sistema de longeo en la pagina actual : significa que cuando entremos como 
  usuario entraremos registrado en la pagina <br>
  en la que nos encontrabamos y no que no nos dirigeremos al index.php como sucedia 
  antes.<br>
  - Se a incluido un foro que era lo que faltaba desde hace tiempo, un sistema 
  para ver los usuarios enlinea usuariosonline.php<br>
  - Se a incluido el archivo configuracion.php para poder establecer un administrador 
  del espacio web, el usuario administrador por defecto es admin, los archivos 
  modificados han sido enlaces,descargas,mods,noticias,enlaceseditar,descarseditar,modseditar,noticiaseditar 
  asi podremos administrar el resto de seccion con nuestro propio usuario<br>
  <strong><br>
  Intalacion del registro de usuarios sin mysql :</strong><br>
  <br>
  El registro de usuarios creara las carpetas y datos de forma automatica.<br>
  si no es asin se debera proceder a dar chmod 777 a la carpeta donde se encuentra<br>
  el script y se deberan crear las siguientes carpetas dentro del susodicho directorio 
  :<br>
  <br>
  <a href="usuarios/" target="_blank">usuarios/</a><br>
  <a href="mensajes/" target="_blank">mensajes/</a><br>
  <a href="noticias/" target="_blank">noticias/</a><br>
  <a href="enlaces/" target="_blank">enlaces/</a><br>
  <a href="descargas/" target="_blank">descargas/ </a><br>
  <a href="mods/" target="_blank">mods/<br>
  </a><a href="foro/" target="_blank">foro/</a><br>
  <br>
  Registro de usuarios realizado por phpmysql basandose en registros de usuarios<br>
  con mysql.<br>
  <br>
  [<a href="registrousuarios.zip">Descargar registro de usuarios</a>]</p>
