<?
if($confirmacion) {
if($confirmacion == "si") {
echo "
<p>Se te ha enviado un email con tus datos de registro.
" ;
}
if($confirmacion == "no") {
echo "
<p>No existe ning�n usuario con este nick. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.
" ;
}
if($confirmacion == "esperar") {
echo "
<p>Por seguridad s�lo puedes pedir tus datos una vez cada 30 minutos.
" ;
}
}
else {
?>
<p>Para recuperar tus datos debes tu usuario con el que te registraste en la web.
<form method="post" action="contrasenaenviar.php">
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="cnnick" maxlength="40" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
?> 