<strong><font size="4">Foro</font></strong><br>
<br>
<?
if(!file_exists("foro/$archivo.dat")) { die("Este tema ya no existe o a sido cambiado de sitio, <a href=javascript:history.back()>volver</a> ");}
// Obtenermos el archivo
$file = "foro/$archivo.dat"; 
// Sumamos hits
if(!$enviar){
if(!file_exists("foro/$archivo.txt")){  
$fichero = fopen("foro/$archivo.txt","w"); 
fputs($fichero,"0"); 
fclose($fichero); 
}
if(file_exists("foro/$archivo.txt")){ 
$fp=fopen("foro/$archivo.txt","r");
$numero=fread($fp,filesize("foro/$archivo.txt"));
$clicks=1+$numero;
$fichero = fopen ("foro/$archivo.txt", "w");
fputs ($fichero,$clicks);
fclose ($fichero);
}
}
// Obtenemos el total de hits
if(file_exists("foro/$archivo.txt")){ 
$archi = "foro/$archivo.txt";
$abrir = fopen($archi,"r");
$hits = fread($abrir, filesize($archi));
fclose($abrir);
}
else {
$hits = "0";
}
# Datos de la ultima columna del archivo
$abrir = fopen($file,"r");
$contenido = fread($abrir, filesize($file));
fclose($abrir);
$contenido_archivo = split("\r\n",$contenido);
$contenidoarchivo = split("\|",$contenido_archivo[0]);
$contenidoarchivo[1] = str_replace("/&/", "|", $contenidoarchivo[1]);
//Se tramita el formulario y se guardan los nuevos datos.
if(!empty($opinion))
{
// bbcode para mayor seguridad
$nick = htmlspecialchars(trim($_POST['nick']));
$opinion = htmlspecialchars(stripslashes(trim($_POST["opinion"])));
$opinion = str_replace("\r\n", "<br>", $opinion);
$fecha = time();
// cambiamos | por ! en opinion
if($nick == "") { die("Pon un subtema, <a href=javascript:history.back()>volver</a> ");}
if(ereg($contenidoarchivo[0],$nick)){ die("Pon un subtema distinto del tema, <a href=javascript:history.back()>volver</a> ");}
if($opinion == "") { die("Pon el comentario del subtema, <a href=javascript:history.back()>volver</a> ");}
$opinion = str_replace("|", "/&/", $opinion);
$nick = str_replace("|", "/&/", $nick);
// creamos el fichero
$fichero = fopen($file, "a");
fwrite($fichero, "$nick|$opinion|$fecha|$tema\r\n");
fclose($fichero);
echo "Subtema creado, <a href='$_SERVER[REQUEST_URI]'>pulsa aqui</a><br>";
}
# Numero de registros que se mostraran por p�gina.
$limiteRegistros = 50;
# Ubicaci�n del fichero de texto.
$ficheroTexto = $file ;
# Leemos el contenido del fichero.
$fd = @fopen($ficheroTexto, "r");
$contenido = @fread($fd, @filesize($ficheroTexto));
@fclose($fd);
# Creamos el array.
$ficheroTexto = explode("\n", $contenido);
# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 1, -1);
# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);
# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];
# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;
$mostrarde = ceil($registrosTotales / $limiteRegistros);
# bbcode
$contenidoarchivo[1] = str_replace("[codigo]","<table width='100%' border='0' cellpadding='4' cellspacing='0'><tr><td><font color='660002' face='Courier New, Courier, mono'>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/codigo]","</font></td></tr></table>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[b]","<b>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/b]","</b>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[zip]","<table width='100%' border='0' cellpadding='4'><tr><td><div align='center'><a href=",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/zip]","> [Descargar achivo]</a></div></td></tr></table>",$contenidoarchivo[1]) ;
?>
<br>
Tema : <strong> 
<?=$contenidoarchivo[0]?>
</strong> | <a href="index.php?id=foro#<?=$archivo?>">Volver</a><br>
<strong> </strong><br>
<table width='100%' border='0' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
  <tr bgcolor="#dddddd"> 
    <td colspan="3" valign="top" class="tabla_titulo"><a href='subtema.php?archivo=<?=$archivo?>&subtema=<?=$columna[0]?>'> 
      </a>Tema </td>
  </tr>
  <tr> 
    <td colspan="3" valign="top" class="tabla_mensaje"><a href='subtema.php?archivo=<?=$archivo?>&subtema=<?=$columna[0]?>'> 
      </a> <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="75%"><strong> 
            <?=$contenidoarchivo[0]?>
            </strong></td>
          <td width="25%"><div align="right">Visitas 
              <?=$hits?>
            </div></td>
        </tr>
        <tr valign="top"> 
          <td colspan="2"> 
            <?=$contenidoarchivo[1]?>
          </td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td valign="top" bgcolor="#dddddd" class="tabla_titulo">Subtema</td>
    <td valign="top" bgcolor="#dddddd" class="tabla_titulo">Contenido subtema</td>
    <td valign="top" bgcolor="#dddddd" class="tabla_titulo">Visitas</td>
  </tr>
  <?
# Mostramos los registros limitandolos por medio de las variables de arriba.
for($i = $mostrarDesde;  $i < $registrosTotales AND $i < $mostrarHasta; $i++)
{
    # Analizamos los resultados
	$columna = split("\|",$ficheroTexto[$i]);
	# bbcode
	$columna[1] = str_replace("/&/", "|", $columna[1]);
	$columna[1] = substr($columna[1],0,50)."..";
	$lineas[1] = str_replace("/&/", "|", $lineas[1]);
	# Resultados del tema

	# Resultados del contenido del tema
	if(!$columna[4]){
	?>
  <tr> 
    <td width='33%' valign="top" class="tabla_mensaje"><a href='index.php?id=forosubtema&archivo=<?=$archivo?>&subtema=<?=$columna[0]?>&pag=<?=$pag?>'> 
      <?=$columna[0]?>
      </a></td>
    <td width='44%' valign="top" class="tabla_mensaje"> 
      <?=$columna[1]?>
    </td>
    <td width='23%' valign="top" class="tabla_mensaje">
<?
// Obtenemos el total de hits en los subtemas
$finalsubtema = md5("$archivo$columna[0]");
if(file_exists("foro/$finalsubtema.log")){ 
$archi2 = "foro/$finalsubtema.log";
$abrir2 = fopen($archi2,"r");
$hits2 = fread($abrir2, filesize($archi2));
fclose($abrir2);
echo $hits2 ;
}
else {
$hits2 = "0";
}
?>&nbsp;
    </td>
  </tr>
  <?
	}
	}
	?>
</table>
	
<?
	# Solo si el total de registros es mayor a el limite de registros por p�gina
	# mostraremos los enlaces para cada p�gina.
	if($registrosTotales > $limiteRegistros)
	{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);
	# Mostramos los enlaces.
echo "<div align='right'>";
	for($i = 1; $i <= $numeroPaginas; $i++)

	{
		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $i)
		{
			echo "| <b>".$i."</b> |";
		}
		else
		{
			echo "| <a href=index.php?id=forosubtema&pag=$i&archivo='$_GET[archivo]'>".$i."</a> |";
		}
	}
}
echo "</div><br>";

?>
<form name="form" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
  Subtema :<br>
  <input name='nick' type='text' class='form' id="nick" maxlength="34"><br>
  Contenido del subtema : <br>
  [codigo]codigo php[/codigo] <br>
  [b]negrita[/b]<br>
  [zip]fichero.zip[/zip] <br>
  <textarea name="opinion" cols="34" rows="13" class="form" id="opinion"></textarea>
  <br>
  <input name='tema' type='hidden' class='form' id="tema" value="<?=$contenidoarchivo[0]?>">
  <br>
<input name="enviar" type="submit" id="enviar" value="Enviar" class="form">
</form>
