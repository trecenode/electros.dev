<?
$administador = "admin";
?>