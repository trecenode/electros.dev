<form method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
<select name="puntos" class="form">
    <option value="electros.php">Elija estilo ... </option>
    <option value="azulverdoso.php">azulverdoso</option>
    <option value="egris.php">egris</option>
    <option value="phpmysql.php">phpmysql</option>
    <option value="cafe.php">cafe</option>
    <option value="red.php">red</option>
  </select>
  <input name="cambiar" type="submit" id="cambiar" value="Cambiar" class="form">
</form>
