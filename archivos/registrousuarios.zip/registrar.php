<?
if($registrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($cnnick) ;
$cnemail= quitar($cnemail) ;
// Comprobar que el usuario existe en la base de datos
if(!file_exists("usuarios/")) { mkdir("usuarios/", 0777); }
if(file_exists("usuarios/$cnnick.php")) {
echo "Ya existe un usuario con ese nick o email en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
}
else {
$cnfecha = time() ;
$cncontrasena = md5($cncontrasena) ;
$cnip = $REMOTE_ADDR ;

$nuevo .= "<"."?\n";
$nuevo .="\$nick = \"$cnnick\";\n";
$nuevo .="\$contrasena = \"$cncontrasena\";\n";
$nuevo .="\$email = \"$cnemail\";\n";
$nuevo .="\$fecha = \"$cnfecha\";\n";
$nuevo .="\$ip = \"$cnip\";\n";
$nuevo .="\$sexo = \"\";\n";
$nuevo .="\$pais = \"$pais\";\n";
$nuevo .="\$edad = \"\";\n";
$nuevo .="\$descripcion = \"\";\n";
$nuevo .= "?".">";

$crea = fopen("usuarios/$cnnick.php","w");
fputs($crea,$nuevo);
fclose($crea);
echo "Has sido registrado con �xito. Haz click <a href=index.php>aqu�</a> para ir a la p�gina principal." ;
}
}
else {
?>
<p>Los datos marcados con un asterisco (*) son obligatorios.
<script>
function revisar() {
if(formulario.cnnick.value.length < 3) { alert('El nick debe contener por lo m�nimo 3 caract�res') ; return false ; }
if(formulario.cncontrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res') ; return false ; }
if(formulario.cnemail.value.length == 0) { alert('Debes poner un email v�lido') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=registrar" onsubmit="return revisar()">
<b>* Nick:</b><br>
<input name="cnnick" type="text" id="cnnick" maxlength="20" class="form"><br>
<b>* Contrase�a:</b><br>
<input name="cncontrasena" type="password" id="cncontrasena" maxlength="20" class="form"><br>
<b>* Email:</b><br>
<input name="cnemail" type="text" id="cnemail" maxlength="40" class="form"><br><br>
<input type="submit" name="registrar" value="Registrar" class="form">
</form>
<?
}
?> 