<?
if($_COOKIE["ucnnick"]) {
// Incluimos la informacion sobre el usuario
if(file_exists("usuarios/$_COOKIE[ucnnick].php")) {
require ("usuarios/$_COOKIE[ucnnick].php");
}
else
{
echo "<script>location='salir.php'</script>" ;
}
?> 
Bienvenido <b><? echo $_COOKIE["ucnnick"] ?></b><br>
<b> </b><br>
<a href="index.php?id=perfil">Perfil</a><br>
<a href="index.php?id=mensajes">Mensajes</a> <?
// Usuarios en linea
$path2 = "mensajes/"; 
// Contar el total
$dir2 = opendir($path2);
$i = 0;
while ($elemento = readdir($dir2))
{
$elemento2 = strtolower($elemento);
if (strpos($elemento2, ".php") > 0) {
include("mensajes/$elemento2");
if($destinatario == $ucnnick) {
$i++;
}
}
}
if ($i != "0") { 
echo "<script>
function BlinkTxt() {
texto = document.getElementsByTagName('blink');
for (i=0; i<texto.length; i++)
if (texto[i].style.visibility=='hidden') {
texto[i].style.visibility='visible';
} else {
texto[i].style.visibility='hidden';
}
setTimeout('BlinkTxt()',100);
}
onload=BlinkTxt;
</script><blink>($i) </blink>" ; 
}
closedir($dir2);
?><br>
<a href="index.php?id=noticiasenviar">Enviar noticias</a><br>
<a href="index.php?id=enlacesenviar">Enviar enlaces</a><br>
<a href="index.php?id=descargasenviar">Enviar descargas</a><br>
<a href="index.php?id=modsenviar">Enviar mods</a><br>
<br>
<a href="salir.php">Salir</a> 
<?
}
else {
?>
<form method="post" action="entrar.php">
Nick:<br>
<input type="text" name="cnnick" class="form"><br>
Contrase�a:<br>
<input type="password" name="cnpass" class="form"><br><br>
<input type="submit" name="entrar" value="Entrar" class="form">
  <input type="hidden" name="id" value="<? echo $_SERVER['REQUEST_URI'] ?>">
</form>
<a href="index.php?id=registrar">� Registrate</a> <br>
<a href="index.php?id=contrasena">� �Olvide contrase�a? </a>
<?
}
?>