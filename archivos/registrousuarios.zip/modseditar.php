<?
include("login.php") ;
?>
<?
// Incluimos los datos
if(file_exists("mods/$e.php")) {
require ("mods/$e.php");
// Leemos la informacion del archivo.txt y la mostarmos
$archi = "mods/$e.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
// Solo edita el usuario propietario y el administrador
if($_COOKIE["ucnnick"] != $administador){
if($autor_mod != $_COOKIE["ucnnick"]) { die("No puedes editar este mod."); }
}
}
// Editamos el mod
if($editar && file_exists("mods/$e.php")) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($autor_mod) ;
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cndescmod = quitar($cndescmod) ;

$edita .= "<"."?\n";
$edita .="\$autor_mod = \"$cnnick\";\n";
$edita .="\$fecha_mod = \"$cnfecha\";\n";
$edita .="\$titulo_mod = \"$cntitulo\";\n";
$edita .="\$desc_mod = \"$cndescmod\";\n";
$edita .= "?".">";

$edit = fopen("mods/$e.php","w");
fputs($edit,$edita);
fclose($edit);

// Editamos el fichero txt
$cnmod = htmlspecialchars(stripslashes(trim($_POST["cnmod"])));
$ncrea = fopen("mods/$e.txt","w"); fwrite($ncrea, $cnmod); fclose($ncrea);
// Subir archivo
if($nuevoarchivo != "") {
@copy($nuevoarchivo,"mods/$e.zip") ;
@move_uploaded_file($nuevoarchivo,"mods/$e.zip") ;
}
// Borrar archivo
if($borrararchivo != "") {
unlink("mods/$e.zip");
}

echo "Mod editado con �xito. Haz click <a href=index.php?id=mods>aqu�</a>.<br><br>" ;
}
?>
<p class="t1">Editar mods
</p>
<p>
<script>
function revisar() {
if(formulario.cntitulo.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="<? $_SERVER['REQUEST_URI'] ?>" onsubmit="return revisar()" enctype="multipart/form-data">
  <div align="left"><b>Titulo :</b><br>
    <input name="cntitulo" type="text" class="form" id="cntitulo" value="<?=$titulo_mod?>" maxlength="60">
    <br>
    <strong>Breve descripcion del mod :</strong><br>
    <textarea name="cndescmod" cols="30" rows="4" class="form" id="cndescmod"><?=$desc_mod?></textarea>
    <br>
    <b>Mod :</b><br>
    [codigo]Codigo php[/codigo] <br>
    [b]Negrita[/b] <b><br>
    </b><br>
    <textarea name="cnmod" cols="30" rows="10" class="form" id="cnmod"><?=$codigo?></textarea>
    <br>
    <b>Archivo :</b><br>
    <input name="nuevoarchivo" type="file" class="form" id="nuevoarchivo" size="30">
    <br>
    <? if(file_exists("mods/$e.zip")) {?><input type="checkbox" name="borrararchivo" value="checkbox">
    Borrar archivo <? } ?><br>
    <br>
    <input type="submit" name="editar" value="Editar" class="form">
  </div>
</form>