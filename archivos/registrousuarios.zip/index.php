<?
// Incluimos la configuracion del sitio
@include("configuracion.php");
?>
<html>
<head>
<style>
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=2), dropshadow(color=#000000,offx=1,offy=1) ;
width: 100% ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
/*
border-left-color: #aaaaaa ; border-left-width: 2 ; border-left-style: solid ;
border-top-color: #aaaaaa ; border-top-width: 2 ; border-top-style: solid ;
border-right-color: #505050 ; border-right-width: 2 ; border-right-style: solid ;
border-bottom-color: #505050 ; border-bottom-width: 2 ; border-bottom-style: solid ;
background: #757575 ;
*/
background: url('fondo_titulo.gif') ;
}
.tabla_subtitulo {
border-left-color: #cccccc ; border-left-width: 2 ; border-left-style: solid ;
border-top-color: #cccccc ; border-top-width: 2 ; border-top-style: solid ;
border-right-color: #aaaaaa ; border-right-width: 2 ; border-right-style: solid ;
border-bottom-color: #aaaaaa ; border-bottom-width: 2 ; border-bottom-style: solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left-color: #eeeeee ; border-left-width: 2 ; border-left-style: solid ;
border-top-color: #eeeeee ; border-top-width: 2 ; border-top-style: solid ;
border-right-color: #cccccc ; border-right-width: 2 ; border-right-style: solid ;
border-bottom-color: #cccccc ; border-bottom-width: 2 ; border-bottom-style: solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border-color: #000000 ; border-width: 1 ; border-style: solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
<script>
<!-- 
if(parent.frames.length > 0) top.location = "<? echo $_SERVER['REQUEST_URI'] ?>" ;
//--> 
</script>
<title>Registro de usuarios sin mysql</title>
</head>
<body>
<font size="3"><strong class="t1">Registro de usuarios sin mysql</strong></font><br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15%" height="408" valign="top"><table width="151" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
        <tr> 
          <!-- Inicio bloques menus -->
          <td width="145" class="tabla_titulo"><div align="right" class="t1">Menu</div></td>
        </tr>
        <tr> 
          <td height="104" valign="top" class="tabla_mensaje"><p>Inicio<br>
              <a href="index.php">� Principal</a><br>
              <a href="index.php?id=usuarios">� Usuarios</a><br>
              <a href="index.php?id=noticias">� Noticias</a><br>
              <a href="index.php?id=mods">� Mods</a><br>
              <a href="index.php?id=enlaces">� Enlaces</a><br>
              <a href="index.php?id=descargas">� Descargas</a><br>
              <a href="index.php?id=foro">&middot; Foro</a></p></td>
        </tr>
      </table>
      <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Usuarios</div></td>
        </tr>
        <tr> 
          <td height="3" valign="top" class="tabla_mensaje" align="left"> 
            <? 
			// el menu de los usuarios
			@include("menu.php"); 
			?>
          </td>
        </tr>
      </table>
      <br> <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Top 10 enlaces</div></td>
        </tr>
        <tr> 
          <td height="26" valign="top" class="tabla_mensaje" align="left"> 
            <?
for($ienlaces=1;$ienlaces<11;$ienlaces++){
if(file_exists("enlaces/$ienlaces.php")) {
include ("enlaces/$ienlaces.php");
echo "<a href='enlaces.php?e=$ienlaces' target='_blank'>� $titulo_enlace</a> ($hits_enlace)<br>" ;
}
}
?>
          </td>
        </tr>
      </table> 
      <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Top 10 descargas</div></td>
        </tr>
        <tr> 
          <td height="26" valign="top" class="tabla_mensaje" align="left"> 
            <?
for($idescargas=1;$idescargas<11;$idescargas++){
if(file_exists("descargas/$idescargas.php")) {
include ("descargas/$idescargas.php");
echo "<a href='descargas.php?e=$idescargas' target='_blank'>� $titulo_descarga</a> ($hits_descarga)<br>" ;
}
}
?>
          </td>
        </tr>
      </table> 
      <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Usuarios online</div></td>
        </tr>
        <tr> 
          <td height="2" valign="top" class="tabla_mensaje" align="left"> 
<?
// Usuarios online
@include("online.php");
?>
          </td>
        </tr>
      </table> 
      <br>
    </td>
    <td width="1%"><br>
    </td>
    <td width="84%" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0" align="center" class='tabla_principal' >
        <tr> 
          <td height="28" class="tabla_mensaje" > 
            <? 
// Donde se incluyen las paginas de forma automatica (con la url index.php?id=nombrepagina
// se abriria la pagina nombrepagina.php en esta parte).
if($id == "") { 
include("principal.php"); 
}
else { 
if(file_exists("$id.php")) { 
$id = htmlspecialchars(trim($_GET["id"]));
$id = eregi_replace("<[^>]*>","",$id) ;
$id = eregi_replace(".*//","",$id) ;
include("$id.php"); 
} 
else { 
echo "Esta pagina no existe o esta siendo acualizada en este momento";
} 
} 
?>
          </td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>