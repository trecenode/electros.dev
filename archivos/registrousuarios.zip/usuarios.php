<title>Usuarios</title><body>
<?
if (!$u) {
?>
<p class="t1">Usuarios</p>
<br> Usuarios registrados en la web: 
<?
// Usuarios totales
$path_usuarios = "usuarios/"; 
// Contar el total
$dir_usuarios = opendir($path_usuarios);
$i_usuarios = 0;
while ($elemento_usuarios = readdir($dir_usuarios))
{
$elemento_usuarios2 = strtolower($elemento_usuarios);
if (strpos($elemento_usuarios2, ".php") > 0) {
include("usuarios/$elemento_usuarios");
$i_usuarios++;
}
}
echo "$i_usuarios" ; 
closedir($dir_usuarios);
?>
<br><br> 
<table width="100%" border="0" cellspacing="0" cellpadding="5" style='border: #757575 1 solid'>
  <tr bgcolor="#dddddd"> 
    <td class="tabla_titulo"><strong class="t1">Nick</strong></td>
    <td class="tabla_titulo"><strong class="t1">Sexo</strong></td>
    <td class="tabla_titulo"><strong class="t1">Pais</strong></td>
  </tr>
<?php
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "usuarios/";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20;             // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['20 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
  $Counter++;
  
  $elemento1 = strtolower($elemento);
  
  if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".php","",$elemento);
?> 
<?
if(file_exists("usuarios/$elemento2.php")) {
require ("usuarios/$elemento2.php");
   // Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
// Sexo
if($sexo == 0) { $sexonumero = "Masculino" ; }
else { $sexonumero = "Femenino" ; }
// Edad
if($edad == 0) { $edad = "" ; }
else { $edad = $edad ; }
}
?>
  <tr> 
    <td class="tabla_mensaje"><a href="index.php?id=usuarios&u=<?php echo $elemento2 ?>"><? echo $elemento2 ?></a></td>
    <td class="tabla_mensaje"><? echo $sexonumero ?>&nbsp;</td>
    <td class="tabla_mensaje"><? echo $pais ?>&nbsp;</td>
  </tr>
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['20 Siguientes'] = 1;
}

//Cerramos el directorio
@closedir($dir);
?>
</table>
<div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?id=usuarios&c=".($Plus-$Config['Show'])."\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=usuarios&c=".($Plus+$Config['Show'])."\">20 Siguientes</a></p>");
}
?>
</div>
<? if ($u) {
if(file_exists("usuarios/$u.php")) {
require ("usuarios/$u.php");
}
// Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
// Sexo
if($sexo == 0) { $sexonumero = "Masculino" ; }
else { $sexonumero = "Femenino" ; }
// Edad
if($edad == 0) { $edad = "" ; }
else { $edad = $edad ; }
$descripcion = str_replace("\r\n","<br>",$descripcion) ;
?>
<p><b>Usuario desde el:</b> <? echo $fecha ?>
<p>
<table width=100% border=0 cellpadding=5 cellspacing=0 style='border: #757575 1 solid'>
  <tr> 
    <td class="tabla_mensaje"><b>Nick:</b></td>
    <td width="68%" class="tabla_mensaje"><? echo $nick ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_mensaje"><b>Pa�s:</b></td>
    <td class="tabla_mensaje"><? echo $pais ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_mensaje"><b>Edad:</b></td>
    <td class="tabla_mensaje"><? echo $edad ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_mensaje"><b>Sexo:</b></td>
    <td class="tabla_mensaje"><? echo $sexonumero ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_mensaje"><b>Descripci�n:</b></td>
    <td class="tabla_mensaje"><? echo $descripcion ?>&nbsp;</td>
  </tr>
  <? if($seccion){?>
  <tr>
    <td class="tabla_mensaje"><strong>Seccion actual :</strong></td>
    <td class="tabla_mensaje"><a href="index.php?id=<? echo $seccion ?>"><? echo $seccion ?></a></td>
  </tr>
  <? } ?>
</table>
<br>
<p><a href=index.php?id=usuarios>Regresar a Usuarios</a>
<?
}
?>
</body>
