<?
include("login.php") ;
?>
<?
// Incluimos los datos
if(file_exists("descargas/$e.php")) {
require ("descargas/$e.php");
// Solo edita el usuario propietario y el administrador
if($_COOKIE["ucnnick"] != $administador){
if($nick_descarga != $_COOKIE["ucnnick"]) { die("No puedes editar esta descarga."); }
}
}
// Editamos el descarga
if($editar && file_exists("descargas/$e.php")) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}

$cnnick = quitar($nick_descarga) ;
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cndescripcion = quitar($cndescripcion) ;
$cnurl = quitar($cnurl) ;
$clicks = quitar($hits_descarga) ;

if($nuevoarchivo != "") {
@copy($nuevoarchivo,"descargas/$e.zip") ;
@move_uploaded_file($nuevoarchivo,"descargas/$e.zip") ;
}  

$edita .= "<"."?\n";
$edita .="\$nick_descarga = \"$cnnick\";\n";
$edita .="\$fecha_descarga = \"$cnfecha\";\n";
$edita .="\$titulo_descarga = \"$cntitulo\";\n";
$edita .="\$descripcion_descarga = \"$cndescripcion\";\n";
$edita .="\$archivo_descarga = \"$e.zip\";\n";
$edita .="\$hits_descarga = \"$clicks\";\n";
$edita .= "?".">";

$edit = fopen("descargas/$e.php","w");
fputs($edit,$edita);
fclose($edit);
echo "Descarga editado con �xito. Haz click <a href=index.php?id=descargas>aqu�</a>.<br><br>" ;
}
?>
<p class="t1">Editar descargas
</p>
<p>
<script>
function revisar() {
if(formulario.cntitulo.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="<? $_SERVER['REQUEST_URI'] ?>" onsubmit="return revisar()" enctype="multipart/form-data">
  <b>Titulo :</b><br>
  <input name="cntitulo" type="text" class="form" id="cntitulo" value="<?=$titulo_descarga?>" maxlength="40">
  <br>
  <b>Descripcion :</b> <br>
  <textarea name="cndescripcion" cols="30" rows="5" class="form" id="cndescripcion"><?=$descripcion_descarga?></textarea>
  <br>
  <b>Archivo :</b><br>
  <input name="nuevoarchivo" type="file" class="form" id="nuevoarchivo" size="30">
  <br>
  <br>
<input type="submit" name="editar" value="Editar" class="form">
</form>