<?
// Incluimos archivo de configuracion
@include("configuracion.php");
// Funciones
if(!file_exists("foro/")) { mkdir("foro/", 0777); }
function leer($filename)
{
$fd = @fopen ($filename, "a+");
$archivo = @fread ($fd, filesize ($filename));
@fclose ($fd);
return $archivo;
}
?>
<body>
<font class="t1">Foro</font><br>
<br>
Total de temas : 
<?
// abrimos el directorio
$dir = opendir("foro/");
while ($elemento = readdir($dir)) {
// leemos solo los que tengan ese tipo de extension
$elemento1 = strtolower($elemento); 
if ((strpos($elemento1, ".dat") > 0)) 
// mostramos el total de ficheros
$i++;
}
echo $i ;
?> | <a href="index.php">Volver</a><br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><div align="center"> 
        <form name="mods" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
          <input name="campo" type="text" id="campo2" class="form">
          <input name="buscar" type="submit" id="buscar" value="Buscar" class="form">
        </form>
      </div></td>
  </tr>
  <tr> 
    <td><div align="center"> 
        <table width="50%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td><div align="left"> 
                <?
if($buscar){
// Incluimos todos los mods
if($campo != ""){
echo "<center>Resultados de la busqueda : $_GET[contar]</center><br>";
}
// Recogemos la informacion de cada archivo

// Comprobamos que la palabra coincide
if($campo != ""){
$path_buscar = "foro/";
$dir_buscar = opendir($path_buscar);
while ($elemento_buscar = readdir($dir_buscar))
{
$contar = count($elemento_buscar);
$extensiones = explode(".",$elemento_buscar) ;
$nombre_buscar = $extensiones[0] ;
$nombre_buscar2  = $extensiones[1] ;
$tipo_buscar = array ("dat");

$contenidobuscador = @leer("$elemento_buscar");
$lineasbuscador = explode("|", $contenidobuscador );
if(eregi("$campo", $lineasbuscador[1])){
if(in_array($nombre_buscar2, $tipo_buscar)){
echo "� <a href='tema.php?archivo=$nombre_buscar'>$lineasbuscador[0]</a><br>" ;
}
}
}
closedir($dir_buscar);
}
}
?>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<div align="left"><br>
  <br>
<?
// Borrar
if($borrar) {
$_GET["borrar"];
// si el usuario borra un mensaje
if ($_COOKIE[ucnnick] == $administador) {
@unlink("foro/$borrar.dat") ;
@unlink("foro/$borrar.txt") ;
@unlink("foro/$borrar.log") ;
echo "<p>El tema ha sido borrado con �xito. Haz click <a href=index.php?id=foro>aqu�</a> para regresar.<br><br>" ;
}
}
?>
  <table width="100%" border="0" cellpadding="5" cellspacing="0" style='border: #757575 1 solid'>
    <tr> 
      <td width="30%" bgcolor="#dddddd" class="tabla_titulo">Categoria</td>
      <td width="48%" bgcolor="#dddddd" class="tabla_titulo">Tema</td>
      <td width="11%" bgcolor="#dddddd" class="tabla_titulo">Visitas</td>
    </tr>
    <?
	// Directorio
$path = "foro/";
$dir = opendir($path);
while ($elemento = readdir($dir))
{
$extensiones = explode(".",$elemento) ;
$nombre = $extensiones[0] ;
$nombre2  = $extensiones[1] ;
$tipo = array ("dat");
if(in_array($nombre2, $tipo)){
$nombrearchivos = md5($nombre);
// Nombre del archivo
$fichero = $nombre ;
if (strlen($fichero) > 35) { 
$fichero  = substr($fichero,0,35)."..";
}
//
if(file_exists("$path$nombre.dat")){
$contenido = leer("$path$nombre.dat");
$lineas = explode("|", $contenido);
}
	?>
    <tr class="tabla_mensaje"> 
      <td class="tabla_mensaje"><div align="left"><a href='index.php?id=forotema&archivo=<?=$nombre?>'> 
          <?=$lineas[0]?>
          </a><a name="<?=$nombre?>"></a> 
          <? if ($_COOKIE[ucnnick] == $administador) { echo "[<a href='index.php?id=foro&borrar=$nombre'>borrar</a>]"; } ?>
        </div></td>
      <td class="tabla_mensaje"> 
        <? 
// Descripcion
$lineas[1] = str_replace("<br>", "", $lineas[1]);
$lineas[1] = substr($lineas[1],0,50)."..";
$lineas[1] = str_replace("/&/", "|", $lineas[1]);
echo $lineas[1]; 
?>
        &nbsp;</td>
      <td class="tabla_mensaje"> 
        <? if(file_exists("foro/$nombre.txt")){ @include("foro/$nombre.txt"); } else { echo "0"; }?>
      </td>
    </tr>
    <?
}
}
closedir($dir);
?>
  </table>
</div>
<br>
<?
if($_COOKIE[ucnnick]){
if($_COOKIE[ucnnick] == $administador) {
?>
<?
if($enviar){
// bbcode para mayor seguridad
$nick = htmlspecialchars(trim($_POST['nick']));
$opinion = htmlspecialchars(stripslashes(trim($_POST["opinion"])));
$opinion = str_replace("\r\n", "<br>", $opinion);
$fecha = time();
// cambiamos | por /&/ en opinion
if($nick == "") { die("Pon un tema, <a href=javascript:history.back()>volver</a> ");}
if($opinion == "") { die("Pon el comentario del tema, <a href=javascript:history.back()>volver</a> ");}
$opinion = str_replace("|", "/&/", $opinion);
$nick = str_replace("|", "/&/", $nick);
// creamos el fichero
$archivo = md5($nick);
$fichero = fopen("foro/$archivo.dat", "a");
fwrite($fichero, "$nick|$opinion|$fecha\r\n");
fclose($fichero);
echo "Tema creado, <a href='index.php?id=foro'>pulsa aqui</a><br>";
}
?>
<form name="form" method="post" action="<? echo $_SERVER['REQUEST_URI'] ?>">
  T&iacute;tulo del tema. :<br>
  <input name='nick' type='text' class='form' id="nick" maxlength="34"><br>
  Contenido del tema : <br>
  <textarea name="opinion" cols="34" rows="13" class="form" id="opinion"></textarea>
  <br>
  <br>
<input name="enviar" type="submit" id="enviar" value="Enviar" class="form">
</form>
<? 
}
}
?>
</body>
</html>
