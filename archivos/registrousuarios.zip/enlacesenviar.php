<?
include("login.php") ;
?>
<?
if($enviar) {

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = $_COOKIE[ucnnick];
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cnenlace = quitar($cnenlace) ;
$cncategoria = quitar($cncategoria) ;

$edita .= "<"."?\n";
$edita .="\$nick_enlace = \"$cnnick\";\n";
$edita .="\$fecha_enlace = \"$cnfecha\";\n";
$edita .="\$titulo_enlace = \"$cntitulo\";\n";
$edita .="\$descripcion_enlace = \"$cndescripcion\";\n";
$edita .="\$url_enlace = \"$cnurl\";\n";
$edita .="\$hits_enlace = \"0\";\n";
$edita .="\$imagen_enlace = \"\";\n";
$edita .= "?".">";

// a�adimos la nueva enlace a contador.txt
if(!file_exists("enlaces/$cncategoria")) { mkdir("enlaces/$cncategoria", 0777); }
if(!file_exists("enlaces/$cncategoria/contador.txt")) { $ncrea = fopen("enlaces/$cncategoria/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "enlaces/$cncategoria/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

$edit = fopen("enlaces/$cncategoria/$clicks.php","w");
fputs($edit,$edita);
fclose($edit);
echo "Tu enlace ha sido enviada con exito. Haz click <a href=index.php?id=enlaces>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
?>
<p class="t1">Enviar enlaces
<p> 
<script>
function revisar() {
if(formulario.cntitulo.value.length == 0) { alert('Debes poner un titulo.') ; return false ; }
if(formulario.cndescripcion.value.length == 0) { alert('Debes poner una descripcion.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
if(formulario.cnurl.value.length == 0) { alert('Debes poner una url.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=enlacesenviar" onsubmit="return revisar()">
  <b>Titulo :</b><br>
<input name="cntitulo" type="text" class="form" id="cntitulo" maxlength="40">
  <br>
  <b>Descripcion :</b> <br>
  <textarea name="cndescripcion" cols="30" rows="5" class="form" id="cndescripcion"></textarea>
  <br>
  <b>Url :</b><br>
  <input name="cnurl" type="text" class="form" id="cnurl" value="http://" size="42">
  <br>
  <strong>Categoria :</strong><br>
  <!-- 
  categorias: basta con especificar la  categoria simple ej)programas/
  subcategorias: hay que especificar las categorias y subcategorias separadas por una / ej) programas/windos98 
  sub-sucategorias: ej) juegos/mods/half life/ y las carpetas hay que crearlas previamente en el directorio web con permismos chmod 777
  -->
  <select name="cncategoria" id="cncategoria" class="form">
    <option value="./">Principal</option>
	<option value="Cine y TV">Cine y TV</option>
	<option value="Deportes">Deportes</option>
	<option value="Emuladores">Emuladores</option>
	<option value="Humor">Humor</option>
	<option value="Internet">Internet</option>
	<option value="M�sica">M�sica</option>
	<option value="Poes�a y literatura">Poes�a y literatura</option>
    <option value="Videojuegos">Videojuegos</option>
    <option value="Webmasters">Webmasters</option>
	<option value="Emule Links">Emule Links</option>
	<option value="Otro">Otro</option>
  </select>
  <br>
  <br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>