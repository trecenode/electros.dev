<?
# Numero de registros que se mostraran por p�gina.
$limiteRegistros = "10";
# Ubicaci�n del fichero de texto.
$ficheroTexto = "online.txt";
# Leemos el contenido del fichero.
$fd = fopen($ficheroTexto, "r");
$contenido = fread($fd, filesize($ficheroTexto));
fclose($fd);
# Creamos el array.
$ficheroTexto = explode("\n", $contenido);
# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 0, -1);
# Ordenamos los elementos del array en orden inverso.
$ficheroTexto = array_reverse($ficheroTexto);
# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);
# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];
# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;
?><p class='t1'>Usuarios online</p> Total de usuarios : <?=$registrosTotales?><br><br>
<table width='50%' border='0' cellspacing='0' cellpadding='5' style='border: #757575 1 solid'>
<tr bgcolor='#dddddd'> 
<td class='tabla_titulo'>Direccion Ip:</td>
<td class='tabla_titulo'>Pagina:</td>
<td class='tabla_titulo'>Usuario:</td>
</tr>
<?
# Mostramos los registros limitandolos por medio de las variables de arriba.
for($iregistros = $mostrarDesde;  $iregistros < $registrosTotales AND $iregistros < $mostrarHasta; $iregistros++)
{
    $columna = split("\|",$ficheroTexto[$iregistros]);
	$columna_anonimos = split("\!",$ficheroTexto[$iregistros]);
	# Resultados
	$columna[0] = substr($columna[0],0,12)."..";
	if($columna[2]){
	?><tr> 
    <td class='tabla_mensaje'><?=$columna[0]?></td>
    <td class='tabla_mensaje'><a href='index.php?id=?=$columna[3]?>'><?=$columna[3]?></a></td>
    <td class='tabla_mensaje'><a href='index.php?id=usuarios&u=<?=$columna[2]?>'><?=$columna[2]?></a></td>
  </tr><?
	}
	# Resultados
	if(!$columna[2]){
	?><tr> 
    <td class='tabla_mensaje'><?=$columna[0]?></td>
    <td class='tabla_mensaje'><a href='index.php?id=<?=$columna_anonimos[1]?>'><?=$columna_anonimos[1]?></a></td>
    <td class='tabla_mensaje'>Invitado</td>
  </tr><?
	}
	
}
# Solo si el total de registros es mayor a el limite de registros por p�gina
# mostraremos los enlaces para cada p�gina.
?>
</table>
<?

if($registrosTotales > $limiteRegistros)
{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);
	# Mostramos los enlaces.
echo "<div align='right'>";
	for($iregistros = 1; $iregistros <= $numeroPaginas; $iregistros++)
	{
		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $iregistros)
		{
			echo "| <b>".$iregistros."</b> |";
		}
		else
		{
			echo "| <a href=index.php?id=usuariosonline&pag=".$iregistros.">".$iregistros."</a> |";
		}
	}
}
echo "</div>";
?>
