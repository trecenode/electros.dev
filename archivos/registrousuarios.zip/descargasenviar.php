<?
include("login.php") ;
?>
<?
if($enviar) {

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = $_COOKIE[ucnnick];
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cndescarga = quitar($cndescarga) ;
$cncategoria = quitar($cncategoria) ;

// a�adimos la nueva descarga a contador.txt
if(!file_exists("descargas/$cncategoria")) { mkdir("descargas/$cncategoria", 0777); }
if(!file_exists("descargas/$cncategoria/contador.txt")) { $ncrea = fopen("descargas/$cncategoria/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "descargas/$cncategoria/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

$edita .= "<"."?\n";
$edita .="\$nick_descarga = \"$cnnick\";\n";
$edita .="\$fecha_descarga = \"$cnfecha\";\n";
$edita .="\$titulo_descarga = \"$cntitulo\";\n";
$edita .="\$descripcion_descarga = \"$cndescripcion\";\n";
$edita .="\$archivo_descarga = \"$clicks.zip\";\n";
$edita .="\$hits_descarga = \"0\";\n";
$edita .= "?".">";

$edit = fopen("descargas/$cncategoria/$clicks.php","w");
fputs($edit,$edita);
fclose($edit);

if($cnarchivo != "") {
move_uploaded_file($cnarchivo,"descargas/$cncategoria/$clicks.zip");
@copy($cnarchivo,"descargas/$cncategoria/$clicks.zip");
}

echo "Tu descarga ha sido enviada con exito. Haz click <a href=index.php?id=descargas>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
?>
<p class="t1">Enviar descargas
<p> 
<script>
function revisar() {
if(formulario.cntitulo.value.length == 0) { alert('Debes poner un titulo.') ; return false ; }
if(formulario.cndescripcion.value.length == 0) { alert('Debes poner una descripcion.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
if(formulario.cnarchivo.value.length == 0) { alert('Debes poner un archivo.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="index.php?id=descargasenviar" onsubmit="return revisar()" enctype="multipart/form-data">
  <b>Titulo :</b><br>
<input name="cntitulo" type="text" class="form" id="cntitulo" maxlength="40">
  <br>
  <b>Descripcion :</b> <br>
  <textarea name="cndescripcion" cols="30" rows="5" class="form" id="cndescripcion"></textarea>
  <br>
  <b>Archivo :</b><br>
  <input name="cnarchivo" type="file" class="form" id="cnarchivo" size="30">
  <b></b><br>
  <strong>Categoria :</strong><br>
  <!-- 
  categorias: basta con especificar la  categoria simple ej)programas/
  subcategorias: hay que especificar las categorias y subcategorias separadas por una / ej) programas/windos98 
  sub-sucategorias: ej) juegos/mods/half life/ y las carpetas hay que crearlas previamente en el directorio web con permismos chmod 777
  -->
  <select name="cncategoria" id="cncategoria" class="form">
    <option value="./">Principal</option>
	<option value="Programas">Programas</option>
	<option value="Musica">Musica</option>
    <option value="Juegos">Juegos</option>
    <option value="Sevicios">Servicios</option>
  </select>
  <br>
  <br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>