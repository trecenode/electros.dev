<?
include("login.php") ;
?>
<p><b>Mensajes</b>
<?
if(!file_exists("mensajes")) { mkdir("mensajes", 0777); }
if($mensajes == "nuevo") {
echo "
<script>
function revisar() {
if(formulario.cndestinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.cnmensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.cnmensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p><b>Nuevo</b>
<p>
<form name=formulario method=post action=index.php?id=mensajes onsubmit=\"return revisar()\">
<b>Destinatario:</b><br>
<input type=text name=cndestinatario maxlength=20 class=form><br>
<b>Mensaje:</b><br>
<textarea name=cnmensaje cols=30 rows=5 class=form></textarea><br><br>
<input type=submit name=enviar value=Enviar class=form>
</form>
" ;
}
else {
echo "<p><a href=index.php?id=mensajes&mensajes=nuevo>Nuevo mensaje</a>" ;
}
if($responder) {
echo "
<script>
function revisar() {
if(formulario.cndestinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.cnmensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.cnmensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p><b>Responder</b>
<p>
<form name=formulario method=post action=index.php?id=mensajes onsubmit=\"return revisar()\">
<b>Destinatario:</b><br>
<input type=text name=cndestinatario maxlength=20 value=\"$responder\" class=form><br>
<b>Mensaje:</b><br>
<textarea name=cnmensaje cols=30 rows=5 class=form></textarea><br><br>
<input type=submit name=enviar value=Enviar class=form>
</form>
";
}
if($borrar) {
$_GET["borrar"];
@include("mensajes/$borrar.php");
// si el usuario borra un mensaje
if ($destinatario = $_COOKIE["ucnnick"]) {
@unlink("mensajes/$borrar.php") ;
echo "<p>El mensaje ha sido borrado con �xito. Haz click <a href=index.php?id=mensajes>aqu�</a> para regresar." ;
}
// Si un usuario intenta borra un mensaje que no es suyo
if ($destinatario != $_COOKIE["ucnnick"]) {
echo "<p>El mensaje no ha sido borrado. Haz click <a href=index.php?id=mensajes>aqu�</a> para regresar." ;
}
}
else {
if($enviar) {

if(!file_exists("usuarios/$cndestinatario.php")) {
echo "<p>Este usuario no existe en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.";
}
else {
$cnremitente = $_COOKIE["ucnnick"] ;

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnfecha = time() ;
$cndestinatario = quitar($cndestinatario) ;
$cnmensaje = quitar($cnmensaje) ;

$nuevo .= "<"."?\n";
$nuevo .="\$fecha = \"$cnfecha\";\n";
$nuevo .="\$remitente = \"$cnremitente\";\n";
$nuevo .="\$destinatario = \"$cndestinatario\";\n";
$nuevo .="\$mensaje = \"$cnmensaje\";\n";
$nuevo .= "?".">";

if(!file_exists("mensajes/contador.txt")) { $ncrea = fopen("mensajes/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }
$file = "mensajes/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);


$crea = fopen("mensajes/$clicks.php","w");
fputs($crea,$nuevo);
fclose($crea);

echo "<p>El mensaje ha sido enviado con �xito. Haz click <a href=index.php?id=mensajes>aqu�</a> para regresar." ;
}
}
else {
echo "<br><br>";
//definimos el path de acceso 
$path = "mensajes/"; 
//abrimos el directorio 
$dir = opendir($path); 
//Mostramos las informaciones 
while ($elemento = readdir($dir)) 
{ 
$elemento1 = strtolower($elemento); 
if (strpos ($elemento1, ".php") > 0){
include("mensajes/$elemento1");
// Asignamos el archivo sin extension
$elemento2 = str_replace(".php","",$elemento); 
if($destinatario == $ucnnick) {
// fecha

$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano $hora" ;
echo "
<table width=100% border=0 cellpadding=1 cellspacing=3 class=tabla_mensaje>
<tr>
<td><b>$remitente</b></td>
<td><div align=right><b>$fecha</b></div></td>
</tr>
<tr>
<td colspan=2>$mensaje</td>
</tr>
<tr>
<td colspan=2>
<div align=right>
<a href=\"index.php?id=mensajes&responder=$remitente\">Responder</a> |
<a href=\"index.php?id=mensajes&borrar=$elemento2\">Borrar</a>
</div>
</td>
</tr>
</table><br>" ;
}
} 
} 
//Cerramos el directorio 
closedir($dir);
}
}
?> 