<?
$dbhost = "localhost" ;
$dbuser = "usuario" ;
$dbpass = "contrase�a" ;
$db = "base_de_datos" ;
if(!$conectar = @mysql_connect($dbhost,$dbuser,$dbpass)) {
$error = mysql_error() ;
echo "
<p class=\"t1\">Error
<p>No se pudo conectar a la base de datos debido a: <b>$error</b>
" ;
exit ;
}
mysql_select_db($db,$conectar) ;
?>
