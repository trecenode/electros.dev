<?
if($id == 2) {
$contrasena2 = md5(md5($contrasena)) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena2,time()+7776000) ;
}
?>
<html>
<head>
<title>eForo v.2.1 - Instalaci�n</title>
<style>
body,table {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
.t1 {
font-size: 15pt ;
font-weight: bold ;
}
.form {
font-family: verdana ;
font-size: 8pt ;
border: #000000 1 solid ;
background: #cccccc ;
color: #000000 ;
}
</style>
</head>
<body style="margin: 100">
<div align="center">
<div class="t1">eForo v.2.1 - Instalaci�n</div>
<?
if(!$id) {
?>
<br>
Este instalador crear� las tablas necesarias en la base de datos para el funcionamiento de eForo v.2.1. Para continuar con
la instalaci�n haz click en siguiente.
<br><br>
<div style="color: #ff0000"><b>El archivo config.php debe estar previamente configurado.</b></div>
<br><br>
<input type="button" value="Siguiente" onclick="location='instalar.php?id=1'" class="form">
<?
}
if($id == 1) {
?>
<p>Para administrar el foro necesitas crear una cuenta de administrador, se crea una cuenta normal como si fueras un usuario,
pero en la configuraci�n se indicar� que eres el administrador, el cu�l m�s adelante puedes cambiar si lo deseas.
<form method="post" action="instalar.php?id=2">
<b>Administrador:</b><br>
<input type="text" name="nick" class="form"><br>
<b>Contrase�a:</b><br>
<input type="password" name="contrasena" class="form"><br><br>
<input type="submit" name="enviar" value="Siguiente" class="form">
</form>
<?
}
if($id == 2) {
include("config.php") ;
mysql_query("
create table eforo_categorias (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria varchar(100) not null,
primary key (id),
index (orden)
)
") ;
mysql_query("
create table eforo_foros (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria tinyint(3) unsigned not null,
foro varchar(100) not null,
descripcion tinytext not null,
temas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (orden,categoria)
)
") ;
mysql_query("
create table eforo_mensajes (
id smallint(5) unsigned not null auto_increment,
foro tinyint(3) unsigned not null,
forotema smallint(5) unsigned not null,
foromostrar enum('0','1') not null,
visitas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
tema varchar(100) not null,
mensaje text not null,
caretos enum('0','1') not null,
codigo enum('0','1') not null,
url enum('0','1') not null,
firma enum('0','1') not null,
editado int(10) unsigned not null,
ultimo int(10) unsigned not null,
primary key (id),
index (foro,forotema,foromostrar)
)
") ;
mysql_query("
create table eforo_usuarios (
id smallint(5) unsigned not null auto_increment,
fecha int(10) unsigned not null,
nick varchar(20) not null,
contrasena varchar(20) not null,
email varchar(40) not null,
pais varchar(20) not null,
edad tinyint(2) unsigned not null,
sexo enum('0','1') not null,
descripcion tinytext not null,
web varchar(100) not null,
firma tinytext not null,
ip varchar(15) not null,
mensajes smallint(5) unsigned not null,
avatar char(3) not null,
primary key (id),
index (nick,contrasena)
)
") ;
mysql_query("
create table eforo_enlinea (
fecha int(10) unsigned not null,
ip varchar(15) not null,
usuario varchar(20) not null,
index (fecha)
)
") ;
mysql_query("
create table eforo_privados (
id smallint(5) unsigned not null auto_increment,
nuevo tinyint(1) unsigned not null,
fecha int(10) unsigned not null,
remitente varchar(20) not null,
destinatario varchar(20) not null,
mensaje tinytext not null,
primary key (id),
index (destinatario)
)
") ;
mysql_query("
create table eforo_config (
administrador varchar(20) not null,
temas tinyint(3) unsigned not null,
mensajes tinyint(3) unsigned not null,
ultimos tinyint(3) unsigned not null,
codigo enum('ON','OFF') not null,
caretos enum('ON','OFF') not null,
url enum('ON','OFF') not null,
censurar enum('ON','OFF') not null,
estilo varchar(30) not null,
privados tinyint(3) unsigned not null,
avatarlargo smallint(5) unsigned not null,
avatarancho smallint(5) unsigned not null,
avatartamano smallint(5) unsigned not null
)
") ;
$fecha = time() ;
$ip = $REMOTE_ADDR ;
mysql_query("insert into eforo_usuarios (fecha,nick,contrasena,ip) values ('$fecha','$nick','$contrasena','$ip')") ;
mysql_query("insert into eforo_config values ('$nick','25','15','15','ON','ON','ON','OFF','electros.php','50','150','150','50')") ;
mysql_close($conectar) ;
?>
<p>La instalaci�n se ha completado con �xito.
<p>Ahora s�lo debes eliminar este archivo y listo, podr�s disfrutar de eForo.
<p><input type="button" value="Finalizar" onclick="location='foroadmin.php'" class="form">
<?
}
?>
</div>
</body>
</html>
