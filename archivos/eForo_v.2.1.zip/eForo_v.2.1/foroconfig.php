<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("config.php") ;
$resp = mysql_query("select * from eforo_config") ;
$datos = mysql_fetch_array($resp) ;
$administrador = $datos[administrador] ;
$administrador_email = $datos[email] ;
$num_temas = $datos[temas] ;
$num_mensajes = $datos[mensajes] ;
$num_ultimos = $datos[ultimos] ;
$codigo = $datos[codigo] ;
$caretos = $datos[caretos] ;
$url = $datos[url] ;
$censurar = $datos[censurar] ;
$estilo = $datos[estilo] ;
$tam_largo = $datos[avatarlargo] ;
$tam_ancho = $datos[avatarancho] ;
$tam_archivo = $datos[avatartamano] ;
$max_privados = $datos[privados] ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
if(!file_exists("eforo_estilo/$estilo")) {
echo "
<p><b>Error</b>
<p>El estilo seleccionado <b>$estilo</b> no existe en el servidor.
" ;
exit ;
}
$tabla_usuarios = "eforo_usuarios" ;
?>
