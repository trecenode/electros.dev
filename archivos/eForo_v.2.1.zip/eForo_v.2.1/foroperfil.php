<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
// Inicio comprobaci�n usuario
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[contrasena] != $HTTP_COOKIE_VARS[ucontrasena]) {
?>
<script>location="usalir.php"</script>
<?
exit ;
}
mysql_free_result($resp) ;
// Fin comprobaci�n usuario
if($editar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$contrasena = quitar($contrasena) ;
$email = quitar($email) ;
$pais = quitar($pais) ;
$edad = quitar($edad) ;
$sexo = quitar($sexo) ;
$descripcion = quitar($descripcion) ;
$web = quitar($web) ;
$firma = quitar($firma) ;
$avatar = quitar($avatar) ;
if($contrasena != "") { $contrasena = ",contrasena='$contrasena'" ; }
if($archivo != "") {
$resp = mysql_query("select id from $tabla_usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
// Se revisa que la extensi�n del archivo s�lo sea .gif y .jpg
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "gif" && $extensiones[$num] != "jpg") { $error = "S�lo se permiten im�genes .gif y .jpg.<br>" ; }
// Tama�o de la imagen medido en pixeles
move_uploaded_file($archivo,"eforo_imagenes/avatares/defecto.$extensiones[$num]") ;
$tamano = getimagesize("eforo_imagenes/avatares/defecto.$extensiones[$num]") ;
$largo = $tamano[0] ;
$ancho = $tamano[1] ;
if($largo > $tam_largo || $ancho > $tam_ancho) {
unlink("eforo_imagenes/avatares/defecto.$extensiones[$num]") ;
$error .= "El tama�o de la imagen debe ser menor de $tam_largo x $tam_ancho pixeles.<br>" ;
}
// Tama�o del archivo
$tam_actual = $archivo_size / 1000 ;
$tam_limite = $tam_archivo ;
$tam_archivo = $tam_archivo * 1000 ;
if($archivo_size > $tam_archivo) { $error .= "El archivo pesa $tam_actual y debe ser menor de $tam_limite Kb.<br>" ; }
if($error) {
echo "
<style>
body {
font-family: verdana ;
font-size: 10pt ;
}
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
</style>
<p><b>Error</b>
<p>$error
<p><a href=\"javascript:history.back()\">� Regresar</a>
" ;
exit ;
}
rename("eforo_imagenes/avatares/defecto.$extensiones[$num]","eforo_imagenes/avatares/$datos[id].$extensiones[$num]") ;
$avatar = ",avatar='$extensiones[$num]'" ;
}
if($web == "http://") { $web = "" ; }
mysql_query("update $tabla_usuarios set email='$email',pais='$pais',edad='$edad',sexo='$sexo',descripcion='$descripcion',web='$web',firma='$firma'$contrasena$avatar where nick='$HTTP_COOKIE_VARS[unick]'") ;
setcookie("unick",$nick,time()+7776000) ;
echo "Tus datos han sido editados con �xito. Haz click <a href=foro.php>aqu�</a> para regresar al foro.<br><br>" ;
}
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Perfil</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<?
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select * from $tabla_usuarios where nick='$usuario'") ;
$datos = mysql_fetch_array($resp) ;
if($datos[edad] == 0) { $edad = "" ; }
else { $edad = $datos[edad] ; }
if($datos[sexo] == 1) { $sexo = " selected" ; }
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
?>
<p class="t1">Perfil
<p><b>Usuario desde el:</b> <? echo $fecha ?>
<p>En esta secci�n puedes editar tus datos de registro. Si deseas cambiar tu contrase�a debes llenar los campos de Nueva contrase�a
y Confirmar nueva contrase�a. El avatar s�lo debe ser una imagen .gif y .jpg, no medir m�s de <? echo $tam_largo ?> x <? echo $tam_ancho ?> pixeles y no pesar m�s de <? echo $tam_archivo ?> Kb.
<p>Los campos con un asterisco (*) son obligatorios.
<script>
archivo = 0 ;
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo menos 3 caract�res.') ; return false ; }
if(formulario.contrasena.value.length > 0 && formulario.contrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res.') ; return false ; }
if(formulario.contrasena.value != formulario.confirmarcontrasena.value) { alert('La contrase�a no es igual a la contrase�a de confirmaci�n.') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.descripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
if(formulario.firma.value.length > 255) { alert('La firma supera los 255 caract�res.') ; return false ; }
if(archivo == 0) { archivo++ ; } else { alert('Tus datos se est�n enviando por favor espera.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="foroperfil.php?id=<? echo $datos[id] ?>" enctype="multipart/form-data" onsubmit="return revisar()">
<b>* Nick:</b><br>
<input type="text" name="nick" maxlength="20" value="<? echo $datos[nick] ?>" class="form" style="color: #757575" readonly><br>
<b>* Nueva contrase�a:</b><br>
<input type="password" name="contrasena" maxlength="20" class="form"><br>
<b>* Confirmar nueva contrase�a:</b><br>
<input type="password" name="confirmarcontrasena" maxlength="20" class="form"><br>
<b>* Email:</b><br>
<input type="text" name="email" maxlength="40" value="<? echo $datos[email] ?>" class="form"><br>
<b>Pa�s:</b><br>
<input type="text" name="pais" maxlength="20" value="<? echo $datos[pais] ?>" class="form"><br>
<b>Edad:</b><br>
<input type="text" name="edad" maxlength="2" size="3" value="<? echo $edad ?>" class="form"><br>
<b>Sexo:</b><br>
<select name="sexo" class="form">
<option value="0">Masculino
<option value="1"<? echo $sexo ?>>Femenino
</select><br>
<b>Descripci�n:</b><br>
<textarea name="descripcion" cols="30" rows="5" class="form"><? echo $datos[descripcion] ?></textarea><br>
<b>Web:</b><br>
<?
if($datos[web] == "") { $datos[web] = "http://" ; } ;
?>
<input type="text" name="web" value="<? echo $datos[web] ?>" class="form"><br>
<b>Firma:</b><br>
<textarea name="firma" cols="30" rows="5" class="form"><? echo $datos[firma] ?></textarea><br>
<b>Avatar:</b><br>
<input type="file" name="archivo" class="form"><br>
<input type="checkbox" name="borrar" value="1" id="borrar"><label for="borrar">Borrar el avatar</label><br><br>
<input type="submit" name="editar" value="Editar" class="form">
</form>
<?
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
