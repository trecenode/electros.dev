<?
$dbhost = "localhost" ;
$dbuser = "" ;
$dbpass = "" ;
$db = "" ;
$conectar = mysql_connect($dbhost,$dbuser,$dbpass) ; mysql_select_db($db,$conectar) ;
?>