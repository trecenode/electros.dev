<?

/****************************************************************
 *                      Downsistem 1.0                          *
 *                    -------------------                       *
 *   autor                : gOndo                               *
 *   pagina web           : http://www.juegosweb.tk             *
 *   fecha                : 10/09*2003                          *
 *   copyright            : Copyright � gOndo                   *
 *   email                : juegosweb@hotmail.com               *
 *                                                              *
 ***************************************************************/

////   este archivo es para sacar el link de la descargas ////

include("conexio.php");  // conectamos a la Bd


$query = "select * from descargas where id='$id'"; $resp = mysql_query($query); 
$existe = mysql_num_rows($resp);  

if ($existe == 0) { echo "No existe la descarga"; exit(); } 
else { 
      $archivo = mysql_fetch_array($resp); 
      $archivo[id]++; 
      $query = "update descargas set descargas='$archivo[id]' where id='$id'"; mysql_query($query); 
      header("location: $archivo[link]"); 
} 


@mysql_free_result($resp); mysql_close($conecta); 

?>