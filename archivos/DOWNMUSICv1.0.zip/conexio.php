<? 
$dbhost = "localhost"; // host

$dbuser = ""; // usuario

$dbpass = ""; // pass

$db = ""; // nombre de la base de datos

 /* edita estos campos con tus datos */

mysql_connect("$dbhost","$dbuser","$dbpass"); // se conecta con la db
mysql_select_db("$db");


?>
