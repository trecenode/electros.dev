<?
include("conexio.php") ;//incluismos la cagada esta de config qeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
include("config.php") ;
if($e) {
$resp = mysql_query("select urlsitio from descargas where id='$e'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) != 0) {
mysql_query("update descargas set visitas=visitas+1 where id='$e'") ;
?>
<script>window.open("<? echo $datos[urlsitio] ?>",'HomeMM','width=780,height=590,location=no,menubar=no,statusbar=yes,toolbar=no,scrollbars=yes,resizable=yes')</script>
<?
}
else {
echo "No se encuentra la descarga" ;
}
}
if($calificar == "si") {
echo "<p><b>Has votado por la descarga</b>" ;
}
if($calificar == "no") {
echo "<p><b>S�lo puedes votar una vez por d�a.</b>" ;
}
?>
<p class="t1">&nbsp;</p>
<?
$mostrar = 10 ;
$resp = mysql_query("select id from descargas where categoria='$c'") ;
$descargas = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
?>
<p><b><font color="#FF0000">Total de Descargas:</font></b><font color="#FF0000"> <? echo $descargas ?> 
</font> 
<p>
<font color="#FF0000">
<?
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from descargas where categoria='$c' order by titulo asc limit $desde,$mostrar") ;
$desde = $desde + mostrar ;
while($datos = mysql_fetch_array($resp)) {
?>
</font>
<div align="center">
  <center>
    <table width="428" border="0" cellspacing="1" bgcolor="#FFFFFF" id="AutoNumber4">
      <tr> 
        <td width="99%" height="20"> <div align="left"> 
            <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
              <tr> 
                <td width="99%" height="14" bgcolor="#000000"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td bgcolor="#6B6B6B"><img src="../../imagenes/bullet.gif" width="6" height="7"><font color="#FF0000"><font face="Verdana" size="1"><a href="index.php?id=modulos/Decargas/info&sec=<? echo $datos[id] ?>"><? echo $datos[titulo] ?></a></font></font></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#6B6B6B"><strong><font color="#FFFFFF" size="1" face="Verdana"><? echo $datos[tipo] ?>&nbsp;|<? echo $datos[tamano] ?>Mb</font></strong></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
          </div></td>
      </tr>
    </table>
    <p></p>
</center>
</div>
<p><br>
<?
}
mysql_free_result($resp) ;
}
else {
?>
  <?
$resp = mysql_query("select id from descargas where categoria=0") ;
$c0 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=1") ;
$c1 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=2") ;
$c2 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=3") ;
$c3 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=4") ;
$c4 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=5") ;
$c5 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=6") ;
$c6 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=7") ;
$c7 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=8") ;
$c8 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=9") ;
$c9 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=10") ;
$c10 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=11") ;
$c11 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from descargas where categoria=12") ;
$c12 = mysql_num_rows($resp) ;
?>
</p>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td><img src="imagenes/stl.gif" width="24" height="33" border="0" alt=""></td>
    <td width="100%" background="imagenes/sbg.gif">&nbsp;</td>
    <td><img src="imagenes/srt.gif" width="62" height="33" border="0" alt=""></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td><img name="stlc" src="imagenes/stlc.gif" width="5" height="10" border="0" alt=""></td>
    <td width="100%" background="imagenes/stm.gif"><img name="stm" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="strc" src="imagenes/strc.gif" width="5" height="10" border="0" alt=""></td>
  </tr>
  <tr> 
    <td background="imagenes/sleft.gif"><img name="sleft" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td valign="top" bgcolor="#555555"><strong><form method="post" action="index.php?id=modulos/Descargas/descargasbuscar" form name="formulario" >
                <div style="position: absolute ; visibility: hidden"> 
                  <input type="text" name="aaa2" size="20" style="font-family: Verdana; font-size: 8pt; color: #FF0000; border: 1px outset #FF0000">
                </div>
                      <div align="center"><img src="logo.gif" width="310" height="50"> 
                      </div>
                      <p align="center"> 
                  
    <input name="palabras2" type="text" class="form" style="font-family: Verdana; font-size: 8pt; color: #C0C0C0; border: 1px outset #FFFFFF; " value="Palabra a buscar" size="30" maxlength="65">
                </p>
                <p align="center"> 
                  <input type="submit" name="buscar2" value="Buscar" class="form " style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF; ">
                    </form></strong>&nbsp; </td>
    <td background="imagenes/sright.gif"><img name="sright" src="themes/DarkX/images/spacer.gif" width="1" height="1" border="0" alt=""></td>
  </tr>
  <tr> 
    <td height="25"><img name="sblc" src="imagenes/sblc.gif" width="5" height="25" border="0" alt=""></td>
    <td background="imagenes/sbtm.gif"><img name="sbtm" src="themes/DarkX/images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="sbrc" src="imagenes/sbrc.gif" width="5" height="25" border="0" alt=""></td>
  </tr>
</table>
<p>&nbsp;</p><table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td><img src="imagenes/stl.gif" width="24" height="33" border="0" alt=""></td>
    <td width="100%" background="imagenes/sbg.gif">
      
    </td>
    <td><img src="imagenes/srt.gif" width="62" height="33" border="0" alt=""></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td><img name="stlc" src="imagenes/stlc.gif" width="5" height="10" border="0" alt=""></td>
    <td width="100%" background="imagenes/stm.gif"><img name="stm" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="strc" src="imagenes/strc.gif" width="5" height="10" border="0" alt=""></td>
  </tr>
  <tr> 
    <td background="imagenes/sleft.gif"><img name="sleft" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td valign="top" bgcolor="#555555"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td colspan="2" background="imagenes/barraone.jpg"><font size="1" face="Verdana">TEMAS 
            MP3</font></td>
        </tr>
        <tr> 
          <td width="98%"><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=0">Trance/Progressive</a></font></td>
          <td width="2%"><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c0 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=1">Dance/Vocales</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c1 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=2">Hardhouse/Bumpin</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c2 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=3">M&aacute;kina/Hardcore</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c3 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=4">Hardstyle</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c4 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=5">House</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c5 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=6">Techno</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c6 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=7">Remember</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c7 ?></font></b></font></td>
        </tr>
        <tr> 
          <td><font size="1" face="Verdana"><img src="imagenes/bullet.gif" width="6" height="7"><a href="index.php?id=modulos/Descargas/index&c=8">Jumper</a></font></td>
          <td><font size="1" face="Verdana"><b><font color="#FFFFFF"><? echo $c8 ?></font></b></font></td>
        </tr>
      </table> </td>
    <td background="imagenes/sright.gif"><img name="sright" src="themes/DarkX/images/spacer.gif" width="1" height="1" border="0" alt=""></td>
  </tr>
  <tr> 
    <td height="25"><img name="sblc" src="imagenes/sblc.gif" width="5" height="25" border="0" alt=""></td>
    <td background="imagenes/sbtm.gif"><img name="sbtm" src="themes/DarkX/images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="sbrc" src="imagenes/sbrc.gif" width="5" height="25" border="0" alt=""></td>
  </tr>
</table>
<p align="center" class="t1"><font color="#FFFFFF" size="2" face="Verdana">&Uacute;ltimas 10 descargas 
  subidas </font> 
<p>
<font color="#FF0000">
<?
$mostrar = 10 ;
$resp = mysql_query("select * from descargas order by id desc limit $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
?>
</font>
<div align="center">
  <center>
    <table width="428" border="0" cellspacing="1" bgcolor="#FFFFFF" id="AutoNumber4">
      <tr> 
        <td width="99%" height="20"> <div align="left"> 
            <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
              <tr> 
                <td width="99%" height="14" bgcolor="#000000"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td bgcolor="#6B6B6B"><img src="../../imagenes/bullet.gif" width="6" height="7"><font color="#FF0000"><font face="Verdana" size="1"><a href="index.php?id=modulos/Decargas/info&sec=<? echo $datos[id] ?>"><? echo $datos[titulo] ?></a></font></font></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#6B6B6B"><strong><font color="#FFFFFF" size="1" face="Verdana"><? echo $datos[tipo] ?>&nbsp;|<? echo $datos[tamano] ?>Mb</font></strong></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
          </div></td>
      </tr>
    </table>
  </center>
</div>
<br>
<?
}
mysql_free_result($resp) ;
?>
<?
}
?>