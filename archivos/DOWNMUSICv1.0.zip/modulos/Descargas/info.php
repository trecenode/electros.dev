<?
include('conexio.php');
if(!isset($id))
{
echo 'no se ha seleccionado ninguna descarga'; //  aqui comprovamos que seleccionamos alguna id 
}else{
$query=mysql_query("SELECT * FROM descargas WHERE id='$sec' ");
if($datos=mysql_fetch_array($query) )
{
// ya esta todo comprobado, mostramos los datos 
$link = "mirror.php?id=$id";
echo '<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td><img src="imagenes/stl.gif" width="24" height="33" border="0" alt=""></td>
    <td width="100%" background="imagenes/sbg.gif"> <div align="left"></div></td>
    <td><img src="imagenes/srt.gif" width="62" height="33" border="0" alt=""></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr> 
    <td height="11"><img name="stlc" src="imagenes/stlc.gif" width="5" height="10" border="0" alt=""></td>
    <td width="100%" background="imagenes/stm.gif"><img name="stm" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="strc" src="imagenes/strc.gif" width="5" height="10" border="0" alt=""></td>
  </tr>
  <tr> 
    <td background="imagenes/sleft.gif"><img name="sleft" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td valign="top" bgcolor="#555555"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="98%"> <div align="center"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">T&iacute;tulo:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["titulo"].'</b></strong></span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Uploader:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["autor"].'</b></strong></span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Tama&ntilde;o:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["tamano"].'</b></strong>Mb</span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Email 
                    del autor:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["autormail"].'</b></strong></span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Calidad:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["calidad"].' 
                    </b></strong>Kbps </span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Estilo:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["estilo"].'</b></strong></span></font></td>
                </tr>
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Tipo:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["tipo"].'</b></strong></span></font></td>
                </tr>
                <tr>
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FFFFFF" size="1" face="Verdana">Extensi&oacute;n:<span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["ext"].'</b></strong></span></font></td>
                </tr>
              </table>
              <table width="95%" border="0" align="center" cellspacing="1" bgcolor="#000000" id="AutoNumber4">
                <tr> 
                  <td width="99%"> <div align="left"> 
                      <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
                        <tr> 
                          <td width="99%" bgcolor="#828282"> <div align="left"><font color="#FFFFFF" size="1" face="Verdana"><span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["descripcion"].'</b></strong></span></font></div></td>
                        </tr>
                      </table>
                    </div></td>
                </tr>
      </table>
            </div></td>
        </tr>
        <tr> 
          <td><img src="imagenes/baja.gif" width="15" height="15"><font size="1" face="Verdana"><a href="'.$link.'">DESCARGAR 
            TEMA</a></font></td>
        </tr>
        <tr>
          <td><table width="95%" border="0" align="center" cellspacing="1" bgcolor="#000000" id="AutoNumber4">
              <tr> 
                <td width="99%"> <div align="left"> 
                    <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
                      <tr> 
                        <td width="99%" background="imagenes/barraone.jpg" bgcolor="#828282"> 
                          <div align="center"><font color="#FFFFFF" size="1" face="Verdana"><span style="FONT-SIZE: 8pt"><strong>::INSTRUCCIONES::</strong></span></font></div></td>
                      </tr>
                    </table>
                  </div></td>
              </tr>
            </table>
            <table width="95%" border="0" align="center" cellspacing="1" bgcolor="#000000" id="AutoNumber4">
              <tr> 
                <td width="99%"> <div align="left"> 
                    <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
                      <tr> 
                        <td width="99%" bgcolor="#828282"> <div align="center"><font color="#FFFFFF" size="1" face="Verdana"><span style="FONT-SIZE: 8pt"><strong style="font-weight: 400"><b>'.$datos["instruc"].'</b></strong></span></font></div></td>
                      </tr>
                    </table>
                  </div></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td background="imagenes/sright.gif">&nbsp;</td>
  </tr>
  <tr> 
    <td height="25"><img name="sblc" src="imagenes/sblc.gif" width="5" height="25" border="0" alt=""></td>
    <td background="imagenes/sbtm.gif"><img name="sbtm" src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td><img name="sbrc" src="imagenes/sbrc.gif" width="5" height="25" border="0" alt=""></td>
  </tr>
</table>';
}else{
echo 'la descargas seleccionada no existe';
}
} 

?>