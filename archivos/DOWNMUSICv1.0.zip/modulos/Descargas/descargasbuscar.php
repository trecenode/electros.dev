<table width="428" border="0" align="center" cellspacing="1" bgcolor="#FF0000" id="AutoNumber4">
  <tr> 
    <td width="99%" height="20"> <div align="left"> 
        <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
          <tr> 
            <td width="99%" height="14" bgcolor="#000000"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><form method="post" action="../../index.php?id=descargasbuscar" form name="formulario" >
                <div style="position: absolute ; visibility: hidden"> 
                  <input type="text" name="aaa2" size="20" style="font-family: Verdana; font-size: 8pt; color: #FF0000; border: 1px outset #FF0000">
                </div>
                      <div align="center"><img src="imagenes/logo.gif" width="310" height="50"> 
                      </div>
                      <p align="center"> 
                  
    <input name="palabras2" type="text" class="form" style="font-family: Verdana; font-size: 8pt; color: #FF0000; border: 1px outset #FF0000" value="Palabra a buscar" size="30" maxlength="65">
                </p>
                <p align="center"> 
                  <input type="submit" name="buscar2" value="Buscar" class="form " style="font-family: Verdana; font-size: 8pt; color: #FF0000; border: 1px outset #FF0000">
              </form>
                    &nbsp; </td>
                </tr>
              </table></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<table width="428" border="0" align="center" cellspacing="1" bgcolor="#FF0000" id="AutoNumber4">
  <tr> 
    <td width="99%" height="20"> <div align="left"> 
        <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
          <tr> 
            <td width="99%" height="14" bgcolor="#000000"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><?
if($buscar) {
include("../../config.php") ;
$resp = mysql_query("select * from descargas where descripcion like '%$palabras%'") ;
if(mysql_num_rows($resp) == 0) {
echo "No se encontraron resultados en la b�squeda." ;
}
else {
while($datos = mysql_fetch_array($resp)) {
echo "
<table width="428" border="0" cellspacing="1" bgcolor="#FF0000" id="AutoNumber4">
  <tr> 
    <td width="99%" height="20"> <div align="left"> 
        <table border="0" cellspacing="1" id="AutoNumber5" style="font-family: Verdana; font-size: 8pt; color: #FFFFFF; border: 1px outset #FFFFFF" bgcolor="#000000" width="100%">
          <tr> 
            <td width="99%" height="14" bgcolor="#000000"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td><img src="imagenes/bullet.gif" width="6" height="7"><font color="#FF0000"><font face="Verdana" size="1"><a href="file:///C|/Documents%20and%20Settings/Eduardo/Mis%20documentos/Mijn%20webs/Dreaversound/index.php?id=info&sec=<? echo $datos[id] ?>
<p>"><? echo $datos[nombre] ?></a></font></font></td> </tr> </table></td> </tr> </table> </div></td> </tr> </table>
  <br>
  " ; 
  } 
  } 
  } 
  ?>&nbsp;</td>
                </tr>
              </table></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<p>&nbsp; </p>
