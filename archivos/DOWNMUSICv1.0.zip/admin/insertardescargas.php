<?

/****************************************************************
 *                      Downsistem 1.0                          *
 *                    -------------------                       *
 *   autor                : gOndo                               *
 *   pagina web           : http://www.juegosweb.tk             *
 *   fecha                : 10/09*2003                          *
 *   copyright            : Copyright � gOndo                   *
 *   email                : juegosweb@hotmail.com               *
 *                                                              *
 ***************************************************************/

// esta archivo insertara los datos del formulario a la base de datos

include('../conexio.php'); //incluimos el config.php que contiene los datos de la conexi�n a la db



//introducimos la descarga en la base de datos
mysql_query("INSERT INTO descargas (titulo,autor,link,descripcion,tamano,categoria,autormail,calidad,estilo,tipo,instruc,ext,puntos,votos,calificacion) values ('$titulo','$autor','$link','$descripcion','$tamano','$cateroria','$autormail','$calidad','$estilo','$tipo','$instruc','$ext','5','1','5') "); 
echo 'Descargas Ingresada con exito'; 


?>
