<form action="admin/insertardescargas.php" method="POST">
  <p><font color="#FFFFFF" size="1" face="Verdana">Nombre del tema: 
    <input name="titulo" type="text" id="titulo" size="30">
    <br>
    Tu nick: 
    <select name="autor" id="autor">
      <option selected>--ELIGE--</option>
      <option value="Guso">Guso</option>
      <option value="Edudj">Edudj</option>
    </select>
    <br>
    lURL: 
    <input type="text" name="link" size="50">
    <br>
    Descripcion
<textarea name="descripcion" cols="30" rows="10"></textarea>
    <br>
    Tama&ntilde;o: 
    <input name="tamano" type="text" id="tamano" size="30">
    Mb</font></p>
  <p><font size="1" face="Verdana"> Categoria: 
    <select name='categoria' class='form'>
      <option selected>[..ELIGE UNA..]</option>
      <option value="0">Manuales </option>
      <option value="1">Paginas afiliadas </option>
      <option value="2">programas </option>
      <option value="5">Pagina en webcindario </option>
      <option value="6">Paginas recomendadas </option>
      <option value="7">Servidores </option>
    </select>
    </font></p>
  <p><font size="1" face="Verdana">Email del autor:</font><font color="#FFFFFF" size="1" face="Verdana"> 
    <input name="autormail" type="text" id="autormail" value="name@dominio.com" size="30">
    </font></p>
  <p><font color="#FFFFFF" size="1" face="Verdana">Calidad:</font><font size="1" face="Verdana"> 
    <input name="calidad" type="text" id="calidad" size="30">
    Kbps </font></p>
  <p><font size="1" face="Verdana">Estilo: 
    <select name="estilo" id="estilo">
      <option selected>--ELIGE--</option>
      <option value="Trance/Progressive">Trance/Progressive</option>
      <option value="Hardhouse/Bumpin">Hardhouse/Bumpin</option>
      <option value="M&aacute;kina/Hardcore">M&aacute;kina/Hardcore</option>
      <option value="Jumper">Jumper</option>
      <option value="Remember">Remember</option>
      <option value="Techno">Techno</option>
      <option value="Cantaditas/Vocales">Cantaditas/Vocales</option>
    </select>
    </font></p>
  <p><font size="1" face="Verdana">Tipo: 
    <select name="tipo" id="tipo">
      <option selected>--ELIGE--</option>
      <option value="XOOM">XOOM</option>
      <option value="Descarga directa">Descarga directa</option>
    </select>
    </font></p>
  <p><font size="1" face="Verdana">Extension:
    <select name="ext" id="ext">
      <option selected>--ELIGE UNA--</option>
      <option value=".mp3">.mp3</option>
      <option value=".ogg">.ogg</option>
      <option value=".zip">.zip</option>
      <option value=".rar">.rar</option>
    </select>
    </font></p>
  <p><font size="1" face="Verdana">Instrucciones:
    <select name="instruc" id="instruc">
      <option value="Descarga directa con un gestor de descargas" selected>Descarga 
      directa</option>
      <option value="Descarga desde XOOM">XOOM</option>
      <option value="Renombrar a .mp3">Renombrar a .mp3</option>
      <option value="Renombrar a .zip">Renombrar a .zip</option>
      <option value="Renombrar a .rar">Renombrar a .rar</option>
      <option value="Renombrar a .ogg">Renombrar a .ogg</option>
    </select>
    </font></p>
  <p><br>
    <input type="submit" name="submit" value="Enviar">
  </p>
</form><br>