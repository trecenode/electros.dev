<?
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes",
"S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
"Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w) ;
$diames = date(j) ;
$mesano = date(n) - 1 ;
$ano = date(Y) ;
$fechadehoy = "Hoy es $diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
echo $fechadehoy ;
?>