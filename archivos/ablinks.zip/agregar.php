<title>AGREGAR LINKS</title>
<div align="center">En este formulario podras agregar links, los que quieras, solo introduce los datos correctos</div>
<p><script>
function revisar() {
if(formulario.titulo.value.length < 3) { alert('Debes introducir un Titulo') ; return false ; }
if(formulario.url.value.length < 9) { alert('Debes introducir una Url') ; return false ; }
if(formulario.descripcion.value.length == 0) { alert('Debes introducir una descripcion') ; return false ; }
}
</script>
<div align="center">
<?
if($enviar) {
include("config.php") ;
$fecha = time() - 25200 ;
mysql_query("insert into agregarlinks (id,fecha,titulo,usuario,url,descripcion) values ('$id','$fecha','$titulo','$usuario','$url','$descripcion')") ;
echo "Tu pagina web ha sido agregada vuelve <a href=buscar.php>aqui</a> para buscar el link agregado" ;
}
else {
?>
<form method="post" action="agregar.php" form name="formulario"  onsubmit="return revisar()">
<font color="#000000">Usuario:</font><br>
<input type="text" name="usuario" maxlength="40" class="form"><p>
<font color="#000000">Titulo:</font><br>
<input type="text" name="titulo" maxlength="40" class="form"><p>
<font color="#000000">URL:</font><br>
<input type="text" name="url" maxlength="200" value="http://" class="form"><p>
<font color="#000000">Descripci�n:</font><br>
<textarea name="descripcion" cols="30" rows="5" maxlength="20" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
?></div>