<? 
include("config.php") ;
$resp = mysql_query("select url from agregarlinks where id=$id") ; 
$datos = mysql_fetch_array($resp) ; 
if(mysql_num_rows($resp) != 0) { 
mysql_query("update agregarlinks set visitas=visitas+1 where id=$id") ; 
header("location: $datos[url]") ; 
} 
else { 
echo "No existe el enlace" ; 
} 
?>