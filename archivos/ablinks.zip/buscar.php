<title>BUSCAR LINKS</title>
<div align="center">Ingresa la descripcion del link ah buscar.</div>
<p><script>
function revisar() {
if(formulario.palabras.value.length < 3) { alert('Debes introducir un Titulo de busqueda') ; return false ; }
}
</script>
<div align="center"><b><div align="center">
<form method="post" action="buscar.php" form name="formulario"  onsubmit="return revisar()">
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="palabras" size="30" maxlength="65" class="form"><p>
<input type="submit" name="buscar" value="Buscar" class="form">
</form>
<?
if($buscar) {
include("config.php") ;
$resp = mysql_query("select *from agregarlinks where descripcion like '%$palabras%'") ;
if(mysql_num_rows($resp) == 0) {
echo "No se encontraron resultados en la b�squeda." ;
}
else {
while($datos = mysql_fetch_array($resp)) {
echo "
<table border=1 background=imagenes/fondo_1.gif width=100%>
	<tr>
		<td><a href=enlaces.php?id=$datos[id] target=\"_blank\">$datos[titulo]</a><br></td>
	</tr>
	<tr>
		<td><b><span style=\"color: #cc6600\">Descripcion:</b></span><span style=\"color: #000000\">$datos[descripcion]</span></td>
	</tr>
	<tr>
		<td><b><span style=\"color: #cc6600\">Enviado por:</b></span> <span style=\"color: #000000\">$datos[usuario]<br></span></td>
	</tr>
	<tr>
			<td><b><span style=\"color: #cc6600\">Visitas:</b></span> <span style=\"color: #000000\">$datos[visitas]<br></span></td>
</table><br>

" ;
}
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
}
?>
</div>