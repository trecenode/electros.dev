<?
$db = mysql_connect("$dbhost","$user","$pass") or die ("Can't connect to mySQL server");
mysql_select_db ("$dbname") or die (mysql_error());
?>