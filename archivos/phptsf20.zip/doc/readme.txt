  PHP TopSites FREE
  Version 2.0 beta - 12/17/2002
  http://www.itop10.net

  Copyright (C) 2000-2002 iTop10.Net <support@itop10.net>


COPYRIGHT NOTICE:
----------------------------------------------------
This script is being offered as freeware. It may be used and
modified free of charge for personal, non-profit and academic 
use under the following conditions:

    1. The 'Powered By PHP TopSites' text
       remains/is placed on the bottom of the list pages.
    2. The text is linked to:
            http://itop10.net/product

Selling the code for this program, or a program derived from Links, without 
prior written consent is expressly forbidden. Similarly, redistributing
this program, or a program derived from Links, over the Internet, CD-Rom 
or any other medium is expressly forbidden without prior written consent. 
By using this program you agree to indemnify iTop10.Net. 
from any liability.


	1. Requirements
	2. Features
	3. Quick Install
	4. Support
	5. Other Products



Requirements:
----------------------------------------
* OS: Unix, Linux, Windows 9x/Me, Windows NT/2000
* WWW Server: Apache 1.3x+ or other
* PHP: PHP3.0+
* MySQL: 3.23.xx+
* Basic knowledge of html, php & mysql

Features:
----------------------------------------
* Unlimited Number of Sites.
* Unlimited Number of Categories.
* Unlimited Number of Reviews for Each Site.
* Administrator Control Panel.
* Rating for Each Site.
* 'Stars' Rating for Each Site.


Quick Install:
----------------------------------------
[1] UnTar and UnZip the distribution and make sure you keep the file-structure

[2] Open the file config.php and edit $dbhost, $dbname, $user, $pass and all other variables.

[3] Upload all files
    Make sure your /phptopsites/admin/ directory is password protected with .htaccess.

[4] Create MySQL database for PHP TopSites FREE (Example phptop)

[5] Click 'Setup' link in admin area from your browser to install MySQL Tables.

[6] Click 'Install Tables' link in admin area from your browser to install MySQL Tables.

[7] Set chmod 666 for config.php , for admin/reset.txt and for admin/count.txt

[8] Edit rules for your top list in rules.php file.

[9] Insert your advertising HTML code to ads1.html and ads2.html

[10] Edit header.php and footer.php

[11] Click 'Check Vars' link in admin area.

Support, Suggestions & Bugs Report:
----------------------------------------
Please don't hesitate to contact with us for bugs discussion and solution.
http://itop10.net/support/
----------------------------------------
