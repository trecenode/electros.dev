		</td>
	</tr>
	</table>
	<br><br>
	</td>
</tr>
</table>
</body>
</html>
<? @mysql_close($db);?>
