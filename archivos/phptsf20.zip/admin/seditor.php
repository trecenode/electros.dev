<?
include "../config.php";
include "header.php";
?>
<center>
<form action="seditor.php" method="post">
	Search by 
	<select name=field>
	<option <?if ($field=="description") echo "selected";?> value="description">Description</option>
	<option <?if ($field=="name") echo "selected";?> value="name">Owner Name</option>
	<option <?if ($field=="email") echo "selected";?> value="email">Owner Email</option>
	<option <?if ($field=="url") echo "selected";?> value="url">Site Url</option>
	<option <?if ($field=="title") echo "selected";?> value="title">Site Title</option>
	<option <?if ($field=="sid") echo "selected";?> value="sid">Site ID</option>
	</select>
	<input type=text name=que value="<? echo $que;?>"><BR>
	<input type=submit name=submit>
</form>
</center>
<?
if ($que AND !$a) {
	?>
	<table align=center border=1 cellpadding=3 cellspacing=0>
	<tr>
		<td align=center bgcolor="#5087AF"><B><font face=verdana size=2 color="white">Site ID:</font></B></td>
		<td align=center bgcolor="#5087AF"><B><font face=verdana size=2 color="white">Site Title:</font></B></td>
		<td align=center bgcolor="#5087AF"><B><font face=verdana size=2 color="white">Action:</font></B></td>
		<td align=center bgcolor="#5087AF"><B><font face=verdana size=2 color="white">Reviews:</font></B></td>
	</tr>
	<?
	$query = mysql_query ("select sid,title from top_user where $field like '%$que%' order by sid",$db) or die("Sites Database SELECT Error");
	while ($rows = mysql_fetch_array($query)) {
		echo "<tr>
			<td><font face=verdana size=2>$rows[sid]</font></td>
			<td><font face=verdana size=2>$rows[title]</font></td>
			<td><font face=verdana size=2><a href=\"seditor.php?sid=$rows[sid]&a=edit\">Edit</a> | <a href=\"seditor.php?sid=$rows[sid]&a=delete\">Delete</a></font></td>
			<td><font face=verdana size=2><a href=\"reditor.php?sid=$rows[sid]&a=edit\">Edit</a> | <a href=\"reditor.php?sid=$rows[sid]&a=edit\">Delete</a></font></td>
		      </tr>";
	}
	?>
	</table>
	<?
}
if ($sid AND $a) {
	if ($a == "edit") {
		$query = mysql_db_query ($dbname,"select * from top_user where sid=$sid",$db) or die (mysql_error());
		$rows = mysql_fetch_array($query);
		?>
		<Table Align="center" Border="1" Width="400" CellPadding="3" CellSpacing="0">
		<tr>
		<td>
			<form action="seditor.php" method="post">
			User Name:<BR>
			<input type="text" name="name" value="<? echo $rows[name]?>"><BR>
			Password:<BR>
			<input type="text" name="passw" value="<? echo $rows[password]?>"><BR>
			Email Address:<BR>
			<input type="text" name="email" value="<? echo $rows[email]?>"><BR>
			Site Title:<BR>
			<input size=50 type="text" name="title" value="<? echo $rows[title]?>"><BR>
			Site URL:<BR>
			<input size=50 type="text" name="url" value="<? echo $rows[url]?>"><BR>
			Link Back URL:<BR>
			<input size=50 type="text" name="linkback" value="<? echo $rows[linkback]?>"><BR>
			Banner URL:<BR>
			<input size=50 type="text" name="banner_url" value="<? echo $rows[banner]?>"><BR>
			<hr><center>
			<IMG SRC="<? echo $rows[banner];?>" border=0></center>
			<hr>
			Current Width for any Banner is <? echo $max_banner_width;?><BR>
			<input size="4" type="text" name="banner_w" value="<? echo $max_banner_width;?>"><BR>
			Current Height for any Banner is <? echo $max_banner_height;?><BR>
			<input size="4" type="text" name="banner_h" value="<? echo $max_banner_height;?>"><BR>
			Site Description:<BR>
			<input size="50" type="text" name="description" value="<? echo $rows[description]?>"><BR>
			Hits OUT:<BR>
			<input size="10" type="text" name="thout" value="<? echo $rows[thout]?>"><BR>
			STATUS:<BR>
			<select name=status>
			<? if ($rows[status] == "Y") echo "<option value=Y selected>OK</option>"; else echo "<option value=Y>OK</option>"?>
			<? if ($rows[status] == "N") echo "<option value=N selected>Waiting for Validation</option>"; else echo "<option value=N>Waiting for Validation</option>"?>
			</select><BR>
			Set site as a Hot:<BR>
			<select name=stars>
			<? if ($rows[stars] == 0) echo "<option value=1 selected>No</option>"; else echo "<option value=1>No</option>"?>
			<? if ($rows[stars] >= 1) echo "<option value=2 selected>Yes</option>"; else echo "<option value=2>Yes</option>"?>
			</select><BR>
			Site Category:<BR>
			<select name=category>
			<?
			$query = mysql_db_query ($dbname,"select * from top_cats order by catname",$db) or die (mysql_error());
			while ($rowss = mysql_fetch_array($query))
			{
				echo "<option value=$rowss[cid]";
				if ($rows[category] == $rowss[cid]) {echo " selected";}
				echo ">$rowss[catname]</option><BR>";
			}
			?>
			</select><BR>
			<font color="<? echo $font_color;?>" face="<? echo $font_face;?>" size="<? echo $font_size;?>">Country:</font><BR>
			<select name=country>
			<?
			$handle=opendir("../images/flags");
			while (false!==($file = readdir($handle))) { 
			    if ($file != "." && $file != "..") { 
				$country = substr($file,0,strpos($file,'.'));
				echo "<option value=\"".$file."\" ";
				if ($rows[country] == $file) echo "selected";
				echo ">".$country."</option>\n";
			    } 
			}
			closedir($handle); 
			?>
			</select>
			</font>
			<BR>
			<center>
			<BR>
			<input type="submit" name="submit">
			<input type=hidden name=sid value="<? echo $rows[sid]?>">
			<input type=hidden name=a value="update">
			</center>
			</form>
		</td>
		</tr>
		</Table>
		<?		
	}
	if ($a == "update") {
		$query = mysql_db_query ($dbname,"Update top_user set name='$name',password='$passw',email='$email',title='$title',url='$url',banner='$banner_url',bannerw=$banner_w,bannerh=$banner_h,description='$description',category=$category,thout=$thout,stars=$stars,country='$country',status='$status',linkback='$linkback' Where sid=$sid",$db) or die(mysql_error());
		echo "Site has been updated.<BR>";
	}
	if ($a == "delete") {
		mysql_db_query ($dbname,"delete from top_user where sid=$sid",$db) or die (mysql_error());
		mysql_db_query ($dbname,"delete from top_hits where sid=$sid",$db) or die (mysql_error());
		mysql_db_query ($dbname,"delete from top_review where sid=$sid",$db) or die (mysql_error());
	}
}
include "footer.php";
?>