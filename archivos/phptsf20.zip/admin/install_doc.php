<?
include "header.php";
?>
<p align="center"><font face="verdana" size="2"><br>
</font><font face="verdana" size="3"><b>PHP TopSites FREE Installtion</b></font></p>
  <center>
  <table border="0" cellpadding="5" width="90%" cellspacing="5">
    <tr>
      <td width="100%"><font face="verdana" size="2"><b>PHP TopSites FREE
        Installation</b></font>
      </td>
    </tr>
    <tr>
      <td width="100%"><font face="verdana" size="2">
<BR>
<OL>
<LI>At this point it is assumed you have extracted the archive containing PHP TopSites FREE. If you have not yet done so, you should do that now.<BR>
<BR>
You should also have the following information:<BR>
<BR>
- The name of the mySQL database which you will be using to store the data<BR>
- The username which you use to access the mySQL database<BR>
- The password which you use to access the mySQL database<BR>
<BR>
If you do not have this information, contact your server administrator to get it.<BR>
<BR>
</LI>
<LI>You will now need to login to your server and create some directories for PHP TopSites FREE. You will need to create next directory structure:<BR>
<BR>
<B>Example Directory Structure: </B>
<BR>
/home/username/toplist <BR>
/home/username/toplist/admin<BR>
/home/username/toplist/images<BR>
/home/username/toplist/images/flags<BR>
/home/username/toplist/tmpl<BR>
<BR>
Note: The only files you should place in these directories are the ones indicated in this documentation. Uploading other files can and will cause problems.<BR>
<BR>
</LI>
<BR>
</LI>
<LI>Now you are ready to begin uploading the files to your server. On most servers it is not necessary to upload the files in ASCII mode, however we recommend that you do so anyway. 
<BR>
Below is a table of where each file should be uploaded, using the example directory structure above:<BR>
<BR>
<B>/toplist</B><BR>
style.css<BR>
add.php<BR>
config.php<BR>
counter.php<BR>
edit.php<BR>
footer.php<BR>
forgot.php<BR>
header.php<BR>
help.php<BR>
in.php<BR>
index.php<BR>
new.php<BR>
out.php<BR>
random.php<BR>
rate.php<BR>
recommend.php<BR>
review.php<BR>
<BR>
<B>/toplist/admin</B><BR>
index.html<BR>
ceditor.php<BR>
check.php<BR>
clean.php<BR>
footer.php<BR>
header.php<BR>
install.php<BR>
menu.php<BR>
reditor.php<BR>
seditor.php<BR>
validate.php<BR>
templates.php<BR>
security.php<BR>
install_doc.php<BR>
setup.php<BR>
<BR>
<B>/toplist/images</B><BR>
All other .gif files<BR>
<BR>
<B>/toplist/images/flags</B><BR>
All Flags .gif files<BR>
<BR>
<B>/toplist/tmpl</B><BR>
All .phtml files<BR>
<BR>
</LI>
<LI>Next, you will need to set permissions on the directories and files that PHP TopSites FREE will be using. If you are not sure how to set permissions, consult the documentation for your FTP client and/or contact your server administrator for more information. Below is a table containing the permissions you will need to set on each directory or file.<BR>
<BR>
              <TABLE cellSpacing=1 cellPadding=3 border=0>
                <TBODY>
                <TR>
                  <TD align=middle bgColor=#afafaf><FONT face=Verdana 
                    size=1><B>File or Directory</B></FONT></TD>
                  <TD align=middle bgColor=#afafaf><FONT face=Verdana 
                    size=1><B>Permissions</B></FONT></TD></TR>
                <TR>
                  <TD bgColor=#dcdcdc><FONT face=verdana size=1>config.php</FONT></TD>
                  <TD align=middle bgColor=#dcdcdc><FONT face=Verdana 
                    size=1>777</FONT></TD></TR>
                <TR>
                  <TD bgColor=#dcdcdc><FONT face=Verdana size=1>Directory 
                    Containing the .php files</FONT></TD>
                  <TD align=middle bgColor=#dcdcdc><FONT face=Verdana 
                    size=1>711</FONT></TD></TR>
                <TR>
                  <TD bgColor=#dcdcdc><FONT face=Verdana size=1>admin 
                    Directory</FONT></TD>
                  <TD align=middle bgColor=#dcdcdc><FONT face=Verdana 
                    size=1>711</FONT></TD></TR>
                <TR>
                  <TD bgColor=#dcdcdc><FONT face=Verdana size=1>images 
                    Directory</FONT></TD>
                  <TD align=middle bgColor=#dcdcdc><FONT face=Verdana 
                    size=1>711</FONT></TD></TR>
		</TBODY></TABLE>
<BR>
These are only the recommended file permissions, and may need to be altered depending on your server configuration. Once you have all permissions set, continue to the next step.<BR>
<BR>
</LI>
<LI>Next you need to setup all variables. Click to 'Setup' on the left menu.<BR>
<BR>
</LI>
<LI>
Now Install MySQL Tables. Click to 'Install Tables' on the left menu.<BR>
<BR>
</LI>
<LI>Help Prevent Software Piracy<BR>
If you have uploaded the PHP TopSites FREE zip (or tar or tar.gz) file to your server, remove it now. Leaving it on your server provides a chance for other users to steal it from your web space. Make sure you never leave a copy of the software where other people can access it.<BR>
Never share your software with anyone. The license you purchased is for your use only - you may not give the software to anyone under any circumstances.<BR>
</LI>
</OL>
<font color=red>Make sure your /phptopsites/admin/ directory is password protected with .htaccess</font>
</p>
<BR>
	</font>
      </td>
    </tr>
  </table>
  </center>
<p><font face="verdana" size="2"><br>
</font>
</p>
<?
include "footer.php";
?>
