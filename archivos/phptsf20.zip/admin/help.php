<html>
<head>
<META HTTP-EQUIV="content-type" CONTENT="text/html;charset=iso-8859-1">
<title>PHP TopSites PRO Help Page</title>

<style type="text/css">
	select {font-family: verdana;font-size: 11;}
	input {font-family: verdana;font-size: 11;}
	body {font-family: verdana;font-size: 11;}
	table {font-family: verdana;font-size: 11;}
	A:link {color: blue;font-family: verdana;font-size: 11;}
	A:active {color: #FF4040;font-family: verdana;font-size: 11;}
	A:visited {color: blue;font-family: verdana;font-size: 11;}
	A:hover {color: #FF4040;font-family: verdana;font-size: 11;}
</style>

</head>
<body link="#0000FF" vlink="#0000FF" alink="#0000FF">

<a name="mysql_host"><b>MySQL Hostname</b></a><hr>
Usually MySQL Hostname is "localhost"<br><br>
<a name="mysql_host"><b>Overall Sites per Page</b></a><hr>
The number of sites to be listed per page.<br>
Example: 10 <br><br>
<a name="vote_image_url"><b>URL to the vote image</b></a><hr>
The full URL to the default banner to use for accounts.<br>
Example: http://www.domain.com/toplist/images/banner.gif  <br><br>
<a name="url_to_folder"><b>HTML URL</b></a><hr>
The full URL to where the ranking pages will be located.<br>
Example: http://www.domain.com/toplist <br><br>
<a name="full_path"><b>HTML Directory</b></a><hr>
The full path to the directory where the main HTML pages will reside.<br>
Example: /home/username/www/toplist  <br><br>
<a name="vote_timeout"><b>Vote Timeout</b></a><hr>
How many hours until someone can vote for the same site again.<br>
Example: 24  <br><br>
<a name="days_to_reset"><b>Reset Time</b></a><hr>
The number of day(s) between list resets.<br>
Example: 30  <br><br>
<a name="som_to_reset"><b>"Site of Moment" Reset Time</b></a><hr>
The number of day(s) between "Site of Moment" site reset.<br>
Example: 10  <br><br>
<a name="search_limit"><b>Search limit</b></a><hr>
The number of search results the search script should display per page.<br>
Example: 10  <br><br>
<a name="new_site_days"><b>New Icon Time</b></a><hr>
The minimum number of days to display the new icon next to a site.<br>
Example: 14  <br><br>
<a name="new_site_image"><b>New Icon HTML</b></a><hr>
The full HTML tag to use for the new image.<br>
Example #1: &lt;FONT size=1 color=red&gt;&lt;SUP&gt;NEW&lt;/SUP&gt;&lt;/FONT&gt;  <br>
Example #2: &lt;img src=\"images/new.gif\" width=\"10\" height=\"10\" border=\"0\"&gt;  <br><br>
<a name="hot_site_image"><b>Hot Icon HTML</b></a><hr>
The full HTML tag to use for the Hot image.<br>
Example #1: &lt;FONT size=1 color=red&gt;&lt;SUP&gt;HOT&lt;/SUP&gt;&lt;/FONT&gt;  <br>
Example #2: &lt;img src=\"images/hot.gif\" width=\"10\" height=\"10\" border=\"0\"&gt;  <br><br>
<a name="use_cool"><b>Use Cool Icon</b></a><hr>
The Cool Icon will gets site with 5 stars. (The Rating System should be enabled) <br>
<a name="cool_site_image"><b>Cool Icon HTML</b></a><hr>
The full HTML tag to use for the Cool image.<br>
Example #1: &lt;FONT size=1 color=blue&gt;&lt;SUP&gt;COOL&lt;/SUP&gt;&lt;/FONT&gt;  <br>
Example #2: &lt;img src=\"images/cool.gif\" width=\"10\" height=\"10\" border=\"0\"&gt;  <br><br>
<a name="auto_validation"><b>Automatic Validation</b></a><hr>
All new sites will be added to the toplist without your validation.<br><br>
<a name="min_hits"><b>Minimum Hits</b></a><hr>
The minimum number of hits needed to get listed.<br>
Example : 1<br><br>
<a name="max_banners"><b>Banners To Show</b></a><hr>
The number of member banners to show on the ranking pages.<br>
Example : 5<br><br>
<a name="use_rating"><b>Use Rating System</b></a><hr>
The Rating System allows visitors to rate any site from the list.<br>
Example : Yes<br><br>
<a name="title_l"><b>Site Title Length</b></a><hr>
The maximum number of characters in site title.<br>
Example : 30 (max:255)<br><br>
<a name="description_l"><b>Site Description Length</b></a><hr>
The maximum number of characters in site description.<br>
Example : 100 (max:255)<br><br>
</body>
</html>