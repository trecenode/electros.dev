<?
include "header.php";
?>
<p align="center"><font face="verdana" size="2"><br>
</font><font face="verdana" size="3"><b>PHP TopSites FREE - Security Notes</b></font></p>
  <center>
  <table border="0" cellpadding="5" width="90%" cellspacing="5">
    <tr>
      <td width="100%"><font face="verdana" size="2"><b>PHP TopSites FREE
        Security Notes</b></font>
      </td>
    </tr>
    <tr>
      <td width="100%"><p><font face="verdana" size="2">These
        Security Notes are not meant to be a replacement for a good
        understanding of web security.  They will allow you to set up a reasonably secure
        'PHP TopSites FREE' install, but do not count on them to cover everything.  Take responsibility for the integrity of your
        own web site...
        Learn the security basics, and remember: a little paranoia is a good thing.<br>
        <br>
        You must protect your ~/phptopsitesfree/admin directory using whatever resources you have
        available.&nbsp; If you are using an Apache web server, then a standard
        .htaccess file is the way to go.&nbsp;[<a href="http://apache.org/docs/" target="_blank">Apache
        Documentation</a>]
        If you are using some other less
        popular web server, then contact your system admin for assistance.<br>
        <br>
        &quot;Common Sense Security&quot; is not a bad idea
        either.&nbsp; Renaming the /admin directory to something really
        strange like &quot;/d23#@$fasd&quot; so that it
        can't easily be guessed and pulled up in a browser, will work in a pinch.<br>
        <br>
        Users on shared systems, such as having an &quot;account&quot; with a
        Web Hosting Provider, will definitely need some form of directory
        security, as anyone could browse into your directory and have easy
        access to your config.php file.&nbsp;Not all systems are the same, and
        your particular setup may vary. If you are on a shared system, chances
        are good that a standard method of securing a directory from other users has
        already been devised.&nbsp; You should contact
        your system admin for assistance in securing the /admin
        directory.<br>
	</font></p>
      </td>
    </tr>
  </table>
  </center>
<p><font face="verdana" size="2"><br>
</font>
</p>

<?
include "footer.php";
?>
