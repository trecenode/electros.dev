<html>
<head>
<META HTTP-EQUIV="content-type" CONTENT="text/html;charset=iso-8859-1">
<title>PHP TopSites FREE Remote Admin</title>
  <script language="JavaScript">
    function moreInfo(url, name) { 
      window.open(url, name, 'scrollbars=1,resizable=yes,width=350,height=450,status=0,menubar=0');
    }
  </script>
<style type="text/css">
	textarea {font-family: verdana;font-size: 11px;}
	select {font-family: verdana;font-size: 11px;}
	input {font-family: verdana;font-size: 11px;}
	body {font-family: verdana;font-size: 11px;}
	table {font-family: verdana;font-size: 11px;}
	A:link {color: blue;font-family: verdana;font-size: 11px; text-decoration: none;}
	A:active {color: #FF4040;font-family: verdana;font-size: 11px; text-decoration: none;}
	A:visited {color: blue;font-family: verdana;font-size: 11px; text-decoration: none;}
	A:hover {color: #FF4040;font-family: verdana;font-size: 11px; text-decoration: none;}
</style>

<script type="text/javascript">
	function mMOver(ob) {
		ob.style.background='#D7DCE3';
	}
	function mMOut(ob) {
		ob.style.background='E1E5E8';
	}
        function openBanner(url, name) { 
	        window.open(url, name, 'scrollbars=1,resizable=no,width=640,height=480,status=0,menubar=0');
        }
</script>

</head>

<body background="images/bg_tile.gif" topmargin="5" leftmargin="5" marginheight="0" marginwidth="0" bgcolor="#E5E5E5" link="#0000FF" vlink="#0000FF" alink="#0000FF">

<table height=500 align=center width=750 cellpadding=1 cellspacing=0 border=0 bgcolor=black>
<tr>
	<td valign=top height=60>
	<table width=100% cellpadding=0 cellspacing=0 border=0 height=60>
	<tr>
		<td bgcolor="#BFC7CF" height=60>
		&nbsp;&nbsp;<font face=impact size=6 color="#808080"><i>PHP TopSites FREE</i></font>
		</td>
	</tr>
	</table>
	</td>
</tr>
<tr>
	<td valign=top>
	<table height=100% width=100% cellpadding=4 cellspacing=0 border=0>
	<tr>
		<td bgcolor=#DFDFDF width=150 valign=top>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Docs</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="security.php">Security</A><BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="install_doc.php">Installation</A>
					</td>
				</tr>
				</table>
				<br>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Installation</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="setup.php">Setup</A><BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="install.php">Install Tables</A><BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="check.php">Check Vars</A>
					</td>
				</tr>
				</table>
				<br>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Categories Admin</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="ceditor.php">Add / Edit</A>
					</td>
				</tr>
				</table>
				<br>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Sites Admin</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="validate.php">Validate Sites</A><BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="seditor.php">Edit Sites</A><BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="oldsites.php">Inactive Sites</A><BR>
					</td>
				</tr>
				</table>
				<br>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Support</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						<A HREF="http://itop10.net/support/">Support Forum</A><BR>
					</td>
				</tr>
				</table>
				<br>
				<table width=98% align=center cellpadding=1 cellspacing=1 border=0 bgcolor="black">
				<tr>
					<td bgcolor="#BFC7CF">
						<font color="black"><b>Version</b></font>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
						This: 2.0 FREE<BR>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
					<?
						$fp = @fopen("http://itop10.net/free.txt","r");
						$l_free = @fgets($fp,1024);
						@fclose($fp);
						echo "Latest FREE: $l_free";					
					?>
					</td>
				</tr>
				<tr>
					<td onmouseover="mMOver(this);" onmouseout="mMOut(this);" bgcolor="E1E5E8">
					<?
						$fp = @fopen("http://itop10.net/pro.txt","r");
						$l_pro = @fgets($fp,1024);
						@fclose($fp);
						echo "Latest PRO: $l_pro";					
					?>
					</td>
				</tr>
				</table>
<!-------- Start of HTML Code --------><form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST"><input type="hidden" name="ID" value="10846"><table BORDER="0" CELLSPACING="0" bgcolor="#800000"><tr><td><table border="0" cellspacing="0" width="100%" bgcolor="#EFEFEF" cellpadding="3"><tr><td align="center"><font face="arial, verdana" size="2"><b>Rate Our Program<br><font face="verdana, arial" size="1"><a href="http://www.hotscripts.com" style="text-decoration: none">
@ HotScripts.com
</a></b></font></font><table border="0" cellspacing="3" cellpadding="0"><tr><td align="center"><select name="ex_rate" size="1"><option value selected>-- Select One --</option><option value="5">Excellent!</option><option value="4">Very Good</option><option value="3">Good</option><option value="2">Fair</option><option value="1">Poor</option></select></td></tr><tr><td align="center"><input type="submit" value="Cast My Vote!"></td></tr></table></td></tr></table></td></tr></table></form><!-------- End of HTML Code -------->
		</td>
		<td bgcolor=#EFEFEF valign=top>
