<?
include "header.php";

if ($action == "update") {

	$fp = fopen ("../config.php","w");
	fputs ($fp,"<?\n");
	$putstr = "\$user = \"".$user."\";\n";
	fputs ($fp,$putstr);
	$putstr = "\$pass = \"".$pass."\";\n";
	fputs ($fp,$putstr);
	$putstr = "\$dbname = \"".$dbname."\";\n";
	fputs ($fp,$putstr);
	$putstr = "\$dbhost = \"".$dbhost."\";\n";
	fputs ($fp,$putstr);

	if ($t_step < 1) $t_step = 10;
	$putstr = "\$t_step = \"".$t_step."\";\n";
	fputs ($fp,$putstr);

	if ($last_ssites < 1) $last_ssites = 10;
	$putstr = "\$last_ssites = \"".$last_ssites."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$max_banner_width = \"".$max_banner_width."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$max_banner_height = \"".$max_banner_height."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$title_l = \"".$title_l."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$description_l = \"".$description_l."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$vote_image_url = \"".$vote_image_url."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$url_to_folder = \"".$url_to_folder."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$full_path = \"".$full_path."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$reset_log_file = \"".$reset_log_file."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$count_log_file = \"".$count_log_file."\";\n";
	fputs ($fp,$putstr);

	if ($use_cookies > 1)  $use_cookies = 1;
	$putstr = "\$use_cookies = \"".$use_cookies."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$vote_timeout = \"".$vote_timeout."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$gateway = \"".$gateway."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$days_to_reset = \"".$days_to_reset."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$new_site_days = \"".$new_site_days."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$new_site_image = \"".$new_site_image."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$hot_site_image = \"".$hot_site_image."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$use_cool = \"".$use_cool."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$cool_site_image = \"".$cool_site_image."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$button_text = \"".$button_text."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$top_name = \"".$top_name."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$admin_email = \"".$admin_email."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$new_member = \"".$new_member."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$auto_validation = \"".$auto_validation."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$min_hits = \"".$min_hits."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$use_review = \"".$use_review."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$review_step = \"".$review_step."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$use_taf = \"".$use_taf."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$r_subject = \"".$r_subject."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$use_rating = \"".$use_rating."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$row1_bg_color = \"".$row1_bg_color."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$row2_bg_color = \"".$row2_bg_color."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$font_face = \"".$font_face."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$font_size = \"".$font_size."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$font_color = \"".$font_color."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$RANK = \"".$RANK."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$SITES = \"".$SITES."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$VOTES = \"".$VOTES."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$HITS = \"".$HITS."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$RATING = \"".$RATING."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$anti_cheat_message = \"".$anti_cheat_message."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$vote_log_message = \"".$vote_log_message."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$cookie_message = \"".$cookie_message."\";\n";
	fputs ($fp,$putstr);

	$putstr = "\$ver = \"2.0 FREE\";\n";
	fputs ($fp,$putstr);

	fputs ($fp,"include_once(\"\$full_path/connect.php\");\n");
	fputs ($fp,"include_once(\"\$full_path/functions.php\");\n");

	fputs ($fp,"?>\n");
	fclose($fp);

	echo "<center>All variables were updated.<br>";
	echo "<A href=\"setup.php\">Click Here</A> to continue.<br></center>";

}

else {

include "../config.php";

?>
<form action=setup.php method=post>
<table border=0 align=center cellpadding=3 cellspacing=1 width=90% bgcolor="black">
	<tr><td colspan=2 bgcolor="#BFBFBF"><b>PHP TopSites FREE Setup:</b></td></tr>

	<tr>
		<td bgcolor="#DFDFDF" width=40%>
			MySQL Username :
		</td>
		<td bgcolor="#DFDFDF" width=60%>
			<input type=text name=user value="<? echo $user;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			MySQL Password :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=password name=pass value="<? echo $pass;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			MySQL Database Name :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text name=dbname value="<? echo $dbname;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			MySQL Hostname or IP Address :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text name=dbhost value="<? echo $dbhost;?>"> (<A href="javascript:moreInfo('help.php#mysql_host')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Sites per Page :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=t_step value="<? echo $t_step;?>"> (<A href="javascript:moreInfo('help.php#t_step')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Sites on "New(Last) XX Sites" Page :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=4 name=last_ssites value="<? echo $last_ssites;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Maximum banner width :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=max_banner_width value="<? echo $max_banner_width;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Maximum banner height :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=4 name=max_banner_height value="<? echo $max_banner_height;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Site Title Length :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=4 name=title_l value="<? echo $title_l;?>"> (<A href="javascript:moreInfo('help.php#title_l')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Site Description Length :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=4 name=description_l value="<? echo $description_l;?>"> (<A href="javascript:moreInfo('help.php#description_l')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			The full URL to the vote image :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=vote_image_url value="<? echo $vote_image_url;?>"> (<A href="javascript:moreInfo('help.php#vote_image_url')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			HTML URL :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=40 name=url_to_folder value="<? echo $url_to_folder;?>"> (<A href="javascript:moreInfo('help.php#url_to_folder')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			HTML Directory :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=full_path value="<? echo $full_path;?>"> (<A href="javascript:moreInfo('help.php#full_path')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Path to reset file :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=reset_log_file value="<? echo $reset_log_file;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Path to count file :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=count_log_file value="<? echo $count_log_file;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Vote timeout in hours :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=vote_timeout value="<? echo $vote_timeout;?>"> (<A href="javascript:moreInfo('help.php#vote_timeout')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Track hits using cookies :
		</td>
		<td bgcolor="#DFDFDF">
			<select name=use_cookies>
				<option value=1 <? if ($use_cookies == 1) echo "selected";?>>Yes
				<option value=0 <? if ($use_cookies == 0) echo "selected";?>>No
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Enable The  Gateway page :
		</td>
		<td bgcolor="#DFDFDF">
			<select name=gateway>
				<option value=1 <? if ($gateway == 1) echo "selected";?>>Yes
				<option value=0 <? if ($gateway == 0) echo "selected";?>>No
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			Reset Time :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=days_to_reset value="<? echo $days_to_reset;?>"> (<A href="javascript:moreInfo('help.php#days_to_reset')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			New Icon Time :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=4 name=new_site_days value="<? echo $new_site_days;?>"> (<A href="javascript:moreInfo('help.php#new_site_days')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 New Icon HTML:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=new_site_image value="<? echo $new_site_image;?>"> (<A href="javascript:moreInfo('help.php#new_site_image')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Hot Icon HTML:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=hot_site_image value="<? echo $hot_site_image;?>"> (<A href="javascript:moreInfo('help.php#hot_site_image')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Use COOL Icon:
		</td>                  
		<td bgcolor=#DFDFDF>
			<select name=use_cool>
				<option value=1 <? if ($use_cool == "1") echo "selected";?>>Yes
				<option value=0 <? if ($use_cool == "0") echo "selected";?>>No
				</option>
			</select> (<A href="javascript:moreInfo('help.php#use_cool')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Cool Icon HTML:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=40 name=cool_site_image value="<? echo $cool_site_image;?>"> (<A href="javascript:moreInfo('help.php#cool_site_image')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Submit Button Text :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text name=button_text value="<? echo $button_text;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Top List Name :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=30 name=top_name value="<? echo $top_name;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Admin Email Address:
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=30 name=admin_email value="<? echo $admin_email;?>">
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Get an email when there is a new member :
		</td>
		<td bgcolor=#DFDFDF>
			<select name=new_member>
				<option value=yes <? if ($new_member == "yes") echo "selected";?>>Yes
				<option value=no <? if ($new_member == "no") echo "selected";?>>No
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Automatic Validation:
		</td>
		<td bgcolor="#DFDFDF">
			<select name=auto_validation>
				<option value=yes <? if ($auto_validation == "yes") echo "selected";?>>Yes
				<option value=no <? if ($auto_validation == "no") echo "selected";?>>No
				</option>
			</select> (<A href="javascript:moreInfo('help.php#auto_validation')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Minimum hits :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=min_hits value="<? echo $min_hits;?>"> (<A href="javascript:moreInfo('help.php#min_hits')">?</A>)
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Use Users Reviews Service:
		</td>
		<td bgcolor="#DFDFDF">
			<select name=use_review>
				<option value=1 <? if ($use_review == "1") echo "selected";?>>Yes
				<option value=0 <? if ($use_review == "0") echo "selected";?>>No
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Reviews Per Page :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=4 name=review_step value="<? echo $review_step;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			Use Recommend-it Service :
		</td>
		<td bgcolor="#DFDFDF">
			<select name=use_taf>
				<option value=1 <? if ($use_taf == "1") echo "selected";?>>Yes
				<option value=0 <? if ($use_taf == "0") echo "selected";?>>No
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Subject for Recommend-it Email :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=30 name=r_subject value="<? echo $r_subject;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Use Rating System :
		</td>
		<td bgcolor=#DFDFDF>
			<select name=use_rating>
				<option value=1 <? if ($use_rating == "1") echo "selected";?>>Yes
				<option value=0 <? if ($use_rating == "0") echo "selected";?>>No
				</option>
			</select> (<A href="javascript:moreInfo('help.php#use_rating')">?</A>)
		</td>             
	</tr>
	<tr>
		<td bgcolor="#DFDFDF">
			First Row Color :
		</td>
		<td bgcolor="#DFDFDF">
			<input type=text size=10 name=row1_bg_color value="<? echo $row1_bg_color;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Second Row Color :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=10 name=row2_bg_color value="<? echo $row2_bg_color;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Font Face :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=10 name=font_face value="<? echo $font_face;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Font Size :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=10 name=font_size value="<? echo $font_size;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Font Color :
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=10 name=font_color value="<? echo $font_color;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 SITE Column:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=15 name=SITES value="<? echo $SITES;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 RANK Column:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=15 name=RANK value="<? echo $RANK;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 INCOMING HITS Column:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=15 name=VOTES value="<? echo $VOTES;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 OUTCOMING HITS Column:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=15 name=HITS value="<? echo $HITS;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 RATING Column:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=15 name=RATING value="<? echo $RATING;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Anti Cheat Message:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=45 name=anti_cheat_message value="<? echo $anti_cheat_message;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Vote Log Message:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=45 name=vote_log_message value="<? echo $vote_log_message;?>"> 
		</td>
	</tr>
	<tr>
		<td bgcolor=#DFDFDF>
			 Cookies Message:
		</td>
		<td bgcolor=#DFDFDF>
			<input type=text size=45 name=cookie_message value="<? echo $cookie_message;?>"> 
		</td>
	</tr>
	<tr><td colspan=2 bgcolor="#BFBFBF" align=center><input type=submit name=submit></tr>
</table>
<input type=hidden name=action value=update>
<input type=hidden name=ver value=<? echo $ver;?>>
</form>
<?
}

include "footer.php";
?>
