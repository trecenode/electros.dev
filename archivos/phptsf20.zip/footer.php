	</td>
</tr>
</table>
<center>
<B><font size=1 face=verdana color=black>Powered by <A HREF="http://itop10.net/products">PHP TopSites <? echo $ver?></A>.</font></B>
</center>
</BODY>
</HTML>
<? @mysql_close($db); ?>