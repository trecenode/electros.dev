<?
function get_site_category($sid,$cid) {
	Global $dbname,$db;
	$query = mysql_db_query ($dbname,"select catname from top_cats where cid='$cid'",$db) or die (mysql_error());
	$rows = mysql_fetch_array($query);
	$cc = $rows[catname];
	return $cc;
}

function get_site_reviews($sid) {
	Global $dbname,$db;
	$query = mysql_db_query ($dbname,"select count(rid) as reviews from top_review where sid='$sid'",$db) or die (mysql_error());
	$rows = mysql_fetch_array($query);
	$cc = 0;
	$cc = $rows[reviews];
	return $cc;
}

function reset_update_time() {

	Global $days_to_reset,$reset_log_file;

	$days_code = 86400 * $days_to_reset;
	$reset_date = time()+$days_code;

	$fp = fopen($reset_log_file, "w");
	flock($fp,2);
	$fw = fwrite($fp, $reset_date);
	fclose($fp);
}

function reset_list() {
	
	Global $dbname,$db;
	mysql_db_query ($dbname,"update top_user set thin='0', thout='0'",$db) or die (mysql_error());
	mysql_db_query ($dbname,"delete from top_hits",$db) or die (mysql_error());

}

function check_email_addr($email) {
	if (ereg('^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+'. '@'.'[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.'.'[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$', $email)) {
		return 1;
	}else{
		return 0;
	}
}

function stars_site_rating ($rating,$votes) {

	if ($rating > 0) $site_rating = round (($rating/$votes)/2,1);
	else $site_rating = 0;

	if ($site_rating > 0) {
		$sc = $site_rating;
		while ($sc > 0 && $sc >= 1) {
			$ssc.= "<img src=\"images/star.gif\" width=10 height=9 border=0 ALT=\"Rating : $site_rating\">";
			$sc--;
		}
	}
	if ($sc > 0 && $sc < 1) {
		$ssc.= "<img src=\"images/star_half.gif\" width=5 height=9 border=0 ALT=\"Rating : $site_rating\">";
	}
	return ($ssc);
}

function get_cool_icon ($rating,$votes,$cool_icon) {
        $ci = "";
	if ($rating >0) $rg = round (($rating/$votes)/2,1);
        if ($rg > 4.7) {
		$ci = $cool_icon;
	}
	return ($ci);
}

function hot_status_check ($hot_status,$hot_status_image) {
        $hsi = "";
        if ($hot_status > 0) {
		$hsi = $hot_status_image;
	}
	return ($hsi);
}
?>