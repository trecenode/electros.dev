<?
include "config.php";

$get_rows = mysql_db_query ($dbname,"Select url from top_user Where sid='$site'",$db) or die (mysql_error());
$rows = mysql_fetch_array($get_rows);
$site_url = $rows[url];

	mysql_db_query ($dbname,"update top_user set thout=thout+1 Where sid='$site'",$db) or die (mysql_error());

	mysql_close($db);

//header("location: $site_url");
    echo "<script language=\"JavaScript\">{                                                                                         
    location.href=\"$site_url\";                                                                                           
    self.focus();                                                                                                                   
    }</script>";
?>
