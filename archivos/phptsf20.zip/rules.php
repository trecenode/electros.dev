<TABLE Align="Center" Width="400" BORDER="1" CellPadding="3" CellSpacing="0">
<TR>
	<TD BgColor="#5588aa">
		<font color="<? echo $font_color;?>" face="<? echo $font_face; ?>" Size="<? echo $font_size; ?>"><B>Rules for joining</B></font>
	</TD>
</TR>
<TR>
	<TD>
	<font color="<? echo $font_color;?>" face="<? echo $font_face; ?>" Size="<? echo $font_size; ?>">
		<ul>
			    <li>Ranking depends only on INCOMING Hit's
			    <li>NO Script's allowed for incoming Hit's
			    <li>The Counter's will be reset periodically
			    <li>!!! Cheating is NOT allowed !!!
		</ul>
	</font>
	</TD>
</TR>
</TABLE>