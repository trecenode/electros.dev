<?
/*
*************************************************
*** eForo v3.1
*** Creado por: Electros <webmaster@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
*************************************************

eForo - Comunidad de foros para que tus visitantes convivan y se sientan parte de tu web
Copyright � 2003-2006 Daniel Osorio "Electros"

This file is part of eForo.

eForo is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>eForo v3.1 - Instalaci�n</title>
<style type="text/css">
body {
font-family: verdana, sans-serif ;
font-size: 10pt ;
color: #000 ;
margin: 100px ;
}
a {
font-weight: bold ;
color: #000 ;
text-decoration: none ;
}
a:hover {
text-decoration: underline ;
}
</style>
</head>
<body>
<h3>eForo v3.1 - Instalaci�n</h3>
<?
require 'config.php' ;
if(!isset($_POST['enviar'])) {
?>
<p><b>Aviso:</b> Si est�s actualizando eForo desde una versi�n anterior, entra <a href="actualizar.php">aqu�</a>.
<p>Gracias por tu inter�s en eForo, antes de comenzar con la instalaci�n recuerda haber configurado el archivo <b>config.php</b> con tus datos
de conexi�n a la base de datos. Ahora se comprobar� la configuraci�n de <b>config.php</b>.</p>
<div style="border: #000000 1px solid ; background-color: #cddff0 ; padding: 5px">
Comprobando configuraci�n de <b>config.php</b>...<br /><br />
<?
if($conectar) echo 'El archivo <b>config.php</b> est� configurado correctamente.' ;
?>
</div>
<p>A continuaci�n deber�s completar la configuraci�n previa a la instalaci�n.</p>
<script type="text/javascript">
function comprobar(a) {
	if(a.administrador.value == '') {
		alert('Debes escribir un nick.') ;
		return false ;
	}
	if(a.contrasena.value == '') {
		alert('Debes escribir una contrase�a.') ;
		return false ;
	}
	if(a.contrasena.value != a.contrasena_c.value) {
		alert('Las contrase�as son diferentes.') ;
		return false ;
	}
}
</script>
<form method="post" action="instalar.php" onsubmit="return comprobar(this)">
<fieldset>
<legend>Configuraci�n</legend><br />
<b>Nick del administrador:</b><br />
<input type="text" size="25" name="administrador" /><br />
<b>Contrase�a del administrador:</b><br />
<input type="password" size="25" name="contrasena" /><br />
<b>Confirmar contrase�a:</b><br />
<input type="password" size="25" name="contrasena_c" /><br />
<b>URL donde est� instalado eForo (ej. http://www.pagina.com/carpeta/):</b><br />
<input type="text" size="50" name="foro_url" value="http://<?=$_SERVER['HTTP_HOST'].str_replace('instalar.php','',$_SERVER['PHP_SELF'])?>" /><br />
<b>Tipo de instalaci�n:</b><br />
<input type="radio" id="instalacion1" name="instalacion" value="1" onclick="tabla_usuarios.disabled = true ; tabla_usuarios.value = 'eforo_usuarios'" checked="checked" /><label for="instalacion1">Instalaci�n t�pica</label><br />
<input type="radio" id="instalacion2" name="instalacion" value="2" onclick="tabla_usuarios.disabled = false ; tabla_usuarios.value = ''" /><label for="instalacion2">Compatible con script de sistema de usuarios de www.electros.net</label><br />
<b>Tabla de usuarios:</b><br />
<input type="text" size="20" name="tabla_usuarios" value="eforo_usuarios" disabled="disabled" />
</fieldset><br /><br />
<input type="submit" name="enviar" value="Comenzar Instalaci�n" />
</form>
<?
}
else {
$fecha = gmmktime() ;
$admin_contrasena = md5(md5($_POST['contrasena'])) ;
switch($_POST['instalacion']) {
	case 1 :
		$tabla_usuarios = 'eforo_usuarios' ;
		$usuario = "insert into $tabla_usuarios (fecha_registrado,nick,contrasena,fecha_conectado) values ('$fecha','{$_POST['administrador']}','$admin_contrasena','$fecha')" ;
		break ;
	case 2 :
		$tabla_usuarios = $_POST['tabla_usuarios'] ;
		$con = mysql_query("select id,contrasena from $tabla_usuarios where nick='{$_POST['administrador']}'") ;
		if(mysql_num_rows($con,0,0)) {
			$datos = mysql_fetch_row($con) ;
			$usuario = false ;
			$admin_id = $datos[0] ;
			if($admin_contrasena != $datos[1]) mysql_query("update $tabla_usuarios set contrasena='$admin_contrasena' where id='$admin_id'") ;
		}
		else {
			$usuario = "insert into $tabla_usuarios (fecha_registrado,nick,contrasena,fecha_conectado) values ('$fecha','{$_POST['administrador']}','$admin_contrasena','$fecha')" ;
		}
}
$mensaje_titulo = 'Gracias por usar eForo v3.1' ;
$mensaje_contenido =
'eForo v3.1 es el resultado de muchos meses de trabajo. Su c�digo ha
sido reescrito desde cero con lo que se ha conseguido reducirse
hasta en un 60% en comparaci�n con la versi�n v.2.2.1. Esta versi�n
incorpora un sistema de plantillas, ePiel v1.0 que permiti� poder
separar el c�digo PHP del dise�o del foro, consiguiendo que �ste se
pueda modificar f�cilmente, adem�s de poder crear varios dise�os e
intercambiarlos con s�lo seleccionarlo en la configuraci�n en el panel
de control.

eForo ha sido publicado bajo la licencia GNU General Public License,
lo que te permite realizar modificaciones en su c�digo y redistribuirlo,
prohibi�ndose inclu�rlo ya sea parcial o totalmente en un software
privativo, para m�s informaci�n visita www.gnu.org.

Por favor, no elimines el enlace a nuestra web, puedes moverlo a otra
secci�n de tu web si lo deseas, siempre y cu�ndo sea visible tanto para
la gente como para los buscadores, as� permitir�s que el uso de eForo
crezca y m�s personas puedan utilizar eForo.

Si tienes un foro phpBB, vBulletin o similar y deseas transferir
tus mensajes a eForo, escr�benos en nuestro foro en electros.net/foro.

Agradezco tu inter�s en usar eForo v3.1, espero que te sea de utilidad
y que lo disfrutes.

Electros
' ;
$codigo =
"create table eforo_adjuntos (
id smallint(5) unsigned not null auto_increment,
id_mensaje mediumint(8) unsigned not null,
archivo varchar(100) not null,
descargas mediumint(8) unsigned not null,
primary key (id)
)
;
create table eforo_categorias (
id tinyint(3) unsigned not null auto_increment,
orden smallint(5) unsigned not null,
categoria varchar(100) not null,
primary key (id),
key (orden)
)
;
create table eforo_config (
id tinyint(3) unsigned not null auto_increment,
id_administrador varchar(100) not null,
email varchar(100) not null,
foro_url varchar(100) not null,
foro_titulo varchar(100) not null,
temas tinyint(3) unsigned not null,
mensajes tinyint(3) unsigned not null,
ultimos tinyint(3) unsigned not null,
codigo tinyint(1) unsigned not null,
caretos tinyint(1) unsigned not null,
url tinyint(1) unsigned not null,
firma tinyint(1) unsigned not null,
censurar tinyint(1) unsigned not null,
notificacion tinyint(1) unsigned not null,
plantilla varchar(100) not null,
estilo varchar(100) not null,
avatarlargo smallint(5) unsigned not null,
avatarancho smallint(5) unsigned not null,
avatartamano smallint(5) unsigned not null,
privados smallint(5) unsigned not null,
adjuntotamano smallint(5) unsigned not null,
adjuntoext text not null,
adjuntonombre tinyint(3) unsigned not null,
primary key (id)
)
;
create table eforo_enlinea (
fecha int(10) unsigned not null,
ip varchar(15) not null,
id_usuario mediumint(8) not null,
key (fecha)
)
;
create table eforo_foros (
id smallint(5) unsigned not null auto_increment,
orden smallint(5) unsigned not null,
id_categoria tinyint(3) unsigned not null,
foro varchar(100) not null,
descripcion text not null,
num_temas mediumint(8) unsigned not null,
num_mensajes mediumint(8) unsigned not null,
p_leer smallint(5) not null,
p_nuevo smallint(5) not null,
p_responder smallint(5) not null,
p_editar smallint(5) not null,
p_borrar smallint(5) not null,
p_importante smallint(5) not null,
p_adjuntar smallint(5) not null,
primary key (id),
key (orden),
key (id_categoria)
)
;
create table eforo_mensajes (
id mediumint(8) unsigned not null auto_increment,
id_foro tinyint(3) unsigned not null,
id_tema mediumint(8) unsigned not null,
num_visitas mediumint(8) unsigned not null,
num_respuestas mediumint(8) unsigned not null,
fecha int(10) unsigned not null,
id_usuario mediumint(8) unsigned not null,
tema varchar(100) not null,
mensaje text not null,
o_caretos tinyint(1) unsigned not null,
o_codigo tinyint(1) unsigned not null,
o_url tinyint(1) unsigned not null,
o_firma tinyint(1) unsigned not null,
o_importante tinyint(1) unsigned not null,
o_notificacion tinyint(1) unsigned not null,
o_notificacion_email tinyint(1) unsigned not null,
fecha_editado int(10) unsigned not null,
fecha_ultimo int(10) unsigned not null,
cerrado tinyint(1) unsigned not null,
primary key (id),
key (id_foro),
key (id_tema)
)
;
create table eforo_moderadores (
id smallint(5) unsigned not null auto_increment,
id_foro smallint(5) unsigned not null,
id_usuario mediumint(8) unsigned not null,
primary key (id)
)
;
create table eforo_privados (
id mediumint(8) unsigned not null auto_increment,
leido tinyint(1) unsigned not null,
fecha int(10) unsigned not null,
id_remitente mediumint(8) not null,
id_destinatario mediumint(8) not null,
mensaje text not null,
primary key (id),
key (id_destinatario)
)
;
create table eforo_rangos (
rango smallint(5) not null,
minimo smallint(5) unsigned not null,
descripcion varchar(100) not null,
primary key (rango)
)
;
create table eforo_recientes (
id_usuario mediumint(8) unsigned not null,
fecha int(10) unsigned not null,
id_foro smallint(5) unsigned not null,
id_mensaje mediumint(8) unsigned not null,
primary key (id_mensaje),
key (id_usuario)
)
" ;
if($_POST['instalacion'] == 1) {
$codigo .=
";
create table eforo_usuarios (
id mediumint(8) unsigned not null auto_increment,
fecha_registrado int(10) unsigned not null,
nick varchar(20) not null,
contrasena varchar(32) not null,
email varchar(50) not null,
pais varchar(20) not null,
edad tinyint(2) unsigned not null,
sexo tinyint(1) unsigned not null,
descripcion text not null,
web varchar(100) not null,
ip varchar(15) not null,
firma text not null,
mensajes smallint(5) unsigned not null,
rango smallint(5) not null,
rango_fijo tinyint(1) unsigned not null,
fecha_conectado int(10) unsigned not null,
fecha_rec_contrasena int(10) unsigned not null,
gmt tinyint(2) not null,
avatar char(3) not null,
primary key (id),
key (nick),
key (contrasena)
)
" ;
}
$codigo .=
";
insert into eforo_categorias (orden,categoria) values ('10','Categor�a de ejemplo')
;
insert into eforo_foros (orden,id_categoria,foro,descripcion,num_temas,num_mensajes) values ('10','1','Foro de ejemplo','Descripci�n.','1','1')
;
insert into eforo_mensajes (id_foro,id_tema,fecha,tema,mensaje,fecha_editado,fecha_ultimo) values ('1','1','$fecha','$mensaje_titulo','$mensaje_contenido','$fecha','$fecha')
;
insert into eforo_rangos (rango,descripcion) values ('-1','Banead@')
;
insert into eforo_rangos (rango,descripcion) values ('0','An�nim@')
;
insert into eforo_rangos (rango,descripcion) values ('1','Nuev@')
;
insert into eforo_rangos (rango,descripcion) values ('500','Moderador')
;
insert into eforo_rangos (rango,descripcion) values ('999','Administrador')
" ;
if($_POST['instalacion'] == 2) {
$codigo .=
";
alter table '.$tabla_usuarios.' change fecha fecha_registrado int(10) unsigned not null
;
alter table $tabla_usuarios add firma text not null
;
alter table $tabla_usuarios add mensajes smallint(5) unsigned not null
;
alter table $tabla_usuarios add rango smallint(5) not null
;
alter table $tabla_usuarios add rango_fijo tinyint(1) unsigned not null
;
alter table $tabla_usuarios add fecha_conectado int(10) unsigned not null
;
alter table $tabla_usuarios add fecha_rec_contrasena int(10) unsigned not null
;
alter table $tabla_usuarios add gmt tinyint(2) not null
;
alter table $tabla_usuarios add avatar char(3) not null
;
update $tabla_usuarios set rango_fijo='1' where rango='-1'
;
update $tabla_usuarios set rango_fijo='1' where rango='500'
;
update $tabla_usuarios set rango_fijo='1' where rango='999'
" ;
}
$codigo = explode(';',$codigo) ;
foreach($codigo as $linea) {
$linea = trim($linea) ;
@mysql_query($linea) ;
}
if($usuario) {
	mysql_query($usuario) ;
	$admin_id = mysql_insert_id() ;
}
mysql_query("insert into eforo_config
(id_administrador,email,foro_url,temas,mensajes,ultimos,codigo,caretos,url,firma,censurar,notificacion,plantilla,estilo,avatarlargo,avatarancho,avatartamano,privados,adjuntotamano,adjuntoext,adjuntonombre)
values
('$admin_id','nombre@email.com','{$_POST['foro_url']}','25','20','20','1','1','1','1','0','1','electros','electros','150','150','30','100','512','zip\r\nrar\r\ntxt\r\nrtf\r\ngif\r\njpg\r\njpeg\r\npng\r\ndoc\r\nxls\r\nppt\r\npps\r\npdf\r\nmid\r\nswf\r\nmpg\r\nmpeg\r\navi\r\nwma\r\nwmv','32')
") ;
?>
<p style="font-size: 12pt"><b>Instalaci�n completada</b>
<p>La instalaci�n se ha completado. Ya puedes disfrutar de eForo.
<p>Recuerda darle permiso CHMOD 777 a la carpeta <b>avatares</b> que se encuentra dentro de <b>eforo_imagenes</b>, para esto entra desde cualquier
programa FTP, haz click derecho sobre la carpeta y busca una opci�n que diga CHMOD, Permisos o Propiedades.
<?
if($_POST['instalacion'] == 1) {
?>
<p>Se ha creado un nuevo usuario llamado <b><?=$_POST['administrador']?></b> con la contrase�a <b><?=$_POST['contrasena']?></b>
el cu�l ser� administrador. Para administrar eForo inicia sesi�n con este usuario y en el men� selecciona la opci�n <b>Panel de
control</b>.</p>
<?
}
else {
?>
<p>Se ha seleccionado al usuario <b><?=$_POST['administrador']?></b> como administrador. Para administrar eForo inicia sesi�n
con este usuario y en el men� selecciona la opci�n <b>Panel de control</b>.</p>
<?
}
?>
<p>Si has elegido actualizar el eForo utilizando la compatibilidad con el sistema de usuarios, recuerda cambiar el valor de
la variable <b>$tabla_usuarios</b> por el nombre de la tabla donde se guardan tus usuarios, para esto abre el archivo
<b>foroconfig.php</b> con un editor de texto puro como el Bloc de notas de Windows (notepad.exe) y vuelve a subir el archivo.</p>
<p><span style="font-size: 12pt ; color: #aa0000"><b>�No olvides eliminar los archivos <b>instalar.php</b>, <b>actualizar.php</b>
y la carpeta <b>eforo_parches</b> al terminar la instalaci�n!</b></span></p>
<input type="button" value="Finalizar" onclick="location = 'foro.php'">
<?
}
?>
</body>
</html>