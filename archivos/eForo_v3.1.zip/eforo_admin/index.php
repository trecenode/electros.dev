<?
/*
*************************************************
*** eForo v3.1
*** Creado por: Electros <webmaster@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
*************************************************

eForo - Comunidad de foros para que tus visitantes convivan y se sientan parte de tu web
Copyright � 2003-2006 Daniel Osorio "Electros"

This file is part of eForo.

eForo is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>eForo v3.0 � Panel de administraci�n</title>
</head>
<frameset cols="20%,80%" frameborder="0" framespacing="0">
<frame name="menu" src="menu.php" scrolling="no" />
<frame name="contenido" src="foros.php" />
</frameset>
</html>
