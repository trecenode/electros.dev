<?
/*
*************************************************
*** eForo v3.1
*** Creado por: Electros <webmaster@electros.net>
*** Sitio web: www.electros.net
*** Licencia: GNU General Public License
*************************************************

eForo - Comunidad de foros para que tus visitantes convivan y se sientan parte de tu web
Copyright � 2003-2006 Daniel Osorio "Electros"

This file is part of eForo.

eForo is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
*/

# * Conexi�n a la base de datos
$config = array() ;
$config[0] = 'localhost' ; # Com�nmente "localhost", una URL � una IP
$config[1] = 'usuario' ; # Usuario
$config[2] = 'contrasena' ; # Contrase�a
$config[3] = 'base_de_datos' ; # Nombre

$men_error = '<p><b>Error</b></p><p>No se pudo conectar a la base de datos debido a:</p>' ;
$conectar = mysql_connect($config[0],$config[1],$config[2]) or exit($men_error.mysql_error()) ;
mysql_select_db($config[3],$conectar) or exit($men_error.mysql_error()) ;
?>