<table width="223" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000066">
  <tr> 
    <td width="219" colspan="2" bgcolor="#CCCCCC"> <div align="center"><strong><font color="#666666" size="1" face="Verdana, Arial, Helvetica, sans-serif">FunkyCount 
        1.0</font></strong></div></td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#FFFFFF"><center>
        <?
include ("FCount.actualizacion.php");
?>
      </center></td>
  </tr>
</table>
