<?php
#============== FunkyslimCount  ==================#
#Contador grafico para paginas web                #
#FunkyslimCount esta distribuido bajo la licencia #
#GNU, por lo que no da ninguna garantia           #
#  Autor: Funkyslim (Jose Fernandez Alameda)      #
#  E-Mail: Djfunkyslim@hotmail.com                #
#=================================================#


include ("configuracion.php");

$ruta = "visitas.dat";

file_exists($ruta) or die ("<b>Error fatal, El archivo visitas.dat no existe</b>");

$abrir = fopen($ruta, "r");
$lectura = fread($abrir, filesize($ruta));

$lectura = ($lectura + 1);

fclose($abrir);

$abrir_r = fopen($ruta, "w+");

fwrite($abrir_r, $lectura);

fclose($abrir_r);

$_cad_long = strlen($lectura);

	for ($a = 0; $a <= $_cad_long - 1; $a++)
	{
	$char[$a] = substr($lectura,$a,1);
	$num = $char[$a];
	echo "<img src=".$_num[$num]." alt='Powered by FCount - www.tonoslim.tk'>";	

	}

?>