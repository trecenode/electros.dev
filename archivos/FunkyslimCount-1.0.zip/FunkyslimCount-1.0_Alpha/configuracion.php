<?
#============== FunkyslimCount  ==================#
#Contador grafico para paginas web                #
#FunkyslimCount esta distribuido bajo la licencia #
#GNU, por lo que no da ninguna garantia           #
#  Autor: Funkyslim (Jose Fernandez Alameda)      #
#  E-Mail: Djfunkyslim@hotmail.com                #
#=================================================#

$_num[0] = "imagenes/0.jpg";
$_num[1] = "imagenes/1.jpg";
$_num[2] = "imagenes/2.jpg";
$_num[3] = "imagenes/3.jpg";
$_num[4] = "imagenes/4.jpg";
$_num[5] = "imagenes/5.jpg";
$_num[6] = "imagenes/6.jpg";
$_num[7] = "imagenes/7.jpg";
$_num[8] = "imagenes/8.jpg";
$_num[9] = "imagenes/9.jpg";

?>