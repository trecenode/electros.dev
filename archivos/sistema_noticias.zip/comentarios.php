<?php
include("config.php");
include("funciones.php");
$autor = $_POST['autor']; $autor = vaciar($autor);
$comentario = $_POST['comentario']; $comentario = vaciar($comentario);
$id = $_POST['id_noticia'];
$fecha = time();
mysql_query("insert into comentarios (id_noticia,fecha,autor,comentario) VALUES ('".$id."','".$fecha."','".$autor."','".$comentario."')") or die ("error:\n".mysql_error());
header("location:".$HTTP_REFERER);
?>