<?php
include("config.php");
include("funciones.php");
$resp = mysql_query("select * from noticias where id='".$_GET['i']."'") or die (mysql_error());
$sql = mysql_fetch_array($resp);
$noticia = $sql['noticia']; $noticia = reemplazar($noticia);
$intro = $sql['introduccion']; $intro = reemplazar($intro);
$fecha = date("d/m/y",$sql[fecha]);
include("ver.htm");
mysql_free_result($resp);
$mostrar = $mostrando_comentarios ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select fecha,autor,comentario from comentarios where id_noticia='".$_GET['i']."' order by id desc limit $desde,$mostrar") or die ("error:\n".mysql_error());
$desde = $desde + $mostrar ;
$Resp = mysql_query("select id from comentarios where id_noticia='".$_GET['i']."'") or die ("error:\n".mysql_error());
$total = mysql_num_rows($Resp);
if($total == 0) {
echo "<strong>No hay ningun Comentarios</strong>";
} else {
while($sql = mysql_fetch_array($resp)) {
$fecha = date("d/m/y",$sql['fecha']);
include("comentarios.htm");
}
}
echo "<div style=\"text-align:center\">";
if($desde > $mostrar) {
 	$anteriores = $mostrar * 2;
	if($desde == $anteriores) {
		echo "<a href=\"ver.php?i=".$_GET['i']."\"><strong><<</strong></a> ";
		} else {
			$anteriores = $desde - $mostrar * 2;
			echo "<a href=\"ver.php?i=".$_GET['i']."&desde=$anteriores\"><strong><<</strong></a> ";
			}
			}
if($total > $mostrar) {
	if($desde < $total) {
		echo "<a href=\"ver.php?i=".$_GET['i']."&desde=$desde\"><strong>>></strong></a>";
		}
		}
echo "</div>";
include("form_comentarios.htm");
?>