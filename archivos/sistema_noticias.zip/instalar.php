<?php
switch($_GET['op']) {
case "crear":
include("config.php") ;
include("funciones.php");
$resp = mysql_query("
create table comentarios (
id tinyint(3) unsigned not null auto_increment,
id_noticia smallint(5) unsigned not null,
fecha int(10) unsigned not null,
autor varchar(50) not null,
comentario varchar(255) not null,
primary key (id),
)
") ;
$resp1 = mysql_query("
create table admin (
id tinyint(3) unsigned not null auto_increment,
nick varchar(50) not null,
pass varchar(50) not null,
email varchar(50) not null,
primary key (id),
)
") ;
$resp2 = mysql_query("
create table noticias (
id tinyint(3) unsigned not null auto_increment,
fecha int(10) unsigned not null,
autor varchar(50) not null,
titulo varchar(100) not null,
email varchar(50) not null,
introduccion varchar(255) not null,
noticia text not null,
topic varchar(255) not null,
primary key (id),
)
") ;
mysql_close($conectar) ;
?>
<style>
body {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
</style>
<b>Tablas Creadas</b><br>
<p><b>Comentarios</b><br>
  <?= mensaje($resp); ?>
  <br>
  <strong>Admin</strong><br>
  <?= mensaje($resp1); ?>
  <br>
  <b>Noticias</b><br>
  <?= mensaje($resp2); ?>
  <br>
  <br>
  Recuerda eliminar este archivo inmediatamente despu�s de la instalaci�n.<br><br>
  Haz click <a href="instalar.php?op=agregar">aqui</a> para crear un administrador.
  <?php
  break;
  case "agregar":
  include("config.php");
  if(!$_POST['enviar'])
  {
  ?>
  <style>
body {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
</style>
Estas a punto de agregar un administrador para poder adminstrar las noticias.<br>
Rellene el siguiente formulario<br><br>
<form action="instalar.php?op=agregar" method="post" style="margin:0;">
<b>Admin:</b><br>
<input type="text" name="admin" maxlength="50"><br>
<b>Password:</b><br>
<input type="password" name="passw" maxlength="50"><br>
  <strong>Email:</strong><br>
<input type="text" name="email" maxlength="50"><br><br>
<input type="submit" name="enviar" value="enviar">
</form>
  <?php
  } else {
  $nick = $_POST['admin'];
  $pass = $_POST['passw'];
  $email = $_POST['email'];
  mysql_query("insert into admin (nick,pass,email) VALUES ('".$nick."','".$pass."','".$email."')") or die ("Error wn la consulta:\n".mysql_error());
  echo "Ingresado correctamente";
  }
  break;
  default:
  ?>
  <style>
  body {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
</style>
  Bienvenido y gracias por elegir este sistema de noticias, al pulsar el siguiente 
  link se procedera a crear las tablas en la base de datos para poder administrar 
  correctamente este sistema de noticias. Despues de haberse creado las tablas 
  deberas rellenar un formulario para crear un administrador que sera el encargado 
  de administrar y escribir las noticias.</p>
<p>Haz click <a href="instalar.php?op=crear">aqui</a> para comenzar.</p>
<?php
}
?>