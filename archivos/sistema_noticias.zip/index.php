<?php
/********************************************/
/***** sistema creado por rINg0WEB *********/
/**** http://ringoweb.mundo-irc.org *****/
/****************************************/
include("config.php");
include("funciones.php");
$mostrar = $mostrando ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select id,fecha,autor,titulo,email,introduccion,topic from noticias order by id desc limit $desde,$mostrar") or die ("error:\n".mysql_error());
$paginado = mysql_query("select id from noticias") or die ("error:\n".mysql_error());
$desde = $desde + $mostrar ;
$total = mysql_num_rows($paginado);
while($sql = mysql_fetch_array($resp)) {
$fecha = date("d/m/y",$sql[fecha]);
$noticia = $sql['introduccion'];
$noticia = reemplazar($noticia);
$query = mysql_query("select id from comentarios where id_noticia='".$sql['id']."'");
if(mysql_num_rows($query) == 0) {
$coment = 0;
} else {
$coment = mysql_num_rows($query);
}
include("noticias.htm");
mysql_free_result($query);
}
echo "<div style=\"text-align:center\">";
if($desde > $mostrar) {
 	$anteriores = $mostrar * 2;
	if($desde == $anteriores) {
		echo "<a href=\"index.php\"><strong><<</strong></a> ";
		} else {
			$anteriores = $desde - $mostrar * 2;
			echo "<a href=\"index.php?desde=$anteriores\"><strong><<</strong></a> ";
			}
			}
if($total > $mostrar) {
	if($desde < $total) {
		echo "<a href=\"index.php?desde=$desde\"><strong>>></strong></a>";
		}
		}
echo "</div>";
?>