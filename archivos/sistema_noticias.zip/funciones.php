<?php
function mensaje($opcion) {
if(!$opcion) {
$devuelve = "Tabla <b>NO</b> creada";
return $devuelve;
} else {
$devuelve = "Tabla <b>SI</b> creada";
return $devuelve;
}
}
function vaciar($var) {
	$var = trim($var);
	$var = strip_tags($var);
	$var = addslashes($var);
	return $var;
}
function reemplazar($var) {
$var = str_replace("\r\n","<br />",$var);
$var = eregi_replace("\\[web=([^\\[]*)\\]([^\\[]*)\\[/web\\]", "<a target=\"_blank\" href=\"\\1\">\\2</a>", $var);
$var = eregi_replace("\\[u\\]([^\\[]*)\\[/u\\]","<u>\\1</u>", $var);
$var = eregi_replace("\\[b\\]([^\\[]*)\\[/b\\]","<strong>\\1</strong>", $var);
$var = eregi_replace("\\[i\\]([^\\[]*)\\[/i\\]","<i>\\1</i>", $var);
return $var;
}
?>