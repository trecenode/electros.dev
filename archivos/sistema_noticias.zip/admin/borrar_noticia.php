<?php
$resp = mysql_query("select id,titulo from noticias") or die ("error:\n".mysql_error());
echo "<form action=\"procesador.php?op=borrar_noticia\" method=\"post\">
		<strong>Selecciona la noticia a borrar</strong><br>
		<select name=\"borrar\">";
		while($sql = mysql_fetch_array($resp)) {
			echo "<option value=\"".$sql['id']."\">".$sql['titulo']."\n\n".$sql['id']."</option>";
			}
		echo "</select><br><br>
			  <input type=\"submit\" name=\"enviar\" value=\"Borrar\">
			  </from>";
?>