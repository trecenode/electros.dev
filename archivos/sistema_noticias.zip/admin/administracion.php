<?php
include("../config.php");
if($_COOKIE['admin']) {
$resp = mysql_query("select pass from admin where nick='".$_COOKIE['admin']."'") or die (mysql_error());
if(mysql_num_rows($resp) == 0) {
echo "Imposible entrar";
exit;
} else {
$sql = mysql_fetch_array($resp);
$pass = $sql['pass'];
$pass = md5($pass);
if($_COOKIE['passw'] !== $pass) {
echo "imposible entrar";
exit;
}
}
} else {
echo "imposible entrar";
exit;
}
$resp = mysql_query("select id from noticias") or die ("Error:\n".mysql_error());
$total = mysql_num_rows($resp);
if($total == 0) { 
$mostrar = 0; 
} else { 
$mostrar = $total; 
}
$admin = mysql_query("select id from admin") or die ("error:\n".mysql_error());
$total = mysql_num_rows($admin);
if($total == 0) { 
$admins = 0; 
} else { 
$admins = $total; 
}
?>
<html>
<head>
<title>Administracion de Noticias</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" type=text/css rel=stylesheet>
</head>

<body>
<div align="center" class="total_admin"> 
  <table width="775" border="0" cellspacing="0" cellpadding="0" class="tabla_total">
    <tr>
      <td width="179" height="68"><img src="../imagenes/administracion.png" width="179" height="68"></td>
      <td width="596" valign="top" class="fondo_arriba_admin">&nbsp;</td>
    </tr>
    <tr>
      <td height="40" valign="top" class="fondo_admin">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="arriba_menu" valign="top">.:Menu:.</td>
          </tr>
          <tr>
            <td valign="top">
			  &nbsp;<a href="index.php">Principal</a><br>
			  <br>
			  &nbsp;<a href="administracion.php?op=escribir_noticia">Escribir Noticia</a>&nbsp;<span class="small">(<strong><? echo $mostrar; ?></strong>)</span><br>
              &nbsp;<a href="administracion.php?op=editar_noticia">Editar Noticia</a><br>
              &nbsp;<a href="administracion.php?op=borrar_noticia">Borrar Noticia</a><br>
			  <br>
			  &nbsp;<a href="administracion.php?op=borrar_comentario">Borrar Comentario</a><br>
			  <br>
              &nbsp;<a href="administracion.php?op=agregar_admin">Agregar Admin</a>&nbsp;<span class="small">(<strong><? echo $admins; ?></strong>)</span><br>
              &nbsp;<a href="administracion.php?op=borrar_admin">Borrar Admin</a><br>
			  <br>
              &nbsp;<a href="procesador.php?op=logout">Logout</a><br></td>
          </tr>
        </table></td>
      <td valign="top" class="fondo_arriba_admin"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="arriba_menu_derecha">
			<?php
			echo "Bienvenido administrador " . $_COOKIE['admin'] . " , Gracias por utilizar este sistema de noticias";
			?>
			</td>
          </tr>
          <tr>
            <td height="18" class="tabla_centro">
			<?php
			$op = $_GET['op'];
			if($op == "") {
				include("principal.htm");
			}
			else {
				if(file_exists($op.".php")) {
					include($op.".php");
				}
				elseif(file_exists($op.".htm")) {
					include($op.".htm");
				}
				else {
					include("error.htm");
				}
			}
				?>
			</td>
          </tr>
        </table></td>
    </tr>
  </table>
</div>
</body>
</html>
