<?php
if(!$_GET['noticia'] OR $_GET['noticia'] == "") {
$resp = mysql_query("select id,titulo from noticias") or die ("error:\n".mysql_error());
echo "<form action=\"administracion.php?op=borrar_comentario&noticia=si\" method=\"post\">
		<strong>Selecciona la noticia de la que quieres borrar un comentario</strong><br>
		<select name=\"comentario\">";
		while($sql = mysql_fetch_array($resp)) {
			echo "<option value=\"".$sql['id']."\">".$sql['titulo']."\n\n".$sql['id']."</option>";
			}
		echo "</select><br><br>
			  <input type=\"submit\" name=\"enviar\" value=\"Comentarios\">
			  </from>";
} else {
$resp = mysql_query("select id,autor from comentarios where id_noticia='".$_POST['comentario']."'") or die ("error:\n".mysql_error());
echo "<form action=\"procesador.php?op=borrar_comentario\" method=\"post\">
		<strong>Selecciona el comentario a borrar</strong><br>
		<select name=\"borrar\">";
		while($sql = mysql_fetch_array($resp)) {
			echo "<option value=\"".$sql['id']."\">".$sql['autor']."\n\n".$sql['id']."</option>";
			}
		echo "</select><br><br>
			  <input type=\"submit\" name=\"enviar\" value=\"Borrar\">
			  </from>";
}
?>