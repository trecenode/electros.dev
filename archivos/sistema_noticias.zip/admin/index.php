<?php
include("../config.php");
if($_COOKIE['admin']) {
				include("administracion.php");
		} else {
			echo "No tienes acceso<br><br>";
			include("login.htm");
			}
?>