<?php
include("../config.php");
include("../funciones.php");
if(!$_GET['op']) {
if($_COOKIE['admin']) {
$resp = mysql_query("select pass from admin where nick='".$_COOKIE['admin']."'") or die (mysql_error());
if(mysql_num_rows($resp) == 0) {
echo "No hacks";
exit;
} else {
$sql = mysql_fetch_array($resp);
$pass = $sql['pass'];
$pass = md5($pass);
if($_COOKIE['passw'] !== $pass) {
echo "No hacks";
exit;
}
}
} else {
echo "No hacks";
exit;
}
}
ob_start();
switch($_GET['op']) {
case "login":
if(($_GET['nick']) || ($_GET['pass'])) {
echo "Intento de hackeo..";
}
$user = $_POST['nick'];
$passw = $_POST['pass'];
$resp = mysql_query("select pass from admin where nick='".$user."'") or die ("Error en query login:\n".mysql_error());
$total = mysql_num_rows($resp);
if($total == 0) {
echo "No existe este administrador";
} else {
$sql = mysql_fetch_array($resp);
if($passw !== $sql['pass']) {
echo "Te has equivocado";
} else {
$url = "index.php";
$password = md5($passw);
setcookie("admin",$user,time()+776000);
setcookie("passw",$password,time()+776000);
header("location:".$url);
}
}
break;
case "logout":
setcookie("admin");
setcookie("passw");
header("location:index.php");
break;
case "insertar_noticia":
$autor = $_POST['autor']; $autor = vaciar($autor);
$titulo = $_POST['titulo']; $titulo = vaciar($titulo);
$email = $_POST['email']; $email = vaciar($email);
$topic = $_POST['topic']; $topic = vaciar($topic);
$introduccion = $_POST['introduccion'];
$extendida = $_POST['extendida'];
$fecha = time();
mysql_query("insert into noticias (fecha,autor,titulo,email,introduccion,noticia,topic) values ('".$fecha."','".$autor."','".$titulo."','".$email."','".$introduccion."','".$extendida."','".$topic."')") or die ("Error:\n".mysql_error());
header("location:index.php?op=mensajes&txt=insertada");
break;
case "editar_noticia":
$autor = $_POST['autor']; $autor = vaciar($autor);
$titulo = $_POST['titulo']; $titulo = vaciar($titulo);
$email = $_POST['email']; $email = vaciar($email);
$topic = $_POST['topic']; $topic = vaciar($topic);
$introduccion = $_POST['introduccion'];
$extendida = $_POST['extendida'];
$fecha = time();
mysql_query("update noticias set autor='".$autor."',titulo='".$titulo."',fecha='".$fecha."',email='".$email."',topic='".$topic."',introduccion='".$introduccion."',noticia='".$extendida."' where id='".$_POST['id']."'") or die ("error:\n".mysql_error());
header("location:index.php?op=mensajes&txt=editada");
break;
case "borrar_noticia":
$id = $_POST['borrar'];
$resp = mysql_query("select id from comentarios where id_noticia='".$id."'") or die ("error:\n".mysql_error());
if(mysql_num_rows($resp) !== 0) {
echo "Error, debes de borrar antes los comentarios de dicha noticia";
} else {
mysql_query("delete from noticias where id='".$id."'") or die ("error:\n".mysql_error());
header("location:index.php?op=mensajes&txt=borrada");
}
break;
case "agregar_admin":
$nick = $_POST['admin'];
$pass = $_POST['passw'];
$email = $_POST['email'];
mysql_query("insert into admin (nick,pass,email) VALUES ('".$nick."','".$pass."','".$email."')") or die ("Error wn la consulta:\n".mysql_error());
header("location:index.php");
break;
case "borrar_admin":
$id = $_POST['borrar'];
mysql_query("delete from admin where id='".$id."'") or die ("error:\n".mysql_error());
header("location:index.php");
break;
case "borrar_comentario":
$id = $_POST['borrar'];
mysql_query("delete from comentarios where id='".$id."'") or die (mysql_error());
header("location:index.php");
break;
}
ob_end_flush();
?>