<?php
if($_GET['op'] == "editar_noticia" && !$_GET['estado']) {
$resp = mysql_query("select id,titulo from noticias") or die ("error:\n".mysql_error());
echo "<form action=\"index.php?op=editar_noticia&estado=si\" method=\"post\">
		<strong>Selecciona la noticia a editar</strong><br>
		<select name=\"editar\">";
		while($sql = mysql_fetch_array($resp)) {
			echo "<option value=\"".$sql['id']."\">".$sql['titulo']."\n\n".$sql['id']."</option>";
			}
		echo "</select><br><br>
			  <input type=\"submit\" name=\"enviar\" value=\"Editar\">
			  </from>";
}
if(($_GET['op'] == "editar_noticia") && ($_GET['estado'] == "si")) {
$id = $_POST['editar'];
$resp = mysql_query("select * from noticias where id='".$id."'") or die (mysql_error());
if(mysql_num_rows($resp) == 0) {
header("location:index.php?op=editar_noticia&estado=no");
} else {
$sql = mysql_fetch_array($resp);
include("form_editar.htm");
}
}
if(($_GET['op'] == "editar_noticia") && ($_GET['estado'] == "no")) {
echo "No existe esa noticia";
}
?>