<?php
$resp = mysql_query("select id,nick from admin") or die ("error:\n".mysql_error());
echo "<form action=\"procesador.php?op=borrar_admin\" method=\"post\">
		<strong>Selecciona el admin a borrar</strong><br>
		<select name=\"borrar\">";
		while($sql = mysql_fetch_array($resp)) {
			echo "<option value=\"".$sql['id']."\">".$sql['nick']."\n\n".$sql['id']."</option>";
			}
		echo "</select><br><br>
			  <input type=\"submit\" name=\"enviar\" value=\"Borrar\">
			  </from>";
?>