<?
/* conexion db */
$dbhost = "localhost" ;
$dbuser = "x" ;
$dbpass = "x" ;
$db = "x" ;
$conectar = mysql_connect($dbhost,$dbuser,$dbpass) ; mysql_select_db($db,$conectar) ;
/* alguna variable de ocnfiguracion */
$mostrando = 2;//numero de noticias a mostrar x pagina
$mostrando_comentarios = 1;//comentarios a mostrar por pagina
?> 