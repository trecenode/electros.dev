<style type="text/css">
<!--
.style1 {font-size: 9px}
.style2 {color: #000000}
.style3 {font-size: 12px}
-->
</style>
<?
//Contar Tels
$mensajes1 = file("Ttel.txt");
$total1 = count($mensajes1);
//Contar Noms
$mensajes2 = file("Tnom.txt");
$total2 = count($mensajes2);
?>
<title>Telefonos TEC</title><body link="#0099CC" vlink="#0099CC" alink="#0099CC" text="#336699" bgcolor="#000000" style="font-family: Trebuchet MS; font-size: 10px; color: #336699">

<table border="0" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber1" height="115">
  <tr>
    <td width="12%" height="12"></td>
    <td width="78%" height="12">
    <p align="center">
    <img src="images/tels.jpg" alt="Lista de telefonos de los alumnos de INFORMATICA del Tec de Colima" width="149" height="150" border="0"></td>
    <td width="10%" height="12"></td>
  </tr>
  <tr>
    <td height="22">&nbsp;</td>
    <td height="22">&nbsp;</td>
    <td height="22">&nbsp;</td>
  </tr>
  <tr>
    <td width="12%" height="22">&nbsp;</td>
    <td width="78%" height="22"><div align="center" class="style3">Actualmente hay <? echo $total1; ?> telefonos</div></td>
    <td width="10%" height="22">&nbsp;</td>
  </tr>
  <tr>
    <td width="12%" height="22">&nbsp;</td>
    <td width="78%" height="22">
    <table border="0" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber2">
      <tr>
        <td width="19%">&nbsp;</td>
        <td width="62%" style="border-style: dotted; border-width: 1" bordercolor="#0099CC">
        <table border="0" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber3">
          <tr>
            <td width="5%" align="center">&nbsp;</td>
            <td width="37%" align="left"><font size="2">Tel</font></td>
            <td width="58%" align="left"><font size="2">Nombre</font></td>
          </tr>


<?php
//iniciar desplegado
$maximo=-1;

while($maximo < $total1-1)
{
	$maximo++ ;
	$mensajep1 = $mensajes1[$maximo] ;
	$mensajep2 = $mensajes2[$maximo] ;
?>
	<tr
     onMouseOver="this.style.backgroundColor='#00CCFF';" 
     onMouseOut="this.style.backgroundColor='#000000';"
          >
            <td width="5%" align="center">
            <img border="0" src="images/FMI.jpg" width="14" height="14"></td>
            <td width="37%"><font size="2"><? echo $mensajep1 ?></font></td>
            <td width="58%"><font size="2"><? echo $mensajep2 ?></font></td>
    </tr>
<?php
}
?>
</table>
<td width="19%">&nbsp;</td>
</table>
</table>
<br>
<table border="0" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber4">
	<tr>
	<td width="78%" height="22">
    <form method="POST" action="instel.php">
      <!--webbot bot="SaveResults" u-file="fpweb:///_private/form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" --><p align="center">
      <font size="2">Nombre </font>
      <input type="text" name="nom" size="20" style="color: #FFFFFF; font-size: 8pt; font-family: Trebuchet MS; border-style: solid; border-width: 1; background-color: #0099CC"><font size="2">
      Telefono </font>
      <input type="text" name="tel" size="20" style="color: #FFFFFF; font-size: 8pt; font-family: Trebuchet MS; border-style: solid; border-width: 1; background-color: #0099CC">
      <font size="2">  
      </font>
      <input type="submit" value="Insertar Tel" name="insertar" style="color: #FFFFFF; font-family: Trebuchet MS; font-size: 8pt; border-style: solid; border-width: 1; background-color: #0099CC">
</p>
    </form>
    </td>
	</tr>
</table>
<table><tr>
  <td></td>
  <td><div align="center" class="style2">g</div></td>
  <td></td>
<tr>
  <td width="111"></td>
  <td width="753"><center>
    <span class="style1">Designed and Scripted by</span><br>
    <a href="http://www.dagasmx.tk"><img src="images/Adagas.gif" alt="Entra y descubre !!!!" width="96" height="96" border="0"></a>      
  </center></td>
<td width="93"></td>
</table>
