<body link="#0099CC" vlink="#0099CC" alink="#0099CC" text="#336699" bgcolor="#000000" style="font-family: Trebuchet MS; font-size: 12px; color: #336699">
<?php
	if($nom ==""){ $msg= "<b><i>[Escribe el nombre]</i></b>";}
		else if($tel ==""){ $msg= "[<b><i>Escribe el telefono]</i></b>";}
		else {
			$archivo1 = fopen("Ttel.txt","a");
			$palabras1 = explode(" ",$tel);
			$cantidad1 = count($palabras1);
			$mensaje1 = implode(" ",$palabras1);
			fwrite($archivo1,"$tel\n");
			fclose($archivo1);
			//
			$archivo2 = fopen("Tnom.txt","a");
			$palabras2 = explode(" ",$nom);
			$cantidad2 = count($palabras2);
			$mensaje2 = implode(" ",$palabras2);
			fwrite($archivo2,"$nom\n");
			fclose($archivo2);
			//
			$msg= "Se insert� correctamente a <b><i>[".$nom."]</i></b> y su telefono <b><i>[".$tel."]</i></b>";
	}//end else..
	
	
?>
<center><img src="images/tels.jpg" alt="Has usado la agenda de telefonos de daga&sect;" width="149" height="150">
</center>
<center><br>
Gracias por usar el directorio telefonico
</center><br>
<center>
  <? echo $msg ?>
  <p>Haz click <a href="tels.php">aqui</a> para regresar</p>
  <p>&nbsp;</p>
  <p><a href="http://www.dagasmx.tk"><img src="images/Adagas.jpg" alt="Entra y Descubre !!!" width="96" height="96" border="0"></a></p>
</center>
</body>