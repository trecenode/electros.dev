<?php // 
if (($PHP_AUTH_USER!="usuario") || ($PHP_AUTH_PW!="contrase�a")) { 
header('WWW-Authenticate: Basic realm="Acceso restringido"'); 
header('HTTP/1.0 401 Unauthorized'); 
echo 'Authorization Required.'; 
exit; 
} 
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php echo $PHP_AUTH_USER?> has entrado a la zona restringida<br>
<br>
<br>
</body>
</html>
