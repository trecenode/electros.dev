<?

$admin_name = "Joe Bloggs";			// For the admin control Panel : )
$user = "username";			// your admin username
$pass = "password";		// your admin password

$your_url = "http://www.yoursite.com/dynamicpoll";		// your URL to poll files no trailing slash
$imgurl = "http://www.yoursite.com/dynamicpoll/bar.gif";			// url to bar.gif
$poll_bar_height = "5";						// the height of your poll bar in pixels, 5 is default

$stylesheet_url = "http://www.yoursite.com/css/css.css";	// leave blank ( = ""; ) for default

$nopoll = "No Poll Open";							// text displayed when no poll open
$voted_already = "Already Voted";				// text displayed when visitor has already voted on poll
$view_archive = "View Archive";					// text displayed to view archive
$vote_button_text = "Vote!";
$random_display = false;                     // change this to false if you do not want your polls to be displayed in random order
$thankyou_message = true;			// change to false if you want the poll to refresh the page after voting, otherwise a thank you message will be displayed

$version = "2.0";			// version number

?>