<?
$path =  __FILE__;
$path = preg_replace( "'\\\archive\.php'", "", $path);
$path = preg_replace( "'/archive\.php'", "", $path);
include($path."/poll_config.php");
if($stylesheet_url == "")
	$stylesheet_url = $path."/default_stylesheet.css";
?>
<link rel="stylesheet" href="<? echo $stylesheet_url ?>" type="text/css">
<FONT SIZE="3"><B>Poll Archive</B></FONT><br><br>
<?
$dir = dir($path."/archivedata"); //Create a directory object to the current directory
$polls = array();
$i = 0;
while($dir_entry = $dir->read()){
	if(strstr($dir_entry,"archived")){
		$polls[$i] = $dir_entry;
		$i++;
	}
}
if($i == 0){
	echo "<b>No Archived Polls</b>";
}
else{
	if(isset($_GET['showpoll'])){
		$pollid = $_GET['showpoll'];
		if(empty($polls[$pollid])) $pollid = 0;
	}
	else{
		if(!isset($_POST['pollid'])) $pollid = 0;
		else $pollid = intval($_POST['pollid']);
	}
	$pollfile = $path."/archivedata/".$polls[$pollid];
	
	$delete = array("archived_",".txt");
	$pollid_date = str_replace($delete, "", $polls[$pollid]);
	$data = explode("_", $pollid_date);
	$date = date("D j\<\s\u\p\>S\<\/\s\u\p\> F", $data[1]);
	
	include($pollfile);
?>
<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Archived On</td>
    <td width="99%"><? echo $date; ?></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Poll Question:&nbsp; </td>
    <td width="99%"><? echo stripslashes($ask); ?></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Total Votes:</td>
    <td width="99%"><? echo $total; ?></td>
  </tr>
  <tr>
    <td width="100%" colspan="2">
      <table border="0" cellpadding="5" cellspacing="0" width="100%">
	  <?for($i=0;$i<count($a);$i++){
			$a[$i] = stripslashes($a[$i]);
			if($a[$i] != "" && $v[$i] != ""){ 
				$percentage = (round(($v[$i] / $total) * 100, 1));
		?>
        <tr>
          <td width="1%" nowrap></td>
          <td width="1%" nowrap><? echo $a[$i]; ?></td>
          <td width="1%" nowrap><? echo $v[$i]; ?> vote<? if($v[$i] != 1) echo "s"; ?> (<? echo $percentage; ?>%)</td>
          <td width="97%">
            <table border="0" cellpadding="0" cellspacing="0" width="<? echo (round(($v[$i] / $total) * 80, 0)); ?>" height="<? echo $poll_bar_height; ?>">
              <tr>
                <td bgcolor="#C0C0C0"></td>
              </tr>
            </table>
          </td>
        </tr>
		<?}
		}
		?>
      </table>
    </td>
  </tr>
</table>
<hr>
<?
printNextPrev($pollid);
}

function printNextPrev($pollid){
	global $path;
	$nextpoll = $pollid + 1;
	$prevpoll = $pollid - 1;
	$dir = dir($path."/archivedata"); //Create a directory object to the current directory
	$polls = array();
	$i = 0;
	while($dir_entry = $dir->read()){
		if(strstr($dir_entry,"archived")){
			$polls[$i] = $dir_entry;
			$i++;
		}
	}
	if(!empty($polls[$prevpoll])) echo "<small><A HREF=\"".$_SERVER['PHP_SELF']."?showpoll=$prevpoll\"><< Prev</A>&nbsp;&nbsp;</small>";
	if(!empty($polls[$nextpoll])) echo "<small><A HREF=\"".$_SERVER['PHP_SELF']."?showpoll=$nextpoll\">Next >></A></small>";
}
?>