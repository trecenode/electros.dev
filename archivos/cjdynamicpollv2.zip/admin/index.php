<?
header("Location: admin_index.php");
?>