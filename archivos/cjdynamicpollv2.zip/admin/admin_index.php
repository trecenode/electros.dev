<?
session_start();
header("Cache-control: private"); // IE 6 Fix. 
include "../poll_config.php";
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-gb">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>CJ Dynamic Poll V2.0 Admin</title>
<link rel="stylesheet" href="admin_stylesheet.php" type="text/css">
</head>
<body>
  <table border="0" cellpadding="5" cellspacing="0" width="100%">
    <tr>
      <td>
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td width="100%">
		  				<img border="0" src="topleft.jpg" width="120" height="70"></td>
                  </tr>
                  <tr>
                    <td width="100%"><img border="0" src="top.jpg" width="700" height="23"></td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td width="100%">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td width="1%" bgcolor="#216767" valign="top" style="border-left: 1 solid #C5C5C5; border-right: 1 solid #C5C5C5">
                      <table border="0" cellpadding="5" cellspacing="0" width="120">
                        <tr>
                          <td class="menu">
						  	<?
							if (!isset($_SESSION['username']) && !isset($_SESSION['password'])){
								print "You must be logged in to view the Admin Control Panel";
							}
							else if (isset($_SESSION['username']) && isset($_SESSION['password'])){
							?>
						  <b>Polls</b><br>
				  &nbsp; <A class="menu" HREF="?action=view">Manage</A><br>				
                  &nbsp; <A class="menu" HREF="?action=new">Create</A><br><br>
						  <b>Archives</b><br>
	             &nbsp; <A class="menu" HREF="?action=view_archive">Manage</A><br>
				  &nbsp; <A class="menu" HREF="?action=delete_archives">Delete</A><br><br>
						  <b>Info</b><br>
	             &nbsp; <A class="menu" HREF="?action=upgrade">Upgrade</A><br>
				  &nbsp; <A class="menu" HREF="?action=about">About</A><br>
				  &nbsp; <A class="menu" HREF="?action=support">Support</A><br>
                  &nbsp; <font color=red><A class="menu" HREF="?action=logout">Logout</A></font>
				  		  <?
							}
							?>
						</td>
                        </tr>
                      </table>
                    </td>
                    <td width="99%" valign="top">
                      <table border="0" cellpadding="5" cellspacing="0" width="100%">
                        <tr>
                          <td width="100%">
						  	<?
							if (!isset($_SESSION['username']) && !isset($_SESSION['password'])){
								include "login.php";
							}
							else if (isset($_SESSION['username']) && isset($_SESSION['password'])){
								include "admin.php";
							}
							?>						  
						  </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td width="100%"><img border="0" src="bottom.jpg" width="700" height="23"></td>
            </tr>
          </table>
      </td>
    </tr>
  </table>
</body>
</html>
<?
/*
print "Testing Security:<br>";
print '<pre>';
print_r($GLOBALS);
PRINT '</pre>';
*/
?>
