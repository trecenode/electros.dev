<?
function viewArchives(){
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function ConfirmIt(type,operation,url){
		if (confirm("Warning!\n\nClicking 'OK' will " + type + " the " + operation + " permanently\n\nExisting " + operation + " will be lost!"))
			location.href=url;
	}
	// -->
	</SCRIPT>
	<?
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Archive Management</B></FONT><br><br>";
	$dir = dir("../archivedata"); //Create a directory object to the current directory
	$polls = array();
	$i = 0;
	while($dir_entry = $dir->read()){
		if(strstr($dir_entry,"archived")){
			$polls[$i] = $dir_entry;
			$i++;
		}
	}

	if($i == 0){
		echo "There have been no archived polls";
	}
	else{
		echo "There are currently $i archived polls:<br>";
		?>
		<table border="0" cellpadding="10" cellspacing="0" width="4%">
		   <tr>
		    <td width="1%" nowrap><B>Name</B></td>
		    <td width="1%" nowrap><B>Archived On</B></td>
		    <td width="1%" nowrap colspan="2"><B>Operations</B></td>
		  </tr>
		<?
		$delete = array("archived_",".txt");
		for($j=0;$j<count($polls);$j++){
			$pollid_date = str_replace($delete, "", $polls[$j]);
			$data = explode("_", $pollid_date);
			$pollid = $data[0];
			$date = date("D j\<\s\u\p\>S\<\/\s\u\p\> F", $data[1]);

			?>
			  <tr>
		    <td width="1%" nowrap><li><B><FONT SIZE="2" COLOR="maroon">Poll <? echo $pollid; ?></FONT></B></td>
		    <td width="1%" nowrap><? echo $date; ?></td>
			<td width="1%" nowrap>[<A HREF="?action=edit_archive&pollid=<? echo $pollid; ?>&ts=<? echo $data[1]; ?>">Edit</A>]</td>
		    <td width="1%" nowrap>[<A HREF="javascript:ConfirmIt('delete','archive data','?action=delete_archive&pollid=<? echo $pollid; ?>&ts=<? echo $data[1]; ?>')"><FONT COLOR="red">Delete</FONT></A>]</td>
		  </tr>
	  <?
		}
		?>
		</table>
		<?		
	}

}

function deleteArchivesConfirm(){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Delete Archives</B></FONT><br><br>";	
	echo "Deleting the archives will delete ALL of your archive data at once and no archive will show up on your page<br>";
	echo "To confirm deletion of your archives, click the button below:<br>";
	echo "<form method=\"post\" action=\"?action=delete_archives\">";
	echo "<input type=\"hidden\" name=\"sure\" value=\"true\">";
	echo "<input type=\"submit\" name=\"submit\" value=\"Delete Archives\">";
	echo "</form>";

}

function deleteArchives(){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Delete Archives</B></FONT><br><br>";	
	$dir = dir("../archivedata"); //Create a directory object to the current directory
	$polls = array();
	$i = 0;
	while($dir_entry = $dir->read()){
		if(strstr($dir_entry,"archived")){
			$polls[$i] = $dir_entry;
			$i++;
		}
	}
	if($i == 0){
		echo "There are no archives to delete";
	}
	else{
		$errors = false;
		for($j=0;$j<count($polls);$j++){
			if(!@unlink("../archivedata/".$polls[$j])){
				echo "Could not delete ".$polls[$j]."<br>";
				$errors = true;
			}
			else{
				echo $polls[$j]." deleted successfully<br>";
			}
		}
		if($errors){
			echo "<br><br>We could not automatically delete one or more of the archive files, FTP to<br>";
			echo "the folder 'archivedata' and delete all files starting with 'archived_'.<br><br>";
		}
		else{
			echo "<br><br>Deleted ".count($polls)." archives";
		}
	}

}

function deleteArchive($id, $ts){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Delete Archive</B></FONT><br><br>";	
	if(!@unlink("../archivedata/archived_".$id."_".$ts.".txt")){
		echo "We could not automatically delete the archive file, FTP to<br>";
		echo "the folder 'archivedata' and delete 'archived_$id_$ts.txt'.<br><br>";
	}
	else{
		echo "The archive was deleted successfully.";
	}
}

function deletePoll($id){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Delete Poll</B></FONT><br><br>";	
	if(!@unlink("../polldata/poll_".$id.".txt")){
		echo "We could not automatically delete the poll file, FTP to<br>";
		echo "the folder 'polldata' and delete 'poll_$id.txt'.<br><br>";
	}
	else{
		echo "The poll was deleted successfully.";
	}
	@unlink("../polldata/ips_".$id.".php");
}

function archivePoll($id){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Archive Poll</B></FONT><br><br>";	
	$now = time();
	if (!@copy("../polldata/poll_".$id.".txt", "../archivedata/archived_".$id."_".$now.".txt")) {
		echo "The poll could not be archived, check that the 'archivedata' folder<br>";
		echo "exists and is set permissions 777 (using CHMOD)<br><br>";
		$copied = false;
	}
	else{
		$copied = true;
	}
	
	if($copied){
		echo "The poll has been archived successfully<br><br>";
		if(!@unlink("../polldata/poll_".$id.".txt")){
			echo "However, we could not automatically delete the poll file, FTP to<br>";
			echo "the folder 'polldata' and delete 'poll_$id.txt'.<br><br>";
		}
		@unlink("../polldata/ips_".$id.".php");
	}
}

function resetPollVotes($id){
	include("../polldata/poll_".$id.".txt");
	$file = fopen("../polldata/poll_".$id.".txt","w+");
	fputs ($file, "<?\n");
	fputs ($file, "\$a[0] = \"$a[0]\";\n");
	fputs ($file, "\$a[1] = \"$a[1]\";\n");
	fputs ($file, "\$a[2] = \"$a[2]\";\n");
	fputs ($file, "\$a[3] = \"$a[3]\";\n");
	fputs ($file, "\$a[4] = \"$a[4]\";\n");
	fputs ($file, "\$a[5] = \"$a[5]\";\n");
	fputs ($file, "\$a[6] = \"$a[6]\";\n");
	fputs ($file, "\$a[7] = \"$a[7]\";\n");
	fputs ($file, "\$a[8] = \"$a[8]\";\n");
	fputs ($file, "\$a[9] = \"$a[9]\";\n\n");
	if ($a[0] == "") { fputs ($file, "\$v[0] = \"\";\n"); } else { fputs ($file, "\$v[0] = \"0\";\n"); }
	if ($a[1] == "") { fputs ($file, "\$v[1] = \"\";\n"); } else { fputs ($file, "\$v[1] = \"0\";\n"); }
	if ($a[2] == "") { fputs ($file, "\$v[2] = \"\";\n"); } else { fputs ($file, "\$v[2] = \"0\";\n"); }
	if ($a[3] == "") { fputs ($file, "\$v[3] = \"\";\n"); } else { fputs ($file, "\$v[3] = \"0\";\n"); }
	if ($a[4] == "") { fputs ($file, "\$v[4] = \"\";\n"); } else { fputs ($file, "\$v[4] = \"0\";\n"); }
	if ($a[5] == "") { fputs ($file, "\$v[5] = \"\";\n"); } else { fputs ($file, "\$v[5] = \"0\";\n"); }
	if ($a[6] == "") { fputs ($file, "\$v[6] = \"\";\n"); } else { fputs ($file, "\$v[6] = \"0\";\n"); }
	if ($a[7] == "") { fputs ($file, "\$v[7] = \"\";\n"); } else { fputs ($file, "\$v[7] = \"0\";\n"); }
	if ($a[8] == "") { fputs ($file, "\$v[8] = \"\";\n"); } else { fputs ($file, "\$v[8] = \"0\";\n"); }
	if ($a[9] == "") { fputs ($file, "\$v[9] = \"\";\n"); } else { fputs ($file, "\$v[9] = \"0\";\n\n"); }
	fputs ($file, "\$total = \"0\";\n");
	fputs ($file, "\$ask = \"$ask\";\n");
	fputs ($file, "?>");
	fclose ($file);
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Poll Votes Reset</B></FONT><br><br>";	
	viewSinglePoll($id);
}

function resetPollIPs($id){
	$ipfile = fopen("../polldata/ips_".$id.".php","w");
	fputs ($ipfile, "");
	fclose ($ipfile);
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>IP File Reset</B></FONT><br><br>";
	echo "The IP file for poll $id has been reset!";

}

function viewSinglePoll($id){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Viewing Poll</B></FONT><br><br>";
	include("../polldata/poll_".$id.".txt");
	?>
	<table border="0" cellpadding="2" cellspacing="0" width="100%">
  <tr>
    <td width="100%"><FONT SIZE="2" COLOR="maroon"><B><? echo stripslashes($ask); ?></B></FONT></td>
  </tr>
  <tr>
    <td width="100%">
      <table border="0" cellpadding="5" cellspacing="0" width="100%">
        <tr>
          <td width="1%" nowrap><B>Answers</B></td>
          <td width="99%"><B>Votes</B></td>
        </tr>
		<?
		for($i=0;$i<count($a);$i++){
			if($a[$i] != ""){
		?>
    		   <tr>
	          <td width="1%" nowrap><? echo stripslashes($a[$i]); ?></td>
		      <td width="99%"><? echo $v[$i]; ?></td>
	        </tr>
		<?
			}
		}
		?>
    		   <tr>
	          <td width="1%" nowrap><div align="right"><B>Total</B></div></td>
		      <td width="99%"><? echo $total; ?></td>
	        </tr>
      </table>
	  </td>
</table>
	<?
}


function editArchiveForm($id, $ts, $errors){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Edit Archived Poll $id</B></FONT><br><br>";
	echo "<font color=\"red\">$errors</font>";
	include("../archivedata/archived_".$id."_".$ts.".txt");
?>
<form method="post" action="?action=edit_archive">
<input type="hidden" name="pollid" value="<? echo $id; ?>">
<input type="hidden" name="ts" value="<? echo $ts; ?>">
<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><input type="text" name="question" size="36" value="<? echo stripslashes($ask); ?>"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><input type="text" name="answer[0]" size="36" value="<? echo stripslashes($a[0]); ?>">&nbsp;<input type="text" name="votes[0]" size="5" value="<? echo $v[0]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><input type="text" name="answer[1]" size="36" value="<? echo stripslashes($a[1]); ?>">&nbsp;<input type="text" name="votes[1]" size="5" value="<? echo $v[1]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><input type="text" name="answer[2]" size="36" value="<? echo stripslashes($a[2]); ?>">&nbsp;<input type="text" name="votes[2]" size="5" value="<? echo $v[2]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><input type="text" name="answer[3]" size="36" value="<? echo stripslashes($a[3]); ?>">&nbsp;<input type="text" name="votes[3]" size="5" value="<? echo $v[3]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><input type="text" name="answer[4]" size="36" value="<? echo stripslashes($a[4]); ?>">&nbsp;<input type="text" name="votes[4]" size="5" value="<? echo $v[4]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><input type="text" name="answer[5]" size="36" value="<? echo stripslashes($a[5]); ?>">&nbsp;<input type="text" name="votes[5]" size="5" value="<? echo $v[5]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><input type="text" name="answer[6]" size="36" value="<? echo stripslashes($a[6]); ?>">&nbsp;<input type="text" name="votes[6]" size="5" value="<? echo $v[6]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><input type="text" name="answer[7]" size="36" value="<? echo stripslashes($a[7]); ?>">&nbsp;<input type="text" name="votes[7]" size="5" value="<? echo $v[7]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><input type="text" name="answer[8]" size="36" value="<? echo stripslashes($a[8]); ?>">&nbsp;<input type="text" name="votes[8]" size="5" value="<? echo $v[8]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><input type="text" name="answer[9]" size="36" value="<? echo stripslashes($a[9]); ?>">&nbsp;<input type="text" name="votes[9]" size="5" value="<? echo $v[9]; ?>"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Total Votes</td>
    <td width="99%"><input type="text" name="edittotal" size="10" value="<? echo $total; ?>"></td>
  </tr>
    <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap></td>
    <td width="99%"><input type="submit" value="Edit Archive" name="editPoll"></td>
  </tr>
</table>
</form>
<?
}

function editPollForm($id,$errors){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Edit Poll $id</B></FONT><br><br>";
	echo "<font color=\"red\">$errors</font>";
	include("../polldata/poll_".$id.".txt");
?>
<form method="post" action="?action=edit_poll">
<input type="hidden" name="pollid" value="<? echo $id; ?>">
<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><input type="text" name="question" size="36" value="<? echo stripslashes($ask); ?>"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><input type="text" name="answer[0]" size="36" value="<? echo stripslashes($a[0]); ?>">&nbsp;<input type="text" name="votes[0]" size="5" value="<? echo $v[0]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><input type="text" name="answer[1]" size="36" value="<? echo stripslashes($a[1]); ?>">&nbsp;<input type="text" name="votes[1]" size="5" value="<? echo $v[1]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><input type="text" name="answer[2]" size="36" value="<? echo stripslashes($a[2]); ?>">&nbsp;<input type="text" name="votes[2]" size="5" value="<? echo $v[2]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><input type="text" name="answer[3]" size="36" value="<? echo stripslashes($a[3]); ?>">&nbsp;<input type="text" name="votes[3]" size="5" value="<? echo $v[3]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><input type="text" name="answer[4]" size="36" value="<? echo stripslashes($a[4]); ?>">&nbsp;<input type="text" name="votes[4]" size="5" value="<? echo $v[4]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><input type="text" name="answer[5]" size="36" value="<? echo stripslashes($a[5]); ?>">&nbsp;<input type="text" name="votes[5]" size="5" value="<? echo $v[5]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><input type="text" name="answer[6]" size="36" value="<? echo stripslashes($a[6]); ?>">&nbsp;<input type="text" name="votes[6]" size="5" value="<? echo $v[6]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><input type="text" name="answer[7]" size="36" value="<? echo stripslashes($a[7]); ?>">&nbsp;<input type="text" name="votes[7]" size="5" value="<? echo $v[7]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><input type="text" name="answer[8]" size="36" value="<? echo stripslashes($a[8]); ?>">&nbsp;<input type="text" name="votes[8]" size="5" value="<? echo $v[8]; ?>"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><input type="text" name="answer[9]" size="36" value="<? echo stripslashes($a[9]); ?>">&nbsp;<input type="text" name="votes[9]" size="5" value="<? echo $v[9]; ?>"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Total Votes</td>
    <td width="99%"><input type="text" name="edittotal" size="10" value="<? echo $total; ?>"></td>
  </tr>
    <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap></td>
    <td width="99%"><input type="submit" value="Edit Poll" name="editPoll"></td>
  </tr>
</table>
</form>
<?
}


function editArchive($id,$ts,$question,$answer,$votes,$edittotal){
	$file = fopen("../archivedata/archived_".$id."_".$ts.".txt","w+");
	fputs ($file, "<?\n");
	fputs ($file, "\$a[0] = \"$answer[0]\";\n");
	fputs ($file, "\$a[1] = \"$answer[1]\";\n");
	fputs ($file, "\$a[2] = \"$answer[2]\";\n");
	fputs ($file, "\$a[3] = \"$answer[3]\";\n");
	fputs ($file, "\$a[4] = \"$answer[4]\";\n");
	fputs ($file, "\$a[5] = \"$answer[5]\";\n");
	fputs ($file, "\$a[6] = \"$answer[6]\";\n");
	fputs ($file, "\$a[7] = \"$answer[7]\";\n");
	fputs ($file, "\$a[8] = \"$answer[8]\";\n");
	fputs ($file, "\$a[9] = \"$answer[9]\";\n\n");
	fputs ($file, "\$v[0] = \"$votes[0]\";\n");
	fputs ($file, "\$v[1] = \"$votes[1]\";\n");
	fputs ($file, "\$v[2] = \"$votes[2]\";\n");
	fputs ($file, "\$v[3] = \"$votes[3]\";\n");
	fputs ($file, "\$v[4] = \"$votes[4]\";\n");
	fputs ($file, "\$v[5] = \"$votes[5]\";\n");
	fputs ($file, "\$v[6] = \"$votes[6]\";\n");
	fputs ($file, "\$v[7] = \"$votes[7]\";\n");
	fputs ($file, "\$v[8] = \"$votes[8]\";\n");
	fputs ($file, "\$v[9] = \"$votes[9]\";\n\n");
	fputs ($file, "\$total = \"$edittotal\";\n");
	fputs ($file, "\$ask = \"$question\";\n");
	fputs ($file, "?>");
	fclose ($file);
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Archive Edited<B></FONT><br><br>";

	?>
	<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><? echo stripslashes($question); ?></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <? if($answer[0] != ""){ ?>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><? echo stripslashes($answer[0]); ?></td>
  </tr>
  <?}
	if($answer[1] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><? echo stripslashes($answer[1]); ?></td>
  </tr>
    <?}
	if($answer[2] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><? echo stripslashes($answer[2]); ?></td>
  </tr>
    <?}
	if($answer[3] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><? echo stripslashes($answer[3]); ?></td>
  </tr>
    <?}
	if($answer[4] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><? echo stripslashes($answer[4]); ?></td>
  </tr>
    <?}
	if($answer[5] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><? echo stripslashes($answer[5]); ?></td>
  </tr>
    <?}
	if($answer[6] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><? echo stripslashes($answer[6]); ?></td>
  </tr>
    <?}
	if($answer[7] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><? echo stripslashes($answer[7]); ?></td>
  </tr>
    <?}
	if($answer[8] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><? echo stripslashes($answer[8]); ?></td>
  </tr>
    <?}
	if($answer[9] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><? echo stripslashes($answer[9]); ?></td>
  </tr>
  <?}?>
</table>
<?


}

function editPoll($id,$question,$answer,$votes,$edittotal){
	$file = fopen("../polldata/poll_".$id.".txt","w+");
	fputs ($file, "<?\n");
	fputs ($file, "\$a[0] = \"$answer[0]\";\n");
	fputs ($file, "\$a[1] = \"$answer[1]\";\n");
	fputs ($file, "\$a[2] = \"$answer[2]\";\n");
	fputs ($file, "\$a[3] = \"$answer[3]\";\n");
	fputs ($file, "\$a[4] = \"$answer[4]\";\n");
	fputs ($file, "\$a[5] = \"$answer[5]\";\n");
	fputs ($file, "\$a[6] = \"$answer[6]\";\n");
	fputs ($file, "\$a[7] = \"$answer[7]\";\n");
	fputs ($file, "\$a[8] = \"$answer[8]\";\n");
	fputs ($file, "\$a[9] = \"$answer[9]\";\n\n");
	fputs ($file, "\$v[0] = \"$votes[0]\";\n");
	fputs ($file, "\$v[1] = \"$votes[1]\";\n");
	fputs ($file, "\$v[2] = \"$votes[2]\";\n");
	fputs ($file, "\$v[3] = \"$votes[3]\";\n");
	fputs ($file, "\$v[4] = \"$votes[4]\";\n");
	fputs ($file, "\$v[5] = \"$votes[5]\";\n");
	fputs ($file, "\$v[6] = \"$votes[6]\";\n");
	fputs ($file, "\$v[7] = \"$votes[7]\";\n");
	fputs ($file, "\$v[8] = \"$votes[8]\";\n");
	fputs ($file, "\$v[9] = \"$votes[9]\";\n\n");
	fputs ($file, "\$total = \"$edittotal\";\n");
	fputs ($file, "\$ask = \"$question\";\n");
	fputs ($file, "?>");
	fclose ($file);
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Poll Edited<B></FONT><br><br>";

	?>
	<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><? echo stripslashes($question); ?></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <? if($answer[0] != ""){ ?>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><? echo stripslashes($answer[0]); ?></td>
  </tr>
  <?}
	if($answer[1] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><? echo stripslashes($answer[1]); ?></td>
  </tr>
    <?}
	if($answer[2] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><? echo stripslashes($answer[2]); ?></td>
  </tr>
    <?}
	if($answer[3] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><? echo stripslashes($answer[3]); ?></td>
  </tr>
    <?}
	if($answer[4] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><? echo stripslashes($answer[4]); ?></td>
  </tr>
    <?}
	if($answer[5] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><? echo stripslashes($answer[5]); ?></td>
  </tr>
    <?}
	if($answer[6] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><? echo stripslashes($answer[6]); ?></td>
  </tr>
    <?}
	if($answer[7] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><? echo stripslashes($answer[7]); ?></td>
  </tr>
    <?}
	if($answer[8] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><? echo stripslashes($answer[8]); ?></td>
  </tr>
    <?}
	if($answer[9] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><? echo stripslashes($answer[9]); ?></td>
  </tr>
  <?}?>
</table>
<?


}

function viewPolls(){
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function ConfirmIt(type,operation,url){
		if (confirm("Warning!\n\nClicking 'OK' will " + type + " the " + operation + " permanently\n\nExisting " + operation + " will be lost!"))
			location.href=url;
	}
	function ConfirmArchive(url){
		if (confirm("Warning!\n\nClicking 'OK' will archive this poll\n\nThis poll will no longer be available to vote on"))
			location.href=url;
	}
	// -->
	</SCRIPT>
	<?
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Poll Management</B></FONT><br><br>";
	$dir = dir("../polldata"); //Create a directory object to the current directory
	$polls = array();
	$i = 0;
	while($dir_entry = $dir->read()){
		if(strstr($dir_entry,"poll")){
			$polls[$i] = $dir_entry;
			$i++;
		}
	}

	if($i == 0){
		echo "There have been no polls created";
	}
	else{
		echo "There are currently $i polls active:<br>";
		?>
		<table border="0" cellpadding="7" cellspacing="0" width="4%">
		   <tr>
		    <td width="1%" nowrap><B>Poll Name</B></td>
		    <td width="1%" nowrap colspan="6"><B>Operations</B></td>
		  </tr>
		<?
		$delete = array("poll_",".txt");
		for($j=0;$j<count($polls);$j++){
			$pollid = str_replace($delete, "", $polls[$j]);
			?>
			  <tr>
		    <td width="1%" nowrap><li><B><FONT SIZE="2" COLOR="maroon">Poll <? echo $pollid; ?></FONT></B></td>
		    <td width="1%" nowrap>[<A HREF="?action=view_poll&pollid=<? echo $pollid; ?>">View</A>]</td>
			<td width="1%" nowrap>[<A HREF="?action=edit_poll&pollid=<? echo $pollid; ?>">Edit</A>]</td>
		    <td width="1%" nowrap>[<A HREF="javascript:ConfirmIt('reset','vote data','?action=reset_poll&pollid=<? echo $pollid; ?>')">Reset Votes</A>]</td>
		    <td width="1%" nowrap>[<A HREF="javascript:ConfirmIt('reset','IP data','?action=reset_poll_ip&pollid=<? echo $pollid; ?>')">Reset IPs</A>]</td>
		    <td width="1%" nowrap>[<A HREF="javascript:ConfirmArchive('?action=archive_poll&pollid=<? echo $pollid; ?>')">Archive/Close</A>]</td>
		    <td width="1%" nowrap>[<A HREF="javascript:ConfirmIt('delete','poll data','?action=delete_poll&pollid=<? echo $pollid; ?>')"><FONT COLOR="red">Delete</FONT></A>]</td>
		  </tr>
	  <?
		}
		?>
		</table>
		<?		
	}

}


function createNewPoll($q, $ans){

	include("../pollcount.php");
	$file = fopen("../polldata/poll_".$pollcount.".txt","w");
	$ipfile = fopen("../polldata/ips_".$pollcount.".php","w");
	fputs ($file, "<?\n");
	fputs ($file, "\$a[0] = \"$ans[0]\";\n");
	fputs ($file, "\$a[1] = \"$ans[1]\";\n");
	fputs ($file, "\$a[2] = \"$ans[2]\";\n");
	fputs ($file, "\$a[3] = \"$ans[3]\";\n");
	fputs ($file, "\$a[4] = \"$ans[4]\";\n");
	fputs ($file, "\$a[5] = \"$ans[5]\";\n");
	fputs ($file, "\$a[6] = \"$ans[6]\";\n");
	fputs ($file, "\$a[7] = \"$ans[7]\";\n");
	fputs ($file, "\$a[8] = \"$ans[8]\";\n");
	fputs ($file, "\$a[9] = \"$ans[9]\";\n\n");
	if ($ans[0] == "") { fputs ($file, "\$v[0] = \"\";\n"); } else { fputs ($file, "\$v[0] = \"0\";\n"); }
	if ($ans[1] == "") { fputs ($file, "\$v[1] = \"\";\n"); } else { fputs ($file, "\$v[1] = \"0\";\n"); }
	if ($ans[2] == "") { fputs ($file, "\$v[2] = \"\";\n"); } else { fputs ($file, "\$v[2] = \"0\";\n"); }
	if ($ans[3] == "") { fputs ($file, "\$v[3] = \"\";\n"); } else { fputs ($file, "\$v[3] = \"0\";\n"); }
	if ($ans[4] == "") { fputs ($file, "\$v[4] = \"\";\n"); } else { fputs ($file, "\$v[4] = \"0\";\n"); }
	if ($ans[5] == "") { fputs ($file, "\$v[5] = \"\";\n"); } else { fputs ($file, "\$v[5] = \"0\";\n"); }
	if ($ans[6] == "") { fputs ($file, "\$v[6] = \"\";\n"); } else { fputs ($file, "\$v[6] = \"0\";\n"); }
	if ($ans[7] == "") { fputs ($file, "\$v[7] = \"\";\n"); } else { fputs ($file, "\$v[7] = \"0\";\n"); }
	if ($ans[8] == "") { fputs ($file, "\$v[8] = \"\";\n"); } else { fputs ($file, "\$v[8] = \"0\";\n"); }
	if ($ans[9] == "") { fputs ($file, "\$v[9] = \"\";\n\n"); } else { fputs ($file, "\$v[9] = \"0\";\n\n"); }
	fputs ($file, "\$total = \"0\";\n");
	fputs ($file, "\$ask = \"$q\";\n");
	fputs ($file, "?>");
	fclose ($file);

	$newpollcount = $pollcount + 1;
	$write = "<? $" . "pollcount = " . $newpollcount . "; ?>";
	$countwrite = fopen("../pollcount.php", "w");
	fwrite ($countwrite, $write);
	fclose ($countwrite);

	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>New Poll Created</B></FONT><br><br>";

	?>
	<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><? echo stripslashes($q); ?></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <? if($ans[0] != ""){ ?>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><? echo stripslashes($ans[0]); ?></td>
  </tr>
  <?}
	if($ans[1] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><? echo stripslashes($ans[1]); ?></td>
  </tr>
    <?}
	if($ans[2] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><? echo stripslashes($ans[2]); ?></td>
  </tr>
    <?}
	if($ans[3] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><? echo stripslashes($ans[3]); ?></td>
  </tr>
    <?}
	if($ans[4] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><? echo stripslashes($ans[4]); ?></td>
  </tr>
    <?}
	if($ans[5] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><? echo stripslashes($ans[5]); ?></td>
  </tr>
    <?}
	if($ans[6] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><? echo stripslashes($ans[6]); ?></td>
  </tr>
    <?}
	if($ans[7] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><? echo stripslashes($ans[7]); ?></td>
  </tr>
    <?}
	if($ans[8] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><? echo stripslashes($ans[8]); ?></td>
  </tr>
    <?}
	if($ans[9] != ""){?>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><? echo stripslashes($ans[9]); ?></td>
  </tr>
  <?}?>
</table>
<?

}


function newPollForm($errors){
	echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Create a New Poll</B></FONT><br><br>";
	echo "<font color=\"red\">$errors</font>";
?>
<form method="post" action="?action=new">
<table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tr>
    <td width="1%" nowrap>Question</td>
    <td width="99%"><input type="text" name="question" size="36"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 1</td>
    <td width="99%"><input type="text" name="answer[0]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 2</td>
    <td width="99%"><input type="text" name="answer[1]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 3</td>
    <td width="99%"><input type="text" name="answer[2]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 4</td>
    <td width="99%"><input type="text" name="answer[3]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 5</td>
    <td width="99%"><input type="text" name="answer[4]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 6</td>
    <td width="99%"><input type="text" name="answer[5]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 7</td>
    <td width="99%"><input type="text" name="answer[6]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 8</td>
    <td width="99%"><input type="text" name="answer[7]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 9</td>
    <td width="99%"><input type="text" name="answer[8]" size="36"></td>
  </tr>
  <tr>
    <td width="1%" nowrap>Answer 10</td>
    <td width="99%"><input type="text" name="answer[9]" size="36"></td>
  </tr>
  <tr>
    <td width="100%" nowrap colspan="2" height="25"></td>
  </tr>
  <tr>
    <td width="1%" nowrap></td>
    <td width="99%"><input type="submit" value="Create New Poll" name="submitNewPoll"></td>
  </tr>
</table>
</form>
<?
}
?>