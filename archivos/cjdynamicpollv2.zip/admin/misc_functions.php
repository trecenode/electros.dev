<?
function arrayCleanBlanks($ansrray){ // I had to write this myself, there is no goddamn php function that does it!
	$no_blanks = array ();	// create array
	foreach($ansrray as $value)	// loop around given array
		if(strlen($value)>0)	// make sure values are more than 0 in length
			$no_blanks[] = $value; // if they are more than 0, add them to the new array
	
	return $no_blanks;	 // return the new array in place of the old array
}

function logout(){
  session_destroy();
?>
			   <font size="3"><b>Logged out successfully</b></font>
				<br>
				<br>
				<li><A HREF="admin_index.php">Log In</A>
				<li><a href="javascript:self.close()">Close Window</a>   
<? 
}
function about(){
		echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>About CJ Dynamic Poll V2.0</B></FONT><br><br>";
		echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\">";
		echo "<tr>";
		echo "<td> ";
?>

				The CJ Dynamic Poll V2.0 was created by CJ Website Design.  The script is released under the GPL License.<br>
				The author of the script is <A HREF="mailto:webmaster@cj-design.com">James Crooke</A><br><br>
				Support CJ Website Design by visiting <A HREF="http://www.cj-design.com/?id=donate">this link</A>.<br><br>
				<b>Enjoy the CJ Dynamic Poll V2.0!</b>
   
<? 
		echo "</td>";
		echo "</tr>";
		echo "</table>";
}
?>