<?
if (!isset($_SESSION['username']) && !isset($_SESSION['password'])){
	header("Location: admin_index.php");
	exit;
}
if (isset($_SESSION['username']) && isset($_SESSION['password'])){
	include("../poll_config.php");
	include("poll_functions.php");
	include("misc_functions.php");	
	if($_GET['action'] == "new"){
		if(isset($_POST['submitNewPoll'])){
			$question = $_POST['question'];
			$answer = $_POST['answer'];
			$answer = arrayCleanBlanks($answer);
			$send = true;				
			if(!isset($question) || $question == ""){
				$emsg = "<li>Enter a Question!</li>";
				$send = false;
			}
			$answerFlag = false;
			for($i=0;$i<count($answer);$i++){
				if($answer[$i] != ""){
					$answerFlag = true;
					break;
				}
			}
			if(!$answerFlag || !isset($answer)){
				$emsg .= "<li>Enter at least one answer</li>";
				$send = false;
			}
			$emsg .= "<br><br>";
			if($send){			
				createNewPoll($question,$answer);
			}
			else{
				newPollForm($emsg);
			}
		}
		else{
			newPollForm("");
		}
	}
	else if($_GET['action'] == "view"){
		viewPolls();
	}
	else if($_GET['action'] == "view_poll"){
		if(isset($_GET['pollid'])){
			viewSinglePoll($_GET['pollid']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "edit_poll"){
		if(isset($_GET['pollid']) || isset($_POST['pollid'])){
			if(!isset($_POST['editPoll'])){
				editPollForm($_GET['pollid'],"");
			}
			else{
				$question = $_POST['question'];
				$answer = $_POST['answer'];
				$votes = $_POST['votes'];
				$edittotal = $_POST['edittotal'];
				$answer = arrayCleanBlanks($answer);
				$send = true;
				
				if(!isset($question) || $question == ""){
					$emsg = "<li>Enter a Question!</li>";
					$send = false;
				}
				$answerFlag = false;
				for($i=0;$i<count($answer);$i++){
					if($answer[$i] != ""){
						$answerFlag = true;
						break;
					}
				}
				if(!$answerFlag || !isset($answer)){
					$emsg .= "<li>Enter at least one answer</li>";
					$send = false;
				}
				$emsg .= "<br><br>";
				if($send){			
					editPoll($_POST['pollid'],$question,$answer,$votes,$edittotal);
				}
				else{
					editPollForm($_POST['pollid'],$emsg);
				}
			}
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "edit_archive"){
		if((isset($_GET['pollid']) && isset($_GET['ts'])) || (isset($_POST['pollid']) && isset($_POST['ts']))){
			if(!isset($_POST['editPoll'])){
				editArchiveForm($_GET['pollid'],$_GET['ts'],"");
			}
			else{
				$question = $_POST['question'];
				$answer = $_POST['answer'];
				$votes = $_POST['votes'];
				$edittotal = $_POST['edittotal'];
				$answer = arrayCleanBlanks($answer);
				$send = true;				
				if(!isset($question) || $question == ""){
					$emsg = "<li>Enter a Question!</li>";
					$send = false;
				}
				$answerFlag = false;
				for($i=0;$i<count($answer);$i++){
					if($answer[$i] != ""){
						$answerFlag = true;
						break;
					}
				}
				if(!$answerFlag || !isset($answer)){
					$emsg .= "<li>Enter at least one answer</li>";
					$send = false;
				}
				$emsg .= "<br><br>";
				if($send){			
					editArchive($_POST['pollid'],$_POST['ts'],$question,$answer,$votes,$edittotal);
				}
				else{
					editArchiveForm($_POST['pollid'],$_POST['ts'], $emsg);
				}
			}
		}
		else{
			echo "No Poll ID Specified";
		}
	
	}
	else if($_GET['action'] == "reset_poll"){
		if(isset($_GET['pollid'])){
			resetPollVotes($_GET['pollid']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "reset_poll_ip"){
		if(isset($_GET['pollid'])){
			resetPollIPs($_GET['pollid']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "archive_poll"){
		if(isset($_GET['pollid'])){
			archivePoll($_GET['pollid']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "delete_poll"){
		if(isset($_GET['pollid'])){
			deletePoll($_GET['pollid']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "delete_archive"){
		if(isset($_GET['pollid']) && isset($_GET['ts'])){
			deleteArchive($_GET['pollid'],$_GET['ts']);
		}
		else{
			echo "No Poll ID Specified";
		}
	}
	else if($_GET['action'] == "delete_archives"){
		if(isset($_POST['sure'])){
			deleteArchives();
		}
		else{
			deleteArchivesConfirm();
		}
	}
	else if($_GET['action'] == "view_archive"){
		viewArchives();
	}
	else if($_GET['action'] == "upgrade"){
		echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Upgrade</B></FONT><br><br>";
		echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\">";
		echo "<tr>";
		echo "<td> ";
		echo "This poll script does come with a handfull of features, more than most polls.  We have developed an even better version of this ";
		echo "script called the 'CJ Dynamic Poll V2.0 Pro'.  The 'Pro' version comes with the following added features:<br><br>";
		echo "<ul>";
		echo "<li><B>Poll Inclusion</B></li>";
		echo "<ul><li>- Poll inclusion will allow you to 'hold' polls without closing them.  If you select to include a poll, it will show up in your webpage, if you choose not to include the poll, it will not be available to users to vote on.  This is a good feature if you have an idea for a poll but are not ready to make it public.</li></ul>";
		echo "<li><B>Automatic Archive</B></li>";
		echo "<ul><li>- Ever wanted your poll to end at exactly 1000 votes?  This feature will let you do just that.  It will even let you specify a time to end the poll, for example, if you wanted your poll to end on the first of the next month, you would simply select the date from a calendar and the poll will end on that date!.</li></ul>";
		echo "<li><B>Poll Comments</B></li>";
		echo "<ul><li>- Sometimes you may feel that a poll you are running deserves a 'Click here to add a comment' feature.  This feature would give voters the oppertunity to justify their vote, for example, if the poll was a simple 'Yes' or 'No' answer, the voter could then be asked to add a comment.  This option can be turned off or on in the configuration file.</li></ul>";
		echo "<li><B>Installation and Customisation</B></li>";
		echo "<ul><li>- If you upgrade to 'Pro' we will install it and customise it for you.  We will make sure that the poll fits in with your web site design and that you are happy with the configurations.</li></ul>";
		echo "</ul>";
		echo "<br><br>";
		echo "To see a working demo of the 'Pro' version, click the link below:<br>";
		echo "<A HREF=\"http://www.cj-design.com/downloads/dynamicpoll_v2Pro/demo\">Demo of CJ Dynamic Poll V2.0 Pro</A><br><br>";
		echo "To upgrade to the 'Pro' version costs only �5 (GBP).  For general information or payment details, email:<br>";
		echo "<A HREF=\"mailto:webmaster@cj-design.com?Subject=Dynamic Poll V2 Upgrade\">webmaster@cj-design.com</A>";
		echo "</td>";
		echo "</tr>";
		echo "</table>";
	}
	else if($_GET['action'] == "logout"){
		logout();
	}
	else if($_GET['action'] == "about"){
		about();
	}
	else if($_GET['action'] == "support"){
		echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Upgrade</B></FONT><br><br>";
		echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\">";
		echo "<tr>";
		echo "<td> ";
		print "The support we give on the CJ Dynamic Poll V2.0 can only be offered on our forums.  We try to check them as much as possible but we cannot guarantee a response right away.  If you upgrade to the <A HREF=\"?action=upgrade\">'Pro' version</A>, support will be available next day.  The link below will take you to the forums:<br><br><A HREF=\"http://www.cj-design.com/forum\">CJ Website Design Forums</A>";
		echo "</td>";
		echo "</tr>";
		echo "</table>";
	}
	else{
		echo "<FONT SIZE=\"3\" COLOR=\"#216767\"><B>Welcome ".$admin_name."</B></FONT><br><br>";
		echo "<IMG SRC=\"welcome.gif\" WIDTH=\"400\" HEIGHT=\"250\" BORDER=\"0\" ALT=\"Welcome!\">";
	}

}
?>
