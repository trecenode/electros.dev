<SCRIPT language="JavaScript">
function loadPopupPollArchive() {
popups=window.open("<? echo $your_url; ?>/archive.php","","width=500,height=300,scrollbars")
}
</script>

