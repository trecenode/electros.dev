<?
//Configuracion
$mensaje_de_bienvenida = "Bienvenidos al libro de recursosphp."; // Mensaje por defecto
$titulo_de_la_pagina_web = "Libro de visitas de http://www.phpmysql.tk";
$direccion_de_la_pagina = "http://www.phpmysql.tk";
$usuario = "recursosphp";
$caretos_en_mensajes = "si";
$transformar_urls_en_enlaces = "no"; // No es compatible con mostrar imagenes de $otras_funciones
$censurar_insultos = "si"; // Espercificar los insultos a censurar de una lista
$otras_funciones = "si"; // [img]http://www.elcidop.com/bannercidop.gif[/img] , [url]http://www.elcidop.com/[/url] , [color=red]Texto[/color]
?>
<style>
/* Cuerpo */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 9pt ;
}
</style>
<title><?=$titulo_de_la_pagina_web?></title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
<br>
<table width="100%" border="0" cellspacing="1" cellpadding="2" style="border: #757575 1 solid">
  <tr> 
    <td background="fondo_titulo.gif" bgcolor="#999999"><div align="center"><strong><font size="2">Libro 
        de visitas de 
        <?=$usuario?>
        </font> </strong></div></td>
  </tr>
  <tr>
    <td bgcolor="#dddddd"> <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td>
            <?=$mensaje_de_bienvenida?>
            <br> <br> <input name="firmar" type="reset" class="form" onclick="MM_goToURL('parent','firmar.php');return document.MM_returnValue"  value="Firmar libro"> 
            <input name="Reset" type="reset" class="form" onClick="MM_goToURL('parent','<?=$direccion_de_la_pagina?>');return document.MM_returnValue" value="Volver"></td>
        </tr>
      </table></td>
  </tr>
</table>
<br>
<br>
  <?
// Script echo por elcidop / www.elcidop.com /
// Fichero
$nombre_archivo = "libro.txt";
// Damos chmod 666 al archivo
if(substr(base_convert(fileperms($nombre_archivo),10,8),3) < 666) {
echo "
<style>
.error { font-size: 7pt }
</style>
<div class=\"error\">
<p><b>Error</b>
<br>El archivo <b>$nombre_archivo</b> debe tener el permiso CHMOD 666.
<br>Se intentar� poner el permiso de forma autom�tica ...
" ;
if(!@chmod($nombre_archivo,0666)) { echo "<p>No se pudo modificar el archivo. Debes hacerlo a trav�s de tu programa de FTP favorito." ; }
else { echo "<p>El archivo <b>minichat.txt</b> ha sido modificado. Para finalizar haz click <a href=\"minichat.php\">aqu�</a>." ; }
echo "</div><br>" ;
}
// Funciones
function abrirf($filename)		//funcion para leer un archivo a una variable
{								//recimos como parametro el nombre del fichero
$fd = @fopen ($filename, "a+");	//abrimos el archivo y oasamos el apuntador a $fd
$archivo = @fread ($fd, filesize ($filename));//leemos el archivo apuntado por $fd y pasamos -> $archivo
@fclose ($fd);					//cerramos el apuntador del archivo
return $archivo;				//devolvemos contenido del archivo
}

function guardarf($filename,$valor)//funcion para guardar el contenido de una variable a un archivo
{								//recibimos nombre del archivo en q se guarda la variable $valor
$fe = @fopen ($filename, "w+");	//abrimos el archivo para escritura
@fputs ($fe,$valor);				//escribimos en el fichero apuntado por $fe
@fclose ($fe);					//cerramos el apuntador 
}
// Abrimos el archivo
$archivo = abrirf ($nombre_archivo);
//////////////////
$cacho_lectura = explode("/n",$archivo);
$num_mensajes = count($cacho_lectura);
if($num_mensajes == -1) {
$numero_total = 0; 
}
else { 
$numero_total = ($num_mensajes)-1; 
}
///////////////// 
$tupla = split( '/n', $archivo, $numero_total + 1 );


for ($i=$num_mensajes;$i>=0;$i--) 
{
if ($cacho_lectura[$i] != "") 
{
		
$borrado = trim($tupla[$i]);
$columna = split( "\|" , $tupla[$i] , 6 );
// Espacios en los comentarios 
/*$columna[4] = str_replace("\r\n","<br>",$columna[4]) ;*/
// Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$columna[5]) ; $diames = date(j,$columna[5]) ; $mesano = date(n,$columna[5]) - 1 ; $ano = date(Y,$columna[5]) ;
$hora = date ("h:i:s", $columna[5]);
$columna[5] = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano a las $hora" ;
// Funci�n para poner caretos en los mensajes
if($caretos_en_mensajes == "si") {
$columna[4] = str_replace("[[","",$columna[4]) ;
$columna[4] = str_replace("]]","",$columna[4]) ;
$columna[4] = str_replace(":D","[[alegre.gif]]",$columna[4]) ;
$columna[4] = str_replace(":8","[[asustado.gif]]",$columna[4]) ;
$columna[4] = str_replace(":P","[[burla.gif]]",$columna[4]) ;
$columna[4] = str_replace(":S","[[confundido.gif]]",$columna[4]) ;
$columna[4] = str_replace(":(1","[[demonio.gif]]",$columna[4]) ;
$columna[4] = str_replace(":(2","[[demonio2.gif]]",$columna[4]) ;
$columna[4] = str_replace(":?","[[duda.gif]]",$columna[4]) ;
$columna[4] = str_replace(":-(","[[enojado.gif]]",$columna[4]) ;
$columna[4] = str_replace(";)","[[guino.gif]]",$columna[4]) ;
$columna[4] = str_replace(":'(","[[llorar.gif]]",$columna[4]) ;
$columna[4] = str_replace(":lol","[[lol.gif]]",$columna[4]) ;
$columna[4] = str_replace(":M","[[moda.gif]]",$columna[4]) ;
$columna[4] = str_replace(":|","[[neutral.gif]]",$columna[4]) ;
$columna[4] = str_replace(":)","[[risa.gif]]",$columna[4]) ;
$columna[4] = str_replace(":-)","[[sonrisa.gif]]",$columna[4]) ;
$columna[4] = str_replace(":R","[[sonrojado.gif]]",$columna[4]) ;
$columna[4] = str_replace(":O","[[sorprendido.gif]]",$columna[4]) ;
$columna[4] = str_replace(":(","[[triste.gif]]",$columna[4]) ;
$columna[4] = str_replace("[[","<img src=\"caretos/",$columna[4]) ;
$columna[4] = str_replace("]]","\" width=\"15\" height=\"15\">",$columna[4]) ;
}
// Funci�n para transformar URLs en enlaces
if($transformar_urls_en_enlaces == "si") {
$columna[4] = preg_replace("/(?<!')(?<!<a href=\")(?<!<img src=\")(http|ftp)(s)?:\/\/[^,<\'\"\s]+/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$columna[4]) ;
}
// Funci�n para palabras censuradas
if($censurar_insultos == "si") {
$columna[4] = str_replace("capullo","***",$columna[4]) ;
$columna[4] = str_replace("gay","***",$columna[4]) ;
$columna[4] = str_replace("puta","***",$columna[4]) ;
$columna[4] = str_replace("maricon","***",$columna[4]) ;
$columna[4] = str_replace("pendejo","***",$columna[4]) ;
}
// Otras funciones
if($otras_funciones == "si") {
$columna[4] = str_replace("[b]","<b>",$columna[4]) ; $columna[4] = str_replace("[/b]","</b>",$columna[4]) ;
$columna[4] = str_replace("[img]","<img src=\"",$columna[4]) ; $columna[4] = str_replace("[/img]","\" border=\"0\" onerror=this.onerror='null';this.src='fondo_titulo.gif'>",$columna[4]) ;
$columna[4] = preg_replace("/\[color=((#)?[0-9a-z]+)\]/i","<font color=\"\\1\">",$columna[4]) ; $columna[4] = str_replace("[/color]","</font>",$columna[4]) ;
$columna[4] = preg_replace("/\[url\](www\..+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\1</a>",$columna[4]) ;
$columna[4] = preg_replace("/\[url\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>",$columna[4]) ;
$columna[4] = preg_replace("/\[url=(www\..+)\](.+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\2</a>",$columna[4]) ;
$columna[4] = preg_replace("/\[url=(.+)\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\2</a>",$columna[4]) ;
}
?>
<table width="100%" border="0" cellspacing="1" cellpadding="4" style="border: #757575 1 solid">
  <tr> 
    <td height="27" background="fondo_titulo.gif" bgcolor="#999999"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="19"><strong><img src="usuario.gif" width="16" height="16" border="0"> 
            <? echo $columna[0] ?> 
            <? if($columna[1]){?>
            <a href='mailto:<? echo $columna[1] ?>' target='_blank'><img src="email.gif" width="16" height="16" border="0"></a> 
            <? } ?>
            <? if($columna[3]){?>
            <a href='<? echo $columna[3] ?>' target='_blank'><img src="paginaweb.gif" width="18" height="18" border="0"></a> 
            <? } ?>
            </strong></td>
          <td><div align="right"><strong> 
              <? if($columna[2]){?>
              <img src="lugar.gif" width="16" height="16"> </strong><? echo $columna[2] ?><strong>
              <? } ?>
              </strong> <img src="reloj.gif" width="16" height="16"> <? echo $columna[5] ?></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="26" valign="top" bgcolor="#dddddd"><table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td><? echo $columna[4] ?></td>
        </tr>
      </table></td>
  </tr>
</table><br>
<?
}
// Fin formulario para poder enviar un enlace
}
?>
<br>
<br>
<div align="center"><a href="http://recursosphp.iefactory.com/librodevisitas/librodevisitas.zip">librodevisitas</a> by elcidop</div>
