<style>
/* Cuerpo */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* libro */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
<title>Firmar libro de visitas</title>
<table width="100%" border="0" cellspacing="1" cellpadding="2" style="border: #757575 1 solid">
  <tr> 
    <td background="fondo_titulo.gif" bgcolor="#999999"><div align="center"><strong><font size="2">Insertar 
        nueva firma</font> </strong></div></td>
  </tr>
  <tr> 
    <td height="332" bgcolor="#dddddd"> <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td height="337"><form action='<? $_SERVER["REQUEST_URI"] ?>' method="post" >
              <table width="44%" border="0" align="center" >
                <tr> </tr>
                <tr> 
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="37%"><div align="left">Nombre :</div></td>
                  <td width="63%" colspan="2"><input name="nombre" class="form" id="nombre3" size=40 maxlength=200></td>
                </tr>
                <tr> 
                  <td><div align="left">Email:</div></td>
                  <td colspan="2"> <input name="email" class="form" size=40 maxlength="200"></td>
                </tr>
                <tr> 
                  <td><div align="left">Lugar:</div></td>
                  <td colspan="2"> <input name="lugar" class="form" size=40 maxlength="200"></td>
                </tr>
                <tr> 
                  <td><div align="left">Pagina web :</div></td>
                  <td colspan="2"> <input name="paginaweb" class="form" size=40 maxlength="200"></td>
                </tr>
                <tr> 
                  <td valign="top"><div align="left"> Comentarios :<br>
                      <br>
                      <table width="100%" border="0" cellpadding="2" cellspacing="0">
                        <tr> 
                          <td height="53"><strong>[img]imagen.gif[/img]</strong><br>
                            <strong>[url]http://www.web.com[/url]</strong><br>
                            <strong>[color=red]Texto[/color]</strong></td>
                        </tr>
                      </table>
                      <table width="100%" border="0" cellspacing="1" cellpadding="1">
                        <tr> 
                          <td width="32%" height="19"><img src="caretos/alegre.gif" width="15" height="15"> 
                            :D </td>
                          <td width="32%"><img src="caretos/demonio.gif" width="15" height="15"> 
                            :(1 </td>
                          <td width="36%"><img src="caretos/guino.gif" width="15" height="15"> 
                            ;)</td>
                        </tr>
                        <tr> 
                          <td><img src="caretos/asustado.gif" width="15" height="15"> 
                            :8 </td>
                          <td><img src="caretos/demonio2.gif" width="15" height="15"> 
                            :(2 </td>
                          <td><img src="caretos/llorar.gif" width="15" height="15"> 
                            :'( </td>
                        </tr>
                        <tr> 
                          <td><img src="caretos/burla.gif" width="15" height="15"> 
                            :P </td>
                          <td><img src="caretos/duda.gif" width="15" height="15"> 
                            :? </td>
                          <td><img src="caretos/lol.gif" width="15" height="15"> 
                            :lol </td>
                        </tr>
                        <tr> 
                          <td><img src="caretos/confundido.gif" width="15" height="15"> 
                            :S </td>
                          <td><img src="caretos/enojado.gif" width="15" height="15"> 
                            :-( </td>
                          <td><img src="caretos/moda.gif" width="15" height="15"> 
                            :M </td>
                        </tr>
                        <tr> 
                          <td><img src="caretos/sorprendido.gif" width="15" height="15"> 
                            :O </td>
                          <td><img src="caretos/triste.gif" width="15" height="15"> 
                            :( </td>
                          <td><img src="caretos/risa.gif" width="15" height="15"> 
                            :) </td>
                        </tr>
                        <tr> 
                          <td><img src="caretos/neutral.gif" width="15" height="15"> 
                            :| </td>
                          <td><img src="caretos/sonrisa.gif" width="15" height="15"> 
                            :-) </td>
                          <td><img src="caretos/sonrojado.gif" width="15" height="15"> 
                            :R </td>
                        </tr>
                      </table>
                    </div></td>
                  <td colspan="2" valign="top"> <textarea name="comentarios" cols="38" rows="10" class="form" id="comentarios"></textarea></td>
                </tr>
                <tr> 
                  <td colspan="3"><div align="center"><br>
                      <input name="firmar" type="submit" class="form"  value="Firmar">
                      <input name="Reset" type="reset" class="form" value="Deshacer">
                    </div></td>
                </tr>
              </table>
              <p>&nbsp;</p>
</form></td>
        </tr>
      </table></td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="1" cellpadding="2" style="border: #757575 1 solid">
  <tr> 
    <td height="16" bgcolor="#dddddd"><table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td><a href="libro.php">Volver al libro de visitas</a></td>
          <td><div align="right"></div></td>
        </tr>
      </table> </td>
  </tr>
</table>
<br>
<br>
<?php
/*
Script modificado por elcidop o phpmysql
www.elcidop.com
www.phpmysql.tk
*/
//Configuracion
$nombre_archivo = "libro.txt";
$contrasena = "12345";
// Funciones
function abrirf($filename)		//funcion para leer un archivo a una variable
{								//recimos como parametro el nombre del fichero
$fd = @fopen ($filename, "a+");	//abrimos el archivo y oasamos el apuntador a $fd
$archivo = @fread ($fd, filesize ($filename));//leemos el archivo apuntado por $fd y pasamos -> $archivo
@fclose ($fd);					//cerramos el apuntador del archivo
return $archivo;				//devolvemos contenido del archivo
}

function guardarf($filename,$valor)//funcion para guardar el contenido de una variable a un archivo
{								//recibimos nombre del archivo en q se guarda la variable $valor
$fe = @fopen ($filename, "w+");	//abrimos el archivo para escritura
@fputs ($fe,$valor);				//escribimos en el fichero apuntado por $fe
@fclose ($fe);					//cerramos el apuntador 
}
// Borramos el archivo
if($borrar && $_POST["contrasena_nombre"] == $contrasena)
{
	$filename = $nombre_archivo;
	$archivo = abrirf ($filename);
	$limite = substr_count($archivo, '/n');
	for ($i = 0 ; $i < $limite ; $i++)	//recorremos todos los registros del archivo
	{
	$aux = "tupla".$i;					//para recuperar el valor que envio desde indexuser.php creo la 
	$busco = $$aux."/n";				//variable aux que sera = a "tupla0".... y la declaro variable con
										//$$aux se agrego "/n" para completar la cadena a borrar 
		if($busco != "/n")				//si se envio la variable $busco dera != de "/n"
			$archivo = str_replace ("$busco","", "$archivo");//borramos el registro 
	}
	guardarf ($filename,$archivo);
	echo "<script>location.href='$_SERVER[REQUEST_URI]'</script>";
}
// Agregamos libro
if ($firmar)
{
	if($nombre && $comentarios)
	{
	    $nombre = htmlspecialchars(trim($_POST["nombre"]));
		$email = htmlspecialchars(trim($_POST["email"]));
		$lugar = htmlspecialchars(trim($_POST["lugar"]));
		$paginaweb = htmlspecialchars(trim($_POST["paginaweb"]));
		$comentarios = htmlspecialchars(trim($_POST["comentarios"]));
		// Sutituimos los espacios por <br>
		$comentarios = str_replace("\r\n","<br>",$comentarios) ;
		// Fin sustituir los espacios por <br>
		
		$filename = $nombre_archivo;
		$archivo = abrirf ($filename);
		$fecha = time();
		$archivo = $archivo.trim(" $nombre|$email|$lugar|$paginaweb|$comentarios|$fecha/n");
		guardarf ($filename,$archivo);
		echo "<script>location.href='$_SERVER[REQUEST_URI]'</script>";
	}
	else
		echo "<b>Advertencia</b>:<br>No ha ingresado todos los datos en el formulario<br><br>";
}
// Furmulario para poder borrar un nombre
?>
<table width='100%' border='0' cellspacing='1' cellpadding='4' style="border: #757575 1 solid">
  <tr> 
    <td width="17%" background="fondo_titulo.gif" bgcolor="#999999"><b>Nombre</b></td>
    <td width="18%" background="fondo_titulo.gif" bgcolor="#999999"><b>Email</b></td>
    <td width="18%" background="fondo_titulo.gif" bgcolor="#999999"><b>Lugar</b></td>
    <td width="23%" background="fondo_titulo.gif" bgcolor="#999999"><b>Pagina Web</b></td>
    <td width="18%" background="fondo_titulo.gif" bgcolor="#999999"><b>Comentario</b></td>
    <td width="2%" background="fondo_titulo.gif" bgcolor="#999999">&nbsp;</td>
  </tr>
  <?
echo "<form method='post' action='$_SERVER[REQUEST_URI]'>";
// Abrimos el archivo
$archivo = abrirf ($nombre_archivo);
$limite = substr_count($archivo, '/n' ); 
$tupla = split( '/n', $archivo, $limite + 1 );
for($i=0 ; $i < $limite ; ++$i)
{
	$borrado = trim($tupla[$i]);
	$columna = split( "\|" , $tupla[$i] , 6 );
	// Reduccimos los comentarios
	
if (strlen($columna[4]) > 20) { 
$columna[4] = substr($columna[4],0,20)."..."; 
}
?>
  <tr> 
    <td bgcolor="#dddddd"><? echo $columna[0] ?></td>
    <td bgcolor="#dddddd"><? echo $columna[1] ?></td>
    <td bgcolor="#dddddd"><? echo $columna[2] ?></td>
    <td bgcolor="#dddddd"><? echo $columna[3] ?></td>
    <td bgcolor="#dddddd"><? echo $columna[4] ?></td>
    <td bgcolor="#dddddd"><input type='checkbox' name='<? echo "tupla".$i ?>' value='<? echo $borrado ?>'></td>
  </tr>
  <?
}
// Fin formulario para poder enviar un nombre
?>
</table>
<br>
<div align=right>Contrase�a : <input name='contrasena_nombre' type='text' class='form' size='12'> 
<input name='borrar' type='submit' class='form'  value='Borrar'></div><br>
<?
echo "</form>";
?><br>
<div align="center"><a href="http://recursosphp.iefactory.com/librodevisitas/librodevisitas.zip"><br>
  librodevisitas</a> by elcidop</div>
