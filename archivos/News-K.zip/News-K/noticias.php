<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
define('bbcode', true);
include("config.php");
if(isset($userA) AND ($passA)) {
if($usuarios[$userA]==$passA) {
if(isset($aniadir)) {
if($titulo == "" OR $contenido == "") {
echo "Debes rellenar todos los campos<br><a href=javascript:history.back(1)>Volver</a>";
} else {
$sql = "INSERT INTO `".$tabla."` (`titulo`, `email`, `fecha`, `contenido`, `nombre`) VALUES ('$titulo', '$email', '$fecha', '$contenido', '$nombre')";
$result = mysql_query($sql);
echo "Noticia A�adida<br><a href=index.php>Volver al Index</a>";
}
} else {
$FECHA = date("d.m.Y");
?>
<div align="center">
	<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000000" bordercolordark="#000000" height="313" class="Tabla">
	<form name="form" method="post" action="noticias.php">
<input type="hidden" name="userA" value="<?= $userA ?>">
<input type="hidden" name="passA" value="<?= $passA ?>">
<input type="hidden" name="aniadir">
		<tr>
			<td width="73" height="25">
			<p align="right"><b>Titulo:</b></td>
			<td height="25">&nbsp;<input type="text" name="titulo" size="20"></td>
		</tr>
		<tr>
			<td width="73" height="25">
			<p align="right"><b>Nick:</b></td>
			<td height="25">&nbsp;<input type="text" name="nombre" size="20" value="<? echo $nick; ?>"></td>
		</tr>
		<tr>
			<td width="73" height="25">
			<p align="right"><b>Fecha:</b></td>
			<td height="25">&nbsp;<input type="text" name="fecha" size="20" value="<? echo $FECHA; ?>"></td>
		</tr>
		<tr>
			<td width="73" height="25">
			<p align="right"><b>Email:</b></td>
			<td height="25">&nbsp;<input type="text" name="email" size="20" value="<? echo $mail; ?>"></td>
		</tr>
		<tr>
			<td width="73" height="30">
			<p align="right"><b>BBCode:</b></td>
			<td height="30"><? include("bbcode.php"); ?><br></td>
		</tr>
		<tr>
			<td width="73" height="144">
			<p align="right"><b>Contenido:</b></td>
			<td height="144">&nbsp;<textarea rows="8" name="contenido" cols="42"></textarea></td>
		</tr>
		<tr>
			<td></td><td><input type="Submit" name="anidir" value="A�adir"></td>
		</tr>
</form></table>
</div>
<?
}
} else {
include("admin.php");
}
} else {
include("admin.php");
}
?>