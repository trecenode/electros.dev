<?
if (defined('bbcode')) {
?>
	 <script>
	 function Smile(texto){
	 document.form.contenido.value = document.form.contenido.value + texto;
 	 }
     function put_bbcode(campo,bbcode)
     {
       eval("document.form."+campo+".value += '["+bbcode+"][/"+bbcode+"] '");
       eval("document.form."+campo+".focus()");
     }

     function negrita(campo)
     {
       var bbcode='b';
       put_bbcode(campo,bbcode);  
     }
        function cursiva(campo)
     {
       var bbcode='i';
       put_bbcode(campo,bbcode);    
     }

     function subrayado(campo)
     {
       var bbcode='u';
       put_bbcode(campo,bbcode);   
     }
     
     function quote(campo)
     {
       var bbcode='quote';
       put_bbcode(campo,bbcode);   
     }
     
          function izquierda(campo)
     {
       var bbcode='left';
       put_bbcode(campo,bbcode);   
     }     
          function centro(campo)
     {
       var bbcode='center';
       put_bbcode(campo,bbcode);   
     }     
          function derecha(campo)
     {
       var bbcode='right';
       put_bbcode(campo,bbcode);   
     }
	  
	  function codigo(campo,tipo)
     {
      var bbcode='';
      
      switch(tipo){
        case "PHP": bbcode='php'; break;
      };

      if(bbcode!='') 
          put_bbcode(campo,bbcode);
     }

     function imagen(campo)
     {
       eval("actual=document.form."+campo+".value");

       var imagen2 = prompt("Introduzca la URL de la imagen: ", "http://");

       if((imagen2==null)||(imagen2=="")) return;
       if(imagen2=="http://") return;
       var url_imagen = "[img]"+imagen2+"[/img] ";
       mensaje = actual+url_imagen;
       
       eval("document.form."+campo+".value=mensaje");
       eval("document.form."+campo+".focus()");
     }

     function url(campo)
     {
       eval("mensaje_actual=document.form."+campo+".value");

       var url = prompt("Introduzca la URL de la web: ", "http://");

       if((url==null)||(url=="")) return;
       if(url=="http://") return;

       var titulo = prompt("Nombre para el enlace:", "Titulo de la pagina");

       if((titulo==null)||(titulo=='')) return;
       if(titulo=="Titulo de la pagina") return;
       else
           var url_codigo = "[url="+url+"]name="+titulo+"[/url] ";

       mensaje = mensaje_actual+url_codigo;
       
       eval("document.form."+campo+".value=mensaje");
       eval("document.form."+campo+".focus()");
     }
     </script>
		&nbsp;<a href="javascript:Smile('(:))')"><img border="0" src="smiles/smile.gif" smiles"></a><a href="javascript:Smile('(:S)')"><img border="0" src="smiles/smile%20(1).gif" smiles"></a><a href="javascript:Smile('(8l)')"><img border="0" src="smiles/smile%20(2).gif" smiles"></a><a href="javascript:Smile('(:l)')"><img border="0" src="smiles/smile%20(3).gif" smiles"></a><a href="javascript:Smile('(:@)')"><img border="0" src="smiles/smile%20(4).gif" smiles"></a><a href="javascript:Smile('(:X)')"><img border="0" src="smiles/smile%20(5).gif" smiles"></a><a href="javascript:Smile('(:D)')"><img border="0" src="smiles/smile%20(6).gif" smiles"></a><a href="javascript:Smile('(:|)')"><img border="0" src="smiles/smile%20(7).gif" smiles"></a><a href="javascript:Smile('(:P)')"><img border="0" src="smiles/smile%20(8).gif" smiles"></a><a href="javascript:Smile('(:$)')"><img border="0" src="smiles/smile%20(9).gif" smiles"></a><a href="javascript:Smile('(8-)')"><img border="0" src="smiles/smile%20(10).gif" smiles"></a><a href="javascript:Smile('(:()')"><img border="0" src="smiles/smile%20(11).gif" smiles"></a><a href="javascript:Smile('(:O)')"><img border="0" src="smiles/smile%20(12).gif" smiles"></a><a href="javascript:Smile('(--)')"><img border="0" src="smiles/smile%20(13).gif" smiles"></a><a href="javascript:Smile('(;D)')"><img border="0" src="smiles/smile%20(14).gif"></a><br>
&nbsp;<a href="javascript:;" title="Negrita. [b]texto[/b]"   onClick="negrita('contenido')"><img border="0" src="images/bold.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Cursiva. [i]texto[/i]"   onClick="cursiva('contenido')"><img border="0" src="images/cursiva.jpg" width="23" height="22"><a/>
<a href="javascript:;" title="Subrayado. [u]texto[/u]"   onClick="subrayado('contenido')"><img border="0" src="images/subrayado.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Codigo PHP. [php]texto[/php]"   onClick="codigo('contenido','PHP')"><img border="0" src="images/php.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Url. [url]texto[/url]"   onClick="url('contenido')"><img border="0" src="images/url.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Imagen. [img]texto[/img]"   onClick="imagen('contenido')"><img border="0" src="images/img.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Izquierda. [left]texto[/left]"   onClick="izquierda('contenido')"><img border="0" src="images/izquierda.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Centro. [center]texto[/center]"   onClick="centro('contenido')"><img border="0" src="images/medio.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Derecha. [right]texto[/right]"   onClick="derecha('contenido')"><img border="0" src="images/derecha.jpg" width="23" height="22"></a>
<a href="javascript:;" title="Cita. [quote]texto[/quote]"   onClick="quote('contenido')"><img border="0" src="images/citar.jpg" width="23" height="22"></a>
<?
} else {
echo "&nbsp;<b>No Hagas trampas!</b>";
}
?>