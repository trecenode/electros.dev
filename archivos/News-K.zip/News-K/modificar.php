<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
define('bbcode', true);
include("config.php");
if(isset($userA) AND ($passA)) {
if($usuarios[$userA]==$passA) {
if(isset($modificar)) {
$sql = "UPDATE ".$tabla." SET titulo='$titulo', email='$email', fecha='$fecha', contenido='$contenido', nombre='$nombre' WHERE id='$ID'";
$result = mysql_query($sql);
echo "Noticia Actualizada<br><a href=index.php>Volver al Index</a>";
} else {
if(!isset($ID)) {
?>
<center><b><font size="4">Modificar Noticias:</font></b></center><br>
<div align="center">
	<table border="1" cellpadding="0" style="border-collapse: collapse" width="98%" bordercolorlight="#000000" bordercolordark="#000000" class="Tabla">
		<tr>
			<td width="621">
			<p align="center"><b>Titulo</b></td>
			<td width="15%">
			<p align="center"><b>Modificar</b></td>
		</tr>
		<?
$result = mysql_query("SELECT id, titulo FROM ".$tabla." ORDER by id DESC", $link);
while ($myrow = mysql_fetch_array($result)) {
echo "<tr><td width=69><p align=center>".$myrow["titulo"]."</td><td><center><a href=?id=modificar&userA=".$userA."&passA=".$passA."&ID=".$myrow["id"].">[Modificar]</a></center></td></tr>";
}
?>
</table>
</div>
<?
} else {
$sql = "SELECT * FROM ".$tabla." WHERE id=".$ID;
$result = mysql_query($sql,$link);
$myrow = mysql_fetch_array($result);
$titulO = $myrow["titulo"];
$fechA = $myrow["fecha"];
$emaiL = $myrow["email"];
$contenidO = $myrow["contenido"];
$nombrE = $myrow["nombre"];
$FECHA = date("d.m.Y");
?>
<form name="form" method="post" action="modificar.php">
<input type="hidden" name="userA" value="<?= $userA ?>">
<input type="hidden" name="passA" value="<?= $passA ?>">
<input type="hidden" name="ID" value="<?= $ID ?>">
<input type="hidden" name="modificar">
<div align="center">
	<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolorlight="#000000" bordercolordark="#000000" height="306" class="Tabla">
		<tr>
			<td width="71" height="25">
			<p align="right"><b>Titulo:</b></td>
			<td height="25">&nbsp;<input type=text name=titulo size=20 value="<?php echo $titulO ?>"></td>
		</tr>
		<tr>
			<td width="71" height="25">
			<p align="right"><b>Nick:</b></td>
			<td height="25">&nbsp;<input type="text" name="nombre" size="20" value="<?php echo $nombrE ?>"></td>
		</tr>
		<tr>
			<td width="71" height="25">
			<p align="right"><b>Fecha:</b></td>
			<td height="25">&nbsp;<input type="text" name="fecha" size="20" value="<?php echo $FECHA ?>"></td>
		</tr>
		<tr>
			<td width="71" height="25">
			<p align="right"><b>Email:</b></td>
			<td height="25">&nbsp;<input type="text" name="email" size="20" value="<?php echo $emaiL ?>"></td>
		</tr>
		<tr>
			<td width="71" height="30">
			<p align="right"><b>BBCode:</b></td>
			<td height="30"><? include("bbcode.php"); ?></td>
		</tr>
		<tr>
			<td width="71" height="144">
			<p align="right"><b>Contenido:</b></td>
			<td height="144">&nbsp;<textarea rows="8" name="contenido" cols="42"><?php echo $contenidO ?></textarea></td>
		</tr>
		<tr>
			<td></td><td><input type="Submit" name="modificar" value="Modificar"></td>
		</tr>
	</table>
</div>
</form>
<?
}
}
} else {
include("admin.php");
}
} else {
include("admin.php");
}
?>