<?
echo "Hey man! Get out of Here!";
?>