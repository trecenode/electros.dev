<?
//Realizado por Electros
//Modificado por eliascm36
?>
<!-- se refressca, se actualiza en tantos segundos -->
<meta http-equiv="refresh" content="5">
<!-- va a hacia otra pagina en tantos segundos -->
<meta http-equiv="refresh" content="8;URL=enlinea.php">
<?
include("config.php") ;
# * La fecha que ser� usada en el foro (por defecto se usar� la fecha GMT)
# Esta fecha se guardar� en todos los mensajes as� como en todas las funciones del foro,
# despu�s mediante la zona GMT que eligi� el usuario se le sumar� o restar� la diferencia
# de horas a la fecha guardada y con una simple llamada a date() obtendremos esa fecha
$fecha = strtotime(gmdate('d M Y H:i:s')) ;

# * Fecha corta (Formato: 1 Ene 2004 12:00 AM)
function fecha($a) {
	$fecha_actual = $GLOBALS[fecha] - $a ;
	switch (true) {
		case $fecha_actual > 0 && $fecha_actual < 3600 :
			$minutos = round($fecha_actual / 60) ;
			return ($minutos == 0 || $minutos == 1) ? 'Hace 1 minuto' : "Hace $minutos minutos" ;
			break ;
		case $fecha_actual >= 3600 && $fecha_actual < 86400 :
			$horas = round($fecha_actual / 3600) ;
			return ($horas == 1) ? 'Hace 1 hora' : "Hace $horas horas" ;
			break ;
		default :
			$gmt = $a + 3600 * $GLOBALS[usuario][gmt] ;
			$meses = array('','Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic') ;
			return date('j',$gmt).' '.$meses[date('n',$gmt)].' '.date('Y',$gmt).' '.date('h:i A',$gmt) ;
	}
}
# * Obtener datos del usuario que est� conectado en este momento
if($_COOKIE[unick]) {
$con = mysql_query("select id from usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($con) ;
# Id del usuario
$usuario[id] = $datos[id] ;
# * Se obtienen los usuarios en l�nea en el foro
$tiempo_limite = 600 ; # <-- Tiempo en segundos en el cu�l se mantendr� al usuario en l�nea
$fecha_limite = $fecha - $tiempo_limite ;
# --> Se eliminan los usuarios que superaron el tiempo l�mite
mysql_query("delete from eforo_enlinea where fecha<'$fecha_limite'") ;
# --> Si es un usuario registrado se guarda su ID
if($_COOKIE[unick]) {
	$con = mysql_query("select * from eforo_enlinea where id_usuario='$usuario[id]'") ;
	if(mysql_num_rows($con)) {
		mysql_query("update eforo_enlinea set fecha='$fecha' where id_usuario='$usuario[id]'") ;
	}
	else {
		mysql_query("delete from eforo_enlinea where ip='$_SERVER[REMOTE_ADDR]'") ;
		mysql_query("insert into eforo_enlinea (fecha,id_usuario) values ('$fecha','$usuario[id]')") ;
	}
	mysql_free_result($con) ;
	}
# --> Si es un usuario no registrado se guarda su IP
else {
	$con = mysql_query("select * from eforo_enlinea where ip='$_SERVER[REMOTE_ADDR]'") ;
	if(mysql_num_rows($con)) {
		mysql_query("update eforo_enlinea set fecha='$fecha' where ip='$_SERVER[REMOTE_ADDR]'") ;
	}
	else {
		mysql_query("insert into eforo_enlinea (fecha,ip) values ('$fecha','$_SERVER[REMOTE_ADDR]')") ;
	}
	mysql_free_result($con) ;
}
# --> Se obtiene el total de usuarios
# No registrados
$con = mysql_query("select ip from eforo_enlinea where ip!=''") ;
$total_enlinea[0] = mysql_num_rows($con) ;
mysql_free_result($con) ;
# Registrados
$con = mysql_query("select id_usuario from eforo_enlinea where id_usuario!='0' order by fecha asc") ;
$total_enlinea[1] = mysql_num_rows($con) ;
# Total
$total_enlinea[2] = $total_enlinea[0] + $total_enlinea[1] ;
# --> Se obtiene el nick de los usuarios registrados en l�nea
$reg_enlinea = false ;
for($i = 1 ; $datos = mysql_fetch_array($con) ; $i++) {
	$con2 = mysql_query("select nick from usuarios where id='$datos[id_usuario]'") ;
	$datos2 = mysql_fetch_array($con2) ;
	if($i < $total_enlinea[1]) {
		$reg_enlinea .= "$datos2[nick]<br> " ;
	}
	else {
		$reg_enlinea .= "$datos2[nick]" ;
	}
	mysql_free_result($con2) ;
}
mysql_free_result($con) ;
}
?>
<?=$reg_enlinea?>