<?
//************************************
//***********Realizado Por:***********
//************eliascm36***************
//**************Email:****************
//********eliascm36@hotmail.com*******
//**************Version:**************
//****************1.0*****************
//************************************
?>
<table width="358" height="122" border="0">
  <tr>
    <td width="241"><iframe src="texto.php" width="500" height="400" frameborder="1" scrolling="yes"></iframe></td>
    <td width="107"><iframe src="enlinea.php" width="100" height="400" frameborder="1" scrolling="yes"></iframe></td>
  </tr>
</table>
<form name="form1" method="post" action="index.php?id=chat">
  <input name="texto" type="text" id="texto" size="50">
  <input name="enviar" type="submit" id="enviar" value="Enviar">
  <? include('config.php') ?>
  <? if($enviar){
  $limpiar = '/limpiar' ;
  if($texto == $limpiar){
 mysql_query("TRUNCATE chat") ; 
 }
 else
 {
$usuario = $_COOKIE["unick"] ;
mysql_query("insert into chat (texto,usuario,id) values ('$texto','$usuario','1')") ;
}
}
?>
</form>