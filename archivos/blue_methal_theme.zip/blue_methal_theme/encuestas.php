<?
include("eforo_estilo/$estilopagina") ;
?>
<script>
function abrirpopup(nombre,ancho,alto) {
dat = 'width=' + ancho + ',height=' + alto + ',left=50,top=50,scrollbars=auto,resize=no';
window.open(nombre,'',dat)
}
</script>
<?php require_once('enc_config.php'); ?>
<? 
// miramos la pregunta activa i la mostramos los resultados.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
$ID= $row_encuesta_ver["ID"];

// ************** Configurar: ********************
$restring = getenv("HTTP_X_FORWARDED_FOR"); // Aqui podeis poner lo que querais restringir a solo un voto, puede ser una cookie, una ip... lo que querais.
// ***********************************************
//Realizamos el voto si lo ha pedido.
if($_POST['votar']){
$ID_pregunta = $_POST['ID_pregunta'] ;
$voto = $_POST['votar'] ;
// Revisamos que sea su primer voto
mysql_select_db($database_encuesta, $encuesta);
$query_votar = "SELECT * FROM encuesta_votos WHERE Restringido='$restring' AND ID_pregunta='$ID'";
$votar = mysql_query($query_votar, $encuesta) or die(mysql_error());
$totalRows_votar = mysql_num_rows($votar);
if($totalRows_votar==0){
// insertamos el voto
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "insert into encuesta_votos (ID_pregunta,Restringido,Respuesta) values ('$ID_pregunta','$restring','$voto')";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
echo "<script> alert('Gr�cies per donar la teva opini�!'); </script>" ;
}else{ echo "<script> alert('Tu ja has votat!'); </script>" ; }
}
//miramos si ya ha votado
mysql_select_db($database_encuesta, $encuesta);
$query_comprueba = "SELECT * FROM encuesta_votos WHERE Restringido='$restring' AND ID_pregunta='$ID'";
$comprueba = mysql_query($query_comprueba, $encuesta) or die(mysql_error());
$totalRows_comprueba = mysql_num_rows($comprueba);

if($totalRows_comprueba==0){
// ****************Aqui si no ha votado*******************
// miramos la pregunta activa i la mostramos
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
?>
<style type="text/css">
<!--
.Estilo1 {
	font-size: 12px;
	font-weight: bold;
}
.Estilo5 {font-size: 12px}
-->
</style>

<form name="form1" method="post" action="index.php">
  <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
    <!--DWLayoutTable-->
    <tr> 
      <td width="146" height="23" class="tabla_titulo"><div align="right" class="t1"><span class="Estilo1"> 
          <input name="ID_pregunta2" type="hidden" id="ID_pregunta2" value="<? echo $row_encuesta_ver['ID'] ; ?>">
          Encuesta </span></div></td>
    </tr>
    <tr> 
      <td height="77" align="left" valign="top" class="tabla_mensaje"><div align="left"><span class="Estilo5"> 
          </span><span class="Estilo1"><? echo $row_encuesta_ver['Pregunta'] ; ?></span><br>
          <span class="Estilo5"> 
          <? for ($i = 1; $i <= $maximo_valores; $i++) { // Empezamos la repeticion de respuestas ?>
          </span> 
          <div align="left" class="Estilo5"> 
            <input name="votar" type="radio" value="<? echo $i ; ?>">
            <? echo $row_encuesta_ver["Resp".$i.""] ;  ?> <br>
            <? } //cerramos la repeticion ?>
            <br>
            <input name="submit" type="submit" value="votar">
          </div>
        </div></td>
    </tr>
  </table>
  </form>
<?php
}else{
// Si ya ha votado le ense�amos las estadisticas
mysql_select_db($database_encuesta, $encuesta);
$query_votos = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID'";
$votos = mysql_query($query_votos, $encuesta) or die(mysql_error());
$votos_totales = mysql_num_rows($votos);
?>
<table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Encuesta</div></td>
        </tr>
        
  <tr> 
    <td height="1" valign="top" class="tabla_mensaje" align="left"><table width="130"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2"><strong><? echo $row_encuesta_ver['Pregunta'] ; ?></strong></td>
  </tr>
  <? for ($i = 1; $i <= $maximo_valores; $i++) { ?>
  <tr>
    <td width="50"><? echo $row_encuesta_ver["Resp".$i.""] ;  ?>&nbsp;</td>
    <td width="112" valign="middle"><?
	mysql_select_db($database_encuesta, $encuesta);
	$query_voto = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID' AND Respuesta = '$i'";
	$voto = mysql_query($query_voto, $encuesta) or die(mysql_error());
	$votos_resp = mysql_num_rows($voto);
	@$percentatge = @( $votos_resp * 100 )/($votos_totales);
	?>
      <table width="99%" height="99%"  border="0" valign="middle" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="middle" bgcolor="#CCCCCC"><table width="<? echo $percentatge ; ?>%"  border="1" align="left" cellpadding="0" cellspacing="0" bgcolor="#CC9900">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr> <? } ?>
  <tr>
    <td colspan="2"><div align="center"><strong><a href="#" onClick="abrirpopup('encuesta.php',250,500)">Veure completes </a></strong></div></td>
  </tr>
  
</table>
      <div align="left"></div></td>
        </tr>
      </table>
<? } ?>