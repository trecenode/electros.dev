<a href="index.php?id=administrar">&raquo; Administrar</a><br> <a href="index.php?id=alta">&raquo; Enviar encuesta</a><br>
<a href="index.php?id=enlacesenviar">&raquo; Enviar Enlaces</a> <br>
<a href="index.php?id=descargasenviar">&raquo; Enviar Descargas</a> <br>
<a href="index.php?id=mensaje_general">&raquo; Enviar Mensaje global</a><br>
<img src="images/line_menu.gif" width="149" height="2">