<!-- Titulo: phpmysql.php
Autor: phpmysql
Fecha: 14 de Diciembre del 2003 -->
<style>
/* Cuerpo del foro */
body,table { 
font-family: verdana ; 
font-size: 8pt ; 
color: #000000 ;
scrollbar-arrow-color: #757575;
scrollbar-3dlight-color: #757575;
scrollbar-highlight-color: #FFFFFF;
scrollbar-face-color: #F2F2FF;
scrollbar-shadow-color: #FFFFFF;
scrollbar-darkshadow-color: #757575;
scrollbar-track-color: #FFFFFF;
}
/* Titulos */
.t1 
{ font-size: 10pt ; 
font-weight: bold ; 
color: #F4F4F4 ; 
width:100%; 
filter:dropshadow(color=#000000,offx=1, offy=1, positive=1), glow(color=#000000, strength=0) ; 
height: 1 ; }
.tema {
font-size: 10pt ;
font-weight: bold ;}
/* Enlaces */
a 
{ color: #000059 ; 
font-weight: bold ; 
text-decoration: none 
}
a:hover 
{BACKGROUND: none; COLOR: #000000; TEXT-DECORATION: none; color: 9393FF
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla {
background: #D9D9FF ;
}
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #70777D 2 solid ; border-top: #6C757C 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: url(eforo_estilo/images/menutop.jpg);
}
.tabla_subtitulo {
border-left: #CACAFF 2 solid ; border-top: #CACAFF 2 solid ; border-right: #A8A8FF 2 solid ; border-bottom: #A8A8FF 2 solid ;
background: #B9B9FF ;
}
.tabla_mensaje {
background: #D3E4F5 ;
}
/* Formulario */
/* Formulario */
.form{ 
font-family: verdana ; 
font-size: 8pt ; 
color: #000000 ;
border: #000000 1 solid ; 
background: url(eforo_estilo/images/backround_form.gif);
}
</style>