<?
include ("encuestas.php");
?>
<? 
// Bloque descargas
include("config.php");
if($menu_descargas == "ON") {
?>
<br>
<table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
  <tr> 
    <td class="tabla_titulo"><div align="right" class="t1">Top 10 Descargas</div></td>
  </tr>
  <tr> 
    <td height="89" valign="top" class="tabla_mensaje" align="lef ???!?q??????t" > 
      <form method="post" action="index.php?id=descargas" form name="formulario3" >
        <div style="position: absolute ; visibility: hidden"> 
          <input type="hidden" name="aaa">
        </div>
        <input type="text" name="palabras" size="12" maxlength="65" class="form">
        <input type="submit" name="buscar" value="Buscar" class="form ">
      </form>
      <? // top 10 descargas
include("config.php") ;
$resp = mysql_query("select * from descargas order by visitas desc limit 10") ;
while($datos = @mysql_fetch_array($resp)) {
if (strlen($datos[titulo]) > 30) { 
$datos[titulo] = substr($datos[titulo],0,30).".."; }
echo "� <a href=descargas.php?e=$datos[id] target=_blanck > $datos[titulo]</a> ($datos[visitas])<br>
" ;
}
?>
      <br> <br> </td>
  </tr>
</table>
<?
}
else {
echo "" ;
}
?>
<? 
// Bloque afiliados minibanner
include("config.php");
if($menu_afiliados_minibanner == "ON") {
?>
<br>
<table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
  <tr> 
    <td class="tabla_titulo"><div align="right" class="t1">Afiliados</div></td>
  </tr>
  <tr> 
    <td height="6" valign="top" class="tabla_mensaje"> <div align="center">
        <? // sistema de minibanners
include("config.php");
$resp = mysql_query("select * from enlaces where urlminibanner!='' order by rand() limit 3") ;
$datos = @mysql_fetch_array($resp) ;
$datos1 = @mysql_fetch_array($resp) ;
$datos2 = @mysql_fetch_array($resp) ;
if ($datos[urlminibanner] != '' ) 
{echo "<a href='enlaces.php?e=$datos[id]' target='_blank'><img src='$datos[urlminibanner]' border=0 width=88 height=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>
<a href='enlaces.php?e=$datos1[id]' target='_blank'><img src='$datos1[urlminibanner]' border=0 width=88 height=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>
<a href='enlaces.php?e=$datos2[id]' target='_blank'><img src='$datos2[urlminibanner]' border=0 width=88 heig ???!?q?�:???ht=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>";}
else 
{echo "";}
?>
      </div></td>
  </tr>
</table>
<?
}
else {
echo "" ;
}
?>
<!-- fin bloques menus -->
<br>
<? 
// Link administrar (Todo lo contenido aqui solo lo ve el administrador)
if($HTTP_COOKIE_VARS[unick] == "$administrador") {
?>
<br>
<table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
  <tr> 
    <td class="tabla_titulo"><div align="right" class="t1">Administrar</div></td>
  </tr>
  <tr> 
    <td height="6" valign="top" class="tabla_mensaje"> <div align="left"> 
        <? 
			// el menu de los usuarios
			include("menu_admin.php"); 
			?>
        <a href="index.php?id=administrar"></a></div></td>
  </tr>
</table>
<?
}
else {
echo "" ;
}
// fin de link administrar
?>
