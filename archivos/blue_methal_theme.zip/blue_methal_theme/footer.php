<div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Tus 
  copyright, igual me gustaria que pusieras que yo KekoGrama fui el creador :P 
  tu decides</font></div>
