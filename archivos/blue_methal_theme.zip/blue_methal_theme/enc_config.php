<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_encuesta = "localhost"; //Aca va el servidor de la base de datos// //localhost es la mas usada//
$database_encuesta = ""; //Aca va la base de datos //
$username_encuesta = ""; //Aca va el usuario de la base de datos//
$password_encuesta = ""; //Aca va la password//
$encuesta = mysql_pconnect($hostname_encuesta, $username_encuesta, $password_encuesta) or trigger_error(mysql_error(),E_USER_ERROR); 
?>