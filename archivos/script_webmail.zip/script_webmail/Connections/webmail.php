<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_webmail = "localhost";
$database_webmail = "tu_base_de_datos";
$username_webmail = "tu_nombre_de_usuario_de_la_base_de_datos";
$password_webmail = "tu_contrasena_de_la_base_de_datos";
$webmail = mysql_pconnect($hostname_webmail, $username_webmail, $password_webmail) or trigger_error(mysql_error(),E_USER_ERROR); 
?>