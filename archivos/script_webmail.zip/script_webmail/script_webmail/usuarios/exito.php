<html>
<head>
<title>Operaci�n realizada</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
$op = $_GET[op];
if ($op == "borrado"){
echo "Se ha borrado el webmail con exito.";
}
if ($op == "enviado"){
echo "Se ha enviado el webmail con exito.";
}
?><br>
<a href="inicio.php">Volver a la p�gina principal.</a>
</body>
</html>
