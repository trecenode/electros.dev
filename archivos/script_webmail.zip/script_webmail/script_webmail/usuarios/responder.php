<? if (isset($_COOKIE['usuario'])){ ?>
<?php
 $id = $_GET[id];
 $usuario = $_COOKIE['usuario'];
?>
<?php require_once('../../Connections/webmail.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
$firma = $_POST['firma'];
$texto = $_POST['texto'];
$texto = "<p>$texto</p><p>$firma</p>";
  $insertSQL = sprintf("INSERT INTO webmail (de, para, asunto, texto) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['de'], "text"),
                       GetSQLValueString($_POST['para'], "text"),
                       GetSQLValueString($_POST['asunto'], "text"),
                       GetSQLValueString($texto, "text"));

  mysql_select_db($database_elrefranero, $elrefranero);
  $Result1 = mysql_query($insertSQL, $elrefranero) or die(mysql_error());

  $insertGoTo = "exito.php?op=enviado";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_webmail, $webmail);
$query_responder = "SELECT * FROM webmail WHERE id Like '%$id%'";
$responder = mysql_query($query_responder, $webmail) or die(mysql_error());
$row_responder = mysql_fetch_assoc($responder);
$totalRows_responder = mysql_num_rows($responder);

mysql_select_db($database_webmail, $webmail);
$query_usuario = "SELECT * FROM usuarios WHERE usuario Like '%$usuario%'";
$usuario = mysql_query($query_usuario, $webmail) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);
?>
<html>
<head>
<title>Responder al mensaje: <?php echo $row_responder['asunto']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<center><img src="../../Copia%20de%20webmail/images/webmail.gif"></center>
<form name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <p>
    <input name="de" type="hidden" value="<?php echo $usuario ?>">
    <input name="para" type="hidden" value="<?php echo $row_responder['de']; ?>">
	<input name="firma" type="hidden" value="<?php echo $row_usuario['firma']; ?>">
Asunto:<br>
<input name="asunto" type="text" id="asunto" value="RE: <?php echo $row_responder['asunto']; ?>" size="77"><br>
Mensaje:<br>
<?php
$mensajerecibido = eregi_replace("<p>","",$row_responder['texto']);
$mensajerecibido = eregi_replace("</p>"," ",$mensajerecibido);
$mensajerecibido = eregi_replace("<br>"," ",$mensajerecibido);
?>
<textarea name="texto" cols="82" rows="10" id="texto">>>>>><?php echo $mensajerecibido ?>
</textarea>
<input type="submit" name="Submit" value="Enviar">
  </p>
  <input type="hidden" name="MM_insert" value="form1">
</form>
</body>
</html>
<?php
mysql_free_result($responder);

mysql_free_result($usuario);
?>
<?
}
else
{
header("Location: index.php");
}
?>