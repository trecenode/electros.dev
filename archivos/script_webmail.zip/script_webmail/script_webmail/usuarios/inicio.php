<? if (isset($_COOKIE['usuario'])){ ?>
<html>
<head>
<title>Tu P�gina Principal</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p><center><img src="../images/webmail.gif" width="300" height="200" align="absmiddle">
</center></p>
<p>Bienvenido <?php echo $_COOKIE['usuario'] ?>
</p>
<p><a href="../../Copia%20de%20webmail/usuarios/enviar.php">Enviar web-mail</a><br>
  <a href="../../Copia%20de%20webmail/usuarios/leer.php">Leer web-mail</a><br>
  <a href="../../Copia%20de%20webmail/usuarios/salir.php">Salir</a></p>
</body>
</html>
<?
}
else
{
header("Location: index.php");
}
?>