<? if (isset($_COOKIE['usuario'])){ ?>
<?
$usuario = $_COOKIE['usuario'];
?>
<?php require_once('../../Connections/webmail.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
$firma = $_POST['firma'];
$texto = $_POST['texto'];
$texto = "<p>$texto</p><p>$firma</p>";
  $insertSQL = sprintf("INSERT INTO webmail (de, para, asunto, texto) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['de'], "text"),
                       GetSQLValueString($_POST['para'], "text"),
                       GetSQLValueString($_POST['asunto'], "text"),
                       GetSQLValueString($texto, "text"));

  mysql_select_db($database_elrefranero, $elrefranero);
  $Result1 = mysql_query($insertSQL, $elrefranero) or die(mysql_error());

  $insertGoTo = "exito.php?op=enviado";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_webmail, $webmail);
$query_usuario = "SELECT * FROM usuarios WHERE usuario Like '%$usuario%'";
$usuario = mysql_query($query_usuario, $webmail) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p><center><img src="../../Copia%20de%20webmail/images/webmail.gif" width="300" height="200"></center></p>
<form name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <p><? echo $MM_Username["usuario"] ?>
    <input type="hidden" name="de" value="<?php echo $_COOKIE['usuario'] ?>">
    <input type="hidden" name="firma" value="<?php echo $row_usuario['firma']; ?>">
</p>
  <p>Para: 
    <input name="para" type="text" id="para" size="50"> 
    @elrefranero.es
</p>
  <p>Asunto: 
    <input name="asunto" type="text" id="asunto" size="77">
  </p>
  <p>Texto:</p>
  <p>
    <textarea name="texto" cols="82" rows="10" id="texto">
    </textarea>
    <input type="submit" name="Submit" value="Enviar">
  </p>
  <input type="hidden" name="MM_insert" value="form1">
</form>
</body>
</html>
<?php
mysql_free_result($usuario);
?>
<?
}
else
{
header("Location: index.php");
}
?>