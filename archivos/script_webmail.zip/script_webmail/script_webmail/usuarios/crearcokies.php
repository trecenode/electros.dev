<?php
$origen = $_SERVER['HTTP_REFERER']; 
$_GET[$usuario];
setcookie ("usuario", "$usuario", time () + 7*24*60*60);
header("Location: inicio.php");