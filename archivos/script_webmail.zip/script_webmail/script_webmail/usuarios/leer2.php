<? if (isset($_COOKIE['usuario'])){ ?>
<?php
 $id = $_GET[op];
  ?>
<?php require_once('../../Connections/webmail.php'); ?>
<?php
mysql_select_db($database_webmail, $webmail);
$query_leer2 = "SELECT * FROM webmail WHERE id Like '%$id%'";
$leer2 = mysql_query($query_leer2, $webmail) or die(mysql_error());
$row_leer2 = mysql_fetch_assoc($leer2);
$totalRows_leer2 = mysql_num_rows($leer2);
?>
<html>
<head>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.Estilo1 {color: #FFFFFF}
-->
</style>
</head>

<body>
<center><img src="../../Copia%20de%20webmail/images/webmail.gif"></center>
<?
$usuario = $_COOKIE['usuario'];
if ($usuario == $row_leer2['para']){
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#00CC00">Enviado por: <?php echo $row_leer2['de']; ?>@elrefranero.es</td>
  </tr>
  <tr>
    <td bgcolor="#0000FF"><span class="Estilo1">Asunto: <?php echo $row_leer2['asunto']; ?></span></td>
  </tr>
  <tr>
    <td><?php echo $row_leer2['texto']; ?></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><span class="Estilo1"><a href="../../Copia%20de%20webmail/usuarios/borrar.php?id=<?php echo $row_leer2['id']; ?>">Borrar</a> | <a href="../../Copia%20de%20webmail/usuarios/responder.php?id=<?php echo $row_leer2['id']; ?>">Responder</a> | <a href="../../Copia%20de%20webmail/usuarios/leer.php">Atras </a></span></td>
  </tr>
</table>
<?
}
else{
echo "NO LEAS LOS MENSAJES QUE NO SON TULLOS";
}
?>
</body>
</html>
<?php
mysql_free_result($leer2);
?>
<?
}
else
{
header("Location: index.php");
}
?>