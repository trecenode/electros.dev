<? if (isset($_COOKIE['usuario'])){ ?>
<?
$usuario = $_COOKIE['usuario'];
?>
<?php require_once('../../Connections/webmail.php'); ?>
<?php
mysql_select_db($database_webmail, $webmail);
$query_webmail = "SELECT * FROM webmail WHERE para Like '%$usuario%'";
$webmail = mysql_query($query_webmail, $webmail) or die(mysql_error());
$row_webmail = mysql_fetch_assoc($webmail);
$totalRows_webmail = mysql_num_rows($webmail);
?>
<html>
<head>
<title>Bandeja de entrada</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<center><img src="../images/webmail.gif" width="300" height="200">
</center>
<?php if ($totalRows_webmail > 0) { // Show if recordset not empty ?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <?php do { ?>
  <tr>
    <td bgcolor="#00CC00">Web-Mail enviado por: <?php echo $row_webmail['de']; ?>@elrefranero.es</td>
  </tr>
  <tr>
    <td bgcolor="#0066FF">Asunto: <a href="../../Copia%20de%20webmail/usuarios/leer2.php?op=<?php echo $row_webmail['id']; ?>"><?php echo $row_webmail['asunto']; ?></a></td>
  </tr>
  <tr>
    <td><a href="../../Copia%20de%20webmail/usuarios/borrar.php?id=<?php echo $row_webmail['id']; ?>">Borrar</a> | <a href="../../Copia%20de%20webmail/usuarios/responder.php?id=<?php echo $row_webmail['id']; ?>">Responder</a> </td>
  </tr>
  <?php } while ($row_webmail = mysql_fetch_assoc($webmail)); ?>
</table>
<br>
��Atencion!! Si te aparece un mensaje que ponga enviado por Resource id #... borralo pues esto es un fallo de la base de datos, se puede leer el mensaje pero una vez leido te aconsejo que lo borres porque no te dejara leer los mensajes que tienes acontinuacion.
<?php } // Show if recordset not empty ?>
<?php if ($totalRows_webmail == 0) { // Show if recordset empty ?>
NO TIENES MENSAJES
<?php } // Show if recordset empty ?>
</body>
</html>
<?php
mysql_free_result($webmail);
?>
<?
}
else
{
header("Location: index.php");
}
?>