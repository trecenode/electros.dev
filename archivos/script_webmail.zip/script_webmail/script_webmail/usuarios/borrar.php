<?php require_once('../../Connections/webmail.php'); ?>
<? if (isset($_COOKIE['usuario'])){ ?>
<?php
 $id = $_GET[id];
  ?>
<?php require_once('../../Connections/webmail.php');

<?php
mysql_select_db($database_webmail, $webmail);
$query_verificar = "SELECT * FROM webmail WHERE id Like '%$id%'";
$verificar = mysql_query($query_verificar, $webmail) or die(mysql_error());
$row_verificar = mysql_fetch_assoc($verificar);
$totalRows_verificar = mysql_num_rows($verificar);
?>
?>
<?
$usuario = $_COOKIE['usuario'];
if ($usuario == $row_verificar['para']){
?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

if ((isset($_GET['id'])) && ($_GET['id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM webmail WHERE id=%s",
                       GetSQLValueString($_GET['id'], "int"));

  mysql_select_db($database_webmail, $webmail);
  $Result1 = mysql_query($deleteSQL, $webmail) or die(mysql_error());

  $deleteGoTo = "exito.php?op=borrado";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

?>
<html>
<head>
<title>Borrar</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

</body>
</html>
<?
}
else
{
?>
<html><head><title>No borres lo que no es tullo</title></head><body>No borres lo que no es tullo.</body></html>
<?php
mysql_free_result($verificar);
}
?>
<?
}
else
{
header("Location: index.php");
}
?>