<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<center><img src="../images/webmail.gif"></center>
<form action="../Copia%20de%20webmail/registrarse2.php" method="POST" name="form1">
  <p>Registrarse es facil solo tenes que poner el nombre de usuario,  tu contrase&ntilde;a y una firma para que aparesca en tus mensajes. Tu cuenta de web-mail sera &quot;tunombredeusuario@elrefranero.es&quot;. <br>
&iexcl;&iexcl;ATENCION!!: Esto es un webmail lo que quiere decir que no te podran enviar e-mail nada mas que recibiras web-mails de los usuarios de este site. Si tienes alguna duda contacta con nosotros <a href="mailto:rogelio2c@hotmail.com">aqu&iacute;</a>.</p>
  <p>Usuario: 
    <input name="usuario" type="text" id="usuario" size="30" maxlength="30">
    @elrefranero.es<br>
  Contrase&ntilde;a: 
  <input name="contrasena" type="text" id="contrasena" size="26" maxlength="30">
   <br>Firma: 
   <input name="firma" type="text" id="firma" size="32" maxlength="150">
   <br>
    <input type="submit" name="Submit" value="Enviar">
  </p>
  
</form>
</body>
</html>
