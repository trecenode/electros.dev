<?
if (isset($opcion)){
if ($opcion == "usuario"){
$usuario = $_POST[usuario];
}
else {
$usuario = $_POST[opcion];
}
}
else{
$usuario = $_POST[usuario];
}
$contrasena = $_POST[contrasena];
$firma = $_POST[firma]; ?>
<?php require_once('../Connections/webmail.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO usuarios (usuario, contrasena, firma) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['usuario'], "text"),
                       GetSQLValueString($_POST['contrasena'], "text"),
                       GetSQLValueString($_POST['firma'], "text"));

  mysql_select_db($database_webmail, $webmail);
  $Result1 = mysql_query($insertSQL, $webmail) or die(mysql_error());

  $insertGoTo = "../Copia%20de%20webmail/usuarios/index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_webmail, $webmail);
$query_versiexisteusuario = "SELECT * FROM usuarios WHERE usuario Like '%$usuario%'";
$versiexisteusuario = mysql_query($query_versiexisteusuario, $webmail) or die(mysql_error());
$row_versiexisteusuario = mysql_fetch_assoc($versiexisteusuario);
$totalRows_versiexisteusuario = mysql_num_rows($versiexisteusuario);
?>
<?php if ($totalRows_versiexisteusuario > 0) { // Show if recordset not empty ?>
<html><head><title>El Usuario ya existe</title></head><body>
<form action="../Copia%20de%20webmail/registrarse2.php" method="post">
  <p>
  <?
  $numero1 = rand(1,100);
  $numero2 = rand(1,100);
  if ($numero2 == $numero1){ $numero2 = $numero1 + 1; }
  $numero3 = rand(1,100);
  if ($numero3 == $numero1 OR $numero3 == $numero2){ $numero3 = $numero1*2-$numero2; }
  $numero4 = rand(1,100);
  if ($numero4 == $numero1 OR $numero4 == $numero2 OR $numero4 == $numero3){ $numero4 = $numero1*2-$numero3; }
  $usuario1 = "$usuario$numero1";
  $usuario2 = "$usuario$numero2";
  $usuario3 = "$usuario$numero3";
  $usuario4 = "$usuario$numero4";
  ?>
    <input name="contrasena" type="hidden" value="<?php echo $contrasena ?>">
    <input name="firma" type="hidden" value="<?php echo $firma ?>">
    El nombre de usuario que has puesto ya existe porfavor seleccione alguno de los que viene aqu� o escriba uno.<br>
    <input name="opcion" type="radio" value="<?php echo $usuario1 ?>">
    <?php echo $usuario1 ?><br>
    <input name="opcion" type="radio" value="<?php echo $usuario2 ?>">
    <?php echo $usuario2 ?><br>
    <input name="opcion" type="radio" value="<?php echo $usuario3 ?>">
    <?php echo $usuario3 ?><br>
    <input name="opcion" type="radio" value="<?php echo $usuario4 ?>">
    <?php echo $usuario4 ?><br>
    <input type="radio" name="opcion" value="usuario">
    <input type="text" name="usuario">
</p>
  <p>
    <input type="submit" name="Submit" value="Enviar">
</p>
</form>
</body></html>
<?php } // Show if recordset not empty ?>
<?php if ($totalRows_versiexisteusuario == 0) { // Show if recordset empty ?>
<html>
<head>
<title>Finalizar</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
Tu nombre de usuario es <?php echo $usuario ?>.<br>
Tu contrase�a es <?php echo $contrasena ?>.<br>
Y tu firma es: <?php echo $firma ?>
<form name="form1" action="<?php echo $editFormAction; ?>" method="POST">
<input name="usuario" type="hidden" value="<?php echo $usuario ?>"><input name="contrasena" type="hidden" value="<?php echo $contrasena ?>"><input name="firma" type="hidden" value="<?php echo $firma ?>"><input type="submit" name="Submit" value="Terminar">
<input type="hidden" name="MM_insert" value="form1">
</form>
</body>
</html>
<?php } // Show if recordset empty ?>
<?php
mysql_free_result($versiexisteusuario);
?>
