

<?
$referer = 'referer.txt';
$info = 'info.txt';
$ip = 'ip.txt';
unlink ($referer);
unlink ($info);
unlink ($ip);
?>

<div align="center">
  <p align="center">Borrado con exito,Click <a href="creaestadisticas.php">aqui</a> para crearlos de nuevo.</p>
  <p align="center">    <?
  $comprobarreferer = 'referer.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo referer.txt SI que existe.';
  else
  echo 'El archivo referer.txt NO existe.';
 ?><br>
    <?
  $comprobarreferer = 'info.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo referer.txt SI que existe.';
  else
  echo 'El archivo referer.txt NO existe.';
 ?><br>
    <?
  $comprobarreferer = 'ip.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo ip.txt SI que existe.';
  else
  echo 'El archivo ip.txt NO existe.';
 ?>
