<style type="text/css">
<!--
.Estilo1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 9px;
}
.Estilo2 {
	font-size: 9px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.Estilo3 {font-size: 10px}
.Estilo4 {
	font-size: 16px;
	color: #0033CC;
}
-->
</style>
</head>

<body>

<div align="center">
  <div align="center">
    <table width="34%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
      <tr>
        <td width="47%"><div align="center"><a href="informacionweb.php" class="Estilo2">Estadisticas</a></div></td>
        <td width="53%"><div align="center"><a href="creaestadisticas.php" class="Estilo2">Crear archivos de EST. </a></div></td>
      </tr>
      <tr>
        <td><div align="center"><a href="borrarestadisticas.php" class="Estilo2">Borrar estadisticas </a></div></td>
        <td><div align="center"><a href="ipvisitante.php" class="Estilo2">Ip de visitantes </a></div></td>
      </tr>
    </table>
    <br>
    <table width="27%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
      <tr>
        <td><div align="center" class="Estilo1">Los archivos de estadisticas ocupan: </div></td>
      </tr>
    </table>
    <br>
    <table width="25%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
      <tr>
        <td width="52%" class="Estilo1"><div align="left"><span class="Estilo4">&middot;</span>Referer.txt</div></td>
        <td width="48%"><?
	  $leer = 'referer.txt';
	  $medir = filesize ("$leer");
	  echo $medir;
	  ?>
	    KB</td>
      </tr>
      <tr>
        <td class="Estilo1"><div align="left"><span class="Estilo4">&middot;</span>Ip.txt</div></td>
        <td><?
	  $leerinfo = 'ip.txt';
	  $medirinfo = filesize ("$leerinfo ");
	  echo $medirinfo;
	  ?>
  KB</td>
      </tr>
      <tr>
        <td class="Estilo1"><div align="left"><span class="Estilo4">&middot;</span>Info.txt</div></td>
        <td><?
	  $leerinfo = 'info.txt';
	  $medirinfo = filesize ("$leerinfo");
	  echo $medirinfo;
	  ?>        KB</td>
      </tr>
    </table>
    <br>
    <table width="25%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
      <tr>
        <td><div align="center" class="Estilo1">Estadisticas de archivos </div></td>
      </tr>
      <tr>
        <td class="Estilo2"> <span class="Estilo6">&middot;</span>        <?
  $comprobarreferer = 'referer.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo referer.txt SI que existe.';
  else
  echo 'El archivo referer.txt NO existe.';
 ?></td>
      </tr>
      <tr>
        <td class="Estilo2"><span class="Estilo6">&middot;</span>        <?
  $comprobarreferer = 'info.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo referer.txt SI que existe.';
  else
  echo 'El archivo referer.txt NO existe.';
 ?></td>
      </tr>
    </table>
    <br>
    <table width="39%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
      <tr>
        <td width="65%" class="Estilo1 Estilo3"><span class="Estilo4">&middot;</span>El archivo que captura la ip es</td>
        <td width="35%"><a href="capturarip.php" target="_blank" class="Estilo2"> capturarip.php </a></td>
      </tr>
      <tr>
        <td class="Estilo1"><span class="Estilo4">&middot;</span>El archivo que captura la informacion es</td>
        <td><a href="capturador.php" target="_blank" class="Estilo2">capturador.php</a></td>
      </tr>
    </table>
    <br>
  </div>
