<? 
$archivo = 'ip.txt'; 
$abreme = fopen($archivo,'a'); 
if(strlen($_SERVER['REMOTE_ADDR'] ) > 0) { 
$escribeme = fwrite($abreme,$_SERVER['REMOTE_ADDR'] ."<br>\n"); 

} 
?> 