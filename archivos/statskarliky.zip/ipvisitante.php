<div align="center">
  <p><a href="estadisticas.php">Volver</a></p>
  <table width="55%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td><?php 
$info = 'ip.txt';
readfile ("$info");
?>        &nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
