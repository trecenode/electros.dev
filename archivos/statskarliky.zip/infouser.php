<title>Informacion del user</title>
<? 
$archivo = 'info.txt'; 
$abreme = fopen($archivo,'a'); 
if(strlen($HTTP_USER_AGENT) > 0) { 
$escribeme = fwrite($abreme,$HTTP_USER_AGENT."<br>\n"); 

} 
?> 
