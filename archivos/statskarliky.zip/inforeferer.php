<title>Informacion</title>
<?
$archivo = 'referer.txt'; 
$abreme = fopen($archivo,'a'); 
if(strlen($HTTP_REFERER) > 0) { 
$referer = fwrite($abreme,$HTTP_REFERER."<br>\n"); 
} 
?>