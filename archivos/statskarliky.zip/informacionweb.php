
<p align="center"><a href="estadisticas.php">Volver</a></p>
<p align="center">&nbsp;</p>
<table width="100%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="50%"><div align="center"><strong>Estadisticas de referes </strong></div></td>
    <td width="50%">    <div align="center"><strong>Estadisticas de (sistema operativo/explorador)</strong></div></td>
  </tr>
  <tr>
    <td><?php 
$referer = 'referer.txt';
readfile ("$referer");
?></td>
    <td><?php 
$info = 'info.txt';
readfile ("$info");
?></td>
  </tr>
</table>

