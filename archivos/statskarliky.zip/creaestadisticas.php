<div align="center">Pulsa aqui para volver a las <a href="estadisticas.php">estadisticas</a> </div>
<?
$referer = 'referer.txt'; 
$abreme = fopen($referer,'w+'); 
$creo = fwrite($abreme,"\n"); 
?>
<?
$info = 'info.txt'; 
$abreme = fopen($info,'w+'); 
$creo = fwrite($abreme,"\n"); 
?>
<?
$info = 'ip.txt'; 
$abreme = fopen($info,'w+'); 
$creo = fwrite($abreme,"\n"); 
?>
<div align="center">
  <?
  $comprobarreferer = 'referer.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo referer.txt SI que existe.';
  else
  echo 'El archivo referer.txt NO existe.';
 ?><br>
  <?
  $comprobarreferer = 'info.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo info.txt SI que existe.';
  else
  echo 'El archivo info.txt NO existe.';
 ?><br>
  <?
  $comprobarreferer = 'ip.txt';
  if (file_exists ("$comprobarreferer"))
  echo 'El archivo ip.txt SI que existe.';
  else
  echo 'El archivo rip.txt NO existe.';
 ?>
</div>
