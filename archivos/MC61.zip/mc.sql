-- phpMyAdmin SQL Dump
-- version 2.6.0-pl3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generaci�n: 12-12-2004 a las 15:10:49
-- Versi�n del servidor: 4.0.22
-- Versi�n de PHP: 4.3.9
-- 
-- Base de datos: `infokeko_mc`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alerta_general`
-- 

CREATE TABLE `alerta_general` (
  `id` int(11) NOT NULL auto_increment,
  `texto` text NOT NULL,
  `autor` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `alerta_general`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alerta_mod`
-- 

CREATE TABLE `alerta_mod` (
  `id` int(11) NOT NULL auto_increment,
  `texto` text NOT NULL,
  `email` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  `nick` int(11) NOT NULL default '0',
  `leido` smallint(6) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=13 ;

-- 
-- Volcar la base de datos para la tabla `alerta_mod`
-- 

INSERT INTO `alerta_mod` VALUES (3, 'Prueba', 'prueba@tudominio.com', '200.109.195.233', '06.12.04, 16:00:44', -1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alertas`
-- 

CREATE TABLE `alertas` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL default '',
  `nick` varchar(255) NOT NULL default '',
  `texto` text NOT NULL,
  `autor` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=72 ;

-- 
-- Volcar la base de datos para la tabla `alertas`
-- 

INSERT INTO `alertas` VALUES (32, '81.0.27.27', 'Prueba', 'Prueba.', 'Prueba');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `automensaje`
-- 

CREATE TABLE `automensaje` (
  `id` tinyint(4) NOT NULL default '0',
  `texto` text NOT NULL,
  `ultimo` int(11) NOT NULL default '0'
) TYPE=MyISAM;

-- 
-- Volcar la base de datos para la tabla `automensaje`
-- 

INSERT INTO `automensaje` VALUES (1, 'Uhm prueba de Rott', 1102294033);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `baneos`
-- 

CREATE TABLE `baneos` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL default '',
  `nick` varchar(255) NOT NULL default '',
  `desbanear` int(11) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=100 ;

-- 
-- Volcar la base de datos para la tabla `baneos`
-- 

0);
INSERT INTO `baneos` VALUES (39, '62.43.72.12', 'An�nimo', 1109667660);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `boletin`
-- 

CREATE TABLE `boletin` (
  `id` int(11) NOT NULL auto_increment,
  `titulo` varchar(255) NOT NULL default '',
  `texto` text NOT NULL,
  `autor` int(11) NOT NULL default '0',
  `fecha` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=12 ;

-- 
-- Volcar la base de datos para la tabla `boletin`
-- 

INSERT INTO `boletin` VALUES (4, 'Bienvenido', 'Bienvenido a el Minichat v6.0. Si encuentra algun bug no dudes en contactar a Rott@info-keko.com. Un Saludo, Rott ;)', 80, '15.11.04, 19:19:29');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `caracteres`
-- 

CREATE TABLE `caracteres` (
  `id` int(11) NOT NULL auto_increment,
  `caracter` varchar(255) NOT NULL default '',
  `autor` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `caracteres`
-- 

INSERT INTO `caracteres` VALUES (15, '�', '119', '12.12.04, 10:20:13');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `categorias`
-- 

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(255) NOT NULL default '',
  `imagen` varchar(255) NOT NULL default '',
  `descripcion` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=14 ;

-- 
-- Volcar la base de datos para la tabla `categorias`
-- 

INSERT INTO `categorias` VALUES (13, 'Especiales', '&iquest;Crees que eres especial?\r\nPues aqui tienes una colecci&ntilde;on de placas especiales a tu disposici&oacute;n.', 'http://www.info-keko.com/mcc/catalogo/secciones/especiales.gif');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `censuras`
-- 

CREATE TABLE `censuras` (
  `id` int(11) NOT NULL auto_increment,
  `palabra` varchar(255) NOT NULL default '',
  `autor` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=83 ;

-- 
-- Volcar la base de datos para la tabla `censuras`
-- 

INSERT INTO `censuras` VALUES (1, 'co�o', '2', '21.11.04, 02:47:12');
INSERT INTO `censuras` VALUES (2, 'xoxo', '2', '21.11.04, 02:47:19');
INSERT INTO `censuras` VALUES (3, 'pene', '2', '21.11.04, 02:47:28');
INSERT INTO `censuras` VALUES (4, 'poya', '2', '21.11.04, 02:47:34');
INSERT INTO `censuras` VALUES (5, 'toto', '2', '21.11.04, 02:47:46');
INSERT INTO `censuras` VALUES (6, 'pipa', '2', '21.11.04, 02:47:54');
INSERT INTO `censuras` VALUES (7, 'vulva', '2', '21.11.04, 02:48:00');
INSERT INTO `censuras` VALUES (8, 'puta', '2', '21.11.04, 02:48:52');
INSERT INTO `censuras` VALUES (9, 'follar', '2', '21.11.04, 02:48:59');
INSERT INTO `censuras` VALUES (10, 'folla', '2', '21.11.04, 02:49:10');
INSERT INTO `censuras` VALUES (11, 'mari', '2', '21.11.04, 02:49:19');
INSERT INTO `censuras` VALUES (15, 'tk', '2', '21.11.04, 02:52:25');
INSERT INTO `censuras` VALUES (31, 'joder', '114', '05.12.04, 11:25:44');
INSERT INTO `censuras` VALUES (17, 'tonto', '2', '21.11.04, 02:52:39');
INSERT INTO `censuras` VALUES (18, 'mamon', '2', '21.11.04, 02:52:45');
INSERT INTO `censuras` VALUES (19, 'chupa', '2', '21.11.04, 02:52:55');
INSERT INTO `censuras` VALUES (20, 'agarra', '2', '21.11.04, 02:53:00');
INSERT INTO `censuras` VALUES (30, 'verga', '94', '05.12.04, 07:58:26');
INSERT INTO `censuras` VALUES (22, 'mierda', '105', '28.11.04, 12:54:04');
INSERT INTO `censuras` VALUES (23, 'mamona', '92', '01.12.04, 05:05:24');
INSERT INTO `censuras` VALUES (24, 'mamamelo', '105', '01.12.04, 18:15:11');
INSERT INTO `censuras` VALUES (25, 'cagar', '105', '01.12.04, 18:21:04');
INSERT INTO `censuras` VALUES (26, 'cagon', '105', '01.12.04, 18:21:10');
INSERT INTO `censuras` VALUES (27, 'fuk', '105', '01.12.04, 18:21:33');
INSERT INTO `censuras` VALUES (28, 'mamamela', '92', '02.12.04, 07:30:22');
INSERT INTO `censuras` VALUES (32, 'gay', '94', '05.12.04, 12:01:02');
INSERT INTO `censuras` VALUES (33, 'marico', '94', '05.12.04, 12:01:31');
INSERT INTO `censuras` VALUES (34, 'hack', '94', '05.12.04, 17:51:08');
INSERT INTO `censuras` VALUES (41, 'retrasado', '93', '06.12.04, 13:03:22');
INSERT INTO `censuras` VALUES (40, 'gilipoya', '93', '06.12.04, 12:56:08');
INSERT INTO `censuras` VALUES (42, 'cerda', '119', '07.12.04, 10:07:50');
INSERT INTO `censuras` VALUES (43, 'warra', '119', '07.12.04, 10:08:27');
INSERT INTO `censuras` VALUES (44, 'iepamela', '119', '07.12.04, 10:08:39');
INSERT INTO `censuras` VALUES (45, 'ramera', '119', '07.12.04, 10:08:50');
INSERT INTO `censuras` VALUES (46, 'eskinera', '119', '07.12.04, 10:08:57');
INSERT INTO `censuras` VALUES (47, 'me cago en tu puta madre', '119', '07.12.04, 10:58:06');
INSERT INTO `censuras` VALUES (50, 'web', '2', '07.12.04, 15:28:18');
INSERT INTO `censuras` VALUES (53, 'lamer', '2', '07.12.04, 15:29:08');
INSERT INTO `censuras` VALUES (54, 'pu.to', '2', '07.12.04, 15:29:26');
INSERT INTO `censuras` VALUES (55, 'puto', '2', '07.12.04, 15:29:34');
INSERT INTO `censuras` VALUES (56, 'p.uto', '2', '07.12.04, 15:29:41');
INSERT INTO `censuras` VALUES (57, 'lammer', '2', '07.12.04, 15:29:54');
INSERT INTO `censuras` VALUES (58, 'estupido', '2', '07.12.04, 15:30:12');
INSERT INTO `censuras` VALUES (59, 'feo', '2', '07.12.04, 15:30:17');
INSERT INTO `censuras` VALUES (60, 'warra', '2', '07.12.04, 15:30:22');
INSERT INTO `censuras` VALUES (61, 'guarra', '2', '07.12.04, 15:30:29');
INSERT INTO `censuras` VALUES (62, 'paleto', '2', '07.12.04, 15:30:41');
INSERT INTO `censuras` VALUES (63, 'nen', '2', '07.12.04, 15:30:48');
INSERT INTO `censuras` VALUES (80, 'chinga', '114', '08.12.04, 17:14:56');
INSERT INTO `censuras` VALUES (65, 'ni�ato', '2', '07.12.04, 15:31:03');
INSERT INTO `censuras` VALUES (66, 'ni�ata', '2', '07.12.04, 15:31:09');
INSERT INTO `censuras` VALUES (67, 'panel', '2', '07.12.04, 15:31:29');
INSERT INTO `censuras` VALUES (68, 'shit', '2', '07.12.04, 15:31:55');
INSERT INTO `censuras` VALUES (69, 'skainer', '2', '07.12.04, 15:32:26');
INSERT INTO `censuras` VALUES (71, 'gilipollas', '2', '07.12.04, 15:34:44');
INSERT INTO `censuras` VALUES (72, 'gilipolla', '2', '07.12.04, 15:34:55');
INSERT INTO `censuras` VALUES (79, 'mie.rda', '114', '08.12.04, 17:14:46');
INSERT INTO `censuras` VALUES (74, 'gili', '2', '07.12.04, 15:35:13');
INSERT INTO `censuras` VALUES (75, 'paja', '2', '07.12.04, 15:35:20');
INSERT INTO `censuras` VALUES (76, 'lesbi', '2', '07.12.04, 15:35:34');
INSERT INTO `censuras` VALUES (77, 'zorra', '2', '07.12.04, 15:35:53');
INSERT INTO `censuras` VALUES (78, 'ostia', '2', '07.12.04, 15:38:02');
INSERT INTO `censuras` VALUES (81, 'ca.bron', '114', '08.12.04, 17:15:46');
INSERT INTO `censuras` VALUES (82, 'cabron', '114', '08.12.04, 17:16:03');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `colores`
-- 

CREATE TABLE `colores` (
  `campo` varchar(255) NOT NULL default '',
  `valor` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Volcar la base de datos para la tabla `colores`
-- 

INSERT INTO `colores` VALUES ('fondotabla', '#DBDFE6');
INSERT INTO `colores` VALUES ('bordetabla', '#EEEFF2');
INSERT INTO `colores` VALUES ('colorfondo', '#82A1D9');
INSERT INTO `colores` VALUES ('bordecampo', '#EEEFF2');
INSERT INTO `colores` VALUES ('fondocampo', '#DDDDDD');
INSERT INTO `colores` VALUES ('cimpar', '#DBDFE6');
INSERT INTO `colores` VALUES ('cpar', '#F2F3F4');
INSERT INTO `colores` VALUES ('colortexto', '#000000');
INSERT INTO `colores` VALUES ('colorowners', '#800000');
INSERT INTO `colores` VALUES ('colorvip', '#FFA74F');
INSERT INTO `colores` VALUES ('coloranonimo', '#000000');
INSERT INTO `colores` VALUES ('colormoderador', '#FA6105');
INSERT INTO `colores` VALUES ('colorbronze', '#FA6105');
INSERT INTO `colores` VALUES ('colorrubi', '#FA6105');
INSERT INTO `colores` VALUES ('colorzafiro', '#FA6105');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `configuracion`
-- 

CREATE TABLE `configuracion` (
  `campo` varchar(255) NOT NULL default '',
  `valor` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Volcar la base de datos para la tabla `configuracion`
-- 

INSERT INTO `configuracion` VALUES ('maximo', '15');
INSERT INTO `configuracion` VALUES ('numMensajes', '15');
INSERT INTO `configuracion` VALUES ('maxNick', '15');
INSERT INTO `configuracion` VALUES ('maxMsg', '300');
INSERT INTO `configuracion` VALUES ('activarUrl', 'off');
INSERT INTO `configuracion` VALUES ('activarReg', 'on');
INSERT INTO `configuracion` VALUES ('activarIp', 'on');
INSERT INTO `configuracion` VALUES ('activarHora', 'on');
INSERT INTO `configuracion` VALUES ('activarLogo', 'on');
INSERT INTO `configuracion` VALUES ('activarBBcode', 'off');
INSERT INTO `configuracion` VALUES ('langactual', 'spanish');
INSERT INTO `configuracion` VALUES ('activarTiempo', 'on');
INSERT INTO `configuracion` VALUES ('tiempo', '15');
INSERT INTO `configuracion` VALUES ('esperar', '10');
INSERT INTO `configuracion` VALUES ('activarMant', 'off');
INSERT INTO `configuracion` VALUES ('total_mensajes', '8912');
INSERT INTO `configuracion` VALUES ('activarAutomensaje', 'off');
INSERT INTO `configuracion` VALUES ('tAutomensaje', '');
INSERT INTO `configuracion` VALUES ('catalogo', 'off');
INSERT INTO `configuracion` VALUES ('placasAutomaticas', 'on');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `contenido`
-- 

CREATE TABLE `contenido` (
  `pagina` varchar(255) NOT NULL default '',
  `valor` text NOT NULL
) TYPE=MyISAM;

-- 
-- Volcar la base de datos para la tabla `contenido`
-- 

INSERT INTO `contenido` VALUES ('preguntas', '</b><font face="Tahoma" size="1"><b>MoD:</b>\r\n<br><b>1</b> �Es MoD ese keko?  Si tiene el nick en naranja s�.<br><b>2</b> �Es Owner ese keko?  Si tiene el nick en rojo s�.\r\n<br><b>3</b> �Qu� puesto tiene de MoD?  M�ralo poniendo el cursor encima de su nick.<br><b>4</b> �Qui�nes son los MoDs del MC?  \r\nPulsa en el s�mbolo de la interrogaci�n azul, presiona lista de MoDs y podr�s ver todos los MoDs.<br><br><b>Placas:</b><br><b>1</b> �D�nde se encuentran las placas a la venta?  Est�n en lo alto del MC, el cat�logo.<br><b>\r\n2 </b>�Puedo usar la placa MoD?  No hasta cuando seas MoD y los MoDs de menores rangos no pueden usar las de mayor rango.<br>\r\n<b>3</b> �Las placas del MC puedo usarlas?  S�, enviando un sms, al igual que con la vip.</font><p>\r\n<font face="Tahoma" size="1">\r\n<b>Reglas: </b>\r\n<br><b>1 </b>�Puedo hacer lo que quiera?  No, tenemos una serie de reglas que debes cumplir, est�n en el signo de \r\nla interrogaci�n azul, presiona Reglas del MC.\r\n<br><b>2</b> �Si incumplo alguna regla que pasar�?  Ser�s baneado por algunos de nuestros MoDs.\r\n</font>\r\n</p>\r\n<p><font face="Tahoma" size="1"><b>Ayuda: </b>\r\n<br><b>1</b> �Si me est�n molestando qu� debo hacer?  Comunic�rselo a un MoD y �ste \r\ntomar� las medidas necesarias.<br><b>2 </b>�Si no hay MoD que hago en caso de \r\nque haya alguien molestando?  Presiona en el interrogante azul, despu�s presione �MoD, Ay�dame! y cuando se conecte un MoD le ayudar�.\r\n<br><br><b>Ser MoD:<br>1 </b>�Puedo ser MoD?  S�, pero tienes que tener unos requisitos que los puedes encontrar en el \r\ninterrogante azul, en la secci�n Ser un MoD.\r\n<br><b>2</b> �Teniendo esas condiciones de MoD, podr� serlo?  Puede que s�, \r\ny puede que no, depende del n�mero de MoD''s que hayan. </font> </p>\r\n<p>\r\n<font face="Tahoma" size="1">\r\n<b>Mensaje: </b>\r\n<br><b>1 </b>�Puedo escribir un mensaje del tama�o que quiera?  No, el \r\ntama�o es configurable, lo configuran los Managers.<br><b>2</b> �Puedo escribir \r\nen negrita de alguna manera?  Depende, si esa opci�n esta activada o no.\r\n<br><b>3</b> �Puedo escribir en cursiva de alguna manera?  Depende, si esa \r\nopci�n esta activada o no.\r\n<br><b>4</b> �Puedo escribir subrayado de alguna manera?  Depende, si esa \r\nopci�n esta activada o no.</font>');
INSERT INTO `contenido` VALUES ('privacidad', '<font face="Tahoma"><b><font size="1">Placas:</font></b><font size="1"><br>\r\n<b>1 </b>Las placas de vip solo seran para aquellos que las hayan comprado, si alguien la usa o dice el code sera baneado.<br>\r\n<b>2 </b>Las placas de MoDs son s�lo para MoDs, si alguien intenta averiguar el code o algun MoD dice el code de la placa ser� baneado y en el caso de MoD tambi�n ser� despedido.<br>\r\n<br>\r\n<b>InFo-KeKo:</b><br>\r\n<b>1 </b>Esta web ha tomado medidas par que nadie se copie de ella, quien copie algo de la p�gina ser� baneado y tendr� problemas de muchos tipos.<br>\r\n<b>2 </b>No est� permitido usar el bot�n derecho para copiar (se han tomado medidas) y tampoco otros m�todos, como es el de usar el paint.<br>\r\n<br>\r\n<b>Minichat:</b><br>\r\n<b>1 </b>Los MoDs no deben decir su contrase�a del mc ya que puede haber gente no autoriazada para este puesto.<br>\r\n<b>2 </b> No de nunca informacion personal sobre usted. (Nombre, Msn, Edad, Etc.)<br>\r\n<b>3 </b>Un MoD nunca le pedir� su contrase�a.</b></font></font>');
INSERT INTO `contenido` VALUES ('reglas', '<font face="Tahoma" size="1"><b>Lo que si puedes hacer:</b><br><img border=''0'' src=''../smilies/bien.gif''> Hablar sobre el KekoCity y IK.<br><img border=''0'' src=''../smilies/bien.gif''> Hacer amigos, y pasartelo bien.<br><img border=''0'' src=''../smilies/bien.gif''> Utilizar placas que has comprado.<br><img border=''0'' src=''../smilies/bien.gif''> Quedar en salas del City.<br><b><br>Lo que no puedes hacer:</b><br><img border=''0'' src=''../smilies/mal.gif''> Insultar, molestar, publicidad.<br><img border=''0'' src=''../smilies/mal.gif''> Utilizar placas que no has comprado.<br><img border=''0'' src=''../smilies/mal.gif''> Pedir o intentar usar CODES de placas.<br><img border=''0'' src=''../smilies/mal.gif''> Decir URLs de p�ginas sobre el City.</font><br><img border=''0'' src=''../smilies/mal.gif''> Hablar sobre Cracking y estafas del City.</font>');
INSERT INTO `contenido` VALUES ('seguridad', '<font face="Tahoma"><b> <font size="1">Contrase�as:</font></b><font size="1"><br>\r\n1 </b>No des tu contrase�a a nadie.<br><b>\r\n2 </b>Contrase�a con cifras num�ricas.<br><b>\r\n3 </b>Contrase�a con m�s de 6 car�cteres.<br><b>\r\n4 </b>No cojas una contrase�a como tu nombre, etc.<br><b><br>\r\nInFo-KeKo:<br>\r\n1 </b>Contacta con los MoDs siempre que sea necesario<br><b>\r\n2 </b>�Tienes alguna duda? Nuestros MoDs te las resolver�n<br><b>\r\n3 </b>No molestes, insultes, flodees, publiques u otra cualquier cosa que perjudique a los visitantes o due�os de esta web sino quieres ser baneado de ella.</font></font>');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `flood`
-- 

CREATE TABLE `flood` (
  `ip` varchar(255) NOT NULL default '',
  `tiempo` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Volcar la base de datos para la tabla `flood`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log_alerta_mod`
-- 

CREATE TABLE `log_alerta_mod` (
  `id` int(11) NOT NULL auto_increment,
  `texto` text NOT NULL,
  `email` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  `nick` varchar(255) NOT NULL default '',
  `mod` int(11) NOT NULL default '0',
  `respuesta` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=29 ;

-- 
-- Volcar la base de datos para la tabla `log_alerta_mod`
-- 

INSERT INTO `log_alerta_mod` VALUES (20, 'Prueba', '�Prueba@tudomino.com', '62.43.72.12', '05.12.04, 07:18:13', '-1', 102, 'Prueba');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log_alertas`
-- 

CREATE TABLE `log_alertas` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL default '',
  `nick` varchar(255) NOT NULL default '',
  `autor` varchar(255) NOT NULL default '',
  `texto` text NOT NULL,
  `fecha` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=72 ;

-- 
-- Volcar la base de datos para la tabla `log_alertas`
-- 

INSERT INTO `log_alertas` VALUES (49, '80.26.237.161', 'Prueba', '2', 'Prueba', '11:10');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log_alertas_generales`
-- 

CREATE TABLE `log_alertas_generales` (
  `id` int(11) NOT NULL auto_increment,
  `texto` text NOT NULL,
  `autor` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=46 ;

-- 
-- Volcar la base de datos para la tabla `log_alertas_generales`
-- 

INSERT INTO `log_alertas_generales` VALUES (32, 'Prueba del nuevo mc', '2', '05.12.04, 09:03:57');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log_baneos`
-- 

CREATE TABLE `log_baneos` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL default '',
  `nick` varchar(255) NOT NULL default '',
  `autor` int(11) NOT NULL default '0',
  `causa` text NOT NULL,
  `fecha_baneado` varchar(255) NOT NULL default '',
  `desbanear` int(11) NOT NULL default '0',
  `causa_desbaneo` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=64 ;

-- 
-- Volcar la base de datos para la tabla `log_baneos`
-- 

INSERT INTO `log_baneos` VALUES (36, '83.41.201.194', '.ek0.', 1, 'Hacerse Pasar Por ek0 y estar diciemdo estupidezes.', '05.12.04, 11:50', 1102231800, 'Fin del per�odo');
INSERT INTO `log_baneos` VALUES (38, '83.41.201.194', '.ek0.', 2, 'Por que s&iacute;', '05.12.04, 13:48', 1102291200, 'Fin del per�odo');
INSERT INTO `log_baneos` VALUES (39, '62.43.72.12', 'An�nimo', 102, 'Utilizar Mod Alerts para insultar a los MoDs con insultos muy fuertes . Pongo anonimo en su nick por que no lo se.', '05.12.04, 16:22', 1109667660, '');
INSERT INTO `log_baneos` VALUES (40, '200.109.195.233', 'kekoNombre', 94, 'intentar decifrar codes de alertas', '05.12.04, 19:18', 1072947660, 'Fin Del Periodo');
INSERT INTO `log_baneos` VALUES (41, '83.41.79.41', 'Wold', 2, 'Acusar', '05.12.04, 10:34:24', 1103612400, '');
INSERT INTO `log_baneos` VALUES (42, '201.133.77.183', 'KekoNombre', 94, 'Por insultar e intentar decifrar codes del MC', '05.12.04, 20:08', 1102431780, 'Fin del per�odo');
INSERT INTO `log_baneos` VALUES (43, '200.60.249.48', 'BPD', 93, 'esta insultando al keko apu, ya pesar de k le aviso mas d una vez, sigue picandole', '05.12.04, 20:46', 1102395660, 'Serrico');
INSERT INTO `log_baneos` VALUES (44, '200.60.249.48', 'BPD', 114, 'Ya fue baneado y se cambio el IP', '06.12.04, 00:21', 1102666860, 'Serrico');
INSERT INTO `log_baneos` VALUES (45, '81.38.110.131', 'Ronin', 104, 'Insultar continumente, e infingriendo la ley de I-K', '06.12.04, 20:28', 1607325240, '');
INSERT INTO `log_baneos` VALUES (46, '80.58.20.235', 'Ronin', 1, 'No desbanear !Nunca! Oficialmente Baneado Por Serrico.', '06.12.04, 22:11', 1609405140, '');
INSERT INTO `log_baneos` VALUES (47, '200.106.6.104', 'BPD', 2, 'Estoy hasta los webos de el', '07.12.04, 00:40', 1609405140, '');
INSERT INTO `log_baneos` VALUES (48, '200.109.195.233', 'gabriel!...', 2, 'Publicidad', '07.12.04, 00:43', 1102726800, 'Fin Del Periodo');
INSERT INTO `log_baneos` VALUES (49, '80.102.176.240', '****', 102, 'Por cambiarse de nick , ponerse nick de insultos , y nicks censurados.', '07.12.04, 10:29', 1108540740, '');
INSERT INTO `log_baneos` VALUES (50, '192.168.200.199', '.ek0.', 2, 'Por tonto', '07.12.04, 15:46:40', 1310105520, '');
INSERT INTO `log_baneos` VALUES (51, '192.168.215.100', '.ek0.', 2, 'POr tonto', '07.12.04, 15:47:35', 1362481500, '');
INSERT INTO `log_baneos` VALUES (52, '200.60.255.101', 'BPD', 114, 'Rott ya lo baneo, se cambio IP y debe terminar su tiempo de baneo ya establecido.', '08.12.04, 21:09', 1609405140, '');
INSERT INTO `log_baneos` VALUES (53, '69.79.18.228', 'hjol', 114, 'Isulto de manera grave en el MC', '09.12.04, 02:14', 1105174860, '');
INSERT INTO `log_baneos` VALUES (54, '213.37.81.206', '--.-sergio-.--', 101, 'Insultar en el Mini Chat y decir palabrotas.', '09.12.04, 21:17', 1134191760, '');
INSERT INTO `log_baneos` VALUES (55, '80.24.86.247', 'yamil', 114, 'Insultar', '10.12.04, 04:23', 1103187660, '');
INSERT INTO `log_baneos` VALUES (56, '200.42.194.99', 'Mercenario', 114, 'Flodeo repetidas veces', '10.12.04, 04:24', 1103187660, '');
INSERT INTO `log_baneos` VALUES (57, '200.60.253.74', 'BPD', 114, 'RoTT ya lo baneo. Cambio su IP y flodeo repetidas veces en el MC, debe cumplir su tiempo ya establecido por RoTT', '10.12.04, 04:27', 1609405260, '');
INSERT INTO `log_baneos` VALUES (58, '83.39.67.154', 'kater', 93, 'dice que le baneemos, que no quiere volver a estar en esta mi-erda de web, que serrico es un ni&ntilde;ato y otras cosas, porlo que se ha ganado el baneo', '10.12.04, 19:32', 1104570060, '');
INSERT INTO `log_baneos` VALUES (59, '207.248.43.218', 'OscarMedina', 92, 'vacilar, con ke kekocity no abrir&aacute;, y pasandose de la ralla.', '10.12.04, 19:34', 1116782220, '');
INSERT INTO `log_baneos` VALUES (60, '63.245.106.66', 'yaki', 92, 'insultar, pasarse de la raya, y decir palabras prohibidas totalmente', '10.12.04, 19:34', 1072947660, 'Fin del per�odo');
INSERT INTO `log_baneos` VALUES (61, '63.245.106.66', 'yaki', 114, 'insulta y molestar repetidas veces en el MC', '10.12.04, 19:35', 1105347660, '');
INSERT INTO `log_baneos` VALUES (62, '200.121.183.247', 'BPD', 114, 'el mismo caso de siempre', '10.12.04, 22:24', 1609405260, 'Trankilo no es su culpa -_-');
INSERT INTO `log_baneos` VALUES (63, '200.121.183.247', 'BPD', 118, 'No cumplir su fecha de desbaneo, cambiarse de ip continuamente, ', '10.12.04, 22:33', 1103607300, '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `log_mensajes`
-- 

CREATE TABLE `log_mensajes` (
  `id` int(11) NOT NULL auto_increment,
  `usuario` int(11) NOT NULL default '0',
  `texto` text NOT NULL,
  `web` varchar(255) NOT NULL default '',
  `color` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  `nombre` varchar(255) NOT NULL default '',
  `tiempo` int(11) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=4214 ;

-- 
-- Volcar la base de datos para la tabla `log_mensajes`
-- 

INSERT INTO `log_mensajes` VALUES (3138, 92, 'Pues Quiero Decirle Gente que tenemos un Top en el que podeis ganar precios :o 10� o Un dominio.com y un mes de host privado. Eso si Vuestra **** es la mas votada de todas hoy ya empieza :P si quereis inscribir tu **** y crees que podras ganar no lo dudes y subscribete.', '', '#FA6105', '217.125.123.245', ' Enviado a las 11:11', '', 1102673512);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `mensajes`
-- 

CREATE TABLE `mensajes` (
  `id` int(255) NOT NULL auto_increment,
  `usuario` int(11) NOT NULL default '0',
  `texto` text NOT NULL,
  `web` varchar(255) NOT NULL default '',
  `color` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  `fecha` varchar(255) NOT NULL default '',
  `nombre` varchar(255) NOT NULL default '',
  `tiempo` int(11) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=851 ;

-- 
-- Volcar la base de datos para la tabla `mensajes`
-- 

INSERT INTO `mensajes` VALUES (850, 120, 'de que hablan :P', '', '#FA6105', '200.60.254.40', ' Enviado a las 00:00', '', 1102892459);
INSERT INTO `mensajes` VALUES (849, -1, 'oap mira nuestra **** ^^', '', '#000000', '200.77.129.125', ' Enviado a las 23:33', 'ddryeyi', 1102890796);
INSERT INTO `mensajes` VALUES (848, 114, 'ddryeyi estas?', '', '#FA6105', '201.243.103.105', ' Enviado a las 23:29', '', 1102890562);
INSERT INTO `mensajes` VALUES (847, 114, 'ya llegue! =D', '', '#FA6105', '201.243.103.105', ' Enviado a las 23:29', '', 1102890554);
INSERT INTO `mensajes` VALUES (846, 114, 'Naz', '', '#FA6105', '201.243.103.105', ' Enviado a las 23:29', '', 1102890545);
INSERT INTO `mensajes` VALUES (845, -1, 'hay alguien?', '', '#000000', '200.77.129.125', ' Enviado a las 23:23', 'ddryeyi', 1102890195);
INSERT INTO `mensajes` VALUES (824, -1, ':o', '', '#000000', '84.122.82.43', ' Enviado a las 21:50', 'ZeKa', 1102884601);
INSERT INTO `mensajes` VALUES (825, -1, 'Wols a toos!!! :)', '', '#000000', '81.37.169.130', ' Enviado a las 22:02', 'Ludo', 1102885373);
INSERT INTO `mensajes` VALUES (826, 1, 'Ola ^_^', '', '#800000', '212.159.30.169', ' Enviado a las 22:04', '', 1102885448);
INSERT INTO `mensajes` VALUES (827, 1, 'Alguien por aki?', '', '#800000', '212.159.30.169', ' Enviado a las 22:06', '', 1102885599);
INSERT INTO `mensajes` VALUES (828, 1, 'Enga', '', '#800000', '212.159.30.169', ' Enviado a las 22:09', '', 1102885787);
INSERT INTO `mensajes` VALUES (829, -1, 'yo :)', '', '#000000', '81.37.169.130', ' Enviado a las 22:10', 'Ludo', 1102885807);
INSERT INTO `mensajes` VALUES (830, 1, 'K tal?', '', '#800000', '212.159.30.169', ' Enviado a las 22:11', '', 1102885868);
INSERT INTO `mensajes` VALUES (831, -1, 'Bien :) Aunque estoy muy impaciente x abrir KC :) es la primera vez que hablo con un **** :O', '', '#000000', '81.37.169.130', ' Enviado a las 22:12', 'Ludo', 1102885938);
INSERT INTO `mensajes` VALUES (832, 1, 'xD', '', '#800000', '212.159.30.169', ' Enviado a las 22:12', '', 1102885958);
INSERT INTO `mensajes` VALUES (833, -1, 'Quer&iacute;a decir ****', '', '#000000', '81.37.169.130', ' Enviado a las 22:14', 'Ludo', 1102886040);
INSERT INTO `mensajes` VALUES (834, -1, 'We...b...mas...<br>te....r.....', '', '#000000', '81.37.169.130', ' Enviado a las 22:14', 'Ludo', 1102886057);
INSERT INTO `mensajes` VALUES (835, 1, ':P', '', '#800000', '212.159.30.169', ' Enviado a las 22:14', '', 1102886098);
INSERT INTO `mensajes` VALUES (836, 2, 'xDD NaZ!', '', '#800000', '82.223.12.131', ' Enviado a las 22:16', '', 1102886164);
INSERT INTO `mensajes` VALUES (837, -1, 'Quien hizo la plantilla de Navidad', '', '#000000', '81.37.169.130', ' Enviado a las 22:16', 'Ludo', 1102886167);
INSERT INTO `mensajes` VALUES (838, -1, 'Est&aacute; muy currada', '', '#000000', '81.37.169.130', ' Enviado a las 22:16', 'Ludo', 1102886177);
INSERT INTO `mensajes` VALUES (839, -1, 'Nass Rott', '', '#000000', '81.37.169.130', ' Enviado a las 22:16', 'Ludo', 1102886216);
INSERT INTO `mensajes` VALUES (840, 2, 'Un dise&ntilde;ador', '', '#800000', '82.223.12.131', ' Enviado a las 22:25', '', 1102886749);
INSERT INTO `mensajes` VALUES (841, -1, 'Wolas RoTT ^^', '', '#000000', '200.77.129.125', ' Enviado a las 22:31', 'ddryeyi', 1102887060);
INSERT INTO `mensajes` VALUES (842, -1, 'rott ahora quien ta haciendo KC serrico o tu?', '', '#000000', '81.37.169.130', ' Enviado a las 22:33', 'Santiago', 1102887194);
INSERT INTO `mensajes` VALUES (843, -1, 'RoTT necesito habblar contigo', '', '#000000', '200.77.129.125', ' Enviado a las 22:41', 'ddryeyi', 1102887690);
INSERT INTO `mensajes` VALUES (844, 92, 'Buenas', '', '#FA6105', '217.125.123.245', ' Enviado a las 22:54', '', 1102888455);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `privados`
-- 

CREATE TABLE `privados` (
  `id` int(11) NOT NULL auto_increment,
  `autor` int(11) NOT NULL default '0',
  `receptor` int(11) NOT NULL default '0',
  `asunto` varchar(255) NOT NULL default '',
  `texto` text NOT NULL,
  `fecha` varchar(255) NOT NULL default '',
  `leido` tinyint(4) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `privados`
-- 

INSERT INTO `privados` VALUES (1, 92, 94, 'Soy marc!', 'Naz break, agreggame tu al msn mio: marc91@terra.es\r\n\r\nMoD marc.', '05.12.04, 13:30:10', 1);
INSERT INTO `privados` VALUES (2, 94, 92, 'RE: Soy marc!', 'ok', '05.12.04, 14:35:32', 1);
INSERT INTO `privados` VALUES (3, 107, 1, 'Buenas noches xD', 'Ma&ntilde;an nos vemos fea soy ek0 xD\r\npff sdn las 4 m,e fumo un piti y a las 8:30 me despiertan y hoy e dormido 3 horas xD :(\r\ndww MoOoooGLie!\r\nHappy meal', '08.12.04, 19:03:13', 1);
INSERT INTO `privados` VALUES (4, 1, 107, 'RE: Buenas noches xD', 'Ok buenas Noches xDDDDD obeja rapada y dentro de poco me deveras mi happymeal &gt;_&lt;', '09.12.04, 23:50:12', 1);
INSERT INTO `privados` VALUES (5, 118, 94, 'Simon en el mc es Bpd', 'Cuidado con el keko simon= BPD, se cambia de nick, asi que si uno tiene ip m&uacute;ltiple es el', '10.12.04, 13:32:00', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `productos`
-- 

CREATE TABLE `productos` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(255) NOT NULL default '',
  `precio` varchar(255) NOT NULL default '',
  `imagen` varchar(255) NOT NULL default '',
  `categoria` int(11) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `productos`
-- 

INSERT INTO `productos` VALUES (1, 'Careto', '1', 'http://www.info-keko.com/mcc/catalogo/Especiales/careto.gif', 13);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `smilies`
-- 

CREATE TABLE `smilies` (
  `id` int(11) NOT NULL auto_increment,
  `codigo` varchar(255) NOT NULL default '',
  `imagen` varchar(255) NOT NULL default '',
  `mostrar` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `smilies`
-- 

INSERT INTO `smilies` VALUES (8, 'modrubi', 'http://www.info-keko.com/mcc/img/modrubi.gif', '');
INSERT INTO `smilies` VALUES (7, 'moszafiro', 'http://www.info-keko.com/mcc/img/modzafiro.gif', '');
INSERT INTO `smilies` VALUES (5, 'modbronce', 'http://www.info-keko.com/mcc/img/modbronze.gif', '');
INSERT INTO `smilies` VALUES (9, 'modplatino', 'http://www.info-keko.com/mcc/img/modplatino.gif', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `nick` varchar(255) NOT NULL default '',
  `rol` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default '',
  `mensajes` int(11) NOT NULL default '0',
  `fecha_registro` varchar(255) NOT NULL default '',
  `censuras` int(11) NOT NULL default '0',
  `email` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) TYPE=MyISAM AUTO_INCREMENT=121 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'Demo', 'Owner', 'fe01ce2a7fbac8fafaed7c982a04e229', 0, '01.10.04, 00:10:12', 0, 'demo@tudominio.com');
INSERT INTO `usuarios` VALUES (2, 'Demo2', 'Owner', 'fe01ce2a7fbac8fafaed7c982a04e229', 0, '01.09.04, 19:16:10', 0, 'demo@tudominio.com');

        