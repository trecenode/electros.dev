<?

session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("language/lang-".$langactual.".php");

// verificamos que no entra directamente en la pagina
if ($_SERVER['HTTP_REFERER'] == "") {
   header("Location: ftag.php");
   exit;
}

if (isset($_SESSION['nnick'])) {
	if (!esAdmin($_SESSION['nnick'])) {
		die(_NOACCESS);
		exit;
	}
} else {		
	die(_NOACCESS);
	exit;
	}
	
?>
