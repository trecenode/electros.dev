<? include("acceder.php"); ?>
<?

$query = "UPDATE `privados` SET leido = '1' WHERE id = '".$_GET['id']."'";
@mysql_query($query);

?>
<table border=0 height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `privados`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<font class=\"Texto\">No hay noticias<br></font><a href=\"panel.php?mostrar=borrarnoticia&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['noticia'])) {
  echo "<font class=\"Texto\">No has seleccionado ninguna noticia<br></font><a href=\"panel.php?mostrar=borrarnoticia&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$noticia = $_POST['noticia'];
	$query = "SELECT * FROM `privados`";
	$resp = @mysql_query($query);
    while ($news = @mysql_fetch_array($resp)) {	  
      if ($noticia[$news['id']] == "on") {
	   		$query2 = "DELETE FROM `boletin` WHERE id = '".$news['id']."'";
			@mysql_query($query2);
		}
    }

	echo "Noticias borradas<br><a href=\"panel.php?mostrar=borrarnoticia&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
$query = "SELECT * FROM `privados`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
          echo "<font class=\"Texto\">No hay noticias<br></font><a href=\"panel.php?mostrar=borrarnoticia&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `privados`";
			@mysql_query($query);
	       echo "Todas las noticias han sido borradas<br><a href=\"panel.php?mostrar=borrarnoticia&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else {
  
?>
<table border="0" cellpadding="0" cellspacing="0" height="75%" width="100%">
<form name="form" method="post" action="panel.php?mostrar=borrarnoticia&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center" valign="top"><br><font color="#cc0000">Mensaje Privados</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center" valign="top">
<a href="panel.php?mostrar=enviarprivado&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">[Nuevo]</a><br><br>
<?
$query = "SELECT * FROM `privados` WHERE receptor = '".$_SESSION['id']."' AND id = '".$_GET['id']."'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table border=\"0\" width=100%>";
$n = 0;
$noticia = @mysql_fetch_array($resp);
$query2 = "SELECT * FROM `usuarios` WHERE id = '".$noticia['autor']."'";
$resp2 = @mysql_query($query2);
$usuario = @mysql_fetch_array($resp2);
$nick = $usuario['nick'];
   echo "<tr><td class=\"Texto\"bgcolor=#6699cc><b>".$noticia['asunto']."</b></td></tr><tr><td class=\"Texto\" bgcolor=#e0e0e0>Enviado por: ".$nick."</td></tr><tr><td class=\"Texto\" bgcolor=#e0e0e0>".$noticia['texto']."</td></tr><tr><td class=\"Texto\" bgcolor=#e0e0e0>".$noticia['fecha']."</td></tr>";
   $n ++;
echo "</table>";
if (!eregi("RE: ", $noticia['asunto']))
	$asunto = "RE: ".$noticia['asunto'];
else
	$asunto = $noticia['asunto'];	
$receptor = $noticia['autor'];
}
?>  
<a href="panel.php?mostrar=enviarprivado&asunto=<?=$asunto; ?>&receptor=<?=$receptor; ?>&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">[Responder]</a>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?mostrar=verprivados&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
