<?  

if (isset($_POST['enviarregistro'])) {
	$nick = htmlentities(trim(stripSlashes($_POST['nicknuevo'])));
	$nick = str_replace(" ","",$nick);
	$clave = trim(stripSlashes($_POST['clavenuevo']));
	$clave = str_replace(" ","",$clave);
	$email = htmlentities(trim(stripSlashes($_POST['email'])));
	$email = str_replace(" ","",$email);
	
	echo "<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\" bgcolor=\"#eeeeee\" ";
	echo "height=\"70%\"><tr><td class=\"Texto\" align=\"center\">";   
  if ($nick != "" && $clave != "" && $email != "") {
    if (!yaExiste($nick)) {
      guardar($nick, $clave, $email);
      echo _REGISTERED;
      echo "<div align=\"left\"><br><b>&#187;</b>"._NEWNICK;
	  echo " <font color=\"cc0000\">$nick</font>";
      echo "<br><b>&#187;</b>"._NEWPASS;
	  echo " <font color=\"cc0000\">$clave</font></div>";
	  echo "<br><a href=\"javascript:history.back(1)\" class=\"EnlaceMenu\">"._RETURN."</a>";
    } else {
		echo "<font color=\"#ff0000\">"._ERRORNICK."</font>";
		echo "<br><a href=\"javascript:history.back(1)\" class=\"EnlaceMenu\">"._RETURN."</a>";
      }   
	} else {
      if ($nick == "")
        echo "<font color=#ff0000>"._NONICK."<br></font>";
      if ($clave == "")
        echo "<font color=#ff0000>"._NOPASS."<br></font>";  
	  if ($email == "")
        echo "<font color=#ff0000>El email est� vac�o<br></font>"; 
      echo "<font class=\"Texto\">";
	  echo "<a href=\"javascript:history.back(1)\" class=\"EnlaceMenu\">"._RETURN."</a></font>";
    }
	echo "</td></tr></table>";	
} else
	header("Location: ftag.php");

?>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->