<?
session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("language/lang-".$langactual.".php");
?>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Description" content="Minichat v<?=$version; ?>">
<meta name="Author" content="Rott">
<meta name="Generator" content="Minichat v<?=$version; ?>">
   <title>Minichat v<?=$version; ?></title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
<style type="text/css">
<!--
.CampoTexto { 
   font-size: 10px; 
   font-family: verdana; 
   border: 1px solid <? echo $bordecampo; ?>; 
   background: <? echo $fondocampo; ?>;

}
.Texto {
   font-family: Verdana; 
   font-size: 10px; 
   font-weight: normal;
   color: <?=$colortexto; ?>;
}
-->
</style>
</head>
<body>
<div align="center">
<form method="post" action="logear.php?<? echo session_name()."=".session_id() ?>" name="formAdmin"> 
<table border="0" cellpadding="2" cellspacing="2" bgcolor="#cccccc" style="border: 1px solid black"> 
<tr> 
<td align="center" valign="middle">
<table border="0" cellpadding="2" cellspacing="2"> 
<tr>
<td class="Texto" colspan="2" align="center"><?=_PANELIDEN; ?></td>
</tr>
<td class="Texto"><?=_LOGIN; ?></td> 
<td><input type="text" name="login" size="8" class="Boton" maxlength="<?php echo $maxNick; ?>"></td> 
</tr> 
<tr> 
<td class="Texto"><?=_PASSWORD; ?></td> 
<td><input type="password" name="password" size="8" class="Boton" maxlength="10"></td> 
</tr> 
<tr> 
<td colspan="2" align="center"> 
<input type = "submit" value = "<?=_ACCEPT; ?>" class="Boton" name="entrar"> 
</td> 
</tr>
<tr><td align="center" colspan="2">
<a href="ftag.php?mostrar=tag&?<? echo session_name()."=".session_id(); ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr> 
</table>
</td>
</tr> 
</form>
</table>
</div>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->