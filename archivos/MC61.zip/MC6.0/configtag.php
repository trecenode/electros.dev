<? 
include("conectar.php");

$query = "SELECT * FROM `configuracion`"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

while ($valor = @mysql_fetch_array($resp)) {
	  if ($valor['campo'] == "maximo")
	  	 $maximo = $valor['valor']; 
		 
	  if ($valor['campo'] == "numMensajes")	 		 
 	  	 $numMensajes = $valor['valor']; 
	  
	  if ($valor['campo'] == "maxNick")
 	  	 $maxNick = $valor['valor']; 
	  
	  if ($valor['campo'] == "maxMsg")
 	  	 $maxMsg = $valor['valor']; 
	  
	  if ($valor['campo'] == "activarUrl")
 	  	 $activarUrl = $valor['valor']; 
	  
	  if ($valor['campo'] == "activarReg")
 	  	 $activarReg = $valor['valor'];
	  
	  if ($valor['campo'] == "activarIp")
 	  	 $activarIp = $valor['valor'];
	  
	  if ($valor['campo'] == "activarHora")
 	  	 $activarHora = $valor['valor'];
	  
	  if ($valor['campo'] == "activarLogo")
 	  	 $activarLogo = $valor['valor'];
	  
	  if ($valor['campo'] == "activarBBcode")
 	  	 $activarBBcode = $valor['valor'];
	  
	  if ($valor['campo'] == "langactual")
 	  	 $langactual = $valor['valor']; 
	  
	  if ($valor['campo'] == "activarTiempo")
 	  	 $activarTiempo = $valor['valor'];
	  
	  if ($valor['campo'] == "tiempo")
 	  	 $tiempo = $valor['valor'];

	  if ($valor['campo'] == "activarAutomensaje")
 	  	 $activarAutomensaje = $valor['valor'];
	  
	  if ($valor['campo'] == "tAutomensaje")
 	  	 $tAutomensaje = $valor['valor'];		 
	  
	  if ($valor['campo'] == "esperar")
 	  	 $esperar = $valor['valor']; 	
		 
	  if ($valor['campo'] == "activarMant")
 	  	 $activarMant = $valor['valor'];		 
		 
	  if ($valor['campo'] == "catalogo")
 	  	 $catalogo = $valor['valor'];			 
} 

$version = "6.0";
  
?>