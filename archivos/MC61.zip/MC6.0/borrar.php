<?

session_start();
session_cache_limiter('nocache,private');

  // Cogemos la IP
  if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  else if ($_SERVER['HTTP_VIA'] != "") 
         $ip = $_SERVER['HTTP_VIA'];   
  else if ($_SERVER['REMOTE_ADDR'] != "") 
         $ip = $_SERVER['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 
		 
include("conectar.php");
$query = "DELETE FROM `alertas` WHERE ip = '".$ip."'";
@mysql_query($query);
header("Location: ftag.php?".session_name()."=".session_id());
exit;

?>
