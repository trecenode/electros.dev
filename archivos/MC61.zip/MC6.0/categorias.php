<? include("acceder.php"); ?>
<table border="0" height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['enviar'])) {
  if ($_POST['nombre'] != "" && $_POST['descripcion'] != "" && $_POST['imagen'] != "") {
    $id = "";
    $query = "INSERT INTO `categorias` (id, nombre, imagen, descripcion) VALUES ('".$id."', '".htmlentities($_POST['nombre'])."', '".htmlentities($_POST['descripcion'])."', '".$_POST['imagen']."')";
	@mysql_query($query);
		
	echo "<div align=center><font color=#cc0000>Categor�a a�adida</font><br><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></div>";
  } else 
    echo "<font color=#cc0000>Has dejado alg�n campo vac�o</font><br></font><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `categorias`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<font color=#cc0000>No hay categor�as<br></font><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['ip'])) {
  echo "<font color=#cc0000>No has seleccionado ninguna categor�a<br></font><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$ip = $_POST['ip'];
	$query = "SELECT * FROM `categorias`";
	$resp = @mysql_query($query);
    while ($ban = @mysql_fetch_array($resp)) {	  
      if ($ip[$ban['id']] == "on") {
	   		$query2 = "DELETE FROM `categorias` WHERE id = '".$ban['id']."'";
			@mysql_query($query2);
		}
    }

	echo "<font color=#cc0000>Categor�a borrada</font><br><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
$query = "SELECT * FROM `categorias`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
          echo "<font color=#cc0000>No hay categor�as<br></font><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `categorias`";
			@mysql_query($query);
	       echo "Todas las categor�as han sido borradas<br><a href=\"panel.php?mostrar=categorias&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else {
  
?>
<table border="0" cellpadding="2" cellspacing="0">
<form name="form" method="post" action="panel.php?mostrar=categorias&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Control Categor�as</font></td>
</tr>
<tr><td class="Texto" align="center"></td></tr>
<tr>
<td class="Texto" align="center">
<table border="0" cellpadding="2" cellspacing="0">
<tr>
<td class="Texto" align="right">Nombre:</td><td><input type="text" name="imagen" size="20" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="right">Imagen (url):</td><td><input type="text" name="nombre" size="20" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="right" valign="top">Descripci�n:</td><td><textarea name="descripcion" cols="30" rows="4" value="" class="Boton"></textarea></td>
</tr>
</table>
</td>
</tr>
<tr>
<td class="Texto" align="center"></td></tr>
<tr>
<td class="Texto" align="center"><input name="enviar" type="submit" value="A�adir" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="center">&nbsp;</td></tr>
<tr>
<td class="Texto" align="center"><font color="#cc0000">Categor�as</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center">
<?
$query = "SELECT * FROM `categorias`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table>";
$n = 0;
while ($ban = @mysql_fetch_array($resp)) {
   echo "<tr><td class=\"Texto\"><input type=checkbox name=ip[".$ban['id']."]>".$ban['nombre']."</td></tr>";
   $n ++;
   }
echo "</table>";
}
?>  
</td>
</tr>
<tr>
<td align="center">
<table cellpadding="1" cellspacing="0">
<tr>
<td>
<input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
