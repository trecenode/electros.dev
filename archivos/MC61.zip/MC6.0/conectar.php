<?

$host = "localhost";
$user = ""; 
$pass = ""; 
$dbname = ""; 
$conecta = mysql_connect($host, $user, $pass) or die("No se ha podido conectar con el servidor MySQL. Int�ntalo mas tarde.");
mysql_select_db($dbname, $conecta);
/*
$host = "localhost";
$user = "root"; 
$pass = ""; 
$dbname = "mc"; 
$conecta = mysql_connect($host, $user, $pass) or die("No se ha podido conectar con el servidor MySQL. Int�ntalo mas tarde.");
mysql_select_db($dbname, $conecta);
*/
?>