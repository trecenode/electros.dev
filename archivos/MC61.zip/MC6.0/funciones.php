<?

	function estaBaneado($ip) {
		$query = "SELECT * FROM `baneos` WHERE ip = '$ip'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp); 
		
		if ($rows) {
			$ban = @mysql_fetch_array($resp);
			if ($ban['desbanear'] == 0)
				return true;
			else {
				$actual = time();
				if ($ban['desbanear'] <= $actual) {
					$query = "DELETE FROM `baneos` WHERE ip = '$ip'"; 
					@mysql_query($query);
					return false;
				} else
					return true;
			}	
		} else
			return false;	
	}
	
 	function actualizarIps($esperar) {
		$fecha2 = microtime();
	  	$fecha2 = explode(" ", $fecha2);
	  	$fecha2 = $fecha2[1];
			  
		$query = "SELECT * FROM `flood`"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp); 

		if ($rows)
			while ($flood = @mysql_fetch_array($resp)) {
				$difseg = $fecha2 - $flood['tiempo'];
		    	if ($difseg >= $esperar)
					$query2 = "DELETE FROM `flood` WHERE ip = '".$flood['ip']."'";
				  	@mysql_query($query2);
			}
			  		  
	}
	
	function actualizarIp($fecha, $ip) {
		$query = "SELECT * FROM `flood` WHERE ip = '$ip'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);
		
		if (!$rows)
			$query = "INSERT INTO `flood` (ip, tiempo) values ('".$ip."', '".$fecha."')";
		else
			$query = "UPDATE `flood` set tiempo = '".$fecha."' WHERE ip = '".$ip."'";
		
		@mysql_query($query);

	}
	
	function validarIp($ip) {
			 if (!is_string($ip))
			  return false;

			 $ip_long = ip2long($ip);
			 $ip_reverse = long2ip($ip_long);
			 if ($ip == $ip_reverse)
			   return true;
			 else
			   return false;
    }	

    function yaExiste($login) {
		$query = "SELECT * FROM `usuarios` WHERE nick = '$login'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp); 
		
		if (!$rows)
			return false;
		else
			return true;
    } 	
	
    // Verifica que existe un usuario y que su password es el indicado
    function comprobarNick($login, $pas) {
		global $activarReg;
		
	    $pas = md5($pas);
		$query = "SELECT * FROM `usuarios` WHERE nick = '".$login."'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp); 
		
		if ($rows) {
			$usuario = @mysql_fetch_array($resp);
			if ($activarReg == "on" && $usuario['rol'] == "0") {	
				if ($usuario['pass'] == $pas)
					return $usuario['nick'];
				else
					return "-1";
			}
		
			if ($usuario['rol'] == "Owner" || $usuario['rol'] == "Moderador" || $usuario['rol'] == "Rubi" || $usuario['rol'] == "Zafiro" || $usuario['rol'] == "Bronze") {
				if ($usuario['pass'] == $pas)
					return $usuario['nick'];
				else
					return "-1";
			}
			
		}
			
        return "0";
    }
	
    function guardar($user, $pas, $email) {
		$id = "";
		$query = "INSERT INTO `usuarios` (id, nick, rol, pass, fecha_registro, censuras, email) VALUES ('".$id."', '".$user."', '0', '".md5($pas)."', '".date("d.m.y, H:i:s")."', 0, '".$email."')"; 
		@mysql_query($query);
    }	
	
	// Verifica que existe un usuario y un admin 
	function existeUser($login, $rol, $id) { 
		 global $activarReg; 
		 
		$query = "SELECT * FROM `usuarios` WHERE nick = '".strtolower($login)."'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);
		if ($rows)
			$user = @mysql_fetch_array($resp);

		 if ($activarReg == "on") { 
		 	if ($rows && $user['rol'] == "0") 
				return true; 
		 } 

		 if ($rol == "Owner" && $rows && $user['rol'] == "Owner" && $user['id'] != $id)	
		 	return true;

		 if ($rol == "Zafiro" && $rows && $user['rol'] == "Zafiro" && $user['id'] != $id)  
		 	return true; 
		
		if ($rol == "Moderador" && $rows && $user['rol'] == "Moderador" && $user['id'] != $id)  
		 	return true; 	
		
		if ($rol == "Rubi" && $rows && $user['rol'] == "Rubi" && $user['id'] != $id)  
		 	return true; 	
		
		if ($rol == "Bronze" && $rows && $user['rol'] == "Bronze" && $user['id'] != $id)  
		 	return true; 	

		 return false; 
	} 	
	
	// Busca el numero identificativo del admin 
	function idenAdmin($login) { 
		$query = "SELECT * FROM `usuarios` WHERE nick = '$login'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);  
		$usuario = @mysql_fetch_array($resp);
		
		if (!$rows)
		   return -1;	
		else 
		   return $usuario['rol']; 
	} 	
	
	// Busca el numero identificativo del admin 
	function idAdmin($login) { 
		$query = "SELECT * FROM `usuarios` WHERE nick = '$login'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);  
		$usuario = @mysql_fetch_array($resp);
		
		if (!$rows)
		   return -1;	
		else 
		   return $usuario['id']; 
	} 	
	
	// Verifica si es uno de los administradores
	function esAdmin($login) {
		$query = "SELECT * FROM `usuarios` WHERE nick = '$login'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);  
		$usuario = @mysql_fetch_array($resp);
		
		if ($usuario['rol'] == "Owner" || $usuario['rol'] == "Moderador" || $usuario['rol'] == "Zafiro" || $usuario['rol'] == "Rubi" || $usuario['rol'] == "Bronze")
			return true;
		else
			return false;	
	}	
	
	// Verifica si es el SUPERadministrador
	function esSuperAdmin($login) {
		$query = "SELECT * FROM `usuarios` WHERE nick = '$login'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);  
		$usuario = @mysql_fetch_array($resp);
		
		if ($usuario['rol'] == "Owner")
			return true;
		else
			return false;	 
	}

    // Funci�n para reemplazar los c�digos por su respectivo smilie
    function reemplazarSmilies($palabra) {
		$query = "SELECT * FROM `smilies`";
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);
		if ($rows) {
			while ($placa = @mysql_fetch_array($resp))
			$palabra = str_replace($placa['codigo'] ,"<img src=".$placa['imagen']." align=middle>", $palabra);
		}
	
	    return $palabra;
    }
	
	function bbcode($texto) {
        $texto = eregi_replace("\\[u\\]([^\\[]*)\\[/u\\]","<u>\\1</u>", $texto);

        $texto = eregi_replace("\\[i\\]([^\\[]*)\\[/i\\]","<em>\\1</em>", $texto);

        $texto = eregi_replace("\\[b\\]([^\\[]*)\\[/b\\]","<strong>\\1</strong>", $texto);

		return $texto;
	}
	
	function arrayCensura() {
        $query = "SELECT * from censuras";
		$resp = @mysql_query($query);
		$palabras = array();
		$i = 0;
		while ($palabras[$i] = @mysql_fetch_array($resp)) {
			$palabras[$i] = $palabras[$i]['palabra'];
			$i ++;
		}

		return $palabras;
	}

	function arrayCaracteres() {
        $query = "SELECT * from caracteres";
		$resp = @mysql_query($query);
		$palabras = array();
		$i = 0;
		while ($palabras[$i] = @mysql_fetch_array($resp)) {
			$palabras[$i] = $palabras[$i]['caracter'];
			$i ++;
		}

		return $palabras;
	}	
	
    function guardarMensaje($login, $texto, $web, $ipLogin) {
        global $maximo, $existeNick, $activarIp, $activarHora, $maxMsg, $activarBBcode, $mensajes,
		       $maxNick, $colorowners, $colormoderador, $colorvip, $coloranonimo, $colorrubi, $colorzafiro,
			   $colorbronze, $activarAutomensaje, $tAutomensaje;
	    
		if (strlen($login) > $maxNick) 
		  return _NEXCEEDSLIMITCHARS;
		if (strlen($texto) > $maxMsg)
		  return _MEXCEEDSLIMITCHARS;
		
		$login = htmlentities($login);
        // No permitir etiquetas HTML, ni espacios en blanco en el nick
        $login = reemplazarSmilies($login);
		$web = htmlentities($web);

        // Aqu� vamos a procesar el mensaje palabra por palabra para que ninguna 
		// sea demasiado larga y destroce el dise�o
        // Dividimos el mensaje por palabras
        $palabrasm = explode(" ",$texto);
        // Contamos cuantas palabras son 
        $numpalabras = count($palabrasm); 

        // Bucle "for" para recorrer las palabras y dividirlas si hay alguna larga
        for ($i = 0; $i < $numpalabras; $i++) {
           // Comparamos la longitud de las palabras con el m�ximo
           if (strlen($palabrasm[$i]) > $maximo) {
             // Dividimos las palabras que excedan el m�ximo  
             $palabrasm[$i] = wordwrap($palabrasm[$i], $maximo, "<br>", 1);
			 $palabrasm[$i] = htmlentities($palabrasm[$i]);
			 $palabrasm[$i] = str_replace("&lt;","<", $palabrasm[$i]);
			 $palabrasm[$i] = str_replace("&gt;",">", $palabrasm[$i]);
           } else
		   		$palabrasm[$i] = htmlentities($palabrasm[$i]);
           $palabrasm[$i] = reemplazarSmilies($palabrasm[$i]);
        } // Fin bucle "for"

		$palabras = arrayCensura();
		if ($palabras[0] != "") {
		for ($i = 0; $i < sizeof($palabrasm); $i ++)
		   for ($j = 0; $j < (sizeof($palabras) - 1); $j ++) {
		      if (eregi($palabras[$j], $palabrasm[$i])) {
			    $palabrasm[$i] = "****";  
				if (isset($_SESSION['nnick'])) {
					$query = "UPDATE `usuarios` SET censuras = censuras + 1 WHERE nick ='".$_SESSION['nnick']."'";
					@mysql_query($query);
					}
				}
			}
		}
		
		$caracteres = arrayCaracteres();
		if ($caracteres[0] != "") {
		for ($i = 0; $i < sizeof($palabrasm); $i ++)
		   for ($j = 0; $j < (sizeof($caracteres) - 1); $j ++) {
		      if (eregi($caracteres[$j], $palabrasm[$i])) {
			    $palabrasm[$i] = "";  
				if (isset($_SESSION['nnick'])) {
					$query = "UPDATE `usuarios` SET censuras = censuras + 1 WHERE nick ='".$_SESSION['nnick']."'";
					@mysql_query($query);
					}
				}
			}
		}
				
        // Unimos las palabras mediante espacios vac�os para crear el mensaje
        $texto = implode(" ",$palabrasm);

      	if ($texto == "")
	  		return _NOMESSAGE;
		  
		if ($palabras[0] != "") {  
		for ($i = 0; $i < (sizeof($palabras) - 1); $i ++) {
		   if (eregi($palabras[$i],$login))	{
			 $login = "****";
			 if (isset($_SESSION['nnick'])) {
					$query = "UPDATE `usuarios` SET censuras = censuras + 1 WHERE id ='".$_SESSION['nnick']."'";
					@mysql_query($query);
					}
			 }
		}		
		}

		if ($caracteres[0] != "") {
		for ($i = 0; $i < (sizeof($caracteres) - 1); $i ++) {
		   if (eregi($caracteres[$i], $login)) {	
			 $login = "";
			 if (isset($_SESSION['nnick'])) {
					$query = "UPDATE `usuarios` SET censuras = censuras + 1 WHERE id ='".$_SESSION['nnick']."'";
					@mysql_query($query);
					}
			 }
		}		
		}	
		
      	if ($login == "")
	  		return _NONICK;
		
		if ($activarBBcode == "on")
		  $texto = bbcode($texto);		

        // Fecha en la que se envi� el mensaje
		$fecha .= " "._AT." ";
		
	    $fecha .= Date("H:i");
		  
        if ($existeNick == "true") {
			$rol = idenAdmin($login);
			if ($rol == "Owner")
            	$color = $colorowners;
			else if ($rol == "Moderador")
					$color = $colormoderador;	
			else if ($rol == "Zafiro")
					$color = $colorzafiro;	
			else if ($rol == "Bronze")
					$color = $colorbronze;	
			else if ($rol == "Rubi")
					$color = $colorrubi;	
			else if ($rol == "0")
					$color = $colorvip;		
				
			$query = "SELECT * FROM `usuarios` WHERE nick = '".$login."'"; 
			$resp = @mysql_query($query);
			$usuario = @mysql_fetch_array($resp);
			$user_id = $usuario['id'];	
			$login = "";
			$query = "UPDATE `usuarios` SET mensajes = mensajes + 1 WHERE id ='" .$user_id. "'";
			@mysql_query($query);
        } else {
            $color = $coloranonimo;  // anonimo
			$user_id = -1;
			}
			
		$query = "UPDATE `configuracion` SET valor = valor + 1 WHERE campo = 'total_mensajes'";
		@mysql_query($query);
				
		$id = "";
		$tiempo = microtime();
		$tiempo = explode(" ", $tiempo);
		$tiempo = $tiempo[1];
		$query = "INSERT INTO mensajes (id, usuario, texto, web, color, ip, fecha, nombre, tiempo) VALUES ('".$id."', '".$user_id."', '".$texto."', '".$web."', '".$color."', '".$ipLogin."', '".$fecha."', '".$login."', '".$tiempo."')";
		@mysql_query($query);
		
		if ($activarAutomensaje == "on") {
			$query = "SELECT * FROM `automensaje` WHERE id = '1'"; 
			$resp = @mysql_query($query);
			$automensaje = @mysql_fetch_array($resp);
			$fecha1 = $automensaje['ultimo'];
			$fecha2 = microtime();
			$fecha2 = explode(" ", $fecha2);
			$fecha2 = $fecha2[1];
			if (($fecha2 - $fecha1) >= $tAutomensaje) { 
				$id = "";
				$fecha .= " "._AT." ";
	    		$fecha .= Date("H:i");
				$query = "INSERT INTO mensajes (id, usuario, texto, web, color, ip, fecha, nombre, tiempo) VALUES ('".$id."', '-1', '".$automensaje['texto']."', '', '#cc0000', '', '".$fecha."', 'AutoMensaje', '".$tiempo."')";
				@mysql_query($query);
				$query = "UPDATE `automensaje` set ultimo = '".$fecha2."' WHERE id = '1'";
				@mysql_query($query);
			}
		
		}
		
		return "";
    }

?>
