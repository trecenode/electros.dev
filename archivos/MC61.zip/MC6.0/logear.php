<?

session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("conectar.php");
include("funciones.php");
include("language/lang-".$langactual.".php");

if (isset($_POST['entrar'])) { 
	$login = stripslashes(str_replace(" ","",$_POST['login'])); 
	$password = stripslashes(str_replace(" ","",$_POST['password'])); 
	
	  if (esAdmin($login)) {
		$nick = comprobarNick($login, $password);
	    if ($nick != "-1" && $nick != "0") {
	      $_SESSION['nnick'] = $nick;
          if (!isset($_SESSION['iden'])) {
		  	 $iden = idenAdmin($_SESSION['nnick']); 
   			 $_SESSION['iden'] = $iden;
			 $id = idAdmin($_SESSION['nnick']);
			 $_SESSION['id'] = $id;
 			  }
		  header("Location: panel.php?".session_name()."=".session_id());
	      exit;	
		} else {
		  $error = _INCORRECTPASS;
	      header("Location: ftag.php?mostrar=error&error=".$error."&".session_name()."=".session_id());
	      exit;			
		}
	  } else {
	  	$error = _NOACCESS;
	    header("Location: ftag.php?mostrar=error&error=".$error."&".session_name()."=".session_id());
	    exit;	
	  }
}

?>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
