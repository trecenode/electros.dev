<? include("acceder.php"); ?>
<table border="0" cellpadding="0" cellspacing="1" height="100%" width="80%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<table border="0" cellpadding="1" cellspacing="1" width="80%">
<tr>
<td class="Texto" colspan="2" align="center"><font color="#cc0000">Estad�sticas</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center"></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Total mensajes</td>
<?
$query = "SELECT valor FROM `configuracion` WHERE campo = 'total_mensajes'";
$resp = @mysql_query($query);
$total = @mysql_fetch_array($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$total['valor']; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Managers</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = 'Owner'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Moderadores</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = 'Moderador'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Rubis</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = 'Rubi'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Zafiros</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = 'Zafiro'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Bronzes</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = 'Bronze'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Usuarios registrados</td>
<?
$query = "SELECT id FROM `usuarios` WHERE rol = '0'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Mensajes us. registrados</td>
<?
$query = "SELECT mensajes FROM `usuarios`";
$resp = @mysql_query($query);
$total = 0;
while ($user = @mysql_fetch_array($resp)) {
$total += $user['mensajes'];
}
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$total; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Usuario m�s activo</td>
<?
$query = "SELECT nick, mensajes FROM `usuarios` order by mensajes desc limit 1";
$resp = @mysql_query($query);
$user = @mysql_fetch_array($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><b><?=$user['nick']; ?></b>: <?=$user['mensajes']; ?> msg</td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Alertas pendientes</td>
<?
$query = "SELECT id FROM `alertas`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Baneos actuales</td>
<?
$query = "SELECT id FROM `baneos`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td class="Texto" width="50%" bgcolor="#6699cc" style="color: white;">Palabras que has censurado</td>
<?
$query = "SELECT id FROM `censuras`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
?>
<td align="right" width="50%" class="Texto" style="border: 1px solid #6699cc"><?=$rows; ?></td>
</tr>
<tr>
<td colspan="2" align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr>
</table>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->