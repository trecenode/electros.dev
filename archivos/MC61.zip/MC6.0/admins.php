<? include("acceder.php"); ?>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<table border="0" height="75%" width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<table border="0" cellpadding="0" cellspacing="0">
<form name="form" method="post" action="panel.php?mostrar=procesaradmins&<? echo session_name()."=".session_id() ?>">
<input type="hidden" name="tipo" value="<?=$_GET['admin']; ?>">
<tr>
<td class="Texto" align="center" colspan="2"><font color="#cc0000"><?=_CADMINS; ?> :: <?=$_GET['admin']."s"; ?></font></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"><br></td>
</tr>
<? if ($_GET['admin'] != "Owner") { ?>
<tr>
<td class="Texto" align="right"><?=_NICKNAME; ?>: </td>
<td>
<input type="text" name="newadmin" size="8" value="" class="Boton" maxlength="<?php echo $maxNick; ?>"></td>
</tr>
<tr>
<td class="Texto" align="right">Email: </td>
<td>
<input type="text" name="emailadmin" size="18" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="right"><?=_PASSWORD; ?>: </td>
<td><input type="password" name="newpass" size="8" value="" class="Boton" maxlength="10"></td>
</tr>
<tr>
<?
if ($_GET['admin'] == "Moderador")
	$admin = "Rubis";
	else if ($_GET['admin'] == "Rubi")
		$admin = "Zafiros";
		else if ($_GET['admin'] == "Zafiro")
			$admin = "Bronzes";
				else if ($_GET['admin'] == "Bronze")
						$admin = "ViPs";
?>
<td class="Texto" align="center" colspan="2"><font color="#cc0000"><br><?=$admin; ?></font></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2">
<? 
if ($_GET['admin'] == "Moderador")
	$rol = "Rubi";
	else if ($_GET['admin'] == "Rubi")
		$rol = "Zafiro";
		else if ($_GET['admin'] == "Zafiro")
			$rol = "Bronze";
				else if ($_GET['admin'] == "Bronze")
						$rol = "0";
						
$query = "SELECT * FROM `usuarios` WHERE rol = '".$rol."'"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
		
if (!$rows)
   echo "<div align=center>"._NONE."</div>"; 
else { 
	 echo "<table>"; 
	 $n = 0;
	 while ($user = mysql_fetch_array($resp)) { 
	 	 $name = $user['nick']; 
		 $m = $n + 1; 
		 echo "<tr><td class=\"Texto\">";
		 echo "<INPUT TYPE=checkbox name=nick[".$user['id']."]>";
		 echo "$m. $name</td></tr>"; 
		 $n ++;
	 } 
	 echo "</table>"; 
} 

?> 
</td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2">
<br><input name="aceptar" type="submit" value="<?=_ACCEPT; ?>" class="Boton"></td>
</tr>
<? } ?>
<tr>
<td class="Texto" align="center" colspan="2">&nbsp;</td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"><font color="#cc0000"><?=$_GET['admin']."s"; ?></font></td>
</tr>
<tr>
<td class="Texto" colspan="2">
<?
					
$query = "SELECT * FROM `usuarios` WHERE rol = '".$_GET['admin']."'"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
		
if (!$rows)
   echo "<div align=center>"._NONE."</div>"; 
else { 
	 echo "<table>"; 
	 $n = 0;
	 while ($user = mysql_fetch_array($resp)) { 
		echo "<tr><td class=\"Texto\">";
		if ($_GET['admin'] != "Owner")
			echo "<INPUT TYPE=checkbox name=nadmins[".$user['id']."]>";
		else	
		echo ($n + 1).". ";
		echo $user['nick']."</td></tr>";
		$n ++;
   	}
	echo "</table>";
}

?> 
</td>
</tr>
<? if ($_GET['admin'] != "Owner") { ?>
<tr>
<td colspan="2" align="center"><br>
<table cellpadding="1" cellspacing="0">
<tr>
<td><input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
<? } ?>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr>
</table>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->