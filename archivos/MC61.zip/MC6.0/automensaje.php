<? include("acceder.php"); ?>
<table border=0 height="75%" width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto">
<?

if (isset($_POST['enviar'])) {
  if ($_POST['texto'] != "") {
	$query = "UPDATE  `automensaje` set texto = '".htmlentities($_POST['texto'])."' WHERE id = '1'";
	@mysql_query($query);
	echo "<div align=center>Auto mensaje actualizado<br><a href=\"panel.php?mostrar=automensaje&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></div>";
  } else 
    echo "<font class=\"Texto\">Has dejado alg�n campo vac�o<br></font><a href=\"panel.php?mostrar=automensaje&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
  
?>
<table border="0" cellpadding="0" cellspacing="0">
<form name="form" method="post" action="panel.php?mostrar=automensaje&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Auto Mensaje</font></td>
</tr>
<tr><td class="Texto" align="center"></td></tr>
<tr>
<td class="Texto" align="center">
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td class="Texto" valign="top">Texto:</td>
</tr>
<tr>
<?
$query = "SELECT * from `automensaje` WHERE id = '1'";
$resp = @mysql_query($query);
$mensaje = @mysql_fetch_array($resp);
?>
<td><textarea name="texto" cols="30" rows="4" class="Boton"><?=$mensaje['texto']; ?></textarea></td>
</tr>
<tr>
<td colspan="2" class="Texto" align="center"><input name="enviar" type="submit" value="Enviar" class="Boton"></td>
</tr>
</table>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
