<table border="0" cellpadding="5" cellspacing="0" width="100%" height="100%" 
style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc">
<tr>
<td align="center" width="50%"><img src="smilies/bien.gif" alt=":bien"></td><td class="Texto">:bien</td>
</tr>
<tr>
<td align="center"><img src="smilies/cool.gif" alt=":cool"></td><td class="Texto">:cool</td>
</tr>
<tr>
<td align="center"><img src="smilies/duda.gif" alt=":duda"></td><td class="Texto">:duda</td>
</tr>
<tr>
<td align="center"><img src="smilies/enojado.gif" alt=":enojo"></td><td class="Texto">:enojo</td>
</tr>
<tr>
<td align="center"><img src="smilies/ginando.gif" alt=";)"></td><td class="Texto">;)</td>
</tr>
<tr>
<td align="center"><img src="smilies/lengua.gif" alt=":P"></td><td class="Texto">:P</td>
</tr>
<tr>
<td align="center">
<img src="smilies/llorando.gif" alt=":llorar"></td><td class="Texto">:llorar</td>
</tr>
<tr>
<td align="center">
<img src="smilies/mal.gif" alt=":mal"></td><td class="Texto">:mal</td>
</tr>
<tr>
<td align="center">
<img src="smilies/ojotes.gif" alt="8)"></td><td class="Texto">8)</td>
</tr>
<tr>
<td align="center">
<img src="smilies/risa.gif" alt=":D"></td><td class="Texto">:D</td>
</tr>
<tr>
<td align="center">
<img src="smilies/sonrisa.gif" alt=":)"></td><td class="Texto">:)</td>
</tr>
<tr>
<td align="center">
<img src="smilies/triste.gif" alt=":("></td><td class="Texto">:(</td>
</tr>
<tr>
<td align="center" class="Texto" colspan="2"><font color="#cc0000"><?=_BBCODE; ?></font></td>
</tr>
<tr>
<td align="center" class="Texto">[b]<?=_TEXT; ?>[/b]</td><td class="Texto" align="center"><?=_BOLD; ?></td>
</tr>
<tr>
<tr>
<td align="center" class="Texto">[u]<?=_TEXT; ?>[/u]</td><td class="Texto" align="center"><?=_UNDERLINE; ?></td>
</tr>
<tr>
<tr>
<td align="center" class="Texto">[i]<?=_TEXT; ?>[/i]</td><td class="Texto" align="center"><?=_ITALIC; ?></td>
</tr>
<tr>
<tr>
<tr>
<td align="center" colspan="2">
<a href="ftag.php?mostrar=tag&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr>
</table>