<? include("acceder.php"); ?>
<table border="0" height=75% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `alerta_mod`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<font color=#cc0000>No hay alertas<br></font><a href=\"panel.php?mostrar=alertasmod&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['noticia'])) {
  echo "<font color=#cc0000>No has seleccionado ninguna alerta<br></font><a href=\"panel.php?mostrar=alertasmod&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$noticia = $_POST['noticia'];
	$query = "SELECT * FROM `alerta_mod`";
	$resp = @mysql_query($query);
    while ($news = @mysql_fetch_array($resp)) {	  
      if ($noticia[$news['id']] == "on") {
	   		$query2 = "DELETE FROM `alerta_mod` WHERE id = '".$news['id']."'";
			@mysql_query($query2);
		}
    }

	echo "<font color=#cc0000>Alertas borradas</font><br><a href=\"panel.php?".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
$query = "SELECT * FROM `alerta_mod`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
          echo "<font color=#cc0000>No hay alertas<br></font><a href=\"panel.php?mostrar=alertasmod&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `alerta_mod`";
			@mysql_query($query);
	       echo "<font color=#cc0000>Todas las alertas han sido borradas</font><br><a href=\"panel.php?mostrar=alertasmod&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else if (isset($_POST['ayuda'])) {
         include("ayuda.php");
	   } else {
  
?>
<table border="0" cellpadding="0" cellspacing="0">
<form name="form" method="post" action="panel.php?mostrar=alertasmod&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Alertas MoD</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center" valign="top">
<?
$query = "SELECT * FROM `alerta_mod` WHERE leido = '0' order by id desc";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
  echo "<div align=center>Las alertas ya est�n siendo atendidas por otros MoDs, si el aviso sigue despu�s de un tiempo ser� porque el MoD ha decidido mantener la alerta para que otro la atienda.</div>";
$nohay = "true";
} else {
echo "<table border=\"0\">";
$n = 0;
while ($noticia = @mysql_fetch_array($resp)) {
if ($noticia['nick'] != "-1") {
	$query2 = "SELECT * FROM `usuarios` WHERE id = '".$noticia['nick']."'";
	$resp2 = @mysql_query($query2);
	$usuario = @mysql_fetch_array($resp2);
	$nick = $usuario['nick'].", ";
}
   echo "<tr><td class=\"Texto\"><input type=checkbox name=noticia[".$noticia['id']."]><b>".$nick." email: ".$noticia['email'].", IP: ".$noticia['ip']."</b></td></tr><tr><td class=\"Texto\">".$noticia['texto']."</td></tr><tr><td class=\"Texto\"><i>Enviada el ".$noticia['fecha']."</i></td></tr><tr><td align=center class=Texto><a href=\"panel.php?mostrar=atender&nick=".$noticia['nick']."&mensaje=".$noticia['texto']."&email=".$noticia['email']."&ip=".$noticia['ip']."&".session_name()."=".session_id()."\" class=EnlaceMenu>[Atender]</a></td></tr>";
   $n ++;
   }
echo "</table>";
}
?>  
</td>
</tr>
<? if ($nohay != "true") { ?>
<tr>
<td align="center"><br>
<table cellpadding="1" cellspacing="0">
<tr>
<td>
<input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
