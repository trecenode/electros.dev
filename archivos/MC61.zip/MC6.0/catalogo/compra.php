<html>
<head>
<title>Cat�logo</title>

<link REL="STYLESHEET" HREF="../style.css" TYPE="text/css">
</head>

<body bgcolor="#F0F0F0">
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="325" valign="top" align="right">
  <table border="0" cellpadding="0" cellspacing="0" width="325">
    <tr>
      <td width="100%"><font size="1" face="Tahoma"><img border="0" src="catalogo-arriba.gif" width="325" height="34"></font></td>
    </tr>
    <tr>
      <td width="100%" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1" bgcolor="#EEEEEE" bordercolor="#000000">
  <div align="center">
    <table border="0" cellpadding="0" cellspacing="0" width="95%">
      <tr>
        <td width="100%"><font face="Tahoma" size="1">Gr�cias por su compra :) </font>
          <table border="0" cellpadding="0" cellspacing="0" width="100%" height="11">
            <tr>
              <td width="100%" height="11">
                <p align="center"><font face='Tahoma' size='1'>Placa comprada:<br>
                <img border='0' src='secciones/<?=$placa ?>'>
 </font><p align="center"><font face="Tahoma" size="1">El c�digo de la placa
                comprada es:<br>
                <?=$code?><br>
                <br>
                Introduzca el c�digo de la placa en el campo Mensaje del Mini
                Chat, poniendo ese c�digo se mostrar� la placa en el Mini Chat
                :)<br>
                <br>
                <b><font color="#C40000">MUY IMPORTANTE:</font></b><br>
                Apunte el c�digo de la placa comprada y registre su nombre para tener permisos para usar la placa:<br>
                </font>
                <form method="POST" action="envio/?seccion=<?=$seccion?>&placa=<?=$placa?>">
                  <p align="center"><font face="Tahoma" size="1" font color="#C40000"> <b>Escribe tu nick: <input type="text" name="nombre" class="boton" size="15" value="">   <input type="submit" class="boton" value="Finalizar Compra" name="B1"></p>
                </form>
              </td>
            </tr>
          </table>

  </center>

      </tr>
    </table>
  </div>
      </td>
    </tr>
    <tr>
      <td width="100%"><font size="1" face="Tahoma"><img border="0" src="catalogo-abajo.gif" width="325" height="25"></font></td>
    </tr>
  </table>
    </tr>
  </table>
</div>
</body>
</html>