<?
include("../configtag.php"); 
include("../language/lang-".$langactual.".php");
?>
<html>
<head>
<title>Secciones</title>
<link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body bgcolor="#EEEEEE">
<div align="center">
<img border="0" src="catalogo-portada.gif" width="290" height="137">
  <table border="0" cellpadding="0" cellspacing="0" width="300">
    <tr>
      <td valign="middle" align="center" width="120"><img border="0" src="catalogo-portada-placas.gif" width="64" height="61"></td>
      <td valign="top" align="left">�Bienvenidos al cat�logo del MC. En nuestro cat�logo encontrar�s una secci�n de placas para usarlas en el Minichat a las que puedes acceder f�cilmente desde el men� de la derecha.</td>
    </tr>
  </table>
    <table border="0" cellpadding="0" cellspacing="0" width="300">
      <tr>
        <td><br><br></td>
      </tr>
    </table>
    <table border="0" cellpadding="0" cellspacing="0" width="300">
      <tr>
        <td valign="top" align="left" width="100%">Algunos productos aparecen y desaparecen seg�n las ofertas.</td>
        <td valign="middle" align="center" width="120"><img border="0" src="catalogo-portada-monedas.gif" width="99" height="80"></td>
      </tr>
    </table>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
