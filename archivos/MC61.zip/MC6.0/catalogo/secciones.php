<?
include("../configtag.php");
include("../language/lang-".$langactual.".php");
?>
<html>
<head>
<title>Secciones</title>
<link rel="stylesheet" href="estilo.css" type="text/css">
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#DDDDDD">   
<tr>      
<td width="100%" style="border-bottom: solid; border-bottom-width: 1" height="20"><b>&nbsp;<a href="principal.php" target="principal">Cat�logo</a></b></td>    
</tr>  
</table>
<?
$query = "SELECT * FROM `categorias`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows) {
while ($cat = @mysql_fetch_array($resp)) {
?>
<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#DDDDDD">   
<tr>      
<td width="100%" style="border-bottom: solid; border-bottom-width: 1" height="20"><font face='Tahoma' size='1'><b>&nbsp;<a href="secciones/categoria.php?cat=<?=$cat['id']; ?>" target="principal" class="EnlaceMenu"><?=$cat['nombre']; ?></a></b></font></td>    
</tr>  
</table>
<?} } ?>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->