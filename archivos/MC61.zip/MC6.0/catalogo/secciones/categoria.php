<?
include("../../configtag.php"); 
include("../../language/lang-".$langactual.".php");

$query = "SELECT * FROM `categorias` WHERE id = '".$_GET['cat']."'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows) {
$cat = @mysql_fetch_array($resp);
?>
<html>
<head>
<link rel="stylesheet" href="../estilo.css" type="text/css">
</head>
<body bgcolor="#EEEEEE">
  <table border="0" cellpadding="5" cellspacing="0" width="300">
    <tr>
      <td width="100%">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%"><img border="0" src="<?=$cat['imagen']; ?>"></td>
            </tr>
            <tr>
              <td width="100%"><br><?=$cat['descripcion']; ?><br><br></td>
            </tr>
          </table>
      </td>
    </tr>
  <tr>
    <td width="100%">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
          <tr>
            <td width="125" valign="top" align="center">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td width="100%"><b>Elige</b></td>
                  </tr>
                  <tr>
                    <td width="100%">
                <table border="0" cellpadding="0" cellspacing="0" width="120">
<?
$query2 = "SELECT * FROM `productos` WHERE categoria = '".$_GET['cat']."'";
$resp2 = @mysql_query($query2);
$i = 0;
while ($i < 18) {
$producto = @mysql_fetch_array($resp2); 
if ($i == 0 || $i == 3 || $i == 6 || $i == 9 || $i == 12)
	echo "<tr>";
if ($producto) {	
?>
<td width="33%" height="40" background="../catalogo-placa_campo.gif" align="center"><a href="../comprar.php?seccion=<?=$cat['nombre']; ?>&amp;precio=<?=$producto['precio'] ?>&amp;placa=<?=$producto['nombre']; ?>"><img border="0" src="<?=$producto['imagen']; ?>" width="36" height="36"></a></td>
<?
} else {
?>
<td width="33%" height="40" background="../catalogo-placa_campo.gif" align="center">&nbsp;</td>
<? }
if ($i == 2 || $i == 5 || $i == 8 || $i == 11 || $i == 14)
	echo "</tr><tr>";
$i++;
} 
?>				  
                </table>
                    </td>
                  </tr>
                </table>
            </td>
            <td valign="bottom" align="right">
              <p align="center"><br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              </p>
                <table border="0" cellpadding="0" cellspacing="0" width="90%">
                  <tr>
                    <td width="100%">Haz clic en un producto para obtener informaci�n</td>
                  </tr>
                </table>
            </td>
          </tr>
        </table>
    </td>
  </tr>
  </table>
</body>
</html>
<? } ?>