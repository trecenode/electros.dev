<?
include("../configtag.php");
include("../language/lang-".$langactual.".php");
?>
<head>
<title><?=_placaid; ?> <?=$placa ?></title>
<link rel="stylesheet" href="estilo.css" type="text/css">
</head>

<body bgcolor="#EEEEEE">
<table border="0">
        <td>Comprar placa: <?=$_GET['placa']; ?>&nbsp;
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%">
                <p align="center">Imagen:<br>
                <img border='0' src='secciones/<?=$_GET['seccion'] ?>/<?=$_GET['placa'] ?>'>
                <br>
                El precio de esta placa es de <b><?=$_GET['precio']; ?> <font color="#800000">SMS</font></b></td>
              <td><img border="0" src="secciones/home/catalogo-portada-monedas.gif" width="99" height="80"></td>
            </tr>
          </table>

<p align="left">Para comprar esta placa env�a al 5535 un sms con el siguiente texto (sensible a may�sculas):<br>
<b><font color="#000080">SM comprar <?=$_GET['placa'] ?><br><br></font>
Y escribe en la casilla el c�digo recibido al enviar el SMS<br>
<font color="#800000">* El SMS enviado s�lo es v�lido para comprar esta placa<br>
<font size="1">
<iframe frameborder="0" src="http://acceso-sms.com/cod_acceso.php?id=<?=_codesms ?>&seccion=<?=$_GET['placa']?>"  marginwidth="1" marginheight="1" name="SPONSORmoviles" align="center" height="150" width="305" scrolling="no" border="0"></iframe>
</font></b></p>

<p align="center">
<b>
<font color="#39788C"><a href="../catalogo"><b><font color="#39788C">volver</font></b></font></a>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
