<?
include("../configtag.php"); 
include("../language/lang-".$langactual.".php");

if ($catalogo == "on") {
?>
<html>
<title>Cat�logo</title>
</head>
<body>
<div align="center">
  <table border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="325" valign="top" align="right">
  <table border="0" cellpadding="0" cellspacing="0" width="325">
    <tr>
      <td width="100%"><img border="0" src="catalogo-arriba.gif" width="325" height="34"></td>
    </tr>
    <tr>
      <td width="100%" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1" bgcolor="#EEEEEE" bordercolor="#000000"><iframe marginwidth="0" marginheight="0" src="principal.php" frameborder="0" width="323" height="400" scrolling="no" name="principal"></iframe>
      </td>
    </tr>
    <tr>
      <td width="100%"><img border="0" src="catalogo-abajo.gif" width="325" height="25"></td>
    </tr>
  </table><br></td>
      <td width="118" valign="top" align="left"><br>
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%"><img border="0" src="catalogo-derecha-arriba.gif" width="118" height="28"></td>
            </tr>
            <tr>
              <td width="100%" background="catalogo-derecha-fondo.gif"><iframe marginwidth="0" marginheight="0" src="secciones.php" frameborder="0" width="110" height="385" scrolling="no"></iframe>
              </td>
            </tr>
            <tr>
              <td width="100%"><img border="0" src="catalogo-derecha-abajo.gif" width="117" height="13"></td>
            </tr>
          </table>
        <br>
        <br></td>
    </tr>
  </table>
</div>
</body>
</html>
<? } else { ?>
<html>

<head>
<title>Cat�logo - Inactivo</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="325" valign="top" align="right">
  <table border="0" cellpadding="0" cellspacing="0" width="325">
    <tr>
      <td width="100%"><font size="1" face="Tahoma"><img border="0" src="catalogo-arriba.gif" width="325" height="34"></font></td>
    </tr>
    <tr>
      <td width="100%" style="border-left-style: solid; border-left-width: 1; border-right-style: solid; border-right-width: 1" bgcolor="#EEEEEE" bordercolor="#000000" height="300">
  <p align="center"><font face="Tahoma" size="1">Estamos mejorando el catalogo,<br>estaremos de vuelta lo antes posbile.<br> Disculpen las molestias.</font>
      </td>
    </tr>
    <tr>
      <td width="100%"><font size="1" face="Tahoma"><img border="0" src="catalogo-abajo.gif" width="325" height="25"></font></td>
    </tr>
  </table>
        <p>&nbsp;</td>
      <td width="118" valign="top" align="left">&nbsp;
        <div align="center">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="100%"><font face="Tahoma" size="1"><img border="0" src="catalogo-derecha-arriba.gif" width="118" height="28"></font></td>
            </tr>
            <tr>
              <td width="100%" background="catalogo-derecha-fondo.gif" height="250">&nbsp;
              </td>
            </tr>
            <tr>
              <td width="100%"><font face="Tahoma" size="1"><img border="0" src="catalogo-derecha-abajo.gif" width="117" height="13"></font></td>
            </tr>
          </table>
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>
<?
}
?>

<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->