<? include("acceder.php"); ?>
<table border="0" cellpadding="0" cellspacing="0" height=100% width="600" style="border: 1px solid white" bgcolor="#909090">
<tr>
<td colspan="2" valign="top">
<table border="0" cellpadding="2" cellspacing="0" height=100% width="100%">
<tr>
<td class="titulo" bgcolor="#FFFFFF"><img border="0" src="img/logo.gif"><td class="Texto" colspan="2" bgcolor="#FFFFFF" style="border-bottom: 1px solid white"><? echo _WELLCOME." <b>".$_SESSION['nnick']."</b>"; ?>&nbsp;&nbsp;&nbsp;<a href="javascript:window.close();">Salir</a></td></font></td>
<td bgcolor="#FFFFFF" align="right">
<? 
$query = "SELECT * FROM `alerta_mod` WHERE leido = '0'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows) {
?>
<a href="panel.php?mostrar=alertasmod&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><span style="font-family: Trebuchet MS; font-size: 16px; color:green;"><b>[MoD Alert]</b></span></a>
<? 
} else {
?>
<span style="font-family: Trebuchet MS; font-size: 16px; color:red;"><b>[MoD Alert]</b></span>
<?
}
?>&nbsp;</td>
</tr></form>
</table>
</td>
</tr>
<tr>
<td valign="top" style="border-right: 1px solid white" bgcolor="#FFFFFF">
<table border="0" cellpadding="1" cellspacing="1" width="130">
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Principal</a></td>
</tr>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Poderes</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=banear&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_CONTROLIP; ?></a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=censurar&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_CENSURAR; ?> Palabra</a></td>
</tr> 
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=censurarCaracter&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_CENSURAR; ?> Caracter</a></td>
</tr> 
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi") { ?>
<? if ($_SESSION['iden'] != "Moderador") { ?>
<? if ($activarReg == "on") { ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=registrarusuarios&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Registrar usuario</a></td>
</tr> 
<? } ?>
<? } ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=borrarusuarios&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_ERASEUSER; ?></a></td>
</tr> 
<? } ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=alert&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_ALERT; ?></a></td>
</tr>  
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=alertgeneral&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Alerta General</a></td>
</tr>
<? } ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">
<? 

$query = "SELECT * FROM `mensajes`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
	echo _EMPTY; 
else {
	 echo "<a href=panel.php?mostrar=borrarmensajes&".session_name()."=".session_id(); 
	 echo " class=\"EnlaceMenu\">"._ERASE."</a>"; 
}
?>
</td>
</tr>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=placas&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Control Placas</a></td>
</tr>
<? } ?>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Control MoD</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=admins&admin=Owner&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Owners</a></td>
</tr>
<? if ($_SESSION['iden'] != "Moderador") { ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=admins&admin=Moderador&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Moderadores</a></td>
</tr>
<? } ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=admins&admin=Rubi&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Rubis</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=admins&admin=Zafiro&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Zafiros</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=admins&admin=Bronze&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Bronzes</a></td>
</tr>
<? } ?>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Bolet�n MoD</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=enviarnoticia&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Enviar noticia</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=borrarnoticia&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Borrar noticia</a></td>
</tr>
<? } ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Utilidades</font></td>
</tr>
<? 
$query = "SELECT * FROM `privados` WHERE receptor = '".$_SESSION['id']."'AND leido = '0'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows)
	$bgcolor = "#ffcc00";
else
	$bgcolor = "#ffffff";
?>
<tr>
<td bgcolor="<?=$bgcolor; ?>" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=verprivados&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Mensajes Privados</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=stats&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Estad�sticas</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=statsusers&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Usuarios</a></td>
</tr>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=automensaje&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Auto Mensaje</a></td>
</tr>
<? } ?>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Cat�logo</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=categorias&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Control Categor�as</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=productos&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Control Productos</a></td>
</tr>
<? } ?>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Contenido Ayuda</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=contenido&s=preguntas&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Preguntas</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=contenido&s=seguridad&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Seguridad</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=contenido&s=reglas&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Reglas</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=contenido&s=privacidad&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Privacidad</a></td>
</tr>
<? } ?>
<? if ($_SESSION['iden'] != "Bronze") { ?>
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000"><img border="0" src="img/flechan.gif">&nbsp;Informes</font></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=informes/imensajes&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Archivo mensajes</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=informes/ibaneos&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Baneos/Desbaneos</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=informes/ialertas&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">Alertas enviadas</a></td>
</tr>
<tr>
<td bgcolor="#ffffff" class="Texto" colspan="2">
<img border="0" src="img/flechaa.gif">&nbsp;<a href="panel.php?mostrar=informes/ialertasmod&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">MoD Alerts</a></td>
</tr>
<? } ?>
</table>
</td>
<td align="center" valign="top" class="Texto" width="470" style="border: 1px solid #FFFFFF" bgcolor="#FFFFFF"> 
<? 
include ("mainpanel.php");
include($_GET['mostrar']); 
?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->