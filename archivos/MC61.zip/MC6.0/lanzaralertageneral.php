<?

$query = "SELECT * FROM `alerta_general`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows)
   $_GET['mostrar'] = "alertageneral";
   
?>