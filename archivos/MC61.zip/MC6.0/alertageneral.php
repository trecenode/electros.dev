<?
$query = "SELECT * FROM `alerta_general`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows) {
$alerta .= "<div align=\"center\">";
	  $alerta .= "<p>&nbsp;</p> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
while ($alert = @mysql_fetch_array($resp)) {
	  $alerta .= "<tr>";
	  $alerta .= "<td><img border=\"0\" src=\"img/alerta_management.gif\" width=\"150\" height=\"39\"></td>";
	  $alerta .= "</tr>";
	  $alerta .= "<tr>";
	  $alerta .= "<td background=\"img/alerta_fondo.gif\">";
	  $alerta .= "<div align=center>";
	  $alerta .= "<center>";
	  $alerta .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"115\">";
	  $alerta .= "<tr>";	  
	  $alerta .= "<td>";	
	  $alerta .= "<p align=\"center\"><font face=\"Tahoma\" size=\"1\"><b>Alerta General:<b></font></td>";
      $alerta .= "</tr>";
   	  $alerta .= "<tr>";
      $alerta .= "<td><font face=\"Tahoma\" size=\"1\">".$alert['texto']."</font><br><a href=\"borraralertageneral.php\"><br><center><img border=\"0\" src=\"img/alerta_aceptar.gif\"></a></td>";
	  $alerta .= "</tr>";
	  $alerta .= "</table>";
      $alerta .= "</center>";
	  $alerta .= "</div>";
      $alerta .= "</td>";
   	  $alerta .= "</tr>";
  	  $alerta .= "<tr>";
   	  $alerta .= "<td><img border=\"0\" src=\"img/alerta_abajo.gif\" width=\"150\" height=\"21\"></td>";
      $alerta .= "</tr>";
      $alerta .= "</table>";
	  $alerta .= "</div><p>&nbsp;</p>";
	}
}
echo $alerta;	
?>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->