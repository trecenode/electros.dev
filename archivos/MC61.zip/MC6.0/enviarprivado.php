<? include("acceder.php"); ?>
<table border="0" height="75%" width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto">
<?

if (isset($_POST['enviar'])) {
  if ($_POST['asunto'] != "" && $_POST['texto'] != "") {
    $id = "";
    
	$query = "SELECT * FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'"; 
	$resp = @mysql_query($query);
	$rows = @mysql_num_rows($resp); 
	$usuario = @mysql_fetch_array($resp);
	$user_id = $usuario['id'];	
	
	$query = "INSERT INTO `privados` (id, autor, receptor, asunto, texto, fecha) VALUES ('".$id."', '".$user_id."', '".$_POST['receptor']."', '".htmlentities($_POST['asunto'])."', '".htmlentities($_POST['texto'])."', '".date("d.m.y, H:i:s")."')";
	@mysql_query($query);
	echo "<div align=center><font color=#cc0000>Mensaje enviado</font><br><a href=\"panel.php?mostrar=enviarprivado&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></div>";
  } else 
    echo "<font class=\"Texto\">Has dejado alg�n campo vac�o<br></font><a href=\"panel.php?mostrar=enviarprivado&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
  
?>
<table border="0" cellpadding="0" cellspacing="0">
<form name="form" method="post" action="panel.php?mostrar=enviarprivado&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Enviar Privado</font></td>
</tr>
<tr><td class="Texto" align="center"><br></td></tr>
<tr>
<td class="Texto" align="center">
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td class="Texto" align="left" colspan="2">Destino:
<select name="receptor" class="Select">
<?
$query = "SELECT * FROM `usuarios` WHERE rol != '0' order by nick";
$resp = @mysql_query($query);
while ($cat = @mysql_fetch_array($resp)) {
	if ($_SESSION['nnick'] != $cat['nick']) {
		echo "<option value=\"".$cat['id']."\"";
		if (isset($_GET['receptor']) && $_GET['receptor'] == $cat['id'])
		echo " selected";
		echo ">".$cat['nick']."</option>";
	}
}
?>
</select>
</td>
</tr>
<tr><td><br></td></tr>
<tr>
<td class="Texto" align="left">Asunto:</td><td align="right"><input type="text" name="asunto" size="22" value="<?=$_GET['asunto']; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="left" valign="top" colspan="2"><br>Mensaje:</td>
</tr>
<tr>
<td colspan="2"><textarea name="texto" cols="30" rows="4" value="" class="Boton"></textarea></td>
</tr>
<tr>
<td colspan="2" class="Texto" align="center"><input name="enviar" type="submit" value="Enviar" class="Boton"></td>
</tr>
</table>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center"><br>
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
