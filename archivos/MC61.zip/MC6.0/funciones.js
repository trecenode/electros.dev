function seleccionarTodos(mensaje) {
	for (var i = 0; i < document.forms["formborrar"].elements.length; i++) {
       var elemento = document.forms["formborrar"].elements[i];
       if (elemento.type == "checkbox") {
         elemento.checked = mensaje.checked;
       }
    }
}

var cuenta=0; 

function enviado() { 
	if (cuenta == 0) { 
		cuenta++; 
		return true; 
	} else { 
		alert("<?=_ALERTFLOOD; ?>"); 
		return false; 
	} 
}

function charsleft(campo) {
  var anz = campo.value.length;
  if (anz > <?=$maxMsg; ?>) {
   campo.value = campo.value.substring(0,225);
   frei = 0;
  } else 
      frei = <?=$maxMsg; ?> -anz;
  document.forms["tag"].num.value = frei;
}

function borrarNick() {
  if (document.forms["tag"].nick.value == '<?=_NICKNAME; ?>')
    document.forms["tag"].nick.value='';
}

function borrarMensaje() {
  if (document.forms["tag"].mensaje.value == '<?=_MESSAGE; ?>')
    document.forms["tag"].mensaje.value='';
}

function borrarClave() {
  if (document.forms["tag"].clave.value == '<?=_PASSWORD; ?>')
    document.forms["tag"].clave.value='';
}
