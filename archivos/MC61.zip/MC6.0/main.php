<?

if (isset($_GET['mostrar'])) {
   if ($_GET['mostrar'] == "alerta")
   	  $_GET['mostrar'] = "alerta.php";
   else
   	   $_GET['mostrar'] = $_GET['mostrar'].".php";
} else
	$_GET['mostrar'] = "tag.php";

?>
