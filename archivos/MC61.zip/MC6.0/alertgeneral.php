<? include("acceder.php"); ?>
<table width="100%" height="75%" bgcolor="#eeeeee">
<tr>
<td align="center">
<?
if (isset($_POST['B1'])) {
   if ($_POST['mis'] != "") {
	  $id = "";
	  $query = "INSERT INTO `alerta_general` (id, texto, autor) VALUES ('".$id."', '".htmlentities($_POST['mis'])."', '".$_SESSION['nnick']."')";
	@mysql_query($query);
	$query = "SELECT id FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'";
	$resp = @mysql_query($query);
	$user = @mysql_fetch_array($resp);
	$user_id = $user['id'];
	$query = "INSERT INTO `log_alertas_generales` (id, texto, autor, fecha) VALUES ('".$id."', '".$_POST['mis']."', '".$user_id."', '".date("d.m.y, H:i:s")."')";
	@mysql_query($query);
   	  echo "<tr><td align=center class=Texto><font color=#cc0000>La alerta se ha mandado con �xito</font><br>";
   	  echo "<a href=\"panel.php?".session_name()."=".session_id()."\" class=EnlaceMenu>volver</a></td></tr>";
   } else {
   	  echo "<tr><td align=center class=Texto><font color=\"#cc0000\">Has dejado algun campo vacio<br></font>";
      echo "<a href=\"panel.php?mostrar=alertgeneral&".session_name()."=".session_id()."\" class=EnlaceMenu>volver</a></td></tr>";
   }
} else {
?>
<table border="0">
<tr>
<td align="center" class="Texto"><font color="#cc0000">Alerta General</font></td>
</tr>
<tr>
<td>
<form method="post" action="panel.php?mostrar=alertgeneral&<? echo session_name()."=".session_id() ?>">
<table border="0" cellpadding="0" cellspacing="1">
<tr>
<td class="Texto" align="center">Mensaje:</td>
</tr>
<tr>
<td><textarea type="text" name="mis" rows="5" cols="30" maxlength="150" class="Boton"></textarea></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"><input type="submit" value="Alertar" name="B1" class="Boton"></td>
</tr>
</table>
</form>
</td></tr>
<tr>
<td class="Texto" align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">volver</a><br><br>

</td>
</tr>
</table>
</td>
</tr>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
