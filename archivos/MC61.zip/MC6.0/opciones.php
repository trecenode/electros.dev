<table width="100%" height="100%" style="border: 1px solid <? echo $bordetabla; ?>" bgcolor="#cccccc">
<tr>
<td align="center">
<table border="0" cellspacing="0" cellpadding="2">
<? 
if (isset($_SESSION['nnick']) && esAdmin($_SESSION['nnick'])) { 
  if (!isset($_SESSION['iden'])) {
	$iden = idenAdmin($_SESSION['nnick']); 
   	$_SESSION['iden'] = $iden;
	$id = idAdmin($_SESSION['nnick']);
	$_SESSION['id'] = $id;
  }
?>
<tr>
<td align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu" target="_blank"><?=_ADMINISTRATOR; ?></a></td>
</tr>
<? } ?>
<tr>
<td align="center">
<a href="ftag.php?mostrar=veruser&<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu"><?=_USERS; ?></a></td>
</tr>
<tr>
<td align="center">
<a href="ftag.php?mostrar=smilies&<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu"><?=_SMILIES; ?></a></td>
</tr>
<tr>
<td align="center">
<a href="ftag.php?mostrar=tag&<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
</td>
</tr>
</table>