<?php

// Tag
define("_SEND", "Enviar Mensaje");
define("_NICKNAME", "Keko Nombre");
define("_MESSAGE", "Mensaje");
define("_PASSWORD", "Password");
define("_RESET", "Borrar");
define("_UNKNOWIP", "IP desconocida");
define("_NOWRITE", "Has sido expulsado por un gu�a del Minichat. Si crees que has sido baneado injustamente ponte en contacto con un MoD.");
define("_INCORRECTPASS", "Password incorrecta");
define("_NONICK", "Nick vac�o");
define("_NOMESSAGE", "Error en el Mensaje");

// Registro de Usuarios
define("_REGISTERED", "Registro finalizado con �xito");
define("_NEWNICK", "El Nick es");
define("_NEWPASS", "El Password es");
define("_ERRORNICK", "Este nick ya est� registrado");
define("_RETURN", "volver");
define("_NOPASS", "Password vac�o");
define("_PANELREG", "Panel de registro");
define("_ACCEPT", "Aceptar");
define("_DISABLED", "Esta opci�n no est� activada");

// Panel
define("_SAVEDCONFIG", "Configuraci�n guardada</font><br>");
define("_NOTEXT", "Has dejado alg�n campo vac�o o alg�n valor es incorrecto");
define("_CONFIG", "Configuraci�n");
define("_CNICK", "Caracteres Nick");
define("_CWORD", "Caracteres palabra");
define("_CMESSAGE", "Caracteres mensaje");
define("_SHOWMESSAGES", "Mostrar mensajes");
define("_REGNICK", "Registro nicks");
define("_URLNICK", "Url Nick");
define("_SHOWIP", "Mostrar IP");
define("_SHOWDATEHOUR", "Mostrar fecha y hora");
define("_SHOWLOGO", "Mostrar men� superior");
define("_REFRESH", "Tiempo refresco");
define("_SEG", "Segundos");
define("_CONFIGCOLOR", "Configurar color");
define("_CONTROLIP", "Banear/Desbanear");
define("_EMPTY", "No hay mensajes");
define("_ERASE", "Borrar mensajes");
define("_LOGIN", "Login");
define("_HELP", "Ayuda");
define("_LOGOUT", "[salir]");
define("_PANELIDEN", "Panel de identificaci�n");
define("_INCORRECTD", "Datos incorrectos");
define("_LANGUAGE", "Lenguaje");

// Baneo de IP
define("_BANIP", "IP baneada");
define("_NOIP", "No has introducido la IP");
define("_NOBANIP", "No hay IP's baneadas");
define("_NOSELECTEDIP", "No has seleccionado ninguna IP");
define("_ERASEDIP", "IP borrada");
define("_ALLIPERASED", "Todas las IP's han sido borradas");
define("_IP", "IP");
define("_BANIPS", "IP's baneadas");
define("_NONE", "Ninguno");
define("_ALL", "Todos");
define("_NOACCESS", "No tienes acceso a esta p�gina");

// Borrar Mensajes
define("_ERASEDMESSAGES", "Mensajes borrados");
define("_NOSELECTEDMESSAGES", "No has marcado ning�n mensaje");
define("_ALLMESSAGESERASED", "Todos los mensajes han sido borrados");
define("_ERASEMESSAGES", "Borrar mensajes");

// Funciones
define("_NEXCEEDSLIMITCHARS", "El nick excede el l�mite de caracteres");
define("_MEXCEEDSLIMITCHARS", "El mensaje excede el l�mite de caracteres");
define("_AT", "Enviado a las");
define("_NOSEND", "No puedes enviar");

// Usuarios
define("_REGISTEREDUSERS", "Usuarios registrados");

// 6.0
define("_ECNICKSUPERADMIN", "Color que toma el nick del Superadministrador");
define("_ECNICKADMIN", "Color que toma el nick de los administradores de segundo nivel");
define("_CADMINS", "Control MoDs");
define("_ADMINS", "Administradores nivel 2");
define("_EADMINS", "Opci�n para registrar y borrar a los administradores de nivel 2. S�lo el SuperAdministrador tiene la posibilidad de hacerlo");
define("_CNICKSUPERADMIN", "Superadmin");
define("_AEXISTS", "Este nick ya existe");
define("_WELLCOME", "Bienvenido");
define("_YOUARENOT", "Ahora ya no eres");
define("_REGISTEREDADMIN", "Registro finalizado con �xito");
define("_CENSURAR", "Censurar");
define("_WORD", "Palabra");
define("_CENWORD", "Palabras Prohibidas");
define("_WORDCEN", "Palabra censurada");
define("_NOWORD", "No has introducido la palabra");
define("_NOCENWORD", "No hay palabras censuradas");
define("_NOSELECTEDWORD", "No has seleccionado ninguna palabra");
define("_ERASEDWORD", "Palabra borrada");
define("_ALLWORDERASED", "Todas las palabras han sido borradas");
define("_NOSELECTEDADMIN", "No has seleccionado ning�n administrador");
define("_NONADMIN", "No hay administradores a borrar");
define("_ERASEDADMIN", "Administradores borrados");
define("_ALLADMINSERASED", "Todos los administradores han sido borrados");
define("_ECENSURAR", "Desde aqu� se puede impedir que ciertas palabras sean enviadas dentro de los mensajes");

//nuevo v6.0b
define("_FLOOD", "No puedes enviar otro mensaje hasta que no pasen ".$esperar." segundos");
define("_ANTIFLOOD", "Anti-Flood");
define("_BKCOLOR", "Fondo p�gina");
define("_ALERT", "Alerta por IP");
define("_ERASEUSER", "Borrar usuarios");
define("_ALERTFLOOD", "Por fabor, No realentize el Minichat.");
define("_CHECKEDALL", "Seleccionar todos");
define("_ERASEDALL", "Todos los nicks fueron borrados");
define("_NOSELECNICK", "No has seleccionado el nick a borrar");
define("_ERASEDNICK", "Nick Borrado");
define("_SMILIES", "Smilies/BBcode");
define("_BBCODE", "BBcode");
define("_TEXT", "texto");
define("_BOLD", "Negrita");
define("_ITALIC", "Cursiva");
define("_UNDERLINE", "Subrayado");
define("_EBBCODE", "activa la opci�n para dar formato al texto del mensaje");
define("_EANTIFLOOD", "n�mero de segundos que hay que esperar entre cada mensaje");

?>
