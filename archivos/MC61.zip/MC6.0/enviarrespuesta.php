<? include("acceder.php"); ?>
<table border="0" cellPadding="0" cellSpacing="0" bgcolor="#eeeeee">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Atender MoD Alert</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center" valign="top"><br>
<?
if ($_POST['respuesta'] != "") {
mail($_POST['email'], "Respuesta de su MoD Alert de Info-Keko.com","Alerta atendida por ".$_POST['mod'].":<br>:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>".$_POST['respuesta']."<br>:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<br>Mensaje original:<br>".$_POST['mensaje'],"from ". $_POST['modnombre']);

$id = "";
$query = "INSERT INTO `log_alerta_mod` (id, texto, email, ip, fecha, nick, mod, respuesta) values ('".$id."', '".htmlentities($_POST['mensaje'])."', '".htmlentities($_POST['email'])."', '".$_POST['ip']."', '".Date("d.m.y, H:i:s")."', '".$_POST['nick']."', '".$_POST['mod']."', '".$_POST['respuesta']."')";
@mysql_query($query);
$query = "DELETE FROM `alerta_mod` WHERE texto = '".$_POST['mensaje']."'";
@mysql_query($query);

?>
<font color="#cc0000">Respuesta enviada correctamente</font><br>
<a href="panel.php?"<? echo session_name()."=".session_id(); ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
<? } else { ?>
<font color="#cc0000">Has dejado alg�n campo vac�o</font><br>
<a href="javascript:history.back(1)" class="EnlaceMenu"><?=_RETURN; ?></a>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->

