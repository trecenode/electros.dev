<?
session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("conectar.php");
include("colores.php");
include("funciones.php");
include("language/lang-".$langactual.".php");
?>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Description" content="Minichat v<?=$version; ?>">
<meta name="Author" content="Rott">
<meta name="Generator" content="Minichat v<?=$version; ?>">
   <title>Minichat v<?=$version; ?></title> 
<? 

// opcion de actualizacion cada x tiempo configurable
if ($activarTiempo == "on")
	echo "<meta http-equiv='Refresh' content='".$tiempo."'>";
	
?>
   <link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
<style type="text/css">
<!--
.CampoTexto { 
   font-size: 10px; 
   font-family: verdana; 
   border: 1px solid <? echo $bordecampo; ?>; 
   background: <? echo $fondocampo; ?>;

}
.Texto {
   font-family: Verdana; 
   font-size: 10px; 
   font-style: normal;
   color: <?=$colortexto; ?>;
}
	
-->
</style>
<script language="javascript">
function perfil(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=150,height=124,left = 152,top = 134');");
}

</script>
</head> 
<body bgcolor="<?=$colorfondo; ?>">
<table border="0" cellpadding="0" cellspacing="0" bgcolor="<? echo $fondotabla ?>"
style="border-left: 1px solid <? echo $bordetabla ?>; border-right: 1px solid <? echo $bordetabla ?>; border-top: 1px solid <? echo $bordetabla ?>; border-bottom: 1px solid <? echo $bordetabla ?>;" 
width="100%" height="100%"><tr>
<?
if ($numMensajes == 0)
  $query = "SELECT * FROM `mensajes` order by id desc";
else
  $query = "SELECT * FROM `mensajes` order by id desc limit $numMensajes";
  
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
?>
<td class="Texto" align="center">
<font color="#cc0000">
<? echo _EMPTY; ?>
</font>
</td>
<?
} else {
?>
<td class="Texto" align="center" valign="top">
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<?
$i = 0;
while ($mensajes = mysql_fetch_array($resp)) {

$nuevo = "";

	if ($i % 2 == 0) 
		$bg = $cpar; 
	else 
		$bg = $cimpar;
	
		if ($mensajes['usuario'] == -1) {
			$nombre = $mensajes['nombre'];
			$rol = "Visitante";
		} else {
			$query2 = "SELECT * FROM `usuarios` WHERE id = '".$mensajes['usuario']."'"; 
			$resp2 = @mysql_query($query2);
			$rows2 = @mysql_num_rows($resp2); 
			$user = @mysql_fetch_array($resp2);
			$nombre = $user['nick'];  
			if ($user['rol'] == "0")
				$rol = "ViP";
			else
				$rol = $user['rol'];
		}
			
         // Unimos el mensaje a etiquetas HTML y miramos si el usuario ha introducido una url o un email
		if ($activarIp == "on")
          $nuevo .= "<a href=\"javascript:perfil('perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil-perfil.php?ip=".$mensajes['ip']."&nick=".$nombre."');\" class=\"EnlaceMenu\">";
		else {  
        	$web = $mensajes['web'];
        	if (eregi("@", $web)) {
        	  $web = "mailto:".$web;
        	  $nuevo .= "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
        	} else if ($web != "" && $web != "http://") {
					if (!eregi("http://", $web)) {
						$web = "http://".$web;
					}
					$nuevo .= "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
				}
		}

        $nuevo .= "<font color=\"".$mensajes['color']."\" title=\"".$rol."\">";
		
        $nuevo .= "<b>".$nombre."</b></a></font>";

		if ($activarIp == "on" && isset($_SESSION['nnick']) && esAdmin($_SESSION['nnick']))
			$nuevo .= "</a>";
		else if ($web != "" && $web != "http://")
          $nuevo .= "</i></a>";

        $nuevo .= "<br> ".$mensajes['texto']."";

        if ($activarHora == "on")
          $nuevo .= "<br><font color=\"#cc0000\">".$mensajes['fecha']."</font>";

 	$total = $nuevo;
 	
?>
<tr>
<td class="Texto" bgcolor="<?=$bg; ?>" style="border-bottom: 1px solid <?=$bordetabla ?>"> 
<? echo $total; ?>
</td>
</tr>
<? $i ++; } ?>
</table></td>
<? } ?>
</tr>
</table>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->