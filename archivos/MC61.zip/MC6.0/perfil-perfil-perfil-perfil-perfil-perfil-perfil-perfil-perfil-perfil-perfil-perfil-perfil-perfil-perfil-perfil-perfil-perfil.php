<? 
session_cache_limiter('nocache,private');
session_start();

include("configtag.php");
include("colores.php");
include("language/lang-".$langactual.".php");
include("funciones.php");
?>

<link rel="stylesheet" href="ayuda/estilo.css" type="text/css">

<body topmargin="0" leftmargin="0"><table border=0 cellpadding=0 cellspacing=0>       <tr>         <td><img border=0 src=img/perfil_arriba.gif width=150 height=39></td>       </tr>       <tr>         <td background=img/alerta_fondo.gif>           <div align=center>             <center>             <table border=0 cellpadding=0 cellspacing=0 width=115>               <tr>                 <td><font face=Tahoma size=1>		<b>KeKo:</b> <?=$_GET['nick']; ?><br>
		<? if (esAdmin($HTTP_SESSION_VARS['nnick'], $HTTP_SESSION_VARS['nclave'])) {{ ?><b>IP:</b> <?=$_GET['ip']; ?><? } } else  echo "<b>IP: </b>-<br>"; ?>
		<? 
		if (esAdmin($_GET['nick'])) { 
			$estado = "MoD"; } 
		else if (yaExiste($_GET['nick'])) { 
				$estado = "ViP"; 
				} else {
					$estado = "Usuario";
				}
		?>
        <? if (esAdmin($HTTP_SESSION_VARS['nnick'], $HTTP_SESSION_VARS['nclave'])) {{ ?><br><? } ?><? } else  echo " "; ?><b>Estado: </b><?=$estado?><br><? if (esAdmin($HTTP_SESSION_VARS['nnick'], $HTTP_SESSION_VARS['nclave'])) {{ ?><a href="panel.php?mostrar=banear&ip=<?=$_GET['ip']; ?>&nick=<?=$_GET['nick']; ?>&<? echo session_name()."=".session_id() ?>" class="menu" target="_blank">Banear</a><br>
		<a href="panel.php?mostrar=alert&ip=<?=$_GET['ip']; ?>&nick=<?=$_GET['nick']; ?>&<? echo session_name()."=".session_id() ?>" class="menu" target="_blank">Enviar Alerta</a>
		<? if ($estado == "ViP IK" && ($_SESSION['iden'] == "Moderador" || $_SESSION['iden'] == "Owner")) { ?>
		<br><a href="panel.php?mostrar=borrarusuarios&nick=<?=$_GET['nick']; ?>&<? echo session_name()."=".session_id() ?>" class="menu" target="_blank">Borrar</a>
		<? } ?><? } } else  echo " "; ?>
		</td></tr></font></td>               </tr>             </table>             </center>           </div>         </td>       </tr>       <tr>         <td><img border=0 src=img/alerta_abajo.gif width=150 height=21></td>       </tr>     
		</table>
<title><?=$_GET['nick']; ?></title>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->