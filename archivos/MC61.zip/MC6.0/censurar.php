<? include("acceder.php"); ?>
<table border="0" height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['censurar'])) {
  if ($_POST['npalabra'] != "") {
    $id = "";
	$query = "SELECT id FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'";
	$resp = @mysql_query($query);
	$user = @mysql_fetch_array($resp);
	$user_id = $user['id'];
    $query = "INSERT INTO `censuras` (id, palabra, autor, fecha) VALUES ('".$id."', '".$_POST['npalabra']."', '".$user_id."', '".Date("d.m.y, H:i:s")."')";
	@mysql_query($query);
	echo "<div align=center><font color=\"#cc0000\">"._WORDCEN."</font><br><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></div>";
  } else 
    echo "<font class=\"Texto\">"._NOWORD."<br></font><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `censuras`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<font class=\"Texto\">"._NOCENWORD."<br></font><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['palabra'])) {
  echo "<font class=\"Texto\">"._NOSELECTEDWORD."<br></font><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$palabra = $_POST['palabra'];
	$query = "SELECT * FROM `censuras`";
	$resp = @mysql_query($query);
    while ($censura = @mysql_fetch_array($resp)) {	  
      if ($palabra[$censura['id']] == "on") {
	   		$query2 = "DELETE FROM `censuras` WHERE id = '".$censura['id']."'";
			@mysql_query($query2);
		}
    }

	echo ""._ERASEDWORD."<br><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
		$query = "SELECT * FROM `censuras`";
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);

		if (!$rows)
          echo "<font class=\"Texto\">"._NOCENWORD."<br></font><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `censuras`";
			@mysql_query($query);
	       echo ""._ALLWORDERASED."<br><a href=\"panel.php?mostrar=censurar&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else {
  
?>
<table border="0" cellpadding="2" cellspacing="0">
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<form name="form" method="post" action="panel.php?mostrar=censurar&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center"><font color="#cc0000"><?=_CENSURAR." "._WORD; ?></font></td>
</tr>
<tr>
<td class="Texto" align="center"></td>
</tr>
<tr>
<td class="Texto" align="center"><?=_WORD; ?>: <input type="text" name="npalabra" size="15" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="center"></td>
</tr>
<tr>
<td class="Texto" align="center"><input name="censurar" type="submit" value="Censurar" class="Boton"></td>
</tr>
<? } ?>
<tr>
<td class="Texto" align="center">&nbsp;</td>
</tr>
<tr>
<td class="Texto" align="center"><font color="#cc0000"><?=_CENWORD; ?></font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center">
<?
$query = "SELECT * FROM `censuras` order by id";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table width=\"100%\">";
echo "<tr><td class=\"Texto\" bgcolor=#6699cc>Palabra</td><td class=\"Texto\" bgcolor=#6699cc>Por</td><td class=\"Texto\" bgcolor=#6699cc>Fecha</td></tr>";
$n = 0;
while ($palabras = @mysql_fetch_array($resp)) {
	$query2 = "SELECT nick FROM `usuarios` WHERE id = '".$palabras['autor']."'";
	$resp2 = @mysql_query($query2);
	$user = @mysql_fetch_array($resp2);
    echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\">";
	if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro")
	echo "<input type=checkbox name=palabra[".$palabras['id']."]>";
	echo $palabras['palabra']."</td><td class=\"Texto\" bgcolor=\"#e0e0e0\">".$user['nick']."</td><td class=\"Texto\" bgcolor=\"#e0e0e0\">".$palabras['fecha']."</td></tr>";
   $n ++;
   }
echo "</table>";
}
?>  
</td>
</tr>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<tr>
<td align="center">
<table cellpadding="1" cellspacing="0">
<tr>
<td><input type="submit" name="borrar" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" value="<?=_ALL; ?>" class="Boton" type="submit"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->