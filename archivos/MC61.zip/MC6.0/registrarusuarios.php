<? include("acceder.php"); ?>
<table border="0" cellpadding="2" cellspacing="2" width="100%" bgcolor="#eeeeee" height="70%">
<tr>
<td align="center" valign="middle">
<table border ="0" cellpadding="2" cellspacing="2">
<tr>
<? if ($activarReg == "on") { ?>
<td colspan="2" align="center" class="Texto">
<form method="post" action="panel.php?mostrar=registrar&<? echo session_name()."=".session_id() ?>" 
name="registro">
<?=_PANELREG; ?>
</td>
</tr>
<tr>
<td class="Texto"><?=_NICKNAME; ?></td>
<td>
<input type="text" name="nicknuevo" value="" size="8" class="Boton" 
maxlength="<?php echo $maxNick; ?>"> 
</td>
</tr>
<tr>
<td class="Texto">Email</td>
<td>
<input type="text" name="email" value="" size="8" class="Boton"> 
</td>
</tr>
<tr>
<td class="Texto"><?=_PASSWORD; ?></td>
<td>
<input type="password" name="clavenuevo" value="" size="8" class="Boton" 
maxlength="10"></td>
</tr>
<tr>
<td colspan="2" align="center">
<input type="submit" name="enviarregistro" value="<?=_ACCEPT; ?>" class="Boton"></td>
</tr>
<tr>
<td align="center" colspan="2">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</td>
</form>
<? } else { ?>
<td><?=_DISABLED; ?></td>
<? } ?>
</tr>
</table>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->