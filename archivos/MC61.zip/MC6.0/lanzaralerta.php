<?

  // Cogemos la IP
  if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  else if ($_SERVER['HTTP_VIA'] != "") 
         $ip = $_SERVER['HTTP_VIA'];   
  else if ($_SERVER['REMOTE_ADDR'] != "") 
         $ip = $_SERVER['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 

$query = "SELECT * FROM `alertas` WHERE ip = '$ip'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows)
   $_GET['mostrar'] = "alerta";
 	

?>
