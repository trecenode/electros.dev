<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi") { ?>
<? 
include("acceder.php"); 

function validarCampos() {
		 if ($_POST['loginAdmin'] != "" && $_POST['emailAdmin'] != "" && 
		 $_POST['antiflood'] != "" && $_POST['antiflood'] > -1 &&
		 $_POST['valorPalabra'] != "" && $_POST['valorPalabra'] > 0 &&
 		 $_POST['valorMensajes'] != "" && $_POST['valorMensajes'] > -1 && 
		 $_POST['valorNick'] != "" && $_POST['valorNick'] > 0 && 
		 $_POST['maxPalabra'] != "" && $_POST['maxPalabra'] > 0 && 
 		 ((isset($_POST['refresh']) && $_POST['valorTiempo'] != "" && $_POST['valorTiempo'] > 0) || 
		 !isset($_POST['refresh'])) && ((isset($_POST['automensaje']) && $_POST['tiempoAutomensaje'] != "" && $_POST['tiempoAutomensaje'] > 0) || !isset($_POST['automensaje'])))
		 return true;
		 
		 return false;

}

// Desde aqu� concatenamos toda la informaci�n obtenida en 
// el formulario de configuraci�n y la guardamos en el fichero 
function guardarConfiguracion() { 
		if (existeUser(stripSlashes($_POST['loginAdmin']), $_SESSION['iden'], $_SESSION['id']))
		   echo "<br><font color=\"#cc0000\">"._AEXISTS."</font><br>"; 
		else {
		  $_SESSION['nnick'] = stripSlashes($_POST['loginAdmin']); 
	
			if ($_POST['passnueva'] != "")
				$query = "UPDATE `usuarios` set nick = '".stripSlashes($_POST['loginAdmin'])."', pass = '".md5($_POST['passnueva'])."' WHERE id = '".$_SESSION['id']."'";
			else  
		  		$query = "UPDATE `usuarios` set nick = '".stripSlashes($_POST['loginAdmin'])."' WHERE id = '".$_SESSION['id']."'";
				@mysql_query($query);
				
				$query = "UPDATE `usuarios` set email = '".stripSlashes($_POST['emailAdmin'])."' WHERE id = '".$_SESSION['id']."'";
				@mysql_query($query);
				
				
$query = array();				
$query[0] = "valor = '".$_POST['valorPalabra']."' WHERE campo = 'maximo'";
$query[1] = "valor = '".$_POST['valorMensajes']."' WHERE campo = 'numMensajes'";
$query[2] = "valor = '".$_POST['valorNick']."' WHERE campo = 'maxNick'";
$query[3] = "valor = '".$_POST['maxPalabra']."' WHERE campo = 'maxMsg'";

	if (isset($_POST['url'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off"; 

$query[4] = "valor = '".$nuevo."' WHERE campo = 'activarUrl'";		

	if (isset($_POST['registro'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off"; 
		
$query[5] = "valor = '".$nuevo."' WHERE campo = 'activarReg'";		

	if (isset($_POST['ip'])) 
		$nuevo = "on"; 
	else
		$nuevo = "off";

$query[6] = "valor = '".$nuevo."' WHERE campo = 'activarIp'";		

	if (isset($_POST['hora'])) 
		$nuevo = "on"; 
	else
		$nuevo = "off"; 
	
$query[7] = "valor = '".$nuevo."' WHERE campo = 'activarHora'";		

	if (isset($_POST['logo'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off"; 

$query[8] = "valor = '".$nuevo."' WHERE campo = 'activarLogo'";			
		
	if (isset($_POST['bbcode'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off"; 	

$query[9] = "valor = '".$nuevo."' WHERE campo = 'activarBBcode'";		
$query[10] = "valor = '".$_POST['lenguaje']."' WHERE campo = 'langactual'";

	if (isset($_POST['refresh'])) { 
		$query[11] = "valor = 'on' WHERE campo = 'activarTiempo'";
		$query[12] = "valor = '".$_POST['valorTiempo']."' WHERE campo = 'tiempo'";
	} else {
		$query[11] = "valor = 'off' WHERE campo = 'activarTiempo'";
		$query[12] = "valor = '' WHERE campo = 'tiempo'";
	}
	
	$query[13] = "valor = '".$_POST['antiflood']."' WHERE campo = 'esperar'";

	if (isset($_POST['mantenimiento'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off";
	
	$query[14] = "valor = '".$nuevo."' WHERE campo = 'activarMant'";	

	if (isset($_POST['automensaje'])) { 
		$query[15] = "valor = 'on' WHERE campo = 'activarAutomensaje'";
		$query[16] = "valor = '".$_POST['tiempoAutomensaje']."' WHERE campo = 'tAutomensaje'";
	} else {
		$query[15] = "valor = 'off' WHERE campo = 'activarAutomensaje'";
		$query[16] = "valor = '' WHERE campo = 'tAutomensaje'";
	}

	if (isset($_POST['activarCatalogo'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off";
			
	$query[17] = "valor = '".$nuevo."' WHERE campo = 'catalogo'";	
				
	for ($i = 0; $i < sizeof($query); $i ++)
		@mysql_query("UPDATE `configuracion` SET ".$query[$i]); 
 
	echo "<br><font class=\"Texto\"><font color=\"#cc0000\">"._SAVEDCONFIG."</font>"; 
	}

}

if ($_POST['aceptar']) { 

if ($_SESSION['iden'] == "Moderador") {
if (isset($_POST['mantenimiento'])) 
		$nuevo = "on"; 
	else 
		$nuevo = "off";
		
$query = "UPDATE `configuracion` SET valor = '".$nuevo."' WHERE campo = 'activarMant'";
@mysql_query($query);
echo "<br><font class=\"Texto\"><font color=\"#cc0000\">"._SAVEDCONFIG."</font>"; 
} else {
if (validarCampos()) 
	guardarConfiguracion(); 
else
	echo "<br><font color=\"#cc0000\">"._NOTEXT."<br></font>";
	}
	echo "<a href=\"panel.php?mostrar=configuracion&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a><br><br>"; 
} else { 
?>
<form name="form" method="post" action="panel.php?mostrar=configuracion&<? echo session_name()."=".session_id() ?>">
<table border="0" cellpadding="2" cellspacing="0" width="80%">
<tr>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<td class="Texto" colspan="3" align="left">
<font color="#cc0000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=_CONFIG; ?></font></td>
</tr
<tr><td rowspan="24">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td class="Texto" colspan="2" align="center"><br></td>
</tr>
<tr>
<td class="Texto">
<?=_CNICK; ?>: </td>
<td><input type="text" name="valorNick" size="2" value="<?=$maxNick; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto"> 
<?=_CWORD; ?>: </td>
<td><input type="text" name="valorPalabra" size="2" value="<?=$maximo; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto"> 
<?=_CMESSAGE; ?>: </td>
<td><input type="text" name="maxPalabra" size="2" value="<?=$maxMsg; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto"> 
<?=_ANTIFLOOD; ?>: </td>
<td><input type="text" name="antiflood" size="2" value="<?=$esperar; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto"> 
<?=_SHOWMESSAGES; ?>: </td>
<td>
<input type="text" name="valorMensajes" size="2" value="<?=$numMensajes; ?>" class="Boton"></td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="activarCatalogo" 
<? if($catalogo == "on") { echo "checked"; } ?>> Cat�logo</td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="mantenimiento" 
<? if($activarMant == "on") { echo "checked"; } ?>> Mostrar inoperativo</td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="registro" 
<? if($activarReg == "on") { echo "checked"; } ?>> <?=_REGNICK; ?></td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="url" 
<? if($activarUrl == "on") { echo "checked"; } ?>> <?=_URLNICK; ?> </td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="ip" 
<? if($activarIp == "on") { echo "checked"; } ?>> <?=_SHOWIP; ?> </td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="hora" 
<? if($activarHora == "on") { echo "checked"; } ?>> <?=_SHOWDATEHOUR; ?> </td>
</tr>
<tr>
<td colspan="2" class="Texto"><input type="checkbox" name="bbcode" 
<? if($activarBBcode == "on") { echo "checked"; } ?>> <?=_BBCODE; ?></td>
</tr>
<tr>
<td class="Texto" colspan="2"><input type="checkbox" name="refresh" 
<? if($activarTiempo == "on") { echo "checked"; } ?>> <?=_REFRESH; ?> </td>
</tr>
<tr>
<td class="Texto">      <?=_SEG; ?>:</td>
<td><input type="text" name="valorTiempo" size="2" value="<?=$tiempo; ?>" class="Boton"></td>
</tr> 
<tr>
<td class="Texto" colspan="2"><input type="checkbox" name="automensaje" 
<? if($activarAutomensaje == "on") { echo "checked"; } ?>> Automensaje </td>
</tr>
<tr>
<td class="Texto">      <?=_SEG; ?>:</td>
<td><input type="text" name="tiempoAutomensaje" size="2" value="<?=$tAutomensaje; ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto" colspan="2"><?=_LANGUAGE; ?>:      <select name="lenguaje" class="Select"> 
<? 

$directorio = opendir("language"); 
while ($file = readdir($directorio)) { 
	if (preg_match("/^lang\-(.+)\.php/", $file, $matches)) { 
		$langFound = $matches[1]; 
		$langlista .= "$langFound "; 
	} 
} 
closedir($directorio); 
$langlista = explode(" ", $langlista); 
sort($langlista); 
for ($i = 0; $i < sizeof($langlista); $i ++) { 
	if ($langlista[$i]!="") { 
		$content .= "<option value=\"$langlista[$i]\" "; 
	if ($langlista[$i] == $langactual) $content .= " selected"; 
		$content .= ">".ucfirst($langlista[$i])."</option>\n"; 
	} 
} 

echo $content; 
?> 
</select></td> 
</tr> 
<tr>
<td class="Texto" colspan="2" style="border-top: 1px solid <?=$bordetabla ?>"> </td>
</tr>
<tr>
<?
$query = "SELECT email FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'";
$resp = @mysql_query($query);
$user = @mysql_fetch_array($resp);
?>
<td class="Texto"><?=_LOGIN; ?>:</td>
<td><input type="text" name="loginAdmin" size="5" value="<? echo $_SESSION['nnick']; ?>" class="Boton" maxlength="<?=$maxNick; ?>"></td>
</tr>
<tr>
<td class="Texto"> 
Email: </td>
<td>
<input type="text" name="emailAdmin" size="20" value="<?=$user['email'] ?>" class="Boton"></td>
</tr>
<tr>
<td class="Texto" colspan="2"> Cambiar <?=_PASSWORD; ?>: </td>
</tr>
<tr>
<td class="Texto">Nueva:</td>
<td><input type="password" name="passnueva" size="5" class="Boton" maxlength="10"></td>
</tr>
<tr>
<td class="Texto" colspan="2"></td>
</tr>
</table> 
<input name="aceptar" type="submit" value="<?=_ACCEPT; ?>" class="Boton"> 
</form> 
<? }}} ?>
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<td class="Texto" bgcolor="#FFFFFF"><font color="#cc0000">Bolet�n MoD</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:window.close();">Salir</a></td>
</tr>
<tr>
<td>
<?
$query = "SELECT * FROM `boletin` order by id desc";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center class=\"Texto\">No hay noticias</div>";
else {
echo "<table border=\"0\">";
$n = 0;
while ($noticia = @mysql_fetch_array($resp)) {
$query2 = "SELECT * FROM `usuarios` WHERE id = '".$noticia['autor']."'";
$resp2 = @mysql_query($query2);
$usuario = @mysql_fetch_array($resp2);
$nick = $usuario['nick'];
   echo "<tr><td class=\"Texto\"><b>".$noticia['titulo']."</b></td></tr><tr><td class=\"Texto\">".$noticia['texto']."</td></tr><tr><td class=\"Texto\"><font color=\"#cc0000\">Enviada por ".$nick." el ".$noticia['fecha']."</font></td></tr><tr><td>&nbsp;</td></tr>";
   $n ++;
   }
echo "</table>";
}
?>  
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->