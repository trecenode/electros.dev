<? include("acceder.php"); ?>
<table border="0" height=100% width="100%" bgcolor="#eeeeee" cellpadding="0" cellspacing="0">
<tr>
<td align="center" class="Texto" style="border-bottom: 1px solid <?=$bordetabla; ?>">
<?

if (isset($_POST['aceptar'])) {
  if (isset($_POST['mensaje'])) {
	$mensaje = $_POST['mensaje'];
	$query = "SELECT * FROM `log_mensajes` order by tiempo desc";
	$resp = @mysql_query($query);
    while ($texto = @mysql_fetch_array($resp)) {	  
      if ($mensaje[$texto['id']] == "on") {
	   		$query2 = "DELETE FROM `log_mensajes` WHERE id = '".$texto['id']."'";
			@mysql_query($query2);
		}
    }
		
	echo "<font color=#cc0000>"._ERASEDMESSAGES."</font><br><a href=panel.php?mostrar=informes/imensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>"; 
	} else
	    echo "<font color=#cc0000>"._NOSELECTEDMESSAGES."</font><br><a href=panel.php?mostrar=informes/imensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>";
} else if ($_POST['todos']) {
        $query = "TRUNCATE TABLE `log_mensajes`";
		@mysql_query($query);
		
			   echo "<font color=#cc0000>"._ALLMESSAGESERASED."</font><br><a href=panel.php?mostrar=informes/imensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>";
} else if (isset($_POST['ayuda'])) 
         include("ayuda.php");
	   else {
  
?>
<form name="formborrar" method="post" action="panel.php?mostrar=informes/imensajes&<? echo session_name()."=".session_id() ?>">
<table cellpadding="2" cellspacing="0" border="0">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Archivo de mensajes</font></td>
</tr>
<tr><td>&nbsp;</td></tr>
<? if ($_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td class="Texto">
<input type="checkbox" name="selectodos" value="checkbox" onClick="seleccionarTodos(this);">&nbsp;<?=_CHECKEDALL; ?></td>
</tr>
<? } ?>
</table>
</td>
</tr>
<tr>
<td height="100%" valign="top">
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<?

$query = "SELECT * FROM `log_mensajes` order by tiempo desc"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
	echo "<tr><td height=\"100%\" class=\"Texto\" align=\"center\">"._EMPTY." archivados</td></tr>";
else {
$i = 0;
    while ($mensajes = mysql_fetch_array($resp)) {
     $nuevo = "";
     
     if ($i % 2 == 0)
	   $bg = $cpar;
     else
	   $bg = $cimpar;

         // Unimos el mensaje a etiquetas HTML y miramos si el usuario ha introducido una url o un email
        $web = $mensajes['web'];
        if (eregi("@", $web)) {
          $web = "mailto:".$web;
          $nuevo = "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
        }else if ($web != "" && $web != "http://") {
				if (!eregi("http://", $web)) {
					$web = "http://".$web;
					$nuevo = "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
				}
			}

        $nuevo .= "<font color=\"".$mensajes['color']."\" ";

        if ($activarIp == "on")
          $nuevo .= "title=\"".$mensajes['ip']."\"";

		if ($mensajes['usuario'] == -1)
			$nombre = $mensajes['nombre'];
		else {
			$query2 = "SELECT * FROM `usuarios` WHERE id = '".$mensajes['usuario']."'"; 
			$resp2 = @mysql_query($query2);
			$rows2 = @mysql_num_rows($resp2); 
			$user = @mysql_fetch_array($resp2);
			$nombre = $user['nick'];  
		}
		  
        $nuevo .= "><b>".$nombre."</b></font>";

        if ($web != "" && $web != "http://")
          $nuevo .= "</i></a>";

        $nuevo .= "<br> ".$mensajes['texto']."";

        if ($activarHora == "on")
          $nuevo .= "<br><font color=\"#cc0000\">".$mensajes['fecha']."</font>";

 	   $total = $nuevo;
 	   
       echo "<tr><td class=\"Texto\" style=\"background-color: ".$bg."; border-bottom: 1px solid ".$bordetabla."\">";
	if ($_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi")
	   echo "<input type=checkbox name=mensaje[".$mensajes['id']."]>";
	   echo $total."</td></tr>";
     $i ++;
    }
}
?>
</table>
</td>
</tr>
<? if ($_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td align="center">
<table cellpadding="0">
<tr>
<td><input name="aceptar" type="submit" value="<?=_RESET; ?>" class="Boton">
<input name="todos" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
<tr>
<td align="center"><a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</form>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->