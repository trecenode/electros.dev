<? include("acceder.php"); ?> 
<table border="0" height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top" height=100%>
<table border="0" width="100%">
<tr>
<td align="center" class="Texto" valign="top"> 
<? 

if (isset($_POST['borrar'])) { 

$query = "SELECT * FROM `log_alerta_mod`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
   echo "<font class=\"Texto\">No hay informes<br>";
   echo "</font><a href=\"panel.php?mostrar=informes/ialertasmod&".session_name()."=".session_id()."\"";
   echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
} else { 
  if (!isset($_POST['baneo'])) { 
  	 echo "<font class=\"Texto\">No has seleccionado ning�n informe<br>";
	 echo "</font><a href=\"panel.php?mostrar=informes/ialertasmod&".session_name()."=".session_id()."\"";
	 echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
  } else { 
	$baneo = $_POST['baneo'];
	$query = "SELECT * FROM `log_alerta_mod`";
	$resp = @mysql_query($query);
    while ($ban = @mysql_fetch_array($resp)) {	  
      if ($baneo[$ban['id']] == "on") {
	   		$query2 = "DELETE FROM `log_alerta_mod` WHERE id = '".$ban['id']."'";
			@mysql_query($query2);
		}
    }

  echo "Informes borrado<br><a href=\"panel.php?mostrar=informes/ialertasmod&".session_name()."=".session_id()."\"";
  echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 

  } 
} 
} else if (isset($_POST['todas'])) { 
$query = "SELECT * FROM `log_alerta_mod`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
   	 echo "<font class=\"Texto\">No hay informes<br>";
   	 echo "</font><a href=\"panel.php?mostrar=informes/ialertasmod&".session_name()."=".session_id()."\"";
   	 echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
  } else { 
  	$query = "DELETE FROM `log_alerta_mod`";
	@mysql_query($query); 
  	echo "Todos los informes han sido borrados<br>";
  	echo "<a href=panel.php?mostrar=informes/ialertasmod&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>"; 
  } 
} else { 

?> 
</td>
</tr>
<tr>
<td class="Texto" align="center"><font color="#cc0000">Informe MoD Alerts respondidas</font></td>
</tr>
<tr>
<td align="center" class="Texto" valign="top"> 
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%"> 
<form name="form" method="post" action="panel.php?mostrar=informes/ialertasmod&<? echo session_name()."=".session_id() ?>"> 
<tr><td class="Texto" colspan="2" valign="top"> 
<?
$query = "SELECT * FROM `log_alerta_mod` order by id desc";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" width=\"100%\"><tr><td class=\"Texto\" width=\"100\" bgcolor=#6699cc>IP</td><td class=\"Texto\" bgcolor=#6699cc>Nick</td><td class=\"Texto\" bgcolor=#6699cc>Texto</td><td class=\"Texto\" bgcolor=#6699cc>MoD</td><td class=\"Texto\" bgcolor=#6699cc>Respuesta</td><td class=\"Texto\" bgcolor=#6699cc>Fecha</td></tr>";
$n = 0;
while ($baneo = @mysql_fetch_array($resp)) {
if ($baneo['nick'] == "-1")
	$user = "An�nimo";
else {
	$query2 = "SELECT * FROM `usuarios` WHERE id = '".$baneo['nick']."'"; 
	$resp2 = @mysql_query($query2);
	$rows2 = @mysql_num_rows($resp2); 
	$usuario2 = @mysql_fetch_array($resp2);
	$user = $usuario2['nick'];
}	
	$query2 = "SELECT * FROM `usuarios` WHERE id = '".$baneo['mod']."'"; 
	$resp2 = @mysql_query($query2);
	$rows2 = @mysql_num_rows($resp2); 
	$usuario2 = @mysql_fetch_array($resp2);
	$nick = $usuario2['nick'];	
   echo "<tr><td class=\"Texto\" valign=\"top\" bgcolor=\"#e0e0e0\">";
   if ($_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador")
   echo "<input type=checkbox name=baneo[".$baneo['id']."]>";
   echo $baneo['ip']."</td><td class=\"Texto\" bgcolor=#e0e0e0 valign=\"top\">".$user."</td><td class=\"Texto\" valign=\"top\" bgcolor=\"#e0e0e0\">".$baneo['texto']."</td><td class=\"Texto\" valign=\"top\" bgcolor=\"#e0e0e0\">".$nick."</td><td class=\"Texto\" bgcolor=#e0e0e0 valign=\"top\">".$baneo['respuesta']."</td><td class=\"Texto\" valign=\"top\" bgcolor=\"#e0e0e0\">".$baneo['fecha']."</td></tr>";
   $n ++;
   }
echo "</table>";
}
?> 
</td>
</tr>
<? if ($_SESSION['iden'] != "Zafiro" && $_SESSION['iden'] != "Rubi" && $_SESSION['iden'] != "Moderador") { ?>
<tr>
<td align="center"><br>
<table cellpadding="1" cellspacing="0">
<tr>
<td><input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
</form>
<tr>
<td colspan="2" align="center" valign="bottom">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a> 
</td>
</tr>
</table> 
<? } ?> 
</td>
</tr>
</table> 
</td>
</tr>
</table> 
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->