<? include("acceder.php"); ?>
<table border="0" height=100% width="100%" bgcolor="#eeeeee" cellpadding="0" cellspacing="0">
<tr>
<td align="center" class="Texto" style="border-bottom: 1px solid <?=$bordetabla; ?>">
<?

if (isset($_POST['aceptar'])) {
  if (isset($_POST['mensaje'])) {
	$mensaje = $_POST['mensaje'];
	$query = "SELECT * FROM `mensajes`";
	$resp = @mysql_query($query);
    while ($texto = @mysql_fetch_array($resp)) {	  
      if ($mensaje[$texto['id']] == "on") {
			$id = "";
			$query2 = "INSERT INTO log_mensajes (id, usuario, texto, web, color, ip, fecha, nombre, tiempo) VALUES ('".$id."', '".$texto['usuario']."', '".$texto['texto']."', '".$texto['web']."', '".$texto['color']."', '".$texto['ip']."', '".$texto['fecha']."', '".$texto['nombre']."', '".$texto['tiempo']."')";
			@mysql_query($query2);
	   		$query2 = "DELETE FROM `mensajes` WHERE id = '".$texto['id']."'";
			@mysql_query($query2);
		}
    }
		
	echo "<font color=#cc0000>"._ERASEDMESSAGES."</font><br><a href=panel.php?mostrar=borrarmensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>"; 
	} else
	    echo "<font color=#cc0000>"._NOSELECTEDMESSAGES."</font><br><a href=panel.php?mostrar=borrarmensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>";
} else if ($_POST['todos']) {
	$query = "SELECT * FROM `mensajes`";
	$resp = @mysql_query($query);
    while ($texto = @mysql_fetch_array($resp)) {	
			$id = "";
			$query2 = "INSERT INTO log_mensajes (id, usuario, texto, web, color, ip, fecha, nombre, tiempo) VALUES ('".$id."', '".$texto['usuario']."', '".$texto['texto']."', '".$texto['web']."', '".$texto['color']."', '".$texto['ip']."', '".$texto['fecha']."', '".$texto['nombre']."', '".$texto['tiempo']."')";
			@mysql_query($query2);

    }
        $query = "TRUNCATE TABLE `mensajes`";
		@mysql_query($query);
		
		$query = "SELECT * FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'"; 
		$resp = @mysql_query($query);
		$usuario = @mysql_fetch_array($resp);
		$user_id = $usuario['id'];	
		$id = "";
		$fecha = Date("d.m.y");
		$fecha .= " "._AT." ";		
	    $fecha .= Date("H:i:s");
		
  // Cogemos la IP
  if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  else if ($_SERVER['HTTP_VIA'] != "") 
         $ip = $_SERVER['HTTP_VIA'];   
  else if ($_SERVER['REMOTE_ADDR'] != "") 
         $ip = $_SERVER['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 

			if (esAdmin($_SESSION['nnick'])) {
            	$color = $coloradmin; // admin
				if (esSuperAdmin($_SESSION['nnick']))  
			  		$color = $colorsuperadmin;
			}		
			
		$tiempo = microtime();
		$tiempo = explode(" ", $tiempo);
		$tiempo = $tiempo[1];	
		$query = "INSERT INTO mensajes (id, usuario, texto, web, color, ip, fecha, nombre) VALUES ('".$id."', '".$user_id."', '* Limpieza de mensajes *', '', '".$color."', '".$ip."', '".$fecha."', 'AutoMensaje', '".$tiempo."')";
		@mysql_query($query);
		
			   echo "<font color=#cc0000>"._ALLMESSAGESERASED."</font><br><a href=panel.php?mostrar=borrarmensajes&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>";
} else {
  
?>
<form name="formborrar" method="post" action="panel.php?mostrar=borrarmensajes&<? echo session_name()."=".session_id() ?>">
<table cellpadding="2" cellspacing="0" border="0">
<tr>
<td class="Texto" align="center"><font color="#cc0000"><?=_ERASEMESSAGES; ?></font></td>
</tr>
<tr>
<td class="Texto">
<input type="checkbox" name="selectodos" value="checkbox" onClick="seleccionarTodos(this);">&nbsp;<?=_CHECKEDALL; ?></td>
</tr>
</table>
</td>
</tr>
<tr>
<td height="100%" valign="top">
<table border="0" cellpadding="2" cellspacing="0" width="100%">
<?

$query = "SELECT * FROM `mensajes` order by id desc"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
	echo "<tr><td height=\"100%\" class=\"Texto\" align=\"center\">"._EMPTY."</td></tr>";
else {
$i = 0;
    while ($mensajes = mysql_fetch_array($resp)) {
     $nuevo = "";
     
     if ($i % 2 == 0)
	   $bg = $cpar;
     else
	   $bg = $cimpar;

         // Unimos el mensaje a etiquetas HTML y miramos si el usuario ha introducido una url o un email
        $web = $mensajes['web'];
        if (eregi("@", $web)) {
          $web = "mailto:".$web;
          $nuevo = "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
        }else if ($web != "" && $web != "http://") {
				if (!eregi("http://", $web)) {
					$web = "http://".$web;
					$nuevo = "<a href=".$web." class=\"EnlaceMenu\" target=\"_blank\"><i>";
				}
			}

        $nuevo .= "<font color=\"".$mensajes['color']."\" ";

        if ($activarIp == "on")
          $nuevo .= "title=\"".$mensajes['ip']."\"";

		if ($mensajes['usuario'] == -1)
			$nombre = $mensajes['nombre'];
		else {
			$query2 = "SELECT * FROM `usuarios` WHERE id = '".$mensajes['usuario']."'"; 
			$resp2 = @mysql_query($query2);
			$rows2 = @mysql_num_rows($resp2); 
			$user = @mysql_fetch_array($resp2);
			$nombre = $user['nick'];  
		}
		  
        $nuevo .= "><b>".$nombre."</b></font>";

        if ($web != "" && $web != "http://")
          $nuevo .= "</i></a>";

        $nuevo .= "<br> ".$mensajes['texto']."";

        if ($activarHora == "on")
          $nuevo .= "<br><font color=\"#cc0000\">".$mensajes['fecha']."</font>";

 	   $total = $nuevo;
 	   
       echo "<tr><td class=\"Texto\" style=\"background-color: ".$bg."; border-bottom: 1px solid ".$bordetabla."\">";
	   echo "<input type=checkbox name=mensaje[".$mensajes['id']."]>$total</td></tr>";
     $i ++;
    }
}
?>
</table>
</td>
</tr>
<tr>
<td align="center">
<table cellpadding="0">
<tr>
<td><input name="aceptar" type="submit" value="<?=_RESET; ?>" class="Boton">
<input name="todos" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
<tr>
<td align="center"><a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</form>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
