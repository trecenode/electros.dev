<? 

$query = "SELECT * FROM `colores`"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

while ($valor = @mysql_fetch_array($resp)) {
	  if ($valor['campo'] == "fondotabla")
	  	 $fondotabla = $valor['valor']; 
		 
	  if ($valor['campo'] == "bordetabla")	 		 
 	  	 $bordetabla = $valor['valor']; 
	  
	  if ($valor['campo'] == "colorfondo")
 	  	 $colorfondo = $valor['valor']; 
	  
	  if ($valor['campo'] == "bordecampo")
 	  	 $bordecampo = $valor['valor']; 
	  
	  if ($valor['campo'] == "fondocampo")
 	  	 $fondocampo = $valor['valor']; 
	  
	  if ($valor['campo'] == "cimpar")
 	  	 $cimpar = $valor['valor'];
	  
	  if ($valor['campo'] == "cpar")
 	  	 $cpar = $valor['valor'];
	  
	  if ($valor['campo'] == "colortexto")
 	  	 $colortexto = $valor['valor'];
	  
	  if ($valor['campo'] == "colorowners")
 	  	 $colorowners = $valor['valor'];
	  
	  if ($valor['campo'] == "colorvip")
 	  	 $colorvip = $valor['valor'];
	  
	  if ($valor['campo'] == "coloranonimo")
 	  	 $coloranonimo = $valor['valor']; 
	  
	  if ($valor['campo'] == "colormoderador")
 	  	 $colormoderador = $valor['valor'];
		 
	  if ($valor['campo'] == "colorbronze")
 	  	 $colorbronze = $valor['valor'];	 
		
	  if ($valor['campo'] == "colorzafiro")
 	  	 $colorzafiro = $valor['valor'];	
		 
	  if ($valor['campo'] == "colorrubi")
 	  	 $colorrubi = $valor['valor'];	  
		 
}
?>