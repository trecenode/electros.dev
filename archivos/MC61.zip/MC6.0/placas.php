<? include("acceder.php"); ?>
<table border="0" height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['censurar'])) {
  if ($_POST['codigo'] != "" && $_POST['imagen'] != "") {
    $id = "";
    $query = "INSERT INTO `smilies` (id, codigo, imagen) VALUES ('".$id."', '".$_POST['codigo']."', '".$_POST['imagen']."')";
	@mysql_query($query);
	echo "<div align=center><font color=\"#cc0000\">Placa a�adida</font><br><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></div>";
  } else 
    echo "<font class=\"Texto\">Has dejado alg�n campo vac�o<br></font><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `smilies`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<font class=\"Texto\">No hay placas<br></font><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['palabra'])) {
  echo "<font class=\"Texto\">No has seleccionado ninguna placa<br></font><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$palabra = $_POST['palabra'];
	$query = "SELECT * FROM `smilies`";
	$resp = @mysql_query($query);
    while ($censura = @mysql_fetch_array($resp)) {	  
      if ($palabra[$censura['id']] == "on") {
	   		$query2 = "DELETE FROM `smilies` WHERE id = '".$censura['id']."'";
			@mysql_query($query2);
		}
    }

	echo ""._ERASEDWORD."<br><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
		$query = "SELECT * FROM `smilies`";
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);

		if (!$rows)
          echo "<font class=\"Texto\">No hay placas<br></font><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `smilies`";
			@mysql_query($query);
	       echo "Todas las placas han sido borradas<br><a href=\"panel.php?mostrar=placas&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else {
  
?>
<table border="0" cellpadding="2" cellspacing="0">
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<form name="form" method="post" action="panel.php?mostrar=placas&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center" colspan="2"><font color="#cc0000">Control Placas</font></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"></td>
</tr>
<tr>
<td class="Texto" align="center">C�digo: </td><td><input type="text" name="codigo" size="15" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="center">Imagen(url): </td><td><input type="text" name="imagen" size="15" value="" class="Boton"></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"></td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"><input name="censurar" type="submit" value="Aceptar" class="Boton"></td>
</tr>
<? } ?>
<tr>
<td class="Texto" align="center" colspan="2">&nbsp;</td>
</tr>
<tr>
<td class="Texto" align="center" colspan="2"><font color="#cc0000">Placas</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center">
<?
$query = "SELECT * FROM `smilies` order by id";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table width=\"100%\">";
echo "<tr><td bgcolor=#6699cc></td><td class=\"Texto\" bgcolor=#6699cc>C�digo</td><td class=\"Texto\" bgcolor=#6699cc>Imagen</td></tr>";
$n = 0;
while ($palabras = @mysql_fetch_array($resp)) {
	if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro")
	echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><input type=checkbox name=palabra[".$palabras['id']."]></td>";
	echo "<td class=Texto bgcolor=\"#e0e0e0\" align=center>".$palabras['codigo']."</td><td align=center class=\"Texto\" bgcolor=\"#e0e0e0\"><img src=\"".$palabras['imagen']."\"></td></tr>";
   $n ++;
   }
echo "</table>";
}
?>  
</td>
</tr>
<? if ($_SESSION['iden'] != "Bronze" && $_SESSION['iden'] != "Zafiro") { ?>
<tr>
<td align="center" colspan="2">
<table cellpadding="1" cellspacing="0">
<tr>
<td><input type="submit" name="borrar" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" value="<?=_ALL; ?>" class="Boton" type="submit"></td>
</tr>
</table>
</td>
</tr>
<? } ?>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a>
</td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->