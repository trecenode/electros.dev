<?

  // Destruimos la sesion
  session_start();
  session_destroy();
  header("Location: ftag.php");
  
?>
