<? include("acceder.php");	 ?>
<table border=0 height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<?

if (isset($_POST['aceptar'])) {
  if ($_POST['newadmin'] != "" && $_POST['newpass'] != "" && $_POST['emailadmin'] != "") {
    $nick = trim(stripSlashes($_POST['newadmin']));
    $nick = str_replace(" ","",$nick);
    $clave = md5(trim(stripSlashes($_POST['newpass'])));
  
    if (!yaExiste($nick)) {
	  $id = "";
		$query = "INSERT INTO `usuarios` (id, nick, rol, pass, fecha_registro, censuras, email) VALUES ('".$id."', '".$nick."', '".$_POST['tipo']."', '".$clave."', '".date("d.m.y, H:i:s")."', '0', '". trim($_POST['emailadmin'])."')"; 
		@mysql_query($query);
      echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._REGISTEREDADMIN."</font></td></tr>";
    } else
        echo "<tr><td align=\"center\" class=\"Texto\"><font color=#cc0000>"._ERRORNICK."</font></td></tr>";
	  
  }
  
  if (isset($_POST['nick'])) {
		$nick = $_POST['nick'];
		$query = "SELECT * FROM `usuarios`";
		$resp = @mysql_query($query);
    	while ($user = @mysql_fetch_array($resp)) {	  
      		if ($nick[$user['id']] == "on") {
	   			$query2 = "UPDATE `usuarios` set rol = '".$_POST['tipo']."' WHERE id = '".$user['id']."'";
				@mysql_query($query2);
			}
    	}    

  echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._REGISTEREDADMIN."</font><br>";
  
  }
      if ($_POST['newadmin'] == "" && !isset($_POST['nick']))
        echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._NONICK."</font></td></tr>";
      if ($_POST['newpass'] == "" && !isset($_POST['nick']))
        echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._NOPASS."</font></td></tr>";  
	
	echo "<tr><td align=center><a href=\"panel.php?mostrar=admins&admin=".$_POST['tipo']."&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></td></tr>";
	
} else if (isset($_POST['borrar'])) {
             $query = "SELECT * FROM `usuarios` WHERE rol = '".$_POST['tipo']."'";
			 $resp = @mysql_query($query);
			 $rows = @mysql_num_rows($resp);

			 if (!$rows)
                  echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._NONADMIN."</font></td></tr>";
                else {

                    if (!isset($_POST['nadmins']))
                      echo "<tr><td class=\"Texto\" align=\"center\"><font color=#cc0000>"._NOSELECTEDADMIN."</font></td></tr>";
                    else {
	$nadmins = $_POST['nadmins'];
	$query = "SELECT * FROM `usuarios` WHERE rol = '".$_POST['tipo']."'";
	$resp = @mysql_query($query);
    while ($admin = @mysql_fetch_array($resp)) {	  
      if ($nadmins[$admin['id']] == "on") {
	   		$query2 = "DELETE FROM `usuarios` WHERE id = '".$admin['id']."'";
			@mysql_query($query2);
			$query2 = "UPDATE `mensajes` set usuario = '-1', nombre = '".$admin['nick']."' WHERE usuario = '".$admin['id']."'";
			@mysql_query($query2);
			$query2 = "UPDATE `log_mensajes` set usuario = '-1', nombre = '".$admin['nick']."' WHERE usuario = '".$admin['id']."'";
			@mysql_query($query2);
		}
    }
	                    echo "<tr><td align=\"center\" class=\"Texto\"><font color=#cc0000>"._ERASEDADMIN."</font></td></tr>";

                    }
                }
				echo "<tr><td align=center><a href=\"panel.php?mostrar=admins&admin=".$_POST['tipo']."&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></td></tr>";
	   } else if (isset($_POST['todas'])) {
             $query = "SELECT * FROM `usuarios` WHERE rol = '".$_POST['tipo']."'";
			 $resp = @mysql_query($query);
			 $rows = @mysql_num_rows($resp);

			 if (!$rows)
                  echo "<tr><td align=\"center\" class=\"Texto\"><font color=#cc0000>"._NONADMIN."</font></td></tr>";
                else {
				while ($user = @mysql_fetch_array($resp)) {
				$query2 = "UPDATE `mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
				@mysql_query($query2);
				$query2 = "UPDATE `log_mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
				@mysql_query($query2);
			}
				
                  $query = "DELETE FROM `usuarios` WHERE rol = '".$_POST['tipo']."'";
				  @mysql_query($query);
	              echo "<tr><td align=\"center\" class=\"Texto\"><font color=#cc0000>"._ALLADMINSERASED."</font></td></tr>";
                }   
				echo "<tr><td align=center><a href=\"panel.php?mostrar=admins&admin=".$_POST['tipo']."&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a></td></tr>";
	   }

  
?>
</table>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->