<? include("acceder.php"); ?>
<table border=0 height=100% width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<?

if (isset($_POST['borrar'])) {
$query = "SELECT * FROM `privados`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<br><font color=\"#cc0000\">No hay mensajes<br></font><a href=\"panel.php?mostrar=verprivados&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
else {

if (!isset($_POST['noticia'])) {
  echo "<br><font color=\"#cc0000\">No has seleccionado ning�n mensaje<br></font><a href=\"panel.php?mostrar=verprivados&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
} else {
	$noticia = $_POST['noticia'];
	$query = "SELECT * FROM `privados`";
	$resp = @mysql_query($query);
    while ($news = @mysql_fetch_array($resp)) {	  
      if ($noticia[$news['id']] == "on") {
	   		$query2 = "DELETE FROM `privados` WHERE id = '".$news['id']."'";
			@mysql_query($query2);
		}
    }

	echo "<br><font color=\"#cc0000\">Mensajes borrados</font><br><a href=\"panel.php?mostrar=verprivados&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";

        }
}
} else if (isset($_POST['todas'])) {
$query = "SELECT * FROM `privados`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
          echo "<br><font color=\"#cc0000\">No hay mensajes<br></font><a href=\"panel.php?mostrar=verprivados&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">"._RETURN."</a>";
        else {
			$query = "TRUNCATE TABLE `privados`";
			@mysql_query($query);
	       echo "<br><font color=\"#cc0000\">Todas los mensajes han sido borrados</font><br><a href=\"panel.php?mostrar=verprivados&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
        }
} else {
  
?>
<table border="0" cellpadding="0" cellspacing="0" height="75%" width="100%">
<form name="form" method="post" action="panel.php?mostrar=verprivados&<? echo session_name()."=".session_id() ?>">
<tr>
<td class="Texto" align="center" valign="top"><br><font color="#cc0000">Mensaje Privados</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center" valign="top">
<a href="panel.php?mostrar=enviarprivado&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu">[Nuevo]</a><br><br>
<?
$query = "SELECT * FROM `privados` WHERE receptor = '".$_SESSION['id']."' order by id desc";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
echo "<table border=\"0\" width=100%><tr><td class=\"Texto\" bgcolor=#6699cc></td><td class=\"Texto\" bgcolor=#6699cc>Asunto</td><td class=\"Texto\" bgcolor=#6699cc>Por</td><td class=\"Texto\" bgcolor=#6699cc>Fecha</td></tr>";
if (!$rows)
  echo "<tr><td colspan=4 class=Texto><div align=center>"._NONE."</div></td></tr>";
else {
$n = 0;
while ($noticia = @mysql_fetch_array($resp)) {
$query2 = "SELECT * FROM `usuarios` WHERE id = '".$noticia['autor']."'";
$resp2 = @mysql_query($query2);
$usuario = @mysql_fetch_array($resp2);
$nick = $usuario['nick'];
if ($noticia['leido'] == 0)
	$bgcolor = "#cccccc";
else
	$bgcolor = "#e0e0e0";

   echo "<tr><td class=\"Texto\" bgcolor=".$bgcolor."><input type=checkbox name=noticia[".$noticia['id']."]></td><td class=\"Texto\" bgcolor=".$bgcolor."><b><a href=\"panel.php?mostrar=leerprivado&id=".$noticia['id']."&".session_name()."=".session_id()."\" class=\"EnlaceMenu\">".$noticia['asunto']."</a></b></td><td class=\"Texto\" bgcolor=".$bgcolor.">".$nick."</td><td class=\"Texto\" bgcolor=".$bgcolor.">".$noticia['fecha']."</td></tr>";
   $n ++;
   }

}
echo "</table>";
?>  
</td>
</tr>
<tr>
<td align="center">
<table cellpadding="1" cellspacing="0">
<tr>
<td>
<input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?&<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
