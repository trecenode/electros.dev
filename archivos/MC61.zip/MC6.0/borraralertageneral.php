<?

session_start();
session_cache_limiter('nocache,private');
	
// verificamos que no entra directamente en la pagina
if ($_SERVER['HTTP_REFERER'] == "") {
   echo "Qu� haces!";
} else {
  include("conectar.php");
  $query = "TRUNCATE TABLE `alerta_general`";
  @mysql_query($query);
  header("Location: ftag.php?".session_name()."=".session_id());
  exit;
  }

?>