<?
session_cache_limiter('nocache,private');
session_start();

include("../configtag.php");
include("../language/lang-".$langactual.".php");
?>
<html>
<head>
<title>Ayuda</title>
<link rel="stylesheet" href="estilo.css" type="text/css">
<SCRIPT LANGUAGE="JavaScript">
function menu(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=540,height=500,left = 152,top = 134');");
}
</script>
</head>
<body topmargin="0" leftmargin="0">
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="305" height="263" background="index_fondo.gif">
    <tr>
      <td width="100%" valign="top" align="center" class="Texto">
        <br><b>Ayuda</b>
        <div align="right">
		<?
		  		switch($_GET['p']) {
					case alerta:
						include("alertas.php");
						break;
					case preguntas:
						include("preguntas.php");
						break;	
					case privacidad:
						include("privacidad.php");
						break;		
					case seguridad:
						include("seguridad.php");
						break;		
					case reglas:
						include("reglas.php");
						break;	
					case mods:
						include("mods.php");
						break;		
					case club:
						include("club.php");
						break;		
					default:
					?>
					<table border="0" cellpadding="0" cellspacing="0" width="75%">
            <tr>
              <td width="100%"><br><br><b>�Problemas?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> 
			 <a href="?p=alerta" class="menu"><font color="#A12A36">MoD, ay�dame!</font></a><br><br>
              <font color="#000000"><b>Opciones:<br></b></font>
			  <a href="?p=mods" class="menu">Lista de MoDs</a><br>
			  <a href="?p=club" class="menu">Miembros del Club</font></a><br>
			  <a href="#" class="menu">Control de placas</a><br>
			  <a href="?p=preguntas" class="menu">Preguntas</a><br>
			  <a href="#" class="menu">Ser un MoD</a><br>
			  <a href="?p=seguridad" class="menu">Seguridad</a><br>
			  <a href="?p=reglas" class="menu">Las reglas del Mini Chat</a><br>
			  <a href="?p=privacidad" class="menu">Privacidad</a><br></td>
            </tr>
          </table>
					<?
						break;
		     }
		  ?>
        </div>
        <p align="center">&nbsp;</p></td>
  </tr>
  </table>
</div>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->