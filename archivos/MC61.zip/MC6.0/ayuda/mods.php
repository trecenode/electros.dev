<? include("../colores.php"); ?>
<div align="right"><br><br>
<table border="0" cellpadding="0" cellspacing="0" width="80%" height="76%">
<tr>
	<td><b>Lista de MoDs</b>
</td>
</tr>
<tr>
	<td valign="top"><br>
	<div style="width: 230px; height: 150px; overflow: auto;">
	<b>
	<table><tr><td>
<?

$query = "SELECT * FROM `usuarios` WHERE rol = 'Owner'"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid black\">Owners</td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><font color=".$colorowners.">".$user['nick']."</font></td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = 'Moderador' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid black\">Moderadores</td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><font color=".$colormoderador.">".$user['nick']."</font></td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = 'Rubi' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid black\">Rubis</td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><font color=".$colorrubi.">".$user['nick']."</font></td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = 'Zafiro' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid black\">Zafiros</td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><font color=".$colorzafiro.">".$user['nick']."</font></td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = 'Bronze' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 
echo "<tr><td class=\"Texto\" style=\"border-bottom: 1px solid black\">Bronzes</td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\" bgcolor=\"#e0e0e0\"><font color=".$colorbronze.">".$user['nick']."</font></td></tr>";
}

?>	
</td></tr></table>
	</b>
	</div>
</td>
</tr>
<tr>
<td align="center">
<a href="index.php" class="menu">volver</a>
</td>
</tr>
</table>
</div>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
