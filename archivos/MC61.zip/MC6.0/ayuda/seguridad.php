<?

$query = "SELECT * FROM `contenido` WHERE pagina = 'seguridad'";
$resp = @mysql_query($query);
$pagina = @mysql_fetch_array($resp);
?>
<div align="right"><br><br>
<table border="0" cellpadding="0" cellspacing="0" width="80%" height="76%">
<tr>
	<td><b>Seguridad</b>
</td>
</tr>
<tr>
	<td valign="top"><br>
	<div style="width: 230px; height: 150px; overflow: auto;">
	<b><?=$pagina['valor']; ?></b>
	</div>
</td>
</tr>
<tr>
<td align="center">
<a href="index.php" class="menu">volver</a>
</td>
</tr>
</table>
</div>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
