<?
include("../configtag.php");
if (isset($_POST['avisar'])) {
   if ($_POST['mensaje'] != "" && $_POST['email'] != "") {
   	  $id = "";
	    // Cogemos la IP
  if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  else if ($_SERVER['HTTP_VIA'] != "") 
         $ip = $_SERVER['HTTP_VIA'];   
  else if ($_SERVER['REMOTE_ADDR'] != "") 
         $ip = $_SERVER['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 
		 
  if (isset($_SESSION['nnick'])) {
  	$query = "SELECT * FROM `usuarios` WHERE nick = '".$_SESSION['nnick']."'";
	$resp = @mysql_query($query);
	$usuario = @mysql_fetch_array($resp);
	$nick = $usuario['id'];
  } else
    $nick = "-1";		 
		 
   	  $query = "INSERT INTO `alerta_mod` (id, texto, email, ip, fecha, nick, leido) values ('".$id."', '".htmlentities($_POST['mensaje'])."', '".htmlentities($_POST['email'])."', '".$ip."', '".Date("d.m.y, H:i:s")."', '".$nick."', '0')";
	  @mysql_query($query);
	  ?>
	  <table border="0" cellpadding="0" cellspacing="0" width="95%">
            <tr>
              <td width="90%" align="center"><br><br>
			  <font color=#cc0000>Alerta enviada<br> un MoD te contestar� tan<br> pronto como sea posible</font><br>
			  <a href="index.php" class="menu">volver</a>
              </td>
              <td>
              </td>
            </tr>
          </table>
	  <?
   } else {
   	header("location: index.php?p=alerta");
	exit;
   }
} else {
?>
<table border="0" cellpadding="0" cellspacing="0" width="75%">
            <tr>
              <td width="100%"><br><br><b>Enviar alerta a un MoD<br></b>
                </font>
              </td>
              <td>
              </td>
            </tr>
          </table>
        </div><br>
		<form method="POST" action="index.php?p=alerta">
        <b>T� email:</b><br>
		<input type="text" name="email" maxlength="30" size="40" value=""  class="boton">
		<br><b>Mensaje</b><br>
		<textarea rows="5" class="boton" name="mensaje" cols="40"></textarea><br>
		<input type="hidden" name="ip" value="<?=$ip?>">
		<input type="submit" value="Avisar" class="boton" name="avisar">
		<br><br><a href="javascript:history.back(1)" class="menu"><b><font color="#111111">volver</font></b></form>
		<? } ?>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->