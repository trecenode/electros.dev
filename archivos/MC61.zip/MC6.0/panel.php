<?

session_start();
session_cache_limiter('nocache,private');

include("funciones.php");
include("acceder.php");
include("colores.php");

?>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Description" content="Minichat v<?=$version; ?>">
<meta name="Author" content="Rott">
<meta name="Generator" content="Minichat v<?=$version; ?>">
   <title>Minichat v<?=$version; ?></title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
<script language="javascript">
<? include("funciones.js"); ?>
</script>
<style type="text/css">
<!--
.CampoTexto { 
   font-size: 10px; 
   font-family: verdana; 
   border: 1px solid <? echo $bordecampo; ?>; 
   background: <? echo $fondocampo; ?>;

}
.Texto {
   font-family: Verdana; 
   font-size: 10px; 
   font-weight: normal;
   color: <?=$colortexto; ?>;
}

-->
</style>
</head> 
<body bgcolor="<?=#FFFFFF; ?>">
<div align="center">
<table border="0" cellpadding="1" cellspacing="0">
<tr>
<td>
<?  
if (isset($_SESSION['nnick'])) {
	if (esAdmin($_SESSION['nnick']))
		include ("admintag.php");
} else
	include ("entraradmin.php");
?>
</td>
</tr>
</table>
</div>
</body>
</html>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->
