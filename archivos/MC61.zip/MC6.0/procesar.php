<?

session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("colores.php");
include("funciones.php");
include("language/lang-".$langactual.".php");

// Enviamos el mensaje  
if (isset($_POST['enviar'])) {

  // Cogemos la IP
  if ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];   
  else if ($_SERVER['HTTP_VIA'] != "") 
         $ip = $_SERVER['HTTP_VIA'];   
  else if ($_SERVER['REMOTE_ADDR'] != "") 
         $ip = $_SERVER['REMOTE_ADDR'];  
       else 
         $ip = _UNKNOWIP; 
  
  // Miramos si esta baneado
  if (estaBaneado($ip)) { 
  	 $error = _NOWRITE;
  } else {	
  	$error = "";
	if (!isset($_SESSION['nnick'])) {
	   $nick = str_replace(" ","",stripSlashes($_POST['nick']));
	   $nick = str_replace("�","",$nick);
	   $existe = comprobarNick(htmlentities($nick), $_POST['clave']);
	   if ($existe != "-1" && $existe != "0") {
	     $_SESSION['nnick'] = $existe;
		 $nick = $existe;
		 $existeNick = "true"; 
	   } else if ($existe == "-1")
	   	 	  	 $error = _INCORRECTPASS;
    } else {
	  	$nick = $_SESSION['nnick'];  
		$existeNick = "true";
	}
	
	$fecha2 = microtime();
	$fecha2 = explode(" ", $fecha2);
	$fecha2 = $fecha2[1];
    
	if ($existeNick == "true");
	else
	
	$mensaje = str_replace("�","",trim(stripSlashes($_POST['mensaje'])));
	
    if ($mensaje !=_MESSAGE && $mensaje != "" && $nick != _NICKNAME && $nick != "" && $error == "") {

	  if (isset($_POST['url']))
        $url = str_replace("�","",$_POST['url']);
	  
	  if (esAdmin(htmlentities($nick)))
		$esAdmin = "true";	  
	  
		$query = "SELECT * FROM `flood` WHERE ip = '$ip'"; 
		$resp = @mysql_query($query);
		$rows = @mysql_num_rows($resp);
		
	  if ($rows) {
	  	 $flood = @mysql_fetch_array($resp);
		 $difseg = $fecha2 - $flood['tiempo'];
		 if ($difseg < $esperar && $esAdmin != "true")
		   $error = _FLOOD;	
	  	 else {
	        $error = guardarMensaje($nick, $mensaje, $url, $ip);
			if ($esAdmin != "true")
			  actualizarIp($fecha2, $ip);
			}
	  } else {
	  	 $error = guardarMensaje($nick, $mensaje, $url, $ip);
		 if ($esAdmin != "true")
		   actualizarIp($fecha2, $ip);
	  }
	  actualizarIps($esperar);
  
    } else {
      if ($nick == _NICKNAME || $nick == "")
	  	 $error = _NONICK;
	  else if ($mensaje == _MESSAGE || $mensaje == "")
	  	 $error = _NOMESSAGE;
    } 
  }
  
  if ($error != "") {
  	 header("Location: ftag.php?mostrar=error&error=".$error."&n=".$nick."&u=".$url."&".session_name()."=".session_id());
  	 exit;
  } else {
     header("Location: ftag.php?mostrar=tag&n=".$nick."&u=".$url."&".session_name()."=".session_id());
  	 exit;
  }
  
} else if (isset($_POST['actualizar'])) {
  	   	  header("Location: ftag.php?&".session_name()."=".session_id());
		  exit; 
}

?>
