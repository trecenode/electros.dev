<? include("acceder.php"); ?>
<table border="0" cellPadding="0" cellSpacing="0" bgcolor="#eeeeee">
<tr>
<td class="Texto" align="center"><font color="#cc0000">Atender MoD Alert</font></td>
</tr>
<tr>
<td class="Texto" colspan="2" align="center" valign="top"><br>
<?

if (isset($_POST['dejar'])) {
		$query = "UPDATE `alerta_mod` SET leido = '0' WHERE texto = '".$_POST['mensaje']."'";
		@mysql_query($query);
		echo "<font color=#cc0000>La alerta ha vuelto a la lista para que otro MoD la puede atender</font><br><a href=\"panel.php?mostrar=alertasmod&".session_name()."=".session_id()."\" class=EnlaceMenu>"._RETURN."</a>";
} else if (isset($_GET['mensaje'])) {
	$query = "UPDATE `alerta_mod` SET leido = '1' WHERE texto = '".$_GET['mensaje']."'";
	@mysql_query($query);
}

if (!isset($_POST['dejar'])) {
?>
            <table border="0" borderColor="#000000" cellPadding="1" cellSpacing="0" style="BACKGROUND-COLOR: #cdcdcd; BORDER-BOTTOM: 1px solid; BORDER-LEFT: 1px solid; BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid" width="80%">
                <tr>
                  <td class="Texto" width="100%"><div align="left">Mensaje original:</div>
                    <?=$_GET['mensaje']; ?>
                  </td>
                </tr>
            </table>
            <table border="0" cellPadding="0" cellSpacing="0">
              <tbody>
                <tr>
                  <td width="100%" class="Texto" align="center">
                    <form method="POST" action="panel.php?mostrar=enviarrespuesta&<? echo session_name()."=".session_id() ?>">
                      <b><br>
                      Respuesta de: <?=$_SESSION['nnick']; ?><br></b>
					  <textarea rows="6" class="boton" name="respuesta" cols="38"></textarea><br>
                      <input type="submit" value="Enviar respuesta" name="enviar" class="boton">
                      <input type="hidden" name="email" value="<?=$_GET['email']; ?>">
					  <input type="hidden" name="mensaje" value="<?=$_GET['mensaje']; ?>">
					  <input type="hidden" name="modnombre" value="<?=$_SESSION['nnick']; ?>">
					  <input type="hidden" name="mod" value="<?=$_SESSION['id']; ?>">
					  <input type="hidden" name="ip" value="<?=$_GET['ip']; ?>">
					  <input type="hidden" name="nick" value="<?=$_GET['nick']; ?>">
                    </form>
                  </td>
                </tr>
              </tbody>
            </table>
<form method="POST" action="panel.php?mostrar=atender&<? echo session_name()."=".session_id() ?>">
<input type="hidden" name="mensaje" value="<?=$_GET['mensaje']; ?>">
<hr width="90%" size="1" color="#2E4252">
<input type="submit" value="Dejar que otro MoD atienda la alerta" name="dejar" class="boton"><br>
Si aprietas este bot�n se mantendr� la alerta para que otro MoD la pueda atender.
<hr width="90%" size="1" color="#2E4252">
</form>
<? } ?>
</td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->