<?

if (isset($_GET['mostrar']))
	$_GET['mostrar'] = $_GET['mostrar'].".php";
else {
	 	if (!isset($_SESSION['iden'])) {
		   $iden = idenAdmin($_SESSION['nnick']); 
   		   $_SESSION['iden'] = $iden;
  		}
	 	$_GET['mostrar'] = "configuracion.php";
}

?>
