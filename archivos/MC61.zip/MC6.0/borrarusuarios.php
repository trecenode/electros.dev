<? include("acceder.php"); ?> 
<table border="0" height="100%" width="100%" bgcolor="#eeeeee">
<tr>
<td align="center" class="Texto" valign="top">
<table border="0" cellpading="0" width="100%">
<tr>
<td align="center" class="Texto"> 
<? 
if (isset($_GET['nick'])) {
	$nick = $_GET['nick'];
	$query = "SELECT id FROM `usuarios` WHERE nick = '".$nick."'";
	$resp = @mysql_query($query);
	$user = @mysql_fetch_array($resp);
	$query = "DELETE FROM `usuarios` WHERE nick = '".$nick."'";
	@mysql_query($query);
	$query = "UPDATE `mensajes` set usuario = '-1', nombre = '".$nick."' WHERE usuario = '".$user['id']."'";
	@mysql_query($query);
	$query = "UPDATE `log_mensajes` set usuario = '-1', nombre = '".$nick."' WHERE usuario = '".$user['id']."'";
	@mysql_query($query);

  echo "<font color=#cc0000>"._ERASEDNICK."</font><br><a href=\"panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()."\"";
  echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 

} else if (isset($_POST['borrar'])) { 

$query = "SELECT * FROM `usuarios`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
   echo "<font class=\"Texto\">"._NOSELECNICK."<br>";
   echo "</font><a href=\"panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()."\"";
   echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
} else { 
  if (!isset($_POST['nick'])) { 
  	 echo "<font class=\"Texto\">"._NOSELECNICK."<br>";
	 echo "</font><a href=\"panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()."\"";
	 echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
  } else { 
	$nick = $_POST['nick'];
	$query = "SELECT * FROM `usuarios` WHERE rol = '0'";
	$resp = @mysql_query($query);
    while ($user = @mysql_fetch_array($resp)) {	  
      if ($nick[$user['id']] == "on") {
	   		$query2 = "DELETE FROM `usuarios` WHERE id = '".$user['id']."'";
			@mysql_query($query2);
			$query2 = "UPDATE `mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
			@mysql_query($query2);
			$query2 = "UPDATE `log_mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
			@mysql_query($query2);
		}
    }

  echo _ERASEDNICK."<br><a href=\"panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()."\"";
  echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 

  } 
} 
?>
</td>
</tr>
<?
} else if (isset($_POST['todas'])) { 
?>
<tr>
<td align="center" class="Texto"> 
<?
$query = "SELECT * FROM `usuarios`";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows) {
   	 echo "<font class=\"Texto\">"._NOSELECNICK."<br>";
   	 echo "</font><a href=\"panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()."\"";
   	 echo " class=\"EnlaceMenu\">"._RETURN."</a>"; 
  } else { 
  			while ($user = @mysql_fetch_array($resp)) {
				$query2 = "UPDATE `mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
				@mysql_query($query2);
				$query2 = "UPDATE `log_mensajes` set usuario = '-1', nombre = '".$user['nick']."' WHERE usuario = '".$user['id']."'";
				@mysql_query($query2);
			}

  	$query = "DELETE FROM `usuarios` WHERE rol = '0'";
	@mysql_query($query); 
  	echo _ERASEDALL."<br>";
  	echo "<a href=panel.php?mostrar=borrarusuarios&".session_name()."=".session_id()." class=EnlaceMenu>"._RETURN."</a>"; 
  } 
?>
</td>
</tr>
<?
} else { 

?> 
<tr>
<td class="Texto" align="center"><font color="#cc0000"><?=_ERASEUSER; ?></font></td>
</tr>
<tr>
<td align="center" class="Texto"> 
<table border="0" cellpadding="2" cellspacing="0"> 
<form name="form" method="post" action="panel.php?mostrar=borrarusuarios&<? echo session_name()."=".session_id() ?>"> 
<tr><td class="Texto" colspan="2"> 
<?
$query = "SELECT * FROM `usuarios` WHERE rol = '0' order by id";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);

if (!$rows)
  echo "<div align=center>"._NONE."</div>";
else {
echo "<table>";
$n = 0;
while ($user = @mysql_fetch_array($resp)) {
   echo "<tr><td class=\"Texto\"><input type=checkbox name=nick[".$user['id']."]>".($n+1).". ".$user['nick']."</td></tr>";
   $n ++;
   }
echo "</table>";
}
?> 
</td>
</tr>
<tr>
<td>
<table cellpadding="1" cellspacing="0">
<tr>
<td><input name="borrar" type="submit" value="<?=_RESET; ?>" class="Boton"></td>
<td><input name="todas" type="submit" value="<?=_ALL; ?>" class="Boton"></td>
</tr>
</table>
</td>
</tr>
</form>
<tr>
<td colspan="2" align="center">
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu"><?=_RETURN; ?></a> 
</td>
</tr>
</table> 
<? } ?> 
</td>
</tr>
</table> 
</td>
</tr>
</table> 
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->