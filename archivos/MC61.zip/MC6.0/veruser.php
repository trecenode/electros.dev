<table border="0" cellpadding="2" cellspacing="2" width="100%" bgcolor="#cccccc" 
height="100%" style="border: 1px solid <? echo $bordetabla; ?>">
<tr>
<td class="Texto" align="center" valign="top">
<? if ($activarReg == "on") { ?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td class="Texto" align="center"><font color="#cc0000"><?=_REGISTEREDUSERS; ?></font></td></tr>
<tr>
<td valign="top" height="100%"><table border="0" cellpadding="2" cellspacing="2" width="100%" height="100%">
<?

$query = "SELECT * FROM `usuarios` WHERE rol = 'manager'"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 

echo "<tr><td class=\"Texto\"><b>Managers:</b></td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\">".$user['nick']."</td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = 'admin' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 

echo "<tr><td class=\"Texto\"><b>Administradores:</b></td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\">".$user['nick']."</td></tr>";
}

$query = "SELECT * FROM `usuarios` WHERE rol = '0' order by id"; 
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp); 

echo "<tr><td class=\"Texto\"><b>Usuarios:</b></td></tr>";
while ($user = @mysql_fetch_array($resp)) { 
echo "<tr><td class=\"Texto\">".$user['nick']."</td></tr>";
}
   
echo "</table>";   
?>
</td></tr>
</table>
<? } else { ?>
<?=_DISABLED; ?>
<? } ?>
</td>
</tr>
<tr><td align="center" height="100%" valign="bottom">
<a href="ftag.php?mostrar=opciones&<? echo session_name()."=".session_id() ?>" 
class="EnlaceMenu"><?=_RETURN; ?></a></td>
</tr>
</table>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->