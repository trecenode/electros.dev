<?

session_start();
session_cache_limiter('nocache,private');

include("configtag.php");
include("lanzaralerta.php");
include("lanzaralertageneral.php");
include("colores.php");
include("funciones.php");
include("language/lang-".$langactual.".php");
?>

<? if ($activarMant == "off") { ?>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="Description" content="Minichat v<?=$version; ?>">
<meta name="Author" content="Rott">
<meta name="Generator" content="Minichat v<?=$version; ?>">
   <title>Minichat v<?=$version; ?></title> 
<link REL="STYLESHEET" HREF="style.css" TYPE="text/css">
<script language="javascript">
<? include("funciones.js"); ?>
function catalogo(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,menubar=0,resizable=0,width=460,height=470,left = 152,top = 134');");
}

function ayuda(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,menubar=0,resizable=0,width=307,height=263,left = 152,top = 134');");
}

</script>
<style type="text/css">
<!--
.CampoTexto { 
   font-size: 10px; 
   font-family: verdana; 
   border: 1px solid <? echo $bordecampo; ?>; 
   background: <? echo $fondocampo; ?>;

}
.Texto {
   font-family: verdana; 
   font-size: 10px; 
   font-weight: normal;
   color: <?=$colortexto; ?>;
}

-->
</style>
</head> 
<body bgcolor="<?=$colorfondo; ?>">
<table border="0" cellpadding="1" cellspacing="0">
<tr>
<td align="center">
<table border="0" cellpadding="0" cellspacing="0" width="180">
<tr>
<td background="img/fondo.gif" align="center" class="Texto" width="180">
<? 
if (isset($_SESSION['nnick']) && esAdmin($_SESSION['nnick'])) { 
$query = "SELECT * FROM `alerta_mod` WHERE leido = '0'";
$resp = @mysql_query($query);
$rows = @mysql_num_rows($resp);
if ($rows) {
?>
&nbsp;<a href="panel.php?mostrar=alertasmod&<? echo session_name()."=".session_id() ?>" target="_blank" class="EnlaceMenu"><span style="font-family: Trebuchet MS; font-size: 16px;"><b><font color="#ffcc00">[MoD Alert]</font></b></span></a>
<? } else { ?>
&nbsp;<span style="font-family: Trebuchet MS; font-size: 16px; color:red;"><b>[MoD Alert]</b></span>
<?
}
  if (!isset($_SESSION['iden'])) {
	$iden = idenAdmin($_SESSION['nnick']); 
   	$_SESSION['iden'] = $iden;
	$id = idAdmin($_SESSION['nnick']);
	$_SESSION['id'] = $id;
  }
  
?>
<br>
<a href="panel.php?<? echo session_name()."=".session_id() ?>" class="EnlaceMenu" target="_blank"><span style="font-family: Trebuchet MS; font-size: 11px; color:white;"><b>Panel</b></span></a><? } ?>
</td><td align="right" background="img/fondo.gif"><a href="javascript:catalogo('catalogo');"><img src="img/catalogo.gif" border="0"></a><a href="javascript:ayuda('ayuda');"><img src="img/interrogante.gif" border="0"></a></td>
</tr>
</table>
</td>
</tr>
<tr>
<td>
<? 
include ("main.php"); 
if ($_GET['mostrar'] == "tag.php") {
?>
<iframe marginwidth="0" marginheight="0" src="tag.php?<?=session_name()."=".session_id(); ?>" frameborder="0" width="180" height="350" scrolling="yes" name="iframe"></iframe>

<?
} else {
?>
<div class="frame">
<? include($_GET['mostrar']); ?>
</div>
<? } ?>
</td>
</tr>
<form onSubmit="return enviado()" method="post" 
action="procesar.php?<? echo session_name()."=".session_id() ?>" name="tag">
<tr>
<td align="center" class="Texto">
<? 

if (isset($_SESSION['nnick'])) {
 echo _WELLCOME." <b>"; 
 if (isset($_SESSION['nnick'])) 
 	echo $_SESSION['nnick']; 
 else if (isset($_POST['nick'])) 
 	  	 echo $_POST['nick']; 
 echo "</b> <a href=\"logout.php\" class=\"EnlaceMenu\">"._LOGOUT."</a>&nbsp;";
 } else { 

if ($activarReg == "on")
	$size = "17";
else 
	$size = "30";

if (!isset($_GET['n']) || $_GET['n'] == "")
	$nick =_NICKNAME;
else
	$nick = $_GET['n'];

?> 
<input name="nick" value="<?=$nick; ?>"  size="19" class="CampoTexto"
maxlength="<? echo $maxNick; ?>" onfocus="borrarNick();" onclick="borrarNick();">
<? if ($activarReg == "on") { ?>
<input name="clave" value="<?=_PASSWORD; ?>" size="9" maxlength="10" type="Password" 
onfocus="borrarClave();" class="CampoTexto"><? } ?><? } ?>&nbsp;</td>
</tr>
<? if ($activarUrl == "on") {
if (!isset($_GET['u']) || $_GET['u'] == "")
	$web = "http://";
else
	$web = $_GET['u'];
?>
<tr>
<td align="center">
	<input name="url" value="<?=$web; ?>" size=33 class="CampoTexto"></td>
</tr>
<? } ?>
<tr>
<td align="left" class="Texto">
	<input name="mensaje" size=27 value="<?=_MESSAGE; ?>" class="CampoTexto" onfocus="borrarMensaje();"
	maxlength="<? echo $maxMsg ?>" onKeyPress="charsleft(this);" onKeyDown="charsleft(this);"
	onBlur="charsleft(this);" onKeyUp="charsleft(this);" onFocus="charsleft(this);" wrap="VIRTUAL"
	onChange="charsleft(this);">&nbsp;<input class="CampoTexto" size="2" value="<? echo $maxMsg ?>" name="num"
	readonly>
</td>
</tr>
<tr>
<td align="center">
	<input class="Boton" type="submit" value="<?=_SEND; ?>" name="enviar">
	<input class="Boton" type="Reset" value="<?=_RESET; ?>" name="borrar">
</form>
</tr>
</table>
</body>
</html>
<? } else { ?>
<body bgcolor="#82A1D9">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center">
<img border="0" src="img/mantenimiento.gif">&nbsp; </p>
<? } ?>
<script language="Javascript">
var vie=
parseFloat(navigator.appVersion.slice(navigator.appVersion.indexOf("MSIE")+4,navigator.appVersion.length));
function sinmenu()
{
event.cancelBubble = true;
event.returnValue = false;
return false;
}
function noclicderecho(e)
{ 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) return false;
else
if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) 
{ 
if (vie < 5) // -- para el IE4 -- \\
{
alert('Puedes personalizar este mensaje');
return false;
}
else
if (vie >= 5) // -- para el IE5 -- \\
{
document.oncontextmenu = sinmenu;
return false;
}
}
return true;
} 
document.onmousedown=noclicderecho;

// -- Desabilita el clic derecho en las capas (layers) -- \\

if (document.layers)window.captureEvents(Event.MOUSEDOWN); 
window.onmousedown=noclicderecho;
</script>
<!--webbot bot="HTMLMarkup" endspan --><!--webbot bot="HTMLMarkup" startspan --><script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script><!--webbot bot="HTMLMarkup" endspan -->