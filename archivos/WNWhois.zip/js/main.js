function checkDomain()
 {

		 d = new Date(); now = d.getTime();
		 var url = 'whois.php?domain=' + document.getElementById('domain').value;
		 ajax ( url, handleInfo );  

 }

function handleInfo()
 {
	
	if(http.readyState == 1)
	 {
		document.getElementById('submit').disabled = true;
		document.getElementById('result').innerHTML = 'Revisando la base de datos WHOIS...';
	 }

	if(http.readyState == 4)
	 {
		var response = http.responseText;
		document.getElementById('submit').disabled = false;
		document.getElementById('result').innerHTML = response;
	 }
 }



