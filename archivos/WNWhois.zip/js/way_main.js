function createRequestObject()
{
	var request_;
	var browser = navigator.appName;
	
	if(browser == "Microsoft Internet Explorer")
	{
		request_ = new ActiveXObject("Microsoft.XMLHTTP");
	}
	else
	{
		request_ = new XMLHttpRequest();
	}
	
return request_;
}


var http = createRequestObject();

function ajax ( url, callback )
{
	http.open ( 'get', url, true );

	http.onreadystatechange = callback;

	http.send(null);

}