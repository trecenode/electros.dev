<?PHP
/*
 #
 # Revisa el Dominio para poder verificarlo
 #
*/


#
# Sacamos el dominio para poder revisarlo
#
$domain = explode ( '.', $_GET['domain'] );


#
# Luego, revisamos que haya algo para revisar..
#
if ( empty ( $_GET['domain'] ) )
 {
	echo 'Debe escribir un dominio para poder revisarlo.';
	exit;
 }


#
# Si el dominio contiene http://? damos error
#
if ( preg_match( '/http:\/\//i', $domain[0] ) )
 {
	echo 'El dominio no puede contener http://';
	exit;
 }

#
# Incluyendo el www.
#
if ( $domain[0] == 'www' )
 {
	echo nl2br ( shell_exec ( 'whois '.escapeshellarg ( $domain[1].'.'.$domain[2] ).'' ) );
 }
else
 {
	echo nl2br ( shell_exec ( 'whois '.escapeshellarg ( $_GET['domain'] ).'' ) );
 }

?>