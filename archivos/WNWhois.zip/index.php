<?
/**********************************
WnWhois v1.1.0
Copyright 2006 Erick Vallenas.
Last Updated: 08/02/2006
***********************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
 <head>
  <title>WaypointNet WHOIS v.1.1.0</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <meta http-equiv="Cache-Control" content="no-cache" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta name="robots" content="all" />

  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="js/way_main.js"></script>
 </head>

 <body>
  <h1><a href='./index.php'>WaypointNet.</a></h1>
  <div id='main'>
	<p>Dominio:<br />
	  <input type='text' name='domain' id='domain' size='40' />
	  <input type='button' id='submit' value='Check!' onclick='checkDomain(); return false;' />
    </p>
	<form action='' method='get' onsubmit='checkDomain(); return false;'>
	</form>
	<div id='result'> </div>
  </div>
<p>&copy; Waypointnet.com 2005 - 2006</p>
 </body>
</html>