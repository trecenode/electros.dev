<?
$titulo = "Elegi una opcion"; //titulo de la encuesta
$archivo = "votos.txt";     //archivo donde se guardan los votos
$archivoip = "ips.txt";		//archivo donde se guardan las ip's de los que votan
?>