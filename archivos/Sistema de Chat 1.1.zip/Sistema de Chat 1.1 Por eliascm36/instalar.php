<form name="form1" method="post" action="instalar.php">
Si no tienes el eforo:
  <input name="instalar" type="submit" id="instalar" value="Instalar">
</form>
<form name="form1" method="post" action="">
Si tienes el eforo:
  <input name="instalar2" type="submit" id="instalar2" value="Instalar">
</form>
<?
if($instalar){
include("config.php") ;
mysql_query("
#Esta tabla es para subir la informacion a la base de datos:
CREATE TABLE `chat` (
`id` VARCHAR( 255 ) NOT NULL ,
`usuario` VARCHAR( 255 ) NOT NULL ,
`texto` VARCHAR( 255 ) NOT NULL
);
# Si tienes instalado el eforo no es necesario crear esta tabla:

create table eforo_enlinea (
  fecha int(10) unsigned not null,
  ip varchar(15) not null,
  id_usuario smallint(5) not null,
  key fecha (fecha)
)
");
echo "Se a instalado correctamente. Recuerda borrar el instalador." ;
}
if($instalar2){
include("config.php") ;
mysql_query("
#Esta tabla es para subir la informacion a la base de datos:
CREATE TABLE `chat` (
`id` VARCHAR( 255 ) NOT NULL ,
`usuario` VARCHAR( 255 ) NOT NULL ,
`texto` VARCHAR( 255 ) NOT NULL
); ");
echo"Se a instalado correctamente. Recuerda borrar el instalador." ;
}
?>