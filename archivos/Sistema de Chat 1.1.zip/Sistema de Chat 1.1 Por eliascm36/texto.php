<?
//************************************
//***********Realizado Por:***********
//**************eliascm36**************
//***************Email:***************
//************************************
//***************Version:*************
//*****************1.0****************
//************************************
?>
<!-- se refressca, se actualiza en tantos segundos -->
<meta http-equiv="refresh" content="5">
<!-- va a hacia otra pagina en tantos segundos -->
<meta http-equiv="refresh" content="8;URL=texto.php">
<? include("config.php") ?>
<?
$consulta = mysql_query("select * from chat order by id desc") ;
while($datos = mysql_fetch_array($consulta)) { 
?>
<strong><? echo $datos[usuario] ?>:</strong><? echo $datos[texto] ?><br>
<? } ?>
