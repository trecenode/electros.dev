<? 

$nombredescargas = "descargas_admin.php"; 

$host = "localhost"; 
$user = "nombreDeUSuarioDelaBD"; 
$pass = "TuPassAlaBD"; 
$db = "NombreDelaBD"; 

//conecta a mysql 
$conecta = mysql_connect($host,$user,$pass); mysql_select_db($db,$conecta); 

//si se pide q se a�ada... 
if ($add) { 
   $query = "insert into descargas (nombre,url,descargas) values ('$nombre','$url','0')"; mysql_query($query); 
   echo "<b>Archivo de descarga a�adido:<br>- Nombre identificador: $nombre<br>- URL: $url<br><br></b>"; 
} 

//si se pide borrar alguna descarga... 
if ($borra) { 
    $query = "delete from descargas where nombre='$borra'"; mysql_query($query); 
    echo "<b>Borrada la descarga $borra</b>"; 
} 

//muestra todos los registros de descargas 
echo "<table border=1>"; 
$query = "select * from descargas order by nombre"; $resp = mysql_query($query); 
while ($datos = mysql_fetch_array($resp)) { echo "<tr><td>$datos[nombre]</td><td>$datos[url]</td><td>$datos[descargas]</td><td><a href=$nombredescargas?borra=$datos[nombre]>borrar</a></td></tr>"; } 
echo "</table>"; 

//liberamos memoria y desconecta de mysql 
@mysql_free_result($resp); mysql_close($conecta); 

?> 


<meta http-equiv="Content-Language" content="es-mx">


<title>Administrador de Descargas...By CEZ</title>
<body text="#00FF00" bgcolor="#000000">


<br><br> 
<form enctype="multipart/form-data" method=post action="<?=$nombredescargas?>"> 
<div align="center">
  <center>
  <table border="0" cellspacing="1" id="AutoNumber1" width="50%" bgcolor="#000080">
    <tr>
      <td width="50%" align="center" bgcolor="#000000"> 
<input type="text" name="nombre" value="nombre" size="20"></td>
      <td width="50%" align="center" bgcolor="#000000"> 
<input type="text" name="url" value="Direccion del archivo (con http://...)" size="20"></td>
    </tr>
    <tr>
      <td width="100%" colspan="2" align="center" bgcolor="#000000"> 
<input type=submit name="add" value="A�adir Descarga" style="color: #000080; font-size: 8pt; font-family: Arial"></td>
    </tr>
  </table>
  </center>
</div>
</form>
<p align="center">
By ChronoAntonio...<a href="http://cez.ya.st">http://cez.ya.st</a>
</p>