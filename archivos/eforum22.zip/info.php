<?php if(isset($uri)){$uri="?uri=$uri";}else{$uri='/referrer';} print '<?xml version="1.0" encoding="ISO-8859-1"?>';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
<title>About EasyForum! 2.2</title></head><body bgcolor="#eeeeee">
<div align="center"><br /><img src="pics/info.gif" border="0" width="184" height="38" alt="" usemap="#info" /></div><map name="info" id="info">
<area shape="rect" coords="0,0,45,23" href="http://validator.w3.org/check<?php print $uri; ?>" target="_blank" alt="Valid XHTML1.1!" />
<area shape="rect" coords="46,0,91,23" href="http://jigsaw.w3.org/css-validator/validator<?php print $uri; ?>" target="_blank" alt="Valid CSS!" />
<area shape="rect" coords="0,24,91,38" href="http://www.anybrowser.org/campaign/" target="_blank" alt="Best viewed with any browser" />
<area shape="rect" coords="93,0,184,38" href="http://hot-things.net" target="_blank" alt="HTTP://HOT-THINGS.NET" />
</map></body></html>
