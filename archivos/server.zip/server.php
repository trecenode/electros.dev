<?PHP

$disable_functions = NULL;
$INI_GET    = TRUE;
$LAST_ERROR = NULL;

error_reporting(FATAL | ERROR | WARNING);
set_error_handler('HandleError');


if( $_GET['a'] == 'phpinfo' )
{
    phpinfo();

    $error = GetLastError();

    if( $error != NULL )
    {
        echo $error;
    }
    
    exit;
}



function HandleError($errno, $errstr)
{
    global $LAST_ERROR;

    switch($errno)
    {
        case E_WARNING:
        case E_ERROR:
        case E_WARNING:
            $LAST_ERROR = $errstr;
            break;
    }
}



function GetLastError()
{
    global $LAST_ERROR;

    $error = $LAST_ERROR;
    
    $LAST_ERROR = NULL;

    return $error;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
  <title>Server Test Script</title>
  <style>
  a
  {
      color: Maroon;
  }

  .main-box
  {
      width: 750px;
  }

  .header
  {
      background-color: Maroon;
      color: #FFFFFF;
      font-family: Arial;
      font-size: 12pt;
      font-weight: bold;
      text-align: center;
      padding: 3px;
  }

  .cell-left
  {
      display: table-cell;
      font-family: Verdana;
      font-size: 10pt;
      font-weight: bold;
      width: 210px;
      padding: 3px 3px 3px 3px;
      text-align: right;
  }

  .cell-right
  {
      display: table-cell;
      font-family: Verdana;
      font-size: 10pt;
      width: 525px;
      padding: 3px 3px 3px 3px;
      text-align: left;
  }

  .border
  {
      border: 1px solid Maroon;
  }

  .error
  {
      color: Red;
  }

  .small
  {
      font-size: 8pt;
  }
  </style>
<body bgcolor="white" link="blue">

<center>

<div class="main-box">

<div class="border">
<div class="header">
Informacion Del Servidor
</div>


<div>
<span class="cell-left">
Sistema Operativo
</span>
<span class="cell-right">
<?PHP echo PHP_OS; ?>
</span>
</div>

<div>
<span class="cell-left">
Version PHP
</span>
<span class="cell-right">
<?PHP echo PHP_VERSION ?>
</span>
</div>

<div>
<span class="cell-left">
Servidor
</span>
<span class="cell-right">
<?PHP echo $_SERVER['SERVER_SOFTWARE'] ?>
</span>
</div>

<div>
<span class="cell-left">
Root del Servidor
</span>
<span class="cell-right">
<?PHP echo $_SERVER['DOCUMENT_ROOT'] ?>
</span>
</div>


<div>
<span class="cell-left">
Directorio Actual
</span>
<span class="cell-right">
<?PHP echo getcwd() ?>
</span>
</div>



<div>
<span class="cell-left">
Hora del Servidor
</span>
<span class="cell-right">
<?PHP echo date("D M j G:i:s T Y") ?>
</span>
</div>




<div>
<span class="cell-left">
Extension PCRE 
</span>
<span class="cell-right">
<?PHP

if( extension_loaded('pcre') )
{
    echo "Cargada";
}
else
{
    echo '<span class="error">No disponible</span>';
}

?>
</span>
</div>

<div>
<span class="cell-left">
Extension MySQL 
</span>
<span class="cell-right">
<?PHP

if( extension_loaded('mysql') )
{
    echo 'Cargada';
}
else
{
    echo '<span class="error">NO disponible</span>';
}

?>
</span>
</div>

<div>
<span class="cell-left">
Funcion ini_get 
</span>
<span class="cell-right">
<?PHP

$safe_mode = ini_get('safe_mode');

$error = GetLastError();

if( $error == NULL )
{
    echo 'Activada';
}
else
{
    $INI_GET = FALSE;
    echo '<span class="error">Desactivada</span> ';
    echo '<span class="small">' . $error . '</span>';
}

?>
</span>
</div>

<div>
<span class="cell-left">
Modo Seguro o Safe Mode
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $safe_mode = ini_get('safe_mode');

    if( !$safe_mode )
    {
        echo 'Activada';
    }
    else
    {
        echo '<span class="error">Desactivada</span>';
    }
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>

<div>
<span class="cell-left">
Funciones Desactivadas
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $disable_functions = ini_get('disable_functions');

    echo join('<br />', explode(',', $disable_functions));
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>

<div>
<span class="cell-left">
phpinfo
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    if( stristr($disable_functions, 'phpinfo') )
    {
        echo '<span class="error">Desactivada</span>';
    }
    else
    {
        echo '<a href="server.php?a=phpinfo">Disponible</a>';
    }
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>


<div>
<span class="cell-left">
Upload de Archivos
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $file_uploads = ini_get('file_uploads');

    if( !$file_uploads )
    {
        echo '<span class="error">Desactivada</span>';
    }
    else
    {
        echo 'Activada';
    }
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>



<div>
<span class="cell-left">
open_basedir
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $open_basedir = ini_get('open_basedir');

    echo $open_basedir;
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>


<div>
<span class="cell-left">
safe_mode_include_dir
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $safe_mode_include_dir = ini_get('safe_mode_include_dir');

    echo $safe_mode_include_dir;
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>


<div>
<span class="cell-left">
safe_mode_exec_dir
</span>
<span class="cell-right">
<?PHP

if( $INI_GET )
{
    $safe_mode_exec_dir = ini_get('safe_mode_exec_dir');

    echo $safe_mode_exec_dir;
}
else
{
    echo '<span class="error">No se puede determinar. La Funci�n ini_get est� Desactivada</span>';
}

?>
</span>
</div>

</div>

</center>

</body>
</html>
