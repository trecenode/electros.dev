<?
//****************************
//*** MiniChat v.1.2       ***
//*** Creado por: Electros ***
//*** Web: www.electros.tk ***
//****************************

//*********************
//*** Configuraci�n ***
//*********************

// Mensajes a mostrar (0 para mostrar todos)
$mostrar = 30 ;
// Maximo de caracteres por nick
$max_nick = 20 ;
// Maximo de caracteres por mensaje
$max_mensaje = 200 ;
// Maximo de caracteres por web
$max_web = 50 ;
// Maximo de caracteres por palabra (palabras muy grandes como una URL puede descuadrar el dise�o
// y ocasionar que el minichat no se vea correctamente) si no deseas esta opci�n pon 0.
$max_palabra = 25 ;
// Caretos
$caretos = "ON" ;
// Censura de palabras
$censura = "OFF" ;
// Permitir c�digo HTML (se recomienda que est� desactivado)
$codigo = "OFF" ;
// Altura de la tabla de mensajes (cuando los mensajes mostrados rebasan la altura marcada
// aparece una barra de desplazamiento) 
$altura = 100 ;
// Estilo (archivo que contiene el estilo del minichat, tipo de letra, tama�o, color, fondo)
$estilo = "estilo.php" ;
// Lista de caretos (si $caretos est� en ON)
if($caretos == "ON") {
function caretos($texto) {
$texto = str_replace("[[","",$texto) ;
$texto = str_replace("]]","",$texto) ;
// --> Inicio caretos
$texto = str_replace(":D","[[alegre.gif]]",$texto) ;
$texto = str_replace(":8","[[asustado.gif]]",$texto) ;
$texto = str_replace(":P","[[burla.gif]]",$texto) ;
$texto = str_replace(":S","[[confundido.gif]]",$texto) ;
$texto = str_replace(":(1","[[demonio.gif]]",$texto) ;
$texto = str_replace(":(2","[[demonio2.gif]]",$texto) ;
$texto = str_replace(":?","[[duda.gif]]",$texto) ;
$texto = str_replace(":-(","[[enojado.gif]]",$texto) ;
$texto = str_replace(";)","[[guino.gif]]",$texto) ;
$texto = str_replace(":'(","[[llorar.gif]]",$texto) ;
$texto = str_replace(":lol","[[lol.gif]]",$texto) ;
$texto = str_replace(":M","[[moda.gif]]",$texto) ;
$texto = str_replace(":|","[[neutral.gif]]",$texto) ;
$texto = str_replace(":)","[[risa.gif]]",$texto) ;
$texto = str_replace(":-)","[[sonrisa.gif]]",$texto) ;
$texto = str_replace(":R","[[sonrojado.gif]]",$texto) ;
$texto = str_replace(":O","[[sorprendido.gif]]",$texto) ;
$texto = str_replace(":(","[[triste.gif]]",$texto) ;
// --> Fin caretos
$texto = str_replace("[[","<img src=\"caretos/",$texto) ;
$texto = str_replace("]]","\" width=\"15\" height=\"15\">",$texto) ;
return $texto ;
}
}
// Lista de censura de palabras (si $censura est� en ON)
if($censura == "ON") {
function censura($texto) {
// --> Inicio palabras
$texto = str_replace("insulto","***",$texto) ;
// --> Fin palabras
return $texto ;
}
}
// C�digo HTML (si $codigo est� en OFF)
if($codigo == "OFF") {
function codigo($texto) {
$texto = htmlspecialchars($texto) ;
return $texto ;
}
}

//*******************************
//*** Fin de la configuraci�n ***
//*******************************

// *** Guardar mensaje ***
if($enviar) {
if($_COOKIE[unick]) {
include("../config.php") ;
$resp = mysql_query("select contrasena from usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$contrasena = md5(md5($datos[contrasena])) ;
if($contrasena != $_COOKIE[ucontrasena]) {
?>
<script>top.location="../usalir.php"</script>
<?
exit ;
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
}
if($_COOKIE[unick]) { $nick = $_COOKIE[unick] ; } else { $nick = "Invitado" ; }
function quitar($texto) {
$texto = trim($texto) ;
$texto = stripslashes($texto) ;
return $texto ;
}
$mensaje = quitar($mensaje) ;
$web = quitar($web) ;
if($codigo == "OFF") {
$mensaje = codigo($mensaje) ;
$web = codigo($web) ;
}
// Si $max_palabra es mayor que cero
if($max_palabra > 0) {
$palabras = explode(" ",$mensaje) ;
$total = count($palabras) ;
for($a = 0 ; $a < $total ; $a++) {
if(strlen($palabras[$a]) > $max_palabra) { $palabras[$a] = chunk_split($palabras[$a],$max_palabra," ") ; }
}
$mensaje = implode($palabras," ") ;
}
$minichat = fopen("minichat.txt",a) ;
if($web == "" || $web == "http://") {
fwrite($minichat,"\n<b>&lt;$nick&gt;</b> $mensaje") ;
}
else {
fwrite($minichat,"\n<a href=\"$web\" target=\"_blank\">&lt;$nick&gt;</a> $mensaje") ;
}
fclose($minichat) ;
}
?>
<html>
<head>
<title></title>
<?
include("$estilo") ;
?>
</head>
<body>
<div style="height: <? echo $altura ?> ; overflow: auto">
<?
// *** Mostrar los mensajes ***
$mensajes = file("minichat.txt") ;
$total = count($mensajes) ;
if($total < $mostrar || $mostrar == 0) {
$maximo = 0 ;
}
else {
$maximo = $total - $mostrar ;
}
while($total > $maximo) {
$total-- ;
$mensaje = $mensajes[$total] ;
if($caretos == "ON") {
$mensaje = caretos($mensaje) ;
}
if($censura == "ON") {
$mensaje = censura($mensaje) ;
}
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="mensaje">
<tr>
<td>
<? echo $mensaje ?>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?
}
?>
</div>
<script>
function revisar(campo) {
if(campo.value=='Tu mensaje') { campo.value='' ; }
}
function validar() {
if(formulario.mensaje.value == '' || formulario.mensaje.value == 'Tu mensaje') { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<div align="center">
<form name="formulario" method="post" action="minichat.php" onsubmit="return validar()">
<input type="text" name="mensaje" size="20" maxlength="<? echo $max_mensaje ?>" value="Tu mensaje" onfocus="revisar(this)" class="formulario"><br>
<input type="text" name="web" size="20" maxlength="<? echo $max_web ?>" value="http://" class="formulario"><br>
<input type="submit" name="enviar" value="Enviar" class="formulario">
</form>
<div style="font-family: verdana ; font-size: 7pt">
<a href="http://www.electros.tk" target="_blank">MiniChat v.1.2</a>
</div>
</div>
</body>
</html>
