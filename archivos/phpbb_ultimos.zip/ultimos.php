<?
//iniciamos template
$template->set_filenames(array(
		'ultimos' => 'ultimos.tpl')
	);

// AVERIGUAMOS LOS FOROS A LOS QUE EL USUARIO NO TIENE ACCESO y A LOS QUE TIENE ACCESO. Tb adaptamos salida para concatenar a query
$auth_ary = auth(AUTH_READ, AUTH_LIST_ALL, $userdata); 
foreach ( $auth_ary as $auth_forum_id=>$auth_level ) 
{
	if (!$auth_level['auth_read'] ) 
	{ 
		$auth_view_forums = ($auth_view_forums . " p.forum_id<>" . $auth_forum_id . " AND "); 
		$auth_view_forums1 = ($auth_view_forums1 . " forum_id<>" . $auth_forum_id . " AND "); 
		$no_accesibles[]=$auth_forum_id;
	}
	else 
	{
		$accesibles[]=$auth_forum_id;
	}
	
} 
$auth_view_forums="WHERE " . $auth_view_forums; 


// si no se pasa f por query string	 ->		TODOS LOS FOROS
// si se pasa f por query string	:
//									si no existe ese foro -> TODOS LOS FOROS
//									si existe pero no tiene permisos el usuario -> TODOS LOS FOROS

$foro = ( ( is_array( $no_accesibles ) && in_array( $HTTP_GET_VARS['f'] , $no_accesibles ) ) || !in_array( $HTTP_GET_VARS['f'] , $accesibles ) ) ? "" : $HTTP_GET_VARS['f'];

// Pasamos a primera query el identificador de foro si procede y sino nada
$foro_query = ( $foro == "" ) ? "" : ( " p.forum_id=" . $HTTP_GET_VARS['f'] . " AND " );

// primera query que recoge distintos topic_id dados los últimos mensajes
$sql_ini=("SELECT distinct p.topic_id FROM ".POSTS_TABLE."  p, ".TOPICS_TABLE." t $auth_view_forums $foro_query p.topic_id=t.topic_id ORDER BY t.topic_last_post_id DESC LIMIT 0,5");
if ( !($result_ini = $db->sql_query($sql_ini)) )
		{
			message_die(GENERAL_ERROR, 'No se pudo obtener últimos temas', '', __LINE__, __FILE__, $sql_ini);
		}


while ( $assoc_ini=$db->sql_fetchrow($result_ini) )
	// Para cada topic_id obtenido extraeremos datos necesarios en dos querys
	{
		// Segunda query todos los datos menos el ultimo usuario
		$sql=("SELECT t.topic_last_post_id, t.topic_title, t.topic_id, t.topic_time, t.topic_replies, u.username,u.user_id, f.forum_name, f.forum_id, p.post_id, p.post_time FROM ".POSTS_TABLE." p, ".TOPICS_TABLE." t, ".USERS_TABLE." u, ".FORUMS_TABLE." f WHERE t.topic_poster=u.user_id AND t.topic_id=".$assoc_ini['topic_id']." AND p.post_id=t.topic_last_post_id AND t.forum_id=f.forum_id");
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'No se pudo obtener últimos temas', '', __LINE__, __FILE__, $sql);
		}
		while ( $assoc=$db->sql_fetchrow($result) )
		{
			// tercera query ultimo posteador
			$sql_last=("SELECT u.username FROM ".POSTS_TABLE." p, ".USERS_TABLE." u WHERE p.post_id=".$assoc['topic_last_post_id']." AND  p.poster_id=u.user_id");
			if ( !($result_last = $db->sql_query($sql_last)) )
			{
				message_die(GENERAL_ERROR, 'No se pudo obtener últimos temas', '', __LINE__, __FILE__, $sql_last);
			}
			$ultimo_usuario=$db->sql_fetchrow($result_last);
			$ultimo_usuario=$ultimo_usuario['username'];
			$db->sql_freeresult($result_last);
			$fecha_ultimo=getdate($assoc['post_time']);
			$fecha_ultimo=$fecha_ultimo["mday"]."-".$fecha_ultimo["mon"]."-".$fecha_ultimo["year"]; 
			$fecha_abierto=getdate($assoc['topic_time']);
			$fecha_abierto=$fecha_abierto["mday"]."-".$fecha_abierto["mon"]."-".$fecha_abierto["year"]; 
			$foro_nombre = $assoc['forum_name'];
			$template->assign_block_vars('ultimos', array(
				'LINK_TITULO'		=>	append_sid( "viewtopic.$phpEx?p=".$assoc['post_id']."&highlight=#".$assoc['post_id'] ),
				'TITULO'			=>	( ( strlen ( $assoc["topic_title"] ) > 19 ) ? ( substr ( $assoc["topic_title"] , 0 , 19 ) . "..." ) : $assoc["topic_title"] ),
				'LINK_FORO'			=>	append_sid( "viewforum.$phpEx?f=".$assoc["forum_id"] ),
				'FORO'				=>  ( ( strlen ( $assoc["forum_name"] ) > 19 ) ? ( substr ( $assoc["forum_name"] , 0 , 19 ) . 	"..." ) : $assoc["forum_name"] ),
				'LINK_CREADOR_TEMA'	=>	append_sid( "profile.$phpEx?mode=viewprofile&u=".$assoc["username"] ),
				'CREADOR_TEMA'		=>	$assoc["username"],
				'CREADOR_FECHA'		=>  $fecha_abierto,
				'LINK_AUTOR_ULTIMO'	=>	append_sid( "profile.$phpEx?mode=viewprofile&u=".$ultimo_usuario ),
				'AUTOR_ULTIMO'		=>	$ultimo_usuario,
				'FECHA_ULTIMO'		=>	$fecha_ultimo,
				'RESPUESTAS'		=>	$assoc["topic_replies"]));
		}
		$db->sql_freeresult($result);
		
	}
$db->sql_freeresult($result_ini);
$template->assign_vars(array(
				'FORO_NOMBRE'		=>	( ( $foro == "" ) ? "TODOS LOS FOROS" : $foro_nombre ),
				'INDICE'			=> append_sid("index.$phpEx" ) ) );
make_jumpbox('index.'.$phpEx);
$template->pparse('ultimos');
?>