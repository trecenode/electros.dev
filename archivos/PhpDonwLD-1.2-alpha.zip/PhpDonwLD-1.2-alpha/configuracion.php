<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

$cfg["dir_raiz"] = "index_descargas"; #Directorio indice desde donde se descargan los archivos
$cfg["idioma"]   = "es"; #Idioma del script. Mire [idiomas.txt] en la carpeta idiomas
$cfg["titulo"]   = "� PhpDownLD-1.2 Alpha �";
$cfg["dec"]      = 2; #numero de decimales en el tama�o
$cfg["admin"]    = "password"; #Admin Password
$cfg["ftpmode"]  = "no"; #Modo gestor de archivos
?>
