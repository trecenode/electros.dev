<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#
session_start();
include("configuracion.php");
include("idiomas/".$cfg["idioma"].".php");
include("modulos/phpdownld.mod_edit.php");
include("modulos/phpdownld.funciones.php");
$num["dir"]     = 0;
$num["archivo"] = 0;
echo '<title>'.$cfg["titulo"].'</title><link href="estilo.css" rel="stylesheet" type="text/css">';
echo '<script language="JavaScript">
function confirmar(ruta,ar)
{
function cancel () 
{}
if (confirm("'.$lng['del']." [\"+ar+\"]".'")) 
{
window.location=ruta;
} 
else { cancel(); }
}
</script>';
include ("cabecera.php");
if($_GET['nombre'] == "admin" or ($cfg["ftpmode"] == "yes" and !$_SESSION['admin']))
{
	include("admin.php"); exit();
}
if($_GET['accion'] == "del" && $_SESSION['admin'])
{
	if($_GET['tipo'] == "dir")
	{
		rm($_GET['archivo']);
	}
	else
	{
		unlink($_GET['archivo']);
	}
	
}
if($_GET['ruta'])
{
	$trozos = explode("/",$_GET['ruta']);
	for($a=0; $a<=count($trozos) - 1; $a++)
	{
	$out = $trozos;
	$out[0] = $lng["raiz"];
		for($b=0;$b<=$a;$b++)
		{
		
			$url[$b] = $trozos[$b];
			
		}
		$url_real = join($url,"/");
		if($url_real != $_GET['ruta'])
		{
		$rut[$a] = "<a href=index.php?ruta=".str_replace(" ","%20",$url_real).">".$out[$a]."</a>";
		}
		else
		{
		$rut[$a] = $out[$a];
		}
	}
$nav = join($rut," >> ");
}
#COMIENZO DE LA TABLA

echo '<font class="fuente">'.$nav.'</font><p><table cellpadding="0" cellspacing="0" class="tabla">
<tr>
	<td class="celdas_titulo" colspan="2">'.$lng["name"].'</td>
	<td class="celdas_titulo">'.$lng["tam"].'</td>
	<td class="celdas_titulo">'.$lng["ext"].'</td>
</tr>';
#FIN DE LA CABECERA TABLA

function get_img()
{
	global $ex,$c;
	$ret = substr($ex[$c],strpos($ex[$c],"=") + 1,strlen($ex[$c]));
	return $ret;
}

#DETECCION DE ERRORES
if ($_GET['ruta'])
{
	$ret = explode("/",$_GET['ruta']);
	for($d = 0; $d <= count($ret) - 1; $d++)
	{
		if($ret[$d] == ".." or $ret[$d] == "." or $_GET['ruta'] == ".." or $_GET['ruta'] == "../" or $_GET['ruta'] == "./")
		{
			echo "<script> alert('".$lng["ret"]."','error'); window.location='index.php'; </script>"; exit();
		}
	}
}
if (!file_exists("Palabras_no_listadas.txt")) { echo $lng["err_pnl"]; exit();}
if (!file_exists("extensiones.txt")) { echo $lng["err_ex"]; exit();}
#FIN DE DETECCION DE ERRORES

if(!$_GET['ruta']) { $ruta = $cfg["dir_raiz"]; } else { $ruta = $_GET['ruta']; } //Directorio raiz
if($_GET['accion'] == "cerrar")
{
	session_destroy();
	echo "<script> window.location='index.php?ruta=".$ruta."'; </script>";
	exit();
}
if($ruta != ".")
{
	$ruta_i = $ruta."/";
}
$ld = opendir($ruta);

$pr = file("Palabras_no_listadas.txt");
$b = 0;
while($rs = readdir($ld))
{
	for($a = 0; $a <= count($pr) - 1; $a++)
	{
		if($rs == trim($pr[$a]))
		{
			$en[$b] = "si";
		}
	}
	if($en[$b] != "si")
	{
	$ext = strrev($rs);
	$ppos = strpos($ext,".");
	$ext = strtolower(substr($rs,-1 * $ppos));
		$ex = file("extensiones.txt");
		for($c = 0; $c <= count($ex) - 1; $c++)
		{
			$pos = strpos($ex[$c],"=");
			$e_reg = substr($ex[$c],0,$pos);
			if($e_reg == "dist")
			{
				$dist = get_img();
			}
			if($e_reg == "dir")
			{
				$dir_img = get_img();
			}
			if($e_reg == $ext)
			{
				$img = get_img();
			}
			
		}
		if (!$img)
		{
			$img = $dist;
		}
		$rslink = $rs;
		if($_GET['ruta'])
		{
			$rs_tip = $_GET['ruta']."/".$rs;
		}
		else
		{
			$rs_tip = $ruta_i.$rs;
		}

		if (filetype($rs_tip) == "dir")
		{
		$num["dir"]++;
			$ext = "directorio";
			if($_GET['ruta'])
			{
				$rslink = "index.php?ruta=".$_GET['ruta']."/".$rs;
			}
			else
			{
				$rslink = "index.php?ruta=".$ruta_i."".$r_ini.$rs;
			}
		$tam = "-";
		}
		else
		{
		$num["archivo"]++;
		$rslink = $ruta_i.$rslink;
		$tam = filesize($rslink);
		$date = "(".date ("d F Y - H:i:s", filemtime($rslink)).")";
			if($tam < 1024)
			{
			$tam = $tam;
			$tn = "bytes";
			}
			elseif($tam < pow(1024,2))
			{
			$tam = ($tam/1024);
			$tn = "Kb";
			}
			elseif($tam < pow(1024,3))
			{
			$tam = ($tam/pow(1024,2));
			$tn = "Mb";
			}
		$tam = number_format($tam ,$cfg["dec"] , " ' " ,"");
		$tam = $tam." ".$tn;
		}
		if($ext == "directorio")
		{
			$img = $dir_img;
		}
		$rslink = str_replace(" ","%20",$rslink);
		$nombre_url = str_replace(" ","%20",$rs);
		
		if($_SESSION['admin'])
		{	
			$ruta_url = str_replace(" ","%20",$ruta);
			$tipo = filetype($rs_tip);
			if($tipo != "dir")
			{
			$rd = 'index.php?ruta='.$ruta_url.'&accion=del&archivo='.$rslink.'&tipo=file';
			$del = "<td><a href=javascript:confirmar('".$rd."','".$rs."')><img src=PhpDownLD_imagenes/del.gif border=0></a></td>";
			}
			else
			{
			$rd = 'index.php?ruta='.$ruta_url.'&accion=del&archivo='.$ruta_url."/".$rs.'&tipo=dir';
			$del = "<td><a href=javascript:confirmar('".$rd."','".$rs."')><img src=PhpDownLD_imagenes/del.gif border=0></a></td>";
			}
		$ed = "<tr><td><a href=javascript:edit('".$nombre_url."','".$ruta."','".$tipo."')><img src=PhpDownLD_imagenes/edit.gif border=0></a></td>";
		}
		echo '<tr>
    	<td class="celdas_res" width="2%"><center><img src="PhpDownLD_imagenes/extensiones/'.$img.'"></center></td>
    	<td class="celdas_res" width="50%"><table border=0 class=int>'.$ed.''.$del.'<td><a href='.$rslink.'>'.$rs.'</a> '.$date.'</td></tr></table></td>
    	<td class="celdas_res" width="25%">'.$tam.'</td>
    	<td class="celdas_res" width="23%">'.$ext.'</td>	
		</tr>';
		$img = 0;
	}
$b++;
}
if(!$num["dir"] && !$num["archivo"])
{
		echo '<tr>
    	<td class="celdas_res" colspan=4>'.$lng["nha"].'</td>	
		</tr>';
}
$estadisticas = $lng["fin"]." <b>".$num["dir"]."</b> ".$lng["dis"]." ".$lng["and"]." <b>".$num["archivo"]."</b> ".$lng["files"];
if($_SESSION['admin'])
{
	echo '<table width=100%><tr><td width=4><img src="PhpDownLD_imagenes/admin.gif"><td width=10><font class=fuente_stats><a href=index.php?accion=cerrar&ruta='.$ruta.'>'.$lng['close'].'</a></font></td></td>';
}
else
{
	echo '<table width=100%><tr><td width=4><img src="PhpDownLD_imagenes/admin.gif"><td width=10><font class=fuente_stats><a href=index.php?nombre=admin>'.$lng["admin"].'</a></font></td></td>';
}
echo '<td width=4><img src="PhpDownLD_imagenes/stats.gif"></td><td><font class=fuente_stats>'.$estadisticas.'</font></tr></tr></table>';
if($_SESSION['admin'])
{
	echo "<table style=><tr><td>";
	include("modulos/phpdownld.mod_upload.php");
	echo "</td><td>";
	include("modulos/phpdownld.mod_mkdir.php");
	echo "</td></tr></table>";
}
echo '<center><font class=fuente>PhpDownLD, <a href=http://proyectos.funkybytes.com/phpdownld/>'.$lng["pag"].'</a></font></center></table>';
?>