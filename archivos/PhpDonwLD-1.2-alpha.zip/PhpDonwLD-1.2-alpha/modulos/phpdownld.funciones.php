<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

function rm($ruta)
{
	if(file_exists($ruta))
	{
		$op = opendir($ruta);
		while($read = readdir($op))
		{
			if($read != "." and $read != "..")
			{
				if(filetype($ruta."/".$read) == "dir")
				{
					rm($ruta."/".$read);
				}
				else
				{
					unlink($ruta."/".$read);
				}
			}
		}
	closedir($op);
	rmdir($ruta);
	return 1;
	}
}
?>