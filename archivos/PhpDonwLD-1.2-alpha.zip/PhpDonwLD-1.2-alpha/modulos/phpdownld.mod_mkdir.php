<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

if($_SESSION['admin'])
{
	echo '<form name="mkdir" method="post" action="index.php?ruta='.$ruta.'&accion=mkdir">
 	<p><img src="PhpDownLD_imagenes/mkdir.gif" width="20" height="17"> 
    <input type="text" name="dir" class="form" id="dir">
    <input type="submit" name="Submit" value="'.$lng['mkdir'].'" class="boton">
  	</p>
	</form>';
	if($_GET['accion'] == "mkdir")
	{
		$directorio = $ruta."/".$_POST['dir'];
		
		if(!$_POST["dir"] or !mkdir($directorio))
		{
			echo "<script> alert('".$lng['nomk']." ".$_POST['dir']."','error'); </script>";
		}
		else
		{
			echo "<script> window.location='index.php?ruta=".$ruta."'; </script>";
		}
	}
}
?>
