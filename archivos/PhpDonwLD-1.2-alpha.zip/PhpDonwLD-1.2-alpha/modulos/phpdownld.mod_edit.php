<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

if($_GET['accion'] == "edit" && $_SESSION['admin'])
{
$error["npa"] = "<script> alert('".$lng['rn']."','error'); </script>";
	if($_GET['nombre'] != $_GET['nuevo'])
	{
		if(!file_exists($_GET['ruta']."/".$_GET['nuevo']))
		{
			if(!rename($_GET['ruta']."/".$_GET['nombre'],$_GET['ruta']."/".$_GET['nuevo']))
			{
				echo $error["npa"];
			}
		}
		else
		{
			echo $error["npa"];
		}
	}
}
?>
<script language="JavaScript">
function edit(nombre,ruta,tip)
{
	var nb2 = prompt('<? echo $lng['iun']; ?>',nombre);
	if(nb2)
	{
		window.location="index.php?accion=edit&ruta=" + ruta + "&tipo=" + tip + "&nombre=" + nombre + "&nuevo=" + nb2;
	}
}
</script>