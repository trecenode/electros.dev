<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

if($_SESSION['admin'])
{
echo '<form action="index.php?ruta='.$ruta.'&accion=upload" method="post" enctype="multipart/form-data" name="upload">
  <input name="archivo" type="file" id="archivo" class="form">
  <input name="upload" type="submit" id="upload" value="'.$lng['upload'].'" class="boton">
</form>';
if($_GET['accion'] == "upload")
{
	$archivo = $_POST['archivo'];
	if(move_uploaded_file($_FILES["archivo"]["tmp_name"],$_GET['ruta']."/".$_FILES["archivo"]["name"]))
	{
		echo "<script> window.location='index.php?ruta=".$ruta."'; </script>";
	}
	else
	{
		echo "<script> alert('".$lng['nup']." ".$_FILES["archivo"]["name"]."','error'); </script>";
	}
	
}
}
?>