<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

$lng["err_pnl"] = "Error, no se encuentra el archivo Palabras_no_listadas.txt";
$lng["err_ex"]  = "Error, no se encuentra el archivo extensiones.txt";
$lng["name"]    = "Nombre del archivo";
$lng["tam"]     = "Tama�o";
$lng["ext"]     = "Extensi�n";
$lng["ret"]     = "Error, por motivos de seguridad el uso de [..] y [.] esta desactivado";
$lng["dir"]     = "Directorio";
$lng["vol"]     = "Volver";
$lng["pag"]     = "P�gina web oficial";
$lng["fin"]     = "Encontrados";
$lng["dis"]     = "directorios";
$lng["and"]     = "y";
$lng["files"]   = "archivos";
$lng["nha"]     = "No hay ning�n archivo en este directorio";
$lng["admin"]   = "Administrador";
$lng["pda"]     = "Contrase�a erronea, intentelo de nuevo";
$lng["nhp"]     = "El campo contrase�a esta vacio";
$lng['ysi']     = "ya estas identificado";
$lng['upload']  = "Upload";
$lng['nup']     = "Error, no se ha podido subir el archivo";
$lng['mkdir']   = "Crear Directorio";
$lng['nomk']    = "Error, no se ha podido crear el directorio";
$lng['rn']      = "Error, no se ha podido editar";
$lng['close']   = "Cerrar";
$lng['raiz']    = "Directorio ra�z";
$lng['iun']     = "Inserte un nombre";
$lng['del']     = "�Estas seguro de que deseas eliminar este archivo?";
?>