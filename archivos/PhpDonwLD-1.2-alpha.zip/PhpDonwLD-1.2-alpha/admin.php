<?
#==================================================#
#    PhpDownLD, Sistema de descarga de archivos    #
#      Creado en su totalidad por Funkyslim        #
#==================================================#
#                P�gina web oficial                #
#  	 http://proyectos.funkybytes.com/phpdownld     #
#==================================================#
#     Email de contacto: admin@funkybytes.com      #
#==================================================#
#     Este script esta distribuido bajo GNU.       #
#  La distribucion de este es totalmente gratuita  #
#     por lo que no se permite cobrar por el       #
#==================================================#

if(!$_SESSION['admin'])
{
if($_GET['ident'] == "yes")
{
	if($_POST['pass'])
	{
		if($_POST['pass'] == $cfg["admin"])
		{
			$_SESSION['admin'] = "yes";
			echo "<script> window.location='index.php'; </script>";
		}
		else
		{
			echo "<script> alert('".$lng['pda']."','error'); </script>";
		}
	}
	else
	{
		echo "<script> alert('".$lng['nhp']."','error'); </script>";
	}
}
echo '<table cellpadding="0" cellspacing="0" class="tabla_admin" align="center"><tr><td class=celdas_titulo>Identificacion del administrador</td></tr>
<tr><td class=celdas_res>
  <table width="100%" border="0" cellpadding="3" cellspacing="0">
  <form name="admin" method="post" action="index.php?nombre=admin&ident=yes">
    <tr> 
      <td width=50%><font class=fuente>Contrase�a</font></td>
      <td width=50%><input type="password" name="pass" id="pass" class=form></td>
    </tr>
    <tr> 
      <td height=30><center><input type="submit" name="Submit" value="Identificate" class=boton></center></td>
	  <td><center><input type="submit" name="Submit" value="Borrar" class=boton></center></td>
    </tr>
	</form>
  </table>
</td></tr></table>
<center><a href=index.php>'.$lng["vol"].'</a><center>';
}
else
{	
	echo "<script> alert('".$lng['ysi']."','error'); </script>";
	echo "<script> window.location='index.php'; </script>";
}
?>