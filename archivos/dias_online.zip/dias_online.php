<?php
$lanzamiento = mktime(0,0,0,01,01,2006); /*Dia del Lanzamiento*/
$ahora = time(); /*Fecha de ahora*/
$diferencia = $ahora - $lanzamiento; 
$dias = round($diferencia/86400);
if($dias>0){
echo $dias,' d�as on-line';
}
else{
$dias = -$dias;
echo 'Faltan ',$dias, ' dias para el Lanzamiento';
}
?>