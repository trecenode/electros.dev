<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
include("config.php");
$result = mysql_query("SELECT * FROM ".$tabla." ORDER by id DESC", $link);
while ($myrow = mysql_fetch_array($result)) {
$contenido = $myrow["contenido"];
$contenido = str_replace("(:))","<img border=0 src=smiles/smile.gif>", $contenido);
$contenido = str_replace("(:S)","<img border=0 src=smiles/smile%20(1).gif>", $contenido);
$contenido = str_replace("(8l)","<img border=0 src=smiles/smile%20(2).gif>", $contenido);
$contenido = str_replace("(:l)","<img border=0 src=smiles/smile%20(3).gif>", $contenido);
$contenido = str_replace("(:@)","<img border=0 src=smiles/smile%20(4).gif>", $contenido);
$contenido = str_replace("(:X)","<img border=0 src=smiles/smile%20(5).gif>", $contenido);
$contenido = str_replace("(:D)","<img border=0 src=smiles/smile%20(6).gif>", $contenido);
$contenido = str_replace("(:|)","<img border=0 src=smiles/smile%20(7).gif>", $contenido);
$contenido = str_replace("(:P)","<img border=0 src=smiles/smile%20(8).gif>", $contenido);
$contenido = str_replace("(:$)","<img border=0 src=smiles/smile%20(9).gif>", $contenido);
$contenido = str_replace("(8-)","<img border=0 src=smiles/smile%20(10).gif>", $contenido);
$contenido = str_replace("(:()","<img border=0 src=smiles/smile%20(11).gif>", $contenido);
$contenido = str_replace("(:O)","<img border=0 src=smiles/smile%20(12).gif>", $contenido);
$contenido = str_replace("(--)","<img border=0 src=smiles/smile%20(13).gif>", $contenido);
$contenido = str_replace("(;D)","<img border=0 src=smiles/smile%20(14).gif>", $contenido);
$contenido = str_replace("[b]","<b>", $contenido);
$contenido = str_replace("[/b]","</b>", $contenido);
$contenido = str_replace("[i]","<i>", $contenido);
$contenido = str_replace("[/i]","</i>", $contenido);
$contenido = str_replace("[u]","<u>", $contenido);
$contenido = str_replace("[/u]","</u>", $contenido);
$contenido = str_replace("[php]","<b>Codigo PHP:</b><br><div align=center><font color=#FFFFFF><table border=1 width=98% id=table1 bgcolor=#555555 style=border-collapse:collapse bordercolor=#000000><tr><td class=php>", $contenido);
$contenido = str_replace("[/php]","</td></tr></table></font></div>", $contenido);
$contenido = str_replace("[url=","<a target=_blank href=", $contenido);
$contenido = str_replace("]name=",">", $contenido);
$contenido = str_replace("[/url]","</a>", $contenido);
$contenido = str_replace("?>","?&gt;", $contenido);
$contenido = str_replace("<?","&lt;?", $contenido);
$contenido = str_replace("php?>","php?&gt;", $contenido);
$contenido = str_replace("<?php","&lt;?php", $contenido);
$contenido = str_replace("[img]","<img src=", $contenido);
$contenido = str_replace("[/img]",">", $contenido);
$contenido = str_replace("[center]","<center>", $contenido);
$contenido = str_replace("[/center]","</center>", $contenido);
$contenido = str_replace("[left]","<p align=left>", $contenido);
$contenido = str_replace("[/left]","</p>", $contenido);
$contenido = str_replace("[quote]","<br><b>Cita:</b><br><div align=\"center\" style=\"
  padding:5px;
  margin:5px;
  background-color:       #363636;
  font-family: Courier New; 
  color: #ffffff;
  border-color:           #808080;
  border-style:           solid;
  border-width:           1px;
  font-size:              12px;
  margin:                 0px;
  overflow:               auto;
  padding:                6px;
  text-align:             left;
  width:                  95%;\">", $contenido);
$contenido = str_replace("[/quote]","</div>", $contenido);
$contenido = str_replace("[right]","<p align=right>", $contenido);
$contenido = str_replace("]name=",">", $contenido);
$contenido = str_replace("[/right]","</p>", $contenido);


//ESTA LINEA ES LA KE MUESTRA LAS NOTICIAS, PUEDES MODIFICARLO SI KIERES - WWW.KENKE.NET
echo "<table border=0 cellpadding=0 cellspacing=0 width=100% class=Tabla><tr><td width=63% style=padding-right: 5px align=left><b>� ".$myrow["titulo"]."</b></font></td></tr><tr><td>".$contenido."</td></tr><tr><td width=36% style=padding-left: 5px>Escrito el <b>".$myrow["fecha"]."</b> Por <b>".$myrow["nombre"]."</b></td></tr><tr><td><hr color=#000000 size=1></td></tr></table>";
}
?>
