<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
if(isset($user) AND ($pass)) {
include("config.php");
$userCHANGE = md5($user);
$passCHANGE = md5($pass);
$userA = md5($userCHANGE);
$passA = md5($passCHANGE);

if($usuarios[$userA]==$passA) {
?>
<div align="center">
<table border="0" width="100%" id="table1" cellspacing="0" cellpadding="0" class="Tabla" height="179">
	<tr>
		<td>
			<form method="POST" action="noticias.php">
			<input type="hidden" name="userA" value="<?= $userA ?>">
			<input type="hidden" name="passA" value="<?= $passA ?>">
			<center>
			<INPUT TYPE="image" SRC="images/noticias.gif" BORDER="0" name="noticia" width="48" height="49"><br>
			A�adir Noticia</center>
			</form>
			</td>
			<td>
			<form method="POST" action="modificar.php">
			<input type="hidden" name="userA" value="<?= $userA ?>">
			<input type="hidden" name="passA" value="<?= $passA ?>">
			<center>
			<INPUT TYPE="image" SRC="images/modificar.gif" BORDER="0" name="modificar" width="48" height="49"><br>
			Modificar Noticia</center>
			</form>
			</td>
			<td>
			<form method="POST" action="borrar.php">
			<input type="hidden" name="userA" value="<?= $userA ?>">
			<input type="hidden" name="passA" value="<?= $passA ?>">
			<center>
			<INPUT TYPE="image" SRC="images/borrar.gif" BORDER="0" name="borrar" width="48" height="49"><br>
			Borrar Noticia</center>
			</form>
		</td>
	</tr>
</table>
</div>
<?
} else {
echo "El login no coincide, vuelve a intentarlo.<br>";
echo "<a href=javascript:history.go(-1)>Ir Atras</a>";
}
} else {
?>
<form method=post>
	<div align="center">
		<table border="0" width="26%" id="table1" cellspacing="0" cellpadding="0" height="71" class="Tabla">
		<tr>
			<td width="88" align="right"><b>Usuario:</b></td>
			<td><input type="text" name="user" size="20"></td>
		</tr>
		<tr>
			<td width="88" align="right"><b>Password:</b></td>
			<td><input type="password" name="pass" size="20"></td>
		</tr>
		<tr>
			<td width="88" align="right"></td>
			<td><input type="submit" value="Enviar" name="enviar"></td>
		</tr>
	</table></div>
</form>
<?
}
?>