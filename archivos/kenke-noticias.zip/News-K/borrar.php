<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
define('bbcode', true);
include("config.php");
if(isset($userA) AND ($passA)) {
if($usuarios[$userA]==$passA) {
if(!isset($ID)) {
?>
<center><b><font size="4">Borrar Noticias:</font></b></center><br>
<div align="center">
	<table border="1" cellpadding="0" style="border-collapse: collapse" width="98%" bordercolorlight="#000000" bordercolordark="#000000" class="Tabla">
		<tr>
			<td width="621">
			<p align="center"><b>Titulo</b></td>
			<td width="15%">
			<p align="center"><b>Borrar</b></td>
		</tr>
		<?
$result = mysql_query("SELECT id, titulo FROM ".$tabla." ORDER by id DESC", $link);
while ($myrow = mysql_fetch_array($result)) {
echo "<tr><td width=69><p align=center>".$myrow["titulo"]."</td><td><center><a href=borrar.php?userA=".$userA."&passA=".$passA."&ID=".$myrow["id"].">[Borrar]</a></center></td></tr>";
}
?>
</table>
</div>

<?
} else {
$sql = "DELETE FROM ".$tabla." WHERE id='$ID'";
$result = mysql_query($sql,$link);
echo "Noticia Borrada<br><a href=index.php>Volver al Index</a>";
}
} else {
include("admin.php");
}
} else {
include("admin.php");
}
?>