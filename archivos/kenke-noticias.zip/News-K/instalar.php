<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
$instalacion=false;
if($server && $db && $usuario && $tabla && $nick && $pass){
$instalacion=true;
$userCHANGE = md5($nick);
$passCHANGE = md5($pass);
$userA = md5($userCHANGE);
$passA = md5($passCHANGE);
}
?>
<head>
<title>Instalacion News-K v1.1</title>
<meta name="keywords" content="Instalacion News-K v1.1">
<meta name="description" content="Instalacion News-K v1.1">

<script language="javascript" type="text/javascript">
function vacio(q) {
        for ( i = 0; i < q.length; i++ ) {
                if ( q.charAt(i) != " " ) {
                        return true
                }
        }
        return false
}
function valida(F) {
        if(vacio(instalacion.server.value) == false) {
                alert("Deves rellenar el Servidor de la Base de Datos.")
                return false
        } else {
                if(vacio(instalacion.db.value) == false) {
                alert("Deves rellenar el Nombre de la Base de Datos.")
                return false
        } else {
                if(vacio(instalacion.usuario.value) == false) {
                alert("Deves rellenar el Usuario de la Base de Datos.")
                return false
        } else {
                if(vacio(instalacion.tabla.value) == false) {
                alert("Deves rellenar la tabla donde se instalara el script.")
                return false
        } else {
        if(vacio(instalacion.nick.value) == false) {
                alert("Deves rellenar el Nick del Administrador.")
                return false
        } else {
        if(vacio(instalacion.pass.value) == false) {
                alert("Deves rellenar la Pass del Administrador")
                return false
        } else {
                return true
        }
        }
        }
        }
        }
        }
        
}


</script>

</head>
<STYLE>
BODY{
FILTER:progid:DXImageTransform.Microsoft.Gradient(startColorstr='#222222',endColorstr='#666666', gradientType='0')
}
</STYLE>
<body link="#000000" vlink="#000000" alink="#000000" bgcolor="#000000"><div align="center">
		<form name="instalacion" method="post" action="instalar.php" onSubmit="return valida(this);">
	<table border="1" cellpadding="0" width="500" id="table1" style="border-collapse: collapse" bordercolor="#000000">
		<tr>
			<td bgcolor="#666666">
			<p align="center"><font color="#FFFFFF"><b>Instalaci�n News-K v1.1</b></font></td>
		</tr>
		<tr>
		<td bgcolor="#FFFFFF">
		<? if(!$instalacion) {
		echo "<b><font face=\"Arial\" style=\"font-size: 10pt\">Antes de nada verifica si el archivo config.php tiene permisos CHMOD 0777</font></b>";
		} else {
		$fp = fopen("config.php", "w");
		if($fp){
$string = '<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
$usuarios = array(
"'.$userA.'" => "'.$passA.'",
);

$tabla = "'.$tabla.'";
$link = mysql_connect("'.$server.'", "'.$usuario.'", "'.$password.'");
mysql_select_db("'.$db.'", $link);
?>';
		fputs($fp, $string);
		fclose($fp);
		$conexion=mysql_connect($server,$usuario,$password) or die("<br><center><b>Error conectando con la Base de Datos, vuelve atras y revisa los datos</b></center><br>"); 
		echo "<b>1. (Conectando con Base de Datos)</b><br>";
		mysql_select_db($db,$conexion) or die("<center><b>Error seleccionando la Base de Datos, vuelve atras y revisa los datos</b></center><br>");
		echo "<b>2. (Seleccionada Base de Datos: $db)</b><br>"; 
		echo "<b>3. (Creando tabla: $tabla)</b><br>";
		$sql = 'CREATE TABLE '.$tabla.' ('
        . ' id int(11) NOT NULL auto_increment,'
        . ' titulo varchar(255) default NULL,'
        . ' email varchar(100) default NULL,'
        . ' fecha varchar(10) default NULL,'
        . ' contenido text,'
        . ' nombre varchar(50) default NULL,'
        . ' KEY id (id)'
        . ' ) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;';
        mysql_query($sql,$conexion) or die("<center><b>Error Creando Tabla: $tabla, vuelve atras y revisa los datos</b></center><br>");
		mysql_close($conexion);
		echo "<b>4. (Tabla: $tabla creada correctamente)</b><br>";
		echo "<font color=\"#FF0000\"><center><b>Instalacion Finalizada Correctamente!<br>No olvides borrar el archivo instalar.php del servidor!</b></center></font>";
		echo "<center><b>Este es el contenido del archivo config.php por si hay algun problema:</b><br><textarea rows=\"10\" name=\"S1\" cols=\"50\">".$string."</textarea></center>";
		} else {
		if(!@chmod('config.php',0777)){
		echo "<center><b><font color=\"#FFFFFF\"><span style=\"background-color: #000000\">No se pudo 
		dar permisos CHMOD 0777 al archivo config.php, porfavor; hazlo manualmente.</span></font></b></center>";
		} else {
		$fp = fopen("config.php", "w");
$string = '<?
///////////////////////////////////
//          NEWS-K V1.1          //
//SCRIPT DE NOTICIAS DESARROLLADO//
//COMPLETAMENTE EN PHP,HTML Y SQL//
//           POR KENKE           //
//  pepino_maduro@hotmail.com    //
// PARA BUGS,ERRORES,SUGERENCIAS //
//    ENTRAR EN WWW.KENKE.NET    //
///////////////////////////////////
$usuarios = array(
"'.$userA.'" => "'.$passA.'",
);

$tabla = "'.$tabla.'";
$link = mysql_connect("'.$server.'", "'.$usuario.'", "'.$password.'");
mysql_select_db("'.$db.'", $link);
?>';
		fputs($fp, $string);
		fclose($fp);
		$conexion=mysql_connect($server,$usuario,$password) or die("<br><center><b>Error conectando con la Base de Datos, vuelve atras y revisa los datos</b></center><br>"); 
		echo "<b>1. (Conectando con Base de Datos)</b><br>";
		mysql_select_db($db,$conexion) or die("<center><b>Error seleccionando la Base de Datos, vuelve atras y revisa los datos</b></center><br>");
		echo "<b>2. (Seleccionada Base de Datos: $db)</b><br>"; 
		echo "<b>3. (Creando tabla: $tabla)</b><br>";
		$sql = 'CREATE TABLE '.$tabla.' ('
        . ' id int(11) NOT NULL auto_increment,'
        . ' titulo varchar(255) default NULL,'
        . ' email varchar(100) default NULL,'
        . ' fecha varchar(10) default NULL,'
        . ' contenido text,'
        . ' nombre varchar(50) default NULL,'
        . ' KEY id (id)'
        . ' ) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;';
        mysql_query($sql,$conexion) or die("<center><b>Error Creando Tabla: $tabla, vuelve atras y revisa los datos</b></center><br>");
		mysql_close($conexion);
		echo "<b>4. (Tabla: $tabla creada correctamente)</b><br>";
		echo "<font color=\"#FF0000\"><center><b>Instalacion Finalizada Correctamente!<br>No olvides borrar el archivo instalar.php del servidor!</b></center><br></font>";
		echo "<center><b>Este es el contenido del archivo config.php por si hay algun problema:</b><br><textarea rows=\"10\" name=\"S1\" cols=\"50\">".$string."</textarea></center>";
}
}
}

		?>
		
		</td>
		</tr>
<?
if(!$instalacion){
?>
		<tr>
			<td bgcolor="#FFFFFF">
			<p align="center"><b><i>Datos de la Base de Datos</i></b><i><b>:</b></i></td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF">
			<p align="center">
			<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table2">
				<tr>
					<td width="50%">
					<p align="right"><b>Servidor de la Base de Datos:</b></td>
					<td>&nbsp;<input type="text" size="20" name="server" value="localhost"></td>
				</tr>
				<tr>
					<td width="50%">
					<p align="right"><b>Nombre de la Base de Datos:</b></td>
					<td>&nbsp;<input type="text" size="20" name="db"></td>
				</tr>
				<tr>
					<td width="50%">
					<p align="right"><b>Usuario de la Base de Datos:</b></td>
					<td>&nbsp;<input type="text" size="20" name="usuario" value="root"></td>
				</tr>
				<tr>
					<td width="50%">
					<p align="right"><b>Contrase�a de la Base de Datos:</b></td>
					<td>&nbsp;<input type="password" size="20" name="password"></td>
				</tr>
				<tr>
					<td width="50%">
					<p align="right"><b>Nombre de la Tabla:</b></td>
					<td>&nbsp;<input type="text" size="20" name="tabla" value="web_noticias"></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF">
			<p align="center"><b><i>Datos del Administrador:</i></b></td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF">
			<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table3">
				<tr>
					<td width="50%">
					<p align="right"><b>Login del Administrador:</b></td>
					<td>&nbsp;<input type="text" size="20" name="nick"></td>
				</tr>
				<tr>
					<td width="50%">
					<p align="right"><b>Pass del Administrador:</b></td>
					<td>&nbsp;<input type="password" size="20" name="pass"></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF" height="33">
			<p align="center">
			<input type="submit" value="Instalar &gt;&gt;" name="submit"></td>
		</tr>
<?
}
?>
		<tr>
			<td bgcolor="#666666">
			<p align="center"><b><font color="#FFFFFF">Creado por Kenke -
			<a target="_blank" href="http://www.kenke.net">
			<font color="#FFFFFF">www.kenke.net</font></a></font></b></td>
		</tr>
	</table>
</div>
</form>