<?
function tiempo() {
list($a,$b) = explode(" ",microtime()) ;
$tiempo = $b + $a ;
return $tiempo ;
}
$tiempo_a = tiempo() ;
?>

Aqu� la p�gina

<?
$tiempo_b = tiempo() ;
$tiempo = round($tiempo_b - $tiempo_a,4) ;
echo "<div align=\"center\">Carga del servidor: <b>$tiempo</b></div>" ;
?>