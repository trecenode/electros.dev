<?
//////////////////////////////////////////
/                                        /
/   Mod Echo Por Daniel Gonzalez Toledo  /
/           www.yugioh-ds.com            /
/                                        /
/   si deseas quitar esto me da igual    /
/  pero si lo dejas me arias sentir muy  /
/                  Bien                  /
//////////////////////////////////////////


include("config.php") ;
function caretos($texto) {
$caretos = array(
":D"   => "alegre.gif",
":P"   => "burla.gif",
":(1"  => "demonio.gif",
":?"   => "duda.gif",
";)"   => "guino.gif",
":lol" => "lol.gif",
":|"   => "neutral.gif",
":-)"  => "sonrisa.gif",
":O"   => "sorprendido.gif",
":8"   => "asustado.gif",
":S"   => "confundido.gif",
":(2"  => "demonio2.gif",
":-("  => "enojado.gif",
":/("  => "llorar.gif",
":M"   => "moda.gif",
":)"   => "risa.gif",
":R"   => "sonrojado.gif",
":("   => "triste.gif",
) ;
foreach($caretos as $a => $b) {
$texto = str_replace($a,"<img src=\"eforo_imagenes/caretos/$b\" width=\"15\" height=\"15\">",$texto) ;
}
return $texto ;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($n) {
$resp = mysql_query("select * FROM noticias where id='$n'") ;
$datos = mysql_fetch_array($resp) ;
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Se agregar�n los espacios correspondientes a la noticia extendida
$noticia = $datos[noticia] ;
$noticiaext = $datos[noticiaext] ;
$noticiaext = str_replace("\r\n","<br>",$noticiaext) ;
// Funci�n para transformar URLs en enlaces en la noticia extendida
$noticiaext = str_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$noticiaext) ;
// Codigo especial bbcode en la noticia extendida: [b]texto negrita[/b], [img]eforo_imagenes/carpeta.gif[/img]
$noticiaext = str_replace("[b]","<b>",$noticiaext) ;
$noticiaext = str_replace("[/b]","</b>",$noticiaext) ;
$noticiaext = str_replace("[img]","<img src=\"",$noticiaext) ;
$noticiaext = str_replace("[/img]","\" border=\"0\">",$noticiaext) ;
$noticiaext = str_replace("/\[url\](www\..+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\1</a>",$noticiaext) ;
$noticiaext = str_replace("/\[url\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>",$noticiaext) ;
$noticiaext = str_replace("/\[url=(www\..+)\](.+)\[\/url\]/i","<a href=\"http://\\1\" target=\"_blank\">\\2</a>",$noticiaext) ;
$noticiaext = str_replace("/\[url=(.+)\](.+)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\2</a>",$noticiaext) ;
$noticiaext = eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]", "<a target=\"_blank\" href=\"\\1\">\\2</a>", $noticiaext); 
$datos[noticia] = caretos($datos[noticia]) ;
// Colorear el codigo php en la noticia extendida, utilizar: [codigo]codigo php aqui[/codigo]
if(strstr($noticiaext,"[codigo]")) {
$partes = explode("[codigo]",$noticiaext) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$noticiaext = implode("",$partes) ;
}
// fin colorear codigo php en la noticia extendida
?>

<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr>
<td width="47%" class="tabla_titulo"><p class=t1><? echo $datos[titulo] ?></p></td>
<td width="53%" class="tabla_titulo"><div align=right><? echo $fecha ?></div></td>
</tr>
<tr>
<td colspan=2 class="tabla_mensaje">
<? echo $datos[noticia] ?><br><br>
<? echo $noticiaext ?><br><br>
<b>Enviada por:</b> <? echo $datos[usuario] ?><br>
<a href="main.php">� Regresar a la p�gina principal</a>
<p>
<?
mysql_free_result($resp) ;
echo "<p><b>Comentarios</b>" ;
// Mostrar la lista de comentarios de 5 en 5
$mostrar = 5 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * FROM noticiascom where noticia='$n' ORDER BY id desc LIMIT $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mas comentarios." ; }
else {
$comentarios = mysql_num_rows($resp) ;
// mostrar el total de comentarios
$resp2 = mysql_query("select * FROM noticiascom where noticia='$n' ORDER BY id desc") ;
$comentarios2 = mysql_num_rows($resp2) ;
?>
<p><b>Total de comentarios:</b> <? echo $comentarios2 ?>
<p>
<?
while($datos = mysql_fetch_array($resp)) {
// Mostrar fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// Codigo especial bbcode en los comentarios: [b]texto negrita[/b], [img]eforo_imagenes/carpeta.gif[/img]
$datos[comentario] = str_replace("[b]","<b>",$datos[comentario]) ;
$datos[comentario] = str_replace("[/b]","</b>",$datos[comentario]) ;
$datos[comentario] = str_replace("[img]","<img src=\"",$datos[comentario]) ;
$datos[comentario] = str_replace("[/img]","\" border=\"0\">",$datos[comentario]) ;
$datos[comentario] = str_replace("[hr]","<hr>",$datos[comentario]) ;
$datos[comentario] = str_replace("[center]","<center>",$datos[comentario]) ;
$datos[comentario] = str_replace("[/center]","</center>",$datos[comentario]) ;
$datos[comentario] = str_replace("[i]","<i>",$datos[comentario]) ;
$datos[comentario] = str_replace("[/i]","</i>",$datos[comentario]) ;
$datos[comentario] = caretos($datos[comentario]) ;
// Colorear el codigo php en los comentarios, utilizar: [codigo]codigo php aqui[/codigo]
if(strstr($datos[comentario],"[codigo]")) {
$partes = explode("[codigo]",$datos[comentario]) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$datos[comentario] = implode("",$partes) ;
}
// fin colorear codigo php en los comentarios
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
  <tr> 
  <?
$resp3 = mysql_query("select avatar from usuarios where nick='$datos[usuario]'") ;
$datos3 = mysql_fetch_array($resp3) ;
if($datos3[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<td width=4% rowspan=2 class=tabla_subtitulo><center><img src=\"avatares/$datos3[avatar]\"></center> </td>" ;
}
echo $avatar ;
?>
<td  class="tabla_subtitulo"><b>&lt;<? echo $datos[usuario] ?>&gt;</b></td>
<td  class="tabla_subtitulo"><div align=right><b><? echo $fecha ?></b></div></td>
</tr>
<tr> 
<td colspan=2 class="tabla_mensaje"> <? echo $datos[comentario] ?> <br>
<?
// Mostrar la web del usuario que ha escrito en los comentarios
$resp4 = mysql_query("select id,web from usuarios where nick='$datos[usuario]'") ;
$datos4 = mysql_fetch_array($resp4) ;
if($datos4[web] == "") {
$web = "" ;
}
else {
$web = "<a href='$datos4[web]'target='_blank'>$datos4[web]</a>" ;
}
echo $web ;
?>
</td>
</tr>
</table><br>
<?
}
?>
<?
}
// mostrar siguientes 5 comentarios noticias
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=main.php?secc=noticias&n=$n>Anteriores $mostrar comentarios noticias</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=main.php?secc=noticias&n=$n&desde=$anteriores>Anteriores $mostrar comentarios noticias</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $comentarios2) {
echo "<a href=main.php?secc=noticias&n=$n&desde=$desde>Siguientes $mostrar comentarios noticias</a>" ;
}
if($desde > $comentarios2) {
echo "<a href=main.php?secc=noticias&n=$n&desde=$desde>Siguientes $mostrar comentarios noticias</a>" ;
}
mysql_free_result($resp) ;
?></td>
</tr>
<tr>
  <td class="tabla_mensaje"><p>
	<script language='Javascript'> 
function caretos(codigo) {
formulario.comentario.value += codigo ;
formulario.comentario.focus() ;
}
</script>
	<b>Escribir comentario</b>
    
    <p align="left"><a href="javascript:caretos('[b]texto[/b]')"><img src='botones/bold.gif' width="24" height="20" border="1" style="border: 1px #000000 solid; "></a><a href="javascript:caretos('[i]texto[/i]')"><img src='botones/italic.gif' width="24" height="20" border="1" style="border: 1px #000000 solid; "></a><a href="javascript:caretos('[u]texto[/u]')"><img src='botones/under.gif'width="24" height="20" border="1" style="border: 1px #000000 solid; "></a><a href="javascript:caretos('[img]http://[/img]')"><img src='botones/img.gif' width="24" height="20" border="1" style="border: 1px #000000 solid; "></a><a href="javascript:caretos('[hr]')"><img src='botones/hr.gif' width="24" height="20" border="1" style="border: 1px #000000 solid; "></a><a href="javascript:caretos('[center]Texto[/center]')"><img src='botones/center.gif'width="24" height="20" border="1" style="border: 1px #000000 solid; "></a>
<form method=post action="noticiascom.php" name="formulario">
      <input type="hidden" name="noticia" value="<? echo $n ?>" >
  Comentario:<br>
  <textarea name="comentario" cols="30" rows="5" class="form"></textarea>
  <br>
  <br>
  <input type="submit" name="enviar" value="Enviar" class="form">
    </form></td>
  <td class="tabla_mensaje"><a href="javascript:caretos(':D')"><img src='eforo_imagenes/caretos/alegre.gif' border='0'></a> <a href="javascript:caretos(':P')"><img src='eforo_imagenes/caretos/burla.gif' border='0'></a> <a href="javascript:caretos(':(1')"><img src='eforo_imagenes/caretos/demonio.gif' border='0'></a> <a href="javascript:caretos(':?')"><img src='eforo_imagenes/caretos/duda.gif' border='0'></a> <a href="javascript:caretos(';)')"><img src='eforo_imagenes/caretos/guino.gif' border='0'></a> <a href="javascript:caretos(':lol')"><img src='eforo_imagenes/caretos/lol.gif' border='0'></a><br>
    <a href="javascript:caretos(':|')"><img src='eforo_imagenes/caretos/neutral.gif' border='0'></a> <a href="javascript:caretos(':-)')"><img src='eforo_imagenes/caretos/sonrisa.gif' border='0'></a> <a href="javascript:caretos(':O')"><img src='eforo_imagenes/caretos/sorprendido.gif' border='0'></a> <a href="javascript:caretos(':8')"><img src='eforo_imagenes/caretos/asustado.gif' border='0'></a> <a href="javascript:caretos(':S')"><img src='eforo_imagenes/caretos/confundido.gif' border='0'></a> <a href="javascript:caretos(':(2')"><img src='eforo_imagenes/caretos/demonio2.gif' border='0'></a><br>
    <a href="javascript:caretos(':-(')"><img src='eforo_imagenes/caretos/enojado.gif' border='0'></a> <a href="javascript:caretos(':/(')"><img src='eforo_imagenes/caretos/llorar.gif' border='0'></a> <a href="javascript:caretos(':M')"><img src='eforo_imagenes/caretos/moda.gif' border='0'></a> <a href="javascript:caretos(':)')"><img src='eforo_imagenes/caretos/risa.gif' border='0'></a> <a href="javascript:caretos(':R')"><img src='eforo_imagenes/caretos/sonrojado.gif' border='0'></a> <a href="javascript:caretos(':(')"><img src='eforo_imagenes/caretos/triste.gif' border='0'></a> </td>
</tr>
</table>
<?
}
else {
$mostrar = 10 ;
$resp = mysql_query("select * FROM noticias ORDER BY id desc LIMIT $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
// Mostrar la fecha en texto
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano" ;
// caretos
$datos[noticia] = caretos($datos[noticia]) ;
// definir la suma del total de comentarios en una noticia
$resp2 = mysql_query("select id FROM noticiascom where noticia='$datos[id]'") ;
$comentarios = mysql_num_rows($resp2) ;
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr> 
<td colspan="2" class="tabla_titulo"><p class=t1><? echo $datos[titulo] ?></p></td>
<td class="tabla_titulo"><div align=right><? echo $fecha ?></div></td>
</tr>
<tr> 
<td colspan=3 class="tabla_mensaje"> <? echo $datos[noticia] ?>&nbsp;</td>
</tr>
<tr> 
<td class="tabla_mensaje"><a href="main.php?secc=noticias&n=<? echo $datos[id] ?>" >Ver 
m�s</a> </td>
<td class="tabla_mensaje"><b>Comentarios:</b> <? echo $comentarios ?></td>
<td class="tabla_mensaje"><div align="right"><b>Enviada por: </b><? echo $datos[usuario] ?></div></td>
</tr>
</table>
<br>
<?
}
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>



