<form method="POST" action="insdb.php">
<table width="74%"  border="0">
  <tr>
    <th colspan="2" scope="row">CREACION DE  TABLAS MEDIANTE UN FORMULARIO </th>
  </tr>
  <tr>
    <th width="61%" scope="row"><div align="left">Ingrese el nombre que le quiera poner a la tabla : </div></th>
    <td width="39%">
      <input type="text" name="ntabla">
    </td>
  </tr>
  <tr>
    <th height="107" scope="row"><div align="left">Ingrese aqui la estructura de la tabla : </div></th>
    <td>
      <textarea name="estructura" cols="45" rows="10" ></textarea>
    </td>
  </tr>
  <tr>
    <th scope="row"></th>
    <td><div align="center">
      <input type="submit" value="Enviar" name="enviar">
    </div></td>
  </tr>
</table>
</form>

<?
include ("config.php");

$ntabla =  $_POST['ntabla'];
$estructura = $_POST['estructura'];
$sql = "CREATE TABLE "  .$ntabla.  "(" .$estructura. ");";

if($_POST['enviar'])
{
if(!@mysql_query($sql, $conectar))

{

echo "Error".mysql_error();

}else{

echo "Tabla creada con �xito";
}
}
?>
