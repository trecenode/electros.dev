<?
// Por lo general es localhost pero tambi�n se usan URLs como www.electros.net o IPs como 32.64.128.255
$bdservidor = "localhost" ;
// Usuario de la base de datos
$bdusuario = "" ;
// Contrase�a de la base de datos
$bdcontrasena = "" ;
// Nombre de la base de datos
$bd = "nicop" ;

if($conectar = @mysql_connect($bdservidor,$bdusuario,$bdcontrasena)) {
@mysql_select_db($bd,$conectar) ;
}
else {
$error = mysql_error() ;
echo "No se pudo conectar a la base de datos por: <b>$error</b>" ;
}
?> 
