<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="descargas.php"><img src="down-logo.gif" alt="" width="221" height="42" border="0"></a><br>
          <br>
          <font class="content">[ <a href="descargas.php">Indice</a> | <a href="subir.php">A�adir 
          Descarga</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br> 
  <table width="50%" border="1" cellspacing="0">
    <tr>
      <td><div align="center">
          <?php include("descargas.txt"); #aqu� para cambiar la ruta del archivo que muestra las entradas 
		 ?>
        </div></td>
    </tr>
  </table>
  <br>
  <br>
</div>
