<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"><br>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><a href="http://www.phpmysql.tk">phpmysql.webcindario.com 
  </a></strong></font><br>
  <br>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">Para un correcto 
  fucionamiento del script<br>
  sustituye en las lineas del print los siguientes<br>
  caracteres <br>
  <br>
  los <font color="#FF0000">'</font> por <font color="#FF0000">&quot;<br>
  <br>
  </font>o directamente borra todos los<font color="#FF0000"> &quot;<br>
  <br>
  <font color="#0000FF">y si lo deseas borra tambien este archivo</font></font></font></div>
</body>
</html>
