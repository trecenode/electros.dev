<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center">
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="descargas.php"><img src="down-logo.gif" alt="" width="221" height="42" border="0"></a><br>
          <br>
          <font class="content">[ <a href="descargas.php">Indice</a> | <a href="subir.php">A�adir 
          Descarga</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br>
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td><div align="center"> 
          <?php
$pvm = getdate();
$archivo="descargas.txt"; #aqu� para cambiar la ruta del archivo donde se guardan las entradas 
$uusi="<table width=75% border=0 cellspacing=0 >
  <tr> 
    <td width=2% height='10'><font class=content ><img src=lwin.gif alt=Editar width=9 height=9 border=0></font></td>
    <td width=98% ><a href='http://$url'>$titulo</a></td>
  </tr>
  <tr> 
    <td height=11 colspan=2><b>Descripci�n:</b> $descripcion</td>
  </tr>
  <tr> 
    <td height=23 colspan=2><b>Versi�n: </b>$version <b>Tama�o del archivo: 
      </b>$tama�o<b> </b>Kb</td>
  </tr>
  <tr> 
    <td height=23 colspan=2><b>Agregado el: </b>$pvm[mday]-$pvm[mon]-$pvm[year]</td>
  </tr>
  <tr> 
    <td height=23 colspan=2><a href=http://$weburl target=new>P�gina de 
      Inicio</a> | <a href=mailto:$email?subject=hay_un_enlace_roto >Informar de un enlace roto</a></td>
  </tr>
</table><br>\n\n";
$fp=fopen($archivo, "r+");
$vanha=fread($fp, filesize($archivo));
fseek($fp, 0);
fwrite($fp, "${uusi}${vanha}");
fclose($fp);


print "Descarga a&ntilde;adida <a href=descargas.php>regresar</a>";
?>
        </div></td>
    </tr>
  </table>
</div>
<div align="center"></div>
</body>
</html>
