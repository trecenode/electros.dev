<SCRIPT type=text/javascript>
maximo = 1024 ;
function regresar(a) {
	a.direction='down' ; a.scrollAmount=8 ;
}
function adelantar(a) {
	a.direction='up' ; a.scrollAmount=8 ;
}
function continuar(a) {
	a.direction='up' ; a.scrollAmount=2 ;
}
function detener(a) {
	a.direction='up' ; a.scrollAmount=0 ;
}
      </SCRIPT>


<TABLE width=147 
      border=0 align="center" cellPadding=2 cellSpacing=0 class=tabla_principal>
        <TBODY>
        <TR>
          <TD width="143" class=tabla_titulo>
            <DIV class=t1 align=right>Ultimos Post </DIV></TD></TR>
        <TR>
          <TD class=tabla_mensaje vAlign=top height=257>
            <MARQUEE id=m onmouseover=this.stop() onmouseout=this.start() 
            scrollAmount=2 direction=up width="155" height=250 
            align="center">
<?
//**************Edita s�lo esta parte, configuraci�n de marquee***********************************//

$mostrarmensajes = "13"; //N�mero de mensajes que se mostrar�n. 
$caracteres = "60"; //Numero de caracteres que se mostraran por mensaje. 

//******************** Hasta aqu� llegas, no modifiques nada a partir de aqu�, si no sabes lo que haces, puedes causar grave da�o******//

$mostrar = $mostrarmensajes-1;
include("config.php"); 
echo " 
<script type=text/javascript> 
function sobre(texto) { subnav.innerHTML = texto; } 
function fuera(texto) { subnav.innerHTML = \"<a href=index.php?id=foro>&nbsp;&nbsp;&nbsp;Ir a los Foros</a>\" } 
</script> 

"; 

$conexion = mysql_connect($dbhost,$dbuser,$dbpass); 
mysql_select_db($db,$conexion); 
$resultado = mysql_query("select * from eforo_mensajes order by ultimo desc"); 
$rows = mysql_fetch_array($resultado);
$i = 0; 
while ($rows = mysql_fetch_array($resultado)) { 
        if ($i <= $mostrar) { 
                $consulta1 = "select * from eforo_mensajes where id='$rows[id]'"; 
                $resultado1 = mysql_query($consulta1); 
                $datos1 = mysql_fetch_array($resultado1); 
                $consulta2 = "select * from eforo_foros where id='$rows[foro]'"; 
                $resultado2 = mysql_query($consulta2); 
                $datos2 = mysql_fetch_array($resultado2); 

                if (strlen($rows[mensaje]) > $caracteres) { 
                        $rows[mensaje] = substr($rows[mensaje],0,$caracteres)."..."; 
                } 

                echo "�<b>�</b>&nbsp;<img src=eforo_imagenes/usuario2.gif>&nbsp;&nbsp;$rows[usuario]:<br><br><a href=\"index.php?id=foro&foroid=$datos2[id]&temaid=$rows[forotema]\" onmouseover='sobre(\"&nbsp;&nbsp;&nbsp;� Foro: <b>$datos2[foro]</b></font>\")' onmouseout='fuera()'>$rows[mensaje]</a><br><br><hr><br>";
                $i++; 
        } 
} 
?>
            </MARQUEE><BR></TD></TR>
        <tr>
          <TD class=tabla_mensaje vAlign=top height=15>
            <p align="center"><? echo "<br><table width=153 border=0 cellpadding=0 cellspacing=0><tr><td id=subnav name=subnav><a href=index.php?id=foro>&nbsp;&nbsp;&nbsp;Ir a Los Foros</a></td></tr></table>"; ?></TD>
        </tr>
        <tr>
          <TD class=tabla_mensaje vAlign=top height=14>
            <p align="center"><A name=#a></A><A onmouseover=regresar(m) 
            onmouseout=continuar(m) href="javascript:regresar(m)"><IMG height=15 
            alt=Regresar src="eforo_imagenes/flecha_izq.gif" width=15 
            border=0></A> <A onmouseover=adelantar(m) onmouseout=continuar(m) 
            href="javascript:adelantar(m)"><IMG height=15 alt=Adelantar 
            src="eforo_imagenes/flecha_der.gif" width=15 border=0></A> </TD>
        </tr>
      </TBODY></TABLE>
      