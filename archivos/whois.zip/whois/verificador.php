<?
#*******************************************
#************Realizado Por:*****************
#**************eliascm36********************
#****************Email:*********************
#*********eliascm36@hotmail.com*************
#****************Fecha:*********************
#******Martes 06 de Diciembre del 2005******
#**********Creador de la Idea:**************
#****************Ironbye********************
#**************Graficos Por:****************
#***************Neubox.net******************
#****************Gracias.*******************
#****************Saludos.*******************
?>
<?
if($buscar){
//Checamos si el dominio existe (ponemos la arroba para que en caso de que no exista no muestre el error):
$check = @fsockopen("$dominio","80");
if ($check) {?>

<table border="1" cellspacing="0">
  <tr>
    <td width="54">Dominio:</td>
    <td width="67">Disponible:</td>
  </tr>
  <tr>
    <td valign="top"><strong>
      <?=$dominio?></strong></td>
    <td valign="top"><div align="center"><img src="no.gif" width="20" height="20"></div></td>
  </tr>
</table>
<?
}
else
{
?>
<table border="1" cellspacing="0">
  <tr>
    <td width="54">Dominio:</td>
    <td width="67">Disponible:</td>
  </tr>
  <tr>
    <td valign="top"><strong>
      <?=$dominio?>
    </strong></td>
    <td valign="top"><div align="center"><img src="si.gif" width="20" height="20"></div></td>
  </tr>
</table>
<?
}
}
?>
<?
?> 
<p>Verifica si tu dominio esta disponible:</p>
<form name="form1" method="post" action="">
  <p>www.
    <input name="dominio" type="text" id="dominiof">
  </p>
  <p>
    <input name="buscar" type="submit" id="buscar" value="Buscar">
</p>
</form>