<?
include("config.php") ;
if($_POST[enviar]) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$contrasena = quitar($contrasena) ;
$contrasena = md5(md5($contrasena)) ;
$con = mysql_query("select contrasena from usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($con) ;
if(mysql_num_rows($con) != 0) {
if($datos[contrasena] == $contrasena) {
setcookie("unick",$nick,time()+2592000) ;
setcookie("ucontrasena",$contrasena,time()+2592000) ;
header("location: $HTTP_REFERER") ;
}
else {
echo "La contrase�a es incorrecta. Haz click <a href=\"javascript:history.back()\">aqu�</a> para regresar." ;
}
}
else {
echo "Este usuario no existe en la base de datos. Haz click <a href=\"javascript:history.back()\">aqu�</a> para regresar." ;
}
}
?>