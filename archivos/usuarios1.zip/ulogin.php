<?
include("config.php") ;
$con = mysql_query("select id from usuarios where nick='$_COOKIE[unick]' and contrasena='$_COOKIE[ucontrasena]'") ;
if(mysql_num_rows($con) == 0) {
?>
<script>location="index.php"</script>
<?
exit ;
}
?>