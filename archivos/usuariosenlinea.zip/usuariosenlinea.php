<?
include("config.php") ;
$fecha = time() ;
$ip = $REMOTE_ADDR ;
$tiempo = 10 ; // Tiempo m�ximo en el cual se considerar� al usuario en l�nea en minutos.
$tiempo = $fecha-$tiempo*60 ;
mysql_query("delete from usuariosenlinea where fecha < $tiempo") ;
$resp = mysql_query("select ip from usuariosenlinea where ip='$ip'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("insert into usuariosenlinea (ip,fecha) values ('$ip','$fecha')") ;
}
else {
mysql_query("update usuariosenlinea set fecha='$fecha' where ip='$ip'") ;
}
mysql_free_result($resp) ;
$resp = mysql_query("select ip from usuariosenlinea") ;
$usuariosenlinea = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>