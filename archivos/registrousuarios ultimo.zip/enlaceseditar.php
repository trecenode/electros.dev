<?
include("login.php") ;
?>
<?
// Incluimos los datos
if(file_exists("enlaces/$e.php")) {
require ("enlaces/$e.php");
// Solo edita el usuario propietario y el administrador
if($_COOKIE["ucnnick"] != $administador){
if($nick_enlace != $_COOKIE["ucnnick"]) { die("No puedes editar este enlace."); }
}
}
// Editamos el enlace
if($editar && file_exists("enlaces/$e.php")) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}

$cnnick = quitar($nick_enlace) ;
$cnfecha = time() ;
$cntitulo = quitar($cntitulo) ;
$cndescripcion = quitar($cndescripcion) ;
$cnurl = quitar($cnurl) ;
$clicks = quitar($hits_enlace) ;
$imagen = quitar($imagen) ;

$edita .= "<"."?\n";
$edita .="\$nick_enlace = \"$cnnick\";\n";
$edita .="\$fecha_enlace = \"$cnfecha\";\n";
$edita .="\$titulo_enlace = \"$cntitulo\";\n";
$edita .="\$descripcion_enlace = \"$cndescripcion\";\n";
$edita .="\$url_enlace = \"$cnurl\";\n";
$edita .="\$hits_enlace = \"$clicks\";\n";
$edita .="\$imagen_enlace = \"$imagen\";\n";
$edita .= "?".">";

$edit = fopen("enlaces/$e.php","w");
fputs($edit,$edita);
fclose($edit);
echo "Enlace editado con �xito. Haz click <a href=index.php?id=enlaces>aqu�</a>.<br><br>" ;
}
?>
<p class="t1">Editar enlaces
</p>
<p>
<script>
function revisar() {
if(formulario.cnemail.value.length == 0) { alert('Debes poner un email v�lido.') ; return false ; }
if(formulario.cndescripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="<? $_SERVER['REQUEST_URI'] ?>" onsubmit="return revisar()">
  <b>Titulo :</b><br>
  <input name="cntitulo" type="text" class="form" id="cntitulo" value="<?=$titulo_enlace?>" maxlength="40">
  <br>
  <b>Descripcion :</b> <br>
  <textarea name="cndescripcion" cols="30" rows="5" class="form" id="cndescripcion"><?=$descripcion_enlace?></textarea>
  <br>
  <b>Url :</b><br>
  <input name="cnurl" type="text" class="form" id="cnurl" value="<?=$url_enlace?>" size="42">
  <br>
  <b>Imagen del enlace :</b><br>
  <input name="imagen" type="text" class="form" id="imagen" value="<?=$imagen_enlace?>" size="42">
  <br>
  <? if($imagen_enlace != "") { ?><br>
  <table width="1" border="0" cellpadding="0" cellspacing="1" bordercolor="#000000" bgcolor="#000000">
    <tr>
      <td><img src="<?=$imagen_enlace?>" width="80" height="80" border="0" onerror=this.onerror='null';this.src='fondo_titulo.gif'></td>
    </tr>
  </table>
  <? } ?>
  <br>
  
<input type="submit" name="editar" value="Editar" class="form">
</form>