<?
// Incluimos archivo de configuracion
@include("configuracion.php");
if (!$n) {
?>
<p class="t1">Mods</p>
<br>
En esta secci�n encontrar�s scripts mejorados o con nuevas opciones a partir de 
los scripts normales, son modificaciones personales creadas por nuestros usuarios 
que te pueden ser de mucha ayuda, si has creado tu propia modificaci�n de un script 
aqu� podr�s darlo a conocer<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><div align="center">
        <form name="mods" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
          <input name="campo" type="text" id="campo" class="form">
          <input name="buscar" type="submit" id="buscar" value="Buscar" class="form">
        </form>
      </div></td>
  </tr>
  <tr> 
    <td><div align="center"> 
        <table width="50%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><div align="left">
                <?
if($buscar){
// Incluimos todos los mods
if($campo != ""){
echo "<center>Resultados de la busqueda :</center><br>";
}
// Tomamos el total de mods
$archi = "mods/contador.txt";
$abrir = fopen($archi,"r");
$total_mods = fread($abrir, filesize($archi));
fclose($abrir);
// Recogemos la informacion de cada archivo
for($bn=0;$bn<$total_mods;$bn++){
if(file_exists("mods/$bn.php")) {
include("mods/$bn.php");
// Comprobamos que la palabra coincide
if($campo != ""){
if(eregi("$campo", $titulo_mod)){
echo "<a href='index.php?id=mods&n=$bn'><li> $titulo_mod $totalcampos</a></li>";
}
}
}
}
}
?>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<br>
<?
// Funcion para borrar los directorios
function deldir($dir)
{
  $handle = opendir($dir);
  while (false!==($FolderOrFile = readdir($handle)))
  {
     if($FolderOrFile != "." && $FolderOrFile != "..")
     {
     } 
  }
  closedir($handle);
  if(rmdir($dir))
  { $success = true; }
  return $success; 
} 

if($borrar) {
$_GET["borrar"];
@include("mods/$borrar.php");
// si el usuario borra un mensaje
if ($nick = $_COOKIE[ucnnick]) {
@unlink("mods/$borrar.php") ;
@unlink("mods/$borrar.zip") ;
// Borramos todos los comentarios existentes
for($bn=0;$bn<1000;$bn++){
@unlink("mods/$borrar/contador.txt") ;
@unlink("mods/$borrar/$bn.php") ;
}
// Borramos el directorio
@deldir("mods/$borrar");
echo "<p>La mod ha sido borrada con �xito. Haz click <a href=index.php?id=mods>aqu�</a> para regresar.<br><br>" ;
}
}
?>
<br>
<?php
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "mods/";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20;             // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['20 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
  $Counter++;
  
  $elemento1 = strtolower($elemento);
  
  if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".php","",$elemento);
?>
<?
if(file_exists("mods/$elemento2.php")) {
require ("mods/$elemento2.php");
// Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha_mod) ; $diames = date(j,$$fecha_mod) ; $mesano = date(n,$fecha_mod) - 1 ; $ano = date(Y,$fecha_mod) ;
$fecha_mod = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
}
$mod = substr($mod,0,255).".."; 
?><table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr> 
    <td width="69%"><div align="left"><a href="index.php?id=mods&n=<? echo $elemento2 ?>">- 
        <? echo $titulo_mod ?></a> 
	   <? 
	   if ($_COOKIE[ucnnick]) {
	   if ($_COOKIE[ucnnick] == $autor_mod or $autor_mod == $administador) { 
	   echo " [<a href='index.php?id=mods&borrar=$secciones$elemento2'>Borrar</a>] [<a href='index.php?id=modseditar&e=$secciones$elemento2'>Editar</a>]"; } } ?>
      </div></td>
    <td width="31%">Por : <a href="index.php?id=usuarios&u=<? echo $autor_mod ?>"><? echo $autor_mod ?></a></td>
  </tr>
</table>
<?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['20 Siguientes'] = 1;
}

//Cerramos el directorio
@closedir($dir);
?>
<div align="right"> 
  <?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?id=mods&c=".($Plus-$Config['Show'])."\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=mods&c=".($Plus+$Config['Show'])."\">20 Siguientes</a></p>");
}
?>
</div>
<? if ($n) {
if(file_exists("mods/$n.php")) {
require ("mods/$n.php");
}
// Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha_mod) ; $diames = date(j,$fecha_mod) ; $mesano = date(n,$fecha_mod) - 1 ; $ano = date(Y,$fecha_mod) ;
$fecha_mod = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
?>
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
<tr>
<td class="tabla_titulo"><p class=t1><? echo $titulo_mod ?></p></td>
<td class="tabla_titulo"><div align=right><? echo $fecha_mod ?></div></td>
</tr>
<tr>
    <td colspan=2 class="tabla_mensaje"> 
	<?
// Buscamos si el archivo existe y lo leemos
if(file_exists("mods/$n.txt")) {  
$archi = "mods/$n.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// bbcode o codigo especial
if ($bbcode != "off" ) {
$codigo = str_replace("[b]","<b>",$codigo) ;
$codigo = str_replace("[/b]","</b>",$codigo) ;
$codigo = str_replace("[img]","<img src=\"",$codigo) ;
$codigo = str_replace("[/img]","\" border=\"0\">",$codigo) ;

$codigo = str_replace("[u]","<u>",$codigo) ; 
$codigo = str_replace("[/u]","</u>",$codigo) ; 
$codigo = str_replace("[s]","<strike>",$codigo) ; 
$codigo = str_replace("[/s]","</strike>",$codigo) ; 
$codigo = str_replace("[sup]","<sup>",$codigo) ; 
$codigo = str_replace("[/sup]","</sup>",$codigo) ; 
$codigo = str_replace("[sub]","<sub>",$codigo) ; 
$codigo = str_replace("[/sub]","</sub>",$codigo) ; 
$codigo = str_replace("[left]","<left>",$codigo) ; 
$codigo = str_replace("[/left]","</left>",$codigo) ; 
$codigo = str_replace("[center]","<p align=center>",$codigo) ;
$codigo = str_replace("[/center]","</p>",$codigo) ;
$codigo = str_replace("[right]","<p align=right>",$codigo) ;
$codigo = str_replace("[/right]","</p>",$codigo) ;
// Inicio caretos : por defecto desactivados
// ya que esta demostrado que puede interferir con colorear el codigo
// para activarlos permanetemente pon if ($caretos != "off" ) {
if ($caretos == "on" ) {
$codigo = str_replace("[[","",$codigo) ;
$codigo = str_replace("]]","",$codigo) ;
$codigo = str_replace(":D","[[alegre.gif]]",$codigo) ;
$codigo = str_replace(":8","[[asustado.gif]]",$codigo) ;
$codigo = str_replace(":P","[[burla.gif]]",$codigo) ;
$codigo = str_replace(":S","[[confundido.gif]]",$codigo) ;
$codigo = str_replace(":(1","[[demonio.gif]]",$codigo) ;
$codigo = str_replace(":(2","[[demonio2.gif]]",$codigo) ;
$codigo = str_replace(":?","[[duda.gif]]",$codigo) ;
$codigo = str_replace(":-(","[[enojado.gif]]",$codigo) ;
$codigo = str_replace(";)","[[guino.gif]]",$codigo) ;
$codigo = str_replace(":'(","[[llorar.gif]]",$codigo) ;
$codigo = str_replace(":lol","[[lol.gif]]",$codigo) ;
$codigo = str_replace(":M","[[moda.gif]]",$codigo) ;
$codigo = str_replace(":|","[[neutral.gif]]",$codigo) ;
$codigo = str_replace(":)","[[risa.gif]]",$codigo) ;
$codigo = str_replace(":-)","[[sonrisa.gif]]",$codigo) ;
$codigo = str_replace(":R","[[sonrojado.gif]]",$codigo) ;
$codigo = str_replace(":O","[[sorprendido.gif]]",$codigo) ;
$codigo = str_replace(":(","[[triste.gif]]",$codigo) ;
$codigo = str_replace("[[","<img src=\"caretos/",$codigo) ;
$codigo = str_replace("]]","\" width=\"15\" height=\"15\">",$codigo) ;
}
// anti-insultos
$codigo = str_replace("capullo","***",$codigo) ;
$codigo = str_replace("cabron","***",$codigo) ;
$codigo = str_replace("hijo puta","***",$codigo) ;
$codigo = str_replace("maricon","***",$codigo) ;
$codigo = str_replace("puta","***",$codigo) ;
$codigo = str_replace("gay","***",$codigo) ;
// convertir enlaces a url
$codigo = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$codigo) ;
// colorear el codigo 
// by wwww.electros.tk
if(strstr($codigo,"[codigo]")) {
$partes = explode("[codigo]",$codigo) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$codigo = implode("",$partes) ;
} 
}
// Ponemos en el codigo los puntos y los espacios correspondientes.
$codigo = str_replace("\r\n","<br>",$codigo) ;
// Mostramos el codigo de la pagina
echo "$codigo";
} 
else 
{ 
echo "Este mod se esta actualizando o ya no existe.";
} 
?><br>
      <? if(file_exists("mods/$n.zip")) {?><center>
        [ <a href="mods/<?=$n?>.zip">Descargar archivo</a> ]
</center>
      <? } ?>
      <br>
<hr>
<b>Enviada por:</b> <? echo $autor_mod ?><br>
<a href="index.php?id=mods">� Regresar a la p�gina principal</a>
<p>

      <p><b>Total de comentarios:</b> 
        <?
if(file_exists("mods/$n/")) {
// Usuarios en linea
$path2 = "mods/$n/"; 
// Contar el total
$dir2 = opendir($path2);
$i = 0;
while ($elemento = readdir($dir2))
{
$elemento2 = strtolower($elemento);
if (strpos($elemento2, ".php") > 0) {
include("mods/$n/$elemento2");
$i++;
}
}
echo $i ;
closedir($dir2);
}
else {
echo "0" ;
}
?>
<br>
<br>
<?php
if(file_exists("mods/$n/")) {
                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "mods/$n/";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 5;             // Numero de archivos a mostrar por p�ginas.

$Show['5 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['5 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['5 Anteriores'] = 1;
$c--;
}
$Counter = 0; // Ponemos a 0 el contador
// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['5 Anteriores'] == 0) $Counter=$Counter-2; else {
$c = 2;
while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
$Show['5 Anteriores'] = 1;
$c--;
}
}
// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
$Counter++;
$elemento1 = strtolower($elemento); 
if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
include("mods/$n/$elemento1");
// Asignamos el archivo sin extension
$elemento2 = str_replace(".php","",$elemento);
// fecha
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto",
"Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha_modcom) ; $mesano = date(n,$fecha_modcom) - 1 ; $ano = date(Y,$fecha_modcom) ; $hora = date("h:i A",$fecha_modcom) ;
$fecha_modcom = "$diames $mesesano[$mesano] $ano $hora" ;
// Espacios correspondientes en comentarios
$comentario = str_replace("\r\n","<br>",$comentario) 
?> 
<table width=100% border=0 cellpadding=5 cellspacing=0 class='tabla_principal'>
        <tr> 
          <td  class="tabla_subtitulo"><b>&lt;<? echo $nick_modcom ?>&gt;</b></td>
          <td  class="tabla_subtitulo"><div align=right><b><? echo $fecha_modcom ?></b></div></td>
        </tr>
        <tr> 
          <td height="4" colspan=2 class="tabla_mensaje"> <? echo $comentario ?> 
          </td>
        </tr>
</table>
      <br>
      <?
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['5 Siguientes'] = 1;
}
//Cerramos el directorio
@closedir($dir);
?>
      <div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['5 Anteriores'] == 1) echo("<a href=\"index.php?id=mods&c=".($Plus-$Config['Show'])."&n=$n\">5 Anteriores | </a>");
if ($Show['5 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=mods&c=".($Plus+$Config['Show'])."&n=$n\">5 Siguientes</a></p>");
}
?>
</div>

<p><br>
<?
if($enviar){
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
$texto = stripslashes($texto) ;
return $texto ;
}

// distinge entre nick registrado y nick anonimo
if ($_COOKIE[ucnnick]) {
$cnnick = $_COOKIE[ucnnick];
}
else {
$cnnick = "No Registrad@";
}

$cnfechacom = time() ;
$cncomentario = quitar($cncomentario) ;

$nuevo .= "<"."?\n";
$nuevo .="\$nick_modcom = \"$cnnick\";\n";
$nuevo .="\$fecha_modcom = \"$cnfechacom\";\n";
$nuevo .="\$modcom = \"$cnmod\";\n";
$nuevo .="\$comentario = \"$cncomentario\";\n";
$nuevo .= "?".">";

// a�adimos la nueva mod a contador.txt
if(!file_exists("mods/$n")) { mkdir("mods/$n", 0777); }
if(!file_exists("mods/$n/contador.txt")) { $ncrea = fopen("mods/$n/contador.txt","w"); fwrite($ncrea, "0"); fclose($ncrea); }

$file = "mods/$n/contador.txt"; 
$nclicks = fopen($file,"r+");
$clicks = fgets($nclicks,1024); 
$clicks++; 
rewind($nclicks);
fwrite($nclicks,$clicks);
fclose($nclicks);

$new = fopen("mods/$n/$clicks.php","w");
fputs($new,$nuevo);
fclose($new);

echo "<script>location='index.php?id=mods&n=$n'</script>";
}
?>
        <br>
        <b>Escribir comentario</b> 
      <form method=post action="index.php?id=mods&n=<? echo $n?>">
<input type="hidden" name="cnmod" value="<? echo $n ?>" >
Comentario:<br>
<textarea name="cncomentario" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
</td>
</tr>
</table>
<?
}
?>
</body>
