<?
if($entrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($cnnick) ;
$cnpass = quitar($cnpass) ;

if(file_exists("usuarios/$cnnick.php")) {
require ("usuarios/$cnnick.php");
// Comprobamos que la contrase�a sea igual a la del usuario
if($contrasena == md5($cnpass)) {
setcookie("ucnnick",$cnnick,time()+7776000) ;
setcookie("ucnpass",$cnpass,time()+7776000) ;
// Enviamos al usuario a la pagina principal
header("location: $id") ;
}
else {
echo "La contrase�a es incorrecta. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
}
}
else {
echo "Este usuario no existe en la base de datos." ;
}
}
else {
echo "
<form method=post action=entrar.php>
<b>Nick:</b><br>
<input type=text name=cnnick maxlength=20><br>
<b>Contrase�a:</b><br>
<input type=cnpassword name=cnpass maxlength=20><br><br>
<input type=submit name=entrar value=Entrar>
</form>
" ;
}
?> 