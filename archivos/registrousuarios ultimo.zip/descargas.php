<div class="t1">Descargas</div>
<br>
<br>
<div align="center">
<!-- inicio categorias -->
  <table width='50%' border='0' cellpadding='0' cellspacing='0' align='center' >
<?
// Incluimos archivo de configuracion
@include("configuracion.php");
// configuramos el directorio que queremos listar:
if(!file_exists("descargas/")) { mkdir("descargas/", 0777); }
if($secciones != "") { $sec = "<a  href='javascript:history.go(-1);'>- Anterior</a>" ; }
if($secciones == "") { $web = "descargas/" ; }
if($secciones != "") { $web = "descargas/$secciones" ; }
$dir = opendir("$web") ;
$parimpar = 0 ;
echo "<table width=50%  border=0 cellspacing=0 cellpadding=0><tr><td>$sec</td></tr></table>";
echo "<table width=50%  border=0 cellspacing=0 cellpadding=0>" ;
while ($file = readdir($dir)) {
$parimpar++ ;
// evitamos q muestre los puntos de volver al directorio superior
if(eregi("config.php", $file)){
echo "<script>location.href='index.php?id=descargas'</script>";
}

if(strpos($file, ".") < 1&& $file != "." && $file != ".."&& $file != "error_log") {
// Contar el total
$dir2 = opendir("descargas/".$secciones.$file);

        $i = 0;

        while ($elemento = readdir($dir2))
        {
            $elemento = strtolower($elemento);

            if ((strpos($elemento, ".php") > 0) && $elemento != "index.php")

            $i++;
        }
//mostramos columnas
   if($parimpar % 2 == 1) { echo "<tr>
<td height='30%'><div align='left'>�
<a  href='index.php?id=descargas&secciones=$secciones$file/'>$file</a> ($i) </div>
" ; }
   if($parimpar % 2 == 0) { echo "
<td height='30%'><div align='left'>�
<a  href='index.php?id=descargas&secciones=$secciones$file/'>$file</a> ($i) </div>
</tr>" ; }
} }

// si el numero de archivos es impar a�adimos esta columna para no descudrar la tabla
if($parimpar % 2 == 1) { echo "<td>&nbsp;</td></tr>" ; }

closedir($dir);
?>  
</table>
<!-- fin categorias --><br>
<br>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td><div align="center"> 
          <form name="descargas" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
            <input name="campo" type="text" id="campo" class="form">
            <input name="buscar" type="submit" id="buscar" value="Buscar" class="form">
          </form>
        </div></td>
    </tr>
    <tr> 
      <td><div align="center"> 
          <table width="50%" border="0" cellspacing="0" cellpadding="0">
            <tr> 
              <td><div align="left"> 
                  <?
if($buscar){
// Incluimos todos los descargas
if($campo != ""){
echo "<center>Resultados de la busqueda :</center><br>";
}
// Tomamos el total de descargas
$archi = "descargas/contador.txt";
$abrir = fopen($archi,"r");
$total_descargas = fread($abrir, filesize($archi));
fclose($abrir);
// Recogemos la informacion de cada archivo
for($bn=0;$bn<$total_descargas;$bn++){
if(file_exists("descargas/$secciones$bn.php")) {
include("descargas/$secciones$bn.php");
// Comprobamos que la palabra coincide
if($campo != ""){
if(eregi("$campo", $titulo_descarga)){
echo "<a href='descargas.php?e=$secciones$bn'><li> $titulo_descarga</a></li>";
}
}
}
}
}
?>
                </div></td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
  <br>
</div>
<b>Categor�a:</b> 
<? if($secciones != "./") { ?>
<?
// Nombre del archivo
if($secciones != "") {
$secciones2 = str_replace("/"," > ",$secciones);
echo "$secciones2";
}
else
{
echo "Principal";
}
?>
<? } else {echo "Principal";}?>
<br>
<br>
<?
if($borrar && file_exists("descargas/$borrar.php")) {
$_GET["borrar"];
@include("descargas/$borrar.php");
// si el usuario borra un mensaje
if ($nick_descarga == $_COOKIE[ucnnick] or $_COOKIE[ucnnick] == $administador) {
@unlink("descargas/$borrar.php") ;
@unlink("descargas/$borrar.zip") ;
echo "<p>La descarga ha sido borrada con �xito. Haz click <a href=index.php?id=descargas>aqu�</a> para regresar.<br>" ;
}
}
?>
<?
if ($e && file_exists("descargas/$e.php")) {
include ("descargas/$e.php");

function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnnick = quitar($nick_descarga);
$cnfecha = quitar($fecha_descarga) ;
$cntitulo = quitar($titulo_descarga) ;
$cndescripcion = quitar($descripcion_descarga) ;
$cnhits = 1 + $hits_descarga ;
$cnarchivo = quitar($archivo_descarga) ;

$edita .= "<"."?\n";
$edita .="\$nick_descarga = \"$cnnick\";\n";
$edita .="\$fecha_descarga = \"$cnfecha\";\n";
$edita .="\$titulo_descarga = \"$cntitulo\";\n";
$edita .="\$descripcion_descarga = \"$cndescripcion\";\n";
$edita .="\$archivo_descarga = \"$cnarchivo\";\n";
$edita .="\$hits_descarga = \"$cnhits\";\n";
$edita .= "?".">";

$edit = fopen("descargas/$e.php","w");
fputs($edit,$edita);
fclose($edit);


echo "<script>location='descargas/$e.zip'</script>";
}
?>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="5" style='border: #757575 1 solid'>
  <tr bgcolor="#dddddd"> 
    <td width="23%" class="tabla_subtitulo"><strong>Titulo</strong></td>
    <td width="52%" class="tabla_subtitulo"><strong>Descripcion</strong></td>
    <td width="10%" class="tabla_subtitulo"> <strong>Tama&ntilde;o</strong></td>
    <td width="15%" class="tabla_subtitulo"><strong>Hits</strong></td>
  </tr>
  <?php
  
if($secciones == "") { $web = "descargas/" ; }
if($secciones != "") { $web = "descargas/$secciones" ; }

                                 // Le damos valor a las variables de configuraci�n
$Config['Path'] = "$web";         // Directorio donde stan los archivos a mostrar.
$Config['Show'] = 20;             // Numero de archivos a mostrar por p�ginas.

$Show['20 Anteriores'] = 0;        // Por defecto no se mostrara 10 Anteriores
$Show['20 Siguientes'] = 0;        // Por defecto no se mostrara 10 Siguientes

if ($c == "") $c = 0;            // Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
$dir = @opendir($Config['Path']);         // Abrimos el directorio donde estan los archivos
$Plus = $c;                    // Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
{
  $Show['20 Anteriores'] = 1;
  $c--;
}

$Counter = 0;            // Ponemos a 0 el contador

// Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = @readdir($dir))        // Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
}

// Mostramos el numero de archivos que se tienen que mostrar por p�gina.
while (($Counter != $Config['Show']) && ($elemento = @readdir($dir)))
{
  $Counter++;
  
  $elemento1 = strtolower($elemento);
  
  if (strpos($elemento1, ".php") > 0 && $elemento != "index.php") {
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".php","",$elemento);
?>
  <?
if(file_exists("descargas/$secciones$elemento2.php")) {
require ("descargas/$secciones$elemento2.php");
   // Dia
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha_descarga = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
$descripcion_descarga = str_replace("\r\n","<br>",$descripcion_descarga) ;
}
?>
  <tr> 
    <td valign="top" class="tabla_mensaje"><div align="left"><a href="descargas.php?e=<? echo $secciones ?><?php echo $elemento2 ?>" target="_blank">&middot; 
        <? echo $titulo_descarga ?></a> 
        <?
		if ($_COOKIE[ucnnick]) {
		if ($_COOKIE[ucnnick] == $nick_descarga or $_COOKIE[ucnnick] == $administador) { echo " [<a href='index.php?id=descargas&borrar=$secciones$elemento2&secciones=$secciones'>Borrar</a>] [<a href='index.php?id=descargaseditar&e=$secciones$elemento2&secciones=$secciones'>Editar</a>]"; 
		} 
		} 
		?>
        <? 
		if ($_COOKIE[ucnnick]) {
		if ($_COOKIE[ucnnick] == $nick_descarga && !file_exists("descargas/$secciones$elemento2.zip")) 
		{ echo "<br><div align=left><font color=red>Error : No existe la descarga <strong>$secciones/$elemento2.zip</strong> ,subela manualmente al ftp o contacte con el admin urgentemente.</font></div>"; }
		} ?>
      </div></td>
    <td valign="top" class="tabla_mensaje"><div align="left"><? echo $descripcion_descarga ?>&nbsp;</div></td>
    <td valign="top" class="tabla_mensaje"> <div align="left"> 
        <?  
// asignamos el tama�o de los archivo
if(file_exists("descargas/$secciones$elemento2.zip")) {
$elemento4 = "descargas/$secciones$elemento2.zip";
if(filesize($elemento4) > 1000000) {
$tamano = filesize($elemento4)/1024/1024;
$tamano = ceil($tamano) ;
echo "$tamano Mb";
}
else { 
if(filesize($elemento4) > 1000) {
$tamano = filesize($elemento4)/1024;
$tamano = ceil($tamano) ;
echo "$tamano Kb";
} 
else {
$tamano = filesize($elemento4);
$tamano = ceil($tamano);
echo "$tamano bytes";
} 
}
}
else {
echo "&nbsp;";
}
?>
      </div></td>
    <td valign="top" class="tabla_mensaje"><div align="left"><? echo $hits_descarga ?></div></td>
  </tr>
  <?php
  }
}
  
// Si sobran archivos pondremos el "10 Siguientes"
if ($elemento = @readdir($dir))
{
  $Show['20 Siguientes'] = 1;
}

//Cerramos el directorio
@closedir($dir);
?>
</table>
<div align="right">
<?php
// Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
if ($Show['20 Anteriores'] == 1) echo("<a href=\"index.php?id=descargas&c=".($Plus-$Config['Show'])."&secciones=$secciones\">20 Anteriores | </a>");
if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?id=descargas&c=".($Plus+$Config['Show'])."&secciones=$secciones\">20 Siguientes</a></p>");
?></div>
