Total : 
<?php
// http://www.drew-phillips.com/scripts/index.php
//set the two variables below
$dataFile = "online.txt";
$sessionTime = "5" ; //time in **minutes** to consider someone online before removing them
#####################################################
# No editing needed below
#####################################################
error_reporting(E_ERROR | E_PARSE);
if(!file_exists($dataFile)) {
	$fp = fopen($dataFile, "w+");
	fclose($fp);
}
$ip = $_SERVER['REMOTE_ADDR'];
$users = array();
$onusers = array();
$timeuser = time();
//get users part
$fp = fopen($dataFile, "r");
flock($fp, LOCK_SH);
while(!feof($fp)) {
	$users[] = rtrim(fgets($fp));
}
flock($fp, LOCK_UN);
fclose($fp);
// pagina actual
if($id == ""){ $paginactual = "principal";} else { 
if(file_exists("$id.php")) { $paginactual = $id ;} 
if(!file_exists("$id.php")) { $paginactual = "principal" ;}
}
// refer
$refer=$_SERVER['HTTP_REFERER'];
if($refer==""){
$refer="Su PC"; 
}
// usuario
if($ucnnick == ""){$nameuser = "!$paginactual";} else { $nameuser = "|$ucnnick|$paginactual|$refer"; }
//cleanup part
$x = 0;
$alreadyIn = FALSE;
foreach($users as $key => $data) {
	list( , $lastvisit) = explode("|", $data);
	if(time() - $lastvisit >= $sessionTime * 60) {
		$users[$x] = "";
	} else {
		if(strpos($data, $ip) !== FALSE) {
			$alreadyIn = TRUE;
			$users[$x] = "$ip|$timeuser$nameuser"; //update record
		}
	}
	$x++;
}
if($alreadyIn == FALSE) {
	$users[] = "$ip|$timeuser$nameuser";
}
//write file
$fp = fopen($dataFile, "w+");
flock($fp, LOCK_EX);
$totaluser = 0;
foreach($users as $single) {
	if($single != "") {
		fwrite($fp, $single . "\r\n");
		$totaluser++;
	}
}
flock($fp, LOCK_UN);
fclose($fp);
if($uo_keepquiet != TRUE) {
	echo $totaluser;
}
?>
<br>
Anonimos : 
<?
$fd_anonimo = fopen($dataFile, "r");
$contenido_anonimo = fread($fd_anonimo, filesize($dataFile));
fclose($fd_anonimo);

$fichero_anonimo = explode("!", $contenido_anonimo);
$fichero_anonimo = array_slice($fichero_anonimo, 0, -1);
$fichero_anonimo = array_reverse($fichero_anonimo);
$anonimos = count($fichero_anonimo);
echo $anonimos ;
?>
<br>
Registrados: 
<?
$registrados = $totaluser-$anonimos;
echo $registrados ;
?>
<br>
<?php
# Numero de registros que se mostraran por p�gina.
$limiteRegistros = "10";
# Ubicaci�n del fichero de texto.
$ficheroTexto = $dataFile;
# Leemos el contenido del fichero.
$fd = fopen($ficheroTexto, "r");
$contenido = fread($fd, filesize($ficheroTexto));
fclose($fd);
# Creamos el array.
$ficheroTexto = explode("\n", $contenido);
# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 0, -1);
# Ordenamos los elementos del array en orden inverso.
$ficheroTexto = array_reverse($ficheroTexto);
# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);
# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];
# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;
# Mostramos los registros limitandolos por medio de las variables de arriba.
for($iregistros = $mostrarDesde;  $iregistros < $registrosTotales AND $iregistros < $mostrarHasta; $iregistros++)
{
    $columna = split("\|",$ficheroTexto[$iregistros]);
	# Resultados
	if($columna[2]){
	echo "<a href='index.php?id=usuarios&u=$columna[2]&seccion=$columna[3]'>- $columna[2]</a><br>";
	}
}
# Solo si el total de registros es mayor a el limite de registros por p�gina
# mostraremos los enlaces para cada p�gina.
if($registrosTotales > $limiteRegistros)
{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);
	# Mostramos los enlaces.
echo "<div align='right'>";
	for($iregistros = 1; $iregistros <= $numeroPaginas; $iregistros++)
	{
		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $iregistros)
		{
			echo "| <b>".$iregistros."</b> |";
		}
		else
		{
			echo "| <a href=index.php?id=online&pag=".$iregistros.">".$iregistros."</a> |";
		}
	}
}
echo "</div>";
?>