<strong><font size="4">Foro</font></strong><br>
<br>
<?
if(!file_exists("foro/$archivo.dat")) { die("Este subtema ya no existe o a sido cambiado de sitio, <a href=javascript:history.back()>volver</a> ");}
// Obtenermos el archivo
$finalsubtema = md5("$archivo$subtema");
$file = "foro/$archivo.dat"; 
// Sumamos hits
if(!$enviar){
if(!file_exists("foro/$finalsubtema.log")){  
$fichero = fopen("foro/$finalsubtema.log","w"); 
fputs($fichero,"0"); 
fclose($fichero); 
}
if(file_exists("foro/$finalsubtema.log")){ 
$fp=fopen("foro/$finalsubtema.log","r");
$numero=fread($fp,filesize("foro/$finalsubtema.log"));
$clicks=1+$numero;
$fichero = fopen ("foro/$finalsubtema.log", "w");
fputs ($fichero,$clicks);
fclose ($fichero);
}
}
// Obtenemos el total de hits
if(file_exists("foro/$archivo.txt")){ 
$archi = "foro/$archivo.txt";
$abrir = fopen($archi,"r");
$hits = fread($abrir, filesize($archi));
fclose($abrir);
}
else {
$hits = "0";
}
//Se tramita el formulario y se guardan los nuevos datos.
if(!empty($opinion))
{
// bbcode para mayor seguridad
$nick = htmlspecialchars(trim($_POST['nick']));
$opinion = htmlspecialchars(stripslashes(trim($_POST["opinion"])));
$opinion = str_replace("\r\n", "<br>", $opinion);
$fecha = time();
// cambiamos | por ! en opinion
if($nick == "") { die("Pon un nick, <a href=javascript:history.back()>volver</a> ");}
if($opinion == "") { die("Pon una opinion, <a href=javascript:history.back()>volver</a> ");}
$opinion = str_replace("|", "/&/", $opinion);
$nick = str_replace("|", "/&/", $nick);
// creamos el fichero
$fichero = fopen($file, "a");
fwrite($fichero, "$nick|$opinion|$fecha|$tema|$subtema\r\n");
fclose($fichero);
echo "Comentario a�adido, <a href='$_SERVER[REQUEST_URI]'>pulsa aqui</a><br>";
}
# Numero de registros que se mostraran por p�gina.
$limiteRegistros = 50;
# Ubicaci�n del fichero de texto.
$ficheroTexto = $file ;
# Leemos el contenido del fichero.
$fd = @fopen($ficheroTexto, "r");
$contenido = @fread($fd, @filesize($ficheroTexto));
@fclose($fd);
# Creamos el array.
$ficheroTexto = explode("\n", $contenido);
# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 0, -1);
# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);
# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];
# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;
$mostrarde = ceil($registrosTotales / $limiteRegistros);
# Datos de la ultima columna del archivo
$abrir = fopen($file,"r");
$contenido = fread($abrir, filesize($file));
fclose($abrir);
$contenido_archivo = split("\r\n",$contenido);
$contenidoarchivo = split("\|",$contenido_archivo[0]);
$contenidoarchivo[1] = str_replace("/&/", "|", $contenidoarchivo[1]);
# bbcode
$contenidoarchivo[1] = str_replace("[codigo]","<table width='100%' border='0' cellpadding='4' cellspacing='0'><tr><td><font color='660002' face='Courier New, Courier, mono'>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/codigo]","</font></td></tr></table>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[b]","<b>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/b]","</b>",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[zip]","<table width='100%' border='0' cellpadding='4'><tr><td><div align='center'><a href=",$contenidoarchivo[1]) ;
$contenidoarchivo[1] = str_replace("[/zip]","> [Descargar achivo]</a></div></td></tr></table>",$contenidoarchivo[1]) ;
?>
<br>
Tema <strong> 
<a href="index.php?id=forotema&archivo=<?=$archivo?>"><?=$contenidoarchivo[0]?></a>
</strong> &gt;&gt; <strong> 
<?=$subtema?>
</strong> | <a href="index.php?id=forotema&archivo=<?=$archivo?>">Volver</a><br>
<br>
<br>
<table width='100%' border='0' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
  <tr bgcolor="#dddddd"> 
    <td colspan="4" valign="top" class="tabla_titulo">Subtema</td>
  </tr>
  <?
# Mostramos los registros limitandolos por medio de las variables de arriba.
for($i = $mostrarDesde;  $i < $registrosTotales AND $i < $mostrarHasta; $i++)
{
    # Analizamos los resultados
	$columna = split("\|",$ficheroTexto[$i]);
	# bbcode
	$columna[1] = str_replace("[codigo]","<table width='100%' border='0' cellpadding='4' cellspacing='0'><tr><td><font color='660002' face='Courier New, Courier, mono'>",$columna[1]) ;
	$columna[1] = str_replace("[/codigo]","</font></td></tr></table>",$columna[1]) ;
	$columna[1] = str_replace("[b]","<b>",$columna[1]) ;
	$columna[1] = str_replace("[/b]","</b>",$columna[1]) ;
	$columna[1] = str_replace("[zip]","<table width='100%' border='0' cellpadding='4'><tr><td><div align='center'><a href=",$columna[1]) ;
	$columna[1] = str_replace("[/zip]","> [Descargar achivo]</a></div></td></tr></table>",$columna[1]) ;
	$columna[1] = preg_replace("/\[img\]([^\[]*)\[\/img\]/i","<a href=\"\\1\" target=\"_blank\"><img src=\"\\1\" width='300' height='200' border='0'></a>",$columna[1]) ;
	$columna[1] = str_replace("[imagen]","<img src=\"",$columna[1]) ; 
	$columna[1] = str_replace("[/imagen]","\" border=\"0\">",$columna[1]) ;
	$columna[1] = str_replace("/&/", "|", $columna[1]);
	# Resultados del subtema
	if(ereg($columna[0],$subtema)){
	?>
  <tr> 
    <td height="44" colspan="4" valign="top" class="tabla_mensaje"><b> </b> 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="75%"><strong> <b>
            <?=$columna[0]?>
            </b> </strong></td>
          <td width="25%"><div align="right"> </div></td>
        </tr>
        <tr valign="top"> 
          <td colspan="2"> 
            <?=$columna[1]?>
          </td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr> 
    <td width='13%' valign="top" bgcolor="#dddddd" class="tabla_titulo">Nick </td>
    <td width='87%' colspan='3' valign="top" bgcolor="#dddddd" class="tabla_titulo">Opinion</td>
  </tr>
  <?
	}
	# Resultados de los comentarios del subtema
	if($columna[4]){
	if(ereg("$subtema",$columna[4])){
	?>
  <tr> 
    <td width='13%' valign="top" class="tabla_mensaje"> 
      <?=$columna[0]?>
    </td>
    <td width='87%' colspan='3' valign="top" class="tabla_mensaje"> 
      <?=$columna[1]?>
    </td>
  </tr>
  <?
	}
	}
	}
	?>
</table>
	<?
	# Solo si el total de registros es mayor a el limite de registros por p�gina
	# mostraremos los enlaces para cada p�gina.
	if($registrosTotales > $limiteRegistros)
	{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);
	# Mostramos los enlaces.
echo "<div align='right'>";
	for($i = 1; $i <= $numeroPaginas; $i++)

	{
		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $i)
		{
			echo "| <b>".$i."</b> |";
		}
		else
		{
			$archivo = str_replace(" ","%20",$archivo);
			echo "| <a href='index.php?id=forosubtema&pag=$i&archivo='$_GET[archivo]'&subtema='$subtema'>".$i."</a> |";
		}
	}
}
echo "</div><br>";

?>

<form name="form" method="post" action="<? $_SERVER['REQUEST_URI'] ?>">
  Nick :<br>
  <? 
  if($_COOKIE["ucnnick"]) {
  echo "<input name='nick' type='text' class='form' value='$_COOKIE[ucnnick]' style='color: #757575' readonly>";
  }
  else {
  echo "<input name='nick' type='text' class='form' value='Invitad@' style='color: #757575' readonly>";
  }
  ?>
  <br>
  Opinion : <br>
  [codigo]codigo php[/codigo] <br>
  [b]negrita[/b]<br>
  [zip]fichero.zip[/zip] <br>
  [img]miniatura.gif[/img] <br>
  [imgen]imagen.gif[/imagen] <br>
  <textarea name="opinion" cols="34" rows="13" class="form" id="opinion"></textarea>
  <br>
  <input name='tema' type='hidden' class='form' id="tema" value="<?=$contenidoarchivo[0]?>">
  <br>
<input name="enviar" type="submit" id="enviar" value="Enviar" class="form">
</form>