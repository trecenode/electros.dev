<?
if(!file_exists("torrent")) { mkdir("torrent", 0777); }
// CONTADOR
/* Crear archivos para el contador
for($i=1;$i<500;$i++){
$crea = fopen("contador/$i.txt","w");
fwrite($crea, "0"); 
fclose($crea);
}  
*/
$contador = "contador/$archivo.txt";
function leer($filename)
{
$fd = @fopen ($filename, "r");
$archivo = @fread ($fd, filesize ($filename));
@fclose ($fd);
//
if($archivo == ""){
$archivo = "0";
return $archivo;
}
else {
return $archivo;
}
//
}
//
if($archivo){
//
if(file_exists($contador)){ 
$hits = leer($contador);
$sumar = $hits+1;
$crea = fopen($contador,"w"); 
fwrite($crea, $sumar); 
fclose($crea);
echo "<script>location='$url'</script>";
//
}
if(!file_exists($contador)){ 
//
$crea = fopen($contador,"w"); 
fwrite($crea, "1"); 
fclose($crea);
echo "<script>location='$url'</script>";
//
}
}
?>
<div class="t1">Torrent links</div>
<div class="t1"></div>
<table width="28%" border="0" align="center" cellspacing="0">
  <tr> 
    <td width="47%"><a href="index.php?id=torrent&categoria=juegos">&middot; Juegos</a><br> 
    </td>
    <td width="53%"><a href="index.php?id=torrent&categoria=musica">&middot; Musica</a></td>
  </tr>
  <tr> 
    <td><a href="index.php?id=torrent&categoria=peliculas">&middot; Peliculas</a></td>
    <td><a href="index.php?id=torrent&categoria=drivers">&middot; Drivers</a></td>
  </tr>
  <tr> 
    <td><a href="index.php?id=torrent&categoria=programas">&middot; Programas</a></td>
    <td><a href="index.php?id=torrent&categoria=videoconsolas">&middot; Consolas</a></td>
  </tr>
  <tr>
    <td><a href="index.php?id=torrent&categoria=cracks">&middot; Cracks</a></td>
    <td><a href="index.php?id=torrent">&middot; Principal</a></td>
  </tr>
</table>
<br>
Para poder descargar los enlaces deberas disponer del programa Bitcomet, si no 
dispones de el puedes obtenerlo de su <a href="http://www.bitcomet.com/" target="_blank">pagina 
oficial</a> , los torrent se caracterizan por ser archivos cuya extension es .torrent 
son bastante rapidos de bajarse mas incluso que el emule, recomiendo tener abierto 
el programa cuando abres un torrent. 
<p align="left"> 
  <?php
// Incluimos archivo de configuracion
@include("configuracion.php");
# Paginaci�n de registros de un fichero de texto plano.
# http://www.quikescripts.tk
# Modificado por phpmysql.tk para mostrar los resultados de varias columnas

# Numero de registros que se mostraran por p�gina.
$limiteRegistros = 15 ;

# Leemos el fichero de texto como un array.
if($_COOKIE[ucnnick]){
if($_COOKIE[ucnnick] == $administador) {
if(!file_exists("torrent/$categoria.txt")) { $ncrea = fopen("torrent/$categoria.txt","w"); fwrite($ncrea, ""); fclose($ncrea); }
}
}
$ficheroTexto = @file("torrent/$categoria.txt");

# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);

# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];

# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Mostramos el total de registros
if($categoria == ""){ $cat = "principal";} else {$cat = $categoria;}
echo "<b>Categoria</b> $cat <b>,Total de registros :</b> ".$registrosTotales."<br><br>";
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;

# Mostramos los registros limitandolos por medio de las variables de arriba.
for($i = $mostrarDesde;  $i < $registrosTotales AND $i < $mostrarHasta; $i++)
{
    # Ver solo los dato que nos interesa, $ficheroTexto[$i] seria ver la linea entera
	# Tenemos el archivo separado en 5 columnas y cada columna separada por el caracter | que es igual que \|
	# Para cambiar el caracter de | por # u otro caracter, seria tan sencillo como poner en su lugar el caracter que deseemos usar como separador dentro de las lineas del archivo
    $columna = split( "#" , $ficheroTexto[$i]);
	$direccion = md5("$columna[1]");
	# Mostrarlos datos $columna[0] seria la primeria linea de la columna, $columna[1] la segunda,etc...
	echo "<a href='index.php?id=torrent&categoria=$categoria&archivo=$direccion&url=$columna[1]' target='_blank'>� $columna[0]</a> ("; 
	echo @leer("torrent/$direccion.txt"); 
	echo ") $columna[2]<br>";
    }
echo "<br>";
# Solo si el total de registros es mayor a el limite de registros por p�gina
# mostraremos los enlaces para cada p�gina.
if($registrosTotales > $limiteRegistros)
{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);

	# Mostramos los enlaces.
	for($i = 1; $i <= $numeroPaginas; $i++)
	{
		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $i)
		{
			echo "| <b>".$i."</b> |";
		}
		else
		{
			echo "| <a href=index.php?id=$id&categoria=$categoria&pag=".$i.">".$i."</a> |";
		}
	}
}

?>
  <br>
  <br>
  <br>
  <?
if($enviar){
// Quitamos el html
$nombre = htmlspecialchars(stripslashes(trim($_POST["nombre"])));
$url = htmlspecialchars(stripslashes(trim($_POST["url"])));
$desc = htmlspecialchars(stripslashes(trim($_POST["desc"])));

$crea = fopen("torrent/$categoria.txt","a"); 
fwrite($crea, "$nombre#$url#$desc\r\n"); 
fclose($crea);
echo "Tu enlace ha sido enviado con exito. Haz click <a href=index.php?id=torrent&categoria=$categoria>aqu�</a> para regresar a la p�gina principal.<br><br>" ;
}
?>
</p>
<form name="form1" method="post" action="">
  Nombre : 
  <input name="nombre" type="text" class="form" id="nombre">
  Url: 
  <input name="url" type="text" class="form" id="url" value="http://">
  Descripcion 
  <input name="desc" type="text" class="form" id="desc">
  <input name="enviar" type="submit" id="enviar" value="Enviar" class="form">
</form>

