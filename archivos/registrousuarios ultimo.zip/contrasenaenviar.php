<?
if($enviar) {
if(!$HTTP_COOKIE_VARS[ucnnick]) {
if($cnnick != "") {
include("usuarios/$cnnick.php") ;
$mensaje = "
Estos son tus datos de registro:

Nick: $nick
Contrase�a: $contrasena

Recuerda guardar bien tus datos.
" ;
mail($email,"Recuperaci�n de contrase�a",$mensaje) ;
setcookie("ucpass","ucnpass",time()+1800) ;
header("location: index.php?id=contrasena&confirmacion=si") ;
}
else {
header("location: index.php?id=contrasena&confirmacion=no") ;
}
}
else {
header("location: index.php?id=contrasena&confirmacion=esperar") ;
}
}
?> 