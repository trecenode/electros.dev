<?
// Borramos las cookies
setcookie("ucnnick") ;
setcookie("ucnpass") ;
header("location: index.php") ;
?>