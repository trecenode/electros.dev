<?
if(file_exists("usuarios/$_COOKIE[ucnnick].php")) {
require ("usuarios/$_COOKIE[ucnnick].php");
}
if($contrasena == $_COOKIE[ucnpass]) {
setcookie("ucnnick") ;
setcookie("ucnpass") ;
echo "<script>location='index.php'</script>" ;
}
?> 