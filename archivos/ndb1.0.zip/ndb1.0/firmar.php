<?
#**********************************************#
#*********Ram�n Emilio Torres Salom�n**********#
#************Raymondjavaxx Studios*************#
#************07:30 p.m. 27/06/2003*************#
#**************Santo Domingo R.D.**************#
#**********************************************#

#**Incluimos el fichero config.php**#
include("config.php");

#**Mensaje con interfase en html**#
$nuevo="<table border='0' cellpadding='0' cellspacing='2' style='border-collapse: collapse' bordercolor='#111111' width='100%' id='AutoNumber1'><tr><td width='100%'><b><a style='text-decoration: none' target='_blank' href='$web'>$nick:</a></b> $mensaje</td></tr></table>";

$fp=fopen($file, "r+");
$anterior=fread($fp, filesize($file));
fseek($fp, 0);
fwrite($fp, "${nuevo}\n${anterior}");
fclose($fp);


header("location:libro.php");

?>