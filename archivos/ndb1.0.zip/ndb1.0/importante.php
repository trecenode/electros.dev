<html>

<head>
<title>Importante</title>

</head>

<body>

<div align="center">
  <br>
  <strong><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
  <a href="http://www.raymondjavaxx.tk" style="text-decoration: none">www.Raymondjavaxx.tk</a></font></strong><br>
  <br>
  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">Puedes distribuir 
  este libro de forma gratuita</font></div>
<div align="center">
  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">siempre y cuando mantengas 
  de forma intacta la</font></div>
<div align="center">
  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">informaci�n del autor.</font><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><br>
  <br>
  </font>
  <font color="#0000FF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Puede 
  borrar este archivo si desea.</font></div>

</body>

</html>