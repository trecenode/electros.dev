<?

#**********************************************#
#*********Ram�n Emilio Torres Salom�n**********#
#************Raymondjavaxx Studios*************#
#************07:30 p.m. 27/06/2003*************#
#**************Santo Domingo R.D.**************#
#**********************************************#

#**Palabras censuradas**#
#**Puedes a�adir o quitar**#
$arr = str_replace("co�o", "c***", $arr);
$arr = str_replace("puta", "p***", $arr);
$arr = str_replace("fuck", "f***", $arr);
$arr = str_replace("joder", "j*d**", $arr);
$arr = str_replace("jodas", "j****s", $arr);

?>