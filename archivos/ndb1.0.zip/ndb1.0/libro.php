<?

#**********************************************#
#*********Ram�n Emilio Torres Salom�n**********#
#************Raymondjavaxx Studios*************#
#************07:30 p.m. 27/06/2003*************#
#**************Santo Domingo R.D.**************#
#**********************************************#

#**Incluimos el fichero config.php**#
include("config.php");
?>

<html>

<head>
<title></title>
</head>

<link href="estilo.css" rel="stylesheet" type="text/css">
<body leftmargin="0" topmargin="0">
<script>
function ventana(url_pop,width,height)
    {
     var PopWidth=width;
     var PopHeight=height;
     var PopLeft = (window.screen.width-PopWidth)/2;
     var PopTop = (window.screen.height-PopHeight)/2;
     df=window.open(url_pop,'df','toolbar=no,status=no,menubar=no,location=no,directories=no,resizable=no,scrollbars=yes,width='+PopWidth+',height='+PopHeight+',top='+PopTop+',left='+PopLeft);
     }

</script>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><strong><font face="Verdana, Arial, Helvetica, sans-serif" size="1">�
    <? print "$titulo" ?>�</font></strong></td>
  </tr>
</table>

<?

#**Incluimos el fichero config.php**#
include("config.php");
#**Creamos el array con las lineas del archivo**#
$arr=file($file);

#**Incluimos la tabla de smiles y palabras censuradas**#
include("adsmile.php");
include("censura.php");

$m1=$arr[0]; 
$m2=$arr[1]; 
$m3=$arr[2];
$m4=$arr[3]; 
$m5=$arr[4]; 
$m6=$arr[5]; 
$m7=$arr[6];
$m8=$arr[7];
$m9=$arr[8];
$m10=$arr[9];
$m11=$arr[10];
$m12=$arr[11];
$m13=$arr[12];
$m14=$arr[13];
$m15=$arr[14];


print "$m1 $m2 $m3 $m4 $m5 $m6 $m7 $m8 $m9 $m10 $m11 $m12 $m13 $m14 $m15";

?>
<form method="POST" action="firmar.php" name="libro">
  <table width="100%" cellspacing="0" cellpadding="0" class="tdform">
    <tr>
      <td width="33"><font size="1" face="Verdana">Nick:</font></td>
      <td width="99">
      <input type="text" maxlength="13" name="nick" size="13" class="imp"></td>
    </tr>
    <tr>
      <td width="33"><font size="1" face="Verdana">Web:</font></td>
      <td width="99">
      <input type="text" maxlength="50" name="web" size="13" value="http://" class="imp"></td>
    </tr>
    <tr>
      <td><font size="1" face="Verdana">Firma:</font></td>
      <td><textarea name="mensaje" cols="13" rows="2" class="imp"></textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Enviar" class="imp"> </td>
    </tr>
  </table>
</form>
<p align="center"><a href="javascript:ventana('smiles.htm','175','175')">Smiles</a></p>
<p align="center"><a target="_blank" href="http://www.raymondjavaxx.tk">Powered by:<br>
NDB Guestbook 1.0</a></p><p></p>

</body>

</html>
