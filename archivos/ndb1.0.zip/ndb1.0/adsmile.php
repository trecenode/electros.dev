<?
#**********************************************#
#*********Ram�n Emilio Torres Salom�n**********#
#************Raymondjavaxx Studios*************#
#************07:30 p.m. 27/06/2003*************#
#**************Santo Domingo R.D.**************#
#**********************************************#

#**Insertar Smiles**#
$arr = str_replace(":flecha:", "<img src='smiles/icon_arrow.gif' width='15' height='15'>", $arr);

$arr = str_replace(":D", "<img src='smiles/icon_biggrin' width='15' height='15'>", $arr);

$arr = str_replace(":conf:", "<img src='smiles/icon_confused.gif' width='15' height='15'>", $arr);

$arr = str_replace(":cool:", "<img src='smiles/icon_cool.gif' width='15' height='15'>", $arr);

$arr = str_replace(":llora:", "<img src='smiles/icon_cry.gif' width='15' height='15'>", $arr);

$arr = str_replace(":8:", "<img src='smiles/icon_eek.gif' width='15' height='15'>", $arr);

$arr = str_replace(":malo:", "<img src='smiles/icon_evil.gif' width='15' height='15'>", $arr);

$arr = str_replace(":idea:", "<img src='smiles/icon_idea.gif' width='15' height='15'>", $arr);


$arr = str_replace(":!:", "<img src='smiles/icon_exclaim' width='15' height='15'>", $arr);

$arr = str_replace(":lol:", "<img src='smiles/icon_lol.gif' width='15' height='15'>", $arr);

$arr = str_replace(":enojado:", "<img src='smiles/icon_mad.gif' width='15' height='15'>", $arr);

$arr = str_replace(":mrgreen:", "<img src='smiles/icon_mrgreen.gif' width='15' height='15'>", $arr);

$arr = str_replace(":-:", "<img src='smiles/icon_neutral.gif' width='15' height='15'>", $arr);

$arr = str_replace(":happy:", "<img src='smiles/icon_razz.gif' width='15' height='15'>", $arr);

$arr = str_replace(":rojizo:", "<img src='smiles/icon_redface.gif' width='15' height='15'>", $arr);

$arr = str_replace(":pensar:", "<img src='smiles/icon_rolleyes.gif' width='15' height='15'>", $arr);

$arr = str_replace(":smile:", "<img src='smiles/icon_smile.gif' width='15' height='15'>", $arr);

$arr = str_replace(":sorpr:", "<img src='smiles/icon_surprised.gif' width='15' height='15'>", $arr);

$arr = str_replace(":chiflado:", "<img src='smiles/icon_twisted.gif' width='15' height='15'>", $arr);

$arr = str_replace(":gui�o:", "<img src='smiles/icon_wink.gif' width='15' height='15'>", $arr);

$arr = str_replace(":?:", "<img src='smiles/icon_question.gif' width='15' height='15'>", $arr);

#**Comunes**#
$arr = str_replace(":)", "<img src='smiles/icon_smile.gif' width='15' height='15'>", $arr);

$arr = str_replace(":(", "<img src='smiles/icon_sad.gif' width='15' height='15'>", $arr);

?>