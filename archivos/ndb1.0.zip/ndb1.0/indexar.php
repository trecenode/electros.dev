<html>

<head>
<meta http-equiv="Content-Language" content="es-mx">
<title>NDB Guestbook - Raymondjavaxx Studios</title>
</head>

<body bgcolor="#FFFFFF">

<link href="estilo.css" rel="stylesheet" type="text/css">
<p><iframe name="libro" width="145" height="320" align="right" src="libro.php">El 
explorador no admite los marcos flotantes o no est� configurado actualmente para 
mostrarlos.</iframe></p>
<p><b><font size="4" color="#000080">NDB</font><font size="4" color="#000080"> Guestbook 
1.0</font></b></p>
<p><font color="#FF6600"><i><b>Caracter�sticas:</b></i></font></p>
<p><b>1. No usa base de datos.</b></p>
<p><b>2. Muestra los �ltimos 15 mensajes publicados.</b></p>
<p><b>3. Colores modificables mediante CSS.</b></p>
<p><b>4. Titulo y nombre de fichero usado como base de datos editables mediante 
el fichero &quot;edit.php&quot;.</b></p>
<p><b>5. F�cil instalaci�n: Subir al servidor y usar.</b></p>
<p><b>6. Nombre de usuario con acceso directo a su p�gina de Internet.</b></p>
<p>&nbsp;</p>
<p><b><font size="2">a) Copia y pega este c�digo html en tu p�gina.</font></b></p>
<p><textarea rows="9" name="codigo" cols="73">&lt;p&gt;
&lt;iframe name=&quot;libro&quot; width=&quot;145&quot; height=&quot;320&quot; align=&quot;right&quot; src=&quot;libro.php&quot;&gt;
El explorador no admite los marcos flotantes o no est� configurado actualmente para mostrarlos.
&lt;/iframe&gt;
&lt;/p&gt;</textarea></p>
<p><font size="2"><b>b) Descarga los archivos todos los archivos necesarios</b></font><b><font size="2">.</font></b></p>
<p><font size="2"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </b>
</font><font size="2"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</b></font></p>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="197" id="AutoNumber1">
    <tr>
      <td width="46"><a href="ndb1.0.zip">
      <img border="0" src="download.gif" width="30" height="30"></a></td>
      <td width="151">&nbsp;<a href="ndb1.0.zip">Descargar 28.2kb.</a></td>
    </tr>
  </table>
  </center>
</div>
<p>&nbsp;</p>
<p><font face="Times New Roman">
<a href="mailto:raymondjavaxx@hotmail.com" style="text-decoration: none">
<font color="#000080">�2003 Ram�n Torres Salom�n (Raymondjavaxx).</font></a></font></p>

</body>

</html>
