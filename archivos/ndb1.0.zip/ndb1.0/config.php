<?
#**********************************************#
#*********Ram�n Emilio Torres Salom�n**********#
#************Raymondjavaxx Studios*************#
#************07:30 p.m. 27/06/2003*************#
#**************Santo Domingo R.D.**************#
#**********************************************#

#**CONFIGURACION**#

#**Titulo**#
$titulo="Libro de visitas";

#**Nombre del fichero usado como bd**#
$file="libro.txt";
?>