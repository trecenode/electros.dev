<?php
######################################
#####  PHP Cod : POP-UP Controlado ###
#####  Por Cookies en Javascript   ###
######################################
#####    Powered By TCNetworks . #####
#####   comentariosweb@gmail.com #####
######################################

# Si lo modificas Avisame Pa saber #


  
## Conectamos con la base de datos 
include("config.php");

## Realizamos la Consulta
$query = mysql_query("SELECT * FROM tbl_adspopup ORDER BY RAND() LIMIT 0, 10");


## Montamos en un Array los datos de la consulta
$base = mysql_fetch_array($query);


######################################
## Escribimos el codigo Javascript ###
##    No mover nada desde Aqui     ###
######################################

echo '<script language="javascript"> 

######################################
####   Propiedades de JAvascrip ######
######                        ########


var dire = "'.$base['fld_codigo'].'" // Url A Cargar La saca de la base de datos
var dias = 2  // duracion en Dias de la Cookie
var ancho = 200 //anchura de la ventana
var alto = 300 //altura de la ventana


######################################
######################################

if(document.cookie.indexOf(\'popupillo=false\')<0){
    cad=new Date()
    cad.setTime(cad.getTime() + (dias*24*60*60*1000))
    expira="; expires=" + cad.toGMTString()
    document.cookie = "popupillo=false" + expira
    ventanita = window.open (dire,\'ventanita\',\'width=\' + ancho +\',height=\' + alto)
    }

</script>';
mysql_free_result($query);
mysql_close();
?>