CREATE TABLE `tbl_adspopup` (
  `fld_id` int(11) NOT NULL auto_increment,
  `fld_codigo` text NOT NULL,
  PRIMARY KEY  (`fld_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;