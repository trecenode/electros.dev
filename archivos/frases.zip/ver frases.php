<?
$archivo = file("frases.txt");
$lineas = count($archivo);
echo "N�mero de frases: <strong>$lineas</strong><br> <hr align=\"left\" width=\"90%\" size=\"1\" noshade color=\"#6C92D2\"><br>";
for($i=0; $i < $lineas; $i++){
echo $archivo[$i];
echo "<br>";
echo "<br>";
}
?> 

