// Mi primer script
// MaKa (12 de Octubre de 2003)

<?
$archivo = file("frases.txt");
$lineas = count($archivo);
$numero = rand(0,$lineas-1); 

echo $archivo[$numero];
?>