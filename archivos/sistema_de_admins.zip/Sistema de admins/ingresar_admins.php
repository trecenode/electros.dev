<?
//////////////////////////////////////////
/                                        /
/           Mod Echo Por j0u             /
/          www.zona-zero.info            /
/                                        /
/   Espero que le sea util este script   /
/                                        /
//////////////////////////////////////////

$admins=array("admin","admin2"); //poner aqui el usuario que solo pueda entrar a ingresar admins
if(in_array($_COOKIE["unick"],$admins)){ 
?>
<?
include("config.php") ;
if($ingresar_admins) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
mysql_close($conectar) ;
}
$nick = quitar($nick) ;
// Comprobar que el usuario existe en la base de datos
$resp = mysql_query("select id from admins where nick='$nick'") ;
if(mysql_num_rows($resp) != 0) {
echo "Ya existe un usuario con ese nick en la base de datos. Haz click <a href=javascript:history.back()>aqu&iacute;</a> para regresar." ;
}
else {
$fecha = time() ;
mysql_query("insert into admins (fecha,nick) values ('$fecha','$nick')") ;
include("mensaje_bienvenida_admins.php") ;
echo "El admin ha sido ingresado con &eacute;xito. Haz click <a href=index.php>aqu&iacute;</a> para ir a la p&aacute;gina principal." ;
}
}
else {
?>
<b>Zona de administraci&oacute;n de admins</b> 
<script>
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo minimo 3 caracteres') ; return false ; }
}
</script>
<form name="formulario" method="post" action="ingresar_admins.php" onsubmit="return revisar()">
<b>Nick:</b><br>
<input type="text" name="nick" maxlength="20" class="form">
<br>
<br>
<input type="submit" name="ingresar_admins" value="Ingresar" class="form">
</form>
<? } ?>
<?
}
else {
?>
Estas intentando entrar en una zona restringida
<?
}
?>