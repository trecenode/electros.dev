<?
include("config.php") ;

////// Configurar //////
$mensaje = "Alta en sistema de admins.<br> Has sido ingresado en el sistema de admins de la web, desde ahora podras enviar noticias, descargas, enlaces, entrar en la zona de administraci�n y editar las mismas y muchas cosas m�s..." ;
//Pon tu nick entre las comillas de remite, o dejalo en blanco, para q llegue el mensaje como anonimo.
$remite = "Usuario" ;
/////////////////////// 

$fecha = time() ;
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$nick','$remite','$mensaje')") ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>