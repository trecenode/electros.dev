<title>Enviar noticias</title>
<link href="noticias.css" rel="stylesheet" type="text/css">
<p><strong><font size="2">Enviar noticias<br>
  </font></strong><br>
  Para volver a la zona de noticias pulsa <a href="noticias.php">aqui </a><br>
  Recuerda que en el campo usuario debes poner tu nombre o nick y en campo url 
  puedes poner <br>
  una direccion http:// o ftp:// comprueba no dejar ningun dato en blanco antes 
  de enviar el enlace.<a href="noticias.php"><br>
  </a><br>
  <?
if($enviar){
# htmlspecialchars,stripslashes,trim
$usuario = htmlspecialchars(stripslashes(trim($_POST["usuario"])));
$titulo = htmlspecialchars(stripslashes(trim($_POST["titulo"])));
$descripcion = htmlspecialchars(stripslashes(trim($_POST["descripcion"])));
$fecha = time();
# Comprobamos que los datos no estan vacios
if($usuario == ""){ $error .= "No has puesto el usuario<br>";}
if($titulo == ""){ $error .= "No has puesto el titulo<br>";}
if($descripcion == ""){$error .= "No has puesto una descripcion<br>";}
if($error) {
echo "<b>Error</b>
<p><font color='#FF0000'>$error</font> 
<p><a href='javascript:history.back()'>Regresar</a>" ;
exit ;
}
# Insertamos los datos
$fecha = time();
$crea = fopen("noticias.txt","a"); 
fwrite($crea, "$usuario|$titulo|$descripcion|$fecha
");
fclose($crea);
echo "Insertado correctamente, pulsa <a href='noticias.php'>aqui</a><br><br>";
}
?>
</p>
<form name="form" method="post" action="<? $_SERVER['REQUEST_URI'] ?>" enctype="multipart/form-data">
  Usuario: 
  <input name="usuario" type="text" id="usuario">
  <br>
  Titulo: 
  <input name="titulo" type="text" id="titulo">
  <br>
  Descripcion: <br>
  <textarea name="descripcion" cols="34" rows="8" id="descripcion"></textarea>
  <br>
  <br>
  <input name="enviar" type="submit" id="enviar" value="Enviar">
</form>
