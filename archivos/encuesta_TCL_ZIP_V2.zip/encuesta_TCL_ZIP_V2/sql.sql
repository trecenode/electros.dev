#
# Estructura de tabla para tabla `encuesta_coment`
#

CREATE TABLE encuesta_coment (
  ID int(11) NOT NULL auto_increment,
  Nombre tinytext NOT NULL,
  Fecha datetime NOT NULL default '0000-00-00 00:00:00',
  Comentario longtext NOT NULL,
  id_pre int(5) NOT NULL default '0',
  UNIQUE KEY ID (ID)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Estructura de tabla para tabla `encuesta_pre`
#

CREATE TABLE encuesta_pre (
  ID int(11) NOT NULL auto_increment,
  Pregunta text NOT NULL,
  Resp1 text NOT NULL,
  Resp2 text NOT NULL,
  Resp3 text NOT NULL,
  Resp4 text NOT NULL,
  Resp5 text NOT NULL,
  num_resp tinyint(4) NOT NULL default '0',
  activado tinyint(4) NOT NULL default '0',
  estado tinyint(1) NOT NULL default '0',
  UNIQUE KEY ID (ID)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Estructura de tabla para tabla `encuesta_votos`
#

CREATE TABLE encuesta_votos (
  ID int(11) NOT NULL auto_increment,
  ID_pregunta int(11) NOT NULL default '0',
  Restringido varchar(20) NOT NULL default '',
  Respuesta tinyint(4) NOT NULL default '0',
  UNIQUE KEY ID (ID)
) TYPE=MyISAM;
