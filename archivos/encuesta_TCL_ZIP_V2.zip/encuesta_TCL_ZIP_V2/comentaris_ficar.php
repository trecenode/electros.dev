<?php require_once('config.php'); ?>
<?php
// miramos si nos dan ID de encuesta especifica para mostrar, sin� mostramos la defecto
if($_GET['ID']){
$ID = $_GET['ID'];
}else{
// miramos la pregunta activa y obtenemos su id.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$ID= $row_encuesta_ver["ID"];
}
//Codigo de inserci�n
if($_POST['enviar']=='1'){
$nombre = $_POST['Nombre'];
$Fecha = $_POST['Fecha'];
$Comentario = $_POST['Comentario'];
$id_pre = $_POST['id_pre'];

mysql_select_db($database_encuesta, $encuesta);
  $insertSQL = "INSERT INTO encuesta_coment (Nombre, Fecha, Comentario, id_pre) VALUES ('$nombre','$Fecha','$Comentario','$id_pre')";

  $Result1 = mysql_query($insertSQL, $encuesta) or die(mysql_error());
  header("Location: comentaris.php");
  }
?>
<form method="post" name="form1" action="comentaris_ficar.php">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right"><strong><? echo $lgj_Nombre; ?>: </strong></td>
      <td><input type="text" name="Nombre" value="" size="10"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right"><strong><? echo $lgj_Comentario ; ?>:</strong></td>
      <td><textarea name="Comentario" cols="10"></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="<? echo $enviar; ?>"></td>
    </tr>
  </table>
  <input type="hidden" name="Fecha" value="<? echo date("Y-m-d H:i:s") ?>">
  <input type="hidden" name="id_pre" value="<? echo $ID ?>">
  <input type="hidden" name="enviar" value="1">
</form>
<p>&nbsp;</p>

