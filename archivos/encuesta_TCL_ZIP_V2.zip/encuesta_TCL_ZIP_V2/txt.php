<? 
function texto($texto) {
//Reemplazamos los cambios raros
$texto = str_replace("<","&lt;",$texto); 
$texto = str_replace(">","&gt;",$texto); 
$texto = str_replace("\'","&#39;",$texto); 
$texto = str_replace('\"',"&quot;",$texto); 
$texto = str_replace("\\\\","&#92;",$texto); 

// Quita los espacios al principio y al final
$texto = trim($texto);

// Esta funci�n intenta eliminar todas las etiquetas HTML y PHP de la cadena dada. (Quitar los // si queremos desactivar el html)
$texto = strip_tags($texto);

// Convierte el texto en html con sus etiquetas
$texto = htmlspecialchars($texto);

// convierte las ' " ' en ' " ' para que no den problemas con mysql
$texto = addslashes($texto);

// Reemplaza los saltos de linea por <br>
$texto = nl2br($texto);

return $texto ;
}
?>
