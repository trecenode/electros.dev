<? 
// Fichero de lenguaje en castellano
//A
$lgj_Accion = "Acci�n";
$lgj_Activado = "Activado";
$lgj_Activar = "Activar" ;
$lgj_alta = "Alta" ;
//B
$lgj_Borrar = "Borrar" ;
//C
$lgj_Comentario = "Comentario";
$lgj_Comentarios = "Comentarios";
//D
$lgj_Desactivar = "Desactivar";
//E
$lgj_editar = "Editar" ;
$lgj_enviar = "Enviar" ;
//G
$lgj_Gracias = "Gracias por todo!";
//L
$lgj_limpiar = "Limpiar" ;
//N
$lgj_NO = "No";
$lgj_Nombre = "Nombre";
$lgj_No_comentarios = "Aun no hay ning�n comentario";
$lgj_Nueva = "Nueva encuesta" ;
$lgj_Numerovots = "Numero de votos";
//O
$lgj_Ocultar = "Ocultar" ;
$lgj_Otrasencuestas = "Otras encuestas" ;
//P
$lgj_Pregunta = "Pregunta";
//R
$lgj_Respuestas = "Respuestas";
$lgj_Respuestas_numero = "N�mero de respuestas";
$lgj_Resultados = "Ver resultados";
//S
$lgj_SI = "Si";
//V
$lgj_Ver = "Ver" ;
//Y
$lgj_yavotado = "Tu ya has votado!" ;
?>