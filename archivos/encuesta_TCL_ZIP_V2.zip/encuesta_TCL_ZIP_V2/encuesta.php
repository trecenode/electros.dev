<?php require_once('config.php'); ?>
<?php require_once('lenguaje.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>encuesta por TCL_ZIP</title>
</head>

<body leftmargin="0" marginheight="0" marginwidth="0" rightmargin="0" topmargin="0">
<? 
// miramos si nos dan ID de encuesta especifica para mostrar, sin� mostramos la defecto
if($_GET['ID']){
$ID = $_GET['ID'];
// miramos la pregunta activa i la mostramos los resultados.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE ID=".$ID."";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
}else{
// miramos la pregunta activa i la mostramos los resultados.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
$ID= $row_encuesta_ver["ID"];
}
mysql_select_db($database_encuesta, $encuesta);
$query_votos = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID'";
$votos = mysql_query($query_votos, $encuesta) or die(mysql_error());
$votos_totales = mysql_num_rows($votos);
?>
<table width="100%"  border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3"><strong><? echo $row_encuesta_ver['Pregunta'] ; ?></strong></td>
  </tr>
  <? for ($i = 1; $i <= $maximo_valores; $i++) { 
  mysql_select_db($database_encuesta, $encuesta);
	$query_voto = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID' AND Respuesta = '$i'";
	$voto = mysql_query($query_voto, $encuesta) or die(mysql_error());
	$votos_resp = mysql_num_rows($voto);
  ?>
  <tr>
    <td width="84"><? echo $row_encuesta_ver["Resp".$i.""] ;  ?>&nbsp;(<? echo $votos_resp; ?>)
    <div align="justify"></div></td>
    <td width="109" valign="middle">
      <table width="99%" height="99%"  border="0" valign="middle" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="middle" bgcolor="#CCCCCC"><?
	
	@$percentatge = @( $votos_resp * 100 )/($votos_totales);
	?><table width="<? echo $percentatge ; ?>%"  border="1" align="left" cellpadding="0" cellspacing="0" bgcolor="#CC9900">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
    </table></td>
    <td width="49" valign="middle">    <div align="center"><? $percentatge_redond = floor($percentatge) ; echo $percentatge_redond ; ?>
%</div></td>
  </tr> <? } ?>
  <tr>
    <td colspan="3"><strong><? echo $lgj_Numerovots;?>: </strong><? echo $votos_totales ; ?></td>
  </tr> 
</table>
<div align="center">
    <?
// Obtenemos el listado de encuestas
$maxRows_encuestas = 5;
$pageNum_encuestas = 0;
if (isset($_GET['pageNum_encuestas'])) {
  $pageNum_encuestas = $_GET['pageNum_encuestas'];
}
$startRow_encuestas = $pageNum_encuestas * $maxRows_encuestas;

mysql_select_db($database_encuesta, $encuesta);
$query_encuestas = "SELECT * FROM encuesta_pre WHERE estado='0'";
$query_limit_encuestas = sprintf("%s LIMIT %d, %d", $query_encuestas, $startRow_encuestas, $maxRows_encuestas);
$encuestas = mysql_query($query_limit_encuestas, $encuesta) or die(mysql_error());
$row_encuestas = mysql_fetch_assoc($encuestas);

if (isset($_GET['totalRows_encuestas'])) {
  $totalRows_encuestas = $_GET['totalRows_encuestas'];
} else {
  $all_encuestas = mysql_query($query_encuestas);
  $totalRows_encuestas = mysql_num_rows($all_encuestas);
}
$totalPages_encuestas = ceil($totalRows_encuestas/$maxRows_encuestas)-1;
?><table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><strong><? echo $lgj_Otrasencuestas; ?>: </strong></td>
  </tr>
  <tr>
    <td>	<?php do { ?>  <ul>

      <li>
          
        <div align="left"><a href="encuesta.php?ID=<? echo $row_encuestas['ID'];  ?>"><? echo $row_encuestas['Pregunta']; ?></a>
          
          <br>
        </div>
      </li>
</ul>
<?php } while ($row_encuestas = mysql_fetch_assoc($encuestas)); ?>
</td>
  </tr>
</table>
</div>
<div align="center"><iframe src="comentaris.php?ID=<? echo $ID ; ?>"  scrolling="auto" align="middle" width="250" height="250"></iframe>
</div>
</body>
</html>