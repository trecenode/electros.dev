<script>
function abrirpopup(nombre,ancho,alto) {
dat = 'width=' + ancho + ',height=' + alto + ',left=50,top=50,scrollbars=yes,resize=auto';
window.open(nombre,'',dat)
}
</script>
<?php require_once('config.php'); ?>
<?php require_once('lenguaje.php'); ?>
<? 
// miramos la pregunta activa i la mostramos los resultados.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
$ID= $row_encuesta_ver["ID"];

// ************** Configurar: ********************
function obtener_ip () { 
if(!empty($_SERVER['HTTP_X_FORWARDER_FOR'])) 
$ip = $_SERVER['HTTP_X_FORWARDER_FOR']; 
elseif(!empty($_SERVER['HTTP_VIA'])) 
$ip = $_SERVER['HTTP_VIA']; 
elseif(!empty($_SERVER['REMOTE_ADDR'])) 
$ip = $_SERVER['REMOTE_ADDR']; 
else $ip = 'Desconocido'; 
return $ip; 
}
$restring = obtener_ip (); // Aqui podeis poner lo que querais restringir a solo un voto, puede ser una cookie, una ip... lo que querais.
// ***********************************************
//Realizamos el voto si lo ha pedido.
if($_POST['votar']){
$ID_pregunta = $_POST['ID_pregunta'] ;
$voto = $_POST['votar'] ;
// Revisamos que sea su primer voto
mysql_select_db($database_encuesta, $encuesta);
$query_votar = "SELECT * FROM encuesta_votos WHERE Restringido='$restring' AND ID_pregunta='$ID'";
$votar = mysql_query($query_votar, $encuesta) or die(mysql_error());
$totalRows_votar = mysql_num_rows($votar);
if($totalRows_votar==0){
// insertamos el voto
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "insert into encuesta_votos (ID_pregunta,Restringido,Respuesta) values ('$ID_pregunta','$restring','$voto')";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
echo "<script> alert('".$lgj_Gracias."'); </script>" ;
}else{ echo "<script> alert('".$lgj_yavotado."'); </script>" ; }
}
//miramos si ya ha votado
mysql_select_db($database_encuesta, $encuesta);
$query_comprueba = "SELECT * FROM encuesta_votos WHERE Restringido='$restring' AND ID_pregunta='$ID'";
$comprueba = mysql_query($query_comprueba, $encuesta) or die(mysql_error());
$totalRows_comprueba = mysql_num_rows($comprueba);

if($totalRows_comprueba==0){
// ****************Aqui si no ha votado*******************
// miramos la pregunta activa i la mostramos
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$maximo_valores = $row_encuesta_ver["num_resp"] ;
?>
<style type="text/css">
<!--
.Estilo1 {
	font-size: 12px;
	font-weight: bold;
}
.Estilo5 {font-size: 12px}
-->
</style>

<form name="form1" method="post" action="index.php">
<table width="200" height="86"  border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#3E63E5">
  <tr>
    <td colspan="2"><span class="Estilo1"><? echo $row_encuesta_ver['Pregunta'] ; ?>
        <input name="ID_pregunta" type="hidden" id="ID_pregunta" value="<? echo $row_encuesta_ver['ID'] ; ?>">
    </span></td>
  </tr>
  <tr>
    <td colspan="2">
      <span class="Estilo5">
      <? for ($i = 1; $i <= $maximo_valores; $i++) { // Empezamos la repeticion de respuestas ?>
	  </span>
      <div align="left" class="Estilo5">
  <input name="votar" type="radio" value="<? echo $i ; ?>">
  <? echo $row_encuesta_ver["Resp".$i.""] ;  ?> <br>  
  <? } //cerramos la repeticion ?>
      </div></td>
  </tr>
  <tr>
    <td><div align="right" class="Estilo5">
      
        <div align="left"><strong><a href="#" onclick="abrirpopup('encuesta.php',250,500)"><? echo $lgj_Resultados ; ?></a></strong>        </div>
        <div align="right"></div>
    </div></td>
    <td><div align="right">
      <input name="submit" type="submit" value="votar" />
    </div></td>
  </tr>
</table> 
</form>
<?php
}else{
// Si ya ha votado le ense�amos las estadisticas
mysql_select_db($database_encuesta, $encuesta);
$query_votos = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID'";
$votos = mysql_query($query_votos, $encuesta) or die(mysql_error());
$votos_totales = mysql_num_rows($votos);
?>
<table width="200"  border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#3E63E5">
  <tr>
    <td colspan="2"><strong><? echo $row_encuesta_ver['Pregunta'] ; ?></strong></td>
  </tr>
  <? for ($i = 1; $i <= $maximo_valores; $i++) { 
  mysql_select_db($database_encuesta, $encuesta);
	$query_voto = "SELECT * FROM encuesta_votos WHERE ID_pregunta ='$ID' AND Respuesta = '$i'";
	$voto = mysql_query($query_voto, $encuesta) or die(mysql_error());
	$votos_resp = mysql_num_rows($voto);
	?>
  <tr>
    <td width="94"><? echo $row_encuesta_ver["Resp".$i.""] ;  ?>&nbsp;(<? echo $votos_resp;?>)</td>
    <td width="100" valign="middle"><?
	
	@$percentatge = @( $votos_resp * 100 )/($votos_totales);
	?>
      <table width="99%" height="99%"  border="0" valign="middle" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="middle" bgcolor="#CCCCCC"><table width="<? echo $percentatge ; ?>%"  border="1" align="left" cellpadding="0" cellspacing="0" bgcolor="#CC9900">
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr> <? } ?>
  <tr>
    <td colspan="2"><div align="center">
      <p><strong><a href="#" onClick="abrirpopup('encuesta.php',270,500)"><? echo $lgj_Resultados ?><br/>
        <a href="#" onClick="abrirpopup('comentaris.php',250,500)"><? echo  $lgj_Comentarios ;?></a></strong></p>
      </div></td>
  </tr>
  
</table>

<? } ?>
