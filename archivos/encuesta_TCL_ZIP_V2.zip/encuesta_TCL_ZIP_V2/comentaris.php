<?php require_once('config.php'); ?>
<?php require_once('txt.php'); ?>
<?php require_once('lenguaje.php'); ?>

<? 
// miramos si nos dan ID de encuesta especifica para mostrar, sin� mostramos la defecto
if($_GET['ID']){
$ID = $_GET['ID'];
}else{
// miramos la pregunta activa y obtenemos su id.
mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_ver = "SELECT * FROM encuesta_pre WHERE activado='1'";
$encuesta_ver = mysql_query($query_encuesta_ver, $encuesta) or die(mysql_error());
$row_encuesta_ver = mysql_fetch_assoc($encuesta_ver);
$totalRows_encuesta_ver = mysql_num_rows($encuesta_ver);
$ID= $row_encuesta_ver["ID"];
}
//Obtenemos los comentarios de la encuesta
?>
<?php
$maxRows_encuesta_coment = 10;
$pageNum_encuesta_coment = 0;
if (isset($_GET['pageNum_encuesta_coment'])) {
  $pageNum_encuesta_coment = $_GET['pageNum_encuesta_coment'];
}
$startRow_encuesta_coment = $pageNum_encuesta_coment * $maxRows_encuesta_coment;

mysql_select_db($database_encuesta, $encuesta);
$query_encuesta_coment = "SELECT * FROM encuesta_coment WHERE id_pre='".$ID."' Order by ID DESC";
$query_limit_encuesta_coment = sprintf("%s LIMIT %d, %d", $query_encuesta_coment, $startRow_encuesta_coment, $maxRows_encuesta_coment);
$encuesta_coment = mysql_query($query_limit_encuesta_coment, $encuesta) or die(mysql_error());
$row_encuesta_coment = mysql_fetch_assoc($encuesta_coment);

if (isset($_GET['totalRows_encuesta_coment'])) {
  $totalRows_encuesta_coment = $_GET['totalRows_encuesta_coment'];
} else {
  $all_encuesta_coment = mysql_query($query_encuesta_coment);
  $totalRows_encuesta_coment = mysql_num_rows($all_encuesta_coment);
}
$totalPages_encuesta_coment = ceil($totalRows_encuesta_coment/$maxRows_encuesta_coment)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Encuesta por TCL_ZIP</title>
</head>

<body>
<div align="center">
  <table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">

    <tr>
      <td colspan="3"><div align="center"><strong><? echo $lgj_Comentarios ; ?>:</strong></div></td>
    </tr>
    <?php if ($totalRows_encuesta_coment == 0) { // Show if recordset empty ?>
       <tr>
      <td colspan="3"><div align="center"><strong><? echo $lgj_No_comentarios; ?></strong></div></td>
    </tr>
	<? } else { ?>
	<?php do { ?><tr>
	<tr>
	  <td width="50%"><? echo texto($row_encuesta_coment['Nombre']) ; ?></td>
	  <td><div align="right"><? echo $row_encuesta_coment['Fecha'] ; ?></div></td>
	</tr>
	<tr>
      <td colspan="3"><div align="center"><? echo texto($row_encuesta_coment['Comentario']) ; ?></div></td>
     </tr>
	  <?php } while ($row_encuesta_coment = mysql_fetch_assoc($encuesta_coment)); ?>
	<? } ?>
  </table>
</div>
<?php require_once('comentaris_ficar.php'); ?>
</body>
</html>
<?php
mysql_free_result($encuesta_coment);
?>
