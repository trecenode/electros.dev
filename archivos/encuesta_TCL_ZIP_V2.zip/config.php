<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_encuesta = "localhost";
$database_encuesta = "";
$username_encuesta = "";
$password_encuesta = "";
$encuesta = mysql_pconnect($hostname_encuesta, $username_encuesta, $password_encuesta) or trigger_error(mysql_error(),E_USER_ERROR); 
?>