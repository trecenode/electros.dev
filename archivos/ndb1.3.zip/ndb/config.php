<?php

$titulo = "NDB 1.3";

// ***Largo maximo de las palabras***
$max_letras = 13;

// ***Cantidad de mensajes a mostrar***
$mostrar = 12 ;

// ***Smiles*** (1=activado, 0=desactivado)
$smiles = 1 ;

// ***Censura*** (1=activado, 0=desactivado)
$censura = 1 ;

// ***Largo maximo del Nick*** (en caracteres)
$nick_max = 13 ;

// ***Largo maximo de la url*** (en caracteres)
$web_max = 50 ;

// ***Largo maximo del mensaje*** (en caracteres)
$mensaje_max = 200 ;

?>