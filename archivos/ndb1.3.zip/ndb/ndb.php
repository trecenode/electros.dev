<?php
//////////////////////////
///NDB v1.3 [Tagboard] ///
///Ram�n Torres Salom�n///
///www.raymondjavaxx.tk///
//////////////////////////

//******
include("config.php");
include("smiles.php");

//******
function QuitarUrl(&$temp)
{
	if(eregi("http|www",$temp))
	{
		$temp = "[spam]";
	}
}

//******
function QuitarHtml(&$temp)
{
	$temp = htmlspecialchars($temp);
	$temp = stripslashes($temp);
	$temp = trim($temp);
}

//******
function NoPalabrasLargas(&$temp)
{
	global $max_letras;
	if(strlen($temp) > $max_letras)
	{
		$temp = chunk_split($temp,$max_letras," ");
	}
}

//******
function Censura(&$temp)
{
	$censura = explode(",",join("",file('censura.txt')));
	if(in_array(strtolower($temp),$censura) AND $temp != "")
	{
		$temp = "****";
	}
}

//******
function MostrarError($campo)
{
?>
<html>
<head><title></title></head>
<body topmargin="2" leftmargin="2">
<link href="estilo.css" rel="stylesheet" type="text/css">
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="hd">
<tr><td>
<p align="center">
<a href="javascript:history.back(1)"><b>&lt;--<?PHP echo $campo ?> invalido</b>
</a>
</p>
</td></tr>
</table>
</body>
</html>
<?php
}

//******
function NoMensajeLargo(&$temp)
{
	$temp = str_replace("
", " ", $temp);
	global $mensaje_max;
	if(strlen($temp) > $mensaje_max)
	{
		$temp = substr($temp, 0, $mensaje_max).' ...';
	}
}

//******
if ($accion == post)
{

	$temp = str_replace(" ","",$nick);
	$temp = str_replace("�","",$temp);

	if ($temp == "" OR $temp == "Nick" OR strlen($temp) > $nick_max)
	{
		MostrarError("Nick");
		exit;
	}


	if (strlen($web) > $web_max)
	{
		MostrarError("URL");
		exit;
	}

	NoMensajeLargo($mensaje);
	$temp = str_replace(" ","",$mensaje);
	$temp = str_replace("�","",$temp);

	if ($temp == "" OR $temp == "Mensaje")
	{
		MostrarError("Mensaje");
		exit;
	}

	$archivo = fopen("libro.txt",a);
	$palabras = explode(" ",$mensaje);
	$cantidad = count($palabras);

	for($i=0;$i<$cantidad;$i++)
	{ 
		QuitarUrl($palabras[$i]);
		if ($censura == 1)
		{
			Censura($palabras[$i]);
		}
		NoPalabrasLargas($palabras[$i]);
		QuitarHtml($palabras[$i]);
	}

	QuitarHtml($nick);
	QuitarHtml($web);
	$mensaje = implode(" ",$palabras);

	if($smiles == 1)
	{
		$mensaje = smile($mensaje);
	}

	$web = strtolower($web);
	$temp = str_replace(" ", "", $web);
	$temp = str_replace("�","",$temp);
	if ($web == "" || $web == "http://" || $temp == "")
	{
		fwrite($archivo,"<b>$nick:</b><br>$mensaje\n");
	}
	else
	{
		$web = str_replace("http://", "", strtolower($web));
		if (eregi("@",$web))
		{
			$web = "mailto:$web";
		}
		else
		{
			$web = "http://$web";
		}
		fwrite($archivo,"<a href=\"$web\" target=\"_blank\"><b>$nick:</b></a><br>$mensaje\n");
	}

	fclose($archivo);
	header("location:ndb.php");
}

?>

<html>
<head>
<title></title>
</head>
<body topmargin="2" leftmargin="2">
<link href="estilo.css" rel="stylesheet" type="text/css">

<table width="100%" border="0" cellpadding="1" cellspacing="0" class="hd">
<tr>
<td>
<p align="center">
<a href="#nick"><b>�<?PHP echo $titulo; ?>�</b>
</a>
</p>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?php

//***Mostrar***
$class = 2;
$mensajes = file("libro.txt");
$total = count($mensajes);
if($total < $mostrar || $mostrar == 0)
{
	$maximo = 0 ;
}
else
{
	$maximo = $total - $mostrar ;
}

while($total > $maximo)
{
	$total-- ;
	$mensajep = $mensajes[$total] ;

	//******
	if($class==1)
	{
		$class=2;
	}
	else {
		$class=1;
	}

?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="mensaje<? echo $class ?>">
<tr>
<td>
<? echo $mensajep ?>
</td>
</tr>
</table>
<div style="margin-top: 1"></div>
<?php
}
?>
<script language="JavaScript" type="text/JavaScript">
function revisar(campo)
{
	if(campo.value=='Nick')
	{
		campo.value='' ;
	}
	if(campo.value=='Mensaje')
	{
		campo.value='' ;
	}
}

function validar()
{
	if(libro.nick.value == '' || libro.nick.value == 'Nick')
	{
		alert('Debes escribir un Nick') ;
		return false ;
	}
	if(libro.mensaje.value == '' || libro.mensaje.value == 'Mensaje')
	{
		alert('Debes escribir un Mensaje') ;
		return false ;
	}
}

function ventana(url_pop,width,height)
{
	var PopWidth=width;
    	var PopHeight=height;
	var PopLeft = (window.screen.width-PopWidth)/2;
	var PopTop = (window.screen.height-PopHeight)/2;
	df = window.open(url_pop,'df','toolbar=no,status=no,menubar=no,location=no,directories=no,resizable=no,scrollbars=yes,width='+PopWidth+',height='+PopHeight+',top='+PopTop+',left='+PopLeft);
}

</script>

<div align="center">
<form name="libro" method="post" action="ndb.php?accion=post" onsubmit="return validar()">
<input type="text" name="nick" size="17" maxlength="<? echo $nick_max; ?>;" value="Nick" onfocus="revisar(this)" class="formu"><br>
<input type="text" name="web" size="17" maxlength="<? echo $web_max; ?>" value="http://" onfocus="revisar(this)" class="formu"><br>
<textarea rows="3" name="mensaje" cols="16" onfocus="revisar(this)" class="formu">Mensaje</textarea><br>
<input type="submit" name="enviar" value="Enviar" class="formu">
</form>
<?php
if($smiles == 1)
{
	echo "<p><b><a href=\"javascript:ventana('smiles.htm','175','185')\">Smiles</a></b></p>";
}

?>
<div>
<a href="http://raymondjavaxx.webcindario.com" target="_blank">NDB1.3</a>
</div>
</div>
</body>

</html>