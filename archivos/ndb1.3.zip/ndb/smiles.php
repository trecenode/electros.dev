<?php
// ***Insertar Smiles***
function smile($texto) 
{
	// ***Smiles****
	// *************
	$texto = str_replace(":!:", "<*admiracion*>", $texto);
	$texto = str_replace(":asombrado:", "<*asombrado*>", $texto);
	$texto = str_replace(":burlon:", "<*burlon*>", $texto);
	$texto = str_replace(":confundido:", "<*confundido*>", $texto);
	$texto = str_replace(":contento:", "<*contento*>", $texto);
	$texto = str_replace(":decepcion:", "<*decepcionado*>", $texto);
	$texto = str_replace(":deprimido:", "<*deprimido*>", $texto);
	$texto = str_replace(":dormido:", "<*dormido*>", $texto);
	$texto = str_replace(":enojado:", "<*enojado*>", $texto);
	$texto = str_replace(":feliz:", "<*feliz*>", $texto);
	$texto = str_replace(":flecha:", "<*flecha*>", $texto);
	$texto = str_replace(":foco:", "<*foco*>", $texto);
	$texto = str_replace(":furioso:", "<*furioso*>", $texto);
	$texto = str_replace(":genial:", "<*genial*>", $texto);
	$texto = str_replace(":gui�o:", "<*guino*>", $texto);
	$texto = str_replace(":hiperactivo:", "<*hiperactivo*>", $texto);
	$texto = str_replace(":?:", "<*interrogativo*>", $texto);
	$texto = str_replace(":jubilo:", "<*jubilo*>", $texto);
	$texto = str_replace(":llorando:", "<*llorando*>", $texto);
	$texto = str_replace(":loco:", "<*loco*>", $texto);
	$texto = str_replace(":no:", "<*no*>", $texto);
	$texto = str_replace(":nota:", "<*nota*>", $texto);
	$texto = str_replace(":presumido:", "<*presumido*>", $texto);
	$texto = str_replace(":risa:", "<*risa*>", $texto);
	$texto = str_replace(":si:", "<*si*>", $texto);
	$texto = str_replace(":sonrisa:", "<*sonrisa*>", $texto);
	$texto = str_replace(":sorpresa:", "<*sorpresa*>", $texto);
	$texto = str_replace(":sospecha:", "<*sospecha*>", $texto);
	$texto = str_replace(":triste:", "<*triste*>", $texto);
	$texto = str_replace(":verguenza:", "<*verguenza*>", $texto);

	// ***Comunes***
	// *************
	$texto = str_replace(":)", "<*contento*>", $texto);
	$texto = str_replace(":(", "<*triste*>", $texto);
	$texto = str_replace(";)", "<*guino*>", $texto);
	$texto = str_replace(":D", "<*feliz*>", $texto);
	$texto = str_replace(":P", "<*burlon*>", $texto);
	$texto = str_replace(":p", "<*burlon*>", $texto);

	// *************
	$texto = str_replace("<*","<img src=\"smiles/",$texto);
	$texto = str_replace("*>",".gif\" width=\"15\" height=\"15\">",$texto) ;

	return $texto ;
}

?>