<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
if($HTTP_GET_VARS[administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
if($HTTP_COOKIE_VARS[unick] == $administrador) {
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<?
include("config.php") ;
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="220" valign="top">
<?
if($enviar) {
if($agregar == "categoria") {
mysql_query("insert into eforo_categorias (categoria) values ('$categoria')") ;
$resp = mysql_query("select id from eforo_categorias") ;
$categorias = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$categorias = $categorias * 10 ;
$resp = mysql_query("select id from eforo_categorias order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
mysql_query("update eforo_categorias set orden='$categorias' where id='$datos[id]'") ;
mysql_free_result($resp) ;
}
if($agregar == "foro") {
mysql_query("insert into eforo_foros (categoria,foro,descripcion) values ('$categoria','$foro','$descripcion')") ;
$resp = mysql_query("select id from eforo_foros order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$resp2 = mysql_query("select id from eforo_foros where categoria='$categoria'") ;
$foros = mysql_num_rows($resp2) ;
mysql_free_result($resp2) ;
$foros = $foros * 10 ;
mysql_query("update eforo_foros set orden='$foros' where id='$datos[id]'") ;
mysql_free_result($resp) ;
}
}
if($mover == "categoria") {
if($subir) { mysql_query("update eforo_categorias set orden=orden-15 where id='$id'") ; }
if($bajar) { mysql_query("update eforo_categorias set orden=orden+15 where id='$id'") ; }
$resp = mysql_query("select id from eforo_categorias order by orden asc") ;
$orden = 10 ;
while($datos = mysql_fetch_array($resp)) {
mysql_query("update eforo_categorias set orden='$orden' where id='$datos[id]'") ;
$orden = $orden + 10 ;
}
mysql_free_result($resp) ;
}
if($mover == "foro") {
if($subir) { mysql_query("update eforo_foros set orden=orden-15 where id='$id'") ; }
if($bajar) { mysql_query("update eforo_foros set orden=orden+15 where id='$id'") ; }
$resp = mysql_query("select id from eforo_foros where categoria='$c' order by orden asc") ;
$orden = 10 ;
while($datos = mysql_fetch_array($resp)) {
mysql_query("update eforo_foros set orden='$orden' where id='$datos[id]'") ;
$orden = $orden + 10 ;
}
mysql_free_result($resp) ;
}
if($borrar == "categoria") {
$resp = mysql_query("select id from eforo_foros where categoria='$id'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("delete from eforo_categorias where id='$id'") ;
}
else {
?>
<script>alert('Debes eliminar todos los foros de esta categor�a.')</script>
<?
}
}
if($borrar == "foro") {
mysql_query("delete from eforo_mensajes where foro='$id'") ;
mysql_query("delete from eforo_foros where id='$id'") ;
}
?>
<p class="t1">Agregar categor�as
<p>
<form method="post" action="foroadmin.php?agregar=categoria">
<div style="position: absolute ; visibility: hidden"><input type="text" name="a"></div>
<b>Categor�a:</b><br>
<input type="text" name="categoria" maxlength="100" size="30" class="form"><br><br>
<input type="submit" name="enviar" value="Agregar categor�a" class="form">
</form>
<p class="t1">Agregar foros
<p>
<form method="post" action="foroadmin.php?agregar=foro">
<b>Foro:</b><br>
<input type="text" name="foro" maxlength="100" size="30" class="form"><br>
<b>Categor�a:</b><br>
<select name="categoria" class="form">
<?
$resp = mysql_query("select id,categoria from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<option value="<? echo $datos[id] ?>"><? echo $datos[categoria] ?>
<?
}
mysql_free_result($resp) ;
?>
</select><br>
<b>Descripci�n:</b><br>
<textarea name="descripcion" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Agregar foro" class="form">
</form>
</td>
<td width="10"></td>
<td valign="top">
<table width="100%" border="0" cellpadding="5" cellspacing="1" style="border: #757575 1 solid">
<tr bgcolor="#505050">
<td width="30%"><div class="t1" align="center">Orden</div></td>
<td width="50%"><div class="t1" align="center">Categor�a</div></td>
<td width="20%">&nbsp;</td>
</tr>
<?
$resp = mysql_query("select * from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td bgcolor="#bbbbbb">
<div align="center">
<a href="foroadmin.php?id=<? echo $datos[id] ?>&mover=categoria&bajar=si">Bajar</a> |
<a href="foroadmin.php?id=<? echo $datos[id] ?>&mover=categoria&subir=si">Subir</a><br><br>
</div>
</td>
<td bgcolor="#bbbbbb"><div class="t1"><? echo $datos[categoria] ?></div></td>
<td bgcolor="#bbbbbb"><div align="center"><a href="foroadmin.php?id=<? echo $datos[id] ?>&borrar=categoria">Borrar</a></div></td>
</tr>
<?
$resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
while($datos2 = mysql_fetch_array($resp2)) {
?>
<tr>
<td bgcolor="#dddddd">
<div align="center">
<a href="foroadmin.php?id=<? echo $datos2[id] ?>&c=<? echo $datos[id] ?>&mover=foro&bajar=si">Bajar</a> |
<a href="foroadmin.php?id=<? echo $datos2[id] ?>&c=<? echo $datos[id] ?>&mover=foro&subir=si">Subir</a><br><br>
</div>
</td>
<td bgcolor="#dddddd"><a href="foro.php?foroid=<? echo $datos2[id] ?>"><? echo $datos2[foro] ?></a><br><? echo $datos2[descripcion] ?></td>
<td bgcolor="#dddddd"><div align="center"><a href="foroadmin.php?id=<? echo $datos2[id] ?>&borrar=foro">Borrar</a></div></td>
</tr>
<?
}
mysql_free_result($resp2) ;
}
?>
</table>
</td>
</tr>
</table>
<?
mysql_close($conectar) ;
}
else {
echo "S�lo el administrador tiene acceso a este secci�n." ;
}
?>
<p align="center"><a href="http://www.electros.tk">eForo v.1.0</a>
<p>
</body>
</html>
