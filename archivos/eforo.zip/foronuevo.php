<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
if($HTTP_COOKIE_VARS[unick]) {
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$tema = quitar($tema) ;
$mensaje = quitar($mensaje) ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
mysql_query("insert into eforo_mensajes (foro,foromostrar,fecha,usuario,tema,mensaje,editado,ultimo) values ('$foroid','1','$fecha','$usuario','$tema','$mensaje','$fecha','$fecha')") ;
$resp = mysql_query("select id from eforo_mensajes order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$forotema = $datos[id] ;
mysql_query("update eforo_mensajes set forotema='$forotema' where id='$forotema'") ;
mysql_query("update eforo_foros set temas=temas+1,mensajes=mensajes+1 where id='$foroid'") ;
mysql_query("update usuarios set mensajes=mensajes+1 where nick='$usuario'") ;
echo "Tu mensaje ha sido publicado con �xito. Haz click <a href=foro.php?foroid=$foroid&temaid=$forotema>aqu�</a> para ver tu mensaje." ;
mysql_free_result($resp) ;
}
?>
<script>
function revisar() {
if(formulario.tema.value.length == 0) { alert('Debes escribir un tema') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<form name="formulario" method="post" action="foronuevo.php?foroid=<? echo $foroid ?>" onsubmit="return revisar()">
<b>Tema:</b><br>
<input type="text" name="tema" size="40" maxlength="100" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="50" rows="20" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
else {
?>
<p><b>S�lo los usuarios registrados pueden escribir nuevos mensajes</b>
<p>No est�s registrado ? Que esperas, s�lo necesitas nick, contrase�a y email y podr�s
disfrutar de todos los beneficios como tener un perfil, poder editar tus mensajes y
muchas cosas m�s. 
<p>Haz click <a href="uregistrar.php">aqu�</a> para registrarte.
<?
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk">eForo v.1.0</a>
<p>
</body>
</html>
