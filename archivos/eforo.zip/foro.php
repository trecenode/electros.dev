<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
// Funci�n que muestra la fecha en el formato Lunes 1 de Enero del 2003 12:00 AM
function fecha($fecha) {
$semana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mes = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$semana[$diasemana] $diames de $mes[$mesano] del $ano $hora" ;
return $fecha ;
}
// Funci�n para sustituir el c�digo especial por su respectivo c�digo HTML
function codigo($texto) {
$texto = str_replace("[b]","<b>",$texto) ;
$texto = str_replace("[/b]","</b>",$texto) ;
$texto = str_replace("[img]","<img src=\"",$texto) ;
$texto = str_replace("[/img]","\" border=\"0\">",$texto) ;
$texto = str_replace("[codigo]","<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" style=\"border: #000000 1 solid ; background: #cccccc\"><tr><td><div style=\"color: #000000 ; text-align: left ; font-weight: bold\">",$texto) ;
$texto = str_replace("[/codigo]","</div></td></tr></table>",$texto) ;
$texto = str_replace("\r\n","<br>",$texto) ;
return $texto ;
}
// Muestra los mensajes del foro seleccionado
if($foroid) {
if($temaid) {
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p style="font-size: 10pt"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>" class="tema">� <? echo $datos[tema] ?></a>
<p>
<?
mysql_free_result($resp) ;
}
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p><a href="foro.php">Indice del foro</a> � <a href="foro.php?foroid=<? echo $foroid ?>"><? echo $datos[foro] ?></a>
<?
mysql_free_result($resp) ;
?>
<p><a href="foronuevo.php?foroid=<? echo $foroid?>">Nuevo tema</a>
<?
// Se muestra el enlace para responder solamente cuando se est� dentro de un tema
if($temaid) {
?>
 <b>|</b> <a href="fororesponder.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid?>">Responder</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="1" style="border: #000000 1 solid">
<?
}
// Muestra el tema y los mensajes
if($temaid) {
mysql_query("update eforo_mensajes set visitas=visitas+1 where id='$temaid'") ;
$resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
$totaldemensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_mensajes ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where forotema='$temaid' order by id asc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
while($datos = mysql_fetch_array($resp)) {
$fecha = fecha($datos[fecha]) ;
$datos[mensaje] = codigo($datos[mensaje]) ;
// El total de mensajes del usuario
$resp2 = mysql_query("select mensajes from usuarios where nick='$datos[usuario]'") ;
$datos2 = mysql_fetch_array($resp2) ;
$mensajes = $datos2[mensajes] ;
mysql_free_result($resp2) ;
// Si el mensaje ha sido editado se muestra la fecha de la �ltima modificaci�n 
if($datos[fecha] != $datos[editado]) {
$editado = fecha($datos[editado]) ;
$editado = "<br><br><div style=\"font-size: 7pt\"><b>Editado por �ltima vez el $editado</b></div>" ;
}
else {
$editado = "" ;
}
if($datos[id] == $datos[forotema]) {
$borrar = "tema" ;
}
else {
$borrar = "mensaje" ;
}
?>
<tr>
<td width="25%" valign="top" bgcolor="#dddddd">
<b><? echo $datos[usuario] ?></b><br>
<div style="font-size: 7pt"><b>Mensajes:</b> <? echo $mensajes ?></div>
</td>
<td width="75%" valign="top" bgcolor="#dddddd">
<a name="<? echo $datos[id] ?>"></a>
<b>Tema:</b> <? echo $datos[tema] ?><br>
<hr color="#757575"><br>
<? echo "$datos[mensaje]$editado" ?>
</td>
</tr>
<tr>
<td bgcolor="#dddddd"><div style="font-size: 7pt"><? echo $fecha ?></div></td>
<td bgcolor="#dddddd"><a href="foroeditar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&mensajeid=<? echo $datos[id] ?>">Editar</a> | <a href="foroborrar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&borrar=<? echo $borrar ?>">Borrar</a></td>
</tr>
<?
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldemensajes) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
else {
// Muestra los temas
$resp = mysql_query("select id from eforo_mensajes where foro='$foroid' and foromostrar='1'") ;
$totaldetemas = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_temas ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where foro='$foroid' and foromostrar='1' order by ultimo desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
$mensajes = mysql_num_rows($resp) ;
if($mensajes == 0) {
echo "<p align=center>No se encontraron mensajes." ;
}
else {
?>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="1" style="border: #757575 1 solid">
<tr>
<td width="40%" bgcolor="#757575"><div align="center" class="t1">Tema</div></td>
<td width="10%" bgcolor="#757575"><div align="center" class="t1">Vis</div></td>
<td width="10%" bgcolor="#757575"><div align="center" class="t1">Res</div></td>
<td width="20%" bgcolor="#757575"><div align="center" class="t1">Autor</div></td>
<td width="20%" bgcolor="#757575"><div align="center" class="t1">Ultimo</div></td>
</tr>
<?
while($datos = mysql_fetch_array($resp)) {
$resp2 = mysql_query("select id,fecha,usuario from eforo_mensajes where forotema='$datos[id]' order by id desc limit 1") ;
$datos2 = mysql_fetch_array($resp2) ;
$primero = fecha($datos[fecha]) ;
$ultimo = fecha($datos2[fecha]) ;
if($HTTP_COOKIE_VARS[unick] == "Electros") {
$borrar = "<div align=center><a href=foroborrar.php?foroid=$foroid&temaid=$datos[id]&borrar=tema>Borrar</a>" ;
}
?>
<tr>
<td bgcolor="#dddddd"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $datos[id] ?>">� <? echo $datos[tema] ?></a></td>
<td bgcolor="#dddddd"><div align="center"><? echo $datos[visitas] ?></div></td>
<td bgcolor="#dddddd"><div align="center"><? echo $datos[mensajes] ?></div></td>
<td bgcolor="#dddddd"><div align="center"><b><? echo $datos[usuario] ?></b><br><span style="font-size: 7pt"><? echo $primero ?></span></div></td>
<td bgcolor="#dddddd"><div align="center"><b><? echo $datos2[usuario] ?></b><br><span style="font-size: 7pt"><? echo $ultimo ?></span></div><? echo $borrar ?></td>
</tr>
<?
mysql_free_result($resp2) ;
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldetemas) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
}
}
// Mostrar los foros
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" style="border: #757575 1 solid">
<tr>
<td colspan="2" bgcolor="#757575"><div class="t1" align="center">Categor�a</div></td>
<td bgcolor="#757575"><div class="t1" align="center">Tem</div></td>
<td bgcolor="#757575"><div class="t1" align="center">Men</div></td>
<td bgcolor="#757575"><div class="t1" align="center">Ultimo mensaje</div></td>
</tr>
<?
$resp = mysql_query("select * from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td colspan="5" bgcolor="#bbbbbb"><div class="t1"><? echo $datos[categoria] ?></div></td>
</tr>
<?
$resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
while($datos2 = mysql_fetch_array($resp2)) {
// Obtener el ultimo mensaje enviado
$resp3 = mysql_query("select id,forotema,fecha,usuario from eforo_mensajes where foro='$datos2[id]' order by id desc limit 1") ;
if(mysql_num_rows($resp3) != 0) {
$datos3 = mysql_fetch_array($resp3) ;
$fecha = $datos3[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano<br>$hora" ;
$usuario = $datos3[usuario] ;
$ultimo = "<b>$usuario</b> <a href=foro.php?foroid=$datos2[id]&temaid=$datos3[forotema]#$datos3[id]><img src=eforo_imagenes/ultimo.gif width=18 height=9 border=0></a><br><span style=\"font-size: 7pt\">$fecha</span>" ;
}
else {
$ultimo ="Ninguno" ;
}
?>
<tr>
<td width="10%" bgcolor="#dddddd"><div align="center"><img src="eforo_imagenes/foco.gif" width="15" height="20" border="0"></div></td>
<td width="50%" bgcolor="#dddddd"><a href="foro.php?foroid=<? echo $datos2[id] ?>"><? echo $datos2[foro] ?></a><br><? echo $datos2[descripcion] ?></td>
<td width="10%" bgcolor="#dddddd"><div align="center"><? echo $datos2[temas] ?></div></td>
<td width="10%" bgcolor="#dddddd"><div align="center"><? echo $datos2[mensajes] ?></div></td>
<td width="20%" bgcolor="#dddddd"><div align="center"><? echo $ultimo ?></div></td>
</tr>
<?
mysql_free_result($resp3) ;
}
mysql_free_result($resp2) ;
}
?>
</table>
<?
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk">eForo v.1.0</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
