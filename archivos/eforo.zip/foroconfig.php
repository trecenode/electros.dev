<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

// Administrador del foro (el administrador puede editar y borrar mensajes)
$administrador = "Electros" ;
// Temas a mostrar
$num_temas = "10" ;
// Mensajes por tema a mostrar
$num_mensajes = "10" ;
// Estilo del foro (tipo de letra, color, tama�o)
$estilo = "defecto.php" ;
// T�tulo a mostrar
$titulodelforo = "EForo v.1.0. Por: www.electros.tk" ; 
?>
