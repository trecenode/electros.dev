<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
if($HTTP_GET_VARS[administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
// Administrador del foro (s�lo el administrador del foro puede borrar mensajes)
$administrador = "Electros" ;
if($HTTP_COOKIE_VARS[unick] == $administrador) {
// Se borra el tema con todos los mensajes que contiene
if($borrar == "tema") {
$resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_query("update eforo_foros set temas=temas-1,mensajes=mensajes-$mensajes where id='$foroid'") ;
mysql_query("delete from eforo_mensajes where forotema='$temaid'") ;
echo "
<p><b>Tema borrado:</b> $temaid<br><b>Mensajes borrados en total:</b> $mensajes
<p><a href=foro.php?foroid=$foroid>Regresar al foro</a>
" ;
mysql_free_result($resp) ;
}
// Se borra un s�lo mensaje siempre y cuando no sea un tema
if($borrar == "mensaje") {
mysql_query("update eforo_mensajes set mensajes=mensajes-1 where id='$temaid'") ;
mysql_query("update eforo_foros set mensajes=mensajes-1 where id='$foroid'") ;
mysql_query("delete from eforo_mensajes where id='$mensajeid'") ;
echo "
<p><b>Mensaje borrado:</b> $mensajeid
<p><a href=foro.php?foroid=$foroid>Regresar al foro</a>
" ;
}
}
else {
echo "S�lo el administrador tiene acceso a esta �rea" ;
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk">eForo v.1.0</a>
<p>
</body>
</html>
