<?
include("config.php") ;
mysql_query("
create table eforo_categorias (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria varchar(100) not null,
primary key (id),
index (orden)
)
") ;
mysql_query("
create table eforo_foros (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria tinyint(3) unsigned not null,
foro varchar(100) not null,
descripcion tinytext not null,
temas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (orden,categoria)
)
") ;
mysql_query("
create table eforo_mensajes (
id smallint(5) unsigned not null auto_increment,
foro tinyint(3) unsigned not null,
forotema smallint(5) unsigned not null,
foromostrar tinyint(1) unsigned not null,
visitas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
tema varchar(100) not null,
mensaje text not null,
editado int(10) unsigned not null,
ultimo int(10) unsigned not null,
primary key (id),
index (foro,forotema,foromostrar)
)
") ;
mysql_query("alter table usuarios add mensajes smallint(5) unsigned not null") ;
mysql_close($conectar) ;
?>
<style>
body {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
</style>
<p><b>eForo v.1.0</b>
<p>Tablas creadas:
<p><b>eforo_categorias</b><br><b>eforo_foros</b><br><b>eforo_mensajes</b>
<p>Tablas modificadas:
<p><b>usuarios</b>
<p>La instalaci�n se ha completado con �xito. Recuerda eliminar este archivo inmediatamente despu�s de la instalaci�n.
<p>Esta foro a�n est� en fase de pruebas por lo que recomiendo que no le hagas
modificaciones ya que al momento de actualizar el script tus cambios se perder�n.
<p>Para empezar a agregar categor�as y foros entra <a href="foroadmin.php">aqu�</a>.
<p><b>Nota:</b> Este foro utiliza el script "Registro de usuarios 1",
si no lo tienes bajalo de aqu� <a href="http://www.electros.tk">http://www.electros.tk</a>
