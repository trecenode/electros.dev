<?
// ****************************
// *** eForo v.1.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
if($HTTP_GET_VARS[administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
if($HTTP_COOKIE_VARS[unick] != $administrador) {
$resp = mysql_query("select id from eforo_mensajes where id='$mensajeid' and usuario='$HTTP_COOKIE_VARS[unick]'") ;
if(mysql_num_rows($resp) == 0) {
echo "No puedes editar este mensaje. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
exit ;
}
mysql_free_result($resp) ;
}
if($enviar) {
$editado = time() ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$tema = quitar($tema) ;
$mensaje = quitar($mensaje) ;
mysql_query("update eforo_mensajes set tema='$tema',mensaje='$mensaje',editado='$editado' where id='$mensajeid'") ;
echo "Tu mensaje ha sido editado con �xito. Haz click <a href=foro.php?foroid=$foroid&temaid=$temaid#$mensajeid>aqu�</a> para regresar al mensaje." ;
}
$resp = mysql_query("select tema,mensaje from eforo_mensajes where id=$mensajeid") ;
while($datos = mysql_fetch_array($resp)) {
?>
<form name="formulario" method="post" action="foroeditar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&mensajeid=<? echo $mensajeid ?>">
<b>Tema:</b><br>
<input type="text" name="tema" size="40" maxlength="100" value="<? echo $datos[tema] ?>"class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="50" rows="20" class="form"><? echo $datos[mensaje] ?></textarea><br><br>
<input type="submit" name="enviar" value="Editar Mensaje" class="form">
</form>
<?
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk">eForo v.1.0</a>
<p>
</body>
</html>
