<?

//----------------------------------------//
////////////////////////////////////////--
//************************************//--
//*//////////////////////////////////*//--
//*//     Sistema de Noticias      //*//--
//*//    Creado por: Arturo8a      //*//--
//*//     Web: www.radio8a.tk      //*//--
//*// Contacto:arturo8a@gmail.com  //*//--
//*//        Versi�n: 1.0          //*//--
//*//        Licencia: GNU         //*//--
//*//////////////////////////////////*//--
//************************************//--
////////////////////////////////////////--
//----------------------------------------//

if ($enviar){
include("config.php");
$conexion = mysql_connect($dbhost,$dbuser,$dbpass); 
mysql_select_db($db,$conexion);
$crearhoy = mysql_query("alter table noticias add imagen varchar(40) NOT NULL default ''"); 
echo "Tabla <b>imagen</b> creada con �xito! . Recuerda borrar los archivos <b>creartablaimagen.php</b> y <b>creartablaimagen2.php</b> por seguridad ;).";
}
?>