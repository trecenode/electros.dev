<?

//----------------------------------------//
////////////////////////////////////////--
//************************************//--
//*//////////////////////////////////*//--
//*//     Sistema de Noticias      //*//--
//*//    Creado por: Arturo8a      //*//--
//*//     Web: www.radio8a.tk      //*//--
//*// Contacto:arturo8a@gmail.com  //*//--
//*//        Versi�n: 1.0          //*//--
//*//        Licencia: GNU         //*//--
//*//////////////////////////////////*//--
//************************************//--
////////////////////////////////////////--
//----------------------------------------//

include("ulogin.php") ;
?>
<?
if($enviar) {
include("config.php") ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$usuario = $_COOKIE["unick"] ;
$comentario = quitar($comentario) ;
$titulo= quitar($titulo) ;
$noticia= quitar($noticia) ;
$noticiaext= quitar($noticiaext) ;
if( $_COOKIE["unick"] == "$administrador") { $validar = 0 ; } else { $validar = 1 ; }
mysql_query("insert INTO noticias (fecha,usuario,titulo,noticia,noticiaext,imagen,validar) values ('$fecha','$usuario','$titulo','$noticia','$noticiaext','$imagen','$validar')") ;
echo "La noticia ha sido enviada con �xito. <a href=index.php?id=noticias>volver</a>" ;
mysql_close($conectar) ;
}
?>
<SCRIPT type="text/javascript">
<!--
function showimage() {
if (!document.images)
return
document.images.imagen.src=
document.formulario.imagen.options[document.formulario.imagen.selectedIndex].value
}
//-->
</SCRIPT>
<center><form method="post" action="index.php?id=noticiasenviar" name="formulario">
  <b><u>T�tulo:</u></b><br>
<input type="text" name="titulo" maxlength="100" class="form" size="20"><p>
<u>
<b>Imagen:</b><br>
</u>
<select name="imagen" onChange="showimage()" class="form" >
  <option value="eforo_imagenes/topicos/blank.gif" selected>[ Ninguno ]</option>
  <option value="eforo_imagenes/topicos/abc.gif">ABC</option>
  <option value="eforo_imagenes/topicos/admin.gif">Admin</option> 
  <option value="eforo_imagenes/topicos/AllTopics.gif">Topics</option> 
  <option value="eforo_imagenes/topicos/anime.gif">Anime</option>
  <option value="eforo_imagenes/topicos/anuncio.gif">Anuncio</option>  
  <option value="eforo_imagenes/topicos/aplicacion.gif">Aplicacion</option>
  <option value="eforo_imagenes/topicos/aporte.gif">Aporte</option>
  <option value="eforo_imagenes/topicos/aportes.gif">Aportes</option> 
  <option value="eforo_imagenes/topicos/aprovado.gif">Aprobado</option>
  <option value="eforo_imagenes/topicos/audio2.gif">Audio</option> 
  <option value="eforo_imagenes/topicos/AYUDA.gif">AYUDA</option>  
  <option value="eforo_imagenes/topicos/ayuda_suse.gif">AYUDA2</option>
  <option value="eforo_imagenes/topicos/bugs.gif">Bugs</option>
  <option value="eforo_imagenes/topicos/chicas2.gif">Chicas</option> 
  <option value="eforo_imagenes/topicos/chicas.gif">Chicas2</option>
  <option value="eforo_imagenes/topicos/code_hack.gif">Code Hack</option>
  <option value="eforo_imagenes/topicos/comunicacion.gif">Comunicacion</option>
  <option value="eforo_imagenes/topicos/comunidad.gif">Comunidad</option> 
  <option value="eforo_imagenes/topicos/consultas.gif">Consultas</option>
  <option value="eforo_imagenes/topicos/crackz.gif">Cracks</option>
  <option value="eforo_imagenes/topicos/descargas4.gif">Descargas1</option>
  <option value="eforo_imagenes/topicos/descargas.gif">Descargas2</option>
  <option value="eforo_imagenes/topicos/divx.jpg">Divx</option>
  <option value="eforo_imagenes/topicos/documentos.gif">documentos</option>
  <option value="eforo_imagenes/topicos/dvd.gif">DVD</option>
  <option value="eforo_imagenes/topicos/e_donkey.gif">E-Donkey</option>
  <option value="eforo_imagenes/topicos/e_link.gif">E-Link</option>
  <option value="eforo_imagenes/topicos/E_mails.gif">E-Mail</option>
  <option value="eforo_imagenes/topicos/e_mule2.gif">E-Mule</option>
  <option value="eforo_imagenes/topicos/e-mails.gif">E-Mails</option>
  <option value="eforo_imagenes/topicos/emuladores.gif">Emuladores</option>
  <option value="eforo_imagenes/topicos/error.gif">Error</option>
  <option value="eforo_imagenes/topicos/estadistica.gif">Estadistica</option>
  <option value="eforo_imagenes/topicos/expancion.gif">Expansion</option>
  <option value="eforo_imagenes/topicos/extranio.gif">Extra�o</option>
  <option value="eforo_imagenes/topicos/futbol.gif">Futbol</option>
  <option value="eforo_imagenes/topicos/games.gif">Games</option>
  <option value="eforo_imagenes/topicos/grupos.gif">Grupos</option>
  <option value="eforo_imagenes/topicos/guerrilla.gif">Guerrilla</option>
  <option value="eforo_imagenes/topicos/gun_topic.gif">Gun-Topic</option>
  <option value="eforo_imagenes/topicos/hacked.gif">Hackeado</option>
  <option value="eforo_imagenes/topicos/hackers.gif">Hackers</option>
  <option value="eforo_imagenes/topicos/hard.jpg">Hardware</option>
  <option value="eforo_imagenes/topicos/html.gif">HTML</option>
  <option value="eforo_imagenes/topicos/humor.gif">Humor</option>
  <option value="eforo_imagenes/topicos/ie.gif">Explorer</option>
  <option value="eforo_imagenes/topicos/informacion.gif">Informacion</option>
  <option value="eforo_imagenes/topicos/internet.gif">Internet</option>
  <option value="eforo_imagenes/topicos/invitado.gif">Invitado</option>
  <option value="eforo_imagenes/topicos/iso.jpg">Nero</option>
  <option value="eforo_imagenes/topicos/juegos.gif">Juegos</option>
  <option value="eforo_imagenes/topicos/linux.gif">Linux</option>
  <option value="eforo_imagenes/topicos/mac.gif">Mac</option>
  <option value="eforo_imagenes/topicos/modules.gif">Modulos</option>
  <option value="eforo_imagenes/topicos/mp3.gif">MP3</option>
  <option value="eforo_imagenes/topicos/msn.gif">Msn</option>
  <option value="eforo_imagenes/topicos/musica.gif">Musica</option>
  <option value="eforo_imagenes/topicos/noticias.gif">Noticias</option>
  <option value="eforo_imagenes/topicos/phpnuke.gif">PHP-Nuke</option>
  <option value="eforo_imagenes/topicos/warez.gif">Warez</option>
  <option value="eforo_imagenes/topicos/webmaster.gif">Webmaster</option>
  <option value="eforo_imagenes/topicos/xbox.gif">XBOX</option>
  <option value="eforo_imagenes/topicos/xbxperu.gif">XBX Peru</option>
  <option value="eforo_imagenes/topicos/xfiles.gif">ExpedientesX</option>
</select> </p>
  <p>
<br>
  <b><u>Vista Previa:</u></b><br>

<img src="eforo_imagenes/topicos/blank.gif" alt="" name="imagen" width="88" height="88"> </p>
  <p>
<b><u>Noticia:</u></b><br>

  <br>
  <b><a href="javascript:grabar2('[b][/b]');">Negrita</a></b> - Letra en <b>negrita.</b><br>
  <b><a href="javascript:grabar2('[i][/i]');">Cursiva</a></b> - Letra en <i>Cursiva.</i><br>
  <b><a href="javascript:grabar2('[u][/u]');">Subrayado</a></b> - Letra con <u>Subrayado.</u><br>
  <b><a href="javascript:grabar2('[center][/center]');">Centrar</a></b> - Texto Centrado<br>
  <b><a href="javascript:grabar2('[url=][/url]');">Insertar Pagina Web</a></b> - Insertar Web<br>
  <b><a href="javascript:grabar2('[img]http://..[/img]');">Imagen</a></b> - insertar 
  una imagen.<br>
  <b><a href="javascript:grabar('[codigo][/codigo]');">Codigo</a></b> - insertar 
  un codigo php.<br>
<br>
  <script language="Javascript">
<!--
function grabar(graba) { 
var inserta=document.formulario.elements["noticiaext"]; 
inserta.value=inserta.value+graba+' '; 
document.formulario.noticiaext.focus(); 

}
// -->
</script>
  <script language="Javascript">
<!--
function grabar2(graba) { 
var inserta=document.formulario.elements["noticia"]; 
inserta.value=inserta.value+graba+' '; 
document.formulario.noticia.focus(); 

}
// -->
</script>
<script>
function caretos1(codigo) {
formulario.noticia.value += codigo ;
formulario.noticia.focus() ;
}

function revisar() {
if(formulario.noticia.value.length = 0) { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<div align="center">
  <table border="2" width="172" height="42" id="AutoNumber1" bordercolor="#000000">
    <tr>
      <td width="188" height="42"><a href="javascript:caretos1(':P')">
      <img src="/eforo_imagenes/caretos/burla.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':(1')">
      <img src="/eforo_imagenes/caretos/demonio.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':?')">
      <img src="/eforo_imagenes/caretos/duda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(';)')">
      <img src="/eforo_imagenes/caretos/guino.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':lol')">
      <img src="/eforo_imagenes/caretos/lol.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':D')">
      <img src="/eforo_imagenes/caretos/alegre.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':8')">
      <img src="/eforo_imagenes/caretos/asustado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':P')">
      <img src="/eforo_imagenes/caretos/burla.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':S')">
      <img src="/eforo_imagenes/caretos/confundido.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':(1')">
      <img src="/eforo_imagenes/caretos/demonio.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':(2')">
      <img src="/eforo_imagenes/caretos/demonio2.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':?')">
      <img src="/eforo_imagenes/caretos/duda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':-\(')">
      <img src="/eforo_imagenes/caretos/enojado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(';)')">
      <img src="/eforo_imagenes/caretos/guino.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':\'(')">
      <img src="/eforo_imagenes/caretos/llorar.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':lol')">
      <img src="/eforo_imagenes/caretos/lol.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':M')">
      <img src="/eforo_imagenes/caretos/moda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':|')">
      <img src="/eforo_imagenes/caretos/neutral.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':)')">
      <img src="/eforo_imagenes/caretos/risa.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':-)')">
      <img src="/eforo_imagenes/caretos/sonrisa.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':R')">
      <img src="/eforo_imagenes/caretos/sonrojado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':O')">
      <img src="/eforo_imagenes/caretos/sorprendido.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos1(':(')">
      <img src="/eforo_imagenes/caretos/triste.gif" border="0" width="15" height="15"></a></td>
    </tr>
  </table>
</div>
  <br>
<textarea name="noticia" cols="30" rows="5" class="form"></textarea></p>
  <p><b><u>Noticia Extendida:</u></b><br>

  <br>
  <b><a href="javascript:grabar('[b][/b]');">Negrita</a></b> - Letra en <b>negrita.</b><br>
  <b><a href="javascript:grabar('[i][/i]');">Cursiva</a></b> - Letra en <i>Cursiva.</i><br>
  <b><a href="javascript:grabar('[u][/u]');">Subrayado</a></b> - Letra con <u>Subrayado.</u><br>
  <b><a href="javascript:grabar('[center][/center]');">Centrar</a></b> - Texto Centrado<br>
  <b><a href="javascript:grabar('[url=][/url]');">Insertar Pagina Web</a></b> - Insertar Web<br>
  <b><a href="javascript:grabar('[img]http://..[/img]');">Imagen</a></b> - insertar 
  una imagen.<br>
  <b><a href="javascript:grabar('[codigo][/codigo]');">Codigo</a></b> - insertar 
  un codigo php.<br>
  <br>
&nbsp;<textarea name="noticiaext" cols="30" rows="5" class="form"></textarea><br>&nbsp;</p>
  <p>
<script>
function caretos2(codigo) {
formulario.noticiaext.value += codigo ;
formulario.noticiaext.focus() ;
}

function revisar() {
if(formulario.noticiaext.value.length = 0) { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<div align="center">
  <table border="2" width="172" height="42" id="AutoNumber1" bordercolor="#000000">
    <tr>
      <td width="188" height="42"><a href="javascript:caretos2(':P')">
      <img src="/eforo_imagenes/caretos/burla.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':(1')">
      <img src="/eforo_imagenes/caretos/demonio.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':?')">
      <img src="/eforo_imagenes/caretos/duda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(';)')">
      <img src="/eforo_imagenes/caretos/guino.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':lol')">
      <img src="/eforo_imagenes/caretos/lol.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':D')">
      <img src="/eforo_imagenes/caretos/alegre.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':8')">
      <img src="/eforo_imagenes/caretos/asustado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':P')">
      <img src="/eforo_imagenes/caretos/burla.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':S')">
      <img src="/eforo_imagenes/caretos/confundido.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':(1')">
      <img src="/eforo_imagenes/caretos/demonio.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':(2')">
      <img src="/eforo_imagenes/caretos/demonio2.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':?')">
      <img src="/eforo_imagenes/caretos/duda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':-\(')">
      <img src="/eforo_imagenes/caretos/enojado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(';)')">
      <img src="/eforo_imagenes/caretos/guino.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':\'(')">
      <img src="/eforo_imagenes/caretos/llorar.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':lol')">
      <img src="/eforo_imagenes/caretos/lol.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':M')">
      <img src="/eforo_imagenes/caretos/moda.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':|')">
      <img src="/eforo_imagenes/caretos/neutral.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':)')">
      <img src="/eforo_imagenes/caretos/risa.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':-)')">
      <img src="/eforo_imagenes/caretos/sonrisa.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':R')">
      <img src="/eforo_imagenes/caretos/sonrojado.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':O')">
      <img src="/eforo_imagenes/caretos/sorprendido.gif" border="0" width="15" height="15"></a>
      <a href="javascript:caretos2(':(')">
      <img src="/eforo_imagenes/caretos/triste.gif" border="0" width="15" height="15"></a></td>
    </tr>
  </table>
</div>
<input type="submit" name="enviar" value="Enviar" class="form"> </p>
</form></center>