<?

srand((double)microtime()*1000000); 
$numero = rand(0,2);
// Esto es para tres imagenes (0, 1, 2)
// Si son cuatro, en lugar de 2, ponemos un 3, y asi sucesivamente
// El 0 siempre es fijo.

$imagen0 = "<img src=\"RUTA/imagen0.gif\">";
$imagen1 = "<img src=\"RUTA/imagen1.gif\">";
$imagen2 = "<img src=\"RUTA/imagen2.gif\">";
// Si son cuatro, a�adimos esto:
// $imagen3 = "<img src=\"RUTA/imagen3.gif\">";
// y asi sucesivamente

if ($numero== "0"){ echo ("$imagen0"); }
if ($numero== "1"){ echo ("$imagen1"); }
if ($numero== "2"){ echo ("$imagen2"); }
// Si fuesen cuatro:
// if ($numero== "3") { echo ("$imagen3"); }
// y asi sucesivamente

//para hacer el rotador de banners cambiamos el valor de las variables
//$imagen0 = "<a target=\"_blank\" title=\"LA PAGINA\" href=\"http://URL\"><img src=\"RUTA/imagen0.gif\"></a>";
//lo mismo con las demas (con sus respectivas URLs)

?>
