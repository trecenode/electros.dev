<?
include("ulogin.php") ;
?>
<p><b>Mensajes</b>
<p>Esta es tu bandeja de mensajes privados, para eliminar mensajes selecciona las casillas y despu�s haz click en "Borrar".
<?
include("config.php") ;
// M�ximo de mensajes que se permitir�n por usuario
$maximo = 50 ;
$resp = mysql_query("select id from mensajes where destinatario='$_COOKIE[unick]'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$porcentaje = round($mensajes/$maximo,2) * 100 ;
if($mensajes < ($maximo - 5)) {
$barra = "#c0c0c0" ;
}
else {
$barra = "#800000" ;
$aviso = "<b><span style=\"color: #ff0000\">Atenci�n:</span></b> Te est�s acercando al l�mite de almacenamiento, recuerda tener despejada la bandeja para poder seguir recibiendo mensajes." ;
}
if($porcentaje == 100) {
$barra = "#800000" ;
$aviso = "<b><span style=\"color: #ff0000\">Atenci�n:</span></b> Tu bandeja se encuentra al m�ximo de almacenamiento, no podr�s recibir mensajes hasta que te encuentres abajo del l�mite." ;
}
?>
<p>Espacio utilizado: <b><? echo $mensajes ?>/<? echo $maximo ?> <? echo $porcentaje ?>%</b>
<table width="100" border="0" cellpadding="1" cellspacing="0" style="border-color: #000000 ; border-width: 1 ; border-style: solid">
<tr>
<td>
<table width="<? echo $porcentaje ?>%" border="0" cellpadding="0" style="background: <? echo $barra ?>">
<tr>
<td></td>
</tr>
</table>
</td>
</tr>
</table>
<p><? echo $aviso ?>
<?
if($mensaje == "nuevo") {
?>
<script>
maximo = 1024 ;
function caracteres() {
if(formulario.mensaje.value.length > maximo)
formulario.mensaje.value = formulario.mensaje.value.substring(0,maximo) ;
else
formulario.contador.value = maximo - formulario.mensaje.value.length ; 
}
onload = caracteres ;
</script>
<p><b>Nuevo</b>
<p>
<form name="formulario" method="post" action="index.php?id=mensajes">
<b>Destinatario:</b><br>
<input type="text" name="destinatario" maxlength="20" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="30" rows="5" onkeyup="caracteres()" class="form"></textarea><br>
<input type="text" name="contador" size="3" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
else {
echo "<p><a href=index.php?id=mensajes&mensaje=nuevo>� Nuevo mensaje</a>" ;
}
if($responder) {
?>
<script>
maximo = 1024 ;
function caracteres() {
if(formulario.mensaje.value.length > maximo)
formulario.mensaje.value = formulario.mensaje.value.substring(0,maximo) ;
else
formulario.contador.value = maximo - formulario.mensaje.value.length ; 
}
onload = caracteres ;
</script>
<p><b>Responder</b>
<p>
<form name="formulario" method="post" action="mensajes.php">
<b>Destinatario:</b><br>
<input type="text" name="destinatario" maxlength="20" value="<? echo $responder ?>" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="30" rows="5" onkeyup="caracteres()" style="font-family: verdana" class="form"></textarea><br>
<input type="text" name="contador" size="3" value="0" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
if($borrar) {
while(list($mensaje,$num) = each($_POST)) {
if(ereg("^mensaje",$mensaje)) {
mysql_query("delete from mensajes where id='$num' and destinatario='$_COOKIE[unick]'") ;
}
}
echo "<p>Los mensajes han sido borrados con �xito. Haz click <a href=\"$_SERVER[REQUEST_URI]\">aqu�</a> para regresar." ;
}
else {
if($enviar) {
// Comprobar m�ximo mensajes
// --> Inicio
function quitar($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$fecha = time() - 25200 ;
$destinatario = quitar($destinatario) ;
$mensaje = quitar($mensaje) ;
$resp = mysql_query("select id from usuarios where nick='$destinatario'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) == 0) {
echo "<p>Este usuario no existe en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.";
}
else {
$resp = mysql_query("select id from mensajes where destinatario='$destinatario'") ;
$mensajes = mysql_num_rows($resp) ;
if($mensajes < $maximo) {
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$destinatario','$_COOKIE[unick]','$mensaje')") ;
echo "<p>El mensaje ha sido enviado con �xito. Haz click <a href=\"$_SERVER[REQUEST_URI]\">aqu�</a> para regresar." ;
}
else {
echo "
<p>La bandeja de este usuario ha superado el l�mite.
<p>No se pudo entregar el siguiente mensaje:
<p>$mensaje
" ;
}
}
// --> Fin
mysql_free_result($resp) ;
}
else {
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select id from mensajes where destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 10 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from mensajes where destinatario='$usuario' order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mensajes." ; }
else {
?>
<p><b>Total de mensajes:</b> <? echo $mensajes ?>
<p>
<form method="post" action="<? echo "$_SERVER[REQUEST_URI]" ?>">
<input type="submit" name="borrar" value="Borrar"><br><br>
<?
while($datos = mysql_fetch_array($resp)) {
$fecha = $datos[fecha] ;
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano $hora" ;
$datos[mensaje] = str_replace("\r\n","<br>",$datos[mensaje]) ;
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="tabla_mensaje">
<tr>
<td width="10%"><b><? echo $datos[remitente] ?></b></td>
<td width="90%"><div align="right"><b><? echo $fecha ?></b></div></td>
</tr>
<tr>
<td valign="top"><div align="center"><input type="checkbox" name="mensaje<? echo $datos[id] ?>" value="<? echo $datos[id] ?>"></div></td>
<td valign="top"><? echo $datos[mensaje] ?></td>
</tr>
<tr>
<td colspan="2">
<div align="right">
<a href="index.php?id=mensajes&responder=<? echo $datos[remitente] ?>">� Responder</a>
</div>
</td>
</tr>
</table><br>
<?
if($datos[nuevo] == 0) {
mysql_query("update mensajes set nuevo='1' where id='$datos[id]'") ;
}
}
?>
<input type="submit" name="borrar" value="Borrar">
</form>
<?
echo "
<p align=right><a href=index.php?id=mensajes&desde=$desde>� Siguientes $mostrar mensajes</a>
" ;
}
mysql_free_result($resp) ;
}
}
?> 