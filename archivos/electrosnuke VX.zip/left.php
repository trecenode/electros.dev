<table width="151" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
  <!--DWLayoutTable-->
  <tr> 
    <!-- Inicio bloques menus -->
    <td width="147" class="tabla_titulo"><div align="right" class="t1">Menu</div></td>
  </tr>
  <tr> 
    <td height="22" valign="top" class="tabla_mensaje"> 
      <? 
			// el menu de los usuarios
			include("menu_1.php"); 
			?>
    </td>
  </tr>
</table>   
<? 
// Bloque usuarios
include("config.php");
if($menu_usuarios == "ON") {
?>
<br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
       <td class="tabla_titulo"><div align="right" class="t1">Usuarios</div></td>
        </tr>
        <tr> 
          <td height="1" valign="top" class="tabla_mensaje" align="left"> 
            <? 
			// el menu de los usuarios
			include("umenu.php"); 
			?>
            <br>
          </td>
        </tr>
      </table> 
<?
}
else {
echo "" ;
}
?>
<? 
// Bloque enlaces
include("config.php");
if($menu_enlaces == "ON") {
?>  
	  <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Top 
              10 Enlaces</div></td>
        </tr>
        <tr> 
          <td height="89" valign="top" class="tabla_mensaje" align="left" > <form method="post" action="index.php?id=enlaces" form name="formulario2" >
              <div style="position: absolute ; visibility: hidden"> 
                <input type="hidden" name="aaa">
              </div>
              <input type="text" name="palabras" size="12" maxlength="65" class="form">
              <input type="submit" name="buscar" value="Buscar" class="form ">
            </form>
            <? // top 10 enlaces
include("config.php") ;
$resp = mysql_query("select * from enlaces order by visitas desc limit 10") ;
while($datos = @mysql_fetch_array($resp)) {
if (strlen($datos[titulo]) > 30) { 
$datos[titulo] = substr($datos[titulo],0,30).".."; }
echo "� <a href=enlaces.php?e=$datos[id] target=_blanck > $datos[titulo]</a> ($datos[visitas])<br>
" ;
}
?>
            <br>
            <br> </td>
        </tr>
      </table> 
      
<?
}
else {
echo "" ;
}
?>
