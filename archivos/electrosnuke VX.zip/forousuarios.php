<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<p><a href="index.php?id=foro">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Usuarios</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<?
include("config.php") ;
if($u) {
$resp = mysql_query("select * from $tabla_usuarios where nick='$u'") ;
$datos = mysql_fetch_array($resp) ;
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
if($datos[edad] == 0) { $datos[edad] = "" ; }
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
if($datos[avatar] == "") { $avatar = "0.gif" ; } else { $avatar = "$datos[id].$datos[avatar]" ; }
?>
<p><b>Usuario desde el:</b> <? echo $fecha ?>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_mensaje">
<tr>
<td><b>Nick:</b></td>
<td><? echo $datos[nick] ?></td>
<td rowspan="10">
<b>Avatar:</b><br><br>
<img src="eforo_imagenes/avatares/<? echo $avatar ?>">
</td>
</tr>
<tr>
<td><b>Pa�s:</b></td>
<td><? echo $datos[pais] ?></td>
</tr>
<tr>
<td><b>Edad:</b></td>
<td><? echo $datos[edad] ?></td>
</tr>
<tr>
<td><b>Sexo:</b></td>
<td><? echo $sexotexto[$sexonumero] ?></td>
</tr>
<tr>
<td><b>Descripci�n:</b></td>
<td><? echo $datos[descripcion] ?></td>
</tr>
<tr>
<td><b>Web:</b></td>
<td><a href="<? echo $datos[web] ?>" target="_blank"><? echo $datos[web] ?></a></td>
</tr>
</table>
<p><a href="index.php?id=foroprivados&responder=<? echo $datos[nick] ?>">Enviar mensaje privado a <? echo $datos[nick] ?></a>
<p><a href="index.php?id=forousuarios">� Regresar a Usuarios</a>
<?
}
else {
$resp = mysql_query("select id from $tabla_usuarios") ;
$usuarios = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 25 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select id,nick,sexo,pais from $tabla_usuarios order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
?>
<p><b>Usuarios registrados en el foro:</b> <? echo $usuarios ?>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td width="50%" class="tabla_titulo"><b>Nick</b></td>
<td width="25%" class="tabla_titulo"><b>Sexo</b></td>
<td width="25%" class="tabla_titulo"><b>Pa�s</b></td>
</tr>
<?
while($datos = mysql_fetch_array($resp)) {
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
if($datos[pais] == "") { $datos[pais] = "&nbsp;" ; }
?>
<tr>
<td class="tabla_subtitulo"><a href="index.php?id=forousuarios&u=<? echo $datos[nick] ?>"><? echo $datos[nick] ?></a></td>
<td class="tabla_subtitulo"><? echo $sexotexto[$sexonumero] ?></td>
<td class="tabla_subtitulo"><? echo $datos[pais] ?></td>
</tr>
<?
}
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=forousuarios.php>Anteriores $mostrar usuarios</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=forousuarios.php?desde=$anteriores>Anteriores $mostrar usuarios</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $usuarios) {
echo "<a href=forousuarios.php?desde=$desde>Siguientes $mostrar usuarios</a>" ;
}
}
mysql_close($conectar) ;
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.net" target="_blank">eForo v.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
