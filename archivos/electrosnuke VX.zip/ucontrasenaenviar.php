<?
if($enviar) {
if(!$HTTP_COOKIE_VARS[ucontrasena]) {
include("config.php") ;
$resp = mysql_query("select nick,contrasena from usuarios where email='$email'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) != 0) {
$mensaje = "
Estos son tus datos de registro:

Nick: $datos[nick]
Contrase�a: $datos[contrasena]

Recuerda guardar bien tus datos.
" ;
mail($email,"Recuperaci�n de contrase�a",$mensaje) ;
setcookie("ucontrasena","ucontrasena",time()+1800) ;
header("location: index.php?id=ucontrasena&confirmacion=si") ;
}
else {
header("location: index.php?id=ucontrasena&confirmacion=no") ;
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
}
else {
header("location: index.php?id=ucontrasena&confirmacion=esperar") ;
}
}
?>