<?
include ("config.php"); // Conexion a la bd
mysql_query("delete from uenlineareg where usuario='$_COOKIE[unick]'") ; // se busca el campo creado por uenlinea y se borra
setcookie("unick") ;
setcookie("ucontrasena") ;
?>
<script>location='index.php'</script>s
<?
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>