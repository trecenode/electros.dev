<form method="POST" action="recordar.php">
<p><a href="index.php">Principal</a> ><b> Recordar contrase�a</b></p>
  <p>   Nick<br>
    <input type="text" name="nick" size="20" class="form"><br>
     Frase secreta:<br>
   
  <input type="text" name="reco" size="20" class="form" maxlength="100"></p>
  <p>   <input type="submit" value="  Enviar  " name="B1" class="form"></p>
</form>