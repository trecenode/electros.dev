<? 
if($HTTP_COOKIE_VARS[unick]) {
if($HTTP_COOKIE_VARS[unick] == "$administrador") {
?>
<? 
include("config.php");
//si se pide borrar noticias.
if ($borrarnoticias) { 
$query = "delete from noticias where id='$borrarnoticias'"; 
mysql_query($query);
echo "<b>Borrado noticias <b>$borrarnoticias</b>. <a href=index.php?id=validacion></a><br><br>"; 
}
// si llega a terminiar de editar un noticia
else if($enviar) {
function quitarnoticias($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitarnoticias($titulo) ;
$noticia = quitarnoticias($noticia) ;
$categoria = quitarnoticias($categoria) ;
$noticiaext = quitarnoticias($noticiaext) ;
mysql_query("update noticias set titulo='$titulo',noticia='$noticia',noticiaext='$noticiaext',validar='0' where id='$editarnoticias'") ;
if ($editarnoticias == "" ) {echo "";} else echo "Actualizado noticias $editarnoticias<br><br>" ;
} 
// si se te pide editar un noticia
else if ($editarnoticias) {
$resp3 = mysql_query("select * from noticias where id='$editarnoticias'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarnoticias"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td width="96%" height="7" class="tabla_subtitulo"><b>Editar noticias</b> </td>
<td width="4%" class="tabla_subtitulo"><center>
<a href="index.php?id=validacion#editarnoticias2">x</a>
</center></td>
</tr>
<tr> 
<td height="7" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=validacion&editarnoticias=<? echo $datos3[id] ?>#editarnoticias2' onsubmit="return revisar()">
<p><b>T�tulo:</b><br>
<input type="text" name="titulo" size="30" maxlength="35" value="<? echo $datos3[titulo] ?>" class="form">
<br>
          <b>Noticia:</b><br>
<textarea name="noticia" cols="30" rows="5" class="form" onKeyPress="caracteres"><? echo $datos3[noticia] ?></textarea>
<br>
<script>
function caracteres() {
if(formulario.caracteres.value != formulario.noticia.value.length) {
formulario.caracteres.value = formulario.noticia.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.titulo.value.length > 100) { alert('El tiulo del archivo supera los 100 caract�res.') ; return false ; } 
if(formulario.noticia.value.length == 0) { alert('Debes escribir una noticia .') ; return false ; } 
if(formulario.noticia.value.length > 255) { alert('La noticia supera los 255 caract�res.') ; return false ; }
if(formulario.noticiaext.value.length == 0) { alert('Debes escribir el noticia extendida .') ; return false ; }
if(formulario.noticiaext.value.length > 100) { alert('La url del archivo supera los 100 caract�res.') ; return false ; }
}
</script>
<input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<br>
          <b>Noticia extendida:</b><br>
          <textarea name="noticiaext" cols="30" rows="5" class="form" maxlenght="100"><? echo $datos3[noticiaext] ?></textarea>
<br>
<br>
<input type='submit' name='enviar' value='Validar noticia' class='form'>
</form></td>
</tr>
</table>
<br>
<? 
}
//muestra todos los registros noticias.
?>
<a name="editarnoticias2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td colspan="5" class="tabla_titulo">
<div class="t1">Listado de noticias</div>
</td>
<?
?>
<tr>
<td class="tabla_subtitulo"><b>Id</b></td>
<td class="tabla_subtitulo"><b>Titulo</b></td>
    <td class="tabla_subtitulo"><b>Usuario</b></td>
<td class="tabla_subtitulo">&nbsp;</td>
<td class="tabla_subtitulo">&nbsp;</td>
<? 
$mostrarnoticias = 10 ; 
if(!$desdenoticias) { $desdenoticias = 0 ; }
$query = "select * from noticias where validar='1' order by id asc limit $desdenoticias,$mostrarnoticias"; 
$desdenoticias = $desdenoticias + $mostrarnoticias ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?><tr>
<td class="tabla_mensaje"><? echo $datos[id] ?></td>
<td class="tabla_mensaje"><a href="<? echo $datos[noticiaext] ?>" target="_blank"><? echo $datos[titulo] ?></a></td>
<td class="tabla_mensaje"><? echo $datos[usuario] ?></td>
<td class="tabla_mensaje"><a href=index.php?id=validacion&borrarnoticias=<? echo $datos[id] ?>#editarnoticias2>Borrar</a></td>
<td class="tabla_mensaje"><a href=index.php?id=validacion&editarnoticias=<? echo $datos[id] ?>#editarnoticias>Ver</a></td>
</tr>
<?
} 
?>
<tr> 
<td colspan="5" class="tabla_subtitulo">
<?
// paginamos los resultados de noticias.
mysql_free_result($resp);
if($desdenoticias > $mostrarnoticias) {
$anterioresnoticias = $mostrarnoticias * 2 ;
if($desdenoticias == $anterioresnoticias) {
echo "<p align=right><a href=index.php?id=validacion#editarnoticias2>Anteriores $mostrarnoticias noticias</a> | " ;
}
else {
$anterioresnoticias = $desdenoticias - $mostrarnoticias * 2 ;
echo "<p align=right><a href=index.php?id=validacion&desdenoticias=$anterioresnoticias#editarnoticias2>Anteriores $mostrarnoticias noticias</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdenoticias < $noticias) {
echo "<a href=index.php?id=validacion&desdenoticias=$desdenoticias#editarnoticias2>Siguientes $mostrarnoticias noticias</a>" ;
}
if($desdenoticias > $noticias) {
echo "<a href=index.php?id=validacion&desdenoticias=$desdenoticias#editarnoticias2>Siguientes $mostrarnoticias noticias</a>" ;
echo "</p>" ;
} 
?>
</td>
</tr>
</table>
<?
// liberamos memoria y desconecta de mysql en noticias. 
@mysql_close($conecta); 
?>

<?
}
else {
echo "Solo $administrador puede administrar el sitio." ;
}
}
?>