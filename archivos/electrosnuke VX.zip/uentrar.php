<?
include("config.php") ;
if($entrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$contrasena = quitar($contrasena) ;
$resp = mysql_query("select contrasena from usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) != 0) {
if($datos[contrasena] == $contrasena) {
$contrasena = md5(md5($contrasena)) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena,time()+7776000) ;
?>
<script>location='<? echo $pagina ?>'</script>
<?
}
else {
echo "La contrase�a es incorrecta. Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
}
}
else {
echo "Este usuario no existe en la base de datos." ;
}
}
else {
echo "
<form method=post action=uentrar.php>
<b>Nick:</b><br>
<input type=text name=nick maxlength=20><br>
<b>Contrase�a:</b><br>
<input type=password name=contrasena maxlength=20><br><br>
<input type=submit name=entrar value=Entrar>
</form>
" ;
}
?>