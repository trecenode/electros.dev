<table width="400" cellpadding="3" cellspacing="5">
  <tr>
    <td id="tableProps" valign="top" align="left"><img id="pagerrorImg" SRC="http://xtreme-web.net/web/images/button1.gif" width="25" height="33"></td>
    <td id="tableProps2" align="left" valign="middle" width="360"><h1 id="textSection1"
    style="COLOR: black; FONT: 13pt/15pt verdana"><span id="errorText">P�gina no encontrada</span></h1>
    </td>
  </tr>
  <tr>
    <td id="tablePropsWidth" width="400" colspan="2"><font style="COLOR: black; FONT: 8pt/11pt verdana">No s� qu� buscas amigo pero ya no est� aqu� y nunca lo hemos visto.</font></td>
  </tr>
  <tr>
    <td id="tablePropsWidth" width="400" colspan="2"><font id="LID1"
    style="COLOR: black; FONT: 8pt/11pt verdana"><hr color="#C0C0C0" noshade>
    <p id="LID2">Elige alguna de las siguientes opciones:</p><ul>
      <li id="instructionsText1">Preguntarle al
      <a href="http://www.xtreme-web.net/web/index.php?id=usuarios&u=LoveMaster">psicopata del amor</a><br /><br /></li>
      <li id="instructionsText1">Preguntarle al <a href="http://www.xtreme-web.net/web/index.php?id=usuarios&u=elcidop">tito pato</a><br /><br /></li>
      <li id="instructionsText1">Preguntarle al Hombre invisible<br /><br /></li>
      <li id="instructionsText1">Hacer como que no has visto nada<br /><br /></li>
    </ul>
    <p><br>
    </p>
    <h2 id="IEText" style="font:8pt/11pt verdana; color:black">HTTP 200, OK</h2>
    </font></td>
  </tr>
</table>