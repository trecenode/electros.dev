<?
include("config.php") ; 
?>
<title><? echo $titulodelapagina ?></title><body bgcolor="#CCCCCC" leftmargin="15">
<table width="973" height="430" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <!--DWLayoutTable-->
  <tr> 
    <td width="15" rowspan="3" valign="top" background="images/lado2.gif"><img src="images/lado2.gif" width="15" height="102"></td>
    <td height="117" colspan="3" valign="top"> 
      <?
include("top.php") ;
?>
      <?
include("eforo_estilo/$estilopagina") ;
?>
      <div align="center"></div></td>
    <td width="20" rowspan="3" valign="top" background="images/lado.gif"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="16" rowspan="3" valign="top" bgcolor="#CCCCCC"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  <tr> 
    <td width="155" height="243" valign="top"> 
      <?
include("left.php") ;
?>
      <div align="center"><br>
      </div></td>
    <td width="644" valign="top"> <div align="center">
        <? 
// Donde se incluyen las paginas de forma automatica (con la url index.php?id=nombrepagina
// se abriria la pagina nombrepagina.php en esta parte).
if($id == "") { 
include("principal.php"); 
}
else { 
if(file_exists("$id.php")) { 
include("$id.php"); 
} 
else { 
include("error.php"); 
} 
} 
?>
      </div></td>
    <td width="123" valign="top"> 
      <?
include("right.php") ;
?>
      <div align="center"></div></td>
  </tr>
  <tr> 
    <td height="70" colspan="3" valign="top" background="images/downbanner.gif"> 
      <div align="center"><br>
        <br>
        <?
include("footer.php") ;
?>
      </div></td>
  </tr>
  <tr> 
    <td height="0"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
