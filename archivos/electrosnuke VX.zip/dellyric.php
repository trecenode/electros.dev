<?php

include("config.php");

if ($borrar) {
$id = $_POST['titulo'];
$query = "DELETE FROM lyrics WHERE id = '$id'";
mysql_query($query) or die ("error");
echo "El lyric $id fue borrado<br><br>";
}

echo '<form action="index.php?id=dellyric" method="post">
<select name="titulo" size="20" class="input">';

$query = mysql_query("SELECT * FROM lyrics ORDER by id DESC");
while($array = mysql_fetch_array($query)) {
echo "
<option value=\"$array[id]\">$array[titulo]</option>";
}

echo '</select><br><br>
<input type="submit" name="borrar" value="Borrar">
</form><br><br><div align="center"><a href="http://www.xtreme-web.net">Xtreme-Lyrics 1.0</a></div>';
?>