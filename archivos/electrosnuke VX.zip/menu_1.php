<a href="index.php">&raquo; Principal</a><br>
              <a href="index.php?id=usuarios">&raquo; Usuarios</a><br>
              <a href="index.php?id=noticias">&raquo; Noticias</a><br>
              <a href="index.php?id=foro">&raquo; Foro</a><br>
              <a href="index.php?id=enlaces">&raquo; Enlaces</a> <br>
              <a href="index.php?id=buscar">&raquo; Buscar en la pagina</a><br>
              <a href="index.php?id=descargas">&raquo; Descargas</a><br>
			  <a href="index.php?id=lyrics">&raquo; Lyrics</a><br>
			  <a href="index.php?id=galeria">&raquo; Galeria</a><br>
			  <a href="index.php?id=scripts">&raquo; Scripts</a><br>