<!-- Titulo: egris.php
Autor: live@ct
Fecha: 03 enero 2004 -->
<style>
/* Cuerpo del foro */
body,table {
background-color: #666666;
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color:#333333;
scrollbar-arrow-color:#f0f0f0;
scrollbar-shadow-color:#f0f0f0;
scrollbar-highlight-color:#f0f0f0;
scrollbar-3dlight-color:#000000;
scrollbar-darkshadow-Color:#000000;
scrollbar-track-Color:#000000;
}
/* Titulos */
.t1 {
color: #ffffff ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: 1px solid #cccccc;
}
.tabla_titulo {
border-left: #aaaaaa 1 solid ; border-top: #aaaaaa 1 solid ; border-right: #505050 1 solid ; border-bottom: #505050 1 solid ;
background: #333333 ;
}
.tabla_subtitulo {
border-left: #cccccc 1 solid ; border-top: #cccccc 1 solid ; border-right: #aaaaaa 1 solid ; border-bottom: #aaaaaa 1 solid ;
background: #999999 ;
}
.tabla_mensaje {
border-left: #cccccc 1 solid ; border-top: #cccccc 1 solid ; border-right: #cccccc 1 solid ; border-bottom: #cccccc 1 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>