<?
include("config.php") ;

////// Configurar //////
$mensaje = "Bienvenido como usuario.<br> Estas invitado a recorrer nuestra web. Recibe un cordial saludo" ;
//Pon tu nick entre las comillas de remite, o dejalo en blanco, para q llegue el mensaje como anonimo.
$remite = "" ;
/////////////////////// 

$fecha = time() ;
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$nick','$remite','$mensaje')") ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>
