<a href="index.php?id=administrar">&raquo; Administrar</a><br>
<a href="index.php?id=validacion">&raquo; Validar noticias</a><br>
<a href="index.php?id=dellyric">&raquo; Eliminar Lyrics</a><br>
<a href="index.php?id=mensaje_general">&raquo; Enviar Mensaje</a><br>
<img src="images/line_menu.gif" width="149" height="2">