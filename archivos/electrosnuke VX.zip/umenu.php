<?
if($_COOKIE["unick"] ) {
?>
            <img src="http://www.xtreme-web.net/web/images/g.gif" />Bienvenido<br>
<b><? echo $_COOKIE["unick"]  ?></b><br>
            Estas en: <br /><a href="index.php?id=<? if($id) { echo $id ; } else { echo "principal" ; } ?>"> 
            <? if($id) { echo $id ; } else { echo "Principal" ; } ?>
            </a> <br>
<br>
<?
include("foroconfig.php") ;
include("config.php") ;
$resp = mysql_query("select * from usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if($datos[avatar] == "") { $avatar = "0.gif" ; } else { $avatar = "$datos[id].$datos[avatar]" ; }
?><img src="eforo_imagenes/avatares/<? echo $avatar ?>"> <br>
<br>
<img src="http://www.xtreme-web.net/web/images/propiedades.gif" /><a href="index.php?id=upanel">Panel del Usuario</a><a href="index.php?id=usuarios"><br>
</a><img src="http://www.xtreme-web.net/web/images/salir.gif" /><a href="usalir.php">Salir</a><a href="?usuarios"><br>
            <br>
</a><img src="http://www.xtreme-web.net/web/images/email.gif" /><a href="index.php?id=mensajes" >Mensajes</a> 
<?
include("config.php") ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select id from mensajes where nuevo='0' and destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
if($mensajes == 0) {
?>
<?
}
else {
?>
<script>
function BlinkTxt() {
texto = document.getElementsByTagName('blink');
for (i=0; i<texto.length; i++)
if (texto[i].style.visibility=='hidden') {
texto[i].style.visibility='visible';
} else {
texto[i].style.visibility='hidden';
}
setTimeout('BlinkTxt()',100);
}
onload=BlinkTxt;
</script> <blink>(<? echo $mensajes ; ?>)</blink> <bgsound loop="1" src="newemail.wav">
<?
}
?>
<br>
<br>
<img src="http://www.xtreme-web.net/web/images/noticias.gif" /><a href="index.php?id=noticiasenviar">Enviar Noticias<br>
</a><img src="http://www.xtreme-web.net/web/images/htm.png" /><a href="index.php?id=enlacesenviar">Enviar Enlaces</a><br>
<img src="http://www.xtreme-web.net/web/images/zip.gif" /><a href="index.php?id=descargasenviar">Enviar Descargas</a><br>
<img src="images/lyric.png"><a href="index.php?id=envlyric">Enviar Lyrics</a><br />
<br>
<a href="index.php?id=enlacesenviar&opcion=banner">Afiliados banner</a><br>
<a href="index.php?id=enlacesenviar&opcion=minibanner">Afiliados minibanner</a><br>
<?
}
else {
?>
<form method="post" action="uentrar.php">
              <img src="http://www.xtreme-web.net/web/images/g.gif" />Bienvenido Anonimo<br />Nick:<br>
              <input name="nick" type="text" class="form" size="18">
              <br>
              Contrase�a:<br>
              <input name="contrasena" type="password" class="form" size="18">
			
              <br>
              <br>
              <input type="submit" name="entrar" value="Entrar" class="form">
			  <input type="hidden" name="pagina" value="<? echo $_SERVER['REQUEST_URI'] ?>">
</form>
            
<img src="http://www.xtreme-web.net/web/images/usuario.gif" /><a href="index.php?id=uregistrar">Registrate</a><br>
<img src="http://www.xtreme-web.net/web/images/g8.gif" /><a href="index.php?id=ucontrasena">�Olvide contrase�a?</a><br>
<?
}
?>