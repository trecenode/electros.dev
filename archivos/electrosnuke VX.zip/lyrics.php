<?php
//Coneccion a la base de datos
@include("config.php");

$l = $_GET['l'];


if (isset($l)) {

$buscar = mysql_query("SELECT * FROM lyrics WHERE id = '$l' LIMIT 1");
$lyric = mysql_fetch_array($buscar);

$titulo = trim(htmlspecialchars($lyric[titulo]));
$autor = trim(htmlspecialchars($lyric[autor]));
$letra = trim(nl2br($lyric[lyric]));

//Mostramos el lyric buscado...
echo '
<table width="500" align="center" cellspacing="0">
  <tr>
    <td><b>Autor: ' . $autor . '</b><br><b>Cancion: ' . $titulo . '</b></td>
  </tr>
  <tr>
    <td><b>Lyric/Letra:</b><br>' . $letra . '<br><br><br><div align="center"><a href="http://www.xtreme-web.net">Xtreme-Lyrics 1.0</a></div></td>
  </tr>
</table>';

} else {

//Buscamos los lyrics que hay en la db...
$buscar = mysql_query("SELECT * FROM lyrics ORDER by id DESC");
while ($datos = mysql_fetch_array($buscar)) {
echo '<img src="images/lyric.png"><a href="index.php?id=lyrics&l=' . $datos[id] . '">' . $datos[autor] . ' - ' . $datos[titulo] . '</a><br>';
}

}

mysql_free_result($buscar);
?>