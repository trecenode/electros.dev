<?
include("config.php") ;
?>
<p class=titulo>Usuarios
<?
if($u) {
$resp = mysql_query("select * from usuarios where id='$u'") ;
$datos = mysql_fetch_array($resp) ;
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
if($datos[edad] == 0) { $datos[edad] = "" ; }
if($datos[web] != "http://") { $web = "<a href='$datos[web]' target='_black'>$datos[web]</a>" ; }
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
?>
<p><b>Usuario desde el:</b> <? echo $fecha ?>
<p>
<table width=100% border=0 cellpadding=5 cellspacing=0>
  <tr> 
    <td class="tabla_subtitulo"><b>Nick:</b></td>
    <td class="tabla_subtitulo"><? echo $datos[nick] ?></td>
  </tr>
  <tr> 
    <td class="tabla_subtitulo"><b>Pa�s:</b></td>
    <td class="tabla_subtitulo"><? echo $datos[pais] ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_subtitulo"><b>Edad:</b></td>
    <td class="tabla_subtitulo"><? echo $datos[edad] ?>&nbsp;</td>
  </tr>
  <tr> 
    <td class="tabla_subtitulo"><b>Sexo:</b></td>
    <td class="tabla_subtitulo"><? echo $sexotexto[$sexonumero] ?></td>
  </tr>
  <tr> 
    <td class="tabla_subtitulo"><b>Descripci�n:</b></td>
    <td class="tabla_subtitulo"><? echo $datos[descripcion] ?>&nbsp;</td>
  </tr>
  <tr>
    <td class="tabla_subtitulo"><b>Web</b></td>
    <td class="tabla_subtitulo"><? echo $web ?>&nbsp;</td>
  </tr>
  <tr>
    <td class="tabla_subtitulo"><b>Firma</b></td>
    <td class="tabla_subtitulo"><? echo $datos[firma ] ?>&nbsp;</td>
  </tr>
<?
if($datos[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<tr><td class=\"tabla_subtitulo\"><b>Avatar:</b></td><td class=\"tabla_subtitulo\"><img src=\"eforo_imagenes/avatares/$datos[id].$datos[avatar]\"></td></tr>" ;
}
echo $avatar ;
?>
</table>
<p><a href=index.php?id=usuarios>Regresar a Usuarios</a>
<?
}
else {
$resp = mysql_query("select id from usuarios") ;
$usuarios = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 25 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select id,nick,sexo,pais from usuarios order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
?>
<p><b>Usuarios registrados en la web:</b> <? echo $usuarios ?>
<p>
<table width=100% border=0 cellpadding=5 cellspacing=0>
<tr>
<td width=50% class="tabla_titulo"><b>Nick</b></td>
<td width=25% class="tabla_titulo"><b>Sexo</b></td>
<td width=25% class="tabla_titulo"><b>Pa�s</b></td>
</tr>
<?
while($datos = mysql_fetch_array($resp)) {
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;
?>
<tr>
<td class="tabla_subtitulo"><a href=index.php?id=usuarios&u=<? echo $datos[id]?>><? echo $datos[nick] ?></a></td>
<td class="tabla_subtitulo"><? echo $sexotexto[$sexonumero] ?></td>
<td class="tabla_subtitulo"><? echo $datos[pais] ?>&nbsp;</td>
</tr>
<?
}
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=index.php?id=usuarios>Anteriores $mostrar usuarios</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=index.php?id=usuarios&desde=$anteriores>Anteriores $mostrar usuarios</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $usuarios) {
echo "<a href=index.php?id=usuarios&desde=$desde>Siguientes $mostrar usuarios</a>" ;
}
}
?>