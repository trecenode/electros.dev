<?
include("config.php") ;
$resp = mysql_query("select contrasena from usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[contrasena] != $HTTP_COOKIE_VARS[ucontrasena]) {
?>
<script>location="usalir.php"</script>
<?
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>