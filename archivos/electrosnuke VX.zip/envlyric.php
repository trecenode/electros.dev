<?
include("config.php");

if ($enviar) {
	$autor = trim(htmlspecialchars($_POST['autor']));
	$titulo = trim(htmlspecialchars($_POST['titulo']));
	$lyric = trim($_POST['lyric']);
    $query = "INSERT INTO lyrics (autor, titulo, lyric) values ('$autor', '$titulo', '$lyric')";
    mysql_query($query) or die("error");
    echo "A�ADIDO<br><br>";
	}
	
echo '
<form method="post" action="index.php?id=envlyric" name="form">
Autor:<br>
<input type="text" name="autor"><br>
Titulo:<br>
<input type="text" name="titulo" size="20" class="input"><br><br>
Lyric:<br>
<textarea name="lyric" cols="45" rows="5" class="input"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar">
</form><br><br><div align="center"><a href="http://www.xtreme-web.net">Xtreme-Lyrics 1.0</a></div>';

?>