<?
include("config.php");
if($buscar) {
$ver = 5 ; // resultados a mostrar
$resp = mysql_query("SELECT * FROM noticias WHERE noticia  LIKE '%".$_POST[palabra]."%' ORDER BY `id` DESC LIMIT $ver");
if(mysql_num_rows($resp) == 0) { echo "<strong>NO HUBO RESULTADOS EN lA BD.</strong> ." ; }
else {
while($sql=mysql_fetch_array($resp))  //llamamos a la base de datos 
 {
  ?>
<style type="text/css">
<!--
.Estilo1 {color: #FFFFFF}
-->
</style>

 <table width="330" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
   <tr>
     
    <td bgcolor="##FF0000"><span class="Estilo1">Datos</span></td>
   </tr>
   <tr>
     <td><table width="100%">
       <tr>
         <td>Numero de la noticia:</td>
         <td><?php echo $sql[id] ?>&nbsp;</td>
       </tr>
       <tr>
         <td>Autor:</td>
         <td><?php echo $sql[usuario] ?>&nbsp;</td>
       </tr>
       <tr>
         <td>Titulo de la noticia:</td>
         <td><?php echo $sql[titulo] ?>&nbsp;</td>
       </tr>
       <tr>
         <td>Enlace de la noticia:</td>
         <td><a href="noticias.php?n=<? echo "$sql[id]" ?>">Aqu&iacute;</a>&nbsp;</td></tr>
     </table></td>
   </tr>
 </table>
<br>

<?
}
echo "<strong> RESULTADOS OBTENIDOS</strong>";
}
}
?>
<form action="index.php?id=buscar" method="post">
  <table width="140" cellspacing="2">
  <tr>
    <td width="72"><input type="text" size="15" maxlength="65" name="palabra" class="form">      </td>
    <td width="112"><input type="submit" name="buscar" value="Buscar" class="form"></td>
  </tr>
</table>
</form>