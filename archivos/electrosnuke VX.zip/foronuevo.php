<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[contrasena] != $HTTP_COOKIE_VARS[ucontrasena]) {
header("location: foroentrar.php") ;
exit ;
}
mysql_free_result($resp) ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$tema = quitar($tema) ;
$mensaje = quitar($mensaje) ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
mysql_query("insert into eforo_mensajes (foro,foromostrar,fecha,usuario,tema,mensaje,caretos,codigo,url,firma,editado,ultimo) values ('$foroid','1','$fecha','$usuario','$tema','$mensaje','$caretosusar','$codigousar','$urlusar','$firmausar','$fecha','$fecha')") ;
$resp = mysql_query("select id from eforo_mensajes order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$forotema = $datos[id] ;
mysql_query("update eforo_mensajes set forotema='$forotema' where id='$forotema'") ;
mysql_query("update eforo_foros set temas=temas+1,mensajes=mensajes+1 where id='$foroid'") ;
mysql_query("update $tabla_usuarios set mensajes=mensajes+1 where nick='$usuario'") ;
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Confirmaci�n</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<div align="center">
Tu mensaje ha sido publicado con �xito. Haz click <a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $forotema ?>">aqu�</a> para ver tu mensaje.
</div>
</td>
</tr>
</table>
<?
mysql_free_result($resp) ;
}
else {
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p><a href="foro.php">Indice del foro</a> � <a href="foro.php?foroid=<? echo $foroid ?>"><? echo $datos[foro] ?></a>
<p>
<?
mysql_free_result($resp) ;
?>
<script>
function caretos(codigo) {
formulario.mensaje.value += codigo ;
formulario.mensaje.focus() ;
}
function revisar() {
if(formulario.tema.value.length == 0) { alert('Debes escribir un tema') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<form name="formulario" method="post" action="foronuevo.php?foroid=<? echo $foroid ?>" onsubmit="return revisar()">
<table width="100%" border="0" cellpadding="5" cellspacing="1">
<tr>
<td class="tabla_mensaje" valign="top">
<b>T�tulo:</b><br>
T�tulo del mensaje.
</td>
<td class="tabla_mensaje" valign="top">
<input type="text" name="tema" size="40" maxlength="100" class="form">
</td>
</tr>
<tr>
<td class="tabla_mensaje" valign="top">
<b>Mensaje:</b><br>
Contenido del mensaje.<br><br>
<b>Caretos:</b><br><br>
<table border="0" cellpadding="5" cellspacing="0" align="center">
<tr>
<td><a href="javascript:caretos(':D')"><img src="eforo_imagenes/caretos/alegre.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':8')"><img src="eforo_imagenes/caretos/asustado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':P')"><img src="eforo_imagenes/caretos/burla.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':S')"><img src="eforo_imagenes/caretos/confundido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(1')"><img src="eforo_imagenes/caretos/demonio.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':(2')"><img src="eforo_imagenes/caretos/demonio2.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':?')"><img src="eforo_imagenes/caretos/duda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-\(')"><img src="eforo_imagenes/caretos/enojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(';)')"><img src="eforo_imagenes/caretos/guino.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':\'(')"><img src="eforo_imagenes/caretos/llorar.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td><a href="javascript:caretos(':lol:')"><img src="eforo_imagenes/caretos/lol.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':M')"><img src="eforo_imagenes/caretos/moda.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':|')"><img src="eforo_imagenes/caretos/neutral.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':)')"><img src="eforo_imagenes/caretos/risa.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':-)')"><img src="eforo_imagenes/caretos/sonrisa.gif" width="15" height="15" border="0"></a></td>
</tr>
<tr>
<td></td>
<td><a href="javascript:caretos(':R')"><img src="eforo_imagenes/caretos/sonrojado.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':O')"><img src="eforo_imagenes/caretos/sorprendido.gif" width="15" height="15" border="0"></a></td>
<td><a href="javascript:caretos(':(')"><img src="eforo_imagenes/caretos/triste.gif" width="15" height="15" border="0"></a></td>
<td></td>
</tr>
</table>
</td>
<td class="tabla_mensaje" valign="top">
<textarea name="mensaje" cols="50" rows="20" class="form"></textarea>
</td>
</tr>
<tr>
<td valign="top" class="tabla_mensaje">&nbsp;</td>
<td class="tabla_mensaje">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="50%" valign="top">
<? if($caretos == "ON") { ?><input type="checkbox" name="caretosusar" value="1" id="caretosusar" checked><label for="caretosusar"><b>Usar caretos en los mensajes</b></label><br><? } ?>
<? if($codigo == "ON") { ?><input type="checkbox" name="codigousar" value="1" id="codigousar" checked><label for="codigousar"><b>Usar eCodigo en los mensajes</b></label><br><? } ?>
<? if($url == "ON") { ?><input type="checkbox" name="urlusar" value="1" id="urlusar" checked><label for="urlusar"><b>Transformar URLs en enlaces</b></label><br><? } ?>
</td>
<td width="50%" valign="top">
<input type="checkbox" name="firmausar" value="1" id="firmausar" checked><label for="firmausar"><b>Agregar firma en los mensajes</b></label><br>
</td>
</tr>
</table>
</td>
</tr>
<tr>
<td class="tabla_mensaje">&nbsp;</td>
<td class="tabla_mensaje">
<div align="right">
<input type="submit" name="enviar" value="Enviar" class="form">
</div>
</td>
</tr>
</table>
</form>
<?
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
</body>
</html>
