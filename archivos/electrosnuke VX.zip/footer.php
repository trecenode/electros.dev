<div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&copy; 2006-2010 Xtreme-Web.net - Theme by KekoGrama (Pa ti Colega xD) - Enuke by Electros</font></div>
