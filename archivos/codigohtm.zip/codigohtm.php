<?
$idpass = "123456" ;
$idautor = "elcidop" ;
$idfecha = "14.02.04 a las 16:54:26" ;
$iddesc = "Aqui veremos como funciona este script." ;
?>