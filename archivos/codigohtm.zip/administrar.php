<!-- Este archivo es para el administrador, es el mismo solo que ahora<br>
solo puede editar,borrar y renombrar el adminstrador y la contrase�a es 
por defecto 123456 , para cambiar la contrase�a remplazala de la linea 773,870,934-->
<title>Codigohtm - htm,java,javascript,php</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>

<div class="t1">Codigohtm</div>
<br>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td height="7" class="tabla_subtitulo"><b>Archivo</b></td>
    <td height="7" class="tabla_subtitulo"><strong>Descripcion</strong></td>
    <td width="12%" height="7" class="tabla_subtitulo"><div align="left"><strong>Autor</strong></div></td>
    <td width="8%" class="tabla_subtitulo"><b>Tama�o</b></td>
    <td width="8%" class="tabla_subtitulo"><b>Lecturas</b></td>
    <td colspan="4" class="tabla_subtitulo">&nbsp;</td>
  </tr>
  <?php
// Script 'Codigohtm' realizado  por elcidop en colaboracion con $$felipe$$
/// Web del autor: wwww.phpmysql.tk www.elcidop.com wwww.elcidop.webcindario.com

// Contamos los clicks echo en los archivos
// se pone administrar.php?a=fichero y dependiendo de la existencia fisica del fichero
// en dicho directorio abriremos un header u otro.
if ($a) {
$fichero = $a ; 
$fp=fopen("$fichero.dat","r");
$numero=fread($fp,filesize("$fichero.dat"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.dat", "w");
fputs ($fichero,$clicks);
fclose ($fichero);


header("Location:administrar.php?tutorial=$a");
}
// Contamos los clicks echo en las descargas adjuntas ,
// se guardar como 'archivo.zip.dat'
if ($b) {

$fichero = $b ; 
$fp=fopen("$fichero.zip.dat","r");
$numero=fread($fp,filesize("$fichero.zip.dat"));
$clicks=1+$numero;

$fichero = fopen ("$fichero.zip.dat", "w");
fputs ($fichero,$clicks);
fclose ($fichero);

header("Location:$b.zip");
}
// Script para 'ver el directorio' realizado por $$felipe$$ //
// web del autor de este codigo : portalmusik.elcidop.com //

								 // Le damos valor a las variables de configuraci�n
 $Config['Path'] = "."; 		// Directorio donde stan los archivos a mostrar.
 $Config['Show'] = 20; 			// Numero de archivos a mostrar por p�ginas.

 $Show['20 Anteriores'] = 0;		// Por defecto no se mostrara 10 Anteriores
 $Show['20 Siguientes'] = 0;		// Por defecto no se mostrara 10 Siguientes
 
 if ($c == "") $c = 0;			// Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
 $dir = opendir($Config['Path']); 		// Abrimos el directorio donde estan los archivos
 $Plus = $c;					// Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

 while ($c > 0 && $elemento = readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
 {
  $Show['20 Anteriores'] = 1;
  $c--;
 }

 $Counter = 0;			// Ponemos a 0 el contador

 // Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
 if ($Show['20 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['20 Anteriores'] = 1;
   $c--;
  }
 }
 
 // Mostramos el numero de archivos que se tienen que mostrar por p�gina.
 while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
 {
  $Counter++;

  $elemento1 = strtolower($elemento); 
  if (strpos($elemento1, ".txt") > 1) {

   // pasamos el tama�o del archivo a kb
   $tamano = filesize($elemento)/1024;
   $tamano = ceil($tamano) ; 
   // Asignamos el archivo sin extension
   $elemento2 = str_replace(".txt","",$elemento); 
?>
  <tr> 
    <td width="20%" height='7' class="tabla_mensaje"> 
      <?
// Archivo adjunto
if(file_exists("$elemento2.zip")) {
echo "<a href='administrar.php?b=$elemento2' ><img src='zip.gif' border='0' width='16' height='16'></a>";
}
else 
{ 
echo "";
} 
?>
      <a href="administrar.php?a=<?php echo $elemento2 ?>" ><img src="txt.gif" border="0" width="16" height="16" > 
      <? echo $elemento2 ?></a></td>
    <td width="29%" class="tabla_mensaje">
      <div align="left"><?
// asignamos el tama�o de los archivo
if(file_exists("$elemento2.php")) {
include ("$elemento2.php") ;
echo "$iddesc";
}
else 
{ 
echo "Sin descripcion";
}
?></div>
    </td>
    <td class="tabla_mensaje"> 
      <?
// asignamos el tama�o de los archivo
if(file_exists("$elemento2.php")) {
include ("$elemento2.php") ;
echo "$idautor";
}
else 
{ 
echo "Anonimo";
}
?>
      <br> </td>
    <td height='7' class='tabla_mensaje'> 
      <?  
// asignamos el tama�o de los archivo
if(filesize($elemento) > 1000000) {
$tamano = filesize($elemento)/1024/1024;
$tamano = ceil($tamano) ;
echo "$tamano Mb";
}
else { 
if(filesize($elemento) > 1000) {
$tamano = filesize($elemento)/1024;
$tamano = ceil($tamano) ;
echo "$tamano Kb";
} 
else {
$tamano = filesize($elemento);
$tamano = ceil($tamano);
echo "$tamano bytes";
} 
}
?>
    </td>
    <td class='tabla_mensaje'> 
      <?
// asignamos el tama�o de los archivo
if(file_exists("$elemento2.dat")) {
include ("$elemento2.dat") ;
}
else 
{ 
echo "0";
}
?>
    </td>
    <td width="6%" class='tabla_mensaje'><a href="administrar.php?archivo=<?
echo "$elemento2";
?>" >Editar</a></td>
    <td width="7%" class='tabla_mensaje'><a href="administrar.php?borrar=<?
echo "$elemento2";
?>">Borrar</a></td>
    <td width="10%" class='tabla_mensaje'><a href="administrar.php?renombrar=<?
echo "$elemento2";
?>">Renombrar</a></td>
  </tr>
  <?php
  }
 }
  
 // Si sobran archivos pondremos el "10 Siguientes"
 if ($elemento = readdir($dir))
 {
  $Show['20 Siguientes'] = 1;
 }

 //Cerramos el directorio 
 closedir($dir); 
?>
</table>
<div align="right">
<?php
 // Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
 if ($Show['20 Anteriores'] == 1) echo("<a href=\"administrar.php?c=".($Plus-$Config['Show'])."\">20 Anteriores | </a>");
 if ($Show['20 Siguientes'] == 1) echo("&nbsp;<a href=\"administrar.php?c=".($Plus+$Config['Show'])."\">20 Siguientes</a></p>");
?>
</div>
<a href="administrar.php?archivon=nuevo%20%20tutorial"> <br>
+ A&ntilde;adir nuevo tutorial</a><br>
<? if ($tutorial) 
{ 
?><br>
<table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid' dwcopytype="CopyTableCell">
  <tr> 
    <td width="97%" height="1" align="center" class="tabla_subtitulo"><div align="center" class="t1"> 
        <?
// Nombre del archivo
if(file_exists("$tutorial.txt")) {
echo "$tutorial";
} 
else 
{ 
echo "No existe";
} 
?>
      </div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="8" colspan="2" class="tabla_mensaje"> <div align="left"> 
        <? /*opcion nueva para poder subir tutoriales sobre el bbcode y que no interfiera con el propio bbcode de la pagina*/ if ($bbcode != "off" ) { ?>
        &iquest;Tienes problemas para ver el tutorial ? pulsa en <a href="<? echo $_SERVER[REQUEST_URI] ?>&bbcode=off">desactivar 
        bbcode</a> 
        <? } ?>
        <? if ($bbcode == "off" ) { ?>
        <b>* bbcode desactivado</b> , para activarlo de nuevo pulsa <b> <a href="administrar.php?tutorial=<? echo $tutorial ?>">aqui</a></b> 
        <? } ?>
      </div></td>
  </tr>
  <tr> 
    <td height="83" colspan="2" class="tabla_mensaje"> <table width='100%' border='1' align='center' cellpadding='5' cellspacing='0' style='border: #757575 1 solid'>
        <tr> 
          <td width="100%" height="31" class="tabla_mensaje"> 
            <?
// Autor del tutorial
if(file_exists("$tutorial.php")) {
include ("$tutorial.php") ;
echo "- Autor del tutorial : <b>$idautor</b>";
}
else 
{ 
echo "";
}
?>
            <br> 
            <?
// Fecha subida tutorial
if(file_exists("$tutorial.php")) {
include ("$tutorial.php") ;
echo "- Fecha de subida del tutorial : <b>$idfecha</b>";
}
else 
{ 
echo "";
}
?>
            <br> 
            <?
// asignamos el tama�o de los archivo
if(file_exists("$tutorial.php")) {
include ("$tutorial.php") ;
echo "- Descripcion: $iddesc";
}
else 
{ 
echo "";
}
?>
          </td>
        </tr>
        <?
// Archivo adjunto
if(file_exists("$tutorial.zip")) {
?>
        <?
}
else 
{ 
echo "";
} 
?>
      </table>
      <br>
      <?
// Buscamos si el archivo existe y lo leemos
// $codigo seria el contenido del archivo en si
if(file_exists("$tutorial.txt")) {  
$archi = "$tutorial.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// bbcode o codigo especial, este codigo lo que hace
// es sustituir determinadas expresiones de letras
// por codigo html seguro
// para desactivarlo pon if ($bbcode == "on" ) {
// administrar.php?tutorial=aaa&bbcode=on
if ($bbcode != "off" ) {
$codigo = str_replace("[b]","<b>",$codigo) ;
$codigo = str_replace("[/b]","</b>",$codigo) ;
$codigo = str_replace("[img]","<img src=\"",$codigo) ;
$codigo = str_replace("[/img]","\" border=\"0\">",$codigo) ;

$codigo = str_replace("[u]","<u>",$codigo) ; 
$codigo = str_replace("[/u]","</u>",$codigo) ; 
$codigo = str_replace("[s]","<strike>",$codigo) ; 
$codigo = str_replace("[/s]","</strike>",$codigo) ; 
$codigo = str_replace("[sup]","<sup>",$codigo) ; 
$codigo = str_replace("[/sup]","</sup>",$codigo) ; 
$codigo = str_replace("[sub]","<sub>",$codigo) ; 
$codigo = str_replace("[/sub]","</sub>",$codigo) ; 
$codigo = str_replace("[left]","<left>",$codigo) ; 
$codigo = str_replace("[/left]","</left>",$codigo) ; 
$codigo = str_replace("[center]","<p align=center>",$codigo) ;
$codigo = str_replace("[/center]","</p>",$codigo) ;
$codigo = str_replace("[right]","<p align=right>",$codigo) ;
$codigo = str_replace("[/right]","</p>",$codigo) ;
// Inicio caretos : por defecto desactivados
// ya que esta demostrado que puede interferir con colorear el codigo
// para activarlos permanetemente pon if ($caretos != "off" ) {
if ($caretos == "on" ) {
$codigo = str_replace("[[","",$codigo) ;
$codigo = str_replace("]]","",$codigo) ;
$codigo = str_replace(":D","[[alegre.gif]]",$codigo) ;
$codigo = str_replace(":8","[[asustado.gif]]",$codigo) ;
$codigo = str_replace(":P","[[burla.gif]]",$codigo) ;
$codigo = str_replace(":S","[[confundido.gif]]",$codigo) ;
$codigo = str_replace(":(1","[[demonio.gif]]",$codigo) ;
$codigo = str_replace(":(2","[[demonio2.gif]]",$codigo) ;
$codigo = str_replace(":?","[[duda.gif]]",$codigo) ;
$codigo = str_replace(":-(","[[enojado.gif]]",$codigo) ;
$codigo = str_replace(";)","[[guino.gif]]",$codigo) ;
$codigo = str_replace(":'(","[[llorar.gif]]",$codigo) ;
$codigo = str_replace(":lol","[[lol.gif]]",$codigo) ;
$codigo = str_replace(":M","[[moda.gif]]",$codigo) ;
$codigo = str_replace(":|","[[neutral.gif]]",$codigo) ;
$codigo = str_replace(":)","[[risa.gif]]",$codigo) ;
$codigo = str_replace(":-)","[[sonrisa.gif]]",$codigo) ;
$codigo = str_replace(":R","[[sonrojado.gif]]",$codigo) ;
$codigo = str_replace(":O","[[sorprendido.gif]]",$codigo) ;
$codigo = str_replace(":(","[[triste.gif]]",$codigo) ;
$codigo = str_replace("[[","<img src=\"caretos/",$codigo) ;
$codigo = str_replace("]]","\" width=\"15\" height=\"15\">",$codigo) ;
}
// anti-insultos
$codigo = str_replace("capullo","***",$codigo) ;
$codigo = str_replace("cabron","***",$codigo) ;
$codigo = str_replace("hijo puta","***",$codigo) ;
$codigo = str_replace("maricon","***",$codigo) ;
$codigo = str_replace("puta","***",$codigo) ;
$codigo = str_replace("gay","***",$codigo) ;
// convertir enlaces a url
$codigo = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$codigo) ;
// colorear el codigo 
// by wwww.electros.tk
if(strstr($codigo,"[codigo]")) {
$partes = explode("[codigo]",$codigo) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$codigo = implode("",$partes) ;
} 
}
// Ponemos en el codigo los puntos y los espacios correspondientes.
$codigo = str_replace("\r\n","<br>",$codigo) ;
// Mostramos el codigo de la pagina
echo "$codigo";
} 
else 
{ 
echo "Este tutorial se esta actualizando o ya no existe.";
} 
?>
      &nbsp;</td>
  </tr>
  <?
// Archivo adjunto
if(file_exists("$tutorial.zip")) {
?><tr>
    <td height='4' colspan='2' class='tabla_mensaje'><div align="center"><a href='administrar.php?b=<? echo $tutorial ?>' ><img src='zip.gif' border='0' width='16' height='16'> 
        Descargar archivo</a> (
        <?
// Contamos los clicks en los archivos
if(file_exists("$tutorial.zip.dat")) {
include ("$tutorial.zip.dat") ;
}
else 
{ 
echo "0";
}
?>
        ) </div></td>
  </tr><?
}
else 
{ 
echo "";
} 
?>
</table>
<?
}
?>
<br>
<?
// Crear un nuevo tutorial: si el archivo no tiene nombre 
// y comprobamos si no existe nuevo%20%20tutorial.txt
if ($archivon != "") {
if(!file_exists("nuevo%20%20tutorial.txt")) { 
 function write_fil2($arch, $titulo) {
 if ($fp = @fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left"> 
        Nuevo tutorial 
        <script>
function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
      </div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="587" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method="post" action='administrar.php?action=new&archivon=<? echo $archivon ?>' id="formulario" name="formulario" enctype="multipart/form-data">
          Nombre del tutorial :<br>
          <input name='archivon' type='text' class='form' value="<? /*si el archivo es 'nuevo tutorial' evitaremos que ponga eso mismo en el formulario */  if ($archivon ="nuevo%20%20tutorial"){$archivon ="";}  else {} echo $archivon ?>" size="33">
          <br>
          Autor del tutorial :<br>
          <input name='cnautor' type='text' class='form' id="cnautor" size="33">
          <br>
          Contrase&ntilde;a atribuida al tutorial :<br>
          <input name='cnpass' type='text' class='form' id="cnpass" size="33">
          <br>
          Breve descripcion del tutorial :<br>
          <textarea rows="3" cols="50"  name="cndesc" id="cndesc" class='form'><? echo $codigo ?>
</textarea>
          <br>
          Contenido del tutorial :<br>
          <br>
          <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> 
          Insertar un codigo php.<br>
          <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar un texto 
          en negrita.<br>
          <a href="javascript:descargar('[img][/img]')">[img][/img]</a> Insertar 
          una imagen.<br>
          <br>
          <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. <br>
		  <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. <br>
		  <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> Superindice. <br>
		  <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> Subindice. <br>
		  <a href="javascript:descargar('[left][/left]')">[left][/left]</a> Alinear texto a la izquierda . <br>
		  <a href="javascript:descargar('[right][/right]')">[right][/right]</a> Alinear texto a la derecha . <br>
          <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
          Alinear texto al centro . <br>
          <br>
          <br>
          <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
          <br>
          <br>
          <b>Como deseas enviar el archivo ?</b><br>
          <input type="radio" name="envioarchivo" value="0" id="envioarchivo1" checked>
          <label for="envioarchivo1">No subir archivo</label>
          <input type="radio" name="envioarchivo" value="1" id="envioarchivo2">
          <label for="envioarchivo2">Subir el archivo</label>
          <br>
          <br>
          <b style="color: #ff0000">Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input type="file" name="archivo" size="30" class="form">
          <br>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$descargar = $_POST['descargar'];
}
else if($action == "new")
{
// Comprobamos si en el form se envia $descargar y $descargar no esta vacio
// comprobamos que no haya otro tutorial con el mismo nombre
// comprobamos si existe  nuevo%20%20tutorial.txt
if (isset($descargar)&&($descargar!="")){
// bbcode para mayor seguridad
function quitar1($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$cnpass = quitar1($cnpass) ;
$cnautor = quitar1($cnautor) ;
$cnfecha = quitar1($cnfecha) ;
$cnfecha = quitar1($cnfecha) ;
$cndesc = quitar1($cndesc) ;
// creamos el archivo.php fisicamente con los datos
$cnfecha = Date("d.m.y")." a las ".Date("H:i:s");
$nuevo = "&lt;?
\$idpass = \"$cnpass\" ;
\$idautor = \"$cnautor\" ;
\$idfecha = \"$cnfecha\" ;
\$iddesc = \"$cndesc\" ;
?&gt;";
$nuevo = str_replace("&lt;","<",$nuevo);
$nuevo = str_replace("&gt;",">",$nuevo);
$fich = fopen("$archivon.php","w");
fputs($fich,$nuevo);
fclose($fich);

if(!file_exists("$archivon.txt")) {
if(!file_exists("nuevo%20%20tutorial.txt")) {  
// --> bbcode
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$descargar = quitar($descargar) ;
// --> Fin bbcode
// creamos el tutorial fisicamente
if($envioarchivo != "1") { $error = "El archivo debe tener el mismo nombre del tutorial que es <b>$archivon</b>.<br>" ; }
$rs = write_fil2("$archivon.txt", "$descargar");
$archi = "$archivon.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
// enviamos el archivo
if($enviar) {
if($archivo != "" && $envioarchivo == 1) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "zip") { $error = "S�lo se permiten archivos .zip<br>" ; }

if(file_exists("$archivo_name")) { $error= "Ya existe un archivo con este nombre.<br>" ; }
if($archivo_size > 250000) { $error= "El archivo debe pesar menos de 250 Kb.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
}
copy($archivo,"$archivon.zip")
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Nuevo 
        tutorial </div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
        Nuevo tutorial creado satisfactoriamente, <a href="administrar.php">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
}
}
}
}
?>
<br>
<?
if ($archivo != "") { 
 function write_fil($arch, $titulo) {
 if ($fp = fopen($arch, "w")) {
        fwrite ($fp, stripslashes($titulo));
        fclose($fp);
        return 1;
        }
 else { return 0; }
        };
if($action == ""){
$archi = "$archivo.txt";
$abrir = @fopen($archi,"r");
$codigo = @fread($abrir, @filesize($archi));
@fclose($abrir);
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> 
        Editar un comentario 
        <script>
function descargar(codigo) {
formulario.descargar.value += codigo ;
formulario.descargar.focus() ;
}
</script>
      </div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="5" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method="post" action='administrar.php?action=ver&archivo=<? echo $archivo ?>' id="formulario" name="formulario" enctype="multipart/form-data">
          Contrase&ntilde;a :<br>
          <input type='text' name='contrasena' class='form'>
          <br>
          Nombre del tutorial :<br>
          <input name='archivo' type='text' class='form' value="<? echo $archivo ?>" size="33" readonly>
          <br>
          Contenido del tutorial :<br>
          <br>
          <a href="javascript:descargar('[codigo][/codigo]')">[codigo][/codigo]</a> 
          Insertar un codigo php.<br>
          <a href="javascript:descargar('[b][/b]')">[b][/b]</a> Insertar un texto 
          en negrita.<br>
          <a href="javascript:descargar('[img][/img]')">[img][/img]</a> Insertar 
          una imagen.<br>
          <br>
          <a href="javascript:descargar('[u][/u]')">[u][/u]</a> Subrayado. <br>
          <a href="javascript:descargar('[s][/s]')">[s][/s]</a> Tachado. <br>
          <a href="javascript:descargar('[sup][/sup]')">[sup][/sup]</a> Superindice. 
          <br>
          <a href="javascript:descargar('[sub][/sub]')">[sub][/sub]</a> Subindice. 
          <br>
          <a href="javascript:descargar('[left][/left]')">[left][/left]</a> Alinear 
          texto a la izquierda . <br>
          <a href="javascript:descargar('[right][/right]')">[right][/right]</a> 
          Alinear texto a la derecha . <br>
          <a href="javascript:descargar('[center][/center]')">[right][/right]</a> 
          Alinear texto al centro . <br>
          <br>
          <textarea rows="12" cols="50"  name="descargar" class='form'><? echo $codigo ?>
</textarea>
          <?
// Si existe el Archivo adjunto lo mostramos
if(file_exists("$archivo.zip")) {
?><br>
          <br>
          Archivo adjunto :<b> <img src="zip.gif" width="15" height="16"> <? echo "$archivo.zip" ?><br>
          <br>
          Deseas actualizar el archivo adjunto ?</b> <br>
          <input type='radio' name='envioarchivo' value='0' id='radio3' checked>
          <label for='radio3'>No</label>
          <input type='radio' name='envioarchivo' value='1' id='radio4'>
          <label for='radio4'>Si</label>
          <br>
          <b style='color: #ff0000'>Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input name='archiv' type='file' class='form' id="archiv" size='30'>
          <br>
          <input name="borrare" type="checkbox" id="borrare" value="1">
          Borrar archivo <br>
          <?
}
else 
{ 
?><br>
          <b>Como deseas enviar el archivo ?</b><br>
          <input type="radio" name="envioarchivo" value="0" id="radio6" checked>
          <label for="radio6">No subir archivo</label>
          <input type="radio" name="envioarchivo" value="1" id="radio7">
          <label for="radio7">Subir el archivo</label>
          <br>
          <br>
          <b style="color: #ff0000">Archivo a subir (s�lo si est� seleccionada 
          la segunda opci�n) :</b><br>
          <input name="archiv" type="file" class="form" id="archiv" size="30">
          <br>
          <?
} 
?>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<? 
$descargar = $_POST['descargar'];
}
else if($action == "ver")
{
if ($contrasena != "123456") { exit; }{ 
if (isset($descargar)&&isset($contrasena)&&($descargar!="")&&($contrasena!=""))
{
// --> bbcode
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$descargar = quitar($descargar) ;
// --> Fin bbcode
$rs = write_fil("$archivo.txt", "$descargar");
$archi = "$archivo.txt";
$abrir = fopen($archi,"r");
$codigo = fread($abrir, filesize($archi));
fclose($abrir);
// borrar el archivo
if($borrare == "1") { unlink("$archivo.zip"); }
// actualizar el archivo
if($enviar) {
if($archiv != "" && $envioarchivo == 1) {
$extensiones = explode(".",$archiv_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "zip") { $error = "S�lo se permiten archivos .zip<br>" ; }

if($archiv_size > 250000) { $error= "El archivo debe pesar menos de 250 Kb.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
}
copy($archiv,"$archivo.zip") ;
}
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Editar 
        un comentario</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">
        <?
if($borrare) {
?>* Archivo borrado y Comentario modificado satisfactoriamente, <a href="administrar.php">pulsa aqui</a><?
}
else 
{ 
?>* Comentario modificado satisfactoriamente, <a href="administrar.php">pulsa aqui</a><?
} 
?>
      </div></td>
  </tr>
</table>
<?
}
}
}
}
?>
<br>
<?
if ($borrar != "") {
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> Borrar 
        un archivo</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method=post action='administrar.php?action=borrar&archivo=<? echo $borrar ?>' id=form1 name=form1 enctype="multipart/form-data">
          Se dispone a borrar el siguiente archivo, para confirmar la accion intruduzca 
          la contrase&ntilde;a y pulse enviar.<br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
          <br>
          Nombre del archivo:<br>
          <input name='archivo' type='text' class='form' value="<? echo $borrar ?>" size="33" readonly>
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $_POST['archivo'];
}
else if($action == "borrar")
{
if ($contrasena != "123456") { exit; }{ 
if(isset($archivo)&&isset($contrasena)&&($archivo!="")&&($contrasena!=""))
{
// se borra el archivo
unlink("$archivo.txt") ;
// se borra los posibles restos del archivo, como su contrase�a, comentario, lecturas, zip y clicks en el zip
// a los cuales le ponemos una @ para que no muestre el error en pantalla
@unlink("$archivo.php") ;
@unlink("$archivo.dat") ;
@unlink("$archivo.zip.dat") ;
@unlink("$archivo.zip") ;
@unlink("$archivo.php") ;
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Borrar 
        un archivo</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
        Archivo borrado satisfactoriamente, <a href="administrar.php">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
?>
<br>
<?
if ($renombrar != "") {
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="2" align="center" class="tabla_subtitulo"><div align="left"> Renombrar 
        un archivo</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="1" colspan="2" align="center" class="tabla_mensaje"><div align="left"> 
        <form method=post action='administrar.php?action=renombrar&archivo=<? echo $renombrar ?>' id=form1 name=form1 enctype="multipart/form-data">
          Se dispone a renombrar el siguiente archivo, para confirmar la accion 
          intruduzca la contrase&ntilde;a y pulse enviar.<br>
          <br>
          Contrase&ntilde;a :<br>
          <input name='contrasena' type='text' class='form' id="contrasena">
          <br>
          Nombre del archivo antiguo:<br>
          <input name='archivo' type='text' class='form' value="<? echo $renombrar ?>" size="33" readonly="">
          <br>
          Nuevo nombre:<br>
          <input name='nuevo' type='text' class='form' size="33">
          <br>
          <input type='submit' name='enviar' value='Enviar' class='form'>
        </form>
      </div></td>
  </tr>
</table>
<?
$archivo = $_POST['archivo'];
$nuevo = $_POST['nuevo'];
}
else if($action == "renombrar")
{
if ($contrasena != "123456") { exit; }{ 
if(isset($archivo)&&isset($contrasena)&&isset($nuevo)&&($archivo!="")&&($contrasena!="")&&($nuevo!=""))
{
// renombramos el documento de texto por otro nombre
rename("$archivo.txt", "$nuevo.txt");
// ronombramos el resto de archivos
@rename("$archivo.dat", "$nuevo.dat");
@rename("$archivo.zip.dat", "$nuevo.zip.dat");
@rename("$archivo.zip", "$nuevo.zip");
@rename("$archivo.php", "$nuevo.php");
?>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="97%" height="29" align="center" class="tabla_subtitulo"><div align="left">Renombrar 
        un archivo</div></td>
    <td width="3%" align="center" class="tabla_subtitulo"><a href="administrar.php">x</a></td>
  </tr>
  <tr> 
    <td height="2" colspan="2" align="center" class="tabla_mensaje"><div align="left">* 
        Archivo renombrado satisfactoriamente, <a href="administrar.php">pulsa aqui</a></div></td>
  </tr>
</table>
<?
}
}
}
?>

