<?
/*
+---------------------+
| Referers PHP Script |
+---------------------+
Autor: Gohrum
Email: webmaster@clangatsu.com
Web:   http://www.gatsu-studios.tk
*/

//--------CONFIGURACI�N----------
$host = "localhost";            //suele ser localhost
$user = "***";         //nombre de usuario de la base de datos
$pass = "***";      //contrase�a de la base de datos
$dbname = "***"; //nombre de la base de datos (en lycos es nombre_es_db)
$tabla = "gts_referer";        //nombre de la tabla que hemos creado
$mostrar = 50;             //n�mero de referers a mostrar
//------FIN CONFIGURACI�N--------


$conecta = mysql_connect($host,$user,$pass);
mysql_select_db($dbname,$conecta);
echo "
<table width='100%' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td width='5%'><b>#</b></td>
    <td width='75%'><div align='left'><b>Link</b></div></td>
    <td width='20%'><div align='right'><b>Visitas</b></div></td>
  </tr> ";


$query = "select * from $tabla order by fecha desc";
$resp = mysql_query($query);
$xcontador = 1;
while ($datos = mysql_fetch_array($resp)) 
{ 
while ($datos = mysql_fetch_array($resp))
{
  $dia = date("d/m/Y",$datos[fecha]); //nos muestra la fecha
  $hora = date("H:i:s",$datos[fecha]); //nos muestra la hora
  if ($mostrar > 0)
  {
    echo "
	<tr>
  		<td >$xcontador</td>
    	<td ><div align='left'><a href=\"$datos[referer]\" target=\"_blank\">$datos[referer]</a></div></td>
    	<td ><div align='right'>$dia<br>$hora</div><hr></td>
  		</tr>
		
	";
    $mostrar--;
    $xcontador++;
	} 
	 
  }
}
echo "</table>
		<hr>
	  <div align='center'>Gts_Ref v1.1Creado por <a href='http://www.gatsu-studios.tk' target='_blanck'>Gatsu Studios</a> :: </div>"; 
mysql_close($conecta); //cierra la conexion
?>