<?
/*
+---------------------+
| Referers PHP Script |
+---------------------+
Autor: Gohrum
Email: webmaster@clangatsu.com
Web:   http://www.gatsu-studios.tk
*/

//--------CONFIGURACI�N----------
$host = "localhost";            //suele ser localhost
$user = "***";         //nombre de usuario de la base de datos
$pass = "***";      //contrase�a de la base de datos
$dbname = "***"; //nombre de la base de datos (en lycos es nombre_es_db)
$tabla = "gts_referer";        //nombre de la tabla que hemos creado
//------FIN CONFIGURACI�N--------

$conecta = mysql_connect($host,$user,$pass);
mysql_select_db($dbname,$conecta);

$time = time(); //establecemos el tiempo actual para la fecha
$ref=$HTTP_REFERER; //pasamos el referer a la variable $ref

if ($ref!="") //validamos el referer
{
  $query = "insert into $tabla (fecha, referer) values ('$time', '$ref')";
  mysql_query($query); //insertamos el dato
  mysql_close($conecta); //cierra la conexion
}

?>

