<?
############################################
#  Filename   : INSTALL.PHP                #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

error_reporting(E_ALL);
include("config.php");
?>

<link rel="stylesheet" content="text/css" href="style.css">
<center><img src="images/logo.jpg"></center>

<title>XDT Topsite Installation File</title>

<center>
  <table cellpadding="2" cellspacing="0" width="75%" align=center>
    <tr>
      <td><br><hr style="border-style: dashed"><br></td>
    </tr>
  </table>

<?
if(!isset($_POST['submit']) AND !isset($_POST['install']))
{
?>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center">S e l e c t - L a n g u a g e</td>
    </tr>
    <tr>
      <td width="100%"><center>
      <form method="POST"><br>Select your language:<br>
      <input type="hidden" name="submit" value="1">
      <select name="language">

<?
	$handle = opendir('languages');

	while(false !== ($file = readdir($handle)))
	{
		if($file != "." && $file != "..")
		{
			echo "<option value=\"$file\">$file</option>\n";
		}
	}

	closedir($handle);
?>

      </select><br><br>
      <input type="submit" value="Next Step"></form>
      </center>
      </td>
    </tr>
  </table>
</center>

<?
}

if(isset($_POST['submit']))
{
	include("languages/" . $_POST['language'] . "");

	$installed = @mysql_result(mysql_query("SELECT * FROM ". $table ."_sites"),0);

	if(isset($installed) AND !isset($_POST['install']))
	{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['70'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['71'] . "<br><br><a href=\"index.php\">" . $text['63'] . " >></a>"; ?>
    </td>
  </tr>
</table>

<?
	}

	if(!isset($installed) AND !isset($_POST['install']))
	{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['70'] ?></td>
  </tr>
  <tr>
    <td width="100%">
        <form method="POST">
        <input type="hidden" name="install" value="1">
        <input type="hidden" name="language" value="<? echo $_POST['language'] ?>">
        <table class="content" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%">
          <tr>
            <td width="50%" align="right"><? echo $text['108'] ?> :</td>
            <td width="50%"><input type="text" name="top_name" size="25" maxlength="50"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['120'] ?> :</td>
            <td width="50%"><input type="text" name="web_mail" size="25" maxlength="100"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['121'] ?> :</td>
            <td width="50%"><input type="text" name="web_url" size="25" maxlength="100"></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['109'] ?> :</td>
            <td width="50%"><input type="text" name="top_script" size="25" maxlength="100" value="http://"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['110'] ?> :</td>
            <td width="50%"><input type="text" name="top_imgdir" size="25" maxlength="125" value="http://"></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['111'] ?> :</td>
            <td width="50%"><input type="text" name="top_totbut" size="4" maxlength="5"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['112'] ?> :</td>
            <td width="50%"><select name="top_butext">
            <option value=".gif">.gif</option>
            <option value=".png">.png</option>
            <option value=".jpg">.jpg</option>
            <option value=".jpeg">.jpeg</option>
            <option value=".bmp">.bmp</option>
            </select></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['113'] ?> :</td>
            <td width="50%"><input type="text" name="top_vis" size="4" maxlength="5"></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['114'] ?> :</td>
            <td width="50%"><input type="text" name="top_pp" size="4" maxlength="3"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['122'] ?> :</td>
            <td width="50%"><select name="top_lang">

<?
		$handle = opendir('languages');

		while(false !== ($file = readdir($handle)))
		{
			if($file != "." && $file != "..")
			{
				echo "<option value=\"$file\">$file</option>\n";
			}
		}

		closedir($handle);
?>

            </select></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['115'] ?> :</td>
            <td width="50%"><select name="top_mail">
            <option value="1" selected><? echo $text['43'] ?></option>
            <option value="0"><? echo $text['44'] ?></option>
            </select>
          </tr>
          <tr>
            <td width="50%" align="right">&nbsp;</td>
            <td width="50%">&nbsp;</td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['116'] ?> :</td>
            <td width="50%"><input type="text" name="adm_user" size="10" maxlength="25"></td>
          </tr>
          <tr>
            <td width="50%" align="right"><? echo $text['117'] ?> :</td>
            <td width="50%"><input type="password" name="adm_pass" size="10" maxlength="25"></td>
          </tr>
          <tr>
            <td width="50%" align="right">&nbsp;</td>
            <td width="50%">&nbsp;</td>
          </tr>
          <tr>
            <td width="100%" align="right" colspan="2">
            <p align="center"><input type="submit" value="<? echo $text['41'] ?>">
            <input type="reset" value="<? echo $text['118'] ?>"></td>
          </tr>
        </table>
        </center>
      </div>
      </td>
    </tr>
  </table>
</center>

<?
	}
}

if(isset($_POST['install']))
{
	include("languages/" . $_POST['language'] . "");
?>

  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['70'] ?></td>
    </tr>
    <tr>
      <td width="100%">

<?
	if($_POST['top_name'] AND $_POST['web_url'] AND $_POST['top_name'] AND $_POST['top_script'] AND $_POST['top_lang'] AND $_POST['top_imgdir'] AND $_POST['top_totbut'] AND $_POST['top_butext'] AND $_POST['top_mail'] AND $_POST['top_vis'] AND $_POST['top_pp'] AND $_POST['adm_user'] AND $_POST['adm_pass'])
	{
		mysql_query("CREATE TABLE " . $table . "_sites (memberid int(10) unsigned NOT NULL auto_increment,
		sitename varchar(50) default 0,	url varchar(100) default 0, buttonurl varchar(125) default 0,
		email varchar(75) default 0, description blob, password varchar(32) default 0,
		hitsin int(10) unsigned NOT NULL default 0, clicksin int(10) unsigned NOT NULL default 0,
		hitsout int(10) unsigned NOT NULL default 0, hitstotal int(10) unsigned NOT NULL default 0,
		hitstoday varchar(21) NOT NULL default 0, date varchar(21) NOT NULL default 0,
		register_date DATE default '0000-00-00' NOT NULL, country char(3) default 'oth',
		passreset varchar(12) default NULL, passreset2 varchar(12) default NULL,
		rank int(11) unsigned NOT NULL default 0, ip varchar(20) default '0.0.0.0',
		PRIMARY KEY (memberid))") or die(mysql_error());

		mysql_query("CREATE TABLE " . $table . "_config (webmaster_email char(100) default '0',
		webmaster_url char(100) default '0', topsite_name char(50) default '0',
		script_url char(100) default '0', lang_file char(25) default '0', img_dir char(125) default '0',
		img_total int(5) default '0', img_ext char(5) default '0', img_visible int(5) unsigned default '0',
		per_page int(3) unsigned default '0', date_display char(5) default '0',
		smile_description int(1) unsigned default '0', smile_comments int(1) unsigned default '0',
		webmaster_sendmail int(1) unsigned default '0', admin_user char(25) default '0',
		admin_pass char(25) default '0', admin_prefix char(100) default '0')") or die(mysql_error());

		mysql_query("INSERT INTO " . $table . "_config VALUES ('" . $_POST['web_mail'] . "',
		'" . $_POST['web_url'] . "', '" . $_POST['top_name'] . "', '" . $_POST['top_script'] . "',
		'" . $_POST['top_lang'] . "', '" . $_POST['top_imgdir'] . "', '" . $_POST['top_totbut'] . "',
		'" . $_POST['top_butext'] . "', '" . $_POST['top_vis'] . "', '" . $_POST['top_pp'] . "', 'd M Y', 1, 1,
		'" . $_POST['top_mail'] . "', '" . $_POST['adm_user'] . "', '" . $_POST['adm_pass'] . "',
		'<br>Powered by : <a href=\"http://www.xdt.nl.tt/\" target=\"_blank\">XDT Gold v1.1</a>')")
		or die(mysql_error());

		mysql_query("CREATE TABLE " . $table . "_comments (comment_id int(10) unsigned NOT NULL auto_increment,
		site_id int(10) unsigned NOT NULL default '0', name varchar(50) default NULL,
		email varchar(125) default NULL, website varchar(100) default NULL, comment blob, ip varchar(20) default '0',
		PRIMARY KEY (comment_id))") or die(mysql_error());

		mysql_query("CREATE TABLE " . $table . "_rate (site_id int(10) NOT NULL auto_increment,
		total int(10) default '0', votes int(10) default '0', PRIMARY KEY (site_id))") or die(mysql_error());

		mysql_query("CREATE TABLE " . $table . "_smiles (id int(10) unsigned NOT NULL auto_increment,
		name char(50) default '0', tag char(6) default '0', smile char(50) default '0', PRIMARY KEY (id))")
		or die(mysql_error());

		mysql_query("INSERT INTO " . $table . "_smiles VALUES('1', 'Amazed', ':o', 'amazed.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('2', 'Amuse', '^_^', 'amuse.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('3', 'Big Smile', ':D', 'bigsmile.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('4', 'Blink', 'o_O', 'blink.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('5', 'Cheesy', ':P', 'cheesy.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('6', 'Confused', ':S', 'confused.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('7', 'Cool', '8)', 'cool.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('8', 'Cry', ':\'(', 'cry.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('9', 'Evil', '>8(', 'evil.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('10', 'Laugh', '=D', 'laugh.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('11', 'Mad', ':@', 'mad.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('12', 'No Trust', '=/', 'notrust.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('13', 'No Worry', 'v_v', 'noworry.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('14', 'Nuts', '8D', 'nuts.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('15', 'Oh', '\'_\'', 'oh.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('16', 'Push', '>_<', 'push.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('17', 'Rolleyes', ':roll:', 'rolleyes.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('18', 'Sad', ':(', 'sad.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('19', 'Shy', ':$', 'shy.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('20', 'Sick', ':x', 'sick.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('21', 'Smile', ':)', 'smile.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('22', 'Suspicious', '�_�', 'suspicious.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('23', 'Unsure', '�_�', 'unsure.gif')");
		mysql_query("INSERT INTO " . $table . "_smiles VALUES('24', 'Wink', ';)', 'wink.gif')");

		echo $text['69'] . " !<br><br><a href=\"index.php\">" . $text['63'] . " >></a>";

		unlink("install.php");
	}
	else
	{
		echo $text['124'] . "!<br><br><a href=\"javascript:history.go(-1)\"><< " . $text['20'] . "</a>";
	}
?>

      </td>
    </tr>
  </table>
</center>

<?
}
?>

  <table cellpadding="2" cellspacing="0" width="75%" align=center>
    <tr>
      <td><br><hr style="border-style: dashed"></td>
    </tr>
  </table>

<?
$time = $debug->endTimer();

echo "<br><center>Powered by <a href=\"http://www.xdt.nl.tt/\" target=\"_blank\">XDT Gold v1.1</a></center>";
echo "<center>Parsed in : " . $time . " seconds.</center>";
?>