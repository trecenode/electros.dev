<?
############################################
#  Filename   : LOSTCODE.PHP               #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo $text['143'] ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
</head>

<body>
<center><img src="images/logo.jpg"><br></center>

<?
if(file_exists("install.php"))
{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%" align="center"><hr style="border-style: dashed">
    <a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
    <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
    <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
    <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
    <a href="lostcode.php"><font class="active"><? echo $text['6'] ?></font></a>&nbsp;-&nbsp;
    <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
    <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"><br></td>
  </tr>
</table>

<?
	// Form to fill in site ID
	if(!isset($_POST['submit']))
	{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <form method="POST">
    <input type="hidden" name="submit" value="1">
    <td width="100%" colspan="2" align="center"><? echo $text['85'] ?></td>
  </tr>
  <tr>
    <td width="50%"><p align="center"><? echo $text['83'] ?> :</td>
    <td width="50%"><input type="text" name="id" size="20"></td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><p align="center"><input type="submit" value="<? echo $text['84'] ?>"></td>
  </tr>
</table>

<?
	}

	// If form has been submitted
	if(isset($_POST['submit']))
	{
		// Check if the entered value is numeric
		if(!is_numeric($_POST['id']))
		{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['85'] ?></td>
  </tr>
  <tr class="content">
    <td width="100%"><? echo $text['86'] ?> ...<br><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
		}
		else
		{		
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['85'] ?></td>
  </tr>
  <tr class="content">
    <td width="100%" align="center"><? echo $text['81'] ?> :<br>
    <textarea rows="6" cols="45" onclick="this.select()"><a href="<? echo $script_url ?>/index.php?id=<? echo $_POST['id'] ?>" target="_blank"><img src="<? echo $script_url ?>/img.php?id=<? echo $_POST['id'] ?>" border="0"></a></textarea><br>
    <a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
		}
	}
}
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>


</body>
</html>