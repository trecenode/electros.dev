<?
############################################
#  Filename   : OUT.PHP                    #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

require("config.php");

$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'");
$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'"),0);

if($result)
{
	$hitsout = "UPDATE " . $table . "_sites SET hitsout = hitsout + 1, hitstotal = hitstotal + 1 WHERE memberid = '" . $_GET['id'] . "'";

	$date = date("dmY");

	while($row = mysql_fetch_assoc($query))
	{
		$today = $row['hitstoday'];
		$today = explode(" | ",$today);

		$datetoday = $today[0];
		$hitstoday = $today[1];
		$hitsplus = $today[1] + 1;

		if($date != $datetoday)
		{
			$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | 1' WHERE memberid = '" . $_GET['id'] . "'";
		}
		else
		{
			$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | " . $hitsplus . "' WHERE memberid = '" . $_GET['id'] . "'";
		}

		$days = $row['date'];
		$days = explode(" | ",$days);

		$daytoday = $days[0];
		$dayplus = $days[1] + 1;

		$update2 = "UPDATE " . $table . "_sites SET date = '" . $date . " | " . $dayplus . "' WHERE memberid = '" . $_GET['id'] . "'";

		function dohits()
		{
			global $hitsout,$update,$update2,$date,$daytoday;

			mysql_query($hitsout) or die(mysql_error());
			mysql_query($update) or die(mysql_error());

			if($date != "$daytoday")
			{
				mysql_query($update2) or die(mysql_error());
			}
		}

		dohits();

		header("Location: " . $row['url'] . "");
	}
}
else
{
	echo "This ID doesn't exist.<br><br><a href=\"". $script_url ."/index.php\"><< Return to topsite</a>";
}
?>