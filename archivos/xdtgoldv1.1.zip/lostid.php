<?
############################################
#  Filename   : LOSTID.PHP                 #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )"; ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
</head>

<body>

<center><img src="images/logo.jpg"><br></center>

<?
if(file_exists("install.php"))
{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{
?>

<center>
  <table cellpadding="0" cellspacing="0" width="75%">
    <tr>
      <td width="100%"><hr style="border-style: dashed">
      <center><a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
      <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
      <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
      <a href="lostid.php"><font class="active"><? echo $text['5'] ?></font></a>&nbsp;-&nbsp;
      <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
      <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
      <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"></center></td>
    </tr>
  </table>
</center>

<?
	if(!isset($_POST['submit']))
	{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <form method="POST">
      <input type="hidden" name="submit" value="1">
      <td width="100%" colspan="2"><p align="center"><? echo $text['87'] ?></td>
    </tr>
    <tr>
      <td width="50%"><p align="center"><? echo $text['37'] ?> / <? echo $text['36'] ?>:</td>
      <td width="50%"><input type="text" name="searchthis" size="30"></td>
    </tr>
    <tr>
      <td width="100%" colspan="2"><p align="center"><input type="submit" value="<? echo $text['88'] ?>"></td>
    </tr>
  </table>
</center>

<?
	}
	if(isset($_POST['submit']))
	{
		if(empty($_POST['searchthis']))
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['87'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['89'] ?> ...<br><br>
      <a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
		}
		else
		{
			$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE url LIKE '%" . $_POST['searchthis'] . "%' OR sitename LIKE '%" . $_POST['searchthis'] . "%' ORDER BY memberid ASC");
			$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE url LIKE '%" . $_POST['searchthis'] . "%' OR sitename LIKE '%" . $_POST['searchthis'] . "%'"),0);

			if(!$result)
			{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['87'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['90'] ?> : <b><? echo $_POST['searchthis'] ?></b><br><br>
      <a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
			}
			else
			{
?>

<center><br>
<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
  <tr class="title">
    <td width="10%"><p align="center"><? echo $text['28'] ?></td>
    <td width="45%"><p align="center"><? echo $text['30'] ?></td>
    <td width="45%"><p align="center"><? echo $text['31'] ?></td>
  </tr>

<?
				while($row = mysql_fetch_assoc($query))
				{
?>

  <tr>
    <td width="10%"><p align="center"><? echo $row['memberid'] ?></td>
    <td width="45%"><p align="center"><? echo htmlspecialchars($row['sitename']) ?></td>
    <td width="45%"><p align="center"><? echo htmlspecialchars($row['url']) ?></td>
  </tr>

<?
				}
?>

</table><br>
<a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></center>

<?
			}
		}
	}
}
?>

  <table cellpadding="0" cellspacing="0" width="75%" align="center">
    <tr>
      <td width="100%"><br><hr style="border-style: dashed"></td>
    </tr>
  </table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>