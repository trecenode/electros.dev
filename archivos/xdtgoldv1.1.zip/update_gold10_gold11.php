<?
############################################
#  Filename   : UPDATE_GOLD10_GOLD11.PHP   #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

error_reporting("E_ALL");
include("config.php");
?>

<title>Update XDT Gold v1.0 -> XDT Gold v1.1</title>
<link rel="stylesheet" content="text/css" href="style.css">
<center><img src="images/logo.jpg"></center>

<?
if(!isset($_POST['update']) AND !isset($_GET['finish']))
{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center">Confirm Update</td>
    </tr>
    <tr>
      <td width="100%" align="center"><br>Your about to upgrade your topsite from XDT Gold v1.0 to XDT Gold v1.1<br><br>
      Make sure you entered all data in CONFIG.PHP correct and we recommend you to make a backup from your MySQL database
      of your topsite !<br><br>
      <form method="POST">
      <input type="hidden" value="1" name="update">
      <input type="submit" value="Continue..."><br><br></td>
    </tr>
  </table>
</center>

<?
}

if(isset($_POST['update']))
{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center">Updating...</td>
    </tr>
    <tr>
      <td width="100%" align="center">
<?
	mysql_query("ALTER TABLE " . $table . " RENAME " . $table . "_sites") or die(mysql_error());
	mysql_query("ALTER TABLE " . $table . "_sites ADD country CHAR(3) DEFAULT 'oth' AFTER register_date") or die(mysql_error());
	mysql_query("ALTER TABLE " . $table . "_sites ADD ip CHAR(20) DEFAULT '0.0.0.0'") or die(mysql_error());

	mysql_query("ALTER TABLE " . $table . "_config ADD date_display CHAR(5) DEFAULT 'd M y' AFTER per_page") or die(mysql_error());
	mysql_query("ALTER TABLE " . $table . "_config ADD smile_description INT(1) UNSIGNED DEFAULT '0' AFTER date_display") or die(mysql_error());
	mysql_query("ALTER TABLE " . $table . "_config ADD smile_comments INT(1) UNSIGNED DEFAULT '0' AFTER smile_description") or die(mysql_error());
	mysql_query("ALTER TABLE " . $table . "_config ADD admin_prefix CHAR(100) DEFAULT '0'") or die(mysql_error());

	mysql_query("CREATE TABLE " . $table . "_comments (comment_id int(10) unsigned NOT NULL auto_increment,
	site_id int(10) unsigned NOT NULL default '0', name varchar(50) default NULL,
	email varchar(125) default NULL, website varchar(100) default NULL, comment blob, ip varchar(20) default '0',
	PRIMARY KEY (comment_id))") or die(mysql_error());

	mysql_query("CREATE TABLE " . $table . "_rate (site_id int(10) NOT NULL auto_increment,
	total int(10) default '0', votes int(10) default '0', PRIMARY KEY (site_id))") or die(mysql_error());

	mysql_query("CREATE TABLE " . $table . "_smiles (id int(10) unsigned NOT NULL auto_increment,
	name char(50) default '0', tag char(6) default '0', smile char(50) default '0', PRIMARY KEY (id))")
	or die(mysql_error());

	mysql_query("INSERT INTO " . $table . "_smiles VALUES('1', 'Amazed', ':o', 'amazed.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('2', 'Amuse', '^_^', 'amuse.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('3', 'Big Smile', ':D', 'bigsmile.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('4', 'Blink', 'o_O', 'blink.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('5', 'Cheesy', ':P', 'cheesy.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('6', 'Confused', ':S', 'confused.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('7', 'Cool', '8)', 'cool.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('8', 'Cry', ':\'(', 'cry.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('9', 'Evil', '>8(', 'evil.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('10', 'Laugh', '=D', 'laugh.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('11', 'Mad', ':@', 'mad.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('12', 'No Trust', '=/', 'notrust.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('13', 'No Worry', 'v_v', 'noworry.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('14', 'Nuts', '8D', 'nuts.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('15', 'Oh', '\'_\'', 'oh.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('16', 'Push', '>_<', 'push.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('17', 'Rolleyes', ':roll:', 'rolleyes.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('18', 'Sad', ':(', 'sad.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('19', 'Shy', ':$', 'shy.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('20', 'Sick', ':x', 'sick.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('21', 'Smile', ':)', 'smile.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('22', 'Suspicious', '�_�', 'suspicious.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('23', 'Unsure', '�_�', 'unsure.gif')");
	mysql_query("INSERT INTO " . $table . "_smiles VALUES('24', 'Wink', ';)', 'wink.gif')");

	mysql_query("UPDATE " . $table . "_config SET admin_prefix = '<br>Powered by : <a href=\"http://www.xdt.nl.tt/\" target=\"_blank\">XDT Gold v1.1</a>'") or die(mysql_error());

	$query = mysql_query("SELECT * FROM " . $table . "_sites");

	while($row = mysql_fetch_assoc($query))
	{
		mysql_query("INSERT INTO " . $table . "_rate VALUES ('" . $row['memberid'] . "','0','0')") or die(mysql_error());
	}
?>
      Topsite has successfully been updated...<br><br>
      You can now delete this file and go to your updated topsite !<br><br>
      Delete INSTALL.PHP, UPDATE_GOLD10_GOLD11.PHP and LOGO.JPG from your topsite directory.
      <a href="index.php">Go to your topsite >></a>
      </td>
    </tr>
  </table>
</center>

<?
}
?>