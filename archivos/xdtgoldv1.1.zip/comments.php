<?
############################################
#  Filename   : COMMENTS.PHP               #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo $text['143'] ?></title>
<link rel="stylesheet" content="text/css" href="style.css">

<script language="JavaScript">
function addsmile(emoticon)
{
	form.comment.value += " " + emoticon ;
}
</script>
</head>

<body>
<?
// Check if the installation file still is located in the topsites directory
if(file_exists("install.php"))
{ // If it is... give error
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{ // Else start executing the script
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><center><font style="font-size: 24pt; font-weight: bold"><? echo $text['144'] ?></font></td>
  </tr>
<?
	// If the command for checking stats is triggered
	if(isset($_GET['id']) AND !isset($_POST['submit']) AND !isset($_GET['action']))
	{
		$query = mysql_query("SELECT * FROM " . $table . "_comments WHERE site_id = '" . $_GET['id'] . "' ORDER BY comment_id DESC");
		$total = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_comments WHERE site_id = '" . $_GET['id'] . "'"),0);
?>
  <tr>
    <td colspan="2" align="center"><hr style="border-style: dashed">[ <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=new&site_id=<? echo $_GET['id'] . "\"> " . $text['149'] ?></a> ] &nbsp; [ <a href="javascript:window.close()"><? echo $text['142'] ?></a> ]</td>
  </tr>
<?
		// Check if site has comments
		if(empty($total))
		{
?>
  <tr>
    <td colspan="2" align="center"><br><br><? echo $text['155'] ?></td>
  </tr>
<?
		}
		else
		{
			// Selecting site information from database
			while($row = mysql_fetch_assoc($query))
			{
?>
  <tr>
    <td colspan="2"><hr style="border-style: dashed"></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['145'] ?> :</td>
    <td width="65%"><? echo htmlspecialchars($row['name']) ?></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['39'] ?> :</td>
    <td width="65%"><? echo htmlspecialchars($row['email']) ?></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['37'] ?> :</td>
    <td width="65%"><a href="<? echo htmlspecialchars($row['website']) ?>"><? echo htmlspecialchars($row['website']) ?></a></td>
  </tr>
  <tr>
    <td width="35%" valign="top"><? echo $text['144'] ?> :</td>
    <td width="65%"><?
				$row['comment'] = htmlspecialchars($row['comment']);

				// Checking for smile usage
				if(!empty($smile_com))
				{
					$query2 = mysql_query("SELECT * FROM " . $table . "_smiles");

					while($row2 = mysql_fetch_assoc($query2))
					{
						$row2['tag'] = str_replace(">","&gt;", $row2['tag']);
						$row2['tag'] = str_replace("<","&lt;", $row2['tag']);

						$row['comment'] = str_replace("$row2[tag]","<img src=\"images/smiles/" . $row2['smile'] . "\">", $row['comment']);
					}
				}

				// New line after 30 characters
				$row['comment'] = wordwrap($row['comment'], 30, "\t", 1);

				// Replace blank lines with <br>
				$row['comment'] = str_replace("\n","    <br>", $row['comment']);

				echo "    " . $row['comment'];
?></td>
  </tr>

<?
			}
			echo "  </table>";
		}
	}

	// Form to submit a new comment
	if(!isset($_POST['submit']) AND isset($_GET['action']))
	{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <form method="POST" name="form">
  <input type="hidden" value="1" name="submit">
  <input type="hidden" value="<? echo $_GET['site_id'] ?>" name="site_id">
  <tr>
    <td colspan="2"><hr style="border-style: dashed"><br></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['145'] ?> :</td>
    <td width="65%"><input type="text" name="name" maxlength="75"></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['39'] ?> :</td>
    <td width="65%"><input type="text" name="email" maxlength="125"></td>
  </tr>
  <tr>
    <td width="35%"><? echo $text['37'] ?> :</td>
    <td width="65%"><input type="text" name="website" maxlength="100"></td>
  </tr>
  <tr>
    <td width="35%" valign="top"><? echo $text['144'] ?> :</td>
    <td width="65%"><textarea name="comment" cols="25" rows="5"></textarea></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><?

		// Selecting smile from database
		$query = mysql_query("SELECT * FROM " . $table . "_smiles ORDER BY id ASC");

		echo "\n";

		while($row = mysql_fetch_assoc($query))
		{
			echo "    <a href=\"javascript:addsmile('" . addslashes($row['tag']) . "')\"><img src=\"images/smiles/" . $row['smile'] . "\" border=\"0\"></a>\n";
		}
?>    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" value="<? echo $text['146'] ?>">
    <input type="reset" value="<? echo $text['118'] ?>"></td>
  </tr>
</table>
<?
	}

	// When form for new comment has been submitted
	if(isset($_POST['submit']))
	{
		// If user has filled in NAME and COMMENT
		if($_POST['name'] AND $_POST['email'] AND $_POST['comment'])
		{ // Insert into database
			mysql_query("INSERT INTO " . $table . "_comments VALUES ('','" . $_POST['site_id'] . "','" . $_POST['name'] . "','" . $_POST['email'] . "','" . $_POST['website'] . "','" . $_POST['comment'] . "','" . $_ENV['REMOTE_ADDR'] . "')") or die(mysql_error());
?>
<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><hr style="border-style: dashed"><br></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><? echo $text['147'] ?> !<br><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?id=<? echo $_POST['site_id'] ?>"><? echo $text['152'] ?></a><br>
    <a href="javascript:window.close()"><? echo $text['142'] ?></a></td>
  </tr>
</table>
<?
		}
		else
		{ // Else give error
?>
<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><hr style="border-style: dashed"><br></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><? echo $text['148'] ?><br><br>
    <a href="javascript:history.go(-1)"><? echo $text['20'] ?></a></td>
  </tr>
</table>
<?
		}
	}
}
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>


</body>
</html>