<?
############################################
#  Filename   : EDIT.PHP                   #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Start session for login
session_start();

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )"; ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
<script language="JavaScript">
function addsmile(emoticon)
{
	form.description.value += " " + emoticon ;
}

function showimage()
{
	if(!document.images)return;
	document.images.icons.src="images/flags/"+document.form.country.options[document.form.country.selectedIndex].value;
}
</script>
</head>

<body>

<center><img src="images/logo.jpg"><br></center>

<?
// Check if the installation file still is located in the topsites directory
if(file_exists("install.php"))
{ // If it is... give error
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{ // Else start executing the script
?>

<center>
  <table cellpadding="0" cellspacing="0" width="75%">
    <tr>
      <td width="100%"><hr style="border-style: dashed">
      <center><a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
      <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
      <a href="<? echo $_SERVER['PHP_SELF'] ?>"><font class="active"><? echo $text['4'] ?></font></a>&nbsp;-&nbsp;
      <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
      <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
      <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
      <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"></center></td>
    </tr>
  </table>
</center>

<?
	// Login Part
	if(isset($_POST['submit']) AND !isset($_GET['edit']))
	{

		// Encrypted password (to check with password in database)
		$pass_encrypted = md5($_POST['pass']);

		$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_POST['id'] . "' AND password = '" . $pass_encrypted . "'");
		$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE memberid = '" . $_POST['id'] . "' AND password = '" . $pass_encrypted . "'"),0);

		if(!$result)
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['55'] ?> ...
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
		}
		else
		{
			// Selecting user ID from database
			while($row = mysql_fetch_assoc($query))
			{
				$memberid = $row['memberid'];
			}

			// Register sessions for login
			$_SESSION['inlog'] = 1;
			$_SESSION['memberid'] = $memberid;
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['56'] ?>.<br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>?edit=1"><? echo $text['57'] ?></a><br>
      <a href="<? echo $_SERVER['PHP_SELF'] ?>?logoff=1"><? echo $text['15'] ?></a></td>
    </tr>
  </table>
</center>

<?
		}
	}
	else
	{
		// User menu
		if(isset($_SESSION['inlog']) AND !isset($_GET['edit']) AND !isset($_POST['save']) AND !isset($_GET['logoff']))
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['56'] ?>.<br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>?edit=1"><? echo $text['57'] ?></a><br>
      <a href="<? echo $_SERVER['PHP_SELF'] ?>?logoff=1"><? echo $text['15'] ?></a></td>
    </tr>
  </table>
</center>

<?
		}
	}

	// Edit site info part
	if(isset($_SESSION['inlog']) AND isset($_GET['edit']) AND !isset($_POST['save']) AND !isset($_GET['logoff']))
	{
		$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_SESSION['memberid'] . "'");
		$result = mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites WHERE memberid = '" . $_SESSION['memberid'] . "'"),0);

		if($result)
		{
			while($row = mysql_fetch_assoc($query))
			{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
    <form method="POST" name="form">
    <input type="hidden" value="1" name="save">
      <td width="100%" colspan="2">
      <p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr>
      <td width="50%"><? echo $text['36'] ?> :</td>
      <td width="50%"><input type="text" name="sitename" size="24" value="<? echo htmlspecialchars($row['sitename']); ?>" maxlength="50"></td>
    </tr>
    <tr>
      <td width="50%"><? echo $text['37'] ?> :</td>
      <td width="50%"><input type="text" name="url" size="24" value="<? echo htmlspecialchars($row['url']); ?>" maxlength="100"></td>
    </tr>
    <tr>
      <td width="50%"><? echo $text['38'] ?> [ 88 x 31 ] :</td>
      <td width="50%"><input type="text" name="buttonurl" size="24" value="<? echo htmlspecialchars($row['buttonurl']); ?>" maxlength="125"></td>
    </tr>
    <tr>
      <td width="50%"><? echo $text['137'] ?> :</td>
      <td width="50%"><select name="country" onChange="showimage()"><?

				$handle = opendir('images/flags');
				while(false!==($file = readdir($handle)))
				{
					if($file != "." AND $file != "..")
					{
						if($file == "flag_" . $row['country'] . ".gif")
						{
							$selected = " selected";
						}
						else
						{
							$selected = "";
						}

						echo "<option value=\"" . $file . "\"" . $selected . ">" . $file . "</option>\n";
					}
				}

				closedir($handle);
?>
      </select><img src="images/flags/flag_<? echo $row['country'] ?>.gif" name="icons" border="1" hspace="10"></td>
    </tr>
    <tr>
      <td width="50%"><? echo $text['39'] ?> :</td>
      <td width="50%"><input type="text" name="email" size="24" value="<? echo htmlspecialchars($row['email']); ?>" maxlength="75"></td>
    </tr>
    <tr>
      <td width="50%" valign="top"><? echo $text['40'] ?> :<br><br><center><?

				$query2 = mysql_query("SELECT * FROM " . $table . "_smiles ORDER BY id ASC");

				while($row2 = mysql_fetch_assoc($query2))
				{
					echo "<a href=\"javascript:addsmile('" . addslashes($row2['tag']) . "')\"><img src=\"images/smiles/" . $row2['smile'] . "\" border=\"0\"></a> ";
				}
?><center></td>
      <td width="50%"><textarea rows="7" name="description" cols="35"><? echo htmlspecialchars($row['description']); ?></textarea></td>
    </tr>
    <tr>
      <td width="50%" valign="top"><? echo $text['22'] ?> ( <? echo ucfirst($text['58']) ?> ) :</td>
      <td width="50%"><input type="password" name="pssw" size="12" maxlength="25"></td>
    </tr>
    <tr>
      <td width="50%" valign="top"><? echo $text['22'] ?> [ <? echo $text['59'] ?> ]:</td>
      <td width="50%"><input type="password" name="pssw2" size="12" maxlength="25"></td>
    </tr>
    <tr>
      <td width="100%" valign="top" colspan="2">
      <p align="center"><input type="submit" value="<? echo $text['41'] ?>">
      <input type="reset" value="<? echo $text['118'] ?>"></td>
    </tr>
  </table>
</form>
</center>

<?
			}
		}
		else
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['60'] ?> ...</td>
    </tr>
  </table>
</center>

<?
		}
	}

	// Save site info
	if(isset($_POST['save']))
	{
		// Check if user is logged in
		if($_SESSION['memberid'])
		{

			$_POST['country'] = str_replace("flag_","", $_POST['country']);
			$_POST['country'] = str_replace(".gif","", $_POST['country']);

			// If password has to be changed..
			if($_POST['pssw'])
			{
				// Passwords are correct ?
				if($_POST['pssw'] != $_POST['pssw2'] OR !$_POST['pssw'] AND !$_POST['pssw2'])
				{

?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['61'] ?> ...
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
				}
				else
				{
					// Encrypted version of password
					$pssw_encrypted = md5($_POST['pssw']);

					// Update site info AND passwords
					mysql_query("UPDATE " . $table . "_sites SET sitename = '" . $_POST['sitename'] . "', url = '" . $_POST['url'] . "', buttonurl = '" . $_POST['buttonurl'] . "', email = '" . $_POST['email'] . "', description = '" . $_POST['description'] . "', country = '" . $_POST['country'] . "', password = '" . $pssw_encrypted . "' WHERE memberid = '" . $_SESSION['memberid'] . "'") or die(mysql_error());
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['62'] ?> ...
      <br><br><a href="index.php"><? echo $text['63'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
				}
			}
			else
			{
				// Update site
				mysql_query("UPDATE " . $table . "_sites SET sitename = '" . $_POST['sitename'] . "', url = '" . $_POST['url'] . "', buttonurl = '" . $_POST['buttonurl'] . "', email = '" . $_POST['email'] . "', description = '" . $_POST['description'] . "', country = '" . $_POST['country'] . "' WHERE memberid = '" . $_SESSION['memberid'] . "'") or die(mysql_error());
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['64'] ?> ...
      <br><br><a href="index.php"><? echo $text['63'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
			}
		}
		else
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['65'] ?> ...
      <br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>"><? echo $text['66'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
		}
	}

	// Log off part
	if(isset($_GET['logoff']))
	{
		// Un-register session
		unset($_SESSION['inlog']);
		unset($_SESSION['memberid']);
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['54'] ?></td>
    </tr>
    <tr class="content">
      <td width="100%"><? echo $text['48'] ?> ...
      <br><br><a href="index.php"><? echo $text['63'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
	}

	// Login form
	if(!isset($_SESSION['inlog']) AND !isset($_GET['logoff']) AND !isset($_POST['submit'])){
?>

  <center><br>
    <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <form method="POST">
    <input type="hidden" name="submit" value="1">
      <tr>
        <td width="100%" colspan="2" class="title"><p align="center"><? echo $text['54'] ?></td>
      </tr>
      <tr>
        <td width="50%"><p align="center"><? echo $text['67'] ?> :</td>
        <td width="50%"><input type="text" name="id" size="20"></td>
      </tr>
      <tr>
        <td width="50%"><p align="center"><? echo $text['22'] ?> :</td>
        <td width="50%"><input type="password" name="pass" size="12" maxlength="25">
        ( <a href="passreset.php"><? echo $text['68'] ?> ?</a> )</td>
      </tr>
      <tr>
        <td width="100%" colspan="2"><p align="center"><input type="submit" style="width: 75px" 
        value="<? echo $text['66'] ?>"></td>
      </tr>
    </table>
  </center>

<?
	}
}
?>

  <table cellpadding="0" cellspacing="0" width="75%" align="center">
    <tr>
      <td width="100%"><br><hr style="border-style: dashed"></td>
    </tr>
  </table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>


</body>
</html>