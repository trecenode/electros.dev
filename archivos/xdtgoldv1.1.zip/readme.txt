## ------------------------------------------------ ##
##                                                  ##
##                    XDT Readme                    ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##  Version  : Gold 1.1                             ##
##                                                  ##
##  Authors  : Dennis v/d Hout  (XdRaG00n/Sn03pz4k) ##
##             Vincent Schroers      (Chesta)       ##
##                                                  ##
##  Email    : xdt@scripters.nl      (MSN Too)      ##
##                                                  ##
##  Homepage : http://www.xdt.nl.tt                 ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                    Disclaimer                    ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
## You can put this script on every site you want,  ##
## but only for download. You may not edit the      ##
## sourcecode in case you haven't got permission    ##
## from the XDT Crew, you may edit the sourcede for ##
## YOUR topsite only and you're not allowed to put  ##
## that version on your site to download !          ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                      Updates                     ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
## Updates can be found at our website. (see above) ##
## We also have a forum where you can ask questions ##
## about this script                                ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                   Installation                   ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
## Upload the script to your server, you don't need ##
## to CHMOD any of the files because the script is  ##
## using a MySQL Database. After you've uploaded    ##
## the file to your server, go to :                 ##
##                                                  ##
##    http://www.yoursite.ext/topsite/install.php   ##
##                                                  ##
## And then follow the steps...                     ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                      Buttons                     ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
## Let's say you've got 100 buttons, upload them in ##
## a directory you named in the config. Also how    ##
## much buttons you've got, in this case 100. Then  ##
## make a button called DEFAULT.EXT for all the     ##
## sites who aren't ranked yet or if somebody's     ##
## rank is higher than how much buttons you have.   ##
## At last you have to upload a pic for if the      ##
## buttons aint working at all, call this picture   ##
## ERROR.EXT                                        ##
##                                                  ##
## ATTENTION : Your topsite buttons won't work on   ##
## hosts with no offsite-linking which means you    ##
## can't show buttons from the account on other     ##
## websites...                                      ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                     Features                     ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
## - Counts Hits in                                 ##
## - Counts Clicks in                               ##
## - Counts Hits uit                                ##
## - Counts Total hits                              ##
## - Calculates Average hits                        ##
## - Calculates Hits today                          ##
## - Members can easily edit their information, but ##
##   have to log in first                           ##
## - Img.php will take care of the buttons          ##
## - Members can retrieve their ID if they've       ##
##   forgot it                                      ##
## - Page navigation if your topsite gains members  ##
## - Members can change their password if they lost ##
##   it                                             ##
## - You can choose how much banners your topsite   ##
##   will show on the index                         ##
## - After joining the topsite there will be send   ##
##   an email to the webmaster of that website      ##
## - Nice installer                                 ##
## - Kewl admin :D                                  ##
## - footer.txt to add your own stats-counter       ##
##   to your topsite, and other things :)           ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##                       Bugs?                      ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##          http://www.scripters.nl/forum/          ##
##                                                  ##
## ------------------------------------------------ ##
##                                                  ##
##           Good luck with your topsite !          ##
##                                                  ##
##                     XDT Crew                     ##
##                                                  ##
## ------------------------------------------------ ##