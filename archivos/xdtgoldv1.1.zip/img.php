<?
############################################
#  Filename   : IMG.PHP                    #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Checking if site exists
$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'");
$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'"),0);

// If site exists update stats
if($result)
{
	// Current date
	$date = date("dmY");

	// Update query for HITS IN
	$hitsin = "UPDATE " . $table . "_sites SET hitsin = hitsin + 1, hitstotal = hitstotal + 1 WHERE memberid = '" . $_GET['id'] . "'";

	while($row = mysql_fetch_assoc($query))
	{
		$today = $row['hitstoday'];
		$today = explode(" | ",$today);

		$datetoday = $today[0];
		$hitstoday = $today[1];
		$hitsplus = $today[1] + 1;

		// If date isn't database is the same date of today
		if($date != $datetoday)
		{ // Hits today = 1
			$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | 1' WHERE memberid = '" . $_GET['id'] . "'";
		}
		else
		{ // Hits today = hitstoday + 1
			$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | " . $hitsplus . "' WHERE memberid = '" . $_GET['id'] . "'";
		}

		$days = $row['date'];
		$days = explode(" | ",$days);

		$daytoday = $days[0];
		$dayplus = $days[1] + 1;

		// Update query for date-field
		$update2 = "UPDATE " . $table . "_sites SET date = '" . $date . " | " . $dayplus . "' WHERE memberid = '" . $_GET['id'] . "'";

		// Function to update all stats
		function dohits()
		{
			global $hitsin,$update,$update2,$date,$daytoday;

			mysql_query($hitsin) or die(mysql_error());
			mysql_query($update) or die(mysql_error());

			if($date != "$daytoday")
			{
				mysql_query($update2) or die(mysql_error());
			}
		}

	// Rank, for the image to display
	$rank = $row['rank'];
	}

	// Execute query's to update stats
	dohits();

	// If there is a button to display for the current rank, show the rank picture (example : 5.jpg)
	if($rank < ($img_total + 1))
	{
		header("Location: " . $img_dir . "/" . $rank . "" . $img_ext . "");
	}
	else
	{ // Else display default picture
		header("Location: " . $img_dir . "/default" . $img_ext . "");
	}
}
else
{ // If there's an error with the banners show a buttons with an error message on it
	header("Location: " . $img_dir . "/error" . $img_ext . "");
}
?>