Here will be the pictures for the ranks with their numbers on it

rank 1 = 1.ext
rank 2 = 2.ext
rank 3 = 3.ext

etc....

if you only want 1 pic... upload default.ext to this directory and
edit your config file... also if you want to use more than 1 picture !

if you got 50 ranks you have to upload a default picture too for all ranks
lower than the amount of pictures you made for all ranks... call this extra
pic DEFAULT.EXT

also upload a picture called ERROR.EXT in case that the buttons aint working
at all

Your topsite buttons won't work on hosts with no offsite-linking which means
you can't show buttons from the account on other websites...