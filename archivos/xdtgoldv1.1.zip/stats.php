<?
############################################
#  Filename   : STATS.PHP                  #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

error_reporting(E_ALL);
session_start();
require("config.php");
include("languages/" . $lang_file);
?>

<link rel="stylesheet" content="text/css" href="style.css">

<?
if(file_exists("install.php"))
{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{
?>

<title>
<?
	echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )";
?>
</title>
<?
	if(isset($_GET['id']))
	{
		$query = mysql_query("SELECT *,hitstotal / (TO_DAYS(NOW())-TO_DAYS(register_date)+1) AS average FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'");
		$result = mysql_result(mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'"),0);

		if(!$result)
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['125'] ?> &nbsp;: &nbsp;<? echo $text['126'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['91'] ?> ...</td>
    </tr>
  </table>
</center>

<?
		}
		else
		{
			while($row = mysql_fetch_assoc($query))
			{
?>

<center>
  <table border="1" cellpadding="2" cellspacing="0" width="100%" class="content">
    <tr class="title">
      <td width="100%">
      <p align="center"><? echo $text['125'] ?> &nbsp;: &nbsp;<? echo $_GET['id'] ?></td>
    </tr>
    <tr>
      <td width="100%"><div align="center">
  <center>
  <table border="0" cellpadding="1" cellspacing="0" style="border-collapse: collapse" width="55%" class="content">
    <tr>
      <td width="100%" colspan="2">
      <p align="center"><b><? echo $text['127'] ?></b><hr style="border-style: dotted; border-width: 1"></td>
    </tr>
    <tr>
      <td width="50%">
      <p align="right"><? echo $text['36'] ?> :&nbsp;</td>
      <td width="50%" align="center">

<?
				if(strlen($row['sitename']) > 20) $row['sitename'] = substr($row['sitename'],0,20)."...";   

				echo htmlspecialchars($row['sitename']);
?>

      </td>
    </tr>
    <tr>
      <td width="50%">
      <p align="right"><? echo $text['37'] ?> :&nbsp;</td>
      <td width="50%" align="center"><a href="out.php?id=<? echo $row['memberid']; ?>" target="_blank">

<?
				if(strlen($row['url']) > 25) $row['url'] = substr($row['url'],0,25)."...";   

				echo htmlspecialchars($row['url']);
?>

      </a></td>
    </tr>

    <tr>
      <td width="50%">
      <p align="right"><? echo $text['137'] ?> :&nbsp;</td>
      <td width="50%" align="center"><img src="images/flags/flag_<? echo $row['country'] ?>.gif" border="1"></td>
    </tr>
    <tr>
      <td width="50%" valign="top">
      <p align="right"><? echo $text['136'] ?> :&nbsp;</td>
      <td width="50%" align="center">

<?
				if($row['buttonurl'])
				{
					echo "<img src=\"" . htmlspecialchars($row['buttonurl']) . "\" width=\"88\" height=\"31\">";
				}
				else
				{
					echo "[ NONE ]";
				}
?>

      </a></td>
    </tr>
    <tr>
      <td width="50%">&nbsp;</td>
      <td width="50%">&nbsp;</td>
    </tr>
    <tr>
      <td width="100%" colspan="2" align="center"><b><? echo $text['40'] ?></b><hr style="border-style: dotted; border-width: 1"></td>
    </tr>
    <tr>
      <td width="100%" colspan="2" align="center">

<?
			$row['description'] = htmlspecialchars($row['description']);

			$query2 = mysql_query("SELECT * FROM " . $table . "_smiles");

			while($row2 = mysql_fetch_assoc($query2))
			{
				$row2['tag'] = str_replace("<","&lt;", $row2['tag']);
				$row2['tag'] = str_replace(">","&gt;", $row2['tag']);
				$row['description'] = str_replace("$row2[tag]","<img src=\"images/smiles/" . $row2['smile'] . "\">", $row['description']);
			}

			$row['description'] = wordwrap($row['description'], 50, " ", 1);
			$row['description'] = str_replace("\n","<br>", $row['description']);

			echo $row['description'];

?>

      </td>
    </tr>
    <tr>
      <td width="100%" colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td width="100%" colspan="2" align="center"><b><? echo $text['17'] ?></b><hr style="border-style: dotted; border-width: 1"></td>
    </tr>
    <tr>
      <td width="50%" align="right">
      <p align="right"><? echo $text['128'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $row['hitsin'] ?></font></td>
    </tr>
    <tr>
      <td width="50%" align="right"><? echo $text['129'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $row['clicksin'] ?></font></td>
    </tr>
    <tr>
      <td width="50%" align="right"><? echo $text['130'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $row['hitsout'] ?></font></td>
    </tr>
    <tr>
      <td width="100%" align="right" colspan="2">&nbsp;</td>
    </tr>

<?
				$today = $row['hitstoday'];
				$today = explode(" | ",$today);
?>

    <tr>
      <td width="50%" align="right"><? echo $text['131'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $today[1] ?></font></td>
    </tr>
    <tr>
      <td width="50%" align="right"><? echo $text['132'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $row['hitstotal'] ?></font></td>
    </tr>
<?
				$days = explode(" | ",$row['date']);

				$row['average'] = str_replace(".",",", $row['average']);
?>
    <tr>
      <td width="50%" align="right"><? echo $text['133'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $row['average'] ?></font></td>
    </tr>
    <tr>
      <td width="50%" align="right"><? echo $text['134'] ?> :</td>
      <td width="50%"><font style="text-indent: 30"><? echo $days[1]; ?></font></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="100%" align="right" colspan="2">
      <p align="center"><b><? echo $text['105'] ?></b><hr style="border-style: dotted; border-width: 1"></td>
    </tr>
    <tr>
      <td width="100%" align="right" colspan="2">
      <h2 align="center">
<?
				if($row['rank'] == 1)
				{
					echo "<img src=\"images/rank1.gif\" width=\"30\" height=\"30\" border=\"0\">";
				}
				elseif($row['rank'] == 2)
				{
					echo "<img src=\"images/rank2.gif\" width=\"30\" height=\"30\" border=\"0\">";
				}
				elseif($row['rank'] == 3)
				{
					echo "<img src=\"images/rank3.gif\" width=\"30\" height=\"30\" border=\"0\">";
				}
				else
				{
					echo $row['rank'];
				}
?></td>
    </tr>
  </table>
  </td>
 </tr>
</table>
<br>

<?
			echo "<a href=\"javascript:window.close()\">" . $text['142'] . "</a>";
			}
		}
	}
	else
	{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['1'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['135'] ?> ...</td>
    </tr>
  </table>
</center>

<?
	}
}
?>