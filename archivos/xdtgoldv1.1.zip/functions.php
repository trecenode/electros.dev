<?
############################################
#  Filename   : FUNCTIONS.PHP              #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

class debug
{
	var $starttime;

	function debug()
	{
		$mtime = microtime ();
		$mtime = explode (' ', $mtime);
		$this->starttime = $mtime[1] + $mtime[0];
	}

	function endTimer()
	{
		$mtime = microtime ();
		$mtime = explode (' ', $mtime);
		$mtime = $mtime[1] + $mtime[0];
		$endtime = $mtime;
		$totaltime = round (($endtime - $this->starttime), 5);

		return $totaltime;
	}
}

$debug = new debug();
?>