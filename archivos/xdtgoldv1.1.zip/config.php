<?
############################################
#  Filename   : CONFIG.PHP                 #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

## ---------------------- ##
##                        ##
##       Edit Below       ##
##                        ##
## ---------------------- ##

// MySql Information ( Maybe you should contact your host about this information before you contact us )
$hostname = "localhost";
$username = "user";
$password = "pass";
$database = "topsite";

// The name of the table IN $database (tables look like this : xdt_sites, xdt_config if u use this value)
$table = "xdt";

## ---------------------- ##
##                        ##
##    Don't Edit Below    ##
##                        ##
## ---------------------- ##

// Connect to database
mysql_connect($hostname,$username,$password) or die(mysql_error());
mysql_select_db($database);

// Selecting the configuration info from the MySQL database
$query = mysql_query("SELECT * FROM " . $table . "_config");

// Making loop to select info for topsite configuration
while($row = @mysql_fetch_assoc($query))
{
	$webmaster_email = $row['webmaster_email'];
	$webmaster_url = $row['webmaster_url'];
	$topsite_name = $row['topsite_name'];
	$script_url = $row['script_url'];
	$lang_file = $row['lang_file'];
	$img_dir = $row['img_dir'];
	$img_total = $row['img_total'];
	$img_ext = $row['img_ext'];
	$img_visible = $row['img_visible'];
	$smile_des = $row['smile_description'];
	$smile_com = $row['smile_comments'];
	$per_page = $row['per_page'];
	$date_display = $row['date_display'];
	$webmaster_sendmail = $row['webmaster_sendmail'];
	$admin_user = $row['admin_user'];
	$admin_pass = $row['admin_pass'];
	$admin_prefix = $row['admin_prefix'];
}

// Including pageload script, dont edit this
include("functions.php");

?>