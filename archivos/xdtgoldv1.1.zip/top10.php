<?
############################################
#  Filename   : TOP10.PHP                  #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

require("config.php");

$query = mysql_query("SELECT *,hitstotal / (TO_DAYS(NOW())-TO_DAYS(register_date)+1) AS average FROM ". $table ."_sites ORDER BY average DESC, hitstotal DESC LIMIT 10") or die (mysql_error());
$result = mysql_result(mysql_query("SELECT *,hitstotal / (TO_DAYS(NOW())-TO_DAYS(register_date)+1) AS average FROM ". $table ."_sites ORDER BY average DESC, hitstotal DESC LIMIT 10"),0);

if(!$result)
{
?>

<? echo $text['26'] ?> ...

<?
}
else
{
	while($row = mysql_fetch_assoc($query))
	{
		$row['average'] = str_replace(".",",", $row['average']);

		echo "" . $row['rank'] . ". <a href=\"out.php?id=" . $row['memberid'] . "\" target=\"_blank\">
		" . $row['sitename'] . "</a> ( " . $row['average'] . " )\n<br>";
	}
}
?>