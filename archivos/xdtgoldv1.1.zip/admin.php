<?
############################################
#  Filename   : ADMIN.PHP                  #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Start session for login
session_start();

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )"; ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
</head>

<body>

<center><img src="images/logo.jpg"><br></center>

<?
// Check if the installation file still is located in the topsites directory
if(file_exists("install.php"))
{ // If it is... give error
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{ // Else start executing the script
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%" align="center"><hr style="border-style: dashed">
    <a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
    <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
    <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
    <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
    <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
    <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
    <a href="admin.php"><font class="active"><? echo $text['8'] ?></font></a>
    <hr style="border-style: dashed"><br></td>
  </tr>
</table>

<?
	// User is logged in ?
	if(!isset($_SESSION['loggedin']))
	{
		// Check if login form has been submitted
		if(isset($_POST['submit'])) // If it's submitted...
		{
			// Checking if USERNAME and PASSWORD for admin login are correct
			if($_POST['user'] == "$admin_user" AND $_POST['pass'] == "$admin_pass") // If user + pass for admin are correct
			{
				// User is logged in.. session started
				$_SESSION['loggedin'] = 1;
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['11'] ?><br><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=config"><? echo $text['119'] ?></a><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=list"><? echo $text['12'] ?></a><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=reset"><? echo $text['13'] ?></a> ( <? echo $text['17'] ?> )<br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=empty"><? echo $text['14'] ?></a> ( <? echo $text['18'] ?> )<br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=logoff"><? echo $text['15'] ?></a><br><br>
    <a href="index.php"><? echo $text['16'] ?> >></a></td>
  </tr>
</table>

<?
			}
			else // If user + pass for admin are not correct
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['19'] ?> ...<br><br>
    <a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
			}
		}

		// If user isn't logged in and hasn't submitted the login form show the login form
		if(!isset($_SESSION['loggedin']) AND !isset($_POST['submit']))
		{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <form method="POST">
    <input type="hidden" name="submit" value="1">
    <td width="100%" colspan="2" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['21'] ?>:</td>
    <td width="50%"><input type="text" name="user" size="20"></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['22'] ?>:</td>
    <td width="50%"><input type="password" name="pass" size="12" maxlength="12"></td>
  </tr>
  <tr>
    <td width="100%" colspan="2" align="center">
    <input type="submit" value="<? echo $text['23'] ?>"></td>
  </tr>
</table>

<?
		}
	}
	else // if form hasn't been submitted...
	{

		// If user is logged in
		if(isset($_SESSION['loggedin']) AND !isset($_GET['action']) AND !isset($_POST['save']) AND !isset($_POST['delete']) AND !isset($_POST['submit']))
		{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['11'] ?><br><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=config"><? echo $text['119'] ?></a><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=list"><? echo $text['12'] ?></a><br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=reset"><? echo $text['13'] ?></a> ( <? echo $text['17'] ?> )<br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=empty"><? echo $text['14'] ?></a> ( <? echo $text['18'] ?> )<br>
    <a href="<? echo $_SERVER['PHP_SELF'] ?>?action=logoff"><? echo $text['15'] ?></a><br><br>
    <a href="index.php"><? echo $text['16'] ?> >></a></td>
  </tr>
</table>

<?
		}

		// If an action has been set
		if(isset($_GET['action']))
		{

			// If action = list, show the list with sites
			if($_GET['action'] == "list")
			{
				$query = mysql_query("SELECT COUNT(1) FROM "  . $table . "_sites");
				$total = mysql_result($query,0);

				// Checking if a page has been validated
				if(!isset($_GET['page']))
				{
					$page = 0;
					$prev = "<font class=\"inactive\"><< " . $text['24'] . "&nbsp;" . $per_page . "</font>";
				}

				// Variable to tell the script where to start selecting sites from the database
				$start = $page * $per_page;

				// Number of pages
				$pages = $total / $per_page;

				// Number of pages + 1 (Next Page)
				$pageplus = $page + 1;

				// Number of pages - 1 (Previous Page)
				$pagemin = $page - 1;

				// Creating active link for Next Page
				if(($page + 1) < $pages OR $pageplus == "$pages")
				{
					$next = "[ <a href=\"". $_SERVER['PHP_SELF'] ."?action=list&page=" . $pageplus . "\">" . $text['25'] . "&nbsp;" . $per_page . "</a> ]";
				}

				// Creating active link for Previous Page
				if(($page - 1) < $pages AND $page)
				{
					$prev = "[ <a href=\"". $_SERVER['PHP_SELF'] ."?action=list&page=" . $pagemin . "\">" . $text['24'] . "&nbsp;" . $per_page . "</a> ]";
				}
				else // Creating text for inactive Previous Page
				{
					$prev = "<font class=\"inactive\">[ " . $text['24'] . "&nbsp;" . $per_page . " ]</font>";
				}

				// Creating text for inactive Next Page
				if($pageplus > $pages)
				{
					$next = "<font class=\"inactive\">[ " . $text['25'] . "&nbsp;" . $per_page . " ]</font>";
				}

                                $query = mysql_query("SELECT * FROM " . $table . "_sites ORDER BY memberid ASC LIMIT " . $start . "," . $per_page . "");
				$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites"),0);

				// If there are no records in the table tell users there are no sites listed
				if(!$result)
				{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['26'] ?> ...
    <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
				}
				else // If there are records in the table show them
				{
?>

<table border="0" cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="20%"><? echo $prev ?></td>
    <td width="60%" align="center">
    <script language="javascript">
    function goto(value)
    {
    	document.location.href = '<? echo $_SERVER['PHP_SELF'] ?>?action=list&page=' + value;
    }
    </script>
    <? echo $text['106'] ?> :
    <select name="page" OnChange="goto(value)">
<?
		// Making loop for 'jump to' form
		for($option = 0; $option <= $pages; $option++)
		{
			$select = (isset($_GET["page"]) AND $_GET["page"] == $option)?" selected":"";
			echo "            <option value=\"" . $option . "\"$select>" . ( $per_page * $option + 1 ) . " - " . ( $per_page * $option + $per_page ) . "</option>\n";
		}
?>
    </select></td>
    <td width="20%"><p align="right"><? echo $next ?></td>
  </tr>
  <tr>
    <td colspan="3"><font style="font-size: 4pt">&nbsp;</font></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="2" width="75%" class="content" align="center" >
  <tr class="title">
    <td width="5%" align="center"><? echo $text['28'] ?></td>
    <td width="5%" align="center"><? echo $text['29'] ?></td>
    <td width="20%" align="center"><? echo $text['30'] ?></td>
    <td width="20%" align="center"><? echo $text['31'] ?></td>
    <td width="18%" align="center"><? echo $text['32'] ?></td>
  </tr>
<?
					while($row = mysql_fetch_assoc($query))
					{
						$color = "content";
						$color2 = "content2";

						if(isset($colors) AND $colors == $color2)
						{
							$colors = $color;
						}
						else
						{
							$colors = $color2;
						}
?>
  <tr class="<? echo $colors ?>">
    <td width="5%" align="center"><? echo $row['memberid'] ?></td>
    <td width="5%" align="center"><? echo $row['rank'] ?></td>
    <td width="20%" align="center"><? echo htmlspecialchars($row['sitename']); ?></td>
    <td width="20%" align="center"><a href="<? echo $row['url'] ?>"><? echo htmlspecialchars($row['url']) ?></a></td>
    <td width="18%" align="center"><input type="button" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>?action=mod&id=<? echo $row['memberid'] ?>')" value="<? echo $text['33'] ?>">
    &nbsp;&nbsp; <input type="button" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>?action=del&id=<? echo $row['memberid'] ?>')" value="<? echo $text['34'] ?>"></td>
  </tr>
<?
					}
?>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><font style="font-size: 4pt">&nbsp;</font></td>
  </tr>
  <tr>
    <td width="50%"><? echo $prev ?></td>
    <td width="50%"><p align="right"><? echo $next ?></td>
  </tr>
</table>

<?
				}
			}

			// Modify site section
			if($_GET['action'] == "mod" AND !isset($_POST['save']))
			{
				$query = mysql_query("SELECT *,UNIX_TIMESTAMP(register_date) AS register_date FROM " . $table . "_sites WHERE memberid = '" . $_GET['id']. "'");
				$result = mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites WHERE memberid = '". $_GET['id'] ."'"),0);

				// If the site with this ID wasn't found in the table...
				if(!$result) // No records found, show error
				{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['35'] ?> ...
    <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
				}
				else // Record found
				{
					// Selecting site info from table
                                        while($row = mysql_fetch_assoc($query))
					{
						$row['register_date'] = date("$date_display",$row['register_date']);
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <form method="POST">
    <input type="hidden" value="1" name="save">
    <input type="hidden" value=<? echo $_GET['id'] ?>" name="id">
    <td width="100%" colspan="2" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['36'] ?>:</td>
    <td width="50%"><input type="text" name="sitename" size="30" value="<? echo htmlspecialchars($row['sitename']); ?>"></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['37'] ?>:</td>
    <td width="50%"><input type="text" name="url" size="30" value="<? echo htmlspecialchars($row['url']); ?>"></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['38'] ?>:</td>
    <td width="50%"><input type="text" name="buttonurl" size="30" value="<? echo htmlspecialchars($row['buttonurl']); ?>"></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['39'] ?>:</td>
    <td width="50%"><input type="text" name="email" size="30" value="<? echo htmlspecialchars($row['email']); ?>"></td>
  </tr>
  <tr>
    <td width="50%" valign="top"><p align="center"><? echo $text['40'] ?>:</td>
    <td width="50%"><textarea rows="7" name="description" cols="30"><? echo htmlspecialchars($row['description']); ?></textarea></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['156'] ?>:</td>
    <td width="50%"><input type="text" size="30" value="<? echo $row['ip']; ?>" disabled></td>
  </tr>
  <tr>
    <td width="50%" align="center"><? echo $text['157'] ?>:</td>
    <td width="50%"><input type="text" size="30" value="<? echo $row['register_date']; ?>" disabled></td>
  </tr>
  <tr>
    <td width="100%" valign="top" colspan="2" align="center"><input type="submit" value="<? echo $text['41'] ?>">
    <input type="reset" value="<? echo $text['118'] ?>"></td>
  </tr>
</table>

<?
					}
				}
			}

			// Delete site section
			if($_GET['action'] == "del" AND !isset($_POST['delete']))
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['42'] ?><br><br>
    <form method="POST">
    <input type="hidden" value="1" name="delete">
    <input type="hidden" value="<? echo $_GET['id'] ?>" name="id"><center>
    <input type="submit" value="<? echo $text['43'] ?>">
    <input type="button" value="<? echo $text['44'] ?>" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>')"></center>
    </td>
  </tr>
</table>

<?
			}

			// Empty topsite, not confirmed
			if($_GET['action'] == "empty" AND !isset($_GET['submit']))
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%" align="center"><? echo $text['45'] ?><br><br>
    <input type="button" value="<? echo $text['43'] ?>" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>?action=empty&submit=1')">
    <input type="button" value="<? echo $text['44'] ?>" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>')"></td>
  </tr>
</table>

<?
			}

			// Empty topsite, confirmed
			if($_GET['action'] == "empty" AND isset($_GET['submit']))
			{

				// Deleting sites from table
				mysql_query("DELETE FROM " . $table . "_sites") or die(mysql_error());
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['46'] ?> ... <br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>"><? echo $text['47'] ?> >></a></td>
  </tr>
</table>

<?
			}

			// Log off section
			if($_GET['action'] == "logoff")
			{
				// Drop session 'loggedin'
				unset($_SESSION['loggedin']);
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['48'] ?> ... <br><br><a href="index.php"><? echo $text['16'] ?> >></a></td>
  </tr>
</table>

<?
			}

			// Empty topsite, not confirmed
			if($_GET['action'] == "reset" AND !isset($_GET['submit']))
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" 	align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['49'] ?><center>
    <br><input type="button" value="<? echo $text['43'] ?>" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>?action=reset&submit=1')">
    <input type="button" value="<? echo $text['44'] ?>" OnClick="document.location.href=('<? echo $_SERVER['PHP_SELF'] ?>')"></center></td>
  </tr>
</table>

<?
			}

			// Empty topsite, confirmed
			if($_GET['action'] == "reset" AND isset($_GET['submit']))
			{
				// Date
				$date = date("dmY");

				// Resetting stats
				mysql_query("UPDATE " . $table . "_sites SET hitsin = '0', clicksin = '0', hitsout = '0', hitstotal = '0', hitstoday = '" . $date . " | 0', date = '" . $date . " | 1', register_date = NOW()") or die(mysql_error());
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['50'] ?><br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>"><? echo $text['47'] ?> >></a></td>
  </tr>
</table>

<?
			}

			// Configuration section, change info part
			if($_GET['action'] == "config" AND !isset($_POST['savecfg']))
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%" align="center">
    <form method="POST">
    <input type="hidden" name="savecfg" value="1">
    <table class="content" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse"  width="75%">
      <tr>
        <td width="50%" align="right"><? echo $text['108'] ?> :</td>
        <td width="50%"><input type="text" name="top_name" size="25" value="<? echo $topsite_name ?>" maxlength="50"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['120'] ?> :</td>
        <td width="50%"><input type="text" name="web_mail" size="25" value="<? echo $webmaster_email ?>" maxlength="100"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['121'] ?> :</td>
        <td width="50%"><input type="text" name="web_url" size="25" value="<? echo $webmaster_url ?>" maxlength="100"></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['109'] ?> :</td>
        <td width="50%"><input type="text" name="top_script" size="25" value="<? echo $script_url ?>" maxlength="100"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['110'] ?> :</td>
        <td width="50%"><input type="text" name="top_imgdir" size="25" value="<? echo $img_dir ?>" maxlength="125"></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['111'] ?> :</td>
        <td width="50%"><input type="text" name="top_totbut" size="4" value="<? echo $img_total ?>" maxlength="5"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['112'] ?> :</td>
        <td width="50%">
<?
				// Img Extension is .PNG
				if($img_ext == ".png")
				{
					$png = " selected";
				}
				// Img Extension is .JPG
				elseif($img_ext == ".jpg")
				{
					$jpg = " selected";
				}
				// Img Extension is .JPEG
				elseif($img_ext == ".jpeg")
				{
					$jpeg = " selected";
				}
				// Img Extension is .BMP
				elseif($img_ext == ".bmp")
				{
					$bmp = " selected";
				}
?>
        <select name="top_butext">
        <option value=".gif" selected>.gif</option>
        <option value=".png"<? if(isset($png)){ echo "$png"; } ?>>.png</option>
        <option value=".jpg"<? if(isset($jpg)){ echo "$jpg"; } ?>>.jpg</option>
        <option value=".jpeg"<? if(isset($jpeg)){ echo "$jpeg"; } ?>>.jpeg</option>
        <option value=".bmp"<? if(isset($bmp)){ echo "$bmp"; } ?>>.bmp</option>
        </select></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['113'] ?> :</td>
        <td width="50%"><input type="text" name="top_vis" size="4" value="<? echo $img_visible ?>" maxlength="5"></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['114'] ?> :</td>
        <td width="50%"><input type="text" name="top_pp" size="4" value="<? echo $per_page ?>" maxlength="3"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['122'] ?> :</td>
        <td width="50%"><select name="top_lang">
<?
				// Selecting language files... current language will be selected
				$handle = opendir('languages');

				while(false !== ($file = readdir($handle)))
				{
					if($file != "." && $file != "..")
					{
						echo "        <option value=\"$file\"";

						if($file == $lang_file)
						{
							echo " selected";
						}

						echo ">$file</option>\n";
					}
				}

				closedir($handle);
?>
        </select></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['153'] ?> :</td>
        <td width="50%"><select name="smiles">
<?
				if(!empty($smile_des) AND empty($smile_com))
				{
					$smiles_1 = " selected";
				}

				elseif(empty($smile_des) AND !empty($smile_com))
				{
					$smiles_2 = " selected";
				}

				elseif(!empty($smile_des) AND !empty($smile_com))
				{
					$smiles_3 = " selected";
				}
?>
        <option value="1" selected><? echo $text['154'] ?></option>
        <option value="2"<? if(isset($smiles_1)) echo $smiles_1 ?>><? echo $text['40'] ?></option>
        <option value="3"<? if(isset($smiles_2)) echo $smiles_2 ?>><? echo $text['143'] ?></option>
        <option value="4"<? if(isset($smiles_3)) echo $smiles_3 ?>><? echo $text['40'] ?> + <? echo $text['143'] ?></option>
        </select>
        </td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['115'] ?> :</td>
        <td width="50%"><select name="top_mail">
<?
				// If webmaster wants to receive emails when someone registers
				if(empty($webmaster_sendmail))
				{
					$selected = " selected";
				}
				else
				{
					$selected = "";
				}
?>
        <option value="1" selected><? echo $text['43'] ?></option>
        <option value="0"<? echo $selected . ">" . $text['44'] ?></option>
        </select>
      </tr>
      <tr>
        <td width="50%" align="right">&nbsp;</td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['116'] ?> :</td>
        <td width="50%"><input type="text" name="adm_user" size="10" value="<? echo $admin_user ?>" maxlength="25"></td>
      </tr>
      <tr>
        <td width="50%" align="right"><? echo $text['117'] ?> :</td>
        <td width="50%"><input type="text" name="adm_pass" size="10" value="<? echo $admin_pass ?>" maxlength="25"></td>
      </tr>
      <tr>
        <td width="50%">&nbsp;</td>
        <td width="50%">&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" colspan="2" align="center">
        <input type="submit" value="<? echo $text['41'] ?>"> <input type="reset" value="<? echo $text['118'] ?>"></td>
      </tr>
    </table>
    </td>
  </tr>
</table>

<?
			}
		}

		// Deleting site with the given ID
		if(isset($_POST['id']) AND isset($_POST['delete']))
		{
			$query = mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE memberid = '" . $_POST['id'] . "'") or die(mysql_error());
			$result = mysql_result($query,0);

			if(!$result)
			{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['35'] ?> ...<br><br><a href="javascript:history.go(-2)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
			}
			else
			{
				// Dropping site
				mysql_query("DELETE FROM " . $table . "_sites WHERE memberid = '" . $_POST['id'] . "'") or die(mysql_error());
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['51'] ?> : <b><? echo $_POST['id'] ?></b> <? echo $text['52'] ?> ...
    <br><br><a href="javascript:history.go(-2)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
			}
		}
		// Save site info form has been submitted
		if(isset($_POST['save']))
		{
			// Updating site info
			mysql_query("UPDATE " . $table . "_sites SET sitename = '" . $_POST['sitename'] . "', url = '" . $_POST['url'] . "', buttonurl = '" . $_POST['buttonurl'] . "', email = '" . $_POST['email'] . "', description = '" . $_POST['description'] . "' WHERE memberid = '" . $_POST['id'] . "'") or die(mysql_error());
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['53'] ?> ...<br><br><a href="javascript:history.go(-2)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
		}
		// Save configuration form has been submitted
		if(isset($_POST['savecfg']))
		{
			// Checking for smile config
			if($_POST['smiles'] == "1")
			{
				$smiles_description = 0;
				$smiles_comments = 0;
			}
			elseif($_POST['smiles'] == "2")
			{
				$smiles_description = 1;
				$smiles_comments = 0;				
			}
			elseif($_POST['smiles'] == "3")
			{
				$smiles_description = 0;
				$smiles_comments = 1;
			}
			else
			{
				$smiles_description = 1;
				$smiles_comments = 1;
			}

			// Updating config
			mysql_query("UPDATE " . $table . "_config SET webmaster_email = '" . $_POST['web_mail'] . "', webmaster_url = '" . $_POST['web_url'] . "', topsite_name = '" . $_POST['top_name'] . "', script_url = '" . $_POST['top_script'] . "', lang_file = '" . $_POST['top_lang'] . "', img_dir = '" . $_POST['top_imgdir'] . "', img_total = '" . $_POST['top_totbut'] . "', img_ext = '" . $_POST['top_butext'] . "', img_visible = '" . $_POST['top_vis'] . "', smile_description = '" . $smiles_description . "', smile_comments = '" . $smiles_comments . "', per_page = '" . $_POST['top_pp'] . "', webmaster_sendmail = '" . $_POST['top_mail'] . "', admin_user = '" . $_POST['adm_user'] . "', admin_pass = '" . $_POST['adm_pass'] . "'") or die(mysql_error());
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['10'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['123'] ?> ...<br><br><a href="<? echo $_SERVER['PHP_SELF'] ?>"><< <? echo $text['47'] ?></a></td>
  </tr>
</table>

<?
		}
	}
}
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>

</body>
</html>