<?
############################################
#  Filename   : JOIN.PHP                   #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )"; ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
<script language=javascript>
function showimage()
{
	if(!document.images)return;
	document.images.icons.src="images/flags/"+document.form.country.options[document.form.country.selectedIndex].value;
}
</script>
</head>

<body>

<center><img src="images/logo.jpg"><br></center>

<?
// Check if the installation file still is located in the topsites directory
if(file_exists("install.php"))
{ // If it is... give error
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{ // Else start executing the script
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><hr style="border-style: dashed">
    <center><a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
    <a href="<? echo $_SERVER['PHP_SELF'] ?>"><font class="active"><? echo $text['3'] ?></font></a>&nbsp;-&nbsp;
    <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
    <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
    <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
    <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
    <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"><br></td>
  </tr>
</table>

<?
	// Show form to add your site
	if(!isset($_POST['submit']))
	{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <form method="POST" name=form>
    <input type="hidden" name="submit" value="1">
    <td width="100%" colspan="2">
    <p align="center"><? echo $text['73'] ?></td>
  </tr>
  <tr>
    <td width="50%"><? echo $text['36'] ?> :</td>
    <td width="50%"><input type="text" name="sitename" size="24" maxlength="50"></td>
  </tr>
  <tr>
    <td width="50%"><? echo $text['37'] ?> :</td>
    <td width="50%"><input type="text" name="url" size="24" maxlength="100"></td>
  </tr>
  <tr>
    <td width="50%"><? echo $text['38'] ?> [ 88 x 31 ] :</td>
    <td width="50%"><input type="text" name="buttonurl" size="24" maxlength="125"></td>
  </tr>
  <tr>
    <td width="50%"><? echo $text['39'] ?> :</td>
    <td width="50%"><input type="text" name="email" size="24" maxlength="75"></td>
  </tr>
  <tr>
    <td width="50%"><? echo $text['137'] ?> :</td>
    <td width="50%"><select name="country" onChange="showimage()"><?

		// Selecting different flags directory 'images/flags'
		$handle = opendir('images/flags');
		while(false!==($file = readdir($handle)))
		{
			if($file != "." AND $file != "..")
			{
				if($file == "flag_oth.gif")
				{
					$selected = " selected";
				}
				else
				{
					$selected = " ";
				}

				echo "<option value=\"" . $file . "\"" . $selected . ">" . $file . "</option>\n";
			}
		}

		closedir($handle);
?>
    </select><img src="images/flags/flag_oth.gif" name="icons" border="1" hspace="10"></td>
  </tr>
  <tr>
    <td width="50%" valign="top"><? echo $text['40'] ?> :</td>
    <td width="50%"><textarea rows="7" name="description" cols="26"></textarea></td>
  </tr>
  <tr>
    <td width="50%" valign="top"><? echo $text['22'] ?> :</td>
    <td width="50%"><input type="password" name="pssw" size="12" maxlength="25"></td>
  </tr>
  <tr>
    <td width="50%" valign="top"><? echo $text['22'] ?> [ <? echo $text['59'] ?> ]:</td>
    <td width="50%"><input type="password" name="pssw2" size="12" maxlength="25"></td>
  </tr>
  <tr>
    <td width="100%" valign="top" colspan="2">
    <p align="center"><input type="submit" value="<? echo $text['72'] ?>"></td>
  </tr>
</table>

<?
	}

	// Form has been submitted
	if(isset($_POST['submit']))
	{
		// Checking if email isn't used before to register a website
		$query = mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE email = '" . $_POST['email'] . "'");
		$result = mysql_result($query,0);

		// If email has been registered, give error
		if(!empty($result))
		{
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['73'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['74'] ?> ...
    <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
  </tr>
</table>

<?
		}
		else
		{ // If email hasn't been registered, run script to add site
?>

<table border="1" cellpadding="2" cellspacing="0" width="50%" align="center">
  <tr class="title">
    <td width="100%"><p align="center"><? echo $text['73'] ?></td>
  </tr>
  <tr class="content">
    <td width="100%">

<?
			// If sitename wasn't filled in
			if(empty($_POST['sitename']))
			{
?>

      <? echo $text['75'] ?>
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>

<?
			}
			// If URL wasn't filled in
			elseif(empty($_POST['url']))
			{
?>

      <? echo $text['76'] ?>
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>";

<?
			}
			// If email wasn't filled in
			elseif(empty($_POST['email']))
			{
?>

      <? echo $text['77'] ?>
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>

<?
			}
			// If description wasn't filled in
			elseif(empty($_POST['description']))
			{
?>

      <? echo $text['78'] ?>
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>

<?
			}
			// If password / confirm password weren't filled in
			elseif(empty($_POST['pssw']) OR empty($_POST['pssw2']))
			{
?>

      <? echo $text['79'] ?>
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>

<?
			}
			else
			{
				// If passwords are not the same 
				if($_POST['pssw'] != $_POST['pssw2'] OR empty($_POST['pssw']) OR empty($_POST['pssw2']))
				{
?>

      <? echo $text['61'] ?> ...
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a>

<?
				}
				else
				{
					// Not encrypted version of password
					$pssw = $_POST['pssw'];

					// Encrypted version of password
					$pssw_encrypted = md5($_POST['pssw']);

					$_POST['country'] = str_replace("flag_","", $_POST['country']);
					$_POST['country'] = str_replace(".gif","", $_POST['country']);

					$date = date("dmY");

					// Insert data of website into database
					mysql_query("INSERT INTO " . $table . "_sites (sitename,url,buttonurl,email,description,password,hitsin,clicksin,hitsout,hitstotal,hitstoday,date,register_date,country,rank,ip) VALUES ('" . $_POST['sitename'] . "','" . $_POST['url'] . "','" . $_POST['buttonurl'] . "','" . $_POST['email'] . "','" . $_POST['description'] . "','" . $pssw_encrypted . "','0','0','0','0','" . $date . " | 0','" . $date . " | 1',NOW(),'" . $_POST['country'] . "','-','" . $_ENV['REMOTE_ADDR'] . "')") or die (mysql_error());

					$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE email = '" . $_POST['email'] . "' AND url = '" . $_POST['url'] . "'") or die(mysql_error());

					while($row = mysql_fetch_assoc($query))
					{
						$memberid = $row['memberid'];
					}

					// Creating row for ratings for this website
					mysql_query("INSERT INTO " . $table . "_rate VALUES ('$memberid','0','0')") or die (mysql_error());

					$sitename = htmlspecialchars($_POST['sitename']);
					$email = htmlspecialchars($_POST['email']);
					$url = htmlspecialchars($_POST['url']);
					$buttonurl = htmlspecialchars($_POST['buttonurl']);
					$description = htmlspecialchars($_POST['description']);

					$message = "<font style=\"font-family: verdana; font-size: 8pt\">Dear webmaster of <b>" . $url . "</b>,<br>
					<br>You've added your site in our topsite of " . $webmaster_url . ", that's the why we've send you the
					information we reased from you. Please save this email very good, because the password you've entered has been send into the database totally
					encrypet against hackers e.g so keep that in mind !<br><br>Your information<br>
					<b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ID: " . $memberid . "<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sitename : " . $sitename . "<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; URL : " . $url . "<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Button URL : " . $buttonurl . "<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Description : " . $description . "<br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Password : " . $pssw . "</b><br><br><br>
					So save this email very good, or you have to be sure you won't forget/loose
					the password because it cannot be requested again<br><br>Greetz,<br>
					Webmasters " . $webmaster_url . "</font>";

					// Send email to webmaster of the signed up website
					mail("$email","Welcome to " . $topsite_name . " !!!","$message","From: Welcome to " . $topsite_name . " !!!<" . $webmaster_email . ">\nContent-Type: text/html; charset=iso-8859-1");

					// If webmasters wants to receive an email when a website registers
					if($webmaster_sendmail)
					{
						$message = "<font style=\"font-family: verdana; font-size: 8pt\">Dear
						webmaster,<br><br>A new website has addes his/her site to your topsite,
						the information of this site are:<br><br>The information:<br>
						<b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ID: " . $memberid . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sitename : " . $sitename . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email : " . $email . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; URL : " . $url . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Button URL : " . $buttonurl . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Description : " . $description . "<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Password : " . $pssw . "</b><br><br>There has
						also been send an email to the webmaster of this site with the info like
						above, the password cannot be requested again because it has been encrypted ...<br><br>Greetz autobot :-)</font>";

						mail("$webmaster_email","New Topsite Member !!!", "$message","From: New Topsite Member !!!<" . $webmaster_email . ">\nContent-Type: text/html; charset=iso-8859-1");
					}
?>

      <? echo $text['80'] ?><br><br>
      <? echo $text['81'] ?>:<br><br><center>
      <textarea cols="45" rows="5" onclick="this.select()"><a href="<? echo $script_url ?>/index.php?id=<? echo $memberid ?>" target="_blank"><img src="<? echo $script_url ?>/img.php?id=<? echo $memberid ?>" border="0"></a></textarea><br>
      <a href="index.php"><< <? echo $text['82'] ?></a></center>

<?
				}
			}
?>

    </td>
  </tr>
</table>

<?
		}
	}
}
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>


</body>
</html>