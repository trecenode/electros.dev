<?
############################################
#  Filename   : PASSRESET.PHP              #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

error_reporting(E_ALL);
require("config.php");

if(empty($lang_file))
{
	$lang_file = "lang_english.lng";
}

include("languages/" . $lang_file);
?>

<link rel="stylesheet" content="text/css" href="style.css">
<center><img src="images/logo.jpg"></center>

<?
if(file_exists("install.php"))
{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{
?>

<title>
<?
	echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )";
?>
</title>
<center>
  <table cellpadding="0" cellspacing="0" width="75%">
    <tr>
      <td width="100%"><hr style="border-style: dashed">
      <center><a href="index.php"><? echo $text['2'] ?></a>&nbsp;-&nbsp;
      <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
      <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
      <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
      <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
      <a href="passreset.php"><font class="active"><? echo $text['7'] ?></font></a>&nbsp;-&nbsp;
      <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"></center></td>
    </tr>
  </table>
</center>

<?
	if(!isset($_POST['submit']) AND !isset($_GET['reset']))
	{
?>

    <center><br>
    <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
      <tr class="title">
        <form method="POST">
        <input type="hidden" value="1" name="submit">
        <td width="100%" colspan="2"><p align="center"><? echo $text['99'] ?></td>
      </tr>
      <tr>
        <td width="50%"><? echo $text['96'] ?> :</td>
        <td width="50%"><input type="text" name="email" size="30"></td>
      </tr>
      <tr>
        <td width="50%"><? echo $text['97'] ?> :</td>
        <td width="50%"><input type="password" name="new1" size="12" maxlength="12"></td>
      </tr>
      <tr>
        <td width="50%"><? echo $text['97'] ?> [ <? echo $text['59'] ?> ]:</td>
        <td width="50%"><input type="password" name="new2" size="12" maxlength="12"></td>
      </tr>
      <tr>
        <td width="100%" colspan="2"><p align="center"><input type="submit" value="<? echo $text['98'] ?>"></td>
      </tr>
    </table>
    </center>

<?
	}
	if(isset($_POST['submit']) AND !isset($_GET['reset']))
	{
		$query = mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE email = '" . $_POST['email'] . "'");
		$result = mysql_result($query,0);

		if(!$result)
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['99'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['100'] ?> ...
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
		}
		else
		{
			if($_POST['new1'] != $_POST['new2'] OR !isset($_POST['new1']) OR !isset($_POST['new2'])){
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['99'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['61'] ?> ...
      <br><br><a href="javascript:history.go(-1)"><< <? echo $text['20'] ?></a></td>
    </tr>
  </table>
</center>

<?
			}
			else
			{
				$chars = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
				$code;

				for($c = 0; $c < 12; $c++)
				{
					srand((double)microtime() * 100000000000000);
					$pass = $chars[rand(0, 62)];
					$code = $code.$pass;
				}

				$query = mysql_query("UPDATE " . $table . "_sites SET passreset = '" . $code . "', passreset2 = '" . $_POST['new1'] . "' WHERE email = '" . $_POST['email'] . "'") or die(mysql_error());

				$message = "Dear webmaster,\n<br>\n<br>You wanted to reset your password at out topsite, so this email has been send
				to give you the link to change your password because, if somebody want to change it the real owner of that account
				doesnt even know it. Thats why we give you the url below to (if you click it) change you password for real...\n<br>\n<br>
				&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href=\"" . $script_url . "/" . $_SERVER['PHP_SELF'] . "?reset=" . $code . "\">" . $script_url . "/" . $_SERVER['PHP_SELF'] . "?reset=" . $code . "</a>\n<br>\n<br>
				Greetz,\n<br>				Webmaster " . $webmaster_url . "";

				mail("" . $_POST['email'] . "","Reset Password","$message","From: Reset Wachtwoord<" . $webmaster_email . ">\nContent-Type: text/html; charset=iso-8859-1");
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['99'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['101'] ?> ...
      <br><br><a href="index.php"><? echo $text['82'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
			}
		}
	}
	if(isset($_GET['reset']))
	{
		$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE passreset = '" . $_GET['reset'] . "'");
		$result = mysql_result(mysql_query("SELECT * FROM " . $table . "_sites WHERE passreset = '" . $_GET['reset'] . "'"),0);

		if(!$result)
		{
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['99'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['102'] ?> ...
      <br><br><a href="index.php"><? echo $text['82'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
		}
		else
		{
			while($row = mysql_fetch_assoc($query))
			{
				$new = $row['passreset2'];
			}

			$new_encrypted = md5($new);

			mysql_query("UPDATE " . $table . "_sites SET passreset = NULL, passreset2 = NULL, password = '" . $new_encrypted . "' WHERE passreset = '" . $_GET['reset'] . "'") or die(mysql_error());
?>

<center><br>
  <table border="1" cellpadding="2" cellspacing="0" width="50%" class="content">
    <tr class="title">
      <td width="100%"><p align="center"><? echo $text['99'] ?></td>
    </tr>
    <tr>
      <td width="100%"><? echo $text['103'] ?> : <b><? echo $new ?></b>
      <br><br><? echo $text['104'] ?> ...
      <br><br><a href="index.php"><? echo $text['20'] ?> >></a></td>
    </tr>
  </table>
</center>

<?
		}
	}
}
?>

  <table cellpadding="0" cellspacing="0" width="75%" align="center">
    <tr>
      <td width="100%"><br><hr style="border-style: dashed"></td>
    </tr>
  </table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>