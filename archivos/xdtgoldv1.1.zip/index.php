<?
############################################
#  Filename   : INDEX.PHP                  #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);

if(isset($_GET['id']))
{
	$date = date("dmY");

	$query = mysql_query("SELECT * FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'");
	$result = mysql_result(mysql_query("SELECT COUNT(1) FROM " . $table . "_sites WHERE memberid = '" . $_GET['id'] . "'"),0);

	if($result)
	{
		$clicksin = "UPDATE " . $table . "_sites SET clicksin = clicksin + 1, hitstotal = hitstotal + 1 WHERE memberid = '" . $_GET['id'] . "'";

		while($row = mysql_fetch_assoc($query))
		{
			$today = $row['hitstoday'];
			$today = explode(" | ",$today);

			$datetoday = $today[0];
			$hitstoday = $today[1];
			$hitsplus = $today[1] + 1;

			if($date != "$datetoday")
			{
				$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | 1' WHERE memberid = '" . $_GET['id'] . "'";
			}
			else
			{
				$update = "UPDATE " . $table . "_sites SET hitstoday = '" . $date . " | " . $hitsplus . "' WHERE memberid = '" . $_GET['id'] . "'";
			}

			$days = $row['date'];
			$days = explode(" | ",$days);

			$daytoday = $days[0];
			$dayplus = $days[1] + 1;

			$update2 = "UPDATE " . $table . "_sites SET date = '" . $date . " | " . $dayplus . "' WHERE memberid = '" . $_GET['id'] . "'";

			function dohits()
			{
				global $clicksin,$update,$update2,$date,$daytoday;

				mysql_query($clicksin) or die(mysql_error());
				mysql_query($update) or die(mysql_error());

				if($date != "$daytoday")
				{
					mysql_query($update2) or die(mysql_error());
				}
			}
		}

	dohits();
	header("Location: " . $script_url . "/" . $_SERVER['PHP_SELF'] . "");
	}
	else{
		echo "" . $text['90'] . "<br><br><a href=\"" . $_SERVER['PHP_SELF'] . "\">" . $text['82'] . " >></a>";
	}
}
else
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><? echo htmlspecialchars($topsite_name) ."&nbsp;&nbsp;( " .  $text['107'] ." : ". mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0) . " )"; ?></title>
<link rel="stylesheet" content="text/css" href="style.css">
<script language="JavaScript">
function stats(url, name)
{
	window.open(url, name, 'scrollbars = 0, resizable = no, width = 350, height = 550, status = 0, menubar = 0');
}

function rate(url, name)
{
	window.open(url, name, 'scrollbars = 0, resizable = no, width = 200, height = 175, status = 0, menubar = 0');
}

function comments(url, name)
{
	window.open(url, name, 'scrollbars = 1, resizable = no, width = 400, height = 500, status = 0, menubar = 0');
}
</script>
</head>

<body>

<center><img src="images/logo.jpg"></center>

<?
	if(file_exists("install.php"))
	{
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
	}
	else
	{
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%" align="center"><hr style="border-style: dashed">
    <a href="<? echo $_SERVER['PHP_SELF'] ?>"><font class="active"><? echo $text['2'] ?></font></a>&nbsp;-&nbsp;
    <a href="join.php"><? echo $text['3'] ?></a>&nbsp;-&nbsp;
    <a href="edit.php"><? echo $text['4'] ?></a>&nbsp;-&nbsp;
    <a href="lostid.php"><? echo $text['5'] ?></a>&nbsp;-&nbsp;
    <a href="lostcode.php"><? echo $text['6'] ?></a>&nbsp;-&nbsp;
    <a href="passreset.php"><? echo $text['7'] ?></a>&nbsp;-&nbsp;
    <a href="admin.php"><? echo $text['8'] ?></a><hr style="border-style: dashed"></td>
  </tr>
  <tr>
    <td width="100%">
<?
		$total = mysql_result(mysql_query("SELECT COUNT(1) FROM ". $table ."_sites"),0);

		if(!isset($_GET['page']) OR $_GET['page'] < 1)
		{
			$page = 0;
			$prev = "<font class=\"inactive\"><< " . $text['24'] . $per_page . "</font>";
		}
		else
		{
			$page = $_GET['page'];
		}

		$start = $page * $per_page;

		$pages = $total / $per_page;
		$pageplus = $page + 1;
		$pagemin = $page - 1;

		if(($page + 1) < $pages OR $pageplus == "$pages")
		{
			$next = "[ <a href=\"" . $_SERVER['PHP_SELF'] . "?page=" . $pageplus . "\">" . $text['25'] . "&nbsp;" . $per_page . "</a> ]";
		}

		if(($page - 1) < $pages AND $page)
		{
			$prev = "[ <a href=\"" . $_SERVER['PHP_SELF'] . "?page=" . $pagemin . "\">" . $text['24'] . "&nbsp;" . $per_page . "</a> ]";
		}
		else
		{
			$prev = "<font class=\"inactive\">[ " . $text['24'] . "&nbsp;" . $per_page . " ]</font>";
		}
		if($pageplus > $pages)
		{
			$next = "<font class=\"inactive\">[ " . $text['25'] . "&nbsp;" . $per_page . " ]</font>";
		}
?>
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="20%"><? if(isset($prev)){ echo $prev; } ?></td>
          <td width="60%" align="center">
             <script language="javascript">
             function goto(value)
             {
               document.location.href = '<? echo $_SERVER['PHP_SELF'] ?>?page=' + value;
             }
             </script>
             <? echo $text['106'] ?> :
             <select name="page" OnChange="goto(value)">
<?
		for($i = 0; $i <= $pages; $i++)
		{
			$select = (isset($_GET["page"]) AND $_GET["page"] == $i)?" selected":"";
			echo "             <option value=\"" . $i . "\"$select>" . ( $per_page * $i + 1 ) . " - " . ( $per_page * $i + $per_page ) . "</option>\n";
		}
?>
            </select></td>
          <td width="20%" align="right"><? if(isset($next)){ echo $next; } ?></td>
        </tr>
        <tr>
          <td colspan="3"><font style="font-size: 4pt">&nbsp;</font></td>
        </tr>
      </table>

      <table border="1" cellpadding="2" cellspacing="2" width="100%" class="content">
        <tr class="title">
          <td width="6%"><p align="center"><? echo $text['105'] ?></td>
          <td width="7%"><p align="center"><? echo $text['137'] ?></td>
          <td width="59%"><p align="center"><? echo $text['40'] ?></td>
          <td width="8%"><p align="center"><? echo $text['93'] ?></td>
          <td width="8%"><p align="center"><? echo $text['94'] ?></td>
          <td width="8%"><p align="center"><? echo $text['92'] ?></td>
        </tr>
<?
		$query = mysql_query("SELECT *,hitstotal / (TO_DAYS(NOW())-TO_DAYS(register_date)+1) AS average FROM ". $table ."_sites ORDER BY average DESC, hitstotal DESC LIMIT " . $start . "," . $per_page . "") or die (mysql_error());

		if(!isset($rank))
		{
			$rank = ($page * $per_page) + 1;
		}

		ob_start();

		while($row = mysql_fetch_assoc($query))
		{
			$row['sitename'] = htmlspecialchars($row['sitename']);
			$row['buttonurl'] = htmlspecialchars($row['buttonurl']);

			mysql_query("UPDATE " . $table . "_sites SET rank = '" . $rank . "' WHERE memberid = '" . $row['memberid'] . "'") or die(mysql_error());

			$days = explode(" | ",$row['date']);
			$average = $row['hitstotal'] / $days[1];

			$today = explode(" | ",$row['hitstoday']);

			$color = "content";
			$color2 = "content2";

			if(isset($colors) AND $colors == $color2)
			{
				$colors = $color; 
			}
			else
			{
				$colors = $color2;
			}
?>
        <tr class="<? echo $colors ?>">
          <td width="6%" align="center"><a href="javascript:stats('stats.php?id=<? echo $row['memberid'] ?>');">
<?
			if($rank == 1)
			{
				echo "<img src=\"images/rank1.gif\" width=\"30\" height=\"30\" border=\"0\">";
			}
			elseif($rank == 2)
			{
				echo "<img src=\"images/rank2.gif\" width=\"30\" height=\"30\" border=\"0\">";
			}
			elseif($rank == 3)
			{
				echo "<img src=\"images/rank3.gif\" width=\"30\" height=\"30\" border=\"0\">";
			}
			else
			{
				echo $rank . ".";
			}
?></a></td>
          <td width="7%" align="center"><img src="images/flags/flag_<? echo $row['country'] ?>.gif" alt="<? echo strtoupper($row['country']); ?>" style="border: 1px solid #000000"></td>
          <td width="59%" align="center">
<?
			$query2 = mysql_query("SELECT * FROM " . $table . "_rate WHERE site_id = '" . $row['memberid'] . "'");

			while($row2 = mysql_fetch_assoc($query2))
			{
				$total = $row2['total'];
				$votes = $row2['votes'];

				if(empty($total) OR empty($votes))
				{
					$average_rate = 0;
				}
				else
				{
					$average_rate = $total / $votes;
					$average_rate = round($average_rate,2);
					$average_rate = str_replace(".",",", $average_rate);
				}
			}

			$comments = mysql_num_rows(mysql_query("SELECT * FROM " . $table . "_comments WHERE site_id = '" . $row['memberid'] . "'"));
?>

<table width="100%">
  <tr class="<? echo $colors ?>">
    <td width="24%"><a href="javascript:rate('rate.php?id=<? echo $row['memberid'] ?>')"><? echo $text['151'] ?> :</a> <? echo $average_rate ?><br>
    <b><? echo $text['150'] ?> :</b> <? echo $votes ?><br>
    <a href="javascript:comments('comments.php?id=<? echo $row['memberid'] ?>')"><? echo $text['144'] ?> :</a> <? echo $comments ?><br></td>

    <td width="76%" align="center" valign="top">
    <b><a href="out.php?id=<? echo $row['memberid'] ?>" target="_blank"><? echo $row['sitename'] ?>
<?
			if($row['buttonurl'] AND $img_visible == "all")
			{
?>
          <br><img src="<? echo $row['buttonurl'] ?>" width="88" height="31" border="0" alt="<? echo $row['sitename'] ?>">
<?
			}
			elseif($row['buttonurl'] AND $rank <= $img_visible)
			{
?>
          <br><img src="<? echo $row['buttonurl'] ?>" width="88" height="31" border="0" alt="<? echo $row['sitename'] ?>">
<?
			}

			echo "</a></b><br>";

			$row['description'] = htmlspecialchars($row['description']);

			if(!empty($smile_des))
			{
				$query2 = mysql_query("SELECT * FROM " . $table . "_smiles");

				while($row2 = mysql_fetch_assoc($query2))
				{
					$row2['tag'] = str_replace(">","&gt;", $row2['tag']);
					$row2['tag'] = str_replace("<","&lt;", $row2['tag']);
					$row['description'] = str_replace("$row2[tag]","<img src=\"images/smiles/" . $row2['smile'] . "\">", $row['description']);
				}
			}

			$row['description'] = wordwrap($row['description'], 50, "\t", 1);
			$row['description'] = str_replace("\n","<br>", $row['description']);

			echo $row['description'];
?>    </td>
  </tr>
</table>
       </td>
          <td width="8%" align="center"><?
			$row['average'] = str_replace(".",",",$row['average']);
			echo $row['average'];
?></td>
          <td width="8%"align="center"><? echo $today[1] ?></td>
          <td width="8%"><p align="center"><? echo $row['hitstotal'] ?></td>
        </tr>
<?
			$rank++;
		}

		ob_end_flush();

		$a = $rank - 1;
		$b = $per_page * ($page + 1);

		for($c = $b - $a; $c > 0; $c--)
		{
?>
        <tr>
          <td width="6%"><p align="center">-</td>
          <td width="7%" align="center">-</td>
          <td width="59%"><p align="center"><a href="join.php"><? echo $text['95'] ?></a></td>
          <td width="8%"><p align="center">-</td>
          <td width="8%"><p align="center">-</td>
          <td width="8%"><p align="center">-</td>
        </tr>
<?
		}
?>
      </table>
      </td>
    </tr>
  </table>
</center>

<?
	}
?>

<table border="0" cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><font style="font-size: 4pt">&nbsp;</font></td>
  </tr>
  <tr>
    <td width="50%"><? if(isset($prev)){ echo $prev; } ?></td>
    <td width="50%"><p align="right"><? if(isset($next)){ echo $next; } ?></td>
  </tr>
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
}
?>


</body>
</html>