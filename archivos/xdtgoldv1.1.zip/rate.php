<?
############################################
#  Filename   : RATE.PHP                   #
#------------------------------------------#
#  Written By : Dennis van den Hout        #
#  Email      : xdt@scripters.nl           #
#  Website    : www.xdt.nl.tt              #
#  Questions? : www.scripters.nl/forum     #
#------------------------------------------#
#   Do NOT copy OR publicate this script   #
#    for ANY use on ANY other site !!!     #
#------------------------------------------#
############################################

// Report all script errors on this page
error_reporting(E_ALL);

// Including CONFIG.PHP which includes all configurations
require("config.php");

// Including language file
include("languages/" . $lang_file);

if(isset($_POST['submit']))
{
	$site_id = $_POST['site_id'];
	setcookie("vote_site" . $site_id . "", $site_id);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><? echo $text['138'] ?></title>
<link rel="stylesheet" content="text/css" href="style.css">

</head>

<body>
<?
// Check if the installation file still is located in the topsites directory
if(file_exists("install.php"))
{ // If it is... give error
?>

<table cellpadding="2" cellspacing="0" width="75%" align="center">
  <tr>
    <td colspan="2"><br><hr style="border-style: dashed; size="1"><br></td>
  </tr>
</table>

<table border="1" cellpadding="2" cellspacing="0" width="50%" class="content" align="center">
  <tr class="title">
    <td width="100%" align="center"><? echo $text['1'] ?></td>
  </tr>
  <tr>
    <td width="100%"><? echo $text['9'] ?> ...</td>
  </tr>
</table>

<?
}
else
{ // Else start executing the script
	// Checking for cookies
	if(isset($_COOKIE["vote_site" . $_GET['id'] . ""]))
	{
		// If user has already voted for this site
		if($_COOKIE["vote_site" . $_GET['id'] . ""] == "$_GET[id]")
		{
			echo "<center>" . $text['139'] . "...<br><br>
			<a href=\"javascript:window.close()\">Close Window</a>";
		}
	}
	else
	{
		// If form hasn't been submitted, show vote form
		if(!isset($_POST['submit']))
		{
?>

<center>
<? echo $text['140'] ?>:<br><br>
<form method="POST">
 <input type="hidden" value="<? echo $_GET['id'] ?>" name="site_id">
 <input type="hidden" value="1" name="submit">
  <select name="rating">
   <option value="1">1</option>
   <option value="2">2</option>
   <option value="3">3</option>
   <option value="4">4</option>
   <option value="5">5</option>
   <option value="6">6</option>
   <option value="7">7</option>
   <option value="8">8</option>
   <option value="9">9</option>
   <option value="10">10</option>
  </select><br><br>
 <input type="submit" value="Vote">
</center>

<?
		}

		// If vote form has been submitted
		if(isset($_POST['submit']))
		{
			// Update ratings in database
			mysql_query("UPDATE " . $table . "_rate SET total = total + " . $_POST['rating'] . ", votes = votes + 1 WHERE site_id = '" . $_POST['site_id'] . "'") or die(mysql_error());

			echo "<center>" . $text['141'] . ":<br><br> <font style=\"font-size: 18pt; font-weight: bold\">" . $_POST['rating'] . "</font><br><br> <a href=\"javascript:window.close()\">" . $text['142'] . "</a></center>";
		}
	}
}
?>

<table cellpadding="0" cellspacing="0" width="75%" align="center">
  <tr>
    <td width="100%"><br><hr style="border-style: dashed"></td>
  </tr>
</table>

<?
$time = $debug->endTimer();

echo "<center>";

if(isset($admin_prefix))
{
	echo "$admin_prefix";
}

echo "\n<br>Parsed in : " . $time . " seconds.";
echo "</center>";

include("footer.txt");
?>


</body>
</html>