<?
// De donde provine el usuario o Invitado
$url=$HTTP_REFERER;
if($url==""){
$url="Su PC"; 
}
// Si el Invitado es un usuario anonimo o es un usuario registrado
$usuario=$_COOKIE["unick"];
if($usuario==""){
$usuario="Invitado";
}
// Mostramos ip
if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"] != "") 
{ $ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]; } 
else { $ip = $HTTP_SERVER_VARS["REMOTE_ADDR"];
$ip = substr($ip,0,5)."..";
}
$abrir = fopen('nuevasestadisticas.log','a'); 
fputs($abrir,$file."<tr>
    <td  >".$usuario."</td>
    <td  >".date("d/M/Y")."</td>
    <td  >".date("H:i:s")."</td>
    <td  ><marquee direction=left scrollamount=3 onMouseOver=stop() onMouseOut=start() width=90><a href=".$url." target=_blank >".$url."</a></td></marquee>
    <td  >".$ip."</td>
    <td  ><marquee direction=left scrollamount=3 onMouseOver=stop() onMouseOut=start() width=90><a href=http://recursosphp.iefactory.com".$_SERVER['REQUEST_URI']." target=_blank >".$_SERVER['REQUEST_URI']."</a></td></marquee>
	<td  ><marquee direction=left scrollamount=3 onMouseOver=stop() onMouseOut=start() width=90>".$_SERVER['HTTP_USER_AGENT']."</marquee></td>
	<td  >".$_SERVER['HTTP_ACCEPT_LANGUAGE']."</td>
	");
fclose($abrir);
?>