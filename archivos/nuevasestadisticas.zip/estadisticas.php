<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table border='1' cellpadding='2' cellspacing='0' bordercolor='#000000' >
  <tr> 
    <td><b>Usuario</b></td>
    <td><b>Fecha</b></td>
    <td><b>Hora</b></td>
    <td><b>Entrada desde</b></td>
    <td><b>Ip</b></td>
	<td><b>Pagina vista</b></td>
	<td><b>Navegador</b></td>
	<td><b>Idioma</b></td>
  </tr><tr><?
include("nuevasestadisticas.log");
?></tr></table>
</body>
</html>
