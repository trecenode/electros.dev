<?//nosfertuSoft.com.ar
include("config.php");
class firmar{
	function guardar(){
		$hoy = date("d/m/y");
		$cuerpo = trim(htmlspecialchars($_POST["cuerpo"]));
		$autor = trim(htmlspecialchars($_POST["autor"]));
		$caritas = Array(
			"(Y)" => "bien",
			":|" => "desepcion",
			":@" => "enojado",
			":)" => "feliz",
			"[fumar]" => "fumar",
			";)" => "gino",
			":P" => "lengua",
			":\'(" => "llorando",
			"[ups]" => "ops2",
			":$" => "pena",
			"(H)" => "presumido",
			":D" => "risa");
		foreach($caritas as $comando => $src){
			$cuerpo = str_replace($comando,"<img src=\"caritas/$src.gif\">",$cuerpo);
			}
		@mysql_query("insert into ns_libro (autor,cuerpo,fecha) values ('$autor','$cuerpo','$hoy')") or die(mysql_error());
?>
<div class="coment">
	<span class="datos">Escrito por <?=$autor?> (<?=$hoy?>):</span>
	<div class="texto">
		<?=nl2br($cuerpo)?>
	</div>
</div><br>
<?	
		}
	}
$firma = new firmar();
$firma->guardar();
?>