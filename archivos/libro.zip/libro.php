<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>NosferatuSoft Libro De Visitas</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<? echo "
<script>
function ordenar(){
	self.location.href='libro.php?cant=$cant&por='+document.getElementById('orden').value;
	}
</script>";
?>
<script src="ajax.js"></script><center>
<div id="contenido">
<?
//nosfertuSoft.com.ar
include("config.php");
class ordenar{
	var $defecto = "fecha";
	var $sentencia;
	function ob_sentencia($que){
		$this->que = $que;
		$this->que = htmlspecialchars(trim($this->que));
		$this->que = str_replace("'","",$this->que);
		switch($this->que){
			default:
				$this->sentencia = "select * from ns_libro order by id desc";
				$this->selecion = "selected";
			break;
			case "id_asc":
				$this->sentencia = "select * from ns_libro order by id asc";
				$this->selecion = "selected";
			break;
			case "autor_desc":
				$this->sentencia = "select * from ns_libro order by autor desc";
				$this->selecion = "selected";
			break;
			case "autor_asc":
				$this->sentencia = "select * from ns_libro order by autor asc";
				$this->selecion = "selected";
			break;
			}
		}
	}
class paginar{
	var $cuantos = 10;
	var $enlace_sig;
	var $enlace_ant;
	var $sepa = 0;
	function mostrar($que,$sentencia){
		$cant = $que;
		if(!$que){	
			$cant = 0; 
			}
		$sig = $cant + $this->cuantos;
		$ant = $cant - $this->cuantos;
		$temp = "$sentencia limit $cant,$this->cuantos";
		$this->enlace_ant = $cant<=0 ? "" : "<a href='libro.php?cant=$ant'>$this->cuantos Anteriores<a/>";
		$temp2 = @mysql_query($temp) or die(mysql_error());
		while($leer = mysql_fetch_array($temp2)){
?>
<div class="coment">
	<span class="datos">Escrito por <?=$leer["autor"]?> (<?=$leer["fecha"]?>):</span>
	<div class="texto">
		<?=nl2br($leer["cuerpo"])?>
	</div>
</div><br>
<?
			$this->sepa++;
			}
		$this->enlace_sig = $this->sepa!=$this->cuantos ? "" : "<a href='libro.php?cant=$sig'>$this->cuantos siguientes</a>";

		}
	
	}
$get_por = $_GET["por"];
$get_por = str_replace("'","",$get_por);
$ordenar = new ordenar();
$ordenar->ob_sentencia($get_por);
$paginar = new paginar();
$paginar->mostrar($_GET["cant"],$ordenar->sentencia);
?></div>
<div id="enlaces">
<div class="ant">
<?=$paginar->enlace_ant?></div>
<div class="central">
<select id="orden" onchange="ordenar()">
	<option value="id_desc" <?=$this->selecion = "selected";?>> Id (...3,2,1)</option>
	<option value="id_asc" <?=$this->selecion = "selected";?>> Id (1,2,3...)</option>
	<option value="autor_desc" <?=$this->selecion = "selected";?>> Autor (Z - A)</option>
	<option value="autor_asc" <?=$this->selecion = "selected";?>> Autor (A - Z)</option>
</select></div>
<div class="sig"><?=$paginar->enlace_sig?></div>
</div>
<div class="coment">
	<div class="texto">
		Deja tu comentario:<br>
		<input type="text" id="autor" value="tu nombre" style="width:180px;"><br>
<img src="caritas/bien.gif" onclick="caras('(Y)')" style='cursor:hand;'>
<img src="caritas/desepcion.gif" onclick="caras(':|')" style='cursor:hand;'>
<img src="caritas/enojado.gif" onclick="caras(':@')" style='cursor:hand;'>
<img src="caritas/feliz.gif" onclick="caras(':)')" style='cursor:hand;'>
<img src="caritas/fumar.gif" onclick="caras('[fumar]')" style='cursor:hand;'>
<img src="caritas/gino.gif" onclick="caras(';)')" style='cursor:hand;'>
<img src="caritas/lengua.gif" onclick="caras(':P')" style='cursor:hand;'>
<img src="caritas/llorando.gif" onclick="caras(':\'(')" style='cursor:hand;'>
<img src="caritas/ops2.gif" onclick="caras('[ups]')" style='cursor:hand;'>
<img src="caritas/pena.gif" onclick="caras(':$')" style='cursor:hand;'>
<img src="caritas/presumido.gif" onclick="caras('(H)')" style='cursor:hand;'>
<img src="caritas/risa.gif" onclick="caras(':D')" style='cursor:hand;'><br>
		<textarea id="cuerpo" cols="30" rows="5" style="width:400px; height:120;">tu comentario</textarea><br>
		<input type="button" id="sub" value="Dejar Comentario" onclick="firmar()">
	</div><br>
<!-- -->


</body>
</html>
