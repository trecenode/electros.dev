/*                                                                          */
/*
PHPBB NEWS v1.0
Mostrar noticias de un subforo del phpbb,
Echo por Tebb,
tebb@eresmas.com o tebbxtreme@hotmail.com,
Ya que el script es gratis solo pido que no
elimineis esto! gracias :)
http://www.Area-Zone.Tk
*/
/*                                                                          */

[Instrucciones]


Descomprimir el zip, abrir el archivo phpbbnews.php y configurar los
datos de la base de datos y demas configuraciones y ale ya esta
subes los archivos phpbbnews.php y theme.htm and Done! xD

Ahora solo tienes que incluir el archivo phpbbnews.php en cualquier
sitio de tu web, tienes que hacerlo asi:

<? include("phpbbnews.php"); ?> y recuerda que la pagina donde lo incluyas
tiene que tener extension .php


Si tienes alguna duda, encuentras algun bug, o simplemente
quieres darnos algun consejo lo posteas en el foro:

http://www.elpueblomagico.net/~area-zone/foro/viewforum.php?f=17

thx :)




[Crear Themes]


Simplemente crea un archivo .htm o .php, y haz el dise�o de la tabla
donde quieres que se muestre cada noticia, para mostrar los datos
tienes que usar los:

{titulo} <- esto muestra el titulo de la noticia y tambien el link hacia ella en el foro
{textnews} <- esto muestra el contenido de la noticia
{autor} <- esto muestra el autor de el que escribio la noticia y el link hacia su perfil
{comentarios} <- esto muestra el numero de comentarios (contestaciones en el foro) y tambien el link hacia ellas

Bien, despues de crear el archivo con la tabla lo guardas con cualquier nombre, ejemplo estilojuan.php
y modificas el
$url_style ="theme.htm"; por
$url_style = "laurldetuarchivo/estilojuan.php";

o si esta en la misma carpeta sin el "laurldelarchivo/" solo con "estilojuan.php" y eso es todo.




[Todo] (por hacer..)


Poder mostrar el Avatar y el rango de el que posteo la noticia con por ejemplo {avatar} y {rango}
y tambien mostrar la data en la cual se posteo la noticia, y corregir algunos fallos interpretando
el bbcode...

si encuentras algun bug porfavor postealo en:

http://www.elpueblomagico.net/~area-zone/foro/viewforum.php?f=17

