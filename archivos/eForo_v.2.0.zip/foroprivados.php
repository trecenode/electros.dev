<?
// ****************************
// *** eForo v.2.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
$resp = mysql_query("select id from $tabla_usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
if(mysql_num_rows($resp) == 0) {
header("location: foroentrar.php") ;
}
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Mensajes privados</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<p>Bandeja de mensajes privados de: <b><? echo $HTTP_COOKIE_VARS[unick] ?></b>
<p>
<?
if($mensaje == "nuevo") {
?>
<script>
function caracteres() {
if(formulario.caracteres.value != formulario.mensaje.value.length) {
formulario.caracteres.value = formulario.mensaje.value.length ;
}
setTimeout("caracteres()",200) ;
}
onload=caracteres ;
function revisar() {
if(formulario.destinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.mensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p class="t1">Nuevo
<p>
<form name="formulario" method="post" action="foroprivados.php" onsubmit="return revisar()">
<b>Destinatario:</b><br>
<input type="text" name="destinatario" maxlength="20" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="30" rows="5" onkeypress="caracteres" class="form"></textarea><br>
<input type="text" name="caracteres" size="3" value="0" class="form"> <b>M�ximo 255 caract�res</b><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
else {
echo "<p><a href=?ver=mensajes&mensaje=nuevo>� Nuevo mensaje</a>" ;
}
// En todos los mensajes se ver� un enlace con la variable $responder para contestar al usuario que
// envi� el mensaje privado, como la variable es igual al nombre del usuario, entonces el campo de
// Destinatario tendr� el valor del nombre del usuario
if($responder) {
?>
<script>
function caracteres() {
if(formulario.caracteres.value != formulario.mensaje.value.length) {
formulario.caracteres.value = formulario.mensaje.value.length ;
}
setTimeout("caracteres()",200) ;
}
onload=caracteres ;
function revisar() {
if(formulario.destinatario.value.length == 0) { alert('Debes escribir un destinatario') ; return false ; }
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
if(formulario.mensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res') ; return false ; }
}
</script>
<p class="t1">Responder
<p>
<form name="formulario" method="post" action="foroprivados.php" onsubmit="return revisar()">
<b>Destinatario:</b><br>
<input type="text" name="destinatario" maxlength="20" value="<? echo $responder ?>" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="30" rows="5" onkeypress="caracteres" class="form"></textarea><br>
<input type="text" name="caracteres" size="3" value="0" class="form"> <b>M�ximo 255 caract�res</b><br><br>
<input type="submit" name="enviar" value="Enviar" class=form>
</form>
<?
}
if($borrar) {
$usuario = $HTTP_COOKIE_VARS[unick] ;
mysql_query("delete from eforo_privados where id='$borrar' and destinatario='$usuario'") ;
echo "<p>El mensaje ha sido borrado con �xito. Haz click <a href=?ver=mensajes>aqu�</a> para regresar." ;
}
else {
if($enviar) {
// Comprobar si la bandeja del usuario no supera el l�mite m�ximo
$resp = mysql_query("select id from eforo_privados where destinatario='$destinatario'") ;
if(mysql_num_rows($resp) < $max_privados) {
// Guardar mensaje privado
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$destinatario = quitar($destinatario) ;
$mensaje = quitar($mensaje) ;
$resp = mysql_query("select id from $tabla_usuarios where nick='$destinatario'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) == 0) {
echo "<p>Este usuario no existe en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.";
}
else {
$remitente = $HTTP_COOKIE_VARS[unick] ;
mysql_query("insert into eforo_privados (fecha,destinatario,remitente,mensaje) values ('$fecha','$destinatario','$remitente','$mensaje')") ;
echo "<p>El mensaje ha sido enviado con �xito. Haz click <a href=?ver=mensajes>aqu�</a> para regresar." ;
}
mysql_free_result($resp) ;
}
else {
?>
<p>La bandeja de mensajes privados del usuario <b><? echo $destinatario ?></b> ha excedido el l�mite. No se pudo enviar el siguiente
mensaje:
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="form">
<tr>
<td><? echo $mensaje ?></td>
</tr>
</table>
<p><a href="javascript:history.back()">Regresar</a>
<?
}
}
else {
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select id from eforo_privados where destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = 5 ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_privados where destinatario='$usuario' order by id desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
if(mysql_num_rows($resp) == 0) { echo "<p>No se encontraron mensajes." ; }
else {
echo "
<p><b>Total de mensajes:</b> $mensajes
<p>
" ;
while($datos = mysql_fetch_array($resp)) {
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano $hora" ;
?>
<table width="100%" border="0" cellpadding="1" cellspacing="0" class="form">
<tr>
<td><b><? echo $datos[remitente] ?></b></td>
<td><div align="right"><b><? echo $fecha ?></b></div></td>
</tr>
<tr>
<td colspan="2"><? echo $datos[mensaje] ?></td>
</tr>
<tr>
<td colspan="2">
<div align="right">
<a href="?ver=mensajes&responder=<? echo $datos[remitente] ?>">� Responder</a> |
<a href="?ver=mensajes&borrar=<? echo $datos[id] ?>">� Borrar</a>
</div>
</td>
</tr>
</table><br>
<?
if($datos[nuevo] == 0) {
mysql_query("update eforo_privados set nuevo='1' where id='$datos[id]'") ;
}
}
echo "
<p align=right><a href=?ver=mensajes&desde=$desde>� Siguientes $mostrar mensajes</a>
" ;
}
mysql_free_result($resp) ;
}
}
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.0</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
