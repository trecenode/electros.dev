<?
setcookie("unick") ;
header("location: foro.php") ;
?>