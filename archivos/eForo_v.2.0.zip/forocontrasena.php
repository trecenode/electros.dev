<?
// ****************************
// *** eForo v.2.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Recuperaci�n de contrase�a</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<?
if($confirmacion) {
if($confirmacion == "si") {
echo "
<p>Se te ha enviado un email con tus datos de registro.
" ;
}
if($confirmacion == "no") {
echo "
<p>No existe ning�n usuario con este email. Haz click <a href=javascript:history.back()>aqu�</a> para regresar.
" ;
}
if($confirmacion == "esperar") {
echo "
<p>Por seguridad s�lo puedes pedir tus datos una vez cada media hora.
" ;
}
}
else {
?>
<p>Para recuperar tus datos debes escribir el email con el que te registraste en la web.
<script>
enviado = 0 ;
function revisar() {
if(formulario.email.value == "") { alert('Debes poner un email v�lido.') ; return false ; }
if(enviado == 0) { enviado++ ; alert('Los datos se est�n enviando por favor espera.') ; return false ; }
}
</script>
<form name="formulario" method="post" action="forocontrasenaenviar.php">
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="email" maxlength="40" class="form"><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<?
}
?>
</td>
</tr>
</table>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.0</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
