<?
if($enviar) {
if(!$HTTP_COOKIE_VARS[ucontrasena]) {
include("foroconfig.php") ;
include("config.php") ;
$resp = mysql_query("select nick,contrasena from $tabla_usuarios where email='$email'") ;
$usuarios = mysql_num_rows($resp) ;
if($usuarios != 0) {
$datos = mysql_fetch_array($resp) ;
$mensaje = "
<html>
<body>
<style>
.tabla {
font-family: verdana ;
font-size: 10pt ;
}
.enlace {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
</style>
<p>Estos son tus datos de registro:
<p>Nick: <b>$datos[nick]</b><br>
Contrase�a: <b>$datos[contrasena]</b>
<p>-----------------------------------<br>
Estos datos se te enviaron debido a que solicitaste tus datos de registro en <b>$titulodelforo</b>, si tu no pediste estos
datos alguien registr� una cuenta en el foro con este email, para eliminar estos datos contacta al administrador del
foro por este email <a href=\"mailto:$administrador_email\" class=\"enlace\">$administrador_email</a>.
</body>
</html>
" ;
mail($email,"$titulodelforo :: Recuperaci�n de contrase�a",$mensaje,"From: $administrador <$administrador_email>") ;
setcookie("ucontrasena","ucontrasena",time()+1800) ;
header("location: forocontrasena.php?confirmacion=si") ;
}
else {
header("location: forocontrasena.php?confirmacion=no") ;
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
}
else {
header("location: forocontrasena.php?confirmacion=esperar") ;
}
}
?>
