<?
include("config.php") ;
mysql_query("
create table eforo_categorias (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria varchar(100) not null,
primary key (id),
index (orden)
)
") ;
mysql_query("
create table eforo_foros (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria tinyint(3) unsigned not null,
foro varchar(100) not null,
descripcion tinytext not null,
temas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (orden,categoria)
)
") ;
mysql_query("
create table eforo_mensajes (
id smallint(5) unsigned not null auto_increment,
foro tinyint(3) unsigned not null,
forotema smallint(5) unsigned not null,
foromostrar tinyint(1) unsigned not null,
visitas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
tema varchar(100) not null,
mensaje text not null,
editado int(10) unsigned not null,
ultimo int(10) unsigned not null,
primary key (id),
index (foro,forotema,foromostrar)
)
") ;
mysql_query("
create table eforo_usuarios (
id smallint(5) unsigned not null auto_increment,
fecha int(10) unsigned not null,
nick varchar(20) not null,
contrasena varchar(20) not null,
email varchar(40) not null,
pais varchar(20) not null,
edad tinyint(2) unsigned not null,
sexo tinyint(1) unsigned not null,
descripcion tinytext not null,
web varchar(100) not null,
ip varchar(15) not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (nick,contrasena)
)
") ;
mysql_query("
create table eforo_enlinea (
fecha int(10) unsigned not null,
ip varchar(15) not null,
usuario varchar(20) not null,
index (fecha)
)
") ;
mysql_query("
create table eforo_privados (
id smallint(5) unsigned not null auto_increment,
nuevo tinyint(1) unsigned not null,
fecha int(10) unsigned not null,
remitente varchar(20) not null,
destinatario varchar(20) not null,
mensaje tinytext not null,
primary key (id),
index (destinatario)
)
") ;
mysql_close($conectar) ;
?>
<style>
body,table {
font-family: verdana ;
font-size: 10pt ;
text-align: justify ;
}
</style>
<p><b>eForo v.2.0</b>
<p>Tablas creadas:
<p><b>eforo_categorias</b><br><b>eforo_enlinea</b><br><b>eforo_foros</b><br><b>eforo_mensajes</b><br><b>eforo_usuarios</b><br><b>eforo_privados</b>
<p>La instalaci�n se ha completado con �xito. Recuerda eliminar este archivo inmediatamente despu�s de la instalaci�n.
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="0" style="border: #000000 1 solid ; background: #cccccc">
<tr>
<td>
<b>Nota:</b> Si elegiste la opci�n <b>Compatibilidad con el script Registro de usuarios 1</b>, elimina la tabla <b>eforo_usuarios</b>,
y pega el siguiente c�digo en la casilla SQL de tu phpMyAdmin:
<p><b>alter table usuarios add avatar char(3) unsigned not null, add mensajes smallint(5) unsigned not null, add web varchar(100) not null</b>
<p>De esta forma agregar�s los campos que hacen falta en la tabla <b>usuarios</b> para que eForo funcione correctamente.
</td>
</tr>
</table>
<p>Para empezar a administrar el foro, debes registrarte con el nombre del administrador que pusiste en foroconfig.php,
para registrarte haz click <a href="fororegistrar.php">aqu�</a>.
