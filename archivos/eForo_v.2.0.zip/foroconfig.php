<?
// ****************************
// *** eForo v.2.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

// Administrador del foro
$administrador = "Administrador" ;
// Email del administrador (se env�a en el mensaje cuando el usuario quiere recuperar sus datos)
$administrador_email = "administrador@hotmail.com" ;
// T�tulo del foro
$titulodelforo = "T�tulo del foro - eForo v.2.0" ;
// Temas a mostrar
$num_temas = "20" ;
// Mensajes por tema a mostrar
$num_mensajes = "20" ;
// Mensajes que se mostrar�n al responder un tema (estos se muestran abajo del formulario para escribir mensajes)
$num_ultimos = "10" ;
// C�digo especial
$codigo = "ON" ;
// Caretos
$caretos = "ON" ;
// Censurar palabras
$censurar = "OFF" ;
// Estilo del foro (tipo de letra, color, tama�o)
$estilo = "electros.php" ;

// *** Avatares ***

// Tama�o m�ximo en pixeles permitido
$tam_largo = 150 ;
$tam_ancho = 150 ;
// Peso m�ximo de la imagen en Kb
$tam_archivo = 25 ;

// *** Mensajes privados ***
// M�ximo de mensajes privados de cada usuario
$max_privados = 50 ;

// *** Compatibilidad con el script "Registro de usuarios 1" (perteneciente a la misma web) ***
// Para los usuarios que ya antes han creado el script "Registro de usuarios 1", con esta opci�n har�n que
// eForo utilice la misma tabla donde se han registrado los usuarios para que de esta forma estos no necesiten
// registrarse por segunda vez, si no lo tienes simplemente dejalo como est�.
$registro = "OFF" ;

// ****************************
// *** Fin de configuraci�n ***
// ****************************

if(!file_exists("eforo_estilo/$estilo")) {
echo "
<p><b>Error</b>
<p>El estilo seleccionado <b>$estilo</b> no existe en el servidor.
" ;
exit ;
}

if($registro == "OFF") {
$tabla_usuarios = "eforo_usuarios" ;
}
else {
$tabla_usuarios = "usuarios" ;
}
?>
