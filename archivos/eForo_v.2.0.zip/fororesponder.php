<?
// ****************************
// *** eForo v.2.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
$resp = mysql_query("select contrasena from usuarios where nick='$HTTP_COOKIE_VARS[unick]'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[contrasena] != $HTTP_COOKIE_VARS[ucontrasena]) {
?>
<script>location="foroentrar.php"</script>
<?
exit ;
}
mysql_free_result($resp) ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
if($enviar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$fecha = time() ;
$tema = quitar($tema) ;
$mensaje = quitar($mensaje) ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
mysql_query("insert into eforo_mensajes (foro,forotema,foromostrar,fecha,usuario,tema,mensaje,editado) values ('$foroid','$temaid','0','$fecha','$usuario','$tema','$mensaje','$fecha')") ;
mysql_query("update eforo_mensajes set mensajes=mensajes+1,ultimo='$fecha' where id='$temaid'") ;
mysql_query("update eforo_foros set mensajes=mensajes+1 where id='$foroid'") ;
mysql_query("update $tabla_usuarios set mensajes=mensajes+1 where nick='$usuario'") ;
$resp = mysql_query("select id from eforo_mensajes where fecha='$fecha'") ;
$datos = mysql_fetch_array($resp) ;
$mensaje = $datos[id] ;
echo "Tu mensaje ha sido publicado con �xito. Haz click <a href=foro.php?foroid=$foroid&temaid=$temaid#$mensaje>aqu�</a> para ver tu mensaje." ;
mysql_free_result($resp) ;
}
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p class="tema"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>">� <? echo $datos[tema] ?></a>
<p>
<?
mysql_free_result($resp) ;
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p><a href="foro.php">Indice del foro</a> � <a href="foro.php?foroid=<? echo $foroid ?>"><? echo $datos[foro] ?></a>
<p>
<?
mysql_free_result($resp) ;
?>
<script>
function revisar() {
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje') ; return false ; }
}
</script>
<form name="formulario" method="post" action="fororesponder.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>" onsubmit="return revisar()">
<b>Tema:</b><br>
<input type="text" name="tema" size="40" maxlength="100" class="form"><br>
<b>Mensaje:</b><br>
<textarea name="mensaje" cols="50" rows="20" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Enviar" class="form">
</form>
<div style="height: 175 ; overflow: auto">
<table width="100%" border="0" cellpadding="5" cellspacing="1">
<?
$resp = mysql_query("select id,usuario,mensaje from eforo_mensajes where forotema='$temaid' order by id desc limit $num_ultimos") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td valign="top" class="tabla_mensaje"><a href="forousuarios.php?u=<? echo $datos[id] ?>"><? echo $datos[usuario] ?></a></td>
<td valign="top" class="tabla_mensaje"><? echo $datos[mensaje] ?></td>
</tr>
<?
}
mysql_free_result($resp) ;
?>
</table>
</div>
<?
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.0</a>
<p>
</body>
</html>
