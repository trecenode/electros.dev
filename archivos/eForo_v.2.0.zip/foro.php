<?
// ****************************
// *** eForo v.2.0          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title><? echo $titulodelforo ?></title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
include("foroenlinea.php") ;
// Funci�n que muestra la fecha en el formato 1 Ene 2003 12:00 AM
function fecha1($fecha) {
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano<br>$hora" ;
return $fecha ;
}
// Funci�n que muestra la fecha en el formato Lunes 1 de Enero del 2003 12:00 AM
function fecha2($fecha) {
$semana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mes = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$semana[$diasemana] $diames de $mes[$mesano] del $ano $hora" ;
return $fecha ;
}
// Funci�n para sustituir el c�digo especial por su respectivo c�digo HTML
if($codigo == "ON") {
function codigo($texto) {
// --> Inicio c�digo
$texto = str_replace("[b]","<b>",$texto) ;
$texto = str_replace("[/b]","</b>",$texto) ;
$texto = str_replace("[img]","<img src=\"",$texto) ;
$texto = str_replace("[/img]","\" border=\"0\">",$texto) ;
$texto = str_replace("[codigo]","<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\"><div style=\"color: #000000 ; text-align: left ; font-weight: bold\">",$texto) ;
$texto = str_replace("[/codigo]","</div></td></tr></table>",$texto) ;
$texto = str_replace("\r\n","<br>",$texto) ;
// --> Fin c�digo
return $texto ;
}
}
// Funci�n para poner caretos en los mensajes
if($caretos == "ON") {
function caretos($texto) {
// --> Inicio caretos
$texto = str_replace(":D","[:alegre.gif:]",$texto) ;
$texto = str_replace(":8","[:asustado.gif:]",$texto) ;
$texto = str_replace(":P","[:burla.gif:]",$texto) ;
$texto = str_replace(":S","[:confundido.gif:]",$texto) ;
$texto = str_replace(":(1","[:demonio.gif:]",$texto) ;
$texto = str_replace(":(2","[:demonio2.gif:]",$texto) ;
$texto = str_replace(":?","[:duda.gif:]",$texto) ;
$texto = str_replace(":-(","[:enojado.gif:]",$texto) ;
$texto = str_replace(";)","[:guino.gif:]",$texto) ;
$texto = str_replace(":'(","[:llorar.gif:]",$texto) ;
$texto = str_replace(":lol","[:lol.gif:]",$texto) ;
$texto = str_replace(":M","[:moda.gif:]",$texto) ;
$texto = str_replace(":|","[:neutral.gif:]",$texto) ;
$texto = str_replace(":)","[:risa.gif:]",$texto) ;
$texto = str_replace(":-)","[:sonrisa.gif:]",$texto) ;
$texto = str_replace(":R","[:sonrojado.gif:]",$texto) ;
$texto = str_replace(":O","[:sorprendido.gif:]",$texto) ;
$texto = str_replace(":(","[:triste.gif:]",$texto) ;
// --> Fin caretos
$texto = str_replace("[:","<img src=\"eforo_caretos/",$texto) ;
$texto = str_replace(":]","\" width=\"15\" height=\"15\">",$texto) ;
return $texto ;
}
}
// Funci�n para palabras censuradas
if($censurar == "ON") {
function censurar($texto) {
// --> Inicio palabras
$texto = str_replace("insulto","***",$texto) ;
// --> Fin palabras
return $texto ;
}
}
if($temaid) {
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid'") ;
$datos = mysql_fetch_array($resp) ;
?>
<p class="tema"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>">� <? echo $datos[tema] ?></a>
<p>
<?
mysql_free_result($resp) ;
}
if($foroid) {
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
$foro = " � <a href=\"foro.php?foroid=$foroid\">$datos[foro]</a>" ;
mysql_free_result($resp) ;
}
?>
<p><a href="foro.php">Indice del foro</a><? echo $foro ?>
<p>
<?
// Se muestra el enlace para responder solamente cuando se est� dentro de un tema
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<?
if($foroid) {
if($temaid) {
$mensaje = " <b>|</b> <a href=\"fororesponder.php?foroid=$foroid&temaid=$temaid\">Responder</a>" ;
}
?>
<td>
<a href="foronuevo.php?foroid=<? echo $foroid ?>">Nuevo tema</a><? echo $mensaje ?>
</td>
<?
}
// Se muestra un enlace para que un usuario nuevo se pueda registrar o si ya est�
// registrado se pueda conectar, si el usuario ya est� conectado se muestran 3
// enlaces, uno para mensajes privados, otro para editar el perfil y otro para desconectarse.
if(!$HTTP_COOKIE_VARS[unick]) {
$usuario = "<a href=\"fororegistrar.php\">Registrar</a> <b>|</b> <a href=\"foroentrar.php\">Conectar</a>" ;
}
else {
$usuario = "<a href=\"foroprivados.php\">Mensajes</a> <b>|</b> <a href=\"foroperfil.php\">Perfil</a> <b>|</b> <a href=\"forosalir.php\">Salir</a>" ;
}
?>
<td>
<div align="right">
<? echo $usuario ?>
</div>
</td>
</tr>
</table><br>
<?
if(!$HTTP_COOKIE_VARS[unick]) {
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<div align="right">
<form method="post" action="foroentrar.php">
<input type="hidden" name="url" value="<? echo "$PHP_SELF?$QUERY_STRING" ?>">
<b>Nick:</b>
<input type="text" name="nick" size="10" maxlength="20" class="form">
<b>Contrase�a:</b>
<input type="password" name="contrasena" size="10" maxlength="20" class="form">
<input type="submit" name="entrar" value="Entrar" class="form">
</td>
<td>
</form>
</div>
</td>
</tr>
</table><br>
<?
}
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td class="tabla_mensaje" valign="top">
<?
$resp = mysql_query("select id from $tabla_usuarios") ;
$totaldeusuarios = mysql_num_rows($resp) ;
$resp = mysql_query("select nick from $tabla_usuarios order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$ultimo = $datos[nick] ;
?>
Nos visitan <b><? echo $usuarios ?></b> usuarios: <b><? echo $anonimos ?></b> anonimos y <b><? echo $registrados ?></b> registrados<br><br>
<? echo $renlinea ?>
</td>
<td class="tabla_mensaje" valign="top">
Total de usuarios registrados en el foro: <b><? echo $totaldeusuarios ?></b><br>
Ultimo usuario registrado: <a href="forousuarios.php?u=<? echo $ultimo ?>"><? echo $ultimo ?></a><br>
<a href="forousuarios.php">Ver usuarios</a>
</td>
</tr>
</table><br>
<?
// Muestra los mensajes del foro seleccionado
if($foroid) {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<?
// Muestra el tema y los mensajes
if($temaid) {
mysql_query("update eforo_mensajes set visitas=visitas+1 where id='$temaid'") ;
$resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
$totaldemensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_mensajes ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where forotema='$temaid' order by id asc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
while($datos = mysql_fetch_array($resp)) {
$fecha = fecha2($datos[fecha]) ;
// Agregar c�digo especial
if($codigo == "ON") { $datos[mensaje] = codigo($datos[mensaje]) ; }
// Agregar caretos en los mensajes
if($caretos == "ON") { $datos[mensaje] = caretos($datos[mensaje]) ; }
// Censurar palabras
if($censurar == "ON") { $datos[mensaje] = censurar($datos[mensaje]) ; }
$datos[mensaje] = str_replace("\r\n","<br>",$datos[mensaje]) ;
// El total de mensajes del usuario
$resp2 = mysql_query("select mensajes from $tabla_usuarios where nick='$datos[usuario]'") ;
$datos2 = mysql_fetch_array($resp2) ;
$mensajes = $datos2[mensajes] ;
mysql_free_result($resp2) ;
// Si el mensaje ha sido editado se muestra la fecha de la �ltima modificaci�n 
if($datos[fecha] != $datos[editado]) {
$editado = fecha2($datos[editado]) ;
$editado = "<br><br><div style=\"font-size: 7pt\"><b>Editado por �ltima vez el $editado</b></div>" ;
}
else {
$editado = "" ;
}
if($datos[id] == $datos[forotema]) {
$borrar = "tema" ;
}
else {
$borrar = "mensaje" ;
}
$resp3 = mysql_query("select id,avatar from $tabla_usuarios where nick='$datos[usuario]'") ;
$datos3 = mysql_fetch_array($resp3) ;
if($datos3[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<img src=\"eforo_imagenes/avatares/$datos3[id].$datos3[avatar]\">" ;
}
mysql_free_result($resp3) ; 
?>
<tr>
<td width="25%" valign="top" class="tabla_mensaje">
<b><? echo $datos[usuario] ?></b><br>
<div style="font-size: 7pt"><b>Mensajes:</b> <? echo $mensajes ?></div><br>
<? echo $avatar ?>
</td>
<td width="75%" valign="top" class="tabla_mensaje">
<a name="<? echo $datos[id] ?>"></a>
<b>Tema:</b> <? echo $datos[tema] ?><br>
<hr color="#757575"><br>
<? echo "$datos[mensaje]$editado" ?>
</td>
</tr>
<tr>
<td class="tabla_mensaje"><div style="font-size: 7pt"><? echo $fecha ?></div></td>
<td class="tabla_mensaje"><a href="foroeditar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&mensajeid=<? echo $datos[id] ?>">Editar</a> | <a href="foroborrar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&mensajeid=<? echo $datos[id] ?>&borrar=<? echo $borrar ?>">Borrar</a></td>
</tr>
<?
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldemensajes) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
else {
// Muestra los temas
$resp = mysql_query("select id from eforo_mensajes where foro='$foroid' and foromostrar='1'") ;
$totaldetemas = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_temas ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where foro='$foroid' and foromostrar='1' order by ultimo desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
$mensajes = mysql_num_rows($resp) ;
if($mensajes == 0) {
echo "<p align=center>No se encontraron mensajes." ;
}
else {
?>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td width="40%" class="tabla_titulo"><div align="center" class="t1">Tema</div></td>
<td width="10%" class="tabla_titulo"><div align="center" class="t1">Vis</div></td>
<td width="10%" class="tabla_titulo"><div align="center" class="t1">Res</div></td>
<td width="20%" class="tabla_titulo"><div align="center" class="t1">Autor</div></td>
<td width="20%" class="tabla_titulo"><div align="center" class="t1">Ultimo</div></td>
</tr>
<?
while($datos = mysql_fetch_array($resp)) {
$resp2 = mysql_query("select id,fecha,usuario from eforo_mensajes where forotema='$datos[id]' order by id desc limit 1") ;
$datos2 = mysql_fetch_array($resp2) ;
$primero = fecha1($datos[fecha]) ;
$ultimo = fecha1($datos2[fecha]) ;
?>
<tr>
<td class="tabla_mensaje"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $datos[id] ?>">� <? echo $datos[tema] ?></a></td>
<td class="tabla_mensaje"><div align="center"><? echo $datos[visitas] ?></div></td>
<td class="tabla_mensaje"><div align="center"><? echo $datos[mensajes] ?></div></td>
<td class="tabla_mensaje"><div align="center"><b><? echo $datos[usuario] ?></b><br><span style="font-size: 7pt"><? echo $primero ?></span></div></td>
<td class="tabla_mensaje"><div align="center"><b><? echo $datos2[usuario] ?></b><br><span style="font-size: 7pt"><? echo $ultimo ?></span></div></td>
</tr>
<?
mysql_free_result($resp2) ;
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldetemas) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
}
}
// Mostrar los foros
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td colspan="2" class="tabla_titulo"><div class="t1" align="center">Categor�a</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Tem</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Men</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Ultimo mensaje</div></td>
</tr>
<?
$resp = mysql_query("select * from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td colspan="5" class="tabla_subtitulo"><div class="t1"><? echo $datos[categoria] ?></div></td>
</tr>
<?
$resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
while($datos2 = mysql_fetch_array($resp2)) {
// Obtener el ultimo mensaje enviado
$resp3 = mysql_query("select id,forotema,fecha,usuario from eforo_mensajes where foro='$datos2[id]' order by id desc limit 1") ;
if(mysql_num_rows($resp3) != 0) {
$datos3 = mysql_fetch_array($resp3) ;
$usuario = $datos3[usuario] ;
$fecha = fecha1($datos3[fecha]) ;
$ultimo = "<b>$usuario</b> <a href=foro.php?foroid=$datos2[id]&temaid=$datos3[forotema]#$datos3[id]><img src=eforo_imagenes/ultimo.gif width=18 height=9 border=0></a><br><span style=\"font-size: 7pt\">$fecha</span>" ;
}
else {
$ultimo ="Ninguno" ;
}
?>
<tr>
<td width="10%" class="tabla_mensaje"><div align="center"><img src="eforo_imagenes/foco.gif" width="15" height="20" border="0"></div></td>
<td width="50%" class="tabla_mensaje"><a href="foro.php?foroid=<? echo $datos2[id] ?>"><? echo $datos2[foro] ?></a><br><? echo $datos2[descripcion] ?></td>
<td width="10%" class="tabla_mensaje"><div align="center"><? echo $datos2[temas] ?></div></td>
<td width="10%" class="tabla_mensaje"><div align="center"><? echo $datos2[mensajes] ?></div></td>
<td width="20%" class="tabla_mensaje"><div align="center"><? echo $ultimo ?></div></td>
</tr>
<?
mysql_free_result($resp3) ;
}
mysql_free_result($resp2) ;
}
?>
</table>
<?
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.0</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
