<?
include("ulogin.php") ;
if($datos["nivel"] < 10) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>