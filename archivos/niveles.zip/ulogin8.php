<?
include("ulogin.php") ;
if($datos["nivel"] < 8) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>