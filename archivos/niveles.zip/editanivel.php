<?
include("config.php") ;
mysql_query("update usuarios set nivel='$nivel' where nick='$nick'") ;
mysql_close($conectar) ;
echo " El usuario <b>$nick</b> a sido puesto a Nivel: <b>$nivel</b>
<br><br>
<a href=\"univeles.php\">Volver a la lista de usuarios y Niveles</a>
<br><br>
<a href=\"javascript:history.back(1)\">Volver a cambiar el nivel a $nick</a>
"
?>
