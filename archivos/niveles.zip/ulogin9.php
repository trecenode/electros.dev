<?
include("ulogin.php") ;
if($datos["nivel"] < 9) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>