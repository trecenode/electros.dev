<?
include("ulogin.php") ;
if($datos["nivel"] < 3) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>