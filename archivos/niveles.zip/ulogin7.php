<?
include("ulogin.php") ;
if($datos["nivel"] < 7) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>