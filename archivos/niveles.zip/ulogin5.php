<?
include("ulogin.php") ;
if($datos["nivel"] < 5) {
?>
<script>location="index.php?id=unonivel"</script>
<?
exit ;
}
?>