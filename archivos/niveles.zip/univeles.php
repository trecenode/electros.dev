<script>
function revisar() {
if(editanivel.nivel.value > "9") { alert('El nivel tiene que ser un valor entre 1 y 9') ; return false ; }
if(editanivel.nivel.value < "1") { alert('El nivel tiene que ser un valor entre 1 y 9') ; return false ; }
}
</script>
<?
include("config.php") ;
if($u) {
$resp = mysql_query("select id,nick,nivel from usuarios where id='$u'") ;
$datos = mysql_fetch_array($resp) ;
echo "
<form name=editanivel action=editanivel.php method=post onsubmit=\"return revisar()\">
<table border=0 cellpadding=2 cellspacing=0>
<tr>
<td><b>Nick:</b></td>
<td><input name=nick value=$datos[nick] type=text readonly=true></td>
</tr>
<tr>
<td><b>Nivel:</b></td>
<td>
<input name=nivel type=text value=$datos[nivel] size=1 maxlength=1>
<input type=submit name=editar value=Editar class=form>
</td>
</tr>
</table>
</form>
<br>
<a href=javascript:history.back(1)>Volver a lista de Niveles</a>
" ;
}
else
{
?>
<form name="form1" method="post" action="<?PHP $PHP_SELF ?>">
Ordenar por: <select name="orden" id="orden" onChange="submit()">
      <option></option>
	  <option>nick</option>
      <option>fecha</option>
      <option>nivel</option>
    </select>  
</form>
<?
if($orden == '') {
$orden = nick ;
}

$resp = mysql_query("select id,nick,nivel,fecha from usuarios order by $orden asc") ;
$usuarios = mysql_num_rows($resp) ;
echo "
<table border=0 cellpadding=5 cellspacing=1>
<tr bgcolor=#679CD8>
<td><b>Nick</b></td>
<td><b>Antiguedad</b></td>
<td><b>Nivel</b></td>
</tr>
" ;
while($datos = mysql_fetch_array($resp)) {
$fecha = $datos[fecha] ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diames de $mesesano[$mesano] del $ano" ;
echo "
<tr bgcolor=#D8F3FC>
<td>$datos[nick]</td>
<td>$fecha</td>
<td align=center><b><a href=?id=univeles&u=$datos[id]>$datos[nivel]</a></b></td>
</tr>
" ;
}
echo "</table>" ;
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>