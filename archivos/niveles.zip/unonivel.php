<div align="center">
  <p>Lo siento <b><? echo $_COOKIE["unick"] ?></b>, no tienes nivel de usuario suficiente para ver esta p�gina.</p>
  <p><a href="index.php">Volver</a></p>
</div>