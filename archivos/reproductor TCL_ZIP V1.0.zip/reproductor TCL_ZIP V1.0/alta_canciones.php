<?php require_once('Connections/localhost.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO repromp3 (carpeta) VALUES (%s)",
                       GetSQLValueString($_POST['carpeta'], "text"));

  mysql_select_db($database_localhost, $localhost);
  $Result1 = mysql_query($insertSQL, $localhost) or die(mysql_error());

  $insertGoTo = "mp3player.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
}
if($_GET['borrar']=='0') {
mysql_select_db($database_localhost, $localhost);
$query_existe = "DELETE FROM repromp3 WHERE carpeta='".$_GET['carpeta']."'";
$existe = mysql_query($query_existe, $localhost) or die(mysql_error());
}
?>
<?
//leemos directorio
$dir = "musica/" ;
$listacarpetas = array();
$fdir = opendir($dir);
while($i = readdir($fdir)) {
  	   $playlist[$n] = $i;
  	   $n++;
}
closedir($fdir);
array_multisort($playlist);
?>
<table width="390" height="78" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="256" height="19" bgcolor="#FFFFFF"><strong>Carpeta</strong></td>
    <td width="72" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="40" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
<?  
$numero_carpetas=5;
$paginas=(sizeof($playlist))/5;
$pagina_inicial = $_GET['i'];
//Calculamos el inicio
if($_GET['i']){
$i=($_GET['i']-1)*5;
}else{
$i=1;
}

//calculamos el final
$final= $i+$numero_carpetas;
if ($final > sizeof($playlist)){
$final = sizeof($playlist);
}

$u=1;
for ($i; $i<$final; $i++) { //Por todo $i hasta el final de la cadena
//Color si color no
if ($u==1) { 
$u=2;
$color = "#DFECF7";
}else{
$u=1;
$color = "#C6DDF0";
}
if($playlist[$i]!='...' AND $playlist[$i]!='..' AND $playlist[$i]!='' AND $playlist[$i]!=' '){
// miramos si esta en la lista
mysql_select_db($database_localhost, $localhost);
$query_existe = "SELECT * FROM repromp3 WHERE carpeta = '".addslashes($playlist[$i])."'";
$existe = mysql_query($query_existe, $localhost) or die(mysql_error());
$row_existe = mysql_fetch_assoc($existe);
$totalRows_existe = mysql_num_rows($existe);
?>
<tr>
    <td height="22" align="center" valign="middle" bgcolor="<? echo $color ; ?>"><? echo $playlist[$i] ?></td>
    <td align="center" valign="middle" bgcolor="<? echo $color ; ?>"><?php if ($totalRows_existe == 0) { // Show if recordset empty ?>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
<input type="submit" value="Reprodu�r">
  <input type="hidden" name="carpeta" value="<? echo $playlist[$i] ;?>">
  <input type="hidden" name="MM_insert" value="form1">
</form>
  <?php } // Show if recordset empty ?></td>
    <td align="center" valign="middle" bgcolor="<? echo $color ; ?>"><?php if ($totalRows_existe > 0) { // Show if recordset not empty ?>
          <a href="mp3player.php?borrar=0&amp;carpeta=<? echo $playlist[$i] ?>">Borrar</a>
    <?php } // Show if recordset not empty ?></td>
  </tr>
  <? } } ?>
<tr>
  <td height="22" colspan="3" align="center" valign="middle" bgcolor="#FFFFFF"><div align="center">
    <? 
for($r=1; $r<= $paginas ; $r++){
?>
 <? if($r!=$pagina_inicial){ ?>   
	<a href="mp3player.php?i=<? echo $r; ?>"><? } echo $r ; if($r!=$pagina_inicial){ ?></a>
    
	
	<? 
} }
?>
  </div></td>
  </tr>
</table> 
<?php
mysql_free_result($existe);
?>

