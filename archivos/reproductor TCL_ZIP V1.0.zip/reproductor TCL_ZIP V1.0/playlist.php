<?php require_once('Connections/localhost.php'); ?>
<?php
mysql_select_db($database_localhost, $localhost);
$query_lista_carpetas = "SELECT * FROM repromp3";
$lista_carpetas = mysql_query($query_lista_carpetas, $localhost) or die(mysql_error());
$row_lista_carpetas = mysql_fetch_assoc($lista_carpetas);
$totalRows_lista_carpetas = mysql_num_rows($lista_carpetas);


/*
Hi Guys ! thanks for downloading this script. It's a little addon for my
Flash MP3 Player that scans a directory for mp3 files and automatically
creates the corresponding playlist. Just throw it in the same dir as your
mp3player.swf file and, just below here, set the directory to scan for.
The default setup supposes you have your mp3 files in the "mp3/" subdir.

Next, in your mp3player.html file, give the mp3 player the playlist parameter
that points to this script, playlist.php: 

  <object type="application/x-shockwave-flash" width="280" height="280"
    data="mp3player.swf?playlist=playlist.php">
  <param name="movie" value="mp3player.swf?playlist=playlist.php" />
  </object>

Good luck !
*/
//***************************************************************repeticion por carpetas
echo "<player showDisplay=\"yes\" showPlaylist=\"yes\" autoStart=\"yes\">\n";
?>
<?php do { ?>
  <?
//Empezamos el listado de las carpetas:
$dir = "musica/".$row_lista_carpetas['carpeta']."/";
// reading the directory and inserting the mp3 files in the playlist array
$n = 0;
$playlist = array();
$fdir = opendir($dir);
while($mp3 = readdir($fdir)) {
   // if a .mp3 string is found, add the file to the array
   if (strpos(strtolower($mp3),".mp3") !== false) {
      echo "  <song path=\"$dir$mp3\" title=\"".str_replace(".mp3","",$mp3)."\" />\n";
}
  	} 

// close the directory and sort the array
closedir($fdir);
?>
  <?php } while ($row_lista_carpetas = mysql_fetch_assoc($lista_carpetas)); ?><? 
//**********************************************************************Fin repeticion carpetas
echo "</player>";
?>
<?php
mysql_free_result($lista_carpetas);
?>
