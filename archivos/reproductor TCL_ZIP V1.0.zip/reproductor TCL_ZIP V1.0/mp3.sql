#
# Table structure for table 'repromp3'
#

CREATE TABLE `repromp3` (
  `id` int(11) NOT NULL auto_increment,
  `carpeta` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

