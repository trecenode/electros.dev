<? 
header("ETag: PUB" . time());
header("Last-Modified: " . gmdate("D, d M Y H:i:s", time()-10) . " GMT");
header("Expires: " . gmdate("D, d M Y H:i:s", time() + 5) . " GMT");
header("Pragma: no-cache");
header("Cache-Control: max-age=1, s-maxage=1, no-cache, must-revalidate");
session_cache_limiter("no-store");
	?><html>
<head>
<title>Reproductor TCL_ZIP</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css">
<!--
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
a:hover {
	color: #999999;
}
a:active {
	color: #FFFFFF;
}
-->
</style></head>
<body>
<br>
<? $aleatorio = rand(); ?>
<table width="750" height="328" border="0" align="center" cellpadding="0" cellspacing="0" background="imatges/fondo.gif">
  <tr>
    <td width="300" rowspan="2" align="center" valign="middle"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
    data="repromp3.swf?playlist=playlist.php&no_cache=<? echo $aleatorio;?>" type="application/x-shockwave-flash" width="280" height="280" align="absmiddle" id="<? echo $aleatorio;?>">
      <param name="movie" value="repromp3.swf?playlist=playlist.php&no_cache=<? echo $aleatorio;?>" /><param name="BGCOLOR" value="#FFFF99">
      <embed src="repromp3.swf?playlist=playlist.php&no_cache=<? echo $aleatorio;?>" width="280" height="280" align="absmiddle" bgcolor="#FFFF99"></embed>
    </object></td>
    <td align="center" valign="middle"><?php include('listas.php'); ?></td>
  </tr>
  <tr>
    <td width="470" align="center" valign="middle"><p>&nbsp;</p>
      <?php include('alta_canciones.php'); ?></td>
  </tr>
</table>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
</body>
</html>