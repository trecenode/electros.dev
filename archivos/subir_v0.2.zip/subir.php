<?

/////////////////////////////////////////////////////////
//////////// Manipulador de Archivos ////////////////////
////////////       Version 0.2       ////////////////////
////////////         By Wign         ////////////////////
/////////////////////////////////////////////////////////

// Tu contrase�a
$tucontrasena = 'ACATUCONTRASE�A' ;
if(!empty($_POST['contrasena']) && $_POST['contrasena'] == $tucontrasena) {
setcookie('permitido',1,time()+3600) ;
}
if(!empty($_GET['salir'])) {
setcookie("permitido") ;
}
if(!empty($_COOKIE['permitido'])) {
echo '<p><a href="'.$_SERVER['PHP_SELF'].'?salir=1">Salir</a><br>' ;
?>


<html>
<head>
<title>Manipulador de archivos by Wign</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<center>Manipulador de archivos by Wign versi�n 0.2</center>
Este es un manipulador de archivos muy simple, basicamente te permite subir archivos via web, lo que es muy conveniente en servidores que bloquean
extensiones, esto te permite pasarlas. Y tambien te permite eliminar y renombrar los archivos del directorio en que esta esta pagina. El dise�o
es muy malo, pero igual era para mi uso personal, aunque en el futuro talvez lo mejore y ponga otras cosas.<br>
Wign</center>
<body>
<h2>Enviar un Archivo</h2>
<form enctype="multipart/form-data" action="<?PHP echo $PHP_SELF ?>" 
method="post">
<div align="left">
<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
Seleccionar: 
<input name="userfile" type="file">
<input type="submit" name="submit" value="Enviar">
</div>
</form>
<?PHP 

// copy to this directory 
$dir="./"; 

// copy the file to the server 
if (isset($submit)){ 

if (!is_uploaded_file ($userfile)){ 

echo "<b>$userfile_name</b> Al parecer no ha seleccionado un archivo o ha habido un error.<br>"; 
} 
if (is_uploaded_file ($userfile)){ 
move_uploaded_file($userfile,$dir.$userfile_name) ;
} 

echo "Archivo subido correctamente. <a href=\"$userfile_name\" target=\"_blank\" >Abrirlo</a>"; 
} 

?>

<br><h2>Selecciona un archivo a borrar o Renombrar</h2>
  <?
if(isset($_POST['enviar'])){ 
$nombre = $_POST['nombre'];
unlink("$nombre"); 
echo"El archivo $nombre ha sido borrado satifactoriamente<br> ";
if(!file_exists($nombre)){
echo "Al parecer el archivo ya fue eliminado, porque no fue encontrado en el directorio (comprobaci�n 2)";
}
}else{ 
}
?>
  <?
//renombrar
if(isset($_POST['renombrar'])){ 
$nombre = $_POST['nombre'];
$nombre_f = $_POST['nombre_f'];
rename("$nombre","$nombre_f");
echo"El archivo $nombre ha sido renombrado satifactoriamente<br> ";
}else{ 
}
?>
  <br>
  <form name="form1" method="post" action="<? $PHP_SELF ?>">
    <table width="70%"  border="1" cellpadding="0" cellspacing="0" bordercolor="black">
      <tr>
        <td></td><td>Nombre del archivo</td><td>Tipo</td><td>Peso</td><td>Ultima Modificacion</td><td>Renombrar</td>
</tr>
<?
//definimos el path de acceso
$path="./";

//instanciamos el objeto
$dir=dir($path);

//Mostramos las informaciones
echo "Directorio ".$dir->path.":<br><br>";

while ($elemento = $dir->read())
{
//Peso del archivo
$size=filesize("$elemento");

//Tipo de archivo
$type=filetype("$elemento");

//Ultima Modificacion
$Umodificacion=filemtime("$elemento");

//Permisos

//imprimimos los archivos actuales
echo "<tr><td><input type='radio' name='nombre' id='nombre' value='$elemento'></td><td> $elemento</td><td>",$type,"</td><td>",$size,"</td><td>".date("F d Y H:i:s.",$Umodificacion)."</td><td> Renombrar a (no olvide seleccionar la casilla 'circulo'):<INPUT TYPE='text' NAME='nombre_f' /><td><tr>";
}
//Cerramos el directorio
$dir->close();
?>
</table>

        <br><input name="enviar" type="submit" id="enviar" value="Borrar"><input name="renombrar" type="submit" id="enviar" value="Renombrar">
<br>

</form>
</body>
</html>

<?
}
else {
?>
<center>Contrase�a:
<form method="post" action="subir.php">
<input type="password" name="contrasena" />
<input type="submit" value="Enviar" />
</form></center>
<?
}
?>
