<?
$extension = ".zip"; // EXTENSION DE ARCHIVOS 

if (file_exists("$archivo$extension")) { 
     header("location: $archivo$extension"); 
     $file = fopen("contador/$archivo.txt","r"); // contador de downloads 
     $count = fread($file, 100); 
     $countplus = ($count + 1); 
     fclose($file); 
     $fileb = fopen("contador/$archivo.txt","w"); 
     fwrite($fileb, $countplus, 100); 
     fclose($fileb); 
}

else { echo "El archivo <b>$archivo$extension</b> no existe"; }

?>
