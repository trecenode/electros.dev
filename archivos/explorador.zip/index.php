<html>
<head><title>Webexplorer</title>
<style>
/* Cuerpo del modulo */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter:dropshadow(color=#000000,offx=1, offy=1, positive=1), glow(color=#000000, strength=0) ; 
height: 1 ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
</head>
<body>
<div align="center"><br>
  <br>
  <br>
  <table width="52%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="left"><strong><font size="4">Webexplorer</font></strong></div></td>
    </tr>
  </table>
  <br>
  <br>
  <br>
<table width='52%' border='0' cellspacing='0' cellpadding='0'>
  <tr>
    <td>  <?
// Configuracion
$path_absoluto = "web/";

if(!$secciones) {
// Recorremos el directorio
$path = $path_absoluto;
$dir = opendir($path);
while ($elemento = readdir($dir))
{
 // Extensiones en los archivos
 $extensiones = explode(".",$elemento) ;
 $nombre = $extensiones[0] ;
 $nombre2  = $extensiones[1] ;
 if ($nombre2 == "") { $nombre2 = "carpeta.gif";}
 if(!file_exists("$nombre2.gif") && $nombre2 != "carpeta.gif") { $nombre2 = "defecto.gif";}
 if(file_exists("$nombre2.gif") && $nombre2 != "carpeta.gif") { $nombre2 = "$nombre2.gif";}
 // Fin extensiones en los archivos
 
if($nombre2 != "carpeta.gif" && $elemento != "." && $elemento != ".."){
echo "<a href='$path_absoluto$elemento'><img src='$nombre2' border='0'> $elemento<br></a>" ;
}
if($nombre2 == "carpeta.gif" && $elemento != "." && $elemento != ".."){
echo "<a href='index.php?secciones=$elemento/'><img src='$nombre2' border='0'> <b>$elemento</b><br></a>" ;
}
}
closedir($dir);
}
// Anti-hackeos
if(ereg("\.\./",$secciones) || ereg("/\.\.",$secciones) || ereg("\\\\.\.",$secciones) || ereg("\.\.\\\\",$secciones)){
    die("Hacking Attempt");
}
if($secciones == "") { $path3 = $path_absoluto; }
if($secciones != "") { $path3 = $path_absoluto.$_GET["secciones"]."/"; }
if($secciones != "") { $sec = ".. <a  href='javascript:history.go(-1);'> Atras</a><br><br>";}
if($secciones != "") { $seccion = "Directorio : <b>$secciones</b><hr>$sec";}
echo "<div align=left>$seccion</div>";

if ($dir3 = @opendir($path3)) {
  while (($file3 = readdir($dir3)) !== false && $secciones) {
  
    // Extensiones en los archivos
	$extensiones = explode(".",$file3) ;
    $nombre = $extensiones[0] ;
    $nombre2  = $extensiones[1] ;
	if ($nombre2 == "") { $nombre2 = "subcarpeta.gif";}
	if(!file_exists("$nombre2.gif") && $nombre2 != "subcarpeta.gif") { $nombre2 = "defecto.gif";}
	if(file_exists("$nombre2.gif") && $nombre2 != "carpeta.gif") { $nombre2 = "$nombre2.gif";}
	// Fin Extensiones en los archivos
if ($nombre2 != "subcarpeta.gif" && $file3 != "." && $file3 != "..") {
echo "<a href='$path_absoluto$secciones$file3'><img src='$nombre2' border='0'> $file3</a><br>";
}
if ($nombre2 == "subcarpeta.gif" && $file3 != "." && $file3 != "..") {
echo "<a href='index.php?secciones=$secciones$file3/'><img src='$nombre2' border='0'> $file3</a><br>";
}
}
closedir($dir3);
}
// fin secciones
?></td>
  </tr>
</table>
  <br>
  <br>
  <br>
  <table width="52%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td height="217">
        <?
if($enviar) {
if($archivo != "" ) {
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;

if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
// Anti-hackeos
if(ereg("\.\./",$archivo_name) || ereg("/\.\.",$archivo_name) || ereg("\\\\.\.",$archivo_name) || ereg("\.\.\\\\",$archivo_name)){
    die("Hacking Attempt");
}
copy($archivo,"$path_absoluto$secciones$archivo_name") ;
echo "<script>location='$_SERVER[REQUEST_URI]'</script>";
}
else {
echo "El archivo <b>$archivo_name</b> supera los 10 Mb" ;
}
}
?>
<?
if($mkdir) {
// Anti-hackeos
if(ereg("\.\./",$subcarpeta) || ereg("/\.\.",$subcarpeta) || ereg("\\\\.\.",$subcarpeta) || ereg("\.\.\\\\",$subcarpeta)){
    die("Hacking Attempt");
}
mkdir("$path_absoluto$secciones$subcarpeta/", 0777) ;
echo "<script>location='$_SERVER[REQUEST_URI]'</script>";
}
?>
        <br> <br>
        <strong>Subir </strong>:<br>
        <br> <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
          Archivo: 
          <input type="file" name="archivo" class="form">
          <input type="submit" name="enviar" value="Enviar" class="form">
        </form>
        <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
          Directorio: 
          <input type="text" name="subcarpeta" class="form">
          <input type="submit" name="mkdir" value="Crear" class="form">
       <br></form>
        
        <?
// Funcion para borrar los directorios
function deldir($dir)
{
  $handle = opendir($dir);
  while (false!==($FolderOrFile = readdir($handle)))
  {
     if($FolderOrFile != "." && $FolderOrFile != "..")
     {
     } 
  }
  closedir($handle);
  if(rmdir($dir))
  { $success = true; }
  return $success; 
} 
// Realizamos la accion
if($borrar && !strstr($archivo,"/")) {
unlink("$path_absoluto$secciones$archivo") ;
echo "<script>location='$_SERVER[REQUEST_URI]'</script>";
}
else if ($borrar && strstr($archivo,"/")) {
deldir("$path_absoluto$secciones$archivo");
echo "<script>location='$_SERVER[REQUEST_URI]'</script>";
}
else {
}
?>
        <br> <br>
        <strong>Borrar :</strong><br> <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
          <br>
          Archivo: 
          <select name="archivo" class="form">
            <?
if($secciones == "") { $path6 = $path_absoluto; }
if($secciones != "") { $path6 = $path_absoluto.$_GET["secciones"]."/"; }
$dir6 = opendir($path6);
while ($elemento6 = readdir($dir6))
{
    $extensiones = explode(".",$elemento6) ;
    $nombre = $extensiones[0] ;
    $nombre2  = $extensiones[1] ;
	
if($nombre2 == "" && $elemento6 != "." && $elemento6 != ".."){
echo "<option value='$elemento6/'>$elemento6/</option>" ;
}
if($nombre2 != "" && $elemento6 != "." && $elemento6 != ".."){
echo "<option value='$elemento6'>$elemento6</option>" ;
}
}
closedir($dir6);
?>
          </select>
          <input name="borrar" type="submit" class="form" id="borrar" value="Borrar">
        </form>
        <strong> 
        <?
if($rename) {
// Anti-hackeos
if(ereg("\.\./",$nuevonombre) || ereg("/\.\.",$nuevonombre) || ereg("\\\\.\.",$nuevonombre) || ereg("\.\.\\\\",$nuevonombre)){
    die("Hacking Attempt");
}
rename("$path_absoluto$secciones$nombreantiguo","$path_absoluto$secciones$nuevonombre") ;
echo "<script>location='$_SERVER[REQUEST_URI]'</script>";
}
?>
        <br>
        <br>
        Renombrar :</strong> 
        <form method="post" action="<? echo $_SERVER[REQUEST_URI] ?>" enctype="multipart/form-data">
          <div align="left"><br>
            Nombre antiguo: 
            <select name="nombreantiguo" class="form">
              <?
if($secciones == "") { $path7 = $path_absoluto; }
if($secciones != "") { $path7 = $path_absoluto.$_GET["secciones"]."/"; }
$dir7 = opendir($path7);
while ($elemento7 = readdir($dir7))
{
    $extensiones = explode(".",$elemento7) ;
    $nombre = $extensiones[0] ;
    $nombre2  = $extensiones[1] ;
	
if($nombre2 == "" && $elemento7 != "." && $elemento7 != ".."){
echo "<option value='$elemento7/'>$elemento7/</option>" ;
}
if($nombre2 != "" && $elemento7 != "." && $elemento7 != ".."){
echo "<option value='$elemento7'>$elemento7</option>" ;
}
}
closedir($dir7);
?>
            </select>
            Nuevo nombre: 
            <input name="nuevonombre" type="text" class="form" id="nuevonombre">
            <input name="rename" type="submit" class="form" id="Renombrar" value="Renombrar">
          </div>
        </form>
      </td>
    </tr>
  </table>
  <br>
  <a href="http://recursosphp.iefactory.com/scripts/explorador.zip">Explorador</a> by elcidop</div>
</body>
</html>