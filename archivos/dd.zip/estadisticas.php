<html>
<head>
<title>Estadisticas</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
      body  {
          font-family : Verdana, Arial, Helvetica, sans-serif;
          font-size : 12px;
      }
     tbody {
          font-family : Verdana, Arial, Helvetica, sans-serif;
          font-size : 12px;
      }
     table {
          font-family : Verdana, Arial, Helvetica, sans-serif;
          font-size : 12px;
      }
     a {
          color : blue;
          font-weight : bold;
          text-decoration : none;
      }
     input {
          font-family : Verdana, Arial, Helvetica, sans-serif;
          font-size : 12px;
      }

</style>
</head>

<body>
<font size="2"><strong>CONTROL DE ESTADISTICAS DE LOS USUARIOS DE TU PAGINA</strong></font><br>
<br>
<?php
# Numero de registros que se mostraran por p�gina.
$limiteRegistros = 10;

# Ubicaci�n del fichero de texto.
$ficheroTexto = "estadisticas.txt";

# Leemos el contenido del fichero.
$fd = @fopen($ficheroTexto, "r");
$contenido = @fread($fd, @filesize($ficheroTexto));
@fclose($fd);

# Creamos el array.
$ficheroTexto = explode("\n", $contenido);

# Se extrae la ultimo elemento ya que este es vacio.
$ficheroTexto = array_slice($ficheroTexto, 0, -1);

# Ordenamos los elementos del array en orden inverso.
$ficheroTexto = array_reverse($ficheroTexto);

# Numero de elementos del array �sea registros del fichero.
$registrosTotales = count($ficheroTexto);

# Obtenemos el numero de p�gina actual.
$paginaActual = @$_GET["pag"];

# Si no se ha especificado el numero de p�gina se establce a 1.
if(empty($paginaActual))
{
	$paginaActual = 1;
}
# Mostramos el total de registros
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td><b>Total de registros :</b> <?=$registrosTotales?></td>
  </tr>
</table>
<br>
<table width="100%" border="1" cellpadding="2" cellspacing="2">
  <tr> 
    <td width="15%"><strong>Datos usuario</strong></td>
    <td width="12%"><strong>Datos</strong><strong> fecha</strong></td>
    <td width="25%"><strong>Datos explorador</strong></td>
    <td width="48%"><strong>Datos de las paginas</strong></td>
  </tr>
  <?
# Se crean las variables con las cuales se limitaran los registros.
$mostrarDesde = $paginaActual * $limiteRegistros - $limiteRegistros;
$mostrarHasta = $paginaActual * $limiteRegistros;

# Mostramos los registros limitandolos por medio de las variables de arriba.
for($i = $mostrarDesde;  $i < $registrosTotales AND $i < $mostrarHasta; $i++)
{
    $columna = split( "\#" , $ficheroTexto[$i]);
	// mostras solo una parte de la ip
    $columna[1] = substr($columna[1],0,9)."..";
	// Si la entrada fuera muy grande
	$entrada = $columna[4];
	if (strlen($columna[4]) > 50) {
	$columna[4] = substr($columna[4],0,45).".."; 
	}
	// Si la pagina actual fuera muy grande
	$paginaactual = $columna[7];
	if (strlen($columna[7]) > 50) {
	$columna[7] = substr($columna[7],0,45).".."; 
	}
	// Navegador
 if ( strstr($columna[6], "MSIE")) {
$navegador = "Internet Explorer";
}
else if ( strstr($columna[6], "Mozilla")) {
$navegador = "Mozilla";
}
else if ( strstr($columna[6], "Opera")) {
$navegador = "Opera";
}
else {
$navegador = substr($columna[6],0,40).".."; 
}
// Acortar idioma
if (strlen($columna[5]) > 50) {
	$columna[5] = substr($columna[5],0,40).".."; 
	}
?>
  <tr> 
    <td height="1"> <em>Usuario:</em> 
      <?=$columna[0]?>
      <div align="left"><em>Ip:</em> 
        <?=$columna[1]?>
        </div>
      <div align="left"></div></td>
    <td> <em>Dia: </em> 
      <?=$columna[2]?>
      <div align="left"><em>Hora: </em> 
        <?=$columna[3]?>
      </div>
      <div align="left"></div></td>
    <td><div align="left"><em>Navegador :</em> 
        <?=$navegador?>
        <br>
        <em>Idioma :</em> 
        <?=$columna[5]?>
        <br>
      </div></td>
    <td> <div align="left"><em>Entrada desde :<a href="<?=$entrada?>"></a></em><a href="<?=$entrada?>"> 
        <?=$columna[4]?>
        </a></div>
      <em>Pagina actual :</em> <a href="<?=$paginaactual?>"> 
      <?=$columna[7]?>
      </a></td>
  </tr>
  <?
}
?>
</table>

<table width="100%" border="0" cellpadding="2" cellspacing="2">
  <tr> 
    <td><div align="right"><?
# Solo si el total de registros es mayor a el limite de registros por p�gina
# mostraremos los enlaces para cada p�gina.
if($registrosTotales > $limiteRegistros)
{
	# Numero de enlaces que se mostraran.
	$numeroPaginas = ceil($registrosTotales / $limiteRegistros);

	# Mostramos los enlaces.
	for($i = 1; $i <= $numeroPaginas; $i++)
	{

		# Con esto no mostraremos el enlace de la p�gina actual.
		if($paginaActual == $i)
		{
			echo "| <b>".$i."</b> |";
		}
		else
		{
			echo "| <a href=".$_SERVER["PHP_SELF"]."?pag=".$i.">".$i."</a> |";
		}
	}
}

?></div></td>
  </tr>
</table>
</body>
</html>
