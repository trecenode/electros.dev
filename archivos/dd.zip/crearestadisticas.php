<?
// Si el Invitado es un usuario anonimo o es un usuario registrado, para la cookie "unick"
$usuario=$_COOKIE["unick"];
if($usuario==""){
$usuario="Invitado";
}
// Mostramos ip
if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"] != "") 
{ $ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]; } 
else { $ip = $HTTP_SERVER_VARS["REMOTE_ADDR"];
// Dia
$dia = date("d/M/Y");
// Hora
$hora = date("H:i:s");
// De donde provine el usuario o Invitado
$url=$_SERVER['HTTP_REFERER'];
if($url==""){
$url="Su PC"; 
}
// Idioma
$idioma = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
// Navegador
$navegador = $_SERVER['HTTP_USER_AGENT'];
//Pagina actual
$paginaactual = $_SERVER['REQUEST_URI'];
// Creamos las estadisticas
}
$abrir = fopen('estadisticas.txt','a'); 
fputs($abrir,$file."".$usuario."#".$ip."#".date("d/M/Y")."#".date("H:i:s")."#".$url."#".$_SERVER['HTTP_ACCEPT_LANGUAGE']."#".$_SERVER['HTTP_USER_AGENT']."#".$_SERVER['REQUEST_URI']."\r\n");
fclose($abrir);
?>