<?php
// La funcion para crear el thumbnail
function thumbnail ($imagenes, $imagen, $ancho, $alto) {
$ext = explode(".", strtolower($imagen));

switch($ext[1]) {
case 'jpg':
if (!$src_img = imagecreatefromjpeg($imagenes . $imagen)) {
echo "Error abriendo $imagenes$imagen!"; exit;
}
break;
case 'jpeg':
if (!$src_img = imagecreatefromjpeg($imagenes . $imagen)) {
echo "Error abriendo $imagenes$imagen!"; exit;
}
break;
case 'gif':
if (!$src_img = imagecreatefromgif($imagenes . $imagen)) {
echo "Error abriendo $imagenes$imagen!"; exit;
}
break;
case 'png':
if (!$src_img = imagecreatefrompng($imagenes . $imagen)) {
echo "Error abriendo $imagenes$imagen!"; exit;
}
break;
}

$dst_img = @imagecreatetruecolor($ancho, $alto);
if(!$dst_img) {
$dst_img = imagecreate($ancho, $alto);
}
imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $ancho, $alto, imagesx($src_img), imagesy($src_img));

switch($ext[1]) {
case 'jpg':
imagejpeg($dst_img);
break;
case 'jpeg':
imagejpeg($dst_img);
break;
case 'gif':
imagegif($dst_img);
break;
case 'png':
imagepng($dst_img);
break;
}

imagedestroy($dst_img);
imagedestroy($src_img);
}
//Indicamos el tipo de archivo
header("Content-type: image/jpeg");

//Definimos las variables
$imgs = ""; //Directorio de las imagenes
$img = trim(htmlstecialchars($_GET['img'])); //Imagen
$alto = trim(htmlstecialchars($_GET['h'])); //Alto nuevo para la imagen
$ancho = trim(htmlstecialchars($_GET['w'])); //Ancho nuevo para la imagen

//Finalmente creamos el thumbnail
thumbnail ($imgs, $img, $ancho, $alto);
?>