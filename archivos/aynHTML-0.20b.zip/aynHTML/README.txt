	aynHTML Editor :: wysiwyg HTML editor for IE5.5+
	Copyright (c) 2002-2003 Denis Braet

	--- Install Notes ---
	
	- To install the package, just unzip all files in a directory of your choice.
	- To make use of image uploads and other functions, the editor must be run from within a web server.
	
	--- Release History ---
	
	2002-05-05 - v0.20b

	- removed a bug which caused icons to be unavailable when embedding the editor from a different path
	- added a protocol dropdown in the links interface

	2002-05-02 - v0.19b
	
	- buttons now render correctly when the editor first loads
	- absolute paths are converted to relative paths when saving or changing to code view
	- disabling the image upload is now possible
	- added a table interface which permits merging and splitting cells
	- changed the MSMXL2.DomDocument object to the more generic Microsoft.XMLDOM

	2002-03-05 - v0.18b
	
	- rewrote the append() method, so multiple fields with the same name can be appended
	- emoticons are now loaded through http and no longer hardcoded
	- added an 'open' button, open_method property, open() method and onopen event for faster living
	- added a load_method property and an onbeforeload event for better taste

	2002-11-27 - v0.17b
	
	- added a palette property to choose the color palettes of the color picker
	- color picker loads color palettes through xml file

	2002-11-08 - v0.16b
	
	- added support for <style> tags and <link>ed stylesheets in embedding document
	- rewrote the style formatting and clear formatting routines
	- added a button to remove ms word formatting

	2002-10-29 - v0.15b
	
	- fixed bug that caused content to be inserted outside the editor

	2002-10-21 - v0.14b
	- fixed a bug with the hiding of buttons
	- added color, width and height properties
	- button loading now runs smoother

	2002-10-14 - v0.12b
	
	2002-10-14 - v0.11b
	
	2002-10-17 - v0.13b

	2002-09-18 - v0.10b
	
	

