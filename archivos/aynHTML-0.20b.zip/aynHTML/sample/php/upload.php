<?php 

// set your destination directory
// and the url to the upload directory
$dest = '~/htdocs/';
$url = '/upload/images/';

// set the umask to full permissions 
umask( 0777 ); 

// get the file's base64 encoded content and the href attribute 
$match = preg_match( '/<file\s.*?href="(.*?)".*?>(.*)<\/file>/is', $GLOBALS['HTTP_RAW_POST_DATA'], $matches ); 

if( $match ) { 
$content = base64_decode( $matches[2] ); 
$filename = $matches[1]; 

$path = explode ( '\\', $filename );
$realname = $path[ count( $path ) - 1 ];

$path = $dest . $realname;

// existing file will be overwritten 
$file = fopen( $path, 'w' ); 

// write your content to the file 
fwrite( $file, $content ); 

// close your file handle 
fclose( $file ); 


} 

$path = $url . $realname; 

$xml = '<?xml version="1.0"?><root>'; 
$xml .= '<file name="[your name here]" href="' . $path . '" />'; 
$xml .= '</root>'; 

header( 'Content-type: text/xml; charset=utf-8' ); 

echo $xml; 

?> 
