<?php

ob_start();

$site_pict_root = dirname( $_SERVER['PATH_TRANSLATED']) . '/../upload';
chdir( $site_pict_root );
$folders = array();
$dir = @opendir( '.' ) or die( 'could not find path' );

while( ( $folder = readdir( $dir ) ) !== false ) {
	is_dir( $folder ) && ! preg_match( '/^\.{1,2}$/', $folder ) && $folders = array_merge( $folders, array( filemtime( $folder ) . 'T' => $folder ) );
}

closedir( $dir );

uksort( $folders, 'strnatcmp' );

$folders = array_reverse( $folders );

$keys = array_keys($folders);

while( list( $key, $folder ) = each( $folders ) ) {
	$folders[$key] = array( $folder => array() );
	if( $dir = @opendir( $folder ) ) {
		while( ( $file = readdir( $dir ) ) !== false ) {
			if( ! preg_match( '/^\.{1,2}$/', $file ) ) {
			 	$folders[$key][$folder][] = $file;
			}
		}
		closedir( $dir );
	}
}

$xml = '<?xml version="1.0" encoding="utf-8" ?><folders>';

foreach( $folders as $filelist ) {
	if( count( $filelist[key( $filelist )] ) ) {
		$xml .= '<folder name="' . utf8_encode( key( $filelist ) ) . '">';
		foreach( $filelist[key( $filelist )] as $file ) {
			$xml .= '<file name="' . $file . '" href="' . $file . '"/>';
		}
		$xml .= '</folder>';
	}
}

$xml .= '</folders>';

header( 'Content-type: text/xml; charset=utf-8' );

echo $xml;

ob_end_flush();
?>