
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<? 
if (!$HTTP_POST_VARS){ 
?> 
<form action="contactar.php" method=post>
<font face="Verdana, Arial, Helvetica, sans-serif"><br>
Nombre:</font> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
<input type=text name="nombre" size=25>
<br>
Email:</font> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
</font><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
<input type=text name="email" size=25>
<br>
Mensaje:</font> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
<textarea name="coment" cols="25" rows="6"></textarea>
<br>
<br>
</font><br>
<br>
<input name="submit" type=submit value="Enviar">
</form>
<? 

}else{ 

//Estoy recibiendo el formulario, compongo el cuerpo 

$cuerpo = "Formulario enviado desde la pagina web www.phpmysql.tk\n"; 

$cuerpo .= "Nombre: " . $HTTP_POST_VARS["nombre"] . "\n"; 

$cuerpo .= "Email: " . $HTTP_POST_VARS["email"] . "\n"; 

$cuerpo .= "Mensaje: " . $HTTP_POST_VARS["coment"] . "\n"; 



//mando el correo... 

mail("email@tudireccion.es","Formulario recibido",$cuerpo); 



//doy las gracias por el env�o 

echo "Gracias por rellenar el formulario. Se ha enviado correctamente."; 

} 

?>
</body>
</html>
