<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="enlaces.php"><img src="web.gif" alt="" width="219" height="42" border="0"></a><br>
          <br>
          <font class="content">[ <a href="enlaces.php">Indice</a> | <a href="envia.php">A�adir 
          Enlace</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br> 
  <table width="50%" border="1" cellspacing="0">
    <tr>
      <td><div align="center">
          <?php include("enlaces.txt"); #aqu� para cambiar la ruta del archivo que muestra las entradas 
		 ?>
        </div></td>
    </tr>
  </table>
  <br>
  <br>
</div>
