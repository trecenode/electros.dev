<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center"> 
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td height="68"><div align="center"><br>
          <a href="enlaces.php"><img src="web.gif" alt="" width="219" height="42" border="0"></a><br>
          <br>
          <font class="content">[ <a href="enlaces.php">Indice</a> | <a href="envia.php">A�adir 
          Enlace</a> ]<br>
          <br>
          </font></div></td>
    </tr>
  </table>
  <br>
  <table width="50%" border="1" cellspacing="0">
    <tr> 
      <td><div align="center"> 
          <?php
print "<table width='75%' border='0' cellspacing='0'>
  <form method='post' action='recibe.php' onsubmit='return error ()' name='myform' >
   <script>
                        function error (){
                                if (document.myform.titulo.value == '') {
                                        alert('Por favor, introduzca el titulo..');
                                        document.myform.titulo.focus();
                                        return false}
                                if (document.myform.url.value == '') {
                                        alert('Por favor, introduzca la url.');
                                        document.myform.url.focus();
                                        return false}
								if (document.myform.descripcion.value == '') {
                                        alert('Por favor, introduzca la descripcion.');
                                        document.myform.descripcion.focus();
                                        return false}
                                

                                else return getPermission();
                        }

</script>
    <tr> 
      <td width='16%'>Titulo</td>
      <td width='84%'><input name=titulo type=text id='titulo' maxlenght=30> </td>
    </tr>
    <tr> 
      <td height='23'>url del archivo</td>
      <td>http:// 
        <input name=url type=text id=url2 maxlenght=30></td>
    </tr>
    <tr> 
      <td height='23'>Descripcion</td>
      <td><textarea name='descripcion' id='descripcion2'></textarea></td>
    </tr>
    <tr> 
      <td height='23'>Tu email</td>
      <td><input name=email type=text></td>
    </tr>
    <tr> 
      <td height='23'>Tu web</td>
      <td>Http:// 
        <input name=weburl type=text></td>
    </tr>
    <tr> 
      <td height='23'><input name='submit' type=submit value=Enviar></td>
      <td></td>
    </tr>
   
  </form>
</table><br>";
?>
        </div></td>
    </tr>
  </table>
  <br>
  <br>
</div>
</body>
</html>
