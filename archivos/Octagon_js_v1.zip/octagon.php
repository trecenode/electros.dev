<?php
/*
###########################
##  Octagon JS v1.0 Beta.##
##      by               ##
##        Mefisto        ##
###########################
*/
require("config.php");
$url ="http://tuweb.com";#define la url esacta de tu web sin "/" al final
$result=mysql_query("SELECT * FROM tag_beta ORDER BY id DESC limit 15");
echo"document.write(\"<div style='text-align: left; height: 100px; width: 120px; overflow: auto;'>\");";
echo"document.write(\"<table width=100% border=0 cellpadding=0 cellspacing=0>\");";
while($row=mysql_fetch_array($result)){
$row[msg]=str_replace(":D","<img src=$url/ikon/risa.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":)","<img src=$url/ikon/sonrisa.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace("(y)","<img src=$url/ikon/bien.gif  width=12 height=12>",$row[msg]);
$row[msg]=str_replace("(b)","<img src=$url/ikon/mal.gif  width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":cool:","<img src=$url/ikon/cool.gif  width=12 height=12>",$row[msg]);
$row[msg]=str_replace("8)","<img src=$url/ikon/ojotes.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace("?)","<img src=$url/ikon/duda.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":(","<img src=$url/ikon/triste.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(";)","<img src=$url/ikon/ginando.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":p","<img src=$url/ikon/lengua.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":llora:","$url/ikon/llorando.gif width=12 height=12>",$row[msg]);
$row[msg]=str_replace(":[","<img src=$url/ikon/enojad.gif width=12 height=12>",$row[msg]);
if($row[url] == "http://"){
$user=$row[name];}else{
$user ="<a href='$row[url]' target='_blank'>$row[name]</a>";
}//puedes modificar el color de los nombres o lo k kieras
echo"
document.write(\"<tr><td class=casillas nowrap width=100%><b><font color=#ff0000 title=\'".date("d/m/Y",$row[hora])."\'>$user</font></b><br/>\");
document.write(\"$row[msg]</td></tr>\");
";
 }
 echo"document.write(\"</table>\");";
 echo"document.write(\"</div>\");";
 if($_POST["name"] && $_POST["msg"]){
 $hora =time();
 $ip=$REMOTE_ADDR;
$inserta= mysql_query("INSERT INTO tag_beta(hora,name,msg,ip,url)VALUES
 ('$hora','$_POST[name]','$_POST[msg]','$ip','$_POST[url]')");
 header("location: $HTTP_REFERER");
 }else{
 }
 ?>
function grabar(graba) { 

var inserta=document.tag.elements["msg"]; 

inserta.value=inserta.value+graba+' '; 

document.tag.msg.focus(); 

}
document.write("<a href=javascript:grabar(':D')><img src=<? echo $url;?>/ikon/risa.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(':)')><img src=<? echo $url;?>/ikon/sonrisa.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar('(y)')><img src=<? echo $url;?>/ikon/bien.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar('(b)')><img src=<? echo $url;?>/ikon/mal.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(':cool:')><img src=<? echo $url;?>/ikon/cool.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar('8)')><img src=<? echo $url;?>/ikon/ojotes.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar('?)')><img src=<? echo $url;?>/ikon/duda.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(':(')><img src=<? echo $url;?>/ikon/triste.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(';)')><img src=<? echo $url;?>/ikon/ginando.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(':p')><img src=<? echo $url;?>/ikon/lengua.gif border=0 width=12 height=12></a><br/>");
document.write("<a href=javascript:grabar(':llora:')><img src=<? echo $url;?>/ikon/llorando.gif border=0 width=12 height=12></a>");
document.write("<a href=javascript:grabar(':[')><img src=<? echo $url;?>/ikon/enojado.gif border=0 width=12 height=12></a>");
document.write("<form action='<? echo $url;?>/octagon.php.php' method='post' name=tag><b>Nick:</b></br><input type=text value='Tu nick' name='name'><br/><b>Mensaje:</b><br/><textarea name='msg'></textarea><br/><b>Url:</b><br/><input name=url type=text value=http://><br/><input name=post type=submit id=post value=Enviar></form>");
