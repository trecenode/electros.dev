CREATE TABLE tag_beta (
  id int(10) NOT NULL auto_increment,
  hora int(10) NOT NULL default '0',
  name varchar(25) NOT NULL default '',
  msg varchar(250) NOT NULL default '',
  ip tinytext NOT NULL,
  url text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;
