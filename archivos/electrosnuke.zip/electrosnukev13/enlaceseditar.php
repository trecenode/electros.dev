<?
include("config.php") ;
if($HTTP_GET_VARS[$administrador]) { echo "Acceso denegado. Intento de hackeo." ; exit ; }
// Se comprueba que el mensaje pertenezca al usuario que desea editar el mensaje
// Si el que desea editarlo es el administrador ya no se hace la comprobaci�n
if($HTTP_COOKIE_VARS[unick] != $administrador) {
$resp = mysql_query("select id from enlaces where id='$enlacesid' and usuario='$HTTP_COOKIE_VARS[unick]'") ;
if(@mysql_num_rows($resp) == 0) {
echo "No puedes editar este enlace,Haz click <a href=javascript:history.back()>aqu�</a> para regresar." ;
exit ;
}
mysql_free_result($resp) ;
}
if($enviar) {
function quitar($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitar($titulo) ;
$descripcion = quitar($descripcion) ;
$categoria = quitar($categoria) ;
$urlsitio = quitar($urlsitio) ;
$imagen = quitar($imagen) ;
mysql_query("update enlaces set titulo='$titulo',descripcion='$descripcion',categoria='$categoria',urlsitio='$urlsitio',imagen='$imagen' where id='$enlacesid'") ;
echo "Tu enlace ha sido editado con �xito. Haz click <a href='index.php?id=enlaces' >aqu�</a> para regresar al enlace.<br><br>" ;
}
$resp = mysql_query("select * from enlaces where id=$enlacesid") ;
while($datos = mysql_fetch_array($resp)) {
?> <b>Editar una enlace</b><br>
 <form name='formulario' method='post' action='index.php?id=enlaceseditar&enlacesid=<? echo $enlacesid ?>' onsubmit="return revisar()">
  <p><b>T�tulo:</b><br>
    <input type="text" name="titulo" size="30" maxlength="25" value="<? echo $datos[titulo] ?>" class="form">
    <br>
    <b>Descripci�n de archivo:</b><br>
    <textarea name="descripcion" cols="30" rows="5" class="form" onKeyPress="caracteres"><? echo $datos[descripcion] ?></textarea>
    <br>
    <script>
function caracteres() {
if(formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout("caracteres()",200) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.titulo.value.length > 100) { alert('El tiulo del archivo supera los 100 caract�res.') ; return false ; } 
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
if(formulario.urlsitio.value.length > 100) { alert('La url del archivo supera los 100 caract�res.') ; return false ; }
}
</script>
    <input type="text" name="caracteres" size="3" value="0" class="form">
    M�ximo 255 caract�res<b><br>
    Categor�a:</b><br>
<select name="categoria" class="form">
<option <? if ($datos[categoria] == "0" ) {echo "selected"; } ?> value='0'><? echo $enlace0 ?> 
<option <? if ($datos[categoria] == "1" ) {echo "selected"; } ?> value='1'><? echo $enlace1 ?> 
<option <? if ($datos[categoria] == "2" ) {echo "selected"; } ?> value='2'><? echo $enlace2 ?> 
<option <? if ($datos[categoria] == "3" ) {echo "selected"; } ?> value='3'><? echo $enlace3 ?> 
<option value='4' <? if ($datos[categoria] == "4" ) {echo "selected"; } ?>><? echo $enlace4 ?> 
<option value='5' <? if ($datos[categoria] == "5" ) {echo "selected"; } ?>><? echo $enlace5 ?> 
<option value='6' <? if ($datos[categoria] == "6" ) {echo "selected"; } ?>><? echo $enlace6 ?> 
<option value='7' <? if ($datos[categoria] == "7" ) {echo "selected"; } ?>><? echo $enlace7 ?> 
<option value='8' <? if ($datos[categoria] == "8" ) {echo "selected"; } ?>><? echo $enlace8 ?> 
<option value='9' <? if ($datos[categoria] == "9" ) {echo "selected"; } ?>><? echo $enlace9 ?> 
</select>
    <br>
    <b>URL del enlace :</b><br>
    <input type="text" name="urlsitio" size="30" maxlenght="100" value="<? echo $datos[urlsitio] ?>" class="form">
    <br>
    <b><font color="#FF0000">URL de la imagen del archivo <br>
    (Opcional,</font></b><b><font color="#FF0000">Especifica una direccion web, 
    <br>
    tama&ntilde;o <? echo $tama�oanchoimagen  ?> x <? echo $tama�oaltoimagen  ?>)</font> 
    <font color="#FF0000">:</font></b><br>
    <input name="imagen" type="text" class="form" id="imagen" value="<? echo $datos[imagen] ?>" size="30" maxlenght="100">
    <br>
    <br>
<?
if($datos[imagen] == "") {
$imagen = "" ;
}
else {
$imagen = "<img src='$datos[imagen]' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'><br>" ;
}
echo $imagen ;
?>
	<br>
    <input type='submit' name='enviar' value='Editar enlace' class='form'>
  </p>
  </form>
<?
}

mysql_free_result($resp) ;
@mysql_close($conectar) ;
?>


