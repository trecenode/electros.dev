<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
// Si alguien trata de poner el nombre del administrador en la barra de direcciones se le denegar� el acceso
if($_GET[$administrador]) { echo "Acceso denegado. Intento de hackeo." ; }
// Tambi�n se comprueba si la contrase�a guardada en la base de datos coincide con la de la cookie
$resp = mysql_query("select nick,contrasena from $tabla_usuarios where nick='$administrador'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[nick] != $_COOKIE[unick] || $datos[contrasena] != $_COOKIE[ucontrasena]) {
echo "S�lo <b>$administrador</b> puede administrar el foro." ;
exit ;
}
?>
<p><a href="foro.php">� Regresar al foro</a>
<p>
<?
// *** Procesamiento de datos ***
if($enviar) {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">Confirmaci�n</div></td>
</tr>
<tr>
<td class="tabla_mensaje">
<div align="center">
<?
if($agregar == "categoria") {
mysql_query("insert into eforo_categorias (categoria) values ('$categoria')") ;
$resp = mysql_query("select id from eforo_categorias") ;
$categorias = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$categorias = $categorias * 10 ;
$resp = mysql_query("select id from eforo_categorias order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
mysql_query("update eforo_categorias set orden='$categorias' where id='$datos[id]'") ;
mysql_free_result($resp) ;
echo "La categor�a <b>$categoria</b> ha sido agregada con �xito." ;
}
if($agregar == "foro") {
mysql_query("insert into eforo_foros (categoria,foro,descripcion) values ('$categoria','$foro','$descripcion')") ;
$resp = mysql_query("select id from eforo_foros order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$resp2 = mysql_query("select id from eforo_foros where categoria='$categoria'") ;
$foros = mysql_num_rows($resp2) ;
mysql_free_result($resp2) ;
$foros = $foros * 10 ;
mysql_query("update eforo_foros set orden='$foros' where id='$datos[id]'") ;
mysql_free_result($resp) ;
echo "El foro <b>$foro</b> ha sido agregado con �xito." ;
}
if($ordenar == "categoria") {
if($subir) { mysql_query("update eforo_categorias set orden=orden-15 where id='$id'") ; }
if($bajar) { mysql_query("update eforo_categorias set orden=orden+15 where id='$id'") ; }
$resp = mysql_query("select id from eforo_categorias order by orden asc") ;
$orden = 10 ;
while($datos = mysql_fetch_array($resp)) {
mysql_query("update eforo_categorias set orden='$orden' where id='$datos[id]'") ;
$orden = $orden + 10 ;
}
mysql_free_result($resp) ;
echo "La categor�a ha sido cambiada de orden con �xito." ;
}
if($ordenar == "foro") {
if($subir) { mysql_query("update eforo_foros set orden=orden-15 where id='$id'") ; }
if($bajar) { mysql_query("update eforo_foros set orden=orden+15 where id='$id'") ; }
$resp = mysql_query("select id from eforo_foros where categoria='$c' order by orden asc") ;
$orden = 10 ;
while($datos = mysql_fetch_array($resp)) {
mysql_query("update eforo_foros set orden='$orden' where id='$datos[id]'") ;
$orden = $orden + 10 ;
}
mysql_free_result($resp) ;
echo "El foro ha sido cambiado de orden con �xito." ;
}
if($borrar == "categoria") {
$resp = mysql_query("select id from eforo_foros where categoria='$id'") ;
if(mysql_num_rows($resp) == 0) {
mysql_query("delete from eforo_categorias where id='$id'") ;
echo "La categor�a ha sido borrada con �xito." ;
}
else {
echo "Primero debes eliminar todos los foros de esta categor�a." ;
}
}
if($borrar == "foro") {
mysql_query("delete from eforo_mensajes where foro='$id'") ;
mysql_query("delete from eforo_foros where id='$id'") ;
echo "El foro y todos sus mensajes han sido borrados con �xito." ;
}
if($id == "configuracion") {
mysql_query("update eforo_config set administrador='$c_administrador',temas='$c_temas',mensajes='$c_mensajes',
ultimos='$c_ultimos',codigo='$c_codigo',caretos='$c_caretos',url='$c_url',censurar='$c_censurar',estilo='$c_estilo',
avatarlargo='$c_avatarlargo',avatarancho='$c_avatarancho',avatartamano='$c_avatartamano',privados='$c_privados'") ;
echo "Los datos han sido actualizados con �xito." ;
}
?>
</div>
</td>
</tr>
</table><br>
<?
}

// *** Panel de administraci�n ***
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="150" valign="top">
<!-- Inicio Menu -->
<table width="150" border="0" cellpadding="0" cellspacing="1" class="tabla_principal">
<tr>
<td class="tabla_titulo"><div align="center" class="t1">eForo</div></td>
</tr>
<tr>
<td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php">Administrar</a></div></td>
</tr>
<tr>
<td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?administrar=configuracion">Configuraci�n</a></div></td>
</tr>
</table>
<!-- Fin Menu -->
</td>
<td width="25"></td><!-- Separador -->
<td width="500" valign="top">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<table border="0" cellpadding="0" cellspacing="0" align="center">
<tr>
<td valign="top">
<!-- Inicio Principal -->
<?
if(!$administrar) {
?>
<p class="t1">Agregar categor�as
<p>
<form method="post" action="foroadmin.php?agregar=categoria">
<div style="position: absolute ; visibility: hidden"><input type="text" name="a"></div>
<b>Categor�a:</b><br>
<input type="text" name="categoria" maxlength="100" size="30" class="form"><br><br>
<input type="submit" name="enviar" value="Agregar categor�a" class="form">
</form>
</td>
<td width="25">&nbsp;</td>
<td valign="top">
<p class="t1">Agregar foros
<p>
<form method="post" action="foroadmin.php?agregar=foro">
<b>Foro:</b><br>
<input type="text" name="foro" maxlength="100" size="30" class="form"><br>
<b>Categor�a:</b><br>
<select name="categoria" class="form">
<?
$resp = mysql_query("select id,categoria from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<option value="<? echo $datos[id] ?>"><? echo $datos[categoria] ?>
<?
}
mysql_free_result($resp) ;
?>
</select><br>
<b>Descripci�n:</b><br>
<textarea name="descripcion" cols="30" rows="5" class="form"></textarea><br><br>
<input type="submit" name="enviar" value="Agregar foro" class="form">
</form>
</td>
</tr>
</table><br>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td width="30%" class="tabla_titulo"><div class="t1" align="center">Orden</div></td>
<td width="50%" class="tabla_titulo"><div class="t1" align="center">Categor�a</div></td>
<td width="20%" class="tabla_titulo">&nbsp;</td>
</tr>
<?
$resp = mysql_query("select * from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td class="tabla_subtitulo">
<div align="center">
<a href="foroadmin.php?id=<? echo $datos[id] ?>&ordenar=categoria&bajar=si&enviar=si">Bajar</a> |
<a href="foroadmin.php?id=<? echo $datos[id] ?>&ordenar=categoria&subir=si&enviar=si">Subir</a><br><br>
</div>
</td>
<td class="tabla_subtitulo"><div class="t1"><? echo $datos[categoria] ?></div></td>
<td class="tabla_subtitulo"><div align="center"><a href="foroadmin.php?id=<? echo $datos[id] ?>&borrar=categoria&enviar=si">Borrar</a></div></td>
</tr>
<?
$resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
while($datos2 = mysql_fetch_array($resp2)) {
?>
<tr>
<td class="tabla_mensaje">
<div align="center">
<a href="foroadmin.php?id=<? echo $datos2[id] ?>&c=<? echo $datos[id] ?>&ordenar=foro&bajar=si&enviar=si">Bajar</a> |
<a href="foroadmin.php?id=<? echo $datos2[id] ?>&c=<? echo $datos[id] ?>&ordenar=foro&subir=si&enviar=si">Subir</a>
</div>
</td>
<td class="tabla_mensaje"><a href="foro.php?foroid=<? echo $datos2[id] ?>"><? echo $datos2[foro] ?></a><br><? echo $datos2[descripcion] ?></td>
<td class="tabla_mensaje"><div align="center"><a href="foroadmin.php?id=<? echo $datos2[id] ?>&borrar=foro&enviar=si">Borrar</a></div></td>
</tr>
<?
}
mysql_free_result($resp2) ;
}
?>
</table>
<?
}
if($administrar == "configuracion") {
?>
<form method="post" action="foroadmin.php?id=configuracion">
<table width="100%" border="0" cellpadding="3" cellspacing="1" class="tabla_principal">
<tr>
<td colspan="2" class="tabla_titulo"><div align="center" class="t1">Configuraci�n</div></td>
</tr>
<tr>
<td colspan="2" class="tabla_subtitulo"><div class="t1">General</div></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Administrador:</b><br>Nick del administrador</td>
<td class="tabla_mensaje"><input type="text" name="c_administrador" value="<? echo $administrador ?>" maxlength="20" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Temas:</b><br>Numero de temas a mostrar</td>
<td class="tabla_mensaje"><input type="text" name="c_temas" value="<? echo $num_temas ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Mensajes:</b><br>Mensajes a mostrar por tema</td>
<td class="tabla_mensaje"><input type="text" name="c_mensajes" value="<? echo $num_mensajes ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Ultimos mensajes:</b><br>Al querer responder un tema se ver�n los �ltimos mensajes</td>
<td class="tabla_mensaje"><input type="text" name="c_ultimos" value="<? echo $num_mensajes ?>" maxlength="3"class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Permitir eCodigo:</b><br>El eCodigo es un c�digo especial que sirve para personalizar los mensajes sin necesidad de usar HTML</td>
<td class="tabla_mensaje"><input type="text" name="c_codigo" value="<? echo $codigo ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Permitir caretos:</b><br>Uso de caretos en los mensajes</td>
<td class="tabla_mensaje"><input type="text" name="c_caretos" value="<? echo $caretos ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Transformar URLs en enlaces:</b><br>Transforma autom�ticamente toda direcci�n del tipo http:// a un enlace</td>
<td class="tabla_mensaje"><input type="text" name="c_url" value="<? echo $url ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Censurar palabras:</b><br>Sustituye las palabras censuradas por otras palabras que puedes definir</td>
<td class="tabla_mensaje"><input type="text" name="c_censurar" value="<? echo $censurar ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Estilo del foro:</b><br>Selecciona el estilo del foro (tipo de letra, colores, formularios)</td>
<td class="tabla_mensaje">
<select name="c_estilo" class="form">
<?
$directorio = dir("eforo_estilo");
while($archivo = $directorio -> read()) {
if($archivo != "." && $archivo != "..") {
if($archivo == $estilo) {
echo "<option value=\"$archivo\" selected>$archivo" ;
}
else {
echo "<option value=\"$archivo\">$archivo" ;
}
}
}
$directorio -> close() ;
?>
</select>
</td>
</tr>
<tr>
<td colspan="2" class="tabla_subtitulo"><div class="t1">Mensajes privados</div></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>M�ximo de mensajes privados por usuario:</b><br>Es el n�mero m�ximo de mensajes privados que el usuario podr� recibir</td>
<td class="tabla_mensaje"><input type="text" name="c_privados" value="<? echo $max_privados ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td colspan="2" class="tabla_subtitulo"><div class="t1">Avatares</div></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Tama�o de largo:</b><br>El largo en pixeles de la imagen</td>
<td class="tabla_mensaje"><input type="text" name="c_avatarlargo" value="<? echo $tam_largo ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Tama�o de ancho:</b><br>El ancho en pixeles de la imagen</td>
<td class="tabla_mensaje"><input type="text" name="c_avatarancho" value="<? echo $tam_ancho ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td class="tabla_mensaje"><b>Tama�o de archivo</b><br>El peso m�ximo en Kb</td>
<td class="tabla_mensaje"><input type="text" name="c_avatartamano" value="<? echo $tam_archivo ?>" maxlength="3" class="form"></td>
</tr>
<tr>
<td colspan="2" class="tabla_mensaje"><div align="center"><input type="submit" name="enviar" value="Enviar" class="form"></div></td>
</tr>
</table>
</form>
<!-- Fin Principal -->
</td>
</tr>
</table>
<?
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
</body>
</html>
