
<script>
function valida() {
if(formulario.mensaje.value == '') { alert('El mensaje no puede estar vac�o.') ; return false ; }
if(formulario.mensaje.value.length >= 1024) { alert('El mensaje no puede superar los 1024 car�cteres.') ; return false ; }
}
</script>

<? include("config.php") ;
if($enviar) {
$remite = $_COOKIE["unick"] ;
$mensaje = trim($mensaje) ;
$mensaje = htmlspecialchars($mensaje) ;
$fecha = time() ;
$query = "select nick from usuarios order by id asc"; 
$resp = mysql_query($query);
$totales = mysql_num_rows($resp) ;
$i = 0 ;

while ($datos = mysql_fetch_array($resp)) {
$nick = $datos[nick] ;
$mensaje2 = str_replace("[nick]",$nick,$mensaje) ;
mysql_query("insert into mensajes (fecha,destinatario,remitente,mensaje) values ('$fecha','$nick','$remite','$mensaje2')") ;
$i = $i + 1;
}
if($i == $totales) {
echo "Completado el env�o de mensajes. Total enviados: <b>$i</b><br>
Mensaje enviado: $mensaje<br><br>
<a href=javascript:history.back()>Enviar otro mensaje</a><br>
<a href="index.php">P�gina principal</a>
";
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
} 

else {
?>

<b>Mensaje de difusi�n general:</b>
    <form action="umensajegeneral.php" method="post" name="formulario" onsubmit="return valida()">
    <textarea name="mensaje" cols="20" rows="5"></textarea> 
    <input name="enviar" type="submit" value="Enviar">
    </form>
  <p>Para poner un mensaje personalizado a los usuarios usa: <b>[nick]</b> Ejemplo: Hola [nick] </p>

<? } ?>