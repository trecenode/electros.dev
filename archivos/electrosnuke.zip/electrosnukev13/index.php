<? 
/////////////////////////////
//|-----------------------|//
//| Electrosnuke v1.3     |//
//| by www.phpmysql.tk    |//
//| by www.electros.tk    |//
//|-----------------------|//
//    Licencia: gnu/gpl    //
/////////////////////////////
// conexion a la base de datos
include("config.php") ; 
?>
<html>
<head>
<title><? echo $titulodelapagina ?></title>
</head>
<?
include("eforo_estilo/$estilopagina") ;
?>
<?
echo $cabezera_pagina ;
?>
<body>
<table width="100%" height="60" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="26%" height="19" ><div align="center" class="t1"><font color="#CCCCCC" size="5"><? echo $titulodelportal ?></font></div></td>
    <td width="74%"> <div align="center"> 
        <? 
// Bloque afiliados banner
include("config.php");
if($menu_afiliados_banner == "ON") {
?>
        <? 
// sistema de rotacion de banners
include("config.php") ;
$resp = mysql_query("select * from enlaces where urlminibanner2!='' order by rand() limit 1") ;
while($datos = @mysql_fetch_array($resp)) {
?>
        <? 
if ($datos[urlminibanner2]  != '' ) { 
echo "<a href='enlaces.php?e=$datos[id]' target='_black' ><img src='$datos[urlminibanner2]' border=0  width='468' height='60' alt='Hits: $datos[visitas]  Votos: $datos[votos] '  ></a>";
} 
else {echo "";
} 
?>
        <?
}
// fin sistema rotacion de banners
?>
        <?
}
else {
echo "" ;
}
?>
      </div></td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15%" height="302" valign="top"><table width="151" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        
	<tr> 
          <!-- Inicio bloques menus -->
		  <td width="145" class="tabla_titulo"><div align="right" class="t1">Menu</div></td>
        </tr>
        <tr> 
          <td height="172" valign="top" class="tabla_mensaje"><p>Inicio<br>
              <a href="index.php">� Principal</a><br>
              <a href="index.php?id=usuarios">� Usuarios</a><br>
              <a href="index.php?id=noticias">� Noticias</a><br>
              <a href="foro.php">� Foro</a><br>
              <a href="index.php?id=enlaces">� Enlaces</a> <br>
              <a href="index.php?id=buscar">� Buscar en la pagina</a><br>
              <a href="index.php?id=descargas">� Descargas</a><br>
              Recomendados<br>
              <a href="http://www.phpmysql.tk" target="_blank">� phpmysql</a><br>
              <a href="http://www.morpheo.tk" target="_blank">� Morpheo</a><br>
              <a href="http://www.poliejido.tk" target="_blank">� Poliejido</a><br>
              <a href="http://elcidop.webcindario.com" target="_blank">� Elcidop</a><br>
              <a href="http://usuarios.lycos.es/codigohtm" target="_blank">� Codigohtm</a><br>
              <a href="http://www.electros.tk" target="_blank">� Electros</a><br>
              Complementos<br>
              <a href="descargas/index.php" target="_blank">� Galeria descargas</a><br>
              <a href="eforo_imagenes/index.php" target="_blank">� Galeria imagenes</a><br>
              <? 
// Link administrar (Todo lo contenido aqui solo lo ve el administrador)
if($HTTP_COOKIE_VARS[unick] == "$administrador") {
?>
              Administrar<br>
              <a href="index.php?id=administrar">� Administrar</a><br>
              <a href="index.php?id=umensajegeneral">� Enviar mensaje</a><br>
              <a href="index.php?id=validacion">� Validar noticias</a><br>
              <?
}
else {
echo "" ;
}
// fin de link administrar
?>
            </p>
            </td>
        </tr>
      </table>   
<? 
// Bloque usuarios
include("config.php");
if($menu_usuarios == "ON") {
?>
<br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Usuarios</div></td>
        </tr>
        <tr> 
          <td height="1" valign="top" class="tabla_mensaje" align="left"> 
            <? 
			// el menu de los usuarios
			include("umenu.php"); 
			?>
            <br>
          </td>
        </tr>
      </table> 
<?
}
else {
echo "" ;
}
?>
<? 
// Bloque enlaces
include("config.php");
if($menu_enlaces == "ON") {
?>  
	  <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Top 
              10 Enlaces</div></td>
        </tr>
        <tr> 
          <td height="89" valign="top" class="tabla_mensaje" align="left" > <form method="post" action="index.php?id=enlaces" form name="formulario2" >
              <div style="position: absolute ; visibility: hidden"> 
                <input type="hidden" name="aaa">
              </div>
              <input type="text" name="palabras" size="12" maxlength="65" class="form">
              <input type="submit" name="buscar" value="Buscar" class="form ">
            </form>
            <? // top 10 enlaces
include("config.php") ;
$resp = mysql_query("select * from enlaces order by visitas desc limit 10") ;
while($datos = @mysql_fetch_array($resp)) {
if (strlen($datos[titulo]) > 30) { 
$datos[titulo] = substr($datos[titulo],0,30).".."; }
echo "� <a href=enlaces.php?e=$datos[id] target=_blanck > $datos[titulo]</a> ($datos[visitas])<br>
" ;
}
?>
            <br>
            <br> </td>
        </tr>
      </table> 
      <?
}
else {
echo "" ;
}
?><? 
// Bloque descargas
include("config.php");
if($menu_descargas == "ON") {
?>
<br>
<table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >
  <tr> 
    <td class="tabla_titulo"><div align="right" class="t1">Top 10 Descargas</div></td>
  </tr>
  <tr> 
    <td height="89" valign="top" class="tabla_mensaje" align="left" > <form method="post" action="index.php?id=descargas" form name="formulario3" >
        <div style="position: absolute ; visibility: hidden"> 
          <input type="hidden" name="aaa">
        </div>
        <input type="text" name="palabras" size="12" maxlength="65" class="form">
        <input type="submit" name="buscar" value="Buscar" class="form ">
      </form>
      <? // top 10 descargas
include("config.php") ;
$resp = mysql_query("select * from descargas order by visitas desc limit 10") ;
while($datos = @mysql_fetch_array($resp)) {
if (strlen($datos[titulo]) > 30) { 
$datos[titulo] = substr($datos[titulo],0,30).".."; }
echo "� <a href=descargas.php?e=$datos[id] target=_blanck > $datos[titulo]</a> ($datos[visitas])<br>
" ;
}
?>
      <br> <br> </td>
  </tr>
</table>
<?
}
else {
echo "" ;
}
?>
<? 
// Bloque afiliados minibanner
include("config.php");
if($menu_afiliados_minibanner == "ON") {
?>  
      <br>
      <table width="150" border="0" cellpadding="2" cellspacing="0" class='tabla_principal' >        <tr> 
          <td class="tabla_titulo"><div align="right" class="t1">Afiliados</div></td>
        </tr>
        <tr> 
          <td height="6" valign="top" class="tabla_mensaje">
		  <div align="center"><? // sistema de minibanners
include("config.php");
$resp = mysql_query("select * from enlaces where urlminibanner!='' order by rand() limit 3") ;
$datos = @mysql_fetch_array($resp) ;
$datos1 = @mysql_fetch_array($resp) ;
$datos2 = @mysql_fetch_array($resp) ;
if ($datos[urlminibanner] != '' ) 
{echo "<a href='enlaces.php?e=$datos[id]' target='_blank'><img src='$datos[urlminibanner]' border=0 width=88 height=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>
<a href='enlaces.php?e=$datos1[id]' target='_blank'><img src='$datos1[urlminibanner]' border=0 width=88 height=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>
<a href='enlaces.php?e=$datos2[id]' target='_blank'><img src='$datos2[urlminibanner]' border=0 width=88 height=31 onerror=this.onerror='null';this.src='$errorimagen'></a><br><br>";}
else 
{echo "";}
?>
</div>
</td>
</tr>
</table><?
}
else {
echo "" ;
}
?> 
<!-- fin bloques menus -->
</td>
    <td width="1%">&nbsp;</td>
    <td width="84%" valign="top"> 
<? 
// Bloque top
include("config.php");
if($menu_top == "ON") {
?>
      <table width="100%" border="0" cellpadding="5" cellspacing="0" align="center" class='tabla_principal' >        <tr> 
          <td width="100%" height="7" class="tabla_mensaje"> 
<? 
// Dia,mes y a�o
if($fechadehoy == "ON") {
$fecha = time()  ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fechadehoy = "Hoy es $diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
echo $fechadehoy ;
}
?>
<br>
<?php
//usuarios en linea (aqui veras los usuarios online en la web)
if($usuariosenlinea == "ON") {
include("uenlinea.php");
}

?>
            <br>
            <br>
            
<? 
// Ultimo registrado (Aqui veras el ultimo usuario registrado en la web)
if($ultimoregistrado == "ON") { 
include("config.php") ;
$mostrar = 1 ;
$resp = mysql_query("select * from usuarios order by id desc limit $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
echo "Ultimo registrado:  <a href='index.php?id=usuarios&u=$datos[id]' >$datos[nick]</a><br>" ;
mysql_close($conectar) ;
}
}
?>
          </td>
        </tr>
      </table>
<br>
      <?
}
else {
echo "" ;
}
?>
      <table width="100%" border="0" cellpadding="5" cellspacing="0" align="center" class='tabla_principal' >        <tr> 
          <td height="28" class="tabla_mensaje" > 
<? 
// Donde se incluyen las paginas de forma automatica (con la url index.php?id=nombrepagina
// se abriria la pagina nombrepagina.php en esta parte).
if($id == "") { 
include("principal.php"); 
}
else { 
if(file_exists("$id.php")) { 
include("$id.php"); 
} 
else { 
include("error.php"); 
} 
} 
?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?
echo $pie_pagina ;
?>
