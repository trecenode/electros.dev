<? 
if($HTTP_COOKIE_VARS[unick]) {
if($HTTP_COOKIE_VARS[unick] == "$administrador") {
?><br>
<br>
<? 
include("config.php");
//si se pide borrar enlaces.
if ($borrarenlaces) { 
$query = "delete from enlaces where id='$borrarenlaces'"; 
mysql_query($query);
echo "<b>Borrado enlaces <b>$borrarenlaces</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un enlace
else if($enviar) {
function quitarenlaces($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitarenlaces($titulo) ;
$descripcion = quitarenlaces($descripcion) ;
$categoria = quitarenlaces($categoria) ;
$urlsitio = quitarenlaces($urlsitio) ;
mysql_query("update enlaces set titulo='$titulo',descripcion='$descripcion',categoria='$categoria',urlsitio='$urlsitio' where id='$editarenlaces'") ;
if ($editarenlaces == "" ) {echo "";} else echo "Actualizado enlaces $editarenlaces<br><br>" ;
} 
// si se te pide editar un enlace
else if ($editarenlaces) {
$resp3 = mysql_query("select * from enlaces where id='$editarenlaces'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarenlaces"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="96%" height="7" class="tabla_subtitulo"><b>Editar enlaces</b> </td>
    <td width="4%" class="tabla_subtitulo"><center>
        <a href="index.php?id=administrar#editarenlaces2">x</a>
</center></td>
  </tr>
  <tr> 
    <td height="7" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editarenlaces=<? echo $datos3[id] ?>#editarenlaces2' onsubmit="return revisar()">
        <p><b>T�tulo:</b><br>
          <input type="text" name="titulo" size="30" maxlength="35" value="<? echo $datos3[titulo] ?>" class="form">
          <br>
          <b>Descripci�n de archivo:</b><br>
          <textarea name="descripcion" cols="30" rows="5" class="form" onKeyPress="caracteres"><? echo $datos3[descripcion] ?></textarea>
          <br>
          <script>
function caracteres() {
if(formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.titulo.value.length > 100) { alert('El tiulo del archivo supera los 100 caract�res.') ; return false ; } 
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
if(formulario.urlsitio.value.length > 100) { alert('La url del archivo supera los 100 caract�res.') ; return false ; }
}
</script>
          <input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<b><br>
          Categor�a:</b><br>
          <select name="categoria" class="form">������������
            <option <? if ($datos3[categoria] == "0" ) {echo "selected"; } ?> value='0'> 
            <? if ($enlace0 != "" ) {echo "$enlace0"; } else echo "0"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "1" ) {echo "selected"; } ?> value='1'> 
            <? if ($enlace1 != "" ) {echo "$enlace1"; } else echo "1"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "2" ) {echo "selected"; } ?> value='2'> 
            <? if ($enlace2 != "" ) {echo "$enlace2"; } else echo "2"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "3" ) {echo "selected"; } ?> value='3'> 
            <? if ($enlace3 != "" ) {echo "$enlace3"; } else echo "3"; ?>
            ������������ 
            <option value='4' <? if ($datos3[categoria] == "4" ) {echo "selected"; } ?>> 
            <? if ($enlace4 != "" ) {echo "$enlace4"; } else echo "4"; ?>
            ������������ 
            <option value='5' <? if ($datos3[categoria] == "5" ) {echo "selected"; } ?>> 
            <? if ($enlace5 != "" ) {echo "$enlace5"; } else echo "5"; ?>
            ������������ 
            <option value='6' <? if ($datos3[categoria] == "6" ) {echo "selected"; } ?>> 
            <? if ($enlace6 != "" ) {echo "$enlace6"; } else echo "6"; ?>
            ������������ 
            <option value='7' <? if ($datos3[categoria] == "7" ) {echo "selected"; } ?>> 
            <? if ($enlace7 != "" ) {echo "$enlace7"; } else echo "7"; ?>
            ������������ 
            <option value='8' <? if ($datos3[categoria] == "8" ) {echo "selected"; } ?>> 
            <? if ($enlace8 != "" ) {echo "$enlace8"; } else echo "8"; ?>
            ������������ 
            <option value='9' <? if ($datos3[categoria] == "9" ) {echo "selected"; } ?>> 
            <? if ($enlace9 != "" ) {echo "$enlace9"; } else echo "9"; ?>
            ���������� 
          </select>
          <br>
          <b>URL del enlace :</b><br>
          <input type="text" name="urlsitio" size="30" maxlenght="100" value="<? echo $datos3[urlsitio] ?>" class="form">
          <br>
          <br>
          <input type='submit' name='enviar' value='Editar enlace' class='form'>
      </form></td>
  </tr>
</table>
<br>
<? 
}
//muestra todos los registros enlaces.
?>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td colspan="5" class="tabla_titulo">
<div class="t1">Listado de enlaces</div>
</td>
<?
?>
<tr>
<td class="tabla_subtitulo"><b>Id</b></td>
<td class="tabla_subtitulo"><b>Titulo</b></td>
<td class="tabla_subtitulo"><b>Descripcion</b></td>
<td class="tabla_subtitulo">&nbsp;</td>
<td class="tabla_subtitulo">&nbsp;</td>
<? 
$mostrarenlaces = 10 ; 
if(!$desdeenlaces) { $desdeenlaces = 0 ; }
$query = "select * from enlaces order by id asc limit $desdeenlaces,$mostrarenlaces"; 
$desdeenlaces = $desdeenlaces + $mostrarenlaces ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?>
<!-- 
Colorear temas al paso:
Cuando pasas por encima de un tema este se colorea a tu paso gracias a onmouseover(pasar por la tabla),onmouseout(salirte de la tabla despues de pasar),onmousedown(presionar sobre la tabla)
para que funcione hay que haces lo siguiente:
1) Cambiar <tr> por <tr onmouseover="this.className='tabla_subtitulo';" onmouseout="this.className='tabla_mensaje';" onmousedown="this.className='tabla_subtitulo';">
2) quitar background: #dddddd ; de .tabla_mensaje en el estilo electros.php si utilizas ese estilo, para que se vea.
 -->
<tr>
<td class="tabla_mensaje "><? echo $datos[id] ?></td>
<td class="tabla_mensaje "><a href="<? echo $datos[urlsitio] ?>" target="_blank"><? echo $datos[titulo] ?></a></td>
<td class="tabla_mensaje "><? echo $datos[descripcion] ?></td>
<td class="tabla_mensaje "><a href=index.php?id=administrar&borrarenlaces=<? echo $datos[id] ?>#editarenlaces2>Borrar</a></td>
<td class="tabla_mensaje "><a href=index.php?id=administrar&editarenlaces=<? echo $datos[id] ?>#editarenlaces>Editar</a></td>
</tr>
<?
} 
?>
<tr> 
<td colspan="5" class="tabla_subtitulo">
<?
// paginamos los resultados de enlaces.
mysql_free_result($resp);
if($desdeenlaces > $mostrarenlaces) {
$anterioresenlaces = $mostrarenlaces * 2 ;
if($desdeenlaces == $anterioresenlaces) {
echo "<p align=right><a href=index.php?id=administrar#editarenlaces2>Anteriores $mostrarenlaces enlaces</a> | " ;
}
else {
$anterioresenlaces = $desdeenlaces - $mostrarenlaces * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdeenlaces=$anterioresenlaces#editarenlaces2>Anteriores $mostrarenlaces enlaces</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdeenlaces < $enlaces) {
echo "<a href=index.php?id=administrar&desdeenlaces=$desdeenlaces#editarenlaces2>Siguientes $mostrarenlaces enlaces</a>" ;
}
if($desdeenlaces > $enlaces) {
echo "<a href=index.php?id=administrar&desdeenlaces=$desdeenlaces#editarenlaces2>Siguientes $mostrarenlaces enlaces</a>" ;
echo "</p>" ;
} 
?>
</td>
</tr>
</table>
<?
// liberamos memoria y desconecta de mysql en enlaces. 
@mysql_close($conecta); 
?>
<br>
<br>
<? 
include("config.php");
//si se pide borrar descargas.
if ($borrardescargas) { 
$query = "delete from descargas where id='$borrardescargas'"; 
mysql_query($query);
echo "<b>Borrado descargas <b>$borrardescargas</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un descarga
else if($enviar) {
function quitardescargas($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitardescargas($titulo) ;
$descripcion = quitardescargas($descripcion) ;
$categoria = quitardescargas($categoria) ;
$urlsitio = quitardescargas($urlsitio) ;
mysql_query("update descargas set titulo='$titulo',descripcion='$descripcion',categoria='$categoria',urlsitio='$urlsitio' where id='$editardescargas'") ;
if ($editardescargas == "" ) {echo "";} else echo "Actualizado descargas $editardescargas<br><br>" ;
} 
// si se te pide editar un descarga
else if ($editardescargas) {
$resp3 = mysql_query("select * from descargas where id='$editardescargas'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editardescargas"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="96%" height="7" class="tabla_subtitulo"><b>Editar descargas</b> </td>
    <td width="4%" class="tabla_subtitulo"><center>
        <a href="index.php?id=administrar#editardescargas2">x</a>
</center></td>
  </tr>
  <tr> 
    <td height="7" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editardescargas=<? echo $datos3[id] ?>#editardescargas2' onsubmit="return revisar()">
        <p><b>T�tulo:</b><br>
          <input type="text" name="titulo" size="30" maxlength="35" value="<? echo $datos3[titulo] ?>" class="form">
          <br>
          <b>Descripci�n de archivo:</b><br>
          <textarea name="descripcion" cols="30" rows="5" class="form" onKeyPress="caracteres"><? echo $datos3[descripcion] ?></textarea>
          <br>
          <script>
function caracteres() {
if(formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.titulo.value.length > 100) { alert('El tiulo del archivo supera los 100 caract�res.') ; return false ; } 
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el descarga .') ; return false ; }
if(formulario.urlsitio.value.length > 100) { alert('La url del archivo supera los 100 caract�res.') ; return false ; }
}
</script>
          <input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<b><br>
          Categor�a:</b><br>
          <select name="categoria" class="form">������������
            <option <? if ($datos3[categoria] == "0" ) {echo "selected"; } ?> value='0'> 
            <? if ($descarga0 != "" ) {echo "$descarga0"; } else echo "0"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "1" ) {echo "selected"; } ?> value='1'> 
            <? if ($descarga1 != "" ) {echo "$descarga1"; } else echo "1"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "2" ) {echo "selected"; } ?> value='2'> 
            <? if ($descarga2 != "" ) {echo "$descarga2"; } else echo "2"; ?>
            ������������ 
            <option <? if ($datos3[categoria] == "3" ) {echo "selected"; } ?> value='3'> 
            <? if ($descarga3 != "" ) {echo "$descarga3"; } else echo "3"; ?>
            ������������ 
            <option value='4' <? if ($datos3[categoria] == "4" ) {echo "selected"; } ?>> 
            <? if ($descarga4 != "" ) {echo "$descarga4"; } else echo "4"; ?>
            ������������ 
            <option value='5' <? if ($datos3[categoria] == "5" ) {echo "selected"; } ?>> 
            <? if ($descarga5 != "" ) {echo "$descarga5"; } else echo "5"; ?>
            ������������ 
            <option value='6' <? if ($datos3[categoria] == "6" ) {echo "selected"; } ?>> 
            <? if ($descarga6 != "" ) {echo "$descarga6"; } else echo "6"; ?>
            ������������ 
            <option value='7' <? if ($datos3[categoria] == "7" ) {echo "selected"; } ?>> 
            <? if ($descarga7 != "" ) {echo "$descarga7"; } else echo "7"; ?>
            ������������ 
            <option value='8' <? if ($datos3[categoria] == "8" ) {echo "selected"; } ?>> 
            <? if ($descarga8 != "" ) {echo "$descarga8"; } else echo "8"; ?>
            ������������ 
            <option value='9' <? if ($datos3[categoria] == "9" ) {echo "selected"; } ?>> 
            <? if ($descarga9 != "" ) {echo "$descarga9"; } else echo "9"; ?>
            ���������� 
          </select>
          <br>
          <b>URL del descarga :</b><br>
          <input type="text" name="urlsitio" size="30" maxlenght="100" value="<? echo $datos3[urlsitio] ?>" class="form">
          <br>
          <br>
          <input type='submit' name='enviar' value='Editar descarga' class='form'>
      </form></td>
  </tr>
</table>
<br>
<? 
}
//muestra todos los registros descargas.
?>
<a name="editardescargas2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td colspan="5" class="tabla_titulo">
<div class="t1">Listado de descargas</div>
</td>
<?
?>
<tr>
<td class="tabla_subtitulo"><b>Id</b></td>
<td class="tabla_subtitulo"><b>Titulo</b></td>
<td class="tabla_subtitulo"><b>Descripcion</b></td>
<td class="tabla_subtitulo">&nbsp;</td>
<td class="tabla_subtitulo">&nbsp;</td>
<? 
$mostrardescargas = 10 ; 
if(!$desdedescargas) { $desdedescargas = 0 ; }
$query = "select * from descargas order by id asc limit $desdedescargas,$mostrardescargas"; 
$desdedescargas = $desdedescargas + $mostrardescargas ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?><tr>
<td class="tabla_mensaje"><? echo $datos[id] ?></td>
<td class="tabla_mensaje"><a href="<? echo $datos[urlsitio] ?>" target="_blank"><? echo $datos[titulo] ?></a></td>
<td class="tabla_mensaje"><? echo $datos[descripcion] ?></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&borrardescargas=<? echo $datos[id] ?>#editardescargas2>Borrar</a></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&editardescargas=<? echo $datos[id] ?>#editardescargas>Editar</a></td>
</tr>
<?
} 
?>
<tr> 
<td colspan="5" class="tabla_subtitulo">
<?
// paginamos los resultados de descargas.
mysql_free_result($resp);
if($desdedescargas > $mostrardescargas) {
$anterioresdescargas = $mostrardescargas * 2 ;
if($desdedescargas == $anterioresdescargas) {
echo "<p align=right><a href=index.php?id=administrar#editardescargas2>Anteriores $mostrardescargas descargas</a> | " ;
}
else {
$anterioresdescargas = $desdedescargas - $mostrardescargas * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdedescargas=$anterioresdescargas#editardescargas2>Anteriores $mostrardescargas descargas</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdedescargas < $descargas) {
echo "<a href=index.php?id=administrar&desdedescargas=$desdedescargas#editardescargas2>Siguientes $mostrardescargas descargas</a>" ;
}
if($desdedescargas > $descargas) {
echo "<a href=index.php?id=administrar&desdedescargas=$desdedescargas#editardescargas2>Siguientes $mostrardescargas descargas</a>" ;
echo "</p>" ;
} 
?>
</td>
</tr>
</table>
<?
// liberamos memoria y desconecta de mysql en descargas. 
@mysql_close($conecta); 
?>
<br>
<br>
<? 
include("config.php");
//si se pide borrar usuarios.
if ($borrarusuarios) { 
$query = "delete from usuarios where id='$borrarusuarios'"; 
mysql_query($query);
echo "<b>Borrado usuarios <b>$borrarusuarios</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un usuario
else if($enviar) {
function quitarusuarios($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$nick = quitarusuarios($nick) ;
$email = quitarusuarios($email) ;
mysql_query("update usuarios set nick='$nick',email='$email' where id='$editarusuarios'") ;
if ($editarusuarios == "" ) {echo "";} else echo "Actualizado usuarios $editarusuarios<br><br>" ;
} 
// si se te pide editar un usuario
else if ($editarusuarios) {
$resp3 = mysql_query("select * from usuarios where id='$editarusuarios'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarusuarios"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="96%" height="7" class="tabla_subtitulo"><b>Editar usuarios</b> </td>
    <td width="4%" class="tabla_subtitulo"><center>
        <a href="index.php?id=administrar#editarusuarios2">x</a>
</center></td>
  </tr>
  <tr> 
    <td height="151" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editarusuarios=<? echo $datos3[id] ?>#editarusuarios2' onsubmit="return revisar()">
        <p><b>T�tulo:</b><br>
          <input type="text" name="nick" size="30" maxlength="35" value="<? echo $datos3[nick] ?>" class="form">
          <br>
          <b>Descripci�n de archivo:</b><br>
          <input name="email" type="text" class="form" value="<? echo $datos3[email] ?>" size="30">
          <br>
          <br>
          <input type='submit' name='enviar' value='Editar usuario' class='form'>
      </form></td>
  </tr>
</table>
<br>
<? 
}
//muestra todos los registros usuarios.
?>
<a name="editarusuarios2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td colspan="6" class="tabla_titulo"> <div class="t1">Listado de usuarios</div></td>
    <?
?>
  <tr> 
    <td class="tabla_subtitulo"><b>Id</b></td>
    <td class="tabla_subtitulo"><b>Nick</b></td>
    <td class="tabla_subtitulo"><b>Email</b></td>
    <td class="tabla_subtitulo"><b>Ip</b></td>
    <td class="tabla_subtitulo">&nbsp;</td>
    <td class="tabla_subtitulo">&nbsp;</td>
    <? 
$mostrarusuarios = 10 ; 
if(!$desdeusuarios) { $desdeusuarios = 0 ; }
$query = "select * from usuarios order by id asc limit $desdeusuarios,$mostrarusuarios"; 
$desdeusuarios = $desdeusuarios + $mostrarusuarios ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?>
  <tr> 
    <td class="tabla_mensaje"><? echo $datos[id] ?></td>
    <td class="tabla_mensaje"><a href="<? echo $datos[urlsitio] ?>" target="_blank"><? echo $datos[nick] ?></a></td>
    <td class="tabla_mensaje"><? echo $datos[email] ?></td>
    <td class="tabla_mensaje"><? echo $datos[ip] ?></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&borrarusuarios=<? echo $datos[id] ?>#editarusuarios2>Borrar</a></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&editarusuarios=<? echo $datos[id] ?>#editarusuarios>Editar</a></td>
  </tr>
  <?
} 
?>
  <tr> 
    <td colspan="6" class="tabla_subtitulo"> 
      <?
// paginamos los resultados de usuarios.
mysql_free_result($resp);
if($desdeusuarios > $mostrarusuarios) {
$anterioresusuarios = $mostrarusuarios * 2 ;
if($desdeusuarios == $anterioresusuarios) {
echo "<p align=right><a href=index.php?id=administrar#editarusuarios2>Anteriores $mostrarusuarios usuarios</a> | " ;
}
else {
$anterioresusuarios = $desdeusuarios - $mostrarusuarios * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdeusuarios=$anterioresusuarios#editarusuarios2>Anteriores $mostrarusuarios usuarios</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdeusuarios < $usuarios) {
echo "<a href=index.php?id=administrar&desdeusuarios=$desdeusuarios#editarusuarios2>Siguientes $mostrarusuarios usuarios</a>" ;
}
if($desdeusuarios > $usuarios) {
echo "<a href=index.php?id=administrar&desdeusuarios=$desdeusuarios#editarusuarios2>Siguientes $mostrarusuarios usuarios</a>" ;
echo "</p>" ;
} 
?>
    </td>
  </tr>
</table>
<?
// liberamos memoria y desconecta de mysql en usuarios. 
@mysql_close($conecta); 
?>
<br>
<br>
<? 
include("config.php");
//si se pide borrar noticias.
if ($borrarnoticias) { 
$query = "delete from noticias where id='$borrarnoticias'"; 
mysql_query($query);
echo "<b>Borrado noticias <b>$borrarnoticias</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un noticia
else if($enviar) {
function quitarnoticias($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$titulo = quitarnoticias($titulo) ;
$noticia = quitarnoticias($noticia) ;
$categoria = quitarnoticias($categoria) ;
$noticiaext = quitarnoticias($noticiaext) ;
mysql_query("update noticias set titulo='$titulo',noticia='$noticia',noticiaext='$noticiaext' where id='$editarnoticias'") ;
if ($editarnoticias == "" ) {echo "";} else echo "Actualizado noticias $editarnoticias<br><br>" ;
} 
// si se te pide editar un noticia
else if ($editarnoticias) {
$resp3 = mysql_query("select * from noticias where id='$editarnoticias'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarnoticias"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td width="96%" height="7" class="tabla_subtitulo"><b>Editar noticias</b> </td>
<td width="4%" class="tabla_subtitulo"><center>
<a href="index.php?id=administrar#editarnoticias2">x</a>
</center></td>
</tr>
<tr> 
<td height="7" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editarnoticias=<? echo $datos3[id] ?>#editarnoticias2' onsubmit="return revisar()">
<p><b>T�tulo:</b><br>
<input type="text" name="titulo" size="30" maxlength="35" value="<? echo $datos3[titulo] ?>" class="form">
<br>
          <b>Noticia:</b><br>
<textarea name="noticia" cols="30" rows="5" class="form" onKeyPress="caracteres"><? echo $datos3[noticia] ?></textarea>
<br>
<script>
function caracteres() {
if(formulario.caracteres.value != formulario.noticia.value.length) {
formulario.caracteres.value = formulario.noticia.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.titulo.value.length > 100) { alert('El tiulo del archivo supera los 100 caract�res.') ; return false ; } 
if(formulario.noticia.value.length == 0) { alert('Debes escribir una noticia .') ; return false ; } 
if(formulario.noticia.value.length > 255) { alert('La noticia supera los 255 caract�res.') ; return false ; }
if(formulario.noticiaext.value.length == 0) { alert('Debes escribir el noticia extendida .') ; return false ; }
if(formulario.noticiaext.value.length > 100) { alert('La url del archivo supera los 100 caract�res.') ; return false ; }
}
</script>
<input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<br>
          <b>Noticia extendida:</b><br>
          <textarea name="noticiaext" cols="30" rows="5" class="form" maxlenght="100"><? echo $datos3[noticiaext] ?></textarea>
<br>
<br>
<input type='submit' name='enviar' value='Editar noticia' class='form'>
</form></td>
</tr>
</table>
<br>
<? 
}
//muestra todos los registros noticias.
?>
<a name="editarnoticias2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td colspan="5" class="tabla_titulo">
<div class="t1">Listado de noticias</div>
</td>
<?
?>
<tr>
<td class="tabla_subtitulo"><b>Id</b></td>
<td class="tabla_subtitulo"><b>Titulo</b></td>
    <td class="tabla_subtitulo"><b>Usuario</b></td>
<td class="tabla_subtitulo">&nbsp;</td>
<td class="tabla_subtitulo">&nbsp;</td>
<? 
$mostrarnoticias = 10 ; 
if(!$desdenoticias) { $desdenoticias = 0 ; }
$query = "select * from noticias order by id asc limit $desdenoticias,$mostrarnoticias"; 
$desdenoticias = $desdenoticias + $mostrarnoticias ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?><tr>
<td class="tabla_mensaje"><? echo $datos[id] ?></td>
<td class="tabla_mensaje"><a href="<? echo $datos[noticiaext] ?>" target="_blank"><? echo $datos[titulo] ?></a></td>
<td class="tabla_mensaje"><? echo $datos[usuario] ?></td>
<td class="tabla_mensaje"><a href=index.php?id=administrar&borrarnoticias=<? echo $datos[id] ?>#editarnoticias2>Borrar</a></td>
<td class="tabla_mensaje"><a href=index.php?id=administrar&editarnoticias=<? echo $datos[id] ?>#editarnoticias>Editar</a></td>
</tr>
<?
} 
?>
<tr> 
<td colspan="5" class="tabla_subtitulo">
<?
// paginamos los resultados de noticias.
mysql_free_result($resp);
if($desdenoticias > $mostrarnoticias) {
$anterioresnoticias = $mostrarnoticias * 2 ;
if($desdenoticias == $anterioresnoticias) {
echo "<p align=right><a href=index.php?id=administrar#editarnoticias2>Anteriores $mostrarnoticias noticias</a> | " ;
}
else {
$anterioresnoticias = $desdenoticias - $mostrarnoticias * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdenoticias=$anterioresnoticias#editarnoticias2>Anteriores $mostrarnoticias noticias</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdenoticias < $noticias) {
echo "<a href=index.php?id=administrar&desdenoticias=$desdenoticias#editarnoticias2>Siguientes $mostrarnoticias noticias</a>" ;
}
if($desdenoticias > $noticias) {
echo "<a href=index.php?id=administrar&desdenoticias=$desdenoticias#editarnoticias2>Siguientes $mostrarnoticias noticias</a>" ;
echo "</p>" ;
} 
?>
</td>
</tr>
</table>
<?
// liberamos memoria y desconecta de mysql en noticias. 
@mysql_close($conecta); 
?>

<br>
<br>
<? 
include("config.php");
//si se pide borrar noticiascom.
if ($borrarnoticiascom) { 
$query = "delete from noticiascom where id='$borrarnoticiascom'"; 
mysql_query($query);
echo "<b>Borrado noticiascom <b>$borrarnoticiascom</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un noticiacom
else if($enviar) {
function quitarnoticiascom($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$noticia = quitarnoticiascom($noticia) ;
$comentario = quitarnoticiascom($comentario) ;
mysql_query("update noticiascom set comentario='$comentario' where id='$editarnoticiascom'") ;
if ($editarnoticiascom == "" ) {echo "";} else echo "Actualizado noticiascom $editarnoticiascom<br><br>" ;
} 
// si se te pide editar un noticiacom
else if ($editarnoticiascom) {
$resp3 = mysql_query("select * from noticiascom where id='$editarnoticiascom'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarnoticiascom"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td width="96%" height="7" class="tabla_subtitulo"><b>Editar noticiascom</b> </td>
<td width="4%" class="tabla_subtitulo"><center>
<a href="index.php?id=administrar#editarnoticiascom2">x</a>
</center></td>
</tr>
<tr> 
<td height="207" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editarnoticiascom=<? echo $datos3[id] ?>#editarnoticiascom2' onsubmit="return revisar()">
        <p><b>Comentario:</b><br>
          <textarea name="comentario" cols="30" rows="5" class="form" id="comentario" onKeyPress="caracteres"><? echo $datos3[comentario] ?></textarea>
          <br>
          <script>
function caracteres() {
if(formulario.caracteres.value != formulario.noticia.value.length) {
formulario.caracteres.value = formulario.noticia.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.comentario.value.length > 255) { alert('El comentario supera los 255 caract�res.') ; return false ; } 
if(formulario.comentario.value.length == 0) { alert('Debes escribir un comentario .') ; return false ; } 
}
</script>
          <input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<br>
          <br>
          <input type='submit' name='enviar' value='Editar noticiacom' class='form'>
      </form></td>
</tr>
</table>
<br>
<? 
}
//muestra todos los registros noticiascom.
?>
<a name="editarnoticiascom2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td colspan="5" class="tabla_titulo"> <div class="t1">Listado de noticiascom</div></td>
    <?
?>
  <tr> 
    <td width="9%" class="tabla_subtitulo"><b>Id</b></td>
    <td class="tabla_subtitulo"><b>Usuario</b></td>
    <td width="29%" class="tabla_subtitulo"><b>Comentario</b></td>
    <td width="17%" class="tabla_subtitulo">&nbsp;</td>
    <td width="21%" class="tabla_subtitulo">&nbsp;</td>
    <? 
$mostrarnoticiascom = 10 ; 
if(!$desdenoticiascom) { $desdenoticiascom = 0 ; }
$query = "select * from noticiascom order by id asc limit $desdenoticiascom,$mostrarnoticiascom"; 
$desdenoticiascom = $desdenoticiascom + $mostrarnoticiascom ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?>
  <tr> 
    <td class="tabla_mensaje"><? echo $datos[id] ?></td>
    <td class="tabla_mensaje"><a href="<? echo $datos[noticiaext] ?>" target="_blank"><? echo $datos[usuario] ?></a></td>
    <td class="tabla_mensaje"><? echo $datos[comentario] ?></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&borrarnoticiascom=<? echo $datos[id] ?>#editarnoticiascom2>Borrar</a></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&editarnoticiascom=<? echo $datos[id] ?>#editarnoticiascom>Editar</a></td>
  </tr>
  <?
} 
?>
  <tr> 
    <td colspan="5" class="tabla_subtitulo"> 
      <?
// paginamos los resultados de noticiascom.
mysql_free_result($resp);
if($desdenoticiascom > $mostrarnoticiascom) {
$anterioresnoticiascom = $mostrarnoticiascom * 2 ;

if($desdenoticiascom == $anterioresnoticiascom) {
echo "<p align=right><a href=index.php?id=administrar#editarnoticiascom2>Anteriores $mostrarnoticiascom noticiascom</a> | " ;
}
else {
$anterioresnoticiascom = $desdenoticiascom - $mostrarnoticiascom * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdenoticiascom=$anterioresnoticiascom#editarnoticiascom2>Anteriores $mostrarnoticiascom noticiascom</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdenoticiascom < $noticiascom) {
echo "<a href=index.php?id=administrar&desdenoticiascom=$desdenoticiascom#editarnoticiascom2>Siguientes $mostrarnoticiascom noticiascom</a>" ;
}
if($desdenoticiascom > $noticiascom) {
echo "<a href=index.php?id=administrar&desdenoticiascom=$desdenoticiascom#editarnoticiascom2>Siguientes $mostrarnoticiascom noticiascom</a>" ;
echo "</p>" ;
} 
?>
    </td>
  </tr>
</table>
<?
// liberamos memoria y desconecta de mysql en noticiascom. 
@mysql_close($conecta); 
?>
<br>
<br>
<? 
include("config.php");
//si se pide borrar mensajes.
if ($borrarmensajes) { 
$query = "delete from mensajes where id='$borrarmensajes'"; 
mysql_query($query);
echo "<b>Borrado mensajes <b>$borrarmensajes</b>. <a href=index.php?id=administrar></a><br><br>"; 
}
// si llega a terminiar de editar un mensaje
else if($enviar) {
function quitarmensajes($texto) { 
$texto = trim($texto) ; 
$texto = htmlspecialchars($texto) ;
return $texto ; 
}
$noticia = quitarmensajes($noticia) ;
$comentario = quitarmensajes($comentario) ;
mysql_query("update mensajes set mensaje='$mensaje' where id='$editarmensajes'") ;
if ($editarmensajes == "" ) {echo "";} else echo "Actualizado noticiascom $editarmensajes<br><br>" ;
} 
// si se te pide editar un mensaje
else if ($editarmensajes) {
$resp3 = mysql_query("select * from mensajes where id='$editarmensajes'") ;
$datos3 = mysql_fetch_array($resp3) ;
?>
<a name="editarmensajes"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
<tr> 
<td width="96%" height="7" class="tabla_subtitulo"><b>Editar mensajes</b> </td>
<td width="4%" class="tabla_subtitulo"><center>
<a href="index.php?id=administrar#editarmensajes2">x</a>
</center></td>
</tr>
<tr> 
<td height="207" colspan="2" class="tabla_mensaje"><form name='formulario' method='post' action='index.php?id=administrar&editarmensajes=<? echo $datos3[id] ?>#editarmensajes2' onsubmit="return revisar()">
        <p><b>Mensaje:</b><br>
          <textarea name="mensaje" cols="30" rows="5" class="form" id="mensaje" onKeyPress="caracteres"><? echo $datos3[mensaje] ?></textarea>
          <br>
<script>
function caracteres() {
if(formulario.caracteres.value != formulario.mensaje.value.length) {
formulario.caracteres.value = formulario.mensaje.value.length ;
}
setTimeout("caracteres()",300) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() {
if(formulario.mensaje.value.length > 255) { alert('El mensaje supera los 255 caract�res.') ; return false ; } 
if(formulario.mensaje.value.length == 0) { alert('Debes escribir un mensaje.') ; return false ; } 
}
</script>
          <input type="text" name="caracteres" size="3" value="0" class="form">
          M�ximo 255 caract�res<br>
          <br>
          <input type='submit' name='enviar' value='Editar mensaje' class='form'>
      </form></td>
</tr>
</table>
<br>
<? 
}
//muestra todos los registros mensajes.
?>
<a name="editarmensajes2"></a>
<table width="100%" border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td colspan="6" class="tabla_titulo"> <div class="t1">Listado de mensajes</div></td>
    <?
?>
  <tr> 
    <td width="8%" class="tabla_subtitulo"><b>Id</b></td>
    <td width="11%" class="tabla_subtitulo"><b>Remitente</b></td>
    <td width="12%" class="tabla_subtitulo"><b>Destinatario</b></td>
    <td width="28%" class="tabla_subtitulo"><b>Mensaje</b></td>
    <td width="16%" class="tabla_subtitulo">&nbsp;</td>
    <td width="25%" class="tabla_subtitulo">&nbsp;</td>
    <? 
$mostrarmensajes = 10 ; 
if(!$desdemensajes) { $desdemensajes = 0 ; }
$query = "select * from mensajes order by id asc limit $desdemensajes,$mostrarmensajes"; 
$desdemensajes = $desdemensajes + $mostrarmensajes ;
$resp = mysql_query($query);
while ($datos = mysql_fetch_array($resp)) {
?>
  <tr> 
    <td class="tabla_mensaje"><? echo $datos[id] ?></td>
    <td class="tabla_mensaje"><a href="<? echo $datos[noticiaext] ?>" target="_blank"><? echo $datos[remitente] ?></a></td>
    <td class="tabla_mensaje"><a href="<? echo $datos[noticiaext] ?>" target="_blank"><? echo $datos[destinatario] ?></a></td>
    <td class="tabla_mensaje"><? echo $datos[mensaje] ?></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&borrarmensajes=<? echo $datos[id] ?>#editarmensajes2>Borrar</a></td>
    <td class="tabla_mensaje"><a href=index.php?id=administrar&editarmensajes=<? echo $datos[id] ?>#editarmensajes>Editar</a></td>
  </tr>
  <?
} 
?>
  <tr> 
    <td colspan="6" class="tabla_subtitulo"> 
      <?
// paginamos los resultados de mensajes.
mysql_free_result($resp);
if($desdemensajes > $mostrarmensajes) {
$anterioresmensajes = $mostrarmensajes * 2 ;

if($desdemensajes == $anterioresmensajes) {
echo "<p align=right><a href=index.php?id=administrar#editarmensajes2>Anteriores $mostrarmensajes mensajes</a> | " ;
}
else {
$anterioresmensajes = $desdemensajes - $mostrarmensajes * 2 ;
echo "<p align=right><a href=index.php?id=administrar&desdemensajes=$anterioresmensajes#editarmensajes2>Anteriores $mostrarmensajes mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desdemensajes < $mensajes) {
echo "<a href=index.php?id=administrar&desdemensajes=$desdemensajes#editarmensajes2>Siguientes $mostrarmensajes mensajes</a>" ;
}
if($desdemensajes > $mensajes) {
echo "<a href=index.php?id=administrar&desdemensajes=$desdemensajes#editarmensajes2>Siguientes $mostrarmensajes mensajes</a>" ;
echo "</p>" ;
} 
?>
    </td>
  </tr>
</table>
<?
// liberamos memoria y desconecta de mysql en mensajes. 
@mysql_close($conecta); 
?>
<br>
<br>
<?
}
else {
echo "Solo $administrador puede administrar el sitio." ;
}
}
?>
