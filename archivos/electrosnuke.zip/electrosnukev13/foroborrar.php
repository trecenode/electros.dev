<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
include("config.php") ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
// Si alguien trata de poner el nombre del administrador en la barra de direcciones se le denegar� el acceso
if($_GET[$administrador]) { echo "Acceso denegado. Intento de hackeo." ; }
// Tambi�n se comprueba si la contrase�a guardada en la base de datos coincide con la de la cookie
$resp = mysql_query("select contrasena from $tabla_usuarios where nick='$administrador'") ;
$datos = mysql_fetch_array($resp) ;
$datos[contrasena] = md5(md5($datos[contrasena])) ;
if($datos[contrasena] == $_COOKIE[ucontrasena]) {
// Se borra el tema con todos los mensajes que contiene
if($borrar == "tema") {
$resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_query("update eforo_foros set temas=temas-1,mensajes=mensajes-$mensajes where id='$foroid'") ;
mysql_query("delete from eforo_mensajes where forotema='$temaid'") ;
echo "
<p><b>Tema borrado:</b> $temaid<br><b>Mensajes borrados en total:</b> $mensajes
<p><a href=foro.php?foroid=$foroid>Regresar al foro</a>
" ;
mysql_free_result($resp) ;
}
// Se borra un s�lo mensaje siempre y cuando no sea un tema
if($borrar == "mensaje") {
mysql_query("update eforo_mensajes set mensajes=mensajes-1 where id='$temaid'") ;
mysql_query("update eforo_foros set mensajes=mensajes-1 where id='$foroid'") ;
mysql_query("delete from eforo_mensajes where id='$mensajeid'") ;
echo "
<p><b>Mensaje borrado:</b> $mensajeid
<p><a href=foro.php?foroid=$foroid&temaid=$temaid>Regresar al tema</a>
" ;
}
}
else {
echo "S�lo el administrador tiene acceso a esta �rea" ;
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
</body>
</html>
