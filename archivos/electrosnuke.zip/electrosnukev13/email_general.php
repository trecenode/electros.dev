<script>
function valida() {
if(formulario.mensaje.value == '') { alert('Tienes que poner un email valido.') ; return false ; }
if(formulario.asunto.value == '') { alert('El asunto no puede estar vac�o.') ; return false ; }
if(formulario.remite.value == '') { alert('El mensaje no puede estar vac�o.') ; return false ; }
}
</script>

<?
// MOD por "MaKa"  http://manuel.freedatos.com para la web de Electros.
   
include("config.php") ;
if($enviar) {
$query = "select email,nick from usuarios where lista like '1' order by id" ;
$resp = mysql_query($query);
$totales = mysql_num_rows($resp) ;
$i = 0 ; $j = 0 ;
echo "Lista de mensajes enviados.";

while ($datos = mysql_fetch_array($resp)) {
    $email = $datos[email] ;
    $nick = $datos[nick] ;
    $mensajeb = str_replace("[nick]",$nick,$mensaje) ;

$bien = mail($email,$asunto,$mensajeb,"Content-Type:text/html; charset=iso-8859-15, From: $remiternReply-To: $remitern"); 
$i++ ;

echo "<br>$i - ";
if($bien){ 
    echo "Mensaje para: $nick ($email): <b>OK</b>";
  } else {    
    echo "<font color=#FF0000><b>Mensaje fallido para: $nick ($email)</b></font>";
    $j++ ;
  }
}
$k = $i - $j ;
echo "<br><br>Enviados: $k de $totales <br><hr>" ;
if($i == $totales) {
echo "<b>Mensaje enviado:</b><br> $mensaje<br><hr> <br>Se ha completado el env�o de los mensajes<br>
Total enviados: <b>$i</b><br><br>
<a href=javascript:history.back()>Volver a enviar otro mensaje</a><br>
";
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
} 

else {
?> 
<form action="email_general.php" method="post" name="formulario" onSubmit="return valida()">
  <blockquote>
   Remitente:<br>  <input name="remite" type="text" value="Aqui Tu email"><br><br>
   Asunto:<br>     <input name="asunto" type="text"><br><br>
   Mensaje:<br>    <textarea name="mensaje" cols="40" rows="5"></textarea><br><br>
                   <input name="enviar" type="submit" value="Enviar"> 
  </blockquote>
</form>
 Puedes usar [nick] para personalizar el mensaje. ej: Hola [nick]...
<? } ?>