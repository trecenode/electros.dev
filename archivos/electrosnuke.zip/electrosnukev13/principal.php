<p>Electrosnuke es un script modificado por phpmysql.tk y echo por Electros.tk<br>
  <a href="http://recursosphp.iefactory.com/descargas.php?e=125">&gt;&gt; Descargar 
  electrosnuke v1.3 <<</a><br>
  <br>
  <strong>Novedades en la version v1.3 :</strong><br>
  <br>
  1) sistema de enlaces, paginacion de 6 en 6 en los enlaces por categorias, tanto 
  en los enlaces como en las descargar se <br>
  ha habilitado un sistema ideal para agregar edonkey links en la categoria 6. 
  <br>
  1) top 10 enlaces<br>
  2) sistema de afiliados con banner<br>
  3) sistemas de afiliados con minibanner<br>
  4) Ultimo usuario registrado.<br>
  5) zona de administracion - solo ver y borrar e implementado el sistema de administracion 
  de <a href="mailto:pablo_morpheo@hotmail.com">morpheo</a><br>
  6) posibilidad de editar enlaces por administrador y el usuario proveedor del 
  enlace<br>
  7) Enlaces ordenados de 6 en 6 y con la posibilidad de incluirle una imagen 
  via url al editarlo<br>
  8) Las paginas han sido remodeladas en muchos aspectos, para que sean mas sencillas 
  editarlas.<br>
  9) Al desconectar, desaparici&oacute;n del nombre del usuario en la lista de 
  Uenlinea<br>
  10) Ahora el eforo v 2.1 depende del la tabla <strong>usuarios</strong> (por 
  lo tanto los usuarios podran registrarse solo 1 vez)<br>
  11) El archivo de configuracion es el config.php y foroconfig.php donde se genera 
  todo el entorno del portal.<br>
  13) Sistema de descargas, con posibilidad de enviar una descarga al servidor 
  o via url, limitar el tama&ntilde;o, la extension<br>
  la carpeta donde se sube...<br>
  14) usuarios.php paginando los usuarios de 25 en 25<br>
  15) Paginacion de comentarios de noticias mejorada en noticias.php, ahora se 
  pueden ver los anteriores comentarios<br>
  y los posteriores<br>
  16) Instalar.php mejorado y sistematizado eficazmente por <a href="mailto:pablo_morpheo@hotmail.com">morpheo</a><br>
  17) Al logearnos el registro de usuarios nos envia a la pagina en la que nos 
  encontramos actualmente y no al index.php<br>
  como anteriormente sucedia.<br>
  18) Nuevo panel de administracion v2 por elcidop.com, en <strong>administrar.php</strong><br>
  19) Podemos ver los zips que hay en el directorio descargas/ a traves de un 
  index.php en el mismo directorio, esto sirve<br>
  para poder ver los archivos con extension .zip de una forma directa y sin utilizar 
  el mysql, llamado como <strong>galeria de descargas</strong>.<br>
  20) Galeria de imagenes en la carpeta eforo_imagenes en el index.php de esa 
  misma carpeta, llamamado <strong>galeria de imagenes</strong>.<br>
  <br>
  <strong>Instalacion:</strong><br>
  <br>
  1) Sube los archivos a tu servidor y abre el archivo <a href="instalar.php">instalar.php</a> 
  para <br>
  instalar electrosnuke v1.3 y configurarlo<br>
  <br>
  2) Borra el archivo instalar.php<br>
  <br>
  3) Modifica el archivo <a href="principal.php">principal.php</a> que es donde 
  se muestra este mensaje<br>
  de bienvenida y personalizalo con un texto de bienvenida.<br>
  <br>
  4) Este sistema de paginas tipo <strong>index.php?id=</strong> es bastaste sencillo 
  :<br>
  <em>a)</em> Si tu tienes una pagina llamada <strong>util.php</strong> tendrias 
  que hacer los links a la pagina<br>
  de la siguiente forma <strong>index.php?id=util</strong><br>
  <em>b) </em>Si por algun casual pones una pagina <strong><a href="index.php?id=noexiste">index.php?id=noexiste</a></strong> 
  te mostraria<br>
  <strong><a href="noexiste.php">noexiste.php</a></strong>, pero como esa pagina 
  no existe fisicamente pues te abre<br>
  automaticamente <strong><a href="error.php">error.php</a></strong>, por eso 
  debes personalizar la pagina de error.<br>
  c) Si se da el caso de que quieres cambiar una pagina a este sistema y tienes 
  los links<br>
  asi de esta manera <strong><a href="noticias.php?n=1">noticias.php?n=</a></strong> 
  tendrias que cambiarlos por esta otra forma<br>
  <strong><a href="index.php?id=noticias&n=1">index.php?id=noticias&amp;n=</a> 
  </strong>, en los casos en los que por ejemplo sea un formulario<br>
  a otra pagina distinta, no deberias cambiarlo ( solo deberias cambiarlo en la 
  otra pagina,<br>
  para que no de error de<em> cannon add headers</em> ).<br>
  5) personaliza el index.php a tu gusto, puedes mover los codigos php donde quieras 
  pero recuerda<br>
  no borralos o si no te funcionara.<br>
  6) comienza a&ntilde;adiendo enlaces y sus catogoria en el config.php; veras 
  como se a&ntilde;aden automaticamente en el menu top 10 enlaces<br>
  ademas en <a href="index.php?id=enlaces">enlaces.php</a>.<br>
  7) Personaliza el estilo de tu pagina, recuerda que todos los estilos estan 
  en eforo_estilos/<br>
  <br>
  <strong>Bugs detectados y corregidos</strong><br>
  <br>
  <em>1)</em> 31/12/2003 Faltaba el campo imagen en la tabla enlaces y descargas 
  que no permitia editarlos, archivos modificados: <strong>instalar.php, administrar2.php</strong>, 
  los que se hayan descargado el registro de usuarios antes de esa fecha que pegen<br>
  estos codigo en su casilla mysql<br>
  a) <strong>ALTER TABLE `descargas`ADD `imagen` VARCHAR(150) NOT NULL ;</strong><br>
  b) <strong>ALTER TABLE `enlaces` ADD `imagen` VARCHAR(150) NOT NULL ;</strong><br>
  <em>2)</em>31/12/2003 Se ha atribuido una cabeza html al foro que le faltaba 
  con el titulo de la pagina, archivos modificados: <strong>foro.php</strong><br>
  <em>3)</em> 31/12/2003 Se ha agregado nuevos campos como edad que no se veia,web 
  y firma ,archivos modificados: <strong>usuarios.php</strong><br>
  4) 32/12/2003 Mejorado algunos aspectos y funciones, archivos modificados: <strong>noticias.php, 
  enlaceseditar.php, descargaseditar.php</strong><br>
  <strong>descargas.php, enlaces.php</strong><br>
  5) 1/01/2004 Se ha arreglado un problema con los avatares que no permitian que 
  fueran borrados y editados, archivos modificados: <strong>uperfil.php</strong><br>
  6) 3/01/2004 Agregado el estilo estilo egris.php, archivos modificados: <strong>eforo_estilo</strong>/<strong>egris.php</strong>,<strong> 
  instalar.php, administrar2.php</strong><br>
  7) 7/01/2004 Nuevo sistema de mensajes mejorado con contador de mensajes disponibles 
  en % en la bandeja de entrada<br>
  archivo modificado y se a aumentado a 1024 caracteres asi como se ha facilitado 
  el borrado de mensajes en <strong>mensajes.php</strong><br>
  8) 27/05/2005 Al sistema de descargas se le ha a&ntilde;adido una opcion para 
  poder actualizar los archivos adjuntos.<br>
  <br>
  <a href="http://www.phpmysql.tk" target="_blank">www.phpmysql.tk</a><br>
  <a href="http://www.electros.tk" target="_blank">www.electros.tk</a><br>
  <a href="http://www.elcidop.com" target="_blank">www.elcidop.com</a></p>
