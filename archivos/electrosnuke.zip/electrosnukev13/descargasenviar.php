<?
include("ulogin.php") ;
?>
<?
include ("config.php") ;
if($enviar) {
$descarga = 0 ;
// Si el usuario quiere subir el archivo
if($archivo != "" && $envioarchivo == 1) {
// Comprobaciones para verificar si el archivo es correcto
$extensiones = explode(".",$archivo_name) ;
$num = count($extensiones) - 1 ;
if($extensiones[$num] != "$extensiondelarchivosoportada") { $error = "S�lo se permiten archivos .$extensiondelarchivosoportada<br>" ; }

if(file_exists("$carpetadondeseguardanlosarchivos/$archivo_name")) { $error = "Ya existe un archivo con este nombre.<br>" ; }
if($archivo_size > $tama�oporarchivoenviado) { $error .= "El archivo debe pesar menos de $tama�oporarchivoenviado Bytes.<br>" ; }
if($error) {
echo "
<p class=\"titulo\">Error
<p>$error
<p><a href=\"javascript:history.back()\">Regresar</a>
" ;
exit ;
}
copy($archivo,"$carpetadondeseguardanlosarchivos/$archivo_name") ;
$descarga = 1 ;
}
$fecha = time()  ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$usuario = $HTTP_COOKIE_VARS[unick] ;
$titulo = quitar($titulo) ;
$descripcion = quitar($descripcion) ;
$categoria = quitar($categoria) ;
$urlsitio = quitar($urlsitio) ;
$urlminibanner = quitar($urlminibanner) ;
if($urlsitio == "http://") { $urlsitio = "" ; }
if($urlminibanner == "http://") { $urlminibanner = "" ; }
if($envioarchivo == 1) { $urlsitio = $archivo_name ; }
mysql_query("insert into descargas (fecha,usuario,titulo,descripcion,categoria,urlsitio,urlminibanner,puntos,votos,calificacion,descarga)
values ('$fecha','$usuario','$titulo','$descripcion','$categoria','$urlsitio','$urlminibanner','5','1','5','$descarga')") ;
echo "La descarga ha sido agregada con �xito. Haz click <a href=index.php?id=descargas>aqu�</a> para regresar a descargas.<br><br>" ;
}
?>
<div class="t1">Enviar Descarga</div>
<br>
<form method="post" action="index.php?id=descargasenviar" name="formulario" enctype="multipart/form-data" onsubmit="return revisar()">
  <p><b>T�tulo:</b><br>
    <input type="text" name="titulo" size="30" maxlength="25" class="form">
    <br>
    <b>Descripci�n de archivo:</b><br>
    <textarea name="descripcion" cols="30" rows="5" class="form" onkeypress="caracteres"></textarea>
    <br>
    <script>
function caracteres() {
if(formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout("caracteres()",200) ;
}
onload=caracteres ;
archivo = 0 ;
function revisar() { 
if(formulario.titulo.value.length == 0) { alert('Debes escribir un titulo.') ; return false ; } 
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
if(formulario.urlminibanner.value.length == 0) { alert('Debes escribir el enlace extendido .') ; return false ; }
if(archivo == 0) { archivo++ ; } else { alert('El archivo se est� subiendo por favor espera.') ; return false ; }
}
</script>
    <input type="text" name="caracteres" size="3" value="0" class="form">
    M�ximo 255 caract�res<br>
    <b>Categor�a:</b><br>
    <select name='categoria' class='form'>
    <option value='0' selected><? echo $descarga0 ?> 
	<option value='1'><? echo $descarga1 ?> 
    <option value='2'><? echo $descarga2 ?>
	<option value='3'><? echo $descarga3 ?>
	<option value='4'><? echo $descarga4 ?>
    <option value='5'><? echo $descarga5 ?>
    <option value='6'><? echo $descarga6 ?>
    <option value='7'><? echo $descarga7 ?>
	<option value='8'><? echo $descarga8 ?>
	<option value='9'><? echo $descarga9 ?>
  </select>
    <br>
	<b>Como deseas enviar el archivo ?</b><br>
	<input type="radio" name="envioarchivo" value="0" id="envioarchivo1" checked><label for="envioarchivo1">Indicar s�lo URL para descargar</label>
	<input type="radio" name="envioarchivo" value="1" id="envioarchivo2"><label for="envioarchivo2">Subir el archivo</label>
	<br>
    <b>URL del archivo :</b><br>
    <input type="text" name="urlsitio" size="30" maxlenght="100" value="http://" class="form">
    <br>
	<b style="color: #ff0000">Archivo a subir (s�lo si est� seleccionada la segunda opci�n) :</b><br>
	<input type="file" name="archivo" size="30" class="form"><br>
    <b>URL del ejemplo practico del archivo :</b><br>
    <input type="text" name="urlminibanner" size="30" maxlenght="100" value="http://" class="form">
    <br>
    <br>
    <input type="submit" name="enviar" value="Enviar" class="form">
  </p>
  </form>

