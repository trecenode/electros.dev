<?
if($enviar) {
if(!$HTTP_COOKIE_VARS["enlaces$e"]) {
include("config.php") ;
$resp = mysql_query("select puntos,votos from enlaces where id='$e'") ;
$datos = mysql_fetch_array($resp) ;
$puntos = $datos[puntos] + $puntos ;
$votos = $datos[votos] + 1 ;
$calificacion = round($puntos / $votos,2) ;
mysql_query("update enlaces set puntos='$puntos',votos='$votos',calificacion='$calificacion' where id='$e'") ;
setcookie("enlaces$e","enlaces$e",time()+86400) ;
header("location: index.php?id=enlaces&calificar=si") ;
}
else {
header("location: index.php?id=enlaces&calificar=no") ;
}
}
?>