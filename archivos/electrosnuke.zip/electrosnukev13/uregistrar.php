<?
include("config.php") ;
if($registrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$email= quitar($email) ;
$sexo= quitar($sexo) ;
$edad= quitar($edad) ;
$pais= quitar($pais) ;
$descripcion= quitar($descripcion) ;
// Comprobar que el usuario existe en la base de datos
$resp = mysql_query("select id from usuarios where nick='$nick' or email='$email'") ;
if(mysql_num_rows($resp) != 0) {
echo "<font size=2 face=Verdana, Arial, Helvetica, sans-serif>Ya existe un usuario con ese 
nick o email en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> 
para regresar.</font>" ;
}
else {
$fecha = time() ;
$contrasena = quitar($contrasena) ;
$ip = $REMOTE_ADDR ;
mysql_query("insert into usuarios (fecha,nick,contrasena,email,ip,avatar,sexo,edad,descripcion,pais)
values ('$fecha','$nick','$contrasena','$email','$ip','$avatar','$sexo','$edad','$descripcion','$pais')") ;
echo "<font size=2 face=Verdana, Arial, Helvetica, sans-serif>Has sido registrado con �xito. Haz click <a href=index.php>aqu�</a> para ir a la p�gina principal.</font>" ;
}
}
else {
?>
<p><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Los 
datos marcados con un asterisco (*) son obligatorios.</font>
<!-- inicia codigo para aceptar condiciones -->
<script>
//change two names below to your form's names
document.forms.formulario.activar.checked=false
</script>
<script>
//"Accept terms" form submission- By Dynamic Drive
//For full source code and more DHTML scripts, visit www.dynamicdrive.com
//This credit MUST stay intact for use

var checkobj

function agreesubmit(el){
checkobj=el
if (document.all||document.getElementById){
for (i=0;i<checkobj.form.length;i++){  //hunt down submit button
var tempobj=checkobj.form.elements
if(tempobj.type.toLowerCase()=="submit")
tempobj.disabled=!checkobj.checked
}
}
}

function defaultagree(el){
if (!document.all&&!document.getElementById){
if (window.checkobj&&checkobj.checked)
return true
else{
alert("Por favor lee los termnos bla bla bla....")
return false
}
}
}

</script>
<!-- fin codigo para aceptar condiciones -->
<script>
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo m�nimo 3 caract�res') ; return false ; }
if(formulario.contrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido') ; return false ; }
if(formulario.pais.value.length == 0) { alert('Debes poner un pa�s') ; return false ; }
if(formulario.avatar.value.length == 0) { alert('Debes poner un avatar') ; return false ; }
if(formulario.descripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<SCRIPT type="text/javascript">
<!--
function showimage() {
if (!document.images)
return
document.images.avatar.src=
'avatares/' + document.formulario.avatar.options[document.formulario.avatar.selectedIndex].value
}
//-->
</SCRIPT>

<form name="formulario" method="post" action="uregistrar.php" onsubmit="return revisar()" "return defaultagree(this)">
  <table width="40%" border="1" cellpadding="4" cellspacing="0" bordercolor="#000000" >
  <tr>
    <td width="13%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* Nick:</font></b></td>
    <td width="87%"><input type="text" name="nick" maxlength="20" class="form" ></td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* Contrase�a:</font></b></td>
    <td><input type="password" name="contrasena" maxlength="20" class="form"></td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* Email:</font></b></td>
    <td><input type="text" name="email" maxlength="40" class="form" ></td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">*Pais:</font></b></td>
    <td><input type=text name=pais maxlength=20 class=form></td>
  </tr>
  <tr>
    <td><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><b>Edad:</b></font></td>
    <td><input type=text name=edad maxlength=2 size=10 class=form></td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Sexo:</font></b></td>
    <td><select name=sexo class=form>
      <option value=0>Masculino 
          <option value=1$sexo>Femenino 
      </select></td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* Avatar:</font></b></td>
    <td><select name="avatar" onChange="showimage()" class="form" >
          <option value="eforo_images/avatares/0.gif" selected>Sin avatar</option>
        </select></td>
  </tr>
  <tr>
    <td><b>Muestra</b></td>
      <td><img src="eforo_imagenes/avatares/0.gif" alt="" name="avatar" width="150" height="150"><br>
        tu avatar lo cambias en el Panel del Usuario</td>
  </tr>
  <tr>
    <td><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Descripci�n</font></b> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">:</font></td>
    <td><textarea name=descripcion cols=30 rows=5 class=form style="font-family: verdana"></textarea></td>
  </tr>
  <tr>
    <td>TERMINOS Y CONDICIONES </td>
    <td><textarea name="textarea" cols="30" rows="5" wrap="VIRTUAL">Aqui van los terminos de condiciones que deberas modificarlos en uregistrar.php</textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="registrar" value="Registrar" class="form">
      <input name="activar" type="checkbox" id="activar" value="checkbox" onClick="agreesubmit(this)">
      Acepto terminos y condiciones </td>
  </tr>
</table>
</form>
<?
}
mysql_close($conectar) ;
?>