<title>Directorio imagenes</title>
<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla {
background: #dddddd ;
}
.tablacolor {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
}
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
<div class="t1">Directorio imagenes</div>
<br>
<table width='100%' border='1' cellpadding='5' cellspacing='0' align='center' style='border: #757575 1 solid'>
  <tr> 
    <td width="57%" height="7" class="tabla_subtitulo"><b>Imagen</b></td>
    <td class="tabla_subtitulo"><b>Datos de la imagen</b></td>
  </tr>
  <?php
								 // Le damos valor a las variables de configuraci�n
 $Config['Path'] = "."; 		// Directorio donde stan los archivos a mostrar.
 $Config['Show'] = 5; 			// Numero de archivos a mostrar por p�ginas.

 $Show['5 Anteriores'] = 0;		// Por defecto no se mostrara 5 Anteriores
 $Show['5 Siguientes'] = 0;		// Por defecto no se mostrara 5 Siguientes
 
 if ($c == "") $c = 0;			// Si $c no tiene valor es porque es la primera vez que se visita la p�gina.
 $dir = opendir($Config['Path']); 		// Abrimos el directorio donde estan los archivos
 $Plus = $c;					// Le damos el valor de $c a $plus porque el valor de $c se perdera y lo necessitaremos mas tarde.

 while ($c > 0 && $elemento = readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
 {
  $Show['5 Anteriores'] = 1;
  $c--;
 }

 $Counter = 0;			// Ponemos a 0 el contador

 // Si es la primera vez que vez a�adimos 2 filas, si no lo es se las quitamos.
 if ($Show['5 Anteriores'] == 0) $Counter=$Counter-2; else {
  $c = 2;
  while ($c > 0 && $elemento = readdir($dir))		// Mientras la variable $c sea mayor de 0 saltamos archivos.
  {
   $Show['5 Anteriores'] = 1;
   $c--;
  }
 }
 
 // Mostramos el numero de archivos que se tienen que mostrar por p�gina.
 while (($Counter != $Config['Show']) && ($elemento = readdir($dir)))
 {
  $Counter++;

  $elemento1 = strtolower($elemento); 
  if ((strpos($elemento1, ".gif") > 1) || (strpos($elemento1, ".jpg") > 1)) {

   // pasamos el tama�o del archivo a kb
   $tamano = filesize($elemento)/1024;
   $tamano = ceil($tamano) ; 
?>
  <tr> 
    <td height='7' class="tabla_mensaje"><a href="<?php echo $elemento ?>" target="_blank"><img src="<?php echo $elemento ?>" width="80" height="80" border="0"></a> 
    </td>
    <td height='7' class='tabla_mensaje'>Nombre : <?php echo $elemento ?><br>
      Tama�o :&nbsp;<?php echo $tamano ; ?> Kb </td>
  </tr>
  <?php
  }
 }
  
 // Si sobran archivos pondremos el "10 Siguientes"
 if ($elemento = readdir($dir))
 {
  $Show['5 Siguientes'] = 1;
 }

 //Cerramos el directorio 
 closedir($dir); 
?>
</table>
<div align="right"> 
  <?php
 // Mostraos si es necessario el "10 Anteriores" y "10 Siguientes".
 if ($Show['5 Anteriores'] == 1) echo("<a href=\"index.php?c=".($Plus-$Config['Show'])."\">5 Anteriores | </a>");
 if ($Show['5 Siguientes'] == 1) echo("&nbsp;<a href=\"index.php?c=".($Plus+$Config['Show'])."\">5 Siguientes</a></p>");
?>
</div> 
