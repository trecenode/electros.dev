<?
/////////////////////////////
//|-----------------------|//
//| Electrosnuke v1.3     |//
//| by www.phpmysql.tk    |//
//| by www.electros.tk    |//
//|-----------------------|//
/////////////////////////////

/*--------------- DATOS DE CONEXION ------------*/

$dbhost  = "localhost" ; 
$dbuser  = "" ; 
$dbpass  = "" ;
$db  = "electrosnukev13" ;
$conectar = mysql_connect($dbhost,$dbuser,$dbpass) ; mysql_select_db($db,$conectar) ;

/*------------------------ ENLACES ------------*/

// Activar(ON) o desactivar(OFF) en la pagina principal index.php
$menu_enlaces  = "ON" ;
// Configuracion: puedes utilizar caracteres en la definicion como <br>,<b></b> y <p></p> 
$enlace0  = "Categoria 0" ;
$enlace0definicion  = "Esta es la categoria numero 0" ;
$enlace1  = "Categoria 1" ;
$enlace1definicion  = "Esta es la categoria numero 1" ;
$enlace2  = "Categoria 2" ;
$enlace2definicion  = "Esta es la categoria numero 2" ;
$enlace3  = "Categoria 3" ;
$enlace3definicion  = "Esta es la categoria numero 3" ;
$enlace4  = "Categoria 4" ;
$enlace4definicion  = "Esta es la categoria numero 4" ;
$enlace5  = "Categoria 5" ;
$enlace5definicion  = "Esta es la categoria numero 5" ;
$enlace6  = "Categoria 6" ;
$enlace6definicion  = "Esta es la categoria numero 6" ;
$enlace7  = "Categoria 7" ;
$enlace7definicion  = "Esta es la categoria numero 7" ;
$enlace8  = "Categoria 8" ;
$enlace8definicion  = "Esta es la categoria numero 8" ;
$enlace9  = "Categoria 9" ;
$enlace9definicion  = "Esta es la categoria numero 9" ;
// Tama�o de la imagen del enlace (opcional, al editar un enlace).
$tama�oanchoimagen  = "80" ;
$tama�oaltoimagen  = "80" ;
// Error de una imagen en los enlaces (opcional,util para saber si un enlace o una url esta rota si esta vinculada).
$errorimagen  = "eforo_imagenes/foco.gif" ;
// Opciones para banner afilados y minibanner afiliados
$bannerdetupagina  = "http://recursosphp.iefactory.com/imagenes/banner.gif" ; // 800x600 //
$minibannerdetupagina   = "http://recursosphp.iefactory.com/imagenes/phpmysql.gif" ; // 88x31 //

/*------------------------ DESCARGAS ------------*/

// Activar(ON) o desactivar(OFF) en la pagina principal index.php
$menu_descargas  = "ON" ;
// Configuracion: puedes utilizar caracteres en la definicion como <br>,<b></b> y <p></p> 
$descarga0  = "Categoria 0" ;
$descarga0definicion  = "Esta es la categoria numero 0" ;
$descarga1  = "Categoria 1" ;
$descarga1definicion  = "Esta es la categoria numero 1" ;
$descarga2  = "Categoria 2" ;
$descarga2definicion  = "Esta es la categoria numero 2" ;
$descarga3  = "Categoria 3" ;
$descarga3definicion  = "Esta es la categoria numero 3" ;
$descarga4  = "Categoria 4" ;
$descarga4definicion  = "Esta es la categoria numero 4" ;
$descarga5  = "Categoria 5" ;
$descarga5definicion  = "Esta es la categoria numero 5" ;
$descarga6  = "Categoria 6" ;
$descarga6definicion  = "Esta es la categoria numero 6" ;
$descarga7  = "Categoria 7" ;
$descarga7definicion  = "Esta es la categoria numero 7" ;
$descarga8  = "Categoria 8" ;
$descarga8definicion  = "Esta es la categoria numero 8" ;
$descarga9  = "Categoria 9" ;
$descarga9definicion  = "Esta es la categoria numero 9" ;
// Otras opciones
$tama�oporarchivoenviado  = "250000" ; // 250 kb aproximadamente //
$carpetadondeseguardanlosarchivos  = "descargas" ;
$extensiondelarchivosoportada  = "zip" ; // que tipo de archivo pudes subir solamente //

/*------------------------ADMINISTRACION ------------*/

// Configura tu nick de administracion aqui.
$administrador  = "Administrador" ;
// Poner otro administrador solo para administrar.php, si no quieres tener mas administradores deja puesto el nick de Administrador
$administrador2  = "Administrador" ;

//*************** GENERAL ******************//

// Paginas: titulo de la pagina, estilo de la pagina, url de tu pagina, cabezera o <head> de tu pagina y pie de tu pagina
$versionelectrosnuke  = "Electrosnuke v13" ;
$titulodelapagina  = "Titulo de tu pagina | electrosnuke v13" ;
$estilopagina  = "electros.php" ; // estilos disponibles : azulverdoso.php,cafe.php,electros.php,oscuro.php,red.php //
$titulodelportal  = "eLectrosnuke v.1.3" ; // pon el titulo de tu pagina //
$urldetupagina  = "http://recursosphp.iefactory.com" ; // la url directa de tu pagina, sin redirecciones //
$cabezera_pagina = "<script><!-- if(parent.frames.length > 0) top.location = 'http://recursosphp.iefactory.com' ;//--> </script>" ;// este script es para que funcionen las cookies, no lo quites si no sabes lo que haces //
$pie_pagina = "<br><center><b>Electrosnuke v13</b> by <a href='http://wwww.phpmysql.tk' target='_blank' >phpmysql.tk</a> y <a href='http://wwww.electros.tk' target='_blank' >www.electros.tk</a></center><br>" ; // este mensaje puedes cambiarlo, pero estaria bien que dejaras parte de el a modo de agradecimiento //
// Activar(ON) O desactivar(OFF) codigos php : La fecha de hoy, usuarios en linea(anonimos y registrados) y ultimo registrado en usuarios
$fechadehoy  = "ON" ;
$usuariosenlinea  = "ON" ;
$ultimoregistrado  = "ON" ;
// Activar(ON) O desactivar(OFF) menus : lo mas importante de la pagina
$menu_top  = "ON" ; // la tabla que aparece debajo del banner //
$menu_usuarios  = "ON" ;
$menu_afiliados_minibanner  = "ON" ;
$menu_afiliados_banner  = "ON" ;
// FIN DE LA CONFIGUARCION DE ELECTROSNUKE
?>