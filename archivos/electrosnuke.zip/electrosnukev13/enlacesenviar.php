<?
include("ulogin.php") ;
?>
<?
include ("config.php") ;
if($enviar) {
$fecha = time()  ;
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
$texto = str_replace("\r\n","<br>",$texto) ; 
return $texto ;
}
$usuario = $HTTP_COOKIE_VARS[unick] ;
$titulo = quitar($titulo) ;
$descripcion = quitar($descripcion) ;
$categoria = quitar($categoria) ;
$urlsitio = quitar($urlsitio) ;
$urlminibanner = quitar($urlminibanner) ;
if($urlsitio == "http://") { $urlsitio = "" ; }
if($urlminibanner == "http://") { $urlminibanner = "" ; }
if($urlminibanner2 == "http://") { $urlminibanner2 = "" ; }
mysql_query("insert into enlaces (fecha,usuario,titulo,descripcion,categoria,urlsitio,urlminibanner,urlminibanner2,puntos,votos,calificacion)
values ('$fecha','$usuario','$titulo','$descripcion','$categoria','$urlsitio','$urlminibanner','$urlminibanner2','5','1','5')") ;
echo "El enlace ha sido agregado con �xito. Haz click <a href=index.php?id=enlaces>aqu�</a> para regresar a enlaces.<br><br>" ;
}
?>
<?
if ($opcion=="minibanner") {
?><div class='titulo'>Enviar Enlace - Afiliate con minibanner</div>
<br>
<form method='post' action='index.php?id=enlacesenviar' name='formulario'  onsubmit='return revisar()'  >
<script>
function caracteres() {
if( formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout('caracteres()',200) ;
}
onload=caracteres ;
function revisar() {
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
}
</script>
<script> 
function revisar() { 
if(formulario.titulo.value.length == 0) { alert('Debes escribir un titulo.') ; return false ; }
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
} 
</script>
<b>T�tulo:</b><br>
<input type='text' name='titulo' size='30' maxlength='25' class='form'>
  <br>
<b>Descripci�n:</b><br>
<textarea name='descripcion' cols='30' rows='5' class='form' onkeypress='caracteres' ></textarea>
  <br>
  <input type='text' name='caracteres' size='3' value='0' class='form' >
  M�ximo 255 caract�res<br>
<b>Categor�a:</b><br>
<select name='categoria' class='form'>
    <option value='0' selected><? echo $enlace0 ?>
	<option value='1'><? echo $enlace1 ?>
    <option value='2'><? echo $enlace2 ?>
	<option value='3'><? echo $enlace3 ?>
	<option value='4'><? echo $enlace4 ?>
    <option value='5'><? echo $enlace5 ?>
    <option value='6'><? echo $enlace6 ?>
    <option value='7'><? echo $enlace7 ?>
	<option value='8'><? echo $enlace8 ?>
	<option value='9'><? echo $enlace9 ?>
  </select><br>
<b>URL del sitio:</b><br>
<input type='text' name='urlsitio' size='30' maxlenght='100' value='http://' class='form'><br>
  <b><font color='#FF0000'>URL del minibanner (88 x 31):</font></b><font color='#FF0000'> 
  *</font><br>
  Este campo es obligatorio.<br>
<input type='text' name='urlminibanner' size='30' maxlenght='100' value='http://' class='form'>
  <br>
Recuerda que debes poner este minibanner en tu pagina, hacia la <br>
  url <? echo $urldetupagina ?><br>
  <br>
<img src="<? echo $minibannerdetupagina  ?>">
<br>  <br>
  <br>
  <input type='hidden' name='urlminibanner2' size='30' maxlenght='100' value='http://' class='form'>
<input type='submit' name='enviar' value='Enviar' class='form'>
</form>
<?
} else if ($opcion=="banner") {
?><div class='titulo'>Enviar Enlace - Afiliate con banner</div>
<br>
<form method='post' action='index.php?id=enlacesenviar' name='formulario'  onsubmit='return revisar()'  >
<script>
function caracteres() {
if( formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout('caracteres()',200) ;
}
onload=caracteres ;
function revisar() {
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
}
</script>
<script> 
function revisar() { 
if(formulario.titulo.value.length == 0) { alert('Debes escribir un titulo.') ; return false ; }
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
} 
</script>
<b>T�tulo:</b><br>
<input type='text' name='titulo' size='30' maxlength='25' class='form'>
  <br>
<b>Descripci�n:</b><br>
<textarea name='descripcion' cols='30' rows='5' class='form' onkeypress='caracteres' ></textarea>
  <br>
  <input type='text' name='caracteres' size='3' value='0' class='form' >
  M�ximo 255 caract�res<br>
<b>Categor�a:</b><br>
<select name='categoria' class='form'>
    <option value='0' selected><? echo $enlace0 ?>
	<option value='1'><? echo $enlace1 ?>
    <option value='2'><? echo $enlace2 ?>
	<option value='3'><? echo $enlace3 ?>
	<option value='4'><? echo $enlace4 ?>
    <option value='5'><? echo $enlace5 ?>
    <option value='6'><? echo $enlace6 ?>
    <option value='7'><? echo $enlace7 ?>
	<option value='8'><? echo $enlace8 ?>
	<option value='9'><? echo $enlace9 ?>
  </select><br>
<b>URL del sitio:</b><br>
<input type='text' name='urlsitio' size='30' maxlenght='100' value='http://' class='form'>
  <br>
<input type='hidden' name='urlminibanner' size='30' maxlenght='100' value='http://' class='form'>
  <b><font color='#FF0000'>URL del banner (468 x 60 ):</font></b><font color='#FF0000'> 
  *</font><br>
  Este campo es obligatorio.<br>
  <input type='text' name='urlminibanner2' size='30' maxlenght='100' value='http://' class='form'>
  <br>
  Recuerda que debes poner este banner en tu pagina, hacia la <br>
  url <? echo $urldetupagina ?><br>
  <br>
  <img src='<? echo $bannerdetupagina ?>' ><br>
  <br>
<input type='submit' name='enviar' value='Enviar' class='form'>
</form>
<?
} else {
?><div class='titulo'>Enviar Enlace</div>
<br>
<form method='post' action='index.php?id=enlacesenviar' name='formulario'  onsubmit='return revisar()'  >
<script>
function caracteres() {
if( formulario.caracteres.value != formulario.descripcion.value.length) {
formulario.caracteres.value = formulario.descripcion.value.length ;
}
setTimeout('caracteres()',200) ;
}
onload=caracteres ;
function revisar() {
if(formulario.descripcion.value.length > 255) { alert('La descripcion supera los 255 caract�res.') ; return false ; }
}
</script>
<script> 
function revisar() { 
if(formulario.titulo.value.length == 0) { alert('Debes escribir un titulo.') ; return false ; }
if(formulario.descripcion.value.length == 0) { alert('Debes escribir una descripcion .') ; return false ; } 
if(formulario.urlsitio.value.length == 0) { alert('Debes escribir el enlace .') ; return false ; }
} 
</script>
<b>T�tulo:</b><br>
<input type='text' name='titulo' size='30' maxlength='25' class='form'>
  <br>
<b>Descripci�n:</b><br>
<textarea name='descripcion' cols='30' rows='5' class='form' onkeypress='caracteres' ></textarea>
  <br>
  <input type='text' name='caracteres' size='3' value='0' class='form' >
  M�ximo 255 caract�res<br>
<b>Categor�a:</b><br>
<select name='categoria' class='form'>
    <option value='0' selected><? echo $enlace0 ?>
	<option value='1'><? echo $enlace1 ?>
    <option value='2'><? echo $enlace2 ?>
	<option value='3'><? echo $enlace3 ?>
	<option value='4'><? echo $enlace4 ?>
    <option value='5'><? echo $enlace5 ?>
    <option value='6'><? echo $enlace6 ?>
    <option value='7'><? echo $enlace7 ?>
	<option value='8'><? echo $enlace8 ?>
	<option value='9'><? echo $enlace9 ?>
  </select><br>
<b>URL del sitio:</b><br>
<input type='text' name='urlsitio' size='30' maxlenght='100' value='http://' class='form'>
  <br>
  <br>
<input type='hidden' name='urlminibanner' size='30' maxlenght='100' value='http://' class='form'>
  <input type='hidden' name='urlminibanner2' size='30' maxlenght='100' value='http://' class='form'>
<input type='submit' name='enviar' value='Enviar' class='form'>
</form>
<?
}
?>

