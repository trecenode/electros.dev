<?
include("ulogin.php") ;
?>
<?
include("config.php") ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
if($editar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$contrasena = quitar($contrasena) ;
$email = quitar($email) ;
$pais = quitar($pais) ;
$edad = quitar($edad) ;
$reco = quitar($reco) ;
$descripcion = quitar($descripcion) ;
mysql_query("update usuarios set contrasena='$contrasena',reco='$reco',email='$email',pais='$pais',edad='$edad',sexo='$sexo',descripcion='$descripcion' where nick='$usuario'") ;
setcookie("unick",$nick,time()+7776000) ;
header("location: uperfil.php?editarconfirmacion=si") ;
}
mysql_close($conectar) ;
?>