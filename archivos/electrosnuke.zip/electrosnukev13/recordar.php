<?
include("config.php");
$resp = mysql_query("select contrasena,reco from usuarios where nick='$nick'") ;
$datos = mysql_fetch_array($resp) ;
if($reco==$datos[reco]) {
echo "Su contrase�a es: $datos[contrasena]";
} else {
echo "Lo sentimos, pero esa no es la frase secreta!";
}
mysql_free_result($resp) ;
mysql_close($conectar) ;
?>