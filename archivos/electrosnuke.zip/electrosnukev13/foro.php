<?
include("config.php") ;
?>
<table width="100%" height="60" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="26%" height="19" ><div align="center" class="t1"><font color="#CCCCCC" size="5"><? echo $titulodelportal ?></font></div></td>
    <td width="74%"> <div align="center"> 
        <? 
// Bloque afiliados banner
include("config.php");
if($menu_afiliados_banner == "ON") {
?>
        <? 
// sistema de rotacion de banners
include("config.php") ;
$resp = mysql_query("select * from enlaces where urlminibanner2!='' order by rand() limit 1") ;
while($datos = @mysql_fetch_array($resp)) {
?>
        <? 
if ($datos[urlminibanner2]  != '' ) { 
echo "<a href='enlaces.php?e=$datos[id]' target='_black' ><img src='$datos[urlminibanner2]' border=0  width='468' height='60' alt='Hits: $datos[visitas]  Votos: $datos[votos] '  ></a>";
} 
else {echo "";
} 
?>
        <?
}
// fin sistema rotacion de banners
?>
        <?
}
else {
echo "" ;
}
?>
      </div></td>
  </tr>
</table>
<?
mysql_close($conectar) ;
?>
<?
// ****************************
// *** eForo v.2.1          ***
// *** Creado por: Electros ***
// *** Web: www.electros.tk ***
// ****************************

include("foroconfig.php") ;
?>
<html>
<head>
<title>eForo v.2.1</title>
<?
include("eforo_estilo/$estilo") ;
?>
</head>
<body>
<?
include("config.php") ;
include("foroenlinea.php") ;

// *******************************
// *** Inicio de configuraci�n ***
// *******************************

// Funci�n que muestra la fecha en el formato 1 Ene 2003 12:00 AM
function fecha1($fecha) {
$tiempo_ultimo = time() - $fecha ;
// Si la fecha es menor a 1 d�a se puede expresar de forma m�s exacta
switch (TRUE) {
// Muestra los minutos transcurridos hasta un m�ximo de 59.
case $tiempo_ultimo > 0 && $tiempo_ultimo < 3600 :
$minutos = round($tiempo_ultimo / 60) ;
if($minutos == 0 || $minutos == 1) { $fecha = "Hoy,<br>hace 1 minuto" ; } else { $fecha = "Hoy,<br>hace $minutos minutos" ; }
break ;
// Muestra las horas transcurridas desde 1 hasta 23.
case $tiempo_ultimo >= 3600 && $tiempo_ultimo < 86400 :
$horas = round($tiempo_ultimo / 3600) ;
if($horas == 1) { $fecha = "Hoy,<br>hace 1 hora" ; } else { $fecha = "Hoy,<br> hace $horas horas" ; }
break ;
// Muestra la fecha normal si ha transcurrido m�s de 1 d�a.
default :
$mesesano = array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic") ;
$diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$diames $mesesano[$mesano] $ano<br>$hora" ;
}
return $fecha ;
}
// Funci�n que muestra la fecha en el formato Lunes 1 de Enero del 2003 12:00 AM
function fecha2($fecha) {
$semana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mes = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ; $hora = date("h:i A",$fecha) ;
$fecha = "$semana[$diasemana] $diames de $mes[$mesano] del $ano $hora" ;
return $fecha ;
}
// Funci�n para sustituir el c�digo especial por su respectivo c�digo HTML
if($codigo == "ON") {
function codigo($texto) {
// --> Inicio c�digo
// >> Inicio colorear c�digo
if(strstr($texto,"[codigo]")) {
$partes = explode("[codigo]",$texto) ;
$total = count($partes) ;
for($a = 0 ; $a < $total ; $a++) {
$posicion = strpos($partes[$a],"[/codigo]") ;
if(strstr($partes[$a],"[/codigo]")) {
$codigo = substr($partes[$a],0,$posicion) ;
$codigo = html_entity_decode($codigo) ;
$coloreado = highlight_string($codigo,true) ;
$coloreado = str_replace("\r<br />","<br>",$coloreado) ;
$coloreado = "<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"tabla_principal\"><tr><td class=\"tabla_subtitulo\">$coloreado</td></tr></table>" ;
$normal = substr($partes[$a],$posicion+9) ;
$partes[$a] = "$coloreado$normal" ;
}
}
$texto = implode("",$partes) ;
}
// >> Fin colorear c�digo
$texto = str_replace("[b]","<b>",$texto) ;
$texto = str_replace("[/b]","</b>",$texto) ;
$texto = str_replace("[img]","<img src=\"",$texto) ;
$texto = str_replace("[/img]","\" border=\"0\">",$texto) ;
$texto = str_replace("\r\n","<br>",$texto) ;
// --> Fin c�digo
return $texto ;
}
}
// Funci�n para poner caretos en los mensajes
if($caretos == "ON") {
function caretos($texto) {
$texto = str_replace("[[","",$texto) ;
$texto = str_replace("]]","",$texto) ;
// --> Inicio caretos
$texto = str_replace(":D","[[alegre.gif]]",$texto) ;
$texto = str_replace(":8","[[asustado.gif]]",$texto) ;
$texto = str_replace(":P","[[burla.gif]]",$texto) ;
$texto = str_replace(":S","[[confundido.gif]]",$texto) ;
$texto = str_replace(":(1","[[demonio.gif]]",$texto) ;
$texto = str_replace(":(2","[[demonio2.gif]]",$texto) ;
$texto = str_replace(":?","[[duda.gif]]",$texto) ;
$texto = str_replace(":-(","[[enojado.gif]]",$texto) ;
$texto = str_replace(";)","[[guino.gif]]",$texto) ;
$texto = str_replace(":'(","[[llorar.gif]]",$texto) ;
$texto = str_replace(":lol","[[lol.gif]]",$texto) ;
$texto = str_replace(":M","[[moda.gif]]",$texto) ;
$texto = str_replace(":|","[[neutral.gif]]",$texto) ;
$texto = str_replace(":)","[[risa.gif]]",$texto) ;
$texto = str_replace(":-)","[[sonrisa.gif]]",$texto) ;
$texto = str_replace(":R","[[sonrojado.gif]]",$texto) ;
$texto = str_replace(":O","[[sorprendido.gif]]",$texto) ;
$texto = str_replace(":(","[[triste.gif]]",$texto) ;
// --> Fin caretos
$texto = str_replace("[[","<img src=\"eforo_imagenes/caretos/",$texto) ;
$texto = str_replace("]]","\" width=\"15\" height=\"15\">",$texto) ;
return $texto ;
}
}
// Funci�n para transformar URLs en enlaces
if($url == "ON") {
function url($texto) {
$texto = preg_replace("/(?<!<a href=\")((http|ftp)+(s)?:\/\/[^<>\s]+)/i","<a href=\"\\0\" target=\"_blank\">\\0</a>",$texto) ;
return $texto ;
}
}
// Funci�n para palabras censuradas
if($censurar == "ON") {
function censurar($texto) {
// --> Inicio palabras
$texto = str_replace("insulto","***",$texto) ;
// --> Fin palabras
return $texto ;
}
}

// ****************************
// *** Fin de configuraci�n ***
// ****************************

if($temaid) {
$resp = mysql_query("select tema from eforo_mensajes where forotema='$temaid' order by id asc") ;
$datos = mysql_fetch_array($resp) ;
?>
<p class="tema"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>">� <? echo $datos[tema] ?></a>
<p>
<?
mysql_free_result($resp) ;
}
if($foroid) {
$resp = mysql_query("select foro from eforo_foros where id='$foroid'") ;
$datos = mysql_fetch_array($resp) ;
$foro = " � <a href=\"foro.php?foroid=$foroid\">$datos[foro]</a>" ;
mysql_free_result($resp) ;
}
?>
<p><a href="index.php">Volver a la web</a> � <a href="foro.php">Indice del foro</a><? echo $foro ?>
<p>
<?
// Se muestra el enlace para responder solamente cuando se est� dentro de un tema
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<?
if($foroid) {
if($temaid) {
$mensaje = " <b>|</b> <a href=\"fororesponder.php?foroid=$foroid&temaid=$temaid\">Responder</a>" ;
}
?>
<td>
<a href="foronuevo.php?foroid=<? echo $foroid ?>">Nuevo tema</a><? echo $mensaje ?>
</td>
<?
}
$resp = mysql_query("select id from eforo_privados where nuevo='0' and destinatario='$HTTP_COOKIE_VARS[unick]'") ;
$total = mysql_num_rows($resp) ;
if($total == 0) {
$mensajes = "<a href=\"foroprivados.php\">Mensajes</a>" ;
}
else {
?>
<script>
function aviso() {
texto = document.getElementsByTagName('blink') ;
for(a=0; a<texto.length; a++) {
if(texto[a].style.visibility=='hidden') {
texto[a].style.visibility='visible' ;
}
else {
texto[a].style.visibility='hidden' ;
}
}
setTimeout('aviso()',100) ;
}
onload=aviso ;
</script>
<?
$mensajes = "<a href=\"foroprivados.php\"><blink>Mensajes ($total)</blink></a>" ;
}
mysql_free_result($resp) ;
if(!$HTTP_COOKIE_VARS[unick]) {
$usuario = "<a href=\"fororegistrar.php\">Registrar</a> <b>|</b> <a href=\"foroentrar.php\">Conectar</a>" ;
}
else {
$usuario = "$mensajes <b>|</b> <a href=\"foroperfil.php\">Perfil</a> <b>|</b> <a href=\"forosalir.php\">Salir</a>" ;
}
?>
<td>
<div align="right">
<? echo $usuario ?>
</div>
</td>
</tr>
</table><br>
<?
if(!$HTTP_COOKIE_VARS[unick]) {
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<div align="right">
<form method="post" action="foroentrar.php">
<input type="hidden" name="regresar" value="<? echo "$PHP_SELF?$QUERY_STRING" ?>">
<b>Nick:</b>
<input type="text" name="nick" size="10" maxlength="20" class="form">
<b>Contrase�a:</b>
<input type="password" name="contrasena" size="10" maxlength="20" class="form">
<input type="submit" name="entrar" value="Entrar" class="form">
</td>
<td>
</form>
</div>
</td>
</tr>
</table><br>
<?
}
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="tabla_principal">
<tr>
<td width="50%" class="tabla_mensaje" valign="top">
<?
$resp = mysql_query("select id from $tabla_usuarios") ;
$totaldeusuarios = mysql_num_rows($resp) ;
$resp = mysql_query("select nick from $tabla_usuarios order by id desc limit 1") ;
$datos = mysql_fetch_array($resp) ;
$ultimo = $datos[nick] ;
?>
Nos visitan <b><? echo $usuarios ?></b> usuarios: <b><? echo $anonimos ?></b> anonimos y <b><? echo $registrados ?></b> registrados<br><br>
<? echo $renlinea ?>
</td>
<td width="50%" class="tabla_mensaje" valign="top">
Total de usuarios registrados en el foro: <b><? echo $totaldeusuarios ?></b><br>
Ultimo usuario registrado: <a href="forousuarios.php?u=<? echo $ultimo ?>"><? echo $ultimo ?></a><br>
<a href="forousuarios.php">Ver usuarios</a>
</td>
</tr>
</table><br>
<?
// Muestra los mensajes del foro seleccionado
if($foroid) {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<?
// Muestra el tema y los mensajes
if($temaid) {
mysql_query("update eforo_mensajes set visitas=visitas+1 where id='$temaid'") ;
$resp = mysql_query("select id from eforo_mensajes where forotema='$temaid'") ;
$totaldemensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_mensajes ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where forotema='$temaid' order by id asc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
?>
<script>
function borrar(foroid,temaid,mensajeid,borrar) {
if(borrar == 'tema') { mensaje = 'tema completo junto con todos los mensajes' ; } else { mensaje = 'mensaje' ; }
if(confirm('Deseas borrar el '+mensaje)) { location = 'foroborrar.php?foroid='+foroid+'&temaid='+temaid+'&mensajeid='+mensajeid+'&borrar='+borrar ; }
}
</script>
<?
while($datos = mysql_fetch_array($resp)) {
$fecha = fecha2($datos[fecha]) ;
// Agregar c�digo especial
if($codigo == "ON" && $datos[codigo] == 1) { $datos[mensaje] = codigo($datos[mensaje]) ; }
// Agregar caretos en los mensajes
if($caretos == "ON" && $datos[caretos] == 1) { $datos[mensaje] = caretos($datos[mensaje]) ; }
// Transformar URLs a enlaces
if($url == "ON" && $datos[url] == 1) { $datos[mensaje] = url($datos[mensaje]) ; }
// Censurar palabras
if($censurar == "ON") { $datos[mensaje] = censurar($datos[mensaje]) ; }
$datos[mensaje] = str_replace("\r\n","<br>",$datos[mensaje]) ;
// El total de mensajes del usuario
$resp2 = mysql_query("select mensajes from $tabla_usuarios where nick='$datos[usuario]'") ;
$datos2 = mysql_fetch_array($resp2) ;
$mensajes = $datos2[mensajes] ;
mysql_free_result($resp2) ;
// Si el mensaje ha sido editado se muestra la fecha de la �ltima modificaci�n 
if($datos[fecha] == $datos[editado]) {
$editado = "" ;
}
else {
$editado = fecha2($datos[editado]) ;
$editado = "<br><br><div style=\"font-size: 7pt\"><b>Editado por �ltima vez el $editado</b></div>" ;
}
if($datos[id] == $datos[forotema]) {
$borrar = "tema" ;
}
else {
$borrar = "mensaje" ;
}
$resp3 = mysql_query("select id,firma,avatar from $tabla_usuarios where nick='$datos[usuario]'") ;
$datos3 = mysql_fetch_array($resp3) ;
if($datos[firma] == 0 || $datos3[firma] == "") {
$firma = "" ;
}
else {
if($codigo == "ON") {
$firma = codigo($datos3[firma]) ;
}
$firma = "<hr width=\"100\" color=\"#757575\">$firma" ;
}
if($datos3[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<img src=\"eforo_imagenes/avatares/$datos3[id].$datos3[avatar]\">" ;
}
mysql_free_result($resp3) ;
?>
<tr>
<td width="25%" valign="top" class="tabla_mensaje">
<b><a href="forousuarios.php?u=<? echo $datos[usuario] ?>"><? echo $datos[usuario] ?></a></b><br>
<div style="font-size: 7pt"><b>Mensajes:</b> <? echo $mensajes ?></div><br>
<? echo $avatar ?>
</td>
<td width="75%" valign="top" class="tabla_mensaje">
<a name="<? echo $datos[id] ?>"></a>
<b>Tema:</b> <? echo $datos[tema] ?><br>
<hr color="#757575"><br>
<? echo "$datos[mensaje]$firma$editado" ?>
</td>
</tr>
<tr>
<td class="tabla_mensaje"><div style="font-size: 7pt"><? echo $fecha ?></div></td>
<td class="tabla_mensaje">
<a href="foroeditar.php?foroid=<? echo $foroid ?>&temaid=<? echo $temaid ?>&mensajeid=<? echo $datos[id] ?>">Editar</a> | <a href="javascript:borrar('<? echo $foroid ?>','<? echo $temaid ?>','<? echo $datos[id] ?>','<? echo $borrar ?>')">Borrar</a></td>
</tr>
<?
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldemensajes) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
else {
// Muestra los temas
$resp = mysql_query("select id from eforo_mensajes where foro='$foroid' and foromostrar='1'") ;
$totaldetemas = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
$mostrar = $num_temas ;
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from eforo_mensajes where foro='$foroid' and foromostrar='1' order by ultimo desc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
$mensajes = mysql_num_rows($resp) ;
if($mensajes == 0) {
echo "<p align=center>No se encontraron mensajes." ;
}
else {
?>
<p>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td width="40%" class="tabla_titulo"><div align="center" class="t1">Tema</div></td>
<td width="10%" class="tabla_titulo"><div align="center" class="t1">Vis</div></td>
<td width="10%" class="tabla_titulo"><div align="center" class="t1">Res</div></td>
<td width="20%" class="tabla_titulo"><div align="center" class="t1">Autor</div></td>
<td width="20%" class="tabla_titulo"><div align="center" class="t1">Ultimo</div></td>
</tr>
<?
while($datos = mysql_fetch_array($resp)) {
$resp2 = mysql_query("select id,fecha,usuario from eforo_mensajes where forotema='$datos[id]' order by id desc limit 1") ;
$datos2 = mysql_fetch_array($resp2) ;
$primero = fecha1($datos[fecha]) ;
$ultimo = fecha1($datos2[fecha]) ;
?>
<tr>
<td class="tabla_mensaje"><a href="foro.php?foroid=<? echo $foroid ?>&temaid=<? echo $datos[id] ?>">� <? echo $datos[tema] ?></a></td>
<td class="tabla_mensaje"><div align="center"><? echo $datos[visitas] ?></div></td>
<td class="tabla_mensaje"><div align="center"><? echo $datos[mensajes] ?></div></td>
<td class="tabla_mensaje"><div align="center"><b><? echo $datos[usuario] ?></b><br><span style="font-size: 7pt"><? echo $primero ?></span></div></td>
<td class="tabla_mensaje"><div align="center"><b><? echo $datos2[usuario] ?></b><br><span style="font-size: 7pt"><? echo $ultimo ?></span></div></td>
</tr>
<?
mysql_free_result($resp2) ;
}
mysql_free_result($resp) ;
?>
</table>
<?
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=foro.php?foroid=$foroid>Anteriores $mostrar mensajes</a> | " ;
}
else {
$anteriores = $desde - $anteriores ;
echo "<p align=right><a href=foro.php?foroid=$foroid&desde=$anteriores>Anteriores $mostrar mensajes</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $totaldetemas) {
echo "<a href=foro.php?foroid=$foroid&temaid=$temaid&desde=$desde>Siguientes $mostrar mensajes</a>" ;
}
}
}
}
// Mostrar los foros
else {
?>
<table width="100%" border="0" cellpadding="5" cellspacing="1" class="tabla_principal">
<tr>
<td colspan="2" class="tabla_titulo"><div class="t1" align="center">Categor�a</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Tem</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Men</div></td>
<td class="tabla_titulo"><div class="t1" align="center">Ultimo mensaje</div></td>
</tr>
<?
$resp = mysql_query("select * from eforo_categorias order by orden asc") ;
while($datos = mysql_fetch_array($resp)) {
?>
<tr>
<td colspan="5" class="tabla_subtitulo"><div class="t1"><? echo $datos[categoria] ?></div></td>
</tr>
<?
$resp2 = mysql_query("select * from eforo_foros where categoria='$datos[id]' order by orden asc") ;
while($datos2 = mysql_fetch_array($resp2)) {
// Obtener el ultimo mensaje enviado
$resp3 = mysql_query("select id,forotema,fecha,usuario from eforo_mensajes where foro='$datos2[id]' order by id desc limit 1") ;
if(mysql_num_rows($resp3) != 0) {
$datos3 = mysql_fetch_array($resp3) ;
$usuario = $datos3[usuario] ;
$fecha = fecha1($datos3[fecha]) ;
$ultimo = "<b>$usuario</b> <a href=foro.php?foroid=$datos2[id]&temaid=$datos3[forotema]#$datos3[id]><img src=eforo_imagenes/ultimo.gif width=18 height=9 border=0></a><br><span style=\"font-size: 7pt\">$fecha</span>" ;
}
else {
$ultimo ="Ninguno" ;
}
?>
<tr>
<td width="10%" class="tabla_mensaje"><div align="center"><img src="eforo_imagenes/foro.gif" width="40" height="41" border="0"></div></td>
<td width="50%" class="tabla_mensaje"><a href="foro.php?foroid=<? echo $datos2[id] ?>"><? echo $datos2[foro] ?></a><br><? echo $datos2[descripcion] ?></td>
<td width="10%" class="tabla_mensaje"><div align="center"><? echo $datos2[temas] ?></div></td>
<td width="10%" class="tabla_mensaje"><div align="center"><? echo $datos2[mensajes] ?></div></td>
<td width="20%" class="tabla_mensaje"><div align="center"><? echo $ultimo ?></div></td>
</tr>
<?
mysql_free_result($resp3) ;
}
mysql_free_result($resp2) ;
}
?>
</table>
<?
mysql_free_result($resp) ;
}
mysql_close($conectar) ;
?>
<p align="center"><a href="http://www.electros.tk" target="_blank">eForo v.2.1</a>
<p>
<p align="center"><a href="foroadmin.php">Administrar</a>
<p>
</body>
</html>
