<?
include("config.php") ;
if($e) {
$resp = mysql_query("select urlsitio from enlaces where id='$e'") ;
if(mysql_num_rows($resp) != 0) {
$datos = mysql_fetch_array($resp) ;
mysql_query("update enlaces set visitas=visitas+1 where id='$e'") ;
?>
<script>location='<? echo $datos[urlsitio] ?>'</script>
<?
}
else {
echo "No existe este enlace en la base de datos." ;
}
}
if($calificar == "si") {
echo "<p><b>Has votado por el enlace.</b>" ;
}
if($calificar == "no") {
echo "<p><b>S�lo puedes votar una vez por d�a.</b>" ;
}
?>
<p class="titulo">Enlaces</p>
<?
// clasificar los enlaces
if(isset($c)) {
$clasificacion = array("$enlace0","$enlace1","$enlace2","$enlace3","$enlace4","$enlace5","$enlace6","$enlace7","$enlace8","$enlace9") ;
?>
<p><b>Categor�a:</b> <? echo $clasificacion[$c] ?>
<?
$mostrar = 25 ;
$resp = mysql_query("select id from enlaces where categoria='$c'") ;
$enlaces = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
?>
<p><b>Total de enlaces:</b> <? echo $enlaces ?> | <a href="index.php?id=enlaces" ?>Volver</a>
<p>
<?
$mostrar = 6 ; 
if(!$desde) { $desde = 0 ; }
$resp = mysql_query("select * from enlaces where categoria='$c' order by titulo asc limit $desde,$mostrar") ;
$desde = $desde + $mostrar ;
while($datos = mysql_fetch_array($resp)) {
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
  <form method='post' action='enlacescalificar.php?d=<? echo $datos[id] ?>'>
    <tr> 
      <?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
<td width='97%' height="70" class="tabla_subtitulo"> <a href='<? /*Util para edonkey links: si la seccion es 6 se abre el link directamente*/ if($c == "6") {echo "$datos[urlsitio]" ;} else {echo "enlaces.php?e=$datos[id]" ;}?>' target='<? /*Util para edonkey links: si la seccion es 6 se abre en una misma ventana*/ if($c == "6") { echo "_self" ; } else { echo "_blank" ; } ?>'>
� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?>
<br> 
<?
/*Fin de util para edonkey links*/
if($c == "6") {
echo "" ;
}
else {
?>
<b>Visitas:</b> <? echo $datos[visitas] ?> 
<?
}
?>
<b>Votos:</b> <? echo $datos[votos] ?> <b> 
<?
if($datos[urlminibanner] == "") {
?>
<?
}
else {
?>
| <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
<?
}
?>
<b> 
<? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
| <a href="index.php?id=enlaceseditar&enlacesid=<? echo $datos[id] ?>"> 
Editar</a> | 
<?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> <select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<br>
<?
} 
mysql_free_result($resp) ;
if($desde > $mostrar) {
$anteriores = $mostrar * 2 ;
if($desde == $anteriores) {
echo "<p align=right><a href=index.php?id=enlaces&c=$c>Anteriores $mostrar enlaces</a> | " ;
}
else {
$anteriores = $desde - $mostrar * 2 ;
echo "<p align=right><a href=index.php?id=enlaces&c=$c&desde=$anteriores>Anteriores $mostrar enlaces</a> | " ;
}
}
else {
echo "<p align=right>" ;
}
if($desde < $enlaces) {
echo "<a href=index.php?id=enlaces&c=$c&desde=$desde>Siguientes $mostrar enlaces</a>" ;
}
if($desde > $enlaces) {
echo "<a href=index.php?id=enlaces&c=$c&desde=$desde>Siguientes $mostrar enlaces</a>" ;
} 
}
else {
?>
<p>Para agregar enlaces debes ser un usuario registrado. Si ya estas registrado 
  haz click <a href="index.php?id=enlacesenviar">aqu�</a>. 
<p>
<?
$resp = mysql_query("select id from enlaces where categoria=0") ;
$c0 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=1") ;
$c1 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=2") ;
$c2 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=3") ;
$c3 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=4") ;
$c4 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=5") ;
$c5 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=6") ;
$c6 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=7") ;
$c7 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=8") ;
$c8 = mysql_num_rows($resp) ;
$resp = mysql_query("select id from enlaces where categoria=9") ;
$c9 = mysql_num_rows($resp) ;
?>
<div align="center">
  <table width="80%" border="0" align="center" cellpadding="4" cellspacing="0" class="tabla">
    <tr valign="top"> 
      <td width="285"> <div align="left"><b>�  <a href="index.php?id=enlaces&c=0">
          <?  echo $enlace0 ?>
          <span class="n"> (<? echo $c0 ?></span>)</a></b><br>
          <? echo $enlace0definicion ?> <br>
        </div></td>
      <td width="261"> <div align="left"><b>�  <a href="index.php?id=enlaces&c=5"> 
          <?  echo $enlace5 ?>
          <span class="n"> (<? echo $c5 ?></span>)</a></b><br>
          <? echo $enlace5definicion ?> </div></td>
    </tr>
    <tr valign="top"> 
      <td><div align="left"><b>�  <a href="index.php?id=enlaces&c=1"> 
          <?  echo $enlace1 ?>
          <span class="n"> (<? echo $c1 ?></span>)</a></b><br>
          <? echo $enlace1definicion ?> </div></td>
      <td><div align="left"><b>�  <a href="index.php?id=enlaces&c=6"> 
          <?  echo $enlace6 /*seccion ideal para edonkey links*/ ?>
          <span class="n"> (<? echo $c6 ?></span>)</a></b><br>
          <? echo $enlace6definicion ?> </div></td>
    </tr>
    <tr valign="top"> 
      <td><div align="left"><b>�  <a href="index.php?id=enlaces&c=2"> 
          <?  echo $enlace2 ?>
          <span class="n"> (<? echo $c2 ?></span>)</a></b><br>
          <? echo $enlace2definicion ?> </div></td>
      <td><div align="left"><b>�  <a href="index.php?id=enlaces&c=7"> 
          <?  echo $enlace7 ?>
          <span class="n"> (<? echo $c7 ?></span>)</a></b><br>
          <? echo $enlace7definicion ?> </div></td>
    </tr>
    <tr valign="top">
      <td><b>�  <a href="index.php?id=enlaces&c=3"> 
        <?  echo $enlace3 ?>
        <span class="n"> (<? echo $c3 ?></span>)</a></b><br> <? echo $enlace3definicion ?> 
      </td>
      <td><b>�  <a href="index.php?id=enlaces&c=8"> 
        <?  echo $enlace8 ?>
        <span class="n"> (<? echo $c8 ?></span>)</a></b><br> <? echo $enlace8definicion ?> 
      </td>
    </tr>
    <tr valign="top">
      <td><b>�  <a href="index.php?id=enlaces&c=4"> 
        <?  echo $enlace4 ?>
        <span class="n"> (<? echo $c4 ?></span>)</a></b><br> <? echo $enlace4definicion ?> 
      </td>
      <td><b>�  <a href="index.php?id=enlaces&c=9"> 
        <?  echo $enlace9 ?>
        <span class="n"> (<? echo $c9 ?></span>)</a></b><br> <? echo $enlace9definicion ?> 
      </td>
    </tr>
  </table>
</div>
<div align="center" class="titulo"><br>
  Buscar Enlaces</div>
<div align="center">
<form method="post" action="index.php?id=enlaces" form name="formulario" >
<div style="position: absolute ; visibility: hidden"><input type="text" name="aaa"></div>
<input type="text" name="palabras" size="30" maxlength="65" class="form"><p>
<input type="submit" name="buscar" value="Buscar" class="form ">
</form>
  <?
if($buscar) {
include("config.php") ;
$resp = mysql_query("select * from enlaces where descripcion like '%$palabras%'") ;
if(mysql_num_rows($resp) == 0) {
echo "<font color=red>No se encontraron resultados en la b�squeda.</font>" ;
}
else {
while($datos = mysql_fetch_array($resp)) {
echo "
<table width='100%' border='0' cellpadding='5' cellspacing='0' class='tabla_principal'>
  <tr class='tabla_mensaje'> 
    <td width='75%' height='15'><div> 
        <a href=enlaces.php?e=$datos[id] target=\'_blank\'>$datos[titulo]</a></div></td>
    <td width='25%'><div align='right' style='font-size: 8pt'></div></td>
  </tr>
  <tr class='tabla_mensaje'> 
    <td colspan='2'>$datos[descripcion]</td>
  </tr>
  <tr class='tabla_mensaje'> 
    <td width='100%' colspan='2'> <table width='100%' border='0' cellpadding='5' cellspacing='0' class='tabla_mensaje'>
        <tr> 
          <td width='20%'>&nbsp;</td>
          <td width='30%'>&nbsp;</td>
          <td width='50%'><div aling='right'><b>Enviada por:</b> $datos[usuario]</div></td>
        </tr>
      </table></td>
  </tr>
</table><br>
" ;
}
}
}
?></div>
<p class="t1">Enlace seleccionado aleatoriamente
<p>
<?
$resp = mysql_query("select * from enlaces order by rand() limit 1") ;
$datos = mysql_fetch_array($resp) ;
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
  <form method='post' action='enlacescalificar.php?d=<? echo $datos[id] ?>'>
    <tr> 
      <?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
<td width='97%' height="70" class="tabla_subtitulo"> <a href='<? /*Util para edonkey links: si la seccion es 6 se abre el link directamente*/ if($c == "6") {echo "$datos[urlsitio]" ;} else {echo "enlaces.php?e=$datos[id]" ;}?>' target='<? /*Util para edonkey links: si la seccion es 6 se abre en una misma ventana*/ if($c == "6") { echo "_self" ; } else { echo "_blank" ; } ?>'>
� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?>
<br> 
<?
/*Fin de util para edonkey links*/
if($c == "6") {
echo "" ;
}
else {
?>
<b>Visitas:</b> <? echo $datos[visitas] ?> 
<?
}
?>
<b>Votos:</b> <? echo $datos[votos] ?> <b> 
<?
if($datos[urlminibanner] == "") {
?>
<?
}
else {
?>
| <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
<?
}
?>
<b> 
<? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
| <a href="index.php?id=enlaceseditar&enlacesid=<? echo $datos[id] ?>"> 
Editar</a> | 
<?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> <select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<?
mysql_free_result($resp) ;
?>
<p class="t1">Ultimos 10 enlaces
<p>
<?
$mostrar = 10 ;
$resp = mysql_query("select * from enlaces order by id desc limit $mostrar") ;
while($datos = mysql_fetch_array($resp)) {
?>
<table width='100%' border='0' cellpadding='3' cellspacing='0' class="tabla_titulo">
  <form method='post' action='enlacescalificar.php?d=<? echo $datos[id] ?>'>
    <tr> 
      <?
if($datos[imagen] == "") {
echo "" ;
}
else {
echo "<td width='3%' class='tabla_subtitulo'><img src='$datos[imagen]' border='0' width='$tama�oanchoimagen' height='$tama�oaltoimagen' onerror=this.onerror='null';this.src='$errorimagen'></td>" ;
}
?>
<td width='97%' height="70" class="tabla_subtitulo"> <a href='<? /*Util para edonkey links: si la seccion es 6 se abre el link directamente*/ if($c == "6") {echo "$datos[urlsitio]" ;} else {echo "enlaces.php?e=$datos[id]" ;}?>' target='<? /*Util para edonkey links: si la seccion es 6 se abre en una misma ventana*/ if($c == "6") { echo "_self" ; } else { echo "_blank" ; } ?>'>
� <? echo $datos[titulo] ?></a><br> <? echo $datos[descripcion] ?>
<br> 
<?
/*Fin de util para edonkey links*/
if($c == "6") {
echo "" ;
}
else {
?>
<b>Visitas:</b> <? echo $datos[visitas] ?> 
<?
}
?>
<b>Votos:</b> <? echo $datos[votos] ?> <b> 
<?
if($datos[urlminibanner] == "") {
?>
<?
}
else {
?>
| <a href='<? echo $datos[urlminibanner] ?>'  >Ejemplo</a></b> 
<?
}
?>
<b> 
<? if($HTTP_COOKIE_VARS[unick] == "$administrador" or  $HTTP_COOKIE_VARS[unick] == "$datos[usuario]" or  $HTTP_COOKIE_VARS[unick] == "$administrador2" or  $HTTP_COOKIE_VARS[unick] == "$administrador3") {
?>
| <a href="index.php?id=enlaceseditar&enlacesid=<? echo $datos[id] ?>"> 
Editar</a> | 
<?
}
else {
echo "" ;
}
?>
        Calificaci�n:</b> <? echo $datos[calificacion] ?> <b>Calificar:</b> <select name='select' class='form'>
          <option value='1'>1 
          <option value='2'>2 
          <option value='3'>3 
          <option value='4'>4 
          <option value='5' selected>5 </select> <input type='submit' name='enviar' value='Calificar' class='form'> 
      </td>
    </tr>
  </form>
</table>
<br>
<?
}
mysql_free_result($resp) ;
?>
<?
}
?>
