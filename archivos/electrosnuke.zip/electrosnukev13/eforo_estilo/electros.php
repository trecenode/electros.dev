<style>
/* Cuerpo del foro */
body,table {
font-family: verdana ;
font-size: 8pt ;
color: #000000 ;
text-align: justify ;
scrollbar-face-color: #eeeeee ;
scrollbar-darkshadow-color: #000000 ;
scrollbar-shadow-color: #aaaaaa ;
scrollbar-highlight-color: #ffffff ;
scrollbar-3dlight-color: #000000 ;
scrollbar-track-color: #ffffff ;
scrollbar-arrow-color: #000000 ;
}
/* Titulos */
.t1 {
color: #ffa500 ;
font-size: 10pt ;
font-weight: bold ;
filter: glow(color=#000000,strength=3) ;
height: 1 ;
}
.tema {
font-size: 10pt ;
font-weight: bold ;
}
/* Enlaces */
a {
color: #000000 ;
text-decoration: none ;
font-weight: bold ;
}
/* Negrita */
b {
color: #000000 ;
}
/* Tablas del foro */
.tabla {
background: #dddddd ;
}
.tablacolor {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
}
.tabla_principal {
border: #000000 0 solid ;
}
.tabla_titulo {
border-left: #aaaaaa 2 solid ; border-top: #aaaaaa 2 solid ; border-right: #505050 2 solid ; border-bottom: #505050 2 solid ;
background: #757575 ;
}
.tabla_subtitulo {
border-left: #cccccc 2 solid ; border-top: #cccccc 2 solid ; border-right: #aaaaaa 2 solid ; border-bottom: #aaaaaa 2 solid ;
background: #bbbbbb ;
}
.tabla_mensaje {
border-left: #eeeeee 2 solid ; border-top: #eeeeee 2 solid ; border-right: #cccccc 2 solid ; border-bottom: #cccccc 2 solid ;
background: #dddddd ;
}
/* Formulario */
.form {
border: #000000 1 solid ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
</style>
