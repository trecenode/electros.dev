<?
if($_COOKIE["unick"] ) {
?> 
Panel de usuario de <b><? echo $_COOKIE["unick"]  ?></b><p align="center"><br> 
              <? include("config.php") ;
$resp = mysql_query("select id,avatar from usuarios where nick='$_COOKIE[unick]'") ;
$datos = mysql_fetch_array($resp) ;
if(mysql_num_rows($resp) != 0) {
echo "<div align=\"center\"><img src=\"eforo_imagenes/avatares/$datos[id].$datos[avatar]\" width=\"50\" height=\"50\" border=\"0\"></div>" ;
}
?>
</p>
              <form name="form1">
  <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="18%"><div align="center"><a href="?id=uperfil&t=Editar+perfil"><img src="images/info.gif" width="49" height="50" border="0"></a></div></td>
      <td width="28%"><div align="center"><a href="?id=mensajes"><img src="images/messages.gif" width="49" height="50" border="0"></a></div></td>
      <td width="27%"><div align="center"><a href="usalir.php"><img src="images/exit.gif" width="48" height="49" border="0"></a></div></td>
    </tr>
    <tr> 
      <td><div align="center"><strong><a href="?id=uperfil">Editar perfil </a></strong></div></td>
      <td> <div align="center"><strong><a href="?id=mensajes">Mensajes privados</a></strong></div></td>
      <td><div align="center"><strong><a href="usalir.php">Desconectar</a></strong></div></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><div align="center">Tiene 
          <?
include("config.php") ;
$usuario = $HTTP_COOKIE_VARS[unick] ;
$resp = mysql_query("select id from mensajes where nuevo='0' and destinatario='$usuario'") ;
$mensajes = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
mysql_close($conectar) ;
if($mensajes == 0) { echo "0"
?>
          <?
}
else {
?>
          <script>
function BlinkTxt() {
texto = document.getElementsByTagName('blink');
for (i=0; i<texto.length; i++)
if (texto[i].style.visibility=='hidden') {
texto[i].style.visibility='visible';
} else {
texto[i].style.visibility='hidden';
}
setTimeout('BlinkTxt()',100);
}
onload=BlinkTxt;
                      </script>
          <blink>(<? echo $mensajes ; ?>)</blink> 
          <?
}
?>
          mensajes nuevos </div></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
              <table width="99%" border="0" align="center" cellpadding="3" cellspacing="1">
                <tr class="4477444441">
                  <td width="24%"><div align="center" class="Estilo1"><b>Usuarios on-line </b></div></td>
                </tr>
                <tr class="4477444441">
                  <td valign="top" class="33334477444441"><? include("uenlinea.php"); ?>&nbsp;</td>
                </tr>
</table>
</p>
<?
}
else {
?>
</div>
<form method="post" action="uentrar.php">
              <div align="center">Nick:<br>
                <input name="nick" type="text" class="form">
                <br>
                Contrase�a:<br>
                <input name="contrasena" type="password" class="form">
			
                <br>
                <br>
                <input type="submit" name="entrar" value="Entrar" class="form">
			    <input type="hidden" name="pagina" value="<? echo $_SERVER['REQUEST_URI'] ?>">
              </div>
</form>
            
<a href="?id=uregistrar">� Registrate</a><br>
<a href="?id=ucontrasena">� �Olvide contrase�a?</a><br>
 <br> �Todav�a no tienes una cuenta? Puedes <a href="index.php?id=uregistrar">crearte 
            una</a>. Como usuario registrado tendr�s ventajas como cambiar tu 
            perfil, responder comentarios con tu propio nick y enviar enlaces, 
            descargas y scripts.<br> 
            <?
}
?>