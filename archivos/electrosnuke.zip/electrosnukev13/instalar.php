<title>Instalar electrosnuke v13</title>
<style>
body,table {
font-family: verdana ;
font-size: 8pt ;
text-align: justify ;
}
.form {
border: #000000 1 dashed ;
background: #cccccc ;
font-family: verdana ;
font-size: 8pt ;
}
.t1 {
font-size: 15pt ;
font-weight: bold ;
}
</style>
<?
if($enviar) { 
$nuevo = "<?
/////////////////////////////
//|-----------------------|//
//| Electrosnuke v1.3     |//
//| by www.phpmysql.tk    |//
//| by www.electros.tk    |//
//|-----------------------|//
/////////////////////////////

/*--------------- DATOS DE CONEXION ------------*/

\$dbhost  = \"$_0\" ; 
\$dbuser  = \"$_1\" ; 
\$dbpass  = \"$_2\" ;
\$db  = \"$_3\" ;
\$conectar = mysql_connect(\$dbhost,\$dbuser,\$dbpass) ; mysql_select_db(\$db,\$conectar) ;

/*------------------------ ENLACES ------------*/

// Activar(ON) o desactivar(OFF) en la pagina principal index.php
\$menu_enlaces  = \"$_4\" ;
// Configuracion: puedes utilizar caracteres en la definicion como <br>,<b></b> y <p></p> 
\$enlace0  = \"$_5\" ;
\$enlace0definicion  = \"$_6\" ;
\$enlace1  = \"$_7\" ;
\$enlace1definicion  = \"$_8\" ;
\$enlace2  = \"$_9\" ;
\$enlace2definicion  = \"$_10\" ;
\$enlace3  = \"$_11\" ;
\$enlace3definicion  = \"$_12\" ;
\$enlace4  = \"$_13\" ;
\$enlace4definicion  = \"$_14\" ;
\$enlace5  = \"$_15\" ;
\$enlace5definicion  = \"$_16\" ;
\$enlace6  = \"$_17\" ;
\$enlace6definicion  = \"$_18\" ;
\$enlace7  = \"$_19\" ;
\$enlace7definicion  = \"$_20\" ;
\$enlace8  = \"$_21\" ;
\$enlace8definicion  = \"$_22\" ;
\$enlace9  = \"$_23\" ;
\$enlace9definicion  = \"$_24\" ;
// Tama�o de la imagen del enlace (opcional, al editar un enlace).
\$tama�oanchoimagen  = \"$_25\" ;
\$tama�oaltoimagen  = \"$_26\" ;
// Error de una imagen en los enlaces (opcional,util para saber si un enlace o una url esta rota si esta vinculada).
\$errorimagen  = \"$_27\" ;
// Opciones para banner afilados y minibanner afiliados
\$bannerdetupagina  = \"$_28\" ; // 800x600 //
\$minibannerdetupagina   = \"$_29\" ; // 88x31 //

/*------------------------ DESCARGAS ------------*/

// Activar(ON) o desactivar(OFF) en la pagina principal index.php
\$menu_descargas  = \"$_30\" ;
// Configuracion: puedes utilizar caracteres en la definicion como <br>,<b></b> y <p></p> 
\$descarga0  = \"$_31\" ;
\$descarga0definicion  = \"$_32\" ;
\$descarga1  = \"$_33\" ;
\$descarga1definicion  = \"$_34\" ;
\$descarga2  = \"$_35\" ;
\$descarga2definicion  = \"$_36\" ;
\$descarga3  = \"$_37\" ;
\$descarga3definicion  = \"$_38\" ;
\$descarga4  = \"$_39\" ;
\$descarga4definicion  = \"$_40\" ;
\$descarga5  = \"$_41\" ;
\$descarga5definicion  = \"$_42\" ;
\$descarga6  = \"$_43\" ;
\$descarga6definicion  = \"$_44\" ;
\$descarga7  = \"$_45\" ;
\$descarga7definicion  = \"$_46\" ;
\$descarga8  = \"$_47\" ;
\$descarga8definicion  = \"$_48\" ;
\$descarga9  = \"$_49\" ;
\$descarga9definicion  = \"$_50\" ;
// Otras opciones
\$tama�oporarchivoenviado  = \"$_51\" ; // 250 kb aproximadamente //
\$carpetadondeseguardanlosarchivos  = \"$_52\" ;
\$extensiondelarchivosoportada  = \"$_53\" ; // que tipo de archivo pudes subir solamente //

/*------------------------ADMINISTRACION ------------*/

// Configura tu nick de administracion aqui.
\$administrador  = \"$_54\" ;
// Poner otro administrador solo para administrar.php, si no quieres tener mas administradores deja puesto el nick de $administrador
\$administrador2  = \"$_55\" ;

//*************** GENERAL ******************//

// Paginas: titulo de la pagina, estilo de la pagina, url de tu pagina, cabezera o <head> de tu pagina y pie de tu pagina
\$versionelectrosnuke  = \"$_56\" ;
\$titulodelapagina  = \"$_57\" ;
\$estilopagina  = \"$_58\" ; // estilos disponibles : azulverdoso.php,cafe.php,electros.php,oscuro.php,red.php //
\$titulodelportal  = \"$_59\" ; // pon el titulo de tu pagina //
\$urldetupagina  = \"$_60\" ; // la url directa de tu pagina, sin redirecciones //
\$cabezera_pagina = \"$_61\" ;// este script es para que funcionen las cookies, no lo quites si no sabes lo que haces //
\$pie_pagina = \"$_62\" ; // este mensaje puedes cambiarlo, pero estaria bien que dejaras parte de el a modo de agradecimiento //
// Activar(ON) O desactivar(OFF) codigos php : La fecha de hoy, usuarios en linea(anonimos y registrados) y ultimo registrado en usuarios
\$fechadehoy  = \"$_63\" ;
\$usuariosenlinea  = \"$_64\" ;
\$ultimoregistrado  = \"$_65\" ;
// Activar(ON) O desactivar(OFF) menus : lo mas importante de la pagina
\$menu_top  = \"$_66\" ; // la tabla que aparece debajo del banner //
\$menu_usuarios  = \"$_67\" ;
\$menu_afiliados_minibanner  = \"$_68\" ;
\$menu_afiliados_banner  = \"$_69\" ;
// FIN DE LA CONFIGUARCION DE ELECTROSNUKE
?>";
$fich = fopen("config.php","w");
fputs($fich,$nuevo);
fclose($fich);
echo "Cambios guardados con exito en config.php, debes especificar un usuario y contrase�a para el foro pulsa aqui <a href=instalar.php>Volver</a><br>";
if ($_mysql == "si") {
@include ("config.php") ;
mysql_query("
CREATE TABLE enlaces (
  id smallint(5) unsigned NOT NULL auto_increment,
  fecha int(10) unsigned not null,
  usuario varchar(20) not null,
  titulo varchar(100) not null,
  descripcion tinytext not null,
  categoria tinyint(1) unsigned not null,
  urlsitio varchar(100) not null,
  urlminibanner varchar(100) not null,
  urlminibanner2 varchar(100) not null,
  puntos smallint(5) unsigned not null,
  votos smallint(5) unsigned not null,
  calificacion decimal(3,2) unsigned not null,
  visitas smallint(5) unsigned not null,
  eid varchar(10) not null,
  imagen varchar(100) not null,
  primary key (id)
)
") ;
mysql_query("
CREATE TABLE descargas (
  id smallint(5) unsigned NOT NULL auto_increment,
  fecha int(10) unsigned not null,
  usuario varchar(20) not null,
  titulo varchar(100) not null,
  descripcion tinytext not null,
  categoria tinyint(1) unsigned not null,
  urlsitio varchar(200) not null,
  urlminibanner varchar(100) not null,
  puntos smallint(5) unsigned not null,
  votos smallint(5) unsigned not null,
  calificacion decimal(3,2) unsigned not null,
  visitas smallint(5) unsigned not null,
  descarga tinyint(1) not null,
  eid varchar(10) not null,
  imagen varchar(100) not null,
  primary key (id)
)
") ;
mysql_query("
create TABLE noticias (
id tinyint(3) unsigned not null auto_increment,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
validar smallint(1) unsigned not null,
lecturas smallint(1) unsigned not null,
titulo varchar(100) not null,
noticia tinytext not null,
noticiaext text not null,
primary key (id)
)
") ;
mysql_query("
create TABLE noticiascom (
id smallint(5) unsigned not null auto_increment,
noticia tinyint(3) unsigned not null,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
comentario tinytext not null,
primary key (id),
index (noticia)
)
") ;
mysql_query("
create table mensajes (
id smallint(5) unsigned not null auto_increment,
nuevo tinyint(1) unsigned not null,
fecha int(10) unsigned not null,
remitente varchar(20) not null,
destinatario varchar(20) not null,
mensaje tinytext not null,
primary key(id),
index (destinatario)
)
") ;
mysql_query("
create table uenlineavis (
ip varchar(15) not null,
fecha int(10) unsigned not null,
primary key (ip),
index (fecha)
)
") ;
mysql_query("
create table uenlineareg (
usuario varchar(20) not null,
fecha int(10) unsigned not null,
primary key (usuario),
index (fecha)
)
") ;
mysql_query("
create table usuarios (
id smallint(5) unsigned not null auto_increment,
fecha int(10) unsigned not null,
nick varchar(20) not null,
contrasena varchar(20) not null,
email varchar(40) not null,
pais varchar(20) not null,
lista ENUM( '0', '1' ) DEFAULT '1' not null,
edad tinyint(2) unsigned not null,
sexo tinyint(1) unsigned not null,
descripcion tinytext not null,
ip varchar(15) not null,
avatar char(100) not null,
web varchar(100) not null,
firma varchar(100) not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (nick,email)
)
") ;
mysql_query("
create table eforo_categorias (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria varchar(100) not null,
primary key (id),
index (orden)
)
") ;
mysql_query("
create table eforo_foros (
id tinyint(3) unsigned not null auto_increment,
orden tinyint(3) unsigned not null,
categoria tinyint(3) unsigned not null,
foro varchar(100) not null,
descripcion tinytext not null,
temas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
primary key (id),
index (orden,categoria)
)
") ;
mysql_query("
create table eforo_mensajes (
id smallint(5) unsigned not null auto_increment,
foro tinyint(3) unsigned not null,
forotema smallint(5) unsigned not null,
foromostrar enum('0','1') not null,
visitas smallint(5) unsigned not null,
mensajes smallint(5) unsigned not null,
fecha int(10) unsigned not null,
usuario varchar(20) not null,
tema varchar(100) not null,
mensaje text not null,
caretos enum('0','1') not null,
codigo enum('0','1') not null,
url enum('0','1') not null,
firma enum('0','1') not null,
editado int(10) unsigned not null,
ultimo int(10) unsigned not null,
primary key (id),
index (foro,forotema,foromostrar)
)
") ;
mysql_query("
create table eforo_usuarios (
id smallint(5) unsigned not null auto_increment,
fecha int(10) unsigned not null,
nick varchar(20) not null,
contrasena varchar(20) not null,
email varchar(40) not null,
pais varchar(20) not null,
edad tinyint(2) unsigned not null,
sexo enum('0','1') not null,
descripcion tinytext not null,
web varchar(100) not null,
firma tinytext not null,
ip varchar(15) not null,
mensajes smallint(5) unsigned not null,
avatar char(3) not null,
primary key (id),
index (nick,contrasena)
)
") ;
mysql_query("
create table eforo_enlinea (
fecha int(10) unsigned not null,
ip varchar(15) not null,
usuario varchar(20) not null,
index (fecha)
)
") ;
mysql_query("
create table eforo_privados (
id smallint(5) unsigned not null auto_increment,
nuevo tinyint(1) unsigned not null,
fecha int(10) unsigned not null,
remitente varchar(20) not null,
destinatario varchar(20) not null,
mensaje tinytext not null,
primary key (id),
index (destinatario)
)
") ;
mysql_query("
create table eforo_config (
administrador varchar(20) not null,
temas tinyint(3) unsigned not null,
mensajes tinyint(3) unsigned not null,
ultimos tinyint(3) unsigned not null,
codigo enum('ON','OFF') not null,
caretos enum('ON','OFF') not null,
url enum('ON','OFF') not null,
censurar enum('ON','OFF') not null,
estilo varchar(30) not null,
privados tinyint(3) unsigned not null,
avatarlargo smallint(5) unsigned not null,
avatarancho smallint(5) unsigned not null,
avatartamano smallint(5) unsigned not null
)
") ;
echo "<br>
Tablas creadas: 
<p>electrosnuke v.1.3<br>
  <br>
  Tablas creadas: <br>
  <br>
  <b>usuarios<br>
  noticias<br>
  noticiascom <br>
  uenlineavis<br>
  uenlineareg <br>
  mensajes<br>
  enlaces<br>
  descargas</b> <br>
  <br>
  eForo v.2.1</b> 
<p>Tablas creadas: 
<p><b> <br>
  eforo_categorias</b><br>
  <b>eforo_enlinea</b><br>
  <b>eforo_foros</b><br>
  <b>eforo_mensajes</b><br>
  <b>eforo_usuarios</b><br>
  <b>eforo_privados</b><br>
  <b>eforo_config</b><br>
<p>La instalaci�n se ha completado con �xito. Recuerda eliminar este archivo inmediatamente despu�s de la instalaci�n.
";
} else {echo "<font color=red>Deberas crear las tablas mysql, si no las has creado ya antes</font> <a href=instalar.php>Volver</a>";}
}
else {
if($enviar2) {
$contrasena2 = md5(md5($contrasena)) ;
setcookie("unick",$nick,time()+7776000) ;
setcookie("ucontrasena",$contrasena2,time()+7776000) ;
include("config.php") ; 
$ip = $REMOTE_ADDR ;
mysql_query("insert into $tabla_usuarios (fecha,nick,contrasena,ip) values ('$fecha','$nick','$contrasena','$ip')") ;
mysql_query("insert into eforo_config values ('$nick','25','15','15','ON','ON','ON','OFF','electros.php','50','150','150','50')") ;
echo "Cambios guardados con exito en foroconfig.php , pulsa aqui <a href=foroadmin.php>Administrar el foro</a><br>";
}
{
@include("config.php");
?>
<form action="instalar.php" method="post" enctype="multipart/form-data">
  <p class="t1"><a name="electrosnuke">eLECTROSNUKE V.1.3</a>
  <p><strong>1) DATOS DE CONEXION</strong><br>
    <br>
    host 
    <input value="<? echo "$dbhost"; ?>"  name="_0" type="text" class="form" id="_0">
    <br>
    usuaro 
    <input value="<? echo "$dbuser"; ?>"  class="form" name="_1" type="text" id="_1">
    <br>
    contrase�a 
    <input value="<? echo "$dbpass"; ?>"  class="form" name="_2" type="password" id="_2">
    <br>
    base de datos 
    <input value="<? echo "$db"; ?>"  class="form" name="_3" type="text" id="_3">
    <br>
    <br>
    <strong>2) ENLACES </strong><br>
    <br>
    menu de enlaces 
    <select name="_4" id="_4">
      <option value="ON" <? if($menu_enlaces=="ON") {echo"selected";}else{echo"";} ?>>Si</option>
      <option value="OFF" <? if($menu_enlaces=="OFF") {echo"selected";}else{echo"";} ?>>No</option>
    </select>
    <br>
    <br>
    <em>� Recuerda que si deseas tener menos de 9 categorias, deberas borrar las 
    categorias que te sobren<br>
    del archivo<strong> enlaces.php</strong></em><br>
    enlace 0 
    <input value="<? echo "$enlace0"; ?>"  class="form" name="_5" type="text" id="_5">
    <br>
    enlace definicion 0 
    <input name="_6" type="text"  class="form" id="_6" value="<? echo "$enlace0definicion"; ?>" size="50">
    <br>
    enlace 1 
    <input value="<? echo "$enlace1"; ?>"  class="form" name="_7" type="text" id="_7">
    <br>
    enlace definicion 1 
    <input name="_8" type="text"  class="form" id="_8" value="<? echo "$enlace1definicion"; ?>" size="50">
    <br>
    enlace 2 
    <input value="<? echo "$enlace2"; ?>"  class="form" name="_9" type="text" id="_9">
    <br>
    enlace definicion 2 
    <input name="_10" type="text"  class="form" id="_10" value="<? echo "$enlace2definicion"; ?>" size="50">
    <br>
    enlace 3 
    <input value="<? echo "$enlace3"; ?>"  class="form" name="_11" type="text" id="_11">
    <br>
    enlace definicion 3 
    <input name="_12" type="text"  class="form" id="_12" value="<? echo "$enlace3definicion"; ?>" size="50">
    <br>
    enlace 4 
    <input value="<? echo "$enlace4"; ?>"  class="form" name="_13" type="text" id="_13">
    <br>
    enlace definicion 4 
    <input name="_14" type="text"  class="form" id="_14" value="<? echo "$enlace4definicion"; ?>" size="50">
    <br>
    enlace 5 
    <input value="<? echo "$enlace5"; ?>"  class="form" name="_15" type="text" id="_15">
    <br>
    enlace definicion 5 
    <input name="_16" type="text"  class="form" id="_16" value="<? echo "$enlace5definicion"; ?>" size="50">
    <br>
    enlace 6 
    <input value="<? echo "$enlace6"; ?>"  class="form" name="_17" type="text" id="_17">
    <em>/* Util para edonkey link: abre la url en la misma pagina,abre enlace 
    directo*/</em><br>
    enlace definicion 6 
    <input name="_18" type="text"  class="form" id="_18" value="<? echo "$enlace6definicion"; ?>" size="50">
    <br>
    enlace 7 
    <input value="<? echo "$enlace7"; ?>"  class="form" name="_19" type="text" id="_19">
    <br>
    enlace definicion 7 
    <input name="_20" type="text"  class="form" id="_20" value="<? echo "$enlace7definicion"; ?>" size="50">
    <br>
    enlace 8 
    <input value="<? echo "$enlace8"; ?>"  class="form" name="_21" type="text" id="_21">
    <br>
    enlace definicion 8 
    <input name="_22" type="text"  class="form" id="_22" value="<? echo "$enlace8definicion"; ?>" size="50">
    <br>
    enlace 9 
    <input value="<? echo "$enlace9"; ?>"  class="form" name="_23" type="text" id="_23">
    <br>
    enlace definicion 9 
    <input name="_24" type="text"  class="form" id="_24" value="<? echo "$enlace9definicion"; ?>" size="50">
    <br>
    <br>
    <em>� Los campos <strong>tama&ntilde;o de ancho de la imagen</strong> y <strong>tama&ntilde;o 
    de alto de la imagen</strong></em> son<br>
    aplicables tanto en la seccion descargas como en la seccion enlaces<br>
    <br>
    tama&ntilde;o de ancho de la imagen 
    <input value="<? echo "$tama�oanchoimagen"; ?>"  class="form" name="_25" type="text" id="_25">
    <br>
    tama&ntilde;o de alto de la imagen 
    <input value="<? echo "$tama�oaltoimagen"; ?>"  class="form" name="_26" type="text" id="_26">
    <br>
    definir error en la imagen 
    <input name="_27" type="text"  class="form" id="_27" value="<? echo "$errorimagen"; ?>" size="50">
    <br>
    banner de tu pagina 
    <input name="_28" type="text"  class="form" id="_28" value="<? echo "$bannerdetupagina"; ?>" size="75">
    <br>
    minibanner de tu pagina 
    <input name="_29" type="text"  class="form" id="_29" value="<? echo "$minibannerdetupagina"; ?>" size="75">
    <br>
    <br>
    <strong>3) DESCARGAS </strong><br>
    <br>
    menu de descargas 
    <select name="_30" id="_30">
      <option value="ON" <? if($menu_descargas=="ON") {echo"selected";}else{echo"";} ?>>Si</option>
      <option value="OFF" <? if($menu_descargas=="OFF") {echo"selected";}else{echo"";} ?>>No</option>
    </select>
    <br>
    <br>
    <em>� Recuerda que si deseas tener menos de 9 categorias, deberas borrar las 
    categorias que te sobren<br>
    del archivo<strong> descargas.php</strong></em> <br>
    descarga 0 
    <input value="<? echo "$descarga0"; ?>"  class="form" name="_31" type="text" id="_31">
    <br>
    descarga definicion 0 
    <input name="_32" type="text"  class="form" id="_32" value="<? echo "$descarga0definicion"; ?>" size="50">
    <br>
    descarga 1 
    <input value="<? echo "$descarga1"; ?>"  class="form" name="_33" type="text" id="_33">
    <br>
    descarga definicion 1 
    <input name="_34" type="text"  class="form" id="_34" value="<? echo "$descarga1definicion"; ?>" size="50">
    <br>
    descarga 2 
    <input value="<? echo "$descarga2"; ?>"  class="form" name="_35" type="text" id="_35">
    <br>
    descarga definicion 2 
    <input name="_36" type="text"  class="form" id="_36" value="<? echo "$descarga2definicion"; ?>" size="50">
    <br>
    descarga 3 
    <input value="<? echo "$descarga3"; ?>"  class="form" name="_37" type="text" id="_37">
    <br>
    descarga definicion 3 
    <input name="_38" type="text"  class="form" id="_38" value="<? echo "$descarga3definicion"; ?>" size="50">
    <br>
    descarga 4 
    <input value="<? echo "$descarga4"; ?>"  class="form" name="_39" type="text" id="_39">
    <br>
    descarga definicion 4 
    <input name="_40" type="text"  class="form" id="_40" value="<? echo "$descarga4definicion"; ?>" size="50">
    <br>
    descarga 5 
    <input value="<? echo "$descarga5"; ?>"  class="form" name="_41" type="text" id="_41">
    <br>
    descarga definicion 5 
    <input name="_42" type="text"  class="form" id="_42" value="<? echo "$descarga5definicion"; ?>" size="50">
    <br>
    descarga 6 
    <input value="<? echo "$descarga6"; ?>"  class="form" name="_43" type="text" id="_43">
    <em>/* Util para edonkey link: abre la url en la misma pagina,abre enlace 
    directo*/</em><br>
    descarga definicion 6 
    <input name="_44" type="text"  class="form" id="_44" value="<? echo "$descarga6definicion"; ?>" size="50">
    <br>
    descarga 7 
    <input value="<? echo "$descarga7"; ?>"  class="form" name="_45" type="text" id="_45">
    <br>
    descarga definicion 7 
    <input name="_46" type="text"  class="form" id="_46" value="<? echo "$descarga7definicion"; ?>" size="50">
    <br>
    descarga 8 
    <input value="<? echo "$descarga8"; ?>"  class="form" name="_47" type="text" id="_47">
    <br>
    descarga definicion 8 
    <input name="_48" type="text"  class="form" id="_48" value="<? echo "$descarga8definicion"; ?>" size="50">
    <br>
    descarga 9 
    <input value="<? echo "$descarga9"; ?>"  class="form" name="_49" type="text" id="_49">
    <br>
    descarga definicion 9 
    <input name="_50" type="text"  class="form" id="_50" value="<? echo "$descarga9definicion"; ?>" size="50">
    <br>
    <br>
    tama&ntilde;o por archivo enviado 
    <input value="<? echo "$tama�oporarchivoenviado"; ?>"  class="form" name="_51" type="text" id="_51">
    <br>
    carpeta donde se guardan los archivos 
    <input value="<? echo "$carpetadondeseguardanlosarchivos"; ?>"  class="form" name="_52" type="text" id="_52">
    <br>
    extension del archivo soportado 
    <input value="<? echo "$extensiondelarchivosoportada"; ?>"  class="form" name="_53" type="text" id="_53">
    <br>
    <br>
    <strong>4) ADMINISTRACION</strong><br>
    <br>
    administrador 
    <input value="<? echo "$administrador"; ?>"  class="form" name="_54" type="text" id="_54">
    <br>
    administrador 2 
    <input value="<? echo "$administrador2"; ?>"  class="form" name="_55" type="text" id="_55">
    <br>
    <br>
    <strong><a name=tablas>5) GENERAL</a></strong><br>
    <br>
    version de electrosnuke 
    <input value="<? echo "$versionelectrosnuke"; ?>"  class="form" name="_56" type="text" id="_56">
    <br>
    titulo de la pagina 
    <input name="_57" type="text"  class="form" id="_57" value="<? echo "$titulodelapagina"; ?>" size="50">
    <br>
    estilo de la pagina 
    <select name="_58" id="_58">
      <option <? if($estilopagina=="azulverdoso.php") {echo"selected";}else{echo"";} ?> value="azulverdoso.php">Azul 
      verdoso</option>
      <option <? if($estilopagina=="cafe.php") {echo"selected";}else{echo"";} ?> value="cafe.php">Cafe</option>
      <option <? if($estilopagina=="electros.php") {echo"selected";}else{echo"";} ?> value="electros.php">Electros</option>
      <option <? if($estilopagina=="oscuro.php") {echo"selected";}else{echo"";} ?> value="oscuro.php">Oscuro</option>
      <option <? if($estilopagina=="red.php") {echo"selected";}else{echo"";} ?> value="red.php">Red</option>
      <option <? if($estilopagina=="phpmysql.php") {echo"selected";}else{echo"";} ?> value="phpmysql.php">PhpMysql</option>
      <option <? if($estilopagina=="egris.php") {echo"selected";}else{echo"";} ?> value="egris.php">Egris</option>
    </select>
    <br>
    <br>
    titulo del portal 
    <input name="_59" type="text"  class="form" id="_59" value="<? echo "$titulodelportal"; ?>" size="50">
    <br>
    url de tu pagina 
    <input name="_60" type="text"  class="form" id="_60" value="<? echo "$urldetupagina"; ?>" size="50">
    <br>
    cabecera de la pagina<br>
    <textarea name="_61" cols="50" class="form" id="_61"><? echo "$cabezera_pagina"; ?></textarea>
    <br>
    pie de pagina<br>
    <textarea name="_62" cols="50" class="form" id="_62"><? echo "$pie_pagina"; ?></textarea>
    <br>
    <br>
    fecha de hoy 
    <select name="_63" id="_63">
      <option <? if($fechadehoy=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($fechadehoy=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    usuarios en linea 
    <select name="_64" id="_64">
      <option <? if($usuariosenlinea=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($usuariosenlinea=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    ultimo usuario registrado 
    <select name="_65" id="_65">
      <option <? if($ultimoregistrado=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($ultimoregistrado=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    <br>
    menu top 
    <select name="_66" id="_66">
      <option <? if($menu_top=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($menu_top=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    menu usuarios 
    <select name="_67" id="_67">
      <option <? if($menu_usuarios=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($menu_usuarios=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    menu afiliados por minibanner 
    <select name="_68" id="_68">
      <option <? if($menu_afiliados_minibanner=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($menu_afiliados_minibanner=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    menu afiliados por banner 
    <select name="_69" id="_69">
      <option <? if($menu_afiliados_banner=="ON") {echo"selected";}else{echo"";} ?> value="ON">Si</option>
      <option <? if($menu_afiliados_banner=="OFF") {echo"selected";}else{echo"";} ?> value="OFF">No</option>
    </select>
    <br>
    crear las tablas mysql si 
    <input name="_mysql" type="radio" value="si" checked>
    no 
    <input type="radio" name="_mysql" value="no">
    <br>
    <br>
    <input  class="form" name="enviar" type="submit" id="enviar" value="Guardar cambios en el config">
    <br>
</form>
<form action="instalar.php" method="post">
  <p class="t1"><a name="foro">eFORO v.2.1</a>
  <p><br>
    <br>
    Administrador: 
    <input type="text" name="nick" class="form">
    <br>
    Contrase�a: 
    <input type="password" name="contrasena" class="form">
    <br>
    compatibilidad con registro de usuarios 1 (se utilizara la tabla usuarios) 
    :<br>
    Si has seleccionado &quot;no&quot; recuerda que el foro funciona independiente 
    del registro de usurios<br>
    y que tendras que cambiar manualmente en foroconfig.php &quot;$tabla_usuarios&quot;<br>
    <select name="tabla_usuarios" id="tabla_usuarios">
      <option  value="usuarios" selected>Si</option>
      <option  value="eforo_usuarios">No</option>
    </select>
    <br>
    <br>
    <input type="submit" name="enviar2" value="Guardar cambios en el foroconfig" class="form">
</form>
<p><br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <a href="index.php">Volver a la web (Recuerda que debes configurarlo primero)</a><br>
  <br>
  <?
}
}
?>
</p>
