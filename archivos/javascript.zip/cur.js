var Ver4=parseInt(navigator.appVersion.charAt(0))>=4
var IE=navigator.appName.indexOf("Microsoft")!=-1
var al, imagesrc, ex=-32, ey=-32, x0=-32, y0=-32
  
function BewegeCur()
{ // Neue Position des Cur berechnen
  if (Math.abs(ex-x0)>=10) { x0+=Math.floor((ex-x0)*0.1) }
  else if (ex!=x0) { x0+=Math.abs(ex-x0)/(ex-x0) }
  if (Math.abs(ey-y0)>=10) { y0+=Math.floor((ey-y0)*0.1) }
  else if (ey!=y0) { y0+=Math.abs(ey-y0)/(ey-y0) }

  // entsprechende Grafik in Bezug zur Maus-Position waehlen
  imagesrc=""
  if ( (ex<x0) && ( (x0-ex) > Math.abs(y0-ey)/2 ) )
  { imagesrc="cur/cur_l.gif"
    if ( (x0-ex) < Math.abs(y0-ey)*2 )
    { if (ey<y0) imagesrc="cur/cur_lo.gif"
      if (ey>y0) imagesrc="cur/cur_lu.gif"
    }
  }
  if ( (ex>x0) && ( (ex-x0) > Math.abs(y0-ey)/2) )
  { imagesrc="cur/cur_r.gif"
    if ( (ex-x0) < Math.abs(y0-ey)*2 )
    { if (ey<y0) imagesrc="cur/cur_ro.gif"
      if (ey>y0) imagesrc="cur/cur_ru.gif"
    }
  }
  if (imagesrc=="")
  { if (ey<y0) imagesrc="cur/cur_o.gif"
    if (ey>y0) imagesrc="cur/cur_u.gif"
    if ((ex==x0)&&(ey==y0)) imagesrc="cur/cur.gif"
  }

  // Grafik und Position setzen
  if (Ver4)
  { if (!IE)
    { document.CurLayer.document.images.Cur.src=imagesrc }
    else document.all.CurLayer.document.images.Cur.src=imagesrc
  }
  al.left=x0-32
  al.top=y0

  setTimeout("BewegeCur();",100)
}

function MeinMausEvent(e)
{ // Position des Maus-Cursors ermitteln
  if (Ver4)
  { if (!IE)
    { ex=e.pageX
      ey=e.pageY }
    else
    { ex=event.clientX + document.body.scrollLeft
      ey=event.clientY + document.body.scrollTop }
  }
}

function ScriptSetup()
{ // Alle Cur-Grafiken laden
  isIm = (document.images) ? 1 : 0
  if (isIm)
  { arImLoad = new Array
    ('cur','cur_u','cur_o','cur_l','cur_r',
     'cur_lu','cur_lo','cur_ru','cur_ro')
    arImList = new Array ()
    for (counter in arImLoad)
    { arImList[counter] = new Image()
      arImList[counter].src = arImLoad[counter] + '.gif'
    }
  }

  // Globale Variablen setzen und Maus-Event initialisieren
  if (Ver4)
  { if (!IE)
    { al=document.CurLayer
      document.captureEvents(Event.MOUSEMOVE)
    }
    else
    { al=document.all.CurLayer.style }
    document.onmousemove = MeinMausEvent
    BewegeCur()
  }
}

function Copyright()
{ window.focus()
  alert("Copyright 1999 by Timosoft") }

function ZeigeCur()
{ // Setzen der Block-Level Container zur Anzeige der Grafiken
  if(Ver4)
  { s ='<DIV STYLE="visibility:hidden"></DIV>'
    s+='<DIV ID="CurLayer" STYLE="position:absolute; '
    s+='top:-32; left:-32; width:32; height:32">'
    s+='<A HREF="javascript:Copyright();">'
    s+='<IMG NAME="Cur" SRC="cur/cur.gif" border=0>'
    s+='</A></DIV>'
    document.writeln(s)
  }
}

window.onload = ScriptSetup
ZeigeCur()
