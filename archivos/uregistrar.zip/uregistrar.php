<?
include("config.php") ;
if($registrar) {
function quitar($texto) {
$texto = trim($texto) ;
$texto = htmlspecialchars($texto) ;
return $texto ;
}
$nick = quitar($nick) ;
$email= quitar($email) ;
$sexo= quitar($sexo) ;
$edad= quitar($edad) ;
$pais= quitar($pais) ;
$descripcion= quitar($descripcion) ;
// Comprobar que el usuario existe en la base de datos
$resp = mysql_query("select id from usuarios where nick='$nick' or email='$email'") ;
if(mysql_num_rows($resp) != 0) {
echo "<font size=2 face=Verdana, Arial, Helvetica, sans-serif>Ya existe un usuario con ese 
nick o email en la base de datos. Haz click <a href=javascript:history.back()>aqu�</a> 
para regresar.</font>" ;
}
else {
$fecha = time() ;
$contrasena = quitar($contrasena) ;
$ip = $REMOTE_ADDR ;
mysql_query("insert into usuarios (fecha,nick,contrasena,email,ip,avatar,sexo,edad,descripcion,pais)
values ('$fecha','$nick','$contrasena','$email','$ip','$avatar','$sexo','$edad','$descripcion','$pais')") ;
echo "<font size=2 face=Verdana, Arial, Helvetica, sans-serif>Has sido registrado con �xito. Haz click <a href=main.php>aqu�</a> para ir a la p�gina principal.</font>" ;
}
}
else {
?>
                        <p><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Los 
                          datos marcados con un asterisco (*) son obligatorios.</font> 
                          <script>
function revisar() {
if(formulario.nick.value.length < 3) { alert('El nick debe contener por lo m�nimo 3 caract�res') ; return false ; }
if(formulario.contrasena.value.length < 5) { alert('La contrase�a debe contener por lo m�nimo 5 caract�res') ; return false ; }
if(formulario.email.value.length == 0) { alert('Debes poner un email v�lido') ; return false ; }
if(formulario.pais.value.length == 0) { alert('Debes poner un pa�s') ; return false ; }
if(formulario.avatar.value.length == 0) { alert('Debes poner un avatar') ; return false ; }
if(formulario.descripcion.value.length > 255) { alert('La descripci�n supera los 255 caract�res.') ; return false ; }
}
</script>
<SCRIPT type="text/javascript">
<!--
function showimage() {
if (!document.images)
return
document.images.avatar.src=
'images/avatares/' + document.formulario.avatar.options[document.formulario.avatar.selectedIndex].value
}
//-->
</SCRIPT>
<form name="formulario" method="post" action="main.php?secc=registrar" onsubmit="return revisar()">
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* 
                          Nick:</font></b><br>
                          <input type="text" name="nick" maxlength="20" class="form" >
                          <br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* 
                          Contrase�a:</font></b><br>
<input type="password" name="contrasena" maxlength="20" class="form"><br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* 
                          Email:</font></b><br>
                          <input type="text" name="email" maxlength="40" class="form" >
                          <br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">*Pais:</font></b><br>
                          <input type=text name=pais maxlength=20 class=form>
                          <br>
                          <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><b>Edad:</b></font><br>
                          <input type=text name=edad maxlength=2 size=10 class=form>
                          <br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Sexo:</font></b><br>
                          <select name=sexo class=form>
                            <option value=0>Masculino 
                            <option value=1$sexo>Femenino 
                          </select>
                          <br>
                          <br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">* 
                          Avatar:</font></b><br>
<script>
<!--
function update_smiley(newimage)
{
	document.smiley_image.src = "avatares/" + newimage;
}
//-->
</script>




<br>
<select name="avatar" onchange="update_smiley(this.options[selectedIndex].value);">
  <?
$folder = "avatares";
$dir = opendir($folder);
while(false !==($archivos = readdir($dir))){
if($archivos != "." && $archivos != ".." && $archivos != "Thumbs.db"){
$avatars[] = $archivos;
}
}
$tot = count($avatars);
for($x = 0;$x < $tot;$x++){
?>
  <option value="<?=$avatars[$x]?>">
 <?=$avatars[$x]?>
  </option>
  <?
}
?>
</select>
<br>
<img name="smiley_image" src="avatares/<?=$avatars[0]?>" width=64 height=64 border="0" alt="" /> <br>
<br>
                          <br>
                          <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Descripci�n</font></b> 
                          <font face="Verdana, Arial, Helvetica, sans-serif" size="1">:</font><br>
                          <textarea name=descripcion cols=30 rows=5 class=form style=\"font-family: verdana\"></textarea>
                          <br>
<br>
<input type="submit" name="registrar" value="Registrar" class="form">
</form>
<?
}
?>